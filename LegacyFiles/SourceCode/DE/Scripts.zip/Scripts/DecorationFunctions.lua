triggerType = Type()
radius = 10     --how close someone needs to be to get follow behaviour
angleClamp = 0  --0 = no clamp
speed = 30      --degrees per second
reset = true    --reset to original rotation
movementSound = Resource()

local mFollowTarget = nil
local mDesiredAngle = nil

function OnTouched(trigger)
    mFollowTarget = trigger:GetInstigator()
end

function OnUntouched(trigger)
    if not trigger:IsAvatarTouching(mFollowTarget) then
        mFollowTarget = nil
    end
end

function FollowPlayer(decoration)
    local trigger = decoration:Attach(triggerType, EMPTY_SYMBOL)
    ObjectPortHandler(trigger, "OnTouched")
    ObjectPortHandler(trigger, "OnUntouched")
    
    local initialHeading = decoration:GetRotation().heading
    local startRotation = decoration:GetRotation()
    local curRotation = decoration:GetRotation()
    local pos = decoration:GetPosition()
    local followSound = nil
    trigger:SetRadius(radius)
    
    while not IsNull(decoration) do
        if not IsNull(mFollowTarget) then
            mDesiredAngle = LookTo(pos, mFollowTarget:GetPosition())
            mDesiredAngle.bank = 0
            mDesiredAngle.pitch = 0
        else
            if reset then
                mDesiredAngle = startRotation
            else
                mDesiredAngle = curRotation
            end
        end
            
        if angleClamp > 0 then
            mDesiredAngle.heading = Clamp(mDesiredAngle.heading, initialHeading - angleClamp, initialHeading + angleClamp)
        end
        
        local dir = AngleToDirection(curRotation)
        local desiredDir = AngleToDirection(mDesiredAngle)
        local prod = Dot(dir, desiredDir)
        prod = math.acos(prod)
        
        if prod > 0.05 then
            local heading = curRotation.heading
            local desiredHeading = mDesiredAngle.heading
            local diff = math.abs(heading - desiredHeading)
            
            if (heading < desiredHeading and diff >= 180) or (heading > desiredHeading and diff < 180) then
                heading = heading - speed * DeltaTime()
            else
                heading = heading + speed * DeltaTime()
            end
            curRotation.heading = heading
            decoration:SetRotation(curRotation)

            if IsNull(followSound) then
                followSound = decoration:PlaySound(movementSound, false, Engine.SP_VERY_LOW, false)
            end

            else
                if not IsNull(followSound) then
                 followSound:Stop(false)
                 followSound = nil
            end
            
            
        end
        
        Sleep(0)
    end
end
