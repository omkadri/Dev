coverWaypoint = Instance() --Cover Destination
dest = Instance() --Move To Destination
targ = Instance() --Target (Valid for shoot commands only)
shootTime = 1 --Time to shoot if target is given
Anim = Resource() --Animation (Valid for anim actions only)
action = Instance() --Context Action (Valid for context actions only)
run = true --Should this npc run?
align = false --Should this npc align to his destination?
hose = Instance()
patrolRoute = Instance()

exitOnAlert = false --Exit script if agent is alerted (sound perceptions)
exitOnCombat = false --Exit script if agent is in combat (team combat)
exitOnDamage = false --Exit script if agent takes damage
exitOnEnemySeen = false --Exit script if agent sees an enemy (view cone)
exitOnEnemySeenRadius = 10 --Enemy seen radius

neverExit = false
isAnimLooping = false --For animation functions, loop forever if true

spawncontrol = Instance()

local function lobotomizeAgent(agent)
    if IsNull(agent) == false then
        agent:SetExitOnAlertAwareness(false)
        agent:SetExitOnCombatAwareness(false)
        agent:SetExitOnDamage(false)
        agent:SetExitOnEnemySeen(false, exitOnEnemySeenRadius)
    end
end

local function restoreAgent(agent)
    if IsNull(agent) == false then
        agent:SetExitOnAlertAwareness(true)
        agent:SetExitOnCombatAwareness(true)
        agent:SetExitOnDamage(true)
        agent:SetExitOnEnemySeen(true, exitOnEnemySeenRadius)
    end
end

local function setAgent(agent)
    if IsNull(agent) == false then
        agent:SetExitOnAlertAwareness(exitOnAlert)
        agent:SetExitOnCombatAwareness(exitOnCombat)
        agent:SetExitOnDamage(exitOnDamage)
        agent:SetExitOnEnemySeen(exitOnEnemySeen, exitOnEnemySeenRadius)
        if neverExit == true then
            agent:SetAllExits(false)
        end
    end
end

function SetPerceptions(agent)
    if IsNull(agent) == false then
        setAgent(agent)
    end
end

function takeCover(agent)
    setAgent(agent)
    if IsNull(coverWaypoint) == false then
        agent:EnterNearestCover(coverWaypoint, true)
    end
    Sleep(0)
    agent:StopScriptedMode()
end

function moveTo(agent)
    setAgent(agent)
    agent:MoveTo(dest, run, align, true)
    Sleep(0)
    agent:StopScriptedMode()
end

function moveToCover(agent)
    setAgent(agent)
    if IsNull(coverWaypoint) == false then
        agent:EnterNearestCover(coverWaypoint, true)
    end
    Sleep(0)
    agent:StopScriptedMode()
end

function moveToCoverShootPlayer(agent)
    setAgent(agent)
    local player = gRegion:GetPlayerAvatar()
    
    if IsNull(coverWaypoint) == false then
        agent:EnterNearestCover(coverWaypoint, true)
    end
    Sleep(0)
    
    agent:ShootTargetAvatar(player, shootTime, align, true)
    
    agent:StopScriptedMode()
end

function SetPatrolRoute(agent)
    if not IsNull(agent) then
        if not IsNull(patrolRoute) then
            agent:SetPatrolRoute(patrolRoute)
        end
    end
end

function holdPosition(agent)
    setAgent(agent)
    -- agent:SetPaused(true) --DB - please don't lobotomize the agents
    Sleep(5)
    agent:StopScriptedMode()
end

function holdPositionShootPlayer(agent)
    setAgent(agent)
    local player = gRegion:GetPlayerAvatar()
    local npcAvatar = agent:GetAvatar()
    
    --agent:SetAim(true)
    --agent:SetCrouch(true)
    --agent:SetTargetAvatar(player)
    while IsNull(agent) == false or IsNull(npcAvatar) == false do
        if agent:HasActions() == false or agent:LastActionFailed() == true then
            agent:ShootTargetAvatar(player, shootTime, align, true)
        end
        Sleep(0)
    end

    agent:StopScriptedMode()
end

function shootTarget(agent)
    setAgent(agent) 
    if IsNull(targ) == false then
        agent:SetTarget(targ)
        agent:ShootTarget(targ, shootTime, align, true)
    end
    Sleep(0)
    agent:StopScriptedMode()
end

function playAnim(agent)

    --local avatar = agent:GetAvatar()

    setAgent(agent)
    
    if isAnimLooping == true then
        agent:LoopAnimation(Anim)
    else
        agent:PlayAnimation(Anim, true)
    end
    
    --[[agent:PlayAnimation(Anim, true)
    while isAnimLooping do
        if agent:HasActions() == false then
            --agent:PlayLoopingAnimation(Anim, true)
            agent:LoopAnimation(Anim)
            Sleep(0)
        end
        if IsNull(avatar) == true or IsNull(agent) == true then
            break
        end
    end]]
    --agent:StopScriptedMode()
end

function playSimpleAnim(agent)
    agent:PlayAnimation(Anim, true)
end

function moveToAnim(agent)
    
    local avatar = agent:GetAvatar()
    setAgent(agent)
    agent:MoveTo(dest, run, align, true)    
    
    agent:PlayAnimation(Anim, false)
    while isAnimLooping do
        if agent:HasActions() == false then
            agent:PlayAnimation(Anim, true)
            Sleep(0)
        end
        if IsNull(avatar) == true or IsNull(agent) == true then
            break
        end
    end
    
    agent:StopScriptedMode()
end

function useContext(agent)
    setAgent(agent)
    if IsNull(action) == false then
        agent:UseContextAction(action, true)
        Broadcast("Found Context Action!")
    else
        Broadcast("Context Action is Nil!")
    end
    agent:StopScriptedMode()
end

function MoveToPointShootTarget(agent)
    setAgent(agent)
    agent:MoveTo(dest, run, true, true)
    Sleep(0)
    --agent:SetTarget(targ)
    --agent:SetAim(true)
    agent:ShootTarget(targ,shootTime,align,true)
    --agent:ClearTarget()
    agent:StopScriptedMode()
end

function moveToDie(agent)
    setAgent(agent)
    agent:MoveTo(dest, run, true, false)
    Sleep(2)
    hose:FirePort("Start")
end

function ContextMoveTo(agent)

    setAgent(agent)

    if IsNull(action) == false then
        agent:UseContextAction(action, true)
    end
    
    Sleep(0)
    
    agent:MoveTo(dest, run, align, true)
    agent:StopScriptedMode()

end

function ContextMoveToCover(agent)

    setAgent(agent)

    if IsNull(action) == false then
        agent:UseContextAction(action, true)
    end

    if IsNull(coverWaypoint) == false then
        agent:EnterNearestCover(coverWaypoint, true)
    end
    
    agent:StopScriptedMode()

end

function MakeAvatarVIP() 
    local spawnpoints = spawncontrol:GetSpawnPoints()
    local spawnpoint = spawnpoints[1]
    local avatar = spawnpoint:GetActiveAvatar()
    avatar:DamageControl():SetCanRagdoll(true)

    avatar:SetIsVIP()
    avatar:OverrideDisarmAction(Lotus_Game.LotusNpcAvatar_DA_DAMAGE_ONLY)
end
