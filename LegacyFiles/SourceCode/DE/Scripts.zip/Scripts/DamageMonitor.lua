damageMovie = Resource()

function SetData(text)
    mMovie:SetStringVariable("Info", "text", text)
end

function Initialize()

end

function DamageMonitor(avatar)
    Sleep(1)
    
    local movie = gFlashMgr:FindMovie(damageMovie)
    if IsNull(movie) then
        movie = gFlashMgr:PushMovie(damageMovie)
    end
    local dmgControl = avatar:DamageControl()
        
    local lastHealth = avatar:GetHealth()
    local lastShield = dmgControl:GetShield()
    local damageAccum = 0
    
    local timeAccum = 0.0
    local peakDPS = 0.0
    
    while not IsNull(avatar) do
        
        local health = avatar:GetHealth()
        local shield = dmgControl:GetShield()
        timeAccum = timeAccum + DeltaTime()
        
        damageAccum = damageAccum + (lastHealth - health)
        damageAccum = damageAccum + (lastShield - shield)
        lastHealth = health
        lastShield = shield
        
        if timeAccum > 0.0 then
            local dps = math.ceil(damageAccum / timeAccum)
            local info = dps .. " dps"
            peakDPS = math.max(peakDPS, dps)
            info = info .. "\r\n" .. peakDPS .. " peak"
            if not IsNull(movie) and dps > 0 and peakDPS > 0 then
                movie:Execute("SetData", info)
            end
            if timeAccum > 10 then
                timeAccum = 0.0
                damageAccum = 0.0
            end
        end
        Sleep(0)
    end

end