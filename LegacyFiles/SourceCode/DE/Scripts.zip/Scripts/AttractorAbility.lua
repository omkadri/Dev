coneRadius = 5
coneArc = 30
enemyType = Type()
attractorType = Type()
particleEffect = Type()
activateSound = Resource()
activateLocalSound = Resource()
errorSound = Resource()
deactivateSound = Resource()
loopingEffectSound = Resource()

local UTIL = require "EE.Interface.Utilities"

local printPrefix = "AttractorAbility: "

local function SubtractAngle(to, from)
    if (to - from) > 180.0 then
        to = to - 360.0
    end
    
    if (to - from) < -180.0 then 
        to = to + 360.0;
    end
    
    return (to - from)
end

local function VectorToAngle(vec)
    local angle = math.deg(math.acos(Clamp(vec.z, -1.0, 1.0)));
    angle = angle * UTIL.Ternary(vec.x >= 0, 1.0, -1.0);
    return(angle)
end

function Activate(ability, avatar, boost)
    print(printPrefix .. "Activated attractor ability");

    if gRegion:IsMaster() then
        --find all avatar enemies in a cone in front of player
        local pos = avatar:GetPosition()
        local enemies = gRegion:FindAll(enemyType, pos, 0, coneRadius) 
        local motionControl = avatar:MotionControl()
        
        if IsNull(motionControl) or IsNull(enemies)then
            if avatar:IsLocallyAuthoritative() then
                avatar:PlaySound(errorSound, false, false)
            end
            return
        end
        
        print(printPrefix .. "Found " .. #enemies .. " enemies")
        
        local avatarEyeDir = avatar:GetCameraView()
        local avatarHeading = motionControl:GetTorsoRotation().heading
        local inRangeEnemies = {}
        for k,v in ipairs(enemies) do
            local toEnemy = v:GetPosition() - pos
            Normalize(toEnemy)
            local toEnemyHeading = VectorToAngle(toEnemy)
            if Abs(SubtractAngle(avatarHeading, toEnemyHeading)) < coneArc then
                table.insert(inRangeEnemies, v)
            end
        end
        
        print(printPrefix .. "attaching attractor")
        --attach attractor to them
        for k,v in ipairs(inRangeEnemies) do
            local attractor = v:Attach(attractorType, EMPTY_SYMBOL, Vector(0.0, 0.5, 0.0))
            ability:AddToRememberedObjects(attractor)
        end
    end
    
    avatar:Attach(particleEffect, EMPTY_SYMBOL)
    if avatar:IsLocallyAuthoritative() then
        avatar:PlaySound(activateLocalSound, false, false)
    end
    avatar:PlaySound(activateSound, false, false)
end

function Deactivate(ability, avatar)
    if IsNull(ability) then
        print "Error ability is null"
        return
    end
    print(printPrefix .. "Deactivating attractor ability");
    
    if gRegion:IsMaster() then
        local attractors = ability:GetRememberedObjects()
        
        if IsNull(attractors) then
            return
        end
        
        for k,v in ipairs(attractors) do
            if not IsNull(v) then
                v:Destroy()
            end
        end
        
        ability:ClearRememberedObjects()
    end
    
    avatar:PlaySound(deactivateSound, false, false)
end
