sentinelAgentType = Type()

--captureTime = 10.0
captureFx = Type()
captureTargetEffect = Type()
captureBeamType = Type()
captureInputFilter = Resource()
abandonedRange = 50.0
fadeChangeTime = 5

minPlayerRank = 2

minHealthRank = 1
maxHealthRank = 50
maxCoopHealthRank = 100
minHealthDmgMod = 1
maxHealthDmgMod = 0.1
maxCoopHealthDmgMod = 1

local NV_NUM_DEATH_SQUAD_VICTIMS = Symbol("NumDeathSquadVictims")

local function _SpawnSentinel(squadAvatar)
    if gRegion:IsMaster() and not IsNull(squadAvatar:GetAgent()) then
        local npcMgr = gRegion:GetNpcMgr()
        if not IsNull(npcMgr) then
            local sentinelAgent = npcMgr:CreateAgentFromParent(sentinelAgentType, Vector(1,1,1), Rotation(), squadAvatar:GetAgent())
            if not IsNull(sentinelAgent) then
            
                local aiDir = npcMgr:GetAiDirector()
                if not IsNull(aiDir) and not sentinelAgent:IsIgnoredByAiDirector() then
                    aiDir:IncrementMaxPopulationSpawnCount()
                end
            
                local sentinelAvatar = sentinelAgent:GetAvatar()
                if not IsNull(sentinelAvatar) then
                    sentinelAvatar:SetNewCreatorAvatar(squadAvatar)
                    squadAvatar:InventoryControl():SetSentinelForNpc(sentinelAvatar)
                end
                
                if gPromotedToHost then
                    local brandedPlayer = gGameRules:GetBrandedPlayerForNpc(squadAvatar)
                    if brandedPlayer.playerName ~= "" then
                        local humanPlayers = gRegion:GetHumanPlayers()
                        for i = 1, #humanPlayers do
                            if (humanPlayers[i]:GetPlayerName() == brandedPlayer.playerName) then
                                local playerAv = humanPlayers[i]:GetAvatar()
                                while IsNull(playerAv) do
                                    Sleep(0)
                                end                        
                                squadAvatar:WriteDownedPlayerToBlackboard(playerAv)
                                sentinelAvatar:SetOwningPlayerAvatar(playerAv)
                                break
                            end
                        end
                    end
                end
            end
        end
    end
end

local function CalculateDmgMod(bossRank, minRank, maxRank, minMod, maxMod)

    local damageMod
    
    if bossRank > minRank and bossRank <= maxRank then
        damageMod = ((minMod - maxMod)/(maxRank - minRank))
        damageMod = minMod - (damageMod*(bossRank-(minRank+1)))
    elseif bossRank > maxRank then
        damageMod = maxMod
    else
        damageMod = 1
    end
    
    return damageMod

end

function SpawnSentinel(squadAvatar)
    Sleep(0) -- squad agent won't be wired up yet so wait a frame
    if not IsNull(squadAvatar) then
    
        _SpawnSentinel(squadAvatar)
        ObjectPortHandler(squadAvatar, "OnKilled")
        
        if gRegion:IsMaster() then
            local conclave = _T.weaponConclave
            if conclave == nil then
                print("Weapon Conclave is nil!")
                conclave = (minHealthRank + maxHealthRank) / 2
            end
            local players = gRegion:GetHumanPlayerAvatars()
            local healthDmgMod
            
            if #players > 2 then
                healthDmgMod = CalculateDmgMod(_T.weaponConclave, minHealthRank, maxCoopHealthRank, minHealthDmgMod, maxCoopHealthDmgMod)
            else
                healthDmgMod = CalculateDmgMod(_T.weaponConclave, minHealthRank, maxHealthRank, minHealthDmgMod, maxHealthDmgMod)
            end
            
            squadAvatar:DamageControl():AddDamageModifier(Symbol("BossHealthDmgMod"), Engine.DT_ANY, Engine.ANY_PART, healthDmgMod)
        end
    end
end

-- sentinel capturing ability

local function _Fade(changeTime, finalValue)
    local postProcess = gRegion:GetLevelInfo().postProcess
    local startFade = postProcess.fade

    if changeTime == 0 then
        postProcess.fade = finalValue
        Sleep(0)
        return
    end
    
    local t = 0
    local val
    
    while t < 1 do
        val = Lerp(startFade, finalValue, t)
        postProcess.fade = val
        t = t + DeltaTime() / changeTime
        Sleep(0)
    end
    
    postProcess.fade = finalValue
    Sleep(0)
end

function NpcEvaluateAbility(suit, instigatorAvatar, level, maxLevel)
    local squadAvatar = instigatorAvatar:GetCreatorAvatar()
    if not IsNull(squadAvatar) then
    
        local gameRules = gGameRules
        if IsNull(gameRules) then
            return false
        end
    
        local victims = gameRules:GetBrandedPlayers()
        if victims == nil then
            victims = {}
        end
        
        for i = 1, #victims do
            if squadAvatar:IsA(victims[i].squadAvType) and not IsNull(victims[i].playerAv) then
                -- this guy is already capturing someone
                return 0
            end
        end
        
        local targetAv = squadAvatar:GetDownedPlayerFromBlackboard()
        if not IsNull(targetAv) and targetAv:IsPreDeath() then
            if not IsNull(targetAv:GetPlayer()) then
                gameRules:SetBrandedPlayer(targetAv:GetPlayer():GetPlayerName(), squadAvatar)
            end
            suit:SetActivatingAbilityObjectArg(targetAv)
            return 1
        end
    end
    
    return 0
end

function ActivateAbility(suit, instigatorAvatar, target, level, maxLevel)

    local fx = instigatorAvatar:Attach(captureFx, EMPTY_SYMBOL)
    local targetEffect = target:Attach(captureTargetEffect, EMPTY_SYMBOL)
    local beam = instigatorAvatar:Attach(captureBeamType, EMPTY_SYMBOL, Vector(0, 0.5, 0.15))
    if not IsNull(beam) then
        local beamPos = target:GetSimPosition()
        beamPos.y = beamPos.y + 0.9
        beam:SetEndPoint(beamPos)
    end
    instigatorAvatar:SetOwningPlayerAvatar(target)
    
    local gameRules = gGameRules
    
    if target:ReplicaLocallyControlled() then
        local player = target:GetPlayer()
        if not IsNull(player) and player:FactionHunterAvailable(Lotus_Game.FC_GRINEER) and player:GetPlayerRank() >= minPlayerRank then
            gameRules:BrandCurrentSuit(true)
        end
        target:PushInputFilter(captureInputFilter)
    end
    
    local squadAvatar = instigatorAvatar:GetCreatorAvatar()
    
    -- Already called on host in NpcEvaluateAbility to prevent two sentinels from choosing same target,
    -- but need to call again here on client
    if not gRegion:IsMaster() then
        gameRules:SetBrandedPlayer(target:GetPlayer():GetPlayerName(), squadAvatar)
    end
    
    target:DamageControl():PausePreDeath(true)
    if gRegion:IsMaster() then
        target:SetCanBeRevived(false)
        local numDeathSquadVictims = gameRules:GetNetPersistentVar(NV_NUM_DEATH_SQUAD_VICTIMS, 0)
        gameRules:SetNetPersistentVar(NV_NUM_DEATH_SQUAD_VICTIMS, numDeathSquadVictims + 1)
    end
    local checkAbandoned = true    
    while not IsNull(target) and target:IsPreDeath() do
        if checkAbandoned then
            local abandoned = true
            local playerAvs = gRegion:GetHumanPlayerAvatars()
            for i = 1, #playerAvs do
                if target ~= playerAvs[i] and (target:DistanceToEntity(playerAvs[i]) <  abandonedRange) then
                    abandoned = false
                    break
                end
            end
            if abandoned then
                -- resume bleedout
                target:DamageControl():PausePreDeath(false)
                checkAbandoned = false
            end
        end
        Sleep(0)
    end

    -- target no longer valid
    instigatorAvatar:SetOwningPlayerAvatar(squadAvatar)
    
    if not IsNull(fx) then
        fx:Destroy()
    end
    if not IsNull(targetEffect) then
        targetEffect:Destroy()
    end
    if not IsNull(beam) then
        beam:Destroy()
    end

    if not IsNull(target) then
        if gRegion:IsMaster() then
            target:SetCanBeRevived(true)
            local numDeathSquadVictims = gameRules:GetNetPersistentVar(NV_NUM_DEATH_SQUAD_VICTIMS, 0)
            if numDeathSquadVictims > 0 then
                gameRules:SetNetPersistentVar(NV_NUM_DEATH_SQUAD_VICTIMS, numDeathSquadVictims - 1)
            end
        end
        if target:ReplicaLocallyControlled() then
            local targetPlayer = target:GetPlayer()
            target:PopInputFilter(captureInputFilter)
            if target:IsKilled() and targetPlayer and targetPlayer:FactionHunterAvailable(Lotus_Game.FC_GRINEER) and targetPlayer:GetPlayerRank() >= minPlayerRank then
                _T.gCapturedByDeathSquad = true
                gGameRules:FailMissionLocally()
                _Fade(fadeChangeTime, 1)
                
                if not gRegion:IsMaster() then
                    gGameRules:RequestDisconnectFromMission()
                end
            else
                local gameRules = gGameRules
                gameRules:BrandCurrentSuit(false)
            end
        end
        target:DamageControl():PausePreDeath(false)
        gameRules:UnsetBrandedPlayer(target:GetPlayer():GetPlayerName())
    end
end

function OnKilled(squadAvatar)
    if gRegion:IsMaster() then
        local sentinelAv = squadAvatar:InventoryControl():GetSentinel()
        if not IsNull(sentinelAv) then
            sentinelAv:Destroy()
        end
    end
    
    local gameRules = gGameRules
    local victims = gameRules:GetBrandedPlayers()
    if victims == nil then
        victims = {}
    end
    for i = 1, #victims do
        if squadAvatar:IsA(victims[i].squadAvType) then
        
            local player = nil
            local players = gRegion:GetHumanPlayers()
            for j = 1, #players do
                if players[j]:GetPlayerName() == victims[i].playerName then
                    player = players[j]
                    break
                end
            end
            if not IsNull(player) then
                local target = player:GetAvatar()
                if not IsNull(target) then
                    if gRegion:IsMaster() then
                        target:SetCanBeRevived(true)
                        local numDeathSquadVictims = gameRules:GetNetPersistentVar(NV_NUM_DEATH_SQUAD_VICTIMS, 0)
                        if numDeathSquadVictims > 0 then
                            gameRules:SetNetPersistentVar(NV_NUM_DEATH_SQUAD_VICTIMS, numDeathSquadVictims - 1)
                        end
                        target:InstantRevive()
                    end
            
                    target:DamageControl():PausePreDeath(false)
            
                    if target:ReplicaLocallyControlled() then
                        gameRules:BrandCurrentSuit(false)
                        target:PopInputFilter(captureInputFilter)
                    end
                    
                    local targetEffect = target:GetAttachment(captureTargetEffect)
                    if not IsNull(targetEffect) then
                        targetEffect:Destroy()
                    end
                end
                
                gameRules:UnsetBrandedPlayer(victims[i].playerName)
                break
            end
        end
    end
end