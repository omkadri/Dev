local mShipDeco = nil
changeTime = 0.2
fadeValue = 1.0
transportHackTime = 60
exitAnim = Resource()
enterAnim = Resource()
attachAnim = Resource()
detachAnim = Resource()
expTrigger = Type()
weaponType = Type()
upgradeType = 0
--local mCameraSpot = nil

-- Ship Invade
local loopTime = 0.5

local DAMAGE_MULT_SYMBOL = Symbol("DefenseProtect")

local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local timeLeftString = "/Lotus/Language/Objectives/ObjectiveTimeLeft"
local defenseAvatar = nil
local defenseTracker = nil
local spawnControl = nil

local shipDeathImminnent = false -- Stop creating agents when 10s left of ship death
local sCallbackId = Symbol("CrewShipPilot.lua")
local shipHealthCritical = false
local shipEmpty = true
local exteriorAICount = 0

-- Ship Invade, copy/paste, currently has only the bare minimum: no migration, no proper drop, etc

local function AlertCurrentAI(center, radius)
    local avatars = gRegion:GetAvatars()
    for i=1, #avatars do
        local avatar = avatars[i]
        if not avatar:IsKilled() and not IsNull(avatar:GetAgent()) then
            local d = avatar:DistanceToPoint(center)
            if d < radius then
                local agent = avatar:GetAgent()
                agent:SetAlert()
            end
        end
    end
end

local function StartCaptureMission()
    local EncounterType = Type('/Lotus/Types/Gameplay/CrewShip/DynamicCapture')
    local dynamicCaptureHint = gRegion:FindTagged(Symbol('CrewShipCaptureHint'))
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    aiDir:PrimeMissionOnHintWithType(EncounterType, dynamicCaptureHint[1]);
    
    --dynamicCaptureHint:RegisterChildStatusChangedCallback("OnChildStatusChanged", sCallbackId)
end

local function StartCoreSabatoge(reactor)
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()

    local spawnControls = gRegion:FindTagged(Symbol("ShipCoreSpawnControl"))
    
    while IsNull(spawnControls) do
        spawnControls = gRegion:FindTagged(Symbol("ShipCoreSpawnControl"))
        Sleep(0.1)
    end
    
    spawnControl = spawnControls[1]
    local spawnpoints = spawnControl:GetSpawnPoints()
    local spawnpoint = spawnpoints[1]
    spawnControl:Enable()
    spawnpoint:Enable()
    
    spawnControl:Start()
    spawnControl:SpawnAgent()

    defenseAvatar=spawnpoint:GetActiveAvatar()
    if gPromotedToHost then
        while IsNull(defenseAvatar) do
            defenseAvatar = spawnpoint:GetActiveAvatar()
            Sleep(0.0)
        end
    end

    aiDir:SetAllowLockDown(false)
    aiDir:SetLevelAlert(true)
    aiDir:SetObjective(defenseAvatar)
    aiDir:SetCustomSpawnSelectionFilter(0, 150, 0, 1, false, false, false, true, 10, 100)
    aiDir:SetUseCustomSpawnSelectionFilter(true)
    
    aiDir:ResetDeaths()
    aiDir:MarkZoneAlwaysActive(spawnControl)
    aiDir:OrderNpcsStormTarget(defenseAvatar)
    AlertCurrentAI(defenseAvatar:GetPosition(), 250)

    gGameRules:SetDefenseModeTarget(defenseAvatar)
    
    defenseAvatar:SetFaction(Symbol("TENNO"))
    defenseAvatar:SetThreatModifier(2)
    defenseAvatar:SetForceNotTargetable(false)
    
    local hitProxy = defenseAvatar:GetAttachment(gHitProxyType)
    hitProxy:Enable()
    
    local reactorDeco = gRegion:FindTagged(Symbol("Reactor"))
    gRegion:DestroyObject(reactorDeco[1])

    if IsNull(defenseTracker) then
        defenseTracker = _T.AddHudTracker("MDHealthTracker", LOTUS_UTIL.HT_HEALTH_TRACKER, 0.5)
        defenseTracker.SetTarget(defenseAvatar)
        defenseTracker.SetHealthWarningThreshold(20.0)
        defenseTracker.SetRemoveOnNullTarget(true)
    end
end

local function SpawnSetup()
    local OpenCinTags = gRegion:FindTagged(Symbol("OpenCin"))
    local PlayerSpawnTags = gRegion:FindTagged(Symbol("PlayerSpawn"))
    local GrateTags = gRegion:FindTagged(Symbol("Grate"))
    for x = 1, #PlayerSpawnTags do
        local temp = PlayerSpawnTags[x]
        local zone = temp:GetZone()
        local index = zone:GetLayerIndex()
        if index == 1 then
            temp:FirePort("Enable")
        end
    end
    for x = 1, #OpenCinTags do
        local temp = OpenCinTags[x]
        local zone = temp:GetZone()
        if not IsNull(zone) then
            local index = zone:GetLayerIndex()
            if index == 1 then
                _T.OpeningCin = temp
                ObjectPortHandler(temp, "OnStopped")
            end
        end
    end
    for x = 1, #GrateTags do
        local temp = GrateTags[x]
        local zone = temp:GetZone()
        if not IsNull(zone) then
            temp:FirePort("Hide")
            temp:Destroy()
        end        
    end
end

local function DefendSucceeded(crewShip)
    if _T.coreEnabled then
        crewShip:DestroyShip()              
        _T.RemoveHudTracker(defenseTracker)
        _T.coreEnabled = false
    end
end

local function DefendFailed(crewShip)
    if _T.coreEnabled then
        defenseAvatar:SetFaction(crewShip:GetAvatarOwner():GetFaction())
        defenseAvatar:SetThreatModifier(-5)
        defenseAvatar:SetForceNotTargetable(true)
        defenseAvatar:DamageControl():AddDamageModifier(DAMAGE_MULT_SYMBOL, Engine.DT_ANY, Engine.ANY_PART, 0)

        local hitProxy = defenseAvatar:GetAttachment(gHitProxyType)
        hitProxy:Disable()

        spawnControl:Disable()
        _T.coreEnabled = false
        defenseAvatar = nil
    end
end

local function StartShipInvade(crewShip)
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    _T.coreEnabled = false
    
    print("ShipInvade: Main gameplay loop started") -- Event log
    local initialized = false
    local captureInitialized = false
    local shipReactors = gRegion:FindTagged(Symbol("ReactorSetUp"))
    local shipAvatar = crewShip:GetAvatarOwner()
    
    while true do -- Main loop: TODO: Should separate client loop and host loop
        Sleep(loopTime)
        
        if shipAvatar:GetHealthPercentage() < 0.01 and not shipAvatar:DamageControl():IsAllShieldUp() and not shipHealthCritical then
            shipHealthCritical = true
        elseif shipHealthCritical and shipAvatar:DamageControl():IsAllShieldUp() then
            shipHealthCritical = false
        end

        local avatars = gRegion:GetHumanPlayerAvatars()
        shipEmpty = true
        for i = 1, #avatars do
            local player = avatars[i]
            if player and player:InventoryControl():GetOnBoardShip() == crewShip then
                shipEmpty = false
            end
        end
        
        if not captureInitialized then
            StartCaptureMission()
            captureInitialized = true
        end
        
        if _T.coreEnabled and not initialized then
            initialized = true

            if IsNull(shipReactors[1]) then
                shipReactors = gRegion:FindTagged(Symbol("ReactorSetUp"))                
            end

            StartCoreSabatoge(shipReactors[1])
        end
        
        if _T.coreEnabled then
            local health = defenseAvatar:GetHealth()
            if health <= 0 then
                DefendFailed(crewShip)
                Sleep(1)
            end
            
            if _T.crewShipDefendResult == 1 then
                DefendSucceeded(crewShip)
                _T.crewShipDefendResult = nil
                break                
            elseif _T.crewShipDefendResult == 2 then
                DefendFailed(crewShip)
                _T.crewShipDefendResult = nil
                break                
            end
        end
    end
end

function InitializeShipInvade(crewShip)
    SpawnSetup()
    
    if gRegion:IsMaster() then
        gGameRules:ResetAliveTime()
    end
    
    StartShipInvade(crewShip)
    
    print("ShipInvade: Main gameplay loop over, out of ship")
end

function OnChildStatusChanged(childHint)
    local encounterStatus = childHint:GetEncounterStatus() 
    if encounterStatus == Npc.ES_SUCCEEDED then
        _T.crewShipDefendResult = 1
    elseif encounterStatus == Npc.ES_FAILED or encounterStatus == Npc.ES_SHUTDOWN then 
        _T.crewShipDefendResult = 2
    end
end

function enableCoreObjective(reactor, avatar)
    _T.coreEnabled = true
    _T.crewShipDefendResult = 0
    
    local EncounterType = Type('/Lotus/Types/Gameplay/CrewShip/DynamicDefend')
    local dynamicDefendHint = gRegion:FindNearestTagged(Symbol('DefendHint'), reactor:GetPosition())
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    aiDir:PrimeMissionOnHintWithType(EncounterType, dynamicDefendHint);
    
    dynamicDefendHint:RegisterChildStatusChangedCallback("OnChildStatusChanged", sCallbackId)
end

-------------------------------------------------------------------------------------------------------------------------

function ActivateArchwing(scriptTrigger)
    local instigator = scriptTrigger:GetInstigator()
    
    if IsNull(instigator) then
        return
    end

    local inventoryController = instigator:InventoryControl()
    local boardedShip = inventoryController:GetOnBoardShip()
    
    if not IsNull(boardedShip) then
        if instigator ~= gRegion:GetLocalPlayerAvatar() then
            inventoryController:SetOnBoardShip(nil)
            return
        end

        instigator:PlayAnimation(exitAnim, false, Engine.ATMM_ANIMATION_DRIVEN)
        Sleep(changeTime)
        local postProcess = instigator:CameraControl():ScriptGetCurrentPostProcessInfo()
        local startFade = 0 
        local t = 0
        local val
    
        while t < 1 do
            val = Lerp(startFade, fadeValue, t)
            postProcess.fade = val
            t = t + DeltaTime() / 0.5
            Sleep(0)
        end
        instigator:MotionControl():NotifyCinematic(true)
        postProcess.fade = fadeValue

        local shipAvatar = boardedShip:GetAvatarOwner()
        local triggerType = WeakResource("/Sandbox/JacquesWaller/CrewShip/BoardShip")
        local boardTrigger = shipAvatar:GetAttachment(triggerType)
        local shipRotation = shipAvatar:GetRotation()
        
        local spawnPos = boardTrigger:GetPosition() - boardedShip:GetParallaxOffSet(instigator)
        local spawnRot = CombineRotations(shipRotation, instigator:GetSimRotation())
        local viewRot = CombineRotations(shipRotation, instigator:GetCameraView())

        instigator:Teleport(spawnPos, spawnRot)
        instigator:SetView(viewRot)

        inventoryController:SetOnBoardShip(nil)
        
        instigator:PlayAnimation(attachAnim, false)
        
        local downwardVelocity = Vector(0, -10, 0)
        downwardVelocity = RotateVector(downwardVelocity, shipRotation)
        
        t = 0
        while t < 1 do
            instigator:MotionControl():SetPushVelocity(downwardVelocity, true)
            val = Lerp(fadeValue, startFade, t)
            postProcess.fade = val
            t = t + DeltaTime() / 0.2
            Sleep(0)
        end

        postProcess.fade = startFade
    end
end

function InitializeEmplacement(emplacementAvatar, priorityVal)

    while IsNull(_T.CurrentHudAvatar) do
        Sleep(0)
    end

    if _T.CurrentHudAvatar:GetFaction() ~= emplacementAvatar:GetFaction() then
        return
    end
   
    local name = "Emplacement" .. priorityVal -- Should have better way to distinguish each emplacement
    print(name)
    
    emplacementAvatar:SetLocTag(Symbol(name)) -- Should Use actual Loc Tag instead
    emplacementAvatar:SetThreatModifier(2)
    emplacementAvatar:SetForceNotTargetable(false)
    emplacementAvatar:DamageControl():RemoveDamageModifier(DAMAGE_MULT_SYMBOL)
    emplacementAvatar:DamageControl():RemoveInvulnerabilityBuff(DAMAGE_MULT_SYMBOL)

    local emplacementTracker = _T.AddHudTracker(name, LOTUS_UTIL.HT_HEALTH_TRACKER, 0.5, priorityVal, false, false)
    emplacementTracker.SetTarget(emplacementAvatar)
    emplacementTracker.SetHealthWarningThreshold(20.0)
    emplacementTracker.SetRemoveOnNullTarget(true)

end

function SetUpTransportHack(shipAvatar, transport, hackConsole, smoke)
    local shipAvatarTracker = _T.AddHudTracker("ShipHealthTracker", LOTUS_UTIL.HT_HEALTH_TRACKER, 10)
    shipAvatarTracker.SetTarget(shipAvatar)
    shipAvatarTracker.SetHealthWarningThreshold(20.0)
    shipAvatarTracker.SetRemoveOnNullTarget(true)
    local transportTimer = _T.AddHudTracker("ShipDefenseTimer", LOTUS_UTIL.HT_TIMER, 0.25)
    transportTimer.SetLabel(timeLeftString)
    transportTimer.StartTimer(transportHackTime, false, true)
    _T.TransportHack = 0

     while true do
        Sleep(0.1)

        if transportTimer.Data.Time <= 0 or _T.TransportHack == 2 then
            local damageAmount = shipAvatar:GetMaxHealth() / 10
            local dd = Engine.DamageData()
            dd.baseAmount = damageAmount
            dd:SetDamagePct(Engine.DT_EXPLOSION, 1.0)
            dd:SetSource(shipAvatar)
            dd:SetHitPart(Engine.TORSO)
            shipAvatar:DamageDD(dd)
            break
        elseif _T.TransportHack == 1 then
            break
        end
    end   
    
    _T.RemoveHudTracker(transportTimer)
    gRegion:DestroyObject(smoke)

    if gRegion:IsMaster() then
        local explosion = gRegion:CreateEntity(expTrigger, transport:GetPosition(), transport:GetRotation())    
        transport:Unattach()
        transport:Suicide()
        hackConsole:Disable()       
    
        Sleep(1)

        gRegion:DestroyObject(explosion)
    end
end

function HackTransport(avatar, result, action)
    if IsNull(avatar) then
        return
    end

    if result == nil then
        result = 1
    end

    if result == 1 then
        _T.TransportHack = 1
    else
        _T.TransportHack = 2
    end

end

function WeaponCacheAction(action, instigator)
    instigator:GiveItem(weaponType, true)
end

function UpgradeShip(action, instigator)
    local inventoryController = instigator:InventoryControl()
    local boardedShip = inventoryController:GetOnBoardShip()
    local shipIC = boardedShip:GetAvatarOwner():InventoryControl()

    if upgradeType == 1 then    
        shipIC:AddUpgrade(Game.AVATAR_MOVEMENT_SPEED, Game.ADD, 1)
    elseif upgradeType == 2 then
        shipIC:AddUpgrade(Game.AVATAR_ACROBATIC_SPEED, Game.ADD, 1) -- Ship turn rate
    end

end


-- UI code is below

function Initialize()
    mMovie:SetLuaRawInputEnabled(true)
    
    local avatar = gRegion:GetLocalPlayerAvatar()
    local player = avatar:GetPlayer()
    local crewShip = player:GetCrewShip()
    
    if not IsNull(crewShip) then
        mShipDeco = crewShip:GetAvatarOwner()
--        mCameraSpot = mShipDeco:GetAttachment(gCameraSpotType)
    end
    
--    if not IsNull(mCameraSpot) then
--        avatar:CameraControl():SetTransitionToCameraSpotTime(0.0)
--        avatar:CameraControl():SetCameraSpot(mCameraSpot, 0.0)
--    end
end

local smoothLX = SmoothFloat(0, 1)
local smoothLY = SmoothFloat(0, 1)

local mFiring = false

local function FlyZone(lx, ly)
    
    if IsNull(mShipDeco) or true then
        return
    end
    
    local delta = DeltaTime()
    local rotation = mShipDeco:GetSimRotation()
    
    local turnRate = 10.0
    local pitchRate = 2.0
    
    
    if lx and ly then
        lx = smoothLX:SetUpdateAndFetch(lx, delta)
        ly = smoothLY:SetUpdateAndFetch(ly, delta)
        
        -- squared response
        lx = lx * math.abs(lx)
        ly = ly * math.abs(ly)
        
        rotation.heading = rotation.heading + delta * lx * 20
        rotation.pitch = Clamp(rotation.pitch + delta * ly * 40, -80, 80)
        rotation.bank = lx * -20
                
    else
        local t = Frac(Time() * 0.1)
        local turn = math.sin(math.pi * 2.0 * t)
        --rotation.heading = rotation.heading + delta * turn * turnRate
        --rotation.pitch = rotation.pitch + delta * turn * pitchRate
        rotation.bank = rotation.bank + delta * pitchRate * -0.3
    end
    
    local moveRate = 1.0
    local position = mShipDeco:GetPosition()    
    local dir = AngleToDirection(rotation)
    dir = dir * (moveRate * delta)
    position = position + dir 
    mShipDeco:Teleport(position, rotation)
end

function AutoPilot()
    while not _T.CrewShipPilot do
        FlyZone()
        Sleep(0.0)
    end
end

-- every frame, the movie/UI screen will get this callled by the game engine
function Update()
    _T.CrewShipPilot = true
    local mouseX = mMovie:GetCursorX()
    local mouseY = mMovie:GetCursorY()
    
    local leanX = (mouseX / mMovie:GetViewportWidth()) * 2 - 1
    local leanY = (mouseY / mMovie:GetViewportHeight()) * 2 - 1
    
    FlyZone(leanX, leanY)
    
end

function onRawInputEvent(deviceID, keyName, isDown)
    
    if string.find(keyName, "MOUSE_B0") ~= nil then
        if isDown == "1" then
            mFiring = true
        else
            mFiring = false
        end
    end
    
end


function onKeyDown_MENU_CANCEL()
    mMovie:Close() 
    local spaceZone = gRegion:FindFirstTagged(Symbol("SafeZone"))
    _T.CrewShipPilot = nil
    spaceZone:ScriptRunChildScript(Symbol("AutoPilot"), false)

    local avatar = gRegion:GetLocalPlayerAvatar()    
--    avatar:CameraControl():SetCameraSpot(nil)
    
    local instigator = mMovie:GetInstigator()
    if not IsNull(instigator) then
        instigator:SetUserSelection(2)
--        instigator:DoPostAction(avatar)
    end
end

function onKeyDown_MENU_SELECT()
    mMovie:Close() 
    --local spaceZone = gRegion:FindFirstTagged(Symbol("SpaceZone"))
    _T.CrewShipPilot = nil
    --spaceZone:ScriptRunChildScript(Symbol("AutoPilot"), false)
    
    local boardingMarker = gRegion:FindFirstTagged(Symbol("Boarding"))
    local avatar = gRegion:GetLocalPlayerAvatar()
    avatar:Teleport(boardingMarker:GetPosition())
--    avatar:CameraControl():SetCameraSpot(nil)
    
end
