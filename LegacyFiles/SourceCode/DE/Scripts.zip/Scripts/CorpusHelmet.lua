

Hitproxy = Type()
HelmetDynamicFx=Type()
DamageSymbol = Symbol("ProtectedHead")


function HelmentHead(entity)
    local avatar = entity:GetAttachParent()

    while IsNull(avatar) and not IsNull(entity) do
        avatar = entity:GetAttachParent()
        Sleep(0)
    end

    if IsNull(avatar) or IsNull(entity) then
        return
    end

    avatar:DamageControl():AddDamageModifier(DamageSymbol, Engine.DT_ANY, Engine.HEAD , 0)
    avatar:DamageControl():AddShieldDamageModifier(DamageSymbol, Engine.DT_ANY, Engine.HEAD, 0)
    while entity:GetHealth() > 0 do
        Sleep(.1)
        if avatar:IsKilled() then
            entity:SetPhysicsBehaviorAndRegister(nil)
        end
    end
    entity:SetDissolve(1)
    
    avatar:DamageControl():RemoveDamageModifier(DamageSymbol)
    avatar:DamageControl():RemoveShieldDamageModifier(DamageSymbol)
    local pos = entity:GetPosition()
    pos.y = pos.y - 1
    gRegion:CreateEntity(HelmetDynamicFx,pos,entity:GetRotation(),avatar)
    
    gRegion:DestroyObject(entity)
    
end