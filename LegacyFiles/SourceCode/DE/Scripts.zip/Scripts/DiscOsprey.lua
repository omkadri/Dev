discDelay = 3
discScaleTime = 0.5
discDesiredScale = 6
discType = Type()
discRingType = Type()
fxAttachUp = Type()
fxAttachDown = Type()
hitProxy = Type()

fadeDelay = 0
TimeLength = 6
Peak = 0.5
PeakEnd = 5
PeakValue = 1
ValleyValue = 0
ValleyEndValue = 0
Param = Symbol()
destroyAtEnd = true
bounceProj = true

local emissiveParam = Symbol("EmissiveMapAtten")

function OnStopped(projectile)
    
    local t = 0
    local val = 0
    
    local discUpDelay = 0.9 * discDelay
    local discDownDelay = 0.1 * discDelay
    
    local startPos = projectile:GetSimPosition()
    local startRot = projectile:GetRotation()
    
    local weapon = projectile:GetInstigatorItem()
    
    projectile:Attach(fxAttachUp, EMPTY_SYMBOL, ZERO_VECTOR, Rotation(0, 90, 0), weapon)
    local proxy = projectile:Attach(hitProxy, EMPTY_SYMBOL)
    
    if bounceProj then
        while t < discUpDelay and not IsNull(projectile) do -- Go UP
            val = SmoothStep(t / discUpDelay)
            projectile:SetPosition(Vector(startPos.x, startPos.y + 2.2 * val, startPos.z))  --Move it up 2.2m
            local newRot = Rotation(Lerp(startRot.heading, 0, val), Lerp(startRot.pitch, 0, val), Lerp(startRot.bank, 0, val))
            projectile:SetRotation(newRot)
            projectile:SetMaterialParam(emissiveParam, 1 + val * 4)
            t = t + DeltaTime()
            Sleep(0)
        end
        
        if IsNull(projectile)  or (projectile:GetHealth() <= 0) then
            return
        end
        
        projectile:Attach(fxAttachDown, EMPTY_SYMBOL, ZERO_VECTOR, Rotation(0, -90, 0), weapon)
        t = discDownDelay
        while t > 0  and not IsNull(projectile) do -- Smash down
            val = 1 - math.pow(1 - t / discDownDelay, 4)
            projectile:SetPosition(Vector(startPos.x, startPos.y + 2.0 * val + 0.2, startPos.z))
            t = t - DeltaTime()
            Sleep(0)
        end
        
        if IsNull(projectile) or (projectile:GetHealth() <= 0) then
            return
        end
    end
    
    projectile:SetPosition(Vector(startPos.x, startPos.y + 0.2, startPos.z))

    if gRegion:IsMaster() then
        local disc = gRegion:CreateEntity(discType, startPos + Vector(0,0.2,0), Rotation(), weapon)
        local instigator = projectile:GetInstigator()
        if not IsNull(disc) and not IsNull(instigator) then
            local triggers = disc:GetAllAttachments(gTriggerType)
            for i, trigger in ipairs(triggers) do
                trigger:SetThrowingEntity(instigator)
            end
        end
    end

    projectile:ScheduleDie(0.01) --Destroy the projectile now. needs to be > 0
end

function MaterialFadeFlatPeakAndScale(deco)
    Sleep(0)
    local currentScale = 1
    local timeRemaining = discScaleTime
    local ring = deco:Attach(discRingType, EMPTY_SYMBOL, Vector(0, -.25, 0))
    
    while (timeRemaining > 0) do
        if not IsNull(ring) then
            currentScale = ring:GetMeshScale()
            ring:SetMeshScale(Lerp(discDesiredScale, currentScale, timeRemaining / discScaleTime))
        end
        timeRemaining = timeRemaining - DeltaTime()
        Sleep(0)
    end
    
    Sleep(fadeDelay)

    local t = 0
    local fading
    local val
    local v = ValleyValue
    
    while t < TimeLength do
        if t < Peak then
            fading = t/Peak
        else if t < PeakEnd then
                fading = 1
            else
                v = ValleyEndValue
                fading = 1 - (t-PeakEnd)/(TimeLength-PeakEnd)
            end
        end
        if fading < 0 then
            fading = 0
        end
        val = Lerp(v, PeakValue, fading)
        if not IsNull(ring) then
            ring:SetMaterialParam(Param, val)
        end
        t = t + DeltaTime() 
        Sleep(0)
    end
    if destroyAtEnd and not IsNull(deco) then
        deco:Destroy()
    end
end


