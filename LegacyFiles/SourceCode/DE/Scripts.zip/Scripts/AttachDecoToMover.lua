moverMesh = Type()
mover = Instance()
hiddenMaterial = Resource() 
attachmentType = Resource()
normalPhysics = Resource()
attachmentDelay = 0
destroyDelay = 0
moverDelay = 0

function destroyAttachments()
    Sleep(destroyDelay)
    local attachments = mover:GetAllAttachments(attachmentType)
    for k, attachment in ipairs(attachments) do
        attachment:Destroy()
    end
end
    
function attachToMover()
    Sleep(attachmentDelay)
    local attachment = gRegion:CreateEntity(moverMesh, ZERO_VECTOR, ZERO_ROTATION)
    mover:AttachEntity(attachment, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION) 
    mover:SetOverrideMaterial(0,hiddenMaterial)
    mover:SetPhysicsBehaviorAndRegister(nil)
end

function showMover()
    mover:RemoveAllOverrideMaterials()
    mover:SetPhysicsBehaviorAndRegister(normalPhysics)
end

function delayMover(entity)
    Sleep(moverDelay)
    entity:FirePort("Start")
end