aimGravitySpawner = Type()
aimGravityEnterSound = Resource()
aimGravityExitSound = Resource()
aimGlideAttach = Type()

mixerRatioSpeed = 1.0
mixingGroups = { Resource() }
mixingGains = { 0.0 }
mixingOcclusions = { 0.0 }

local function MixingInterpolation(mixerRatio)
    for i=1,#mixingGroups do
        local mixingGroup = mixingGroups[i]
        if not IsNull(mixingGroup) and mixingGains[i] and mixingOcclusions[i] then
            mixingGroup:SetGainBias(Lerp(0.0, mixingGains[i], mixerRatio))
            mixingGroup:SetOcclusionBias(Lerp(0.0, mixingOcclusions[i], mixerRatio))
        end
    end
end

function AimGravityFX(avatar)
    local isPlayerAvatar = avatar:IsA(gTennoAvatarType)
    local spawner = nil
    local projector = nil
    
    Sleep(0.1)
    if avatar:GetPosture() == Engine.WALLRUNNING_LEFT or avatar:GetPosture() == Engine.WALLRUNNING_RIGHT or avatar:GetPosture() == Engine.WALLRUNNING_UP then
        return
    end
    
    avatar:PlaySound(aimGravityEnterSound, false, -1, false)
    if not IsNull(aimGravitySpawner) then
        spawner = avatar:Attach(aimGravitySpawner, EMPTY_SYMBOL)
    end
    
    if not IsNull(aimGlideAttach) then
        projector = avatar:Attach(aimGlideAttach, EMPTY_SYMBOL)
    end
    
    local mixerRatio = 0
    local aimGravRatio = avatar:GetAimGravityRatio()
    while not IsNull(avatar) and not avatar:IsKilled() and (avatar:HasPostureModifier(Engine.PM_AIM) or avatar:HasPostureModifier(Engine.PM_PARRY)) and avatar:HasPostureModifier(Engine.PM_IN_AIR) and avatar:GetAimGravityRatio() > 0.0 do
        if isPlayerAvatar and not avatar:IsHumanPlayer() then
            break
        end
        
        aimGravRatio = avatar:GetAimGravityRatio()
        if not IsNull(projector) then
            projector:SetMaterialParam(Lotus_Game.ALPHA_ATTEN, math.pow(Clamp(aimGravRatio * 2, 0, 1), 0.5))
        end
        
        
        mixerRatio = Clamp(mixerRatio + DeltaTime() * mixerRatioSpeed, 0, 1)
        MixingInterpolation(mixerRatio)
        
        Sleep(0)
    end
    
    -- play cancel FX
    if not IsNull(avatar) and not avatar:IsKilled() then
        avatar:PlaySound(aimGravityExitSound, false, -1, false)
    end
    
    if not IsNull(spawner) then
        spawner:Destroy()
    end
    
    if not IsNull(projector) then
        projector:Destroy()
    end
    
    while mixerRatio > 0.0 do
        mixerRatio = Clamp(mixerRatio - DeltaTime(), 0.0, 1.0)
        MixingInterpolation(mixerRatio)
        Sleep(0)
    end
end
