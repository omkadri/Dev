movers = { Instance() } -- ports into Close port to close, and Open port to open
openDelay = 0.2 -- delay after avatars uncrouch before the hatch opens
closeDelay = 0.4 -- delay after avatars crouch before the hatch closes

function CheckPosture(entity)

    if IsNull(movers) or #movers == 0 then
        print("No movers detected for bunker hatch.")
        return
    end
    
    local avatars = entity:GetEntitiesTouching()
    local crouching = true
    while #avatars > 0 do
        crouching = true
        avatars = entity:GetEntitiesTouching()
        for i = 1, #avatars do
            if
                avatars[i]:HasPostureModifier(Engine.PM_AIM) or (
                avatars[i]:GetPosture() ~= Engine.CROUCH and 
                avatars[i]:GetPosture() ~= Engine.CROUCH_COVER_LEFT and
                avatars[i]:GetPosture() ~= Engine.CROUCH_COVER_RIGHT)
            then
                crouching = false
            end
        end
        
        if crouching and movers[1]:IsDoorOpened() then
            Sleep(closeDelay)
            for i = 1, #movers do
                movers[i]:FirePort("Close")
            end
        elseif not crouching and not movers[1]:IsDoorOpened() then
            Sleep(openDelay)
            for i = 1, #movers do
                movers[i]:FirePort("Open")
            end
        end
        Sleep(0.1)
    end
    
    for i = 1, #movers do
        movers[i]:FirePort("Close")
    end
    
end