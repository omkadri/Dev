turretSpawnPoints = { Instance() }
local turretDuration = 16

function StartTurrets(avatar, result, instigator)
    if #turretSpawnPoints == 0 then
        return
    end

    if IsNull(avatar) then
        return
    end
    
    local agent = avatar:GetAgent()
    if not IsNull(agent) then
        result = 1
    end
    
    if result == nil then
        result = 1
    end

    if result == 1 then
        for i = 1, #turretSpawnPoints do
            local activeAvatar = turretSpawnPoints[i]:GetActiveAvatar()
            if not IsNull(activeAvatar) then
                activeAvatar:IncrementActivationRequests()
                activeAvatar:SetLevel(agent:GetCurrentLevel())
            end
        end

        instigator:FirePort("Disable")
        
        local sleepTime = turretDuration
        while sleepTime > 0 do
            sleepTime = sleepTime - DeltaTime()
            
            local gameStage = gGameRules:GetGameStage()
            if gameStage == Lotus_Game.LotusPveDeathmatchGameRules_GS_ROUND_SETUP then
                break
            end
            
            Sleep(0)
        end

        for i = 1, #turretSpawnPoints do
            local activeAvatar = turretSpawnPoints[i]:GetActiveAvatar()
            if not IsNull(activeAvatar) then
                activeAvatar:DecrementActivationRequests()
            end
        end
        
        instigator:FirePort("Enable")
    end
end