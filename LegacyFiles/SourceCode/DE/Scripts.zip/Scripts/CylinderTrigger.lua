function CylinderTrigger(trigger, avatar)
    return not IsNull(avatar) and trigger:Distance2DToEntity(avatar) <= trigger:GetRadius()
end
