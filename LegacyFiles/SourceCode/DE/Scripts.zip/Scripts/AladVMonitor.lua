resetTimer = 3
delay = 1
petAvatarType = WeakResource()
petStunnedAnim = Resource()

aladCollarFx = Type()
aladCollarFxAttachBone = Symbol()
petCollarFx = Type()
petCollarFxAttachBone = Symbol()
aladCollarOffColor = Color()
aladCollarOnColor = Color()
collarType = WeakResource()

minHealthRank = 1
maxHealthRank = 50
maxCoopHealthRank = 100
minHealthDmgMod = 1
maxHealthDmgMod = 0.1
maxCoopHealthDmgMod = 1

minShieldRank = 1
maxShieldRank = 50
maxCoopShieldRank = 100
minShieldDmgMod = 1
maxShieldDmgMod = 0.1
maxCoopShieldDmgMod = 1

maxDistancePetAwayFromAlad = 100
aladDownedTimeout = 20

local SYM_EMISSIVE_TINT_COLOR_LO = Symbol("EmissiveTintColorLo")

local function CalculateDmgMod(bossRank, minRank, maxRank, minMod, maxMod)

    local damageMod
    
    if bossRank > minRank and bossRank <= maxRank then
        damageMod = ((minMod - maxMod)/(maxRank - minRank))

        damageMod = minMod - (damageMod*(bossRank-(minRank+1)))
    elseif bossRank > maxRank then
        damageMod = maxMod
    else
        damageMod = 1
    end
    
    return damageMod

end

local function MasterAladMonitor(entity)
    Sleep(delay)
        
    -- Make Alad immune to all damage until the cinematic is complete or skipped.
    entity:DamageControl():AddDamageModifier(Symbol("AladHealthImmune"), Engine.DT_ANY, Engine.ANY_PART, 0)
    entity:DamageControl():AddShieldDamageModifier(Symbol("AladShieldImmune"), Engine.DT_ANY, Engine.ANY_PART, 0)
    
    local aladCollar = entity:GetAttachment(collarType)
    if not IsNull(aladCollar) then
        aladCollar:SetMaterialParam(SYM_EMISSIVE_TINT_COLOR_LO, aladCollarOffColor.red/255, aladCollarOffColor.green/255, aladCollarOffColor.blue/255, 1)
    end
    
    -- Let's apply fx/collar color change at 4.83 seconds of the cinematic or when skipped
    local t = 0
    local inCine = true
    local collarOn = false
    -- Remain in loop until cinematic is finished so we can keep Alad immune for the duration
    while inCine do
        local cinematic = gRegion:GetPlayingCinematic()
        inCine = not IsNull(cinematic)
        t = t + DeltaTime()
        if t > (4.83 - delay) and not IsNull(aladCollar) and not collarOn then
            aladCollar:SetMaterialParam(SYM_EMISSIVE_TINT_COLOR_LO, aladCollarOnColor.red/255, aladCollarOnColor.green/255, aladCollarOnColor.blue/255, 1)
            collarOn = true
        end
        Sleep(0.0)
    end
    
    -- Remove Alad's immunities when the intro cinematic is over
    entity:DamageControl():RemoveDamageModifier(Symbol("AladHealthImmune"))
    entity:DamageControl():RemoveShieldDamageModifier(Symbol("AladShieldImmune"))
    
    -- Apply the real damage modifiers for the fight after we have cleared the immunities given for the cinematic
    local players = gRegion:GetHumanPlayerAvatars()
    local healthDmgMod, shieldDmgMod
    if #players > 2 then
        healthDmgMod = CalculateDmgMod(_T.weaponConclave, minHealthRank, maxCoopHealthRank, minHealthDmgMod, maxCoopHealthDmgMod)
        shieldDmgMod = CalculateDmgMod(_T.weaponConclave, minShieldRank, maxCoopShieldRank, minShieldDmgMod, maxCoopShieldDmgMod)
    else
        healthDmgMod = CalculateDmgMod(_T.weaponConclave, minHealthRank, maxHealthRank, minHealthDmgMod, maxHealthDmgMod)
        shieldDmgMod = CalculateDmgMod(_T.weaponConclave, minShieldRank, maxShieldRank, minShieldDmgMod, maxShieldDmgMod)
    end

    entity:DamageControl():AddDamageModifier(Symbol("BossHealthDmgMod"), Engine.DT_ANY, Engine.ANY_PART, healthDmgMod)
    entity:DamageControl():AddShieldDamageModifier(Symbol("BossShieldDmgMod"), Engine.DT_ANY, Engine.ANY_PART, shieldDmgMod)
    
    _T.AladUnderAttack = false

    _T.AladPhaseOne = true
    
    local petAvatar = gRegion:FindNearest(petAvatarType, entity:GetPosition(), 60)
    local petOrigMaxShield = -1
    
    local currentHealth = entity:GetHealth()
    local prevHealth = currentHealth
    local maxHealth = entity:GetMaxHealth()
    
    local damagecontroller = entity:DamageControl()
    local currentShield = damagecontroller:GetShield()
    local origMaxShield = damagecontroller:GetMaxShield()
    local prevShield = currentShield

    local timer = 0
    local shieldsDownHandled = false
    local aladDownHandled = false
    local petDeadTime = 0

    local fxCreated = false
    local aladFx
    local petFx

    local deathTimout = aladDownedTimeout

    while true do
        if IsNull(petAvatar) then
            petAvatar = gRegion:FindNearest(petAvatarType, entity:GetPosition(), 60)
        elseif petAvatar:DistanceToEntity(entity) > maxDistancePetAwayFromAlad then
            petAvatar:Teleport(entity:GetPosition(), entity:GetRotation())
        end
        
        if not fxCreated and not IsNull(petAvatar) and not IsNull(entity) then
            if not IsNull(aladCollar) then
                aladCollar:SetMaterialParam(SYM_EMISSIVE_TINT_COLOR_LO, aladCollarOnColor.red/255, aladCollarOnColor.green/255, aladCollarOnColor.blue/255, 1)
            end
            aladFx = entity:Attach(aladCollarFx, aladCollarFxAttachBone)
            petFx = petAvatar:Attach(petCollarFx, petCollarFxAttachBone)
            
            fxCreated = true
        end
        if not IsNull(petAvatar) and petOrigMaxShield == -1 then
            petOrigMaxShield = petAvatar:DamageControl():GetMaxShield()
        end
        currentHealth = entity:GetHealth()
        currentShield = entity:DamageControl():GetShield()
        
        if currentHealth < maxHealth then
            _T.AladPhaseOne = false
        else
            _T.AladPhaseOne = true
        end
       
        if currentHealth < prevHealth or
        currentShield < prevShield then
            _T.AladUnderAttack = true
        end

        if not IsNull(entity) and not entity:IsKilled() then
            if damagecontroller:GetShield() <= 5 then
                if not shieldsDownHandled then
                    shieldsDownHandled = true
                    damagecontroller:SetMaxShield(0)
                    entity:SetAnimAction(Symbol("DeactivateCollar"))
                    local agent = entity:GetAgent()
                    if not IsNull(agent) then
                        agent:PlayPhrase(12)
                    end
                    if not IsNull(aladFx) then
                        aladFx:Destroy()
                        aladFx = nil
                        if not IsNull(aladCollar) then
                            aladCollar:SetMaterialParam(SYM_EMISSIVE_TINT_COLOR_LO, aladCollarOffColor.red/255, aladCollarOffColor.green/255, aladCollarOffColor.blue/255, 1)
                        end
                    end
                    if not IsNull(petFx) then
                        petFx:Destroy()
                        petFx = nil
                    end
                    
                        
                    if not IsNull(petAvatar) then
                        petAvatar:PlayAnimation(petStunnedAnim, false, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_ONCE, true)
                        petAvatar:InventoryControl():AddUpgrade(Game.GAMEPLAY_POWER_COOLDOWN, Game.MULTIPLY, 0.5)
                        petAvatar:DamageControl():SetShield(0)
                        petAvatar:DamageControl():SetMaxShield(0)
                    end
                end
                local agent = entity:GetAgent()
                if not IsNull(agent) then
                    agent:PlayPhrase(23)
                    if not shieldsDownHandled then
                        local agent = entity:GetAgent()
                        if not IsNull(agent) then
                            agent:PlayPhrase(23)
                        end 
                    end
                end
            end

            if damagecontroller:IsPreDeath() then
                deathTimout = deathTimout - DeltaTime()
                if IsNull(petAvatar) or petAvatar:IsKilled() or deathTimout < 0 then
                    --we've killed alad and his pet doesn't exist, so we're done
                    damagecontroller:KillAfterPreDeath()
                    return
                elseif petAvatar:IsPreDeath() then
                    --we've killed alad and his pet is dead, so we're done
                    damagecontroller:KillAfterPreDeath()
                    petAvatar:DamageControl():KillAfterPreDeath()
                    return 
                elseif not aladDownHandled then
                    aladDownHandled = true
                    if not IsNull(petAvatar) then
                        local petAgent = petAvatar:GetAgent()
                        if not IsNull(petAgent) then
                            petAgent:AddOrder(Symbol("Revive"), entity, 2.0)
                        end
                    end
                end
                local agent = entity:GetAgent()
                if not IsNull(agent) then
                    agent:PlayPhrase(22)
                end    
                
            elseif aladDownHandled then
                deathTimout = aladDownedTimeout
                aladDownHandled = false
                shieldsDownHandled = false
                damagecontroller:SetMaxShield(origMaxShield)
                entity:SetAnimAction(Symbol("ActivateCollar"))
                damagecontroller:SetShield(origMaxShield * 0.5)
                
                fxCreated = false
                if not IsNull(aladFx) then
                    aladFx:Destroy()
                    aladFx = nil
                    if not IsNull(aladCollar) then
                        aladCollar:SetMaterialParam(SYM_EMISSIVE_TINT_COLOR_LO, aladCollarOffColor.red/255, aladCollarOffColor.green/255, aladCollarOffColor.blue/255, 1)
                    end
                end
                if not IsNull(petFx) then
                    petFx:Destroy()
                    petFx = nil
                end
                
                if not IsNull(petAvatar) then
                    petAvatar:DamageControl():SetMaxShield(petOrigMaxShield)
                    petAvatar:InventoryControl():RemoveUpgrade(Game.GAMEPLAY_POWER_COOLDOWN, Game.MULTIPLY, 0.5)
                    petAvatar:DamageControl():SetShield(50)
                    
                    local petAgent = petAvatar:GetAgent()
                    if not IsNull(petAgent) then
                        petAgent:ClearOrder(Symbol("Revive"))
                    end
                end
            else
                --check if pet has been disabled for too long and revive him
                if not IsNull(petAvatar) and petAvatar:IsPreDeath() then
                    petDeadTime = petDeadTime + DeltaTime()
                    if petDeadTime > 10 then
                        petAvatar:SetHealth(petAvatar:GetMaxHealth() * 0.5)
                    end
                else
                    petDeadTime = 0
                end
            end
        end
        
        if timer >= resetTimer then
            _T.AladUnderAttack = false
            prevHealth = currentHealth
            prevShield = currentShield
            timer = 0
        end
        
        timer = timer + DeltaTime()
        Sleep(0)

    end
end

local function ReplicaAladMonitor(entity)
    Sleep(delay)

    local petAvatar = gRegion:FindNearest(petAvatarType, entity:GetPosition(), 60)
    local damagecontroller = entity:DamageControl()

    local shieldsDownHandled = false
    local aladDownHandled = false
    
    local fxCreated = false
    local aladFx
    local petFx

    while true do
        if IsNull(petAvatar) then
            petAvatar = gRegion:FindNearest(petAvatarType, entity:GetPosition(), 60)
        end
        if not fxCreated and not IsNull(petAvatar) and not IsNull(entity) then
            
            aladFx = entity:Attach(aladCollarFx, aladCollarFxAttachBone)
            petFx = petAvatar:Attach(petCollarFx, petCollarFxAttachBone)
            
            fxCreated = true
        end
        
        if not IsNull(entity) and not entity:IsKilled() then
            if damagecontroller:GetShield() <= 5 then
                if not shieldsDownHandled then
                    shieldsDownHandled = true
                    if not IsNull(aladFx) then
                        aladFx:Destroy()
                        aladFx = nil
                    end
                    if not IsNull(petFx) then
                        petFx:Destroy()
                        petFx = nil
                    end
                end
            end
            if damagecontroller:IsPreDeath() then
                if IsNull(petAvatar) then
                    --we've killed alad and his pet doesn't exist, so we're done
                    return
                elseif petAvatar:IsPreDeath() then
                    --we've killed alad and his pet is dead, so we're done
                    return 
                elseif not aladDownHandled then
                    aladDownHandled = true
                end
            elseif aladDownHandled then
                aladDownHandled = false
                shieldsDownHandled = false
                
                fxCreated = false
                if not IsNull(aladFx) then
                    aladFx:Destroy()
                    aladFx = nil
                end
                if not IsNull(petFx) then
                    petFx:Destroy()
                    petFx = nil
                end
            end
        end
        Sleep(0)
    end
end

function AladMonitor(entity)
    if gRegion:IsMaster() then
        MasterAladMonitor(entity)
    else
        ReplicaAladMonitor(entity)
    end
end
