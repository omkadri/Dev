moverDoor = Instance()

local crusherInterval = 0.75

function Start()

    while true do
        moverDoor:FirePort("Start")
        Sleep(crusherInterval)
        moverDoor:FirePort("Close")
        Sleep(crusherInterval)
    end

end

function CrusherDoor(mover)

    while true do
        mover:FirePort("Start")
        Sleep(crusherInterval)
        mover:FirePort("Close")
        Sleep(crusherInterval)
    end
    

end