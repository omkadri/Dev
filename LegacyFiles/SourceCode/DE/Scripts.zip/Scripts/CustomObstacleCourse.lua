boundsFxType = WeakResource("/Lotus/Fx/Levels/ClanDojo/DojoOutOfBoundsDeco")
textureScale = 4

local mvScales = Symbol("vScales")
local muvScales = Symbol("uvScales")

local function _UpdateBoundsTrigger(placeable)
    if not IsNull(placeable) then
        --Sleep(0) -- wait for attachments to be created
        local boundsFx = placeable:GetAttachment(boundsFxType)
        local proxy = placeable:GetAttachment(gHitProxyType)
        if not IsNull(proxy) and not IsNull(boundsFx) then
            local dimensions = proxy:GetDimensions()
            local largestDim = math.max(dimensions.x, dimensions.y, dimensions.z)
            local dimRatio = dimensions.z/dimensions.x
            boundsFx:SetMaterialParam(mvScales, dimensions.x / largestDim, dimensions.y / largestDim, dimensions.z / largestDim)
            boundsFx:SetMaterialParam(muvScales, dimensions.x/textureScale, dimensions.x/textureScale * dimRatio, dimensions.x/textureScale * 2, dimensions.x/textureScale * dimRatio * 2)
        end
    end
end

function UpdateBoundsTrigger(placeable)
    _UpdateBoundsTrigger(placeable)
end

function InitializeBoundsTrigger(placeable)
    Sleep(0)
    _UpdateBoundsTrigger(placeable)
end