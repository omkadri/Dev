
levelUpSoundType = Resource()
levelUpVFXType = Type()


local function SpawnFX(avatar, capeDeco)
    if not IsNull(gRegion) then
        local gameRules = gGameRules
        if (not avatar:IsKilled()) and (not avatar:IsPreDeath() and not avatar:DamageControl():IsInvulnerable()) then
            if (not IsNull(gameRules)) and gameRules:IsA(gLotusBasePvpGameRulesType) and gameRules:IsPvpEnabled() and (gameRules:GetPvpState() == Lotus_Game.PVP_ROUND_STARTED or gameRules:GetPvpState() == Lotus_Game.PVP_ROUND_ENDED) then
                if not IsNull(levelUpVFXType) then
                    gRegion:CreateEntity(levelUpVFXType, capeDeco:GetPosition(), ZERO_ROTATION, capeDeco, capeDeco)
                end

                if avatar:ReplicaLocallyControlled() and not IsNull(levelUpSoundType) then
                    avatar:PlaySound(levelUpSoundType, false, Engine.SP_NO_SUBTITLE, false)
                end

                return true
            end
        end
    end

    return false
end

function InitCapeEffects(capeDeco)
    local childrenActive = 0
    local childrenCount = 0
    local notNullChildren = 0
    local children = capeDeco:GetAutoSimChildrenArray()

    -- count how many children we have
    for i = 1, #children do
        childrenCount = childrenCount + 1
    end

    -- now we need to wait until our children instances are alive, doing it by scale because invis abilities set visibility!
    while notNullChildren < childrenCount do
        for i = 1, #children do
            if not IsNull(children[i].mInstance) then
                children[i].mInstance:SetDissolve(1.0)
                notNullChildren = notNullChildren + 1
            end
        end

        Sleep(0)

        -- if not ready yet, try again
        if notNullChildren < childrenCount then
            children = capeDeco:GetAutoSimChildrenArray()
        end
    end

    local avatar = capeDeco:GetAttachRoot()
    local human = nil
    -- If we're in backgroundRegion and maximumSyndicateScarfIntensity is set, assume we're the syandana
    -- being previewed in DetailedPurchaseDialog, so max out fx.
    local maxSyandana = (capeDeco:GetRegionMgr() == gBackgroundRegion) and _T.maximumSyndicateScarfIntensity

    while childrenActive < childrenCount do
        local numCompleted = -1
        local alreadySpawnedEffects = false
        if maxSyandana then
            numCompleted = 4
        else
            if IsNull(human) then
                if not IsNull(avatar) and avatar:IsA(gLotusAvatarType) then
                    local player = avatar:GetPlayer()
                    if not IsNull(player) and player:IsA(gLotusHumanPlayerType) then
                        human = player
                        numCompleted = human:GetNumDailyPVPChallengesCompleted()
                    end
                end
            else
                numCompleted = human:GetNumDailyPVPChallengesCompleted()
            end
        end

        if numCompleted >= 0 then
            if numCompleted >= 1 and childrenActive < 1 and childrenCount > 0 then
                children[1].mInstance:SetDissolve(0.0)
                childrenActive = childrenActive + 1
                alreadySpawnedEffects = SpawnFX(avatar, capeDeco)
                if alreadySpawnedEffects then
                    Sleep(1)
                end
            end
            
            if numCompleted >= 2 and childrenActive < 2 and childrenCount > 1 then
                children[2].mInstance:SetDissolve(0.0)
                childrenActive = childrenActive + 1
                alreadySpawnedEffects = SpawnFX(avatar, capeDeco)
                if alreadySpawnedEffects then
                    Sleep(1)
                end
            end
            
            if numCompleted >= 3 and childrenActive < 3 and childrenCount > 2 then
                children[3].mInstance:SetDissolve(0.0)
                childrenActive = childrenActive + 1
                alreadySpawnedEffects = SpawnFX(avatar, capeDeco)
                if alreadySpawnedEffects then
                    Sleep(1)
                end
            end
            
            if numCompleted >= 4 and childrenActive < 4 and childrenCount > 3 then
                children[4].mInstance:SetDissolve(0.0)
                childrenActive = childrenActive + 1
                alreadySpawnedEffects = SpawnFX(avatar, capeDeco)
                if alreadySpawnedEffects then
                    Sleep(1)
                end
            end

            if not IsNull(gRegion) and not IsNull(gGameRules) and not gGameRules:IsPvpEnabled() then
                childrenActive = childrenCount -- force out because we can't really unlock another challenge in non pvp modes
            end
        end
        
        if not alreadySpawnedEffects then
            Sleep(1)
        end
    end
end
