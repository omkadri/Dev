itemTypes = { Type() }
numControlPanels = 1
transmission = Type()

local function FilterBasedOnZone(ControlPanel)
    local filtered = {}
    local players = gRegion:GetHumanPlayers()
    local avatar = nil
    for x = 1, #players do
        avatar = players[x]:GetAvatar()
        if not IsNull(avatar) then
            break
        end
    end
    
    if IsNull(avatar) then
        return filtered
    end
    
    for i=1,#ControlPanel do
        local cp = ControlPanel[i]
        local cpZone = ControlPanel[i]:GetZone()
        local avZone = avatar:GetZone()
        if cpZone == avZone then
            table.insert(filtered, ControlPanel[i])
        end
    end

    return filtered
end

local function CreateControlPanel()

    local ControlPanel = gRegion:FindTagged(Symbol("ControlPanelSpawn"))
    ControlPanel = FilterBasedOnZone(ControlPanel)

    local itemType = itemTypes[1]
    
    local numControlPanelsMade = 0
    while numControlPanelsMade < numControlPanels do
    
        if ControlPanel == nil or #ControlPanel == 0 then
            return
        end
        
        local spidx = RandomInt(1, #ControlPanel)
        local ControlPanelPoint = ControlPanel[spidx]
        ControlPanelPoint:FirePort("Disable")
        table.remove(ControlPanel, spidx)
        local hitPoint = Vector()
        local ignoreEntity = ControlPanelPoint
        local pos = ControlPanelPoint:GetPosition()
        local temprot = ControlPanelPoint:GetRotation() 
        if gRegion:Raycast(pos + Vector(0,1,0), pos - Vector(0,1,0), ignoreEntity, nil, hitPoint) then
            hitPoint = hitPoint + Vector()          
            gRegion:CreateEntity(itemType, hitPoint, temprot)
            numControlPanelsMade = numControlPanelsMade + 1
        end
    end
end

local function GiveObjective1() --Transmission to play when defend stage begins
    
    Sleep(1)
    
    local gameRules = gGameRules
    local players = gRegion:GetHumanPlayers()
    
    if not IsNull(players) then
        for x = 1, #players do
            local avatar = players[x]:GetAvatar()
            avatar:GiveItem(transmission, true)
        end
    end
end

function LockdownSpawnControlPanel()
 
CreateControlPanel()
GiveObjective1()

local DoorTriggerTags = gRegion:FindTagged(Symbol("DoorTrigger"))
    if not IsNull(DoorTriggerTags) then
        for x=1,#DoorTriggerTags do
            DoorTriggerTags[x]:FirePort("Disable")
        end
end

local DoorTags = gRegion:FindTagged(Symbol("Door"))
    if not IsNull(DoorTags) then
        for x=1,#DoorTags do
            DoorTags[x]:FirePort("Close")
            DoorTags[x]:FirePort("MaterialSwitch")
        end
end

local DoorHintTags = gRegion:FindTagged(Symbol("DoorHint"))
    if not IsNull(DoorHintTags) then
        for x=1,#DoorHintTags do
            DoorHintTags[x]:FirePort("OnLocked")
        end
end
    
local DoorFrameTags = gRegion:FindTagged(Symbol("DoorFrameTag"))
    if not IsNull(DoorFrameTags) then
        for x=1,#DoorFrameTags do
            DoorFrameTags[x]:FirePort("MaterialSwitch")
        end
    end
end
