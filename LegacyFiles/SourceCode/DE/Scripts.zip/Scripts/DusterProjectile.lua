dusterProj = Resource()
wayPoint1 = Instance()
wayPoint2 = Instance()

function DusterArmProjectiles()

gRegion:CreateEntity(dusterProj, wayPoint1:GetPosition(), wayPoint1:GetRotation())
gRegion:CreateEntity(dusterProj, wayPoint2:GetPosition(), wayPoint2:GetRotation())
wayPoint1:Destroy()
wayPoint2:Destroy()

end