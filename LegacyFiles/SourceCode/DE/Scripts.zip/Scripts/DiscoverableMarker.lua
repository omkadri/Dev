tag = Symbol()
id = 0

function AddDiscoveredMarker(avatar)
    if not IsNull(avatar) and avatar:IsA(gBaseAvatarType) then
        local player = avatar:GetPlayer()
        if not IsNull(player) and player:IsLocal() then
            local gameData = gPlayerProfileMgr:GetPlayerProfile(0):GetGameSpecificData()
            if not IsNull(gameData) then
                gameData:AddDiscoveredMarker(tostring(tag), id)
                local taggedMarkers = gRegion:FindTagged(tag)
                for i = 1, #taggedMarkers do
                    if not IsNull(taggedMarkers[i]) and taggedMarkers[i]:GetDiscoverableId() == id then
                        taggedMarkers[i]:Enable()
                        return
                    end
                end
            end
        end
    end
end