function MatchAttackEvent(scriptDamageData, player)
    local sourceObject = scriptDamageData:GetSourceObject()
    if not IsNull(sourceObject) and ((sourceObject:IsA(gPowerSuitType) or (sourceObject:IsA(gLotusWeaponType) and sourceObject:IsAbilityWeapon()))) then
        return true
    end
    
    local source = scriptDamageData:GetSource()
    local playerAv = player:GetAvatar()
    if not IsNull(source) and source:IsA(gLotusNpcAvatarType) and not IsNull(playerAv) then
        if source:IsMindControlled() and source:GetMindControllerAvatar() == playerAv then
            return true
        else
            local ability = source:GetSpawnedByAbility()
            if not IsNull(ability) and ability:GetSuit():GetAvatarOwner() == playerAv then
                return true
            end
        end
    end
    
    return false
end
