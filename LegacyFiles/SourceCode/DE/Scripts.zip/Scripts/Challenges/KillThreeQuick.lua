-- Only considers kills done with a weapon from a specified slot

local mSlot1KillTime = 0
local mSlot2KillTime = 0
local mSlot6KillTime = 0

function MatchAttackEvent(scriptDamageData, player)
    if (IsNull(player:GetAvatar()) or (scriptDamageData:GetSource() ~= player:GetAvatar())) then
        return false
    end
    local sourceObject = scriptDamageData:GetSourceObject()
    local curTime = Time()
    if not IsNull(sourceObject) then
        if sourceObject:IsA(gProjectileType) then
            sourceObject = sourceObject:GetInstigatorItem()
        end
        if not IsNull(sourceObject) then
            if sourceObject:IsA(gLotusWeaponType) then            
                local currentSlot = sourceObject:GetCurrentInventorySlot()
                if currentSlot == Engine.SLOT_1 then
                    mSlot1KillTime = curTime
                end
                if currentSlot == Engine.SLOT_2 then
                    mSlot2KillTime = curTime
                end
                if currentSlot == Engine.SLOT_6 then
                    mSlot6KillTime = curTime
                end
            end
        end
    end
    if (curTime - mSlot1KillTime < 5)  and (curTime - mSlot2KillTime < 5) and (curTime - mSlot6KillTime < 5) then
        return true
    end
    return false
end
