tagPrefix = Symbol()


function MatchTagEvent(player, tag)
    return tagPrefix:IsValid() and string.find(tostring(tag), tostring(tagPrefix), 1, true) == 1
end
