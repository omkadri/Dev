rarity = Lotus_Game.RARE


function MatchTagEvent(player, tag, howMany, source, itemType)
    if not IsNull(itemType) then
        -- dirty hack to check if there's an associated StoreItem for this item. It's vastly preferable to fetch rarity from StoreItem interface
        -- to avoid spotloading full chain of dependencies (e.g. stance mods cause massive hitches)
        local storeItemName = string.gsub(tostring(itemType:GetFullName()), "/Lotus/", "/Lotus/StoreItems/", 1)
        local storeItem = Resource(storeItemName)
        if not IsNull(storeItem) then
            return storeItem:GetRarity() >= rarity
        end
    end
        
    return not IsNull(itemType) and Resource(itemType):GetRarity() >= rarity
end
