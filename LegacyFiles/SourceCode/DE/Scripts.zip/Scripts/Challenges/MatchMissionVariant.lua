matchVanilla = true
matchAlert = false
matchEvent = false
matchInvasion = false
matchNightmare = true
matchSortie = true
matchSyndicate = false

function MatchTagEvent()
    local mission = gGameRules:GetMission()
    if mission.alertId ~= "" then
        return matchAlert
    elseif mission.goalId ~= "" then
        return matchEvent
    elseif mission.invasionId ~= "" then
        return matchInvasion
    elseif mission.nightmare then
        return matchNightmare
    elseif mission.sortieId ~= "" then
        return matchSortie
    elseif mission.syndicateId ~= "" then
        return matchSyndicate
    end
    
    return matchVanilla
end