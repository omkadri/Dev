-- Uber: [If unlocked] Use your (uber Warframe ability name) once. 

uberAbilityIndex = 3    -- "C++" format (ie. 0-based)

function CheckPreconditions(player)

    if IsNull(player) then
        return true
    end

    local avatar = player:GetAvatar()
    if IsNull(avatar) then
        return false
    end

    local ic = avatar:InventoryControl()
    if IsNull(ic) or not ic:IsA(gLotusInventoryControllerType) then
        return false
    end

    local powerSuit = ic:GetActivePowerSuit()
    if IsNull(powerSuit) then
        return false
    end

    if powerSuit:IsAbilityUnlocked(uberAbilityIndex) then
        return true
    end

    return false
end
