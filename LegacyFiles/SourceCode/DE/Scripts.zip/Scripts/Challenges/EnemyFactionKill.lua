faction = Symbol()

function MatchAttackEvent(scriptDamageData, player)
    local victim = scriptDamageData:GetVictim()
    if IsNull(victim) then 
        return false 
    end

    if faction == victim:GetFaction() then
        return true
    end
    
    return false
    
end
