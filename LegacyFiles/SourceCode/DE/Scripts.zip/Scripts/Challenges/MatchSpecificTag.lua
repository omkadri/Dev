
local matchedTag = "COMBO_TIER_REACHED"

function MatchTagEvent(player, tag)
    if tag == matchedTag then
        return true
    end

    return false
end
