excludePublicMatchmaking = true

function CheckPreconditions()    
    local missionInfo = gGameRules:GetMission()
    if missionInfo.archwingRequired then
        return false
    end
    
    local faction = missionInfo.faction
    if faction == Lotus_Game.FC_INFESTATION then
        return false
    end
    
    local missionType = missionInfo.missionType
    -- not allowed for missions that are on permanent alert or otherwise too hard to find enemies to stealth kill
    if  missionType == Lotus_Game.MT_DEFENSE or
        missionType == Lotus_Game.MT_SURVIVAL or
        missionType == Lotus_Game.MT_TERRITORY or 
        missionType == Lotus_Game.MT_EXCAVATE or
        missionType == Lotus_Game.MT_EVACUATION or
        missionType == Lotus_Game.MT_RAID
    then
        return false
    end
    
    -- stealth challenge sucks in public multiplayer because randos probably won't play along
    if excludePublicMatchmaking then
        local session = gMatchingService:GetSession()
        if not IsNull(session) then
            local settings = session:GetSettings()
            local regionId = settings.regionId
            if not (regionId == Engine.LOCKED or regionId == Engine.PRIVATE or regionId == Engine.INVITE_ONLY) then
                return false
            end
        end
    end
    
    return true
end