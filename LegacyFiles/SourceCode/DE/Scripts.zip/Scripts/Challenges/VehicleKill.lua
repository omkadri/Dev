vehicleTypes = { WeakResource() }

function MatchAttackEvent(scriptDamageData, player)
    local victim = scriptDamageData:GetVictim()
    for i,v in ipairs(vehicleTypes) do
        if victim:IsA(v) then
            return(victim:HasHostilePilot())
        end
    end
    
    return true
end
