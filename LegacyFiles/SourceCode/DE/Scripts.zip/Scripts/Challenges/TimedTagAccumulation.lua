requiredTags = { Symbol() }
timeLimit = 0
uniqueChallengeId = String()
attackEvent = false

local function GetRecordName(player, id)
    local playerName = tostring(player:GetPlayerName())
    return(tostring(uniqueChallengeId) .. id ..  tostring(player:GetPlayerName()))
end

local function ResetProgress(recordName)
    for k,v in pairs(_T[recordName]) do
        _T[recordName][k] = false
    end
end

local function CheckTimeLimit(recordName)
    local uniqueChallengeTime = tostring(recordName) .. "Time"
    if _T[uniqueChallengeTime] == nil then
        -- Initialize
        local tagMap = {}
        for i = 1, #requiredTags do
            tagMap[tostring(requiredTags[i])] = false
        end
        _T[recordName] = tagMap
        _T[uniqueChallengeTime] = Time()
        if attackEvent then
            _T[recordName]["TTAAttackEvent"] = false
        end
    elseif timeLimit <= 0 then
        return
    elseif (Time() - _T[uniqueChallengeTime]) >= timeLimit then
        print("TimedTagChallenge: " .. recordName .. " - Progress reset")
        _T[uniqueChallengeTime] = Time()
        ResetProgress(recordName)
    end
end

local function CheckCompletion(recordName)
    for k,v in pairs(_T[recordName]) do
        if v == false then
            print("TimedTagChallenge: " .. recordName .. " - " .. k .. " is incomplete, challenge not done yet")
            return false
        end
    end
    
    _T[recordName .. "Time"] = 0
    ResetProgress(recordName)
    
    print("TimedTagChallenge: " .. recordName .. " - Challenge success")
    
    return true
end

function MatchTagEvent(player, tag, amount, source, itemType, id)
    local recordName = GetRecordName(player, id)
    if _T[recordName] ~= nil and _T[recordName][tag] == nil then
        return
    end
    CheckTimeLimit(recordName)
    
    if _T[recordName][tag] == false then
        _T[recordName][tag] = true
        print("TimedTagChallenge: " .. recordName .. " - " .. tag .. " triggered!")
        return CheckCompletion(recordName)
    end
    return false
end

function MatchAttackEvent(scriptDamageData, player, isEstimate, id)
    if attackEvent then
        local recordName = GetRecordName(player, id)
        CheckTimeLimit(recordName)
        _T[recordName]["TTAAttackEvent"] = true
        print("TimedTagChallenge: " .. recordName .. " - TTAAttackEvent triggered!")
        return CheckCompletion(recordName)
    end
    return false
end