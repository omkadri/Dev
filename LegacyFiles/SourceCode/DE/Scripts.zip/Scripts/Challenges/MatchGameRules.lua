gameRules = WeakResource()


local function CheckGameRules()
    return not IsNull(gGameRules) and gGameRules:IsA(gameRules)
end

function MatchTagEvent(player, tag)
    return CheckGameRules()
end

function MatchAttackEvent(scriptDamageData, player)
    return CheckGameRules()
end

function MatchItemEvent(player, item)
    return CheckGameRules()
end
