-- This is a bit silly but, the point of this is to prevent the challenge from making progress when we pick
-- up the item (which does a NotifyItem and does not consider the quantity picked up), but instead make
-- progress at the end of the mission when we commit our collected items to the DB (where we do a NotifyTagMultiple)


function MatchItemEvent(player, itemName)
    return false
end

function MatchTagEvent(player, tag, num, source)
    return true
end