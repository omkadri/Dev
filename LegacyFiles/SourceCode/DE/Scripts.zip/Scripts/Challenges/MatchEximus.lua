function MatchAttackEvent(scriptDamageData, player)
    local victim = scriptDamageData:GetVictim()
    -- intentionally constructing the faction symbol inline to take advantage of short-circuiting
    return not IsNull(victim) and victim:IsEnhanced() and not (victim:GetOriginalFaction() == Symbol("NIGHTMARE_BERSERKER"))
end
