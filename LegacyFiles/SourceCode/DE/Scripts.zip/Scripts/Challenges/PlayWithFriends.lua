requiredTagPrefix = Symbol()
ignoreFriends = false

local function IsPlayingWithFriends()
    local clanName = gRegion:GetLocalPlayer():GetClanName()
    local players = gRegion:GetHumanPlayers()
    for _,player in ipairs(players) do
        if not player:IsLocal() then
            if gGameData:IsFriendAccountId(player:GetPlayerAccountIDString()) then
                return true
            else
                local otherClanName = player:GetClanName()
                if otherClanName == clanName or gGameData:IsGuildInMyAlliance(otherClanName) then
                    return true
                end
            end
        end
    end
    return false
end

function MatchTagEvent(player, tag)
    if not IsNull(gGameData) and (not requiredTagPrefix:IsValid() or string.find(tostring(tag), tostring(requiredTagPrefix), 1, true) == 1) then
        return(ignoreFriends or IsPlayingWithFriends())
    end

    return false
end

function MatchAttackEvent(scriptDamageData, player)
    return IsPlayingWithFriends()
end
