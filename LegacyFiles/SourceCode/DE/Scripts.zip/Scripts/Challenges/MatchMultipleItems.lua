items = {WeakResource()}


function MatchTagEvent(player, tag, howMany, source, item)
    if not IsNull(item) then
        for _,other in ipairs(items) do
            if item == other then
                return true
            end
        end
    end

    return false
end
