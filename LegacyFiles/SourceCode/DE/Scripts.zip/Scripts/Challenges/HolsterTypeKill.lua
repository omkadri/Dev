holsterCategory = Lotus_Game.PISTOL
weaponType = WeakResource()
powerSuitType = WeakResource()

function MatchAttackEvent(scriptDamageData, player)

    local sourceObject = scriptDamageData:GetSourceObject()
    
    if not IsNull(sourceObject) then
        if sourceObject:IsA(gProjectileType) then
            sourceObject = sourceObject:GetInstigatorItem()
        end

        if sourceObject:IsA(weaponType) and not sourceObject:IsA(powerSuitType) and sourceObject:GetHolsterCategory() == holsterCategory then
            return true
        end
    end

    return false

end
