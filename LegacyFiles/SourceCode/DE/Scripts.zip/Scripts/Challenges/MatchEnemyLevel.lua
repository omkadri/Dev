minEnemyLevel = -1


local function CheckEnemyLevel()
    local mission = gGameRules:GetMission()
    if IsNull(mission) then
        return false
    end

    if minEnemyLevel > 0 and mission.minEnemyLevel < minEnemyLevel then
        return false
    end

    return true
end

function MatchTagEvent(player, tag)
    return CheckEnemyLevel()
end

function MatchAttackEvent(scriptDamageData, player)
    return CheckEnemyLevel()
end

function MatchItemEvent(player, item)
    return CheckEnemyLevel()
end
