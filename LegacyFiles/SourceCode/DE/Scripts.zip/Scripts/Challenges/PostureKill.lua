requiredPosture = Engine.WALK
requiredAttackAction = Engine.MELEE_SWING_RIGHT
usePosture = true
useModifiers = false
requiredModifiers = { Engine.PM_PRE_DEATH }

local function IsWallCling(posture)
    return posture == Engine.WALLRUNNING_LEFT or posture == Engine.WALLRUNNING_RIGHT or posture == Engine.WALLRUNNING_UP
end

function CheckPreconditions()
    local missionInfo = gGameRules:GetMission()
    if missionInfo.archwingRequired then
        return false
    end

    return true
end

local function MatchCommonEvent(scriptDamageData, player)
    local avatar = player:GetAvatar()
    
    if useModifiers then
        for i=1, #requiredModifiers do
            if requiredModifiers[i] == Engine.PM_PRE_DEATH then
                if not avatar:IsPreDeath() and not avatar:HasPostureModifier(requiredModifiers[i]) then
                    return false
                end
            else
                if not avatar:HasPostureModifier(requiredModifiers[i]) then
                    return false
                end
            end
        end
        if not usePosture then
            return true
        end
    end
    
    if not usePosture then
        if not IsNull(scriptDamageData) and requiredAttackAction == Engine.MELEE_FINISHER then
            local weapon = scriptDamageData:GetSourceObject()
            if not IsNull(weapon) and weapon:IsA(gLotusWeaponType) and weapon:IsMeleeWeapon() and ((weapon:GetAttackAction() == requiredAttackAction) or avatar:IsDoingFinisher()) then
                return true
            end
        end
        return false
    end
    
    local posture = avatar:GetPosture()
    
    if posture == requiredPosture then
        return true
    elseif not IsNull(scriptDamageData) and requiredPosture == Engine.SLIDE then
        local weapon = scriptDamageData:GetSourceObject()
        
        if not IsNull(weapon) and weapon:IsA(gLotusWeaponType) and weapon:IsMeleeWeapon() and weapon:GetAttackAction() == requiredAttackAction then
            return true
        end
    elseif IsWallCling(requiredPosture) then
        if IsWallCling(posture) then
            return true
        else
            -- Wall jump case, requires modifier check
            for i=1, #requiredModifiers do
                if avatar:HasPostureModifier(requiredModifiers[i]) then
                    return true
                end
            end
        end
    end

    return false
end

function MatchAttackEvent(scriptDamageData, player)
    local victim = scriptDamageData:GetVictim()
    if IsNull(victim) then return false end

    return MatchCommonEvent(scriptDamageData, player)
end


function MatchTagEvent(player, tag)
    return MatchCommonEvent(nil, player)
end

function MatchItemEvent(player, item)
    return MatchCommonEvent(nil, player)
end