local KILLS_FOR_DOMINATION = 2

function MatchAttackEvent(damageData, player)
    local attackerName = player:GetPlayerName()
    local victim = damageData:GetVictim()

    if not IsNull(victim:GetPlayer()) then  -- Should always be the case
        local victimName = victim:GetPlayer():GetPlayerName()

        if _T.gDominationChallengeData == nil then
            _T.gDominationChallengeData = {}
        end

        if _T.gDominationChallengeData[attackerName] == nil then
           _T.gDominationChallengeData[attackerName] = {} 
        end

        if _T.gDominationChallengeData[attackerName][victimName] == nil then
            _T.gDominationChallengeData[attackerName][victimName] = 1
        else
            _T.gDominationChallengeData[attackerName][victimName] = _T.gDominationChallengeData[attackerName][victimName] + 1
        end 
        
        -- Also clear their Domination count against you:
        if _T.gDominationChallengeData[victimName] ~= nil then
            _T.gDominationChallengeData[victimName][attackerName] = 0
        end

        -- Now check for enough kills:
        if _T.gDominationChallengeData[attackerName][victimName] >= KILLS_FOR_DOMINATION then
            --design change: no longer reset
            ---- We did it! Reset count and return true
            ----_T.gDominationChallengeData[attackerName][victimName] = 0

            return(true)
        end
    end

    return(false)
end
