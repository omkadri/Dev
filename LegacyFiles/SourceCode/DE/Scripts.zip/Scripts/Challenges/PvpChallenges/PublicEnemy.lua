local MIN_TEAM_SIZE = 4 -- Require full team

function MatchTagEvent(player, tag, num)
    -- This is just used to reset internal state data on player death, it is never a match

    local attackerName = player:GetPlayerName()
    if _T.gPublicEnemyChallengeData ~= nil and _T.gPublicEnemyChallengeData[attackerName] ~= nil then
        _T.gPublicEnemyChallengeData[attackerName] = nil
    end

    return(false)
end

function MatchAttackEvent(damageData, player)
    local attackerName = player:GetPlayerName()
    local victim = damageData:GetVictim()

    if not IsNull(victim:GetPlayer()) then  -- Should always be the case
        local victimName = victim:GetPlayer():GetPlayerName()
        if _T.gPublicEnemyChallengeData == nil then
            _T.gPublicEnemyChallengeData = {}
        end

        if _T.gPublicEnemyChallengeData[attackerName] == nil then
           _T.gPublicEnemyChallengeData[attackerName] = {} 
        end

        _T.gPublicEnemyChallengeData[attackerName][victimName] = true

        local enemyTeam = 1
        if enemyTeam == player:GetTeam() then
            enemyTeam = 0
        end

        local numKills = 0
        local enemyTeamPlayers = gGameRules:GetTeamPlayers(enemyTeam)
        for i = 1, #enemyTeamPlayers do
            if _T.gPublicEnemyChallengeData[attackerName][enemyTeamPlayers[i]:GetPlayerName()] == nil then
                return(false)   -- Haven't killed this guy yet
            end

            numKills = numKills + 1
        end

        if numKills >= MIN_TEAM_SIZE then
            -- Have enough kills on enemy team! Reset data and return true
            _T.gPublicEnemyChallengeData[attackerName] = nil
            return(true)
        end
    end

    return(false)
end