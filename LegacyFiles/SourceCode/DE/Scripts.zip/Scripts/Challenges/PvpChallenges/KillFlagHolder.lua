local team1FlagType = WeakResource("/Lotus/Types/PickUps/CaptureFlagPvpItem")
local team2FlagType = WeakResource("/Lotus/Types/PickUps/CaptureFlagPvpItemB")

function MatchAttackEvent(damageData, player)
    local victim = damageData:GetVictim()

    if not IsNull(victim:GetPlayer()) then  -- Should always be the case
        if _T.gCaptureFlagKilledHolder ~= nil then
            local team = victim:GetPlayer():GetTeam()
            local flagType = nil
            if team == 0 then
                flagType = team2FlagType
            elseif team == 1 then
                flagType = team1FlagType
            end

            if _T.gCaptureFlagKilledHolder[flagType:GetName()] == victim then
                return(true)
            end
        end
    end

    return(false)   -- We never match through return value, instead we send the tag notification for matching
end