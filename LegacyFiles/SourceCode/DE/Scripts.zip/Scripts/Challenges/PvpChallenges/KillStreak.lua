stopStreakKillsNeeded = 3 -- How many kills victim has on streak to consider the streak stopped
maxStreakKills = 12

local NUMBER_TAGS = {"ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN", "ELEVEN", "TWELVE"}
local CHEVRON_VALUES = {0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 4}

function MatchAttackEvent(damageData, player)
    local attackerName = player:GetPlayerName()
    local victim = damageData:GetVictim()
    if not IsNull(victim:GetPlayer()) then  -- Should always be the case
        local victimName = victim:GetPlayer():GetPlayerName()
        
        if _T.gKillStreakData == nil then
            _T.gKillStreakData = {}
        end

        if _T.gKillStreakData[attackerName] == nil then
            _T.gKillStreakData[attackerName] = 0 
        end

        if _T.gKillStreakData[victimName] == nil then
            _T.gKillStreakData[victimName] = 0 
        end

        _T.gKillStreakData[attackerName] = _T.gKillStreakData[attackerName] + 1

        -- Check for KillStreak "stopped" challenge
        if _T.gKillStreakData[victimName] >= stopStreakKillsNeeded then -- given for whaterver streak kill amount broken but awards the latest passed
            local killStreakTag = Symbol(string.format("STREAK_STOPPED_%s", NUMBER_TAGS[3]))
            if _T.gKillStreakData[victimName] >= 12 then
                killStreakTag = Symbol(string.format("STREAK_STOPPED_%s", NUMBER_TAGS[12]))
            elseif _T.gKillStreakData[victimName] >= 9 then
                killStreakTag = Symbol(string.format("STREAK_STOPPED_%s", NUMBER_TAGS[9]))
            elseif _T.gKillStreakData[victimName] >= 6 then
                killStreakTag = Symbol(string.format("STREAK_STOPPED_%s", NUMBER_TAGS[6]))
            end
            gChallengeMgr:NotifyTag(player, killStreakTag, victim)
        end

        local gameRules = gGameRules
        local killStreakInfo = gameRules:GetKillStreakInfo()

        -- Clear victim's Streak data:
        _T.gKillStreakData[victimName] = 0

        local victimFound = false
        for i = 1, #killStreakInfo do
            if killStreakInfo[i].mName == victimName then
                gameRules:UpdateKillStreakEntry(victimName, 0) -- 0 means no chevron, 1 is 3 kills chevron, 2 is 6 kills chevron, 3 is 9 kills and 4 is 12 or more kills
                victimFound = true
                break
            end
        end

        if not victimFound then
            gameRules:AddToKillStreakData(victimName, 0)
        end

        if _T.gKillStreakData[attackerName] >= stopStreakKillsNeeded and _T.gKillStreakData[attackerName] <= maxStreakKills and
           (_T.gKillStreakData[attackerName] % stopStreakKillsNeeded == 0) then -- only counting multiples of 3
            local killStreakTag = Symbol(string.format("KILL_STREAK_%s", NUMBER_TAGS[_T.gKillStreakData[attackerName]]))
            gChallengeMgr:NotifyTag(player, killStreakTag, victim)

            -- find info about the current attacker or fill a new one
            local killStreakNum = _T.gKillStreakData[attackerName]
            local found = false
            for i = 1, #killStreakInfo do
                if killStreakInfo[i].mName == attackerName then
                    gameRules:UpdateKillStreakEntry(attackerName, CHEVRON_VALUES[killStreakNum])
                    found = true
                    break
                end
            end

            if not found then
                gameRules:AddToKillStreakData(attackerName, CHEVRON_VALUES[killStreakNum])
            end

            local pPlayerA = "</font><font color=\"#" .. string.format("%X", _G.UIColor_PvpTeamTwo) .. "\"><b>" .. player:GetPlayerName() .. "</b></font><font color=\"#FFFFFF\">"
            local numKillsMsg = "</font><font color=\"#" .. string.format("%X", _G.UIColor_PvpTeamOne) .. "\"><b>" .. tostring(killStreakNum).. "</b></font><font color=\"#FFFFFF\">"
            local message = "<p><font color=\"#FFFFFF\">".."$$/Lotus/Language/Game/PlayerOnKillStreak$$" .. "</font></p>"
            if not IsNull(message) then
                local gameRules = gGameRules
                local players = gRegion:GetHumanPlayers()
                for i, p in ipairs(players) do
                    gameRules:SendLogMessageRMI(p, message, pPlayerA, numKillsMsg)
                end
            end
         end

        -- broadcast the data to clients so they can show the chevrons locally
        gameRules:BroadcastKillStreakInfo()
    end

    return(false)
end