
function MatchAttackEvent(damageData, player)

    if damageData:IsDeathInjury() then

        local attackerAvatar = player:GetAvatar()

        if not IsNull(attackerAvatar) then
            if attackerAvatar:IsFalling() then
                return(true)
            end
        end

    end

    return(false)
end

