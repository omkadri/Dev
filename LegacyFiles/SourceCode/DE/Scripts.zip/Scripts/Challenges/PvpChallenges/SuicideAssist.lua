local ASSIST_MAX_TIME = 3
local SUICIDE_ASSIST_SYMBOL = Symbol("SUICIDE_ASSIST")

function MatchTagEvent(player, tag, howMany, source)
    if IsNull(source) then
        return
    end

    local deadPlayerName = player:GetPlayerName()
    local deadPlayerAv = player:GetAvatar()

    if _T.gSuicideAssistData == nil then
        _T.gSuicideAssistData = {}
    end

    if source == deadPlayerAv or (source:IsA(gDamageTriggerType) and source:GetScope():IsValid()) then
        if not IsNull(_T.gSuicideAssistData[deadPlayerName]) then
            local curTime = RealTime()

            local enemyTeam = 0
            if enemyTeam == player:GetTeam() then
                enemyTeam = 1
            end

            local allPlayers = gRegion:GetHumanPlayers()
            for i = 1, #allPlayers do
                if allPlayers[i] ~= player then
                    local enemyAv = allPlayers[i]:GetAvatar()
                    if not IsNull(enemyAv) and not deadPlayerAv:IsAvatarFriendly(enemyAv) then
                        local enemyName = allPlayers[i]:GetPlayerName()
                        if
                            _T.gSuicideAssistData[deadPlayerName][enemyName] ~= nil and
                            (curTime - _T.gSuicideAssistData[deadPlayerName][enemyName]) <= ASSIST_MAX_TIME
                        then
                            gChallengeMgr:NotifyTag(allPlayers[i], SUICIDE_ASSIST_SYMBOL, deadPlayerAv)
                        end
                    end
                end
            end
        end
    end

    _T.gSuicideAssistData[deadPlayerName] = {}
end

function MatchAttackEvent(damageData, player)
    -- This never matches, it just records the attack data
    local attackerName = player:GetPlayerName()
    local victim = damageData:GetVictim()

    if not IsNull(victim:GetPlayer()) then  -- Should always be the case
        -- Check for self-damage
        local victimName = victim:GetPlayer():GetPlayerName()
        
        if _T.gSuicideAssistData == nil then
            _T.gSuicideAssistData = {}
        end

        if _T.gSuicideAssistData[victimName] == nil then
            _T.gSuicideAssistData[victimName] = {} 
        end

        _T.gSuicideAssistData[victimName][attackerName] = RealTime()
    end

    return(false)
end