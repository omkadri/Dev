
function MatchAttackEvent(damageData, player)

    if damageData:IsDeathInjury() then

        local attackerAvatar = player:GetAvatar()
        if not IsNull(attackerAvatar) then
            local posture = attackerAvatar:GetPosture()
            if posture == Engine.SLIDE then
                return(true)
            end
        end

    end

    return(false)
end

