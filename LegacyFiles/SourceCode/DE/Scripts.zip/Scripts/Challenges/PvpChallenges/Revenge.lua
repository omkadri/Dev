local REVENGE_MAX_TIME = 3

function MatchAttackEvent(damageData, player)
    local attackerName = player:GetPlayerName()
    local victim = damageData:GetVictim()

    if not IsNull(victim:GetPlayer()) then  -- Should always be the case
        local victimName = victim:GetPlayer():GetPlayerName()

        if _T.gRevengeChallengeData == nil then
            _T.gRevengeChallengeData = {}
        end

        local curTime = RealTime()

        -- Update last kill time:
        _T.gRevengeChallengeData[attackerName] = curTime

        -- See if victim's last kill time is recent enough
        if _T.gRevengeChallengeData[victimName] ~= nil and (curTime - _T.gRevengeChallengeData[victimName]) <= REVENGE_MAX_TIME then
            return(true)
        end
    end

    return(false)
end