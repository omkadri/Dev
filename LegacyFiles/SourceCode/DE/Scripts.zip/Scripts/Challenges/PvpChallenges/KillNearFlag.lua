checkEnemyFlag = true

local MAX_DISTANCE = 10
local team1FlagPickupType = WeakResource("/Lotus/Types/PickUps/CaptureFlagPvP")
local team2FlagPickupType = WeakResource("/Lotus/Types/PickUps/CaptureFlagPvPB")

local team1flagType = WeakResource("/Lotus/Types/PickUps/CaptureFlagPvpItem")
local team2flagType = WeakResource("/Lotus/Types/PickUps/CaptureFlagPvpItemB")

function MatchAttackEvent(damageData, player)
    local victim = damageData:GetVictim()

    if not IsNull(victim:GetPlayer()) then  -- Should always be the case
        local team = victim:GetPlayer():GetTeam()
        local flagPickupType = nil
        local flagType = nil
        if team == 0 then
            if checkEnemyFlag then
                flagPickupType = team1FlagPickupType
                flagType = team1flagType
            else
                flagPickupType = team2FlagPickupType
                flagType = team2flagType
            end
        elseif team == 1 then
            if checkEnemyFlag then
                flagPickupType = team2FlagPickupType
                flagType = team2flagType
            else
                flagPickupType = team1FlagPickupType
                flagType = team1flagType
            end
        end

        if not IsNull(flagPickupType) then
            local flag = gRegion:FindNearest(flagPickupType, Vector())    -- should only be one
            local flagTypename = flagType:GetName()
            if
                -- Check for distance to pickup
                not IsNull(flag) and
                (_T.gCaptureFlagKilledHolder == nil or _T.gCaptureFlagKilledHolder[flagTypename] ~= victim) and   -- Make sure victim wasn't just holding the flag, otherwise no credit for killing them near it!
                victim:DistanceToEntity(flag) <= MAX_DISTANCE
            then
                return(true)
            elseif
                -- Check for distance to flag holder
                _T.gCaptureFlagHolder ~= nil and
                not IsNull(_T.gCaptureFlagHolder[flagTypename]) and
                _T.gCaptureFlagHolder[flagTypename] ~= victim and
                victim:DistanceToEntity(_T.gCaptureFlagHolder[flagTypename]) <= MAX_DISTANCE
            then
                return(true)
            end
        end
    end

    return(false)   -- We never match through return value, instead we send the tag notification for matching
end