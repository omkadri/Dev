
function MatchAttackEvent(damageData, player)

    if damageData:IsDeathInjury() then
        
        local victim = damageData:GetVictim()
        if not IsNull(victim) then
            if victim:IsFalling() then
                return(true)
            end
        end

    end

    return(false)
end

