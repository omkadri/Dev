function MatchAttackEvent(damageData, player)
    local attackerName = player:GetPlayerName()
    local victim = damageData:GetVictim()

    if not IsNull(victim:GetPlayer()) then  -- Should always be the case
        local victimName = victim:GetPlayer():GetPlayerName()

        if _T.gPaybackChallengeData == nil then
            _T.gPaybackChallengeData = {}
        end

        -- Record who most recently killed victim:
        _T.gPaybackChallengeData[victimName] = attackerName

        -- See if the person I just killed is who most recently killed me:
        if _T.gPaybackChallengeData[attackerName] == victimName then
            _T.gPaybackChallengeData[attackerName] = nil    -- Clear this so we don't get multiple Paybacks without dying multiple times
            return(true)
        end
    end

    return(false)
end