local ASSIST_MAX_TIME = 5
local ASSIST_SYMBOL = Symbol("ASSIST_CHALLENGE")

function MatchAttackEvent(damageData, player)
    local attackerName = player:GetPlayerName()
    local victim = damageData:GetVictim()
    
    if _T.gAssistChallengeData == nil then
        _T.gAssistChallengeData = {}
    end

    if not IsNull(victim:GetPlayer()) then  -- Should always be the case
        local victimName = victim:GetPlayer():GetPlayerName()

        if damageData:IsDeathInjury() then
            -- Check for Assists:
            local curTime = RealTime()
            local teamPlayers = gGameRules:GetTeamPlayers(player:GetTeam())
            for i = 1, #teamPlayers do
                local teamMemberName = teamPlayers[i]:GetPlayerName()
                if teamMemberName ~= attackerName then -- No Assists on yourself
                    if
                        _T.gAssistChallengeData[teamMemberName] ~= nil and
                        _T.gAssistChallengeData[teamMemberName][victimName] ~= nil and
                        (curTime - _T.gAssistChallengeData[teamMemberName][victimName]) <= ASSIST_MAX_TIME
                    then
                        gChallengeMgr:NotifyTag(teamPlayers[i], ASSIST_SYMBOL, victim)
                    end
                end
            end
        else
            -- Record Damage Time
            if _T.gAssistChallengeData == nil then
                _T.gAssistChallengeData = {}
            end

            if _T.gAssistChallengeData[attackerName] == nil then
                _T.gAssistChallengeData[attackerName] = {} 
            end

            _T.gAssistChallengeData[attackerName][victimName] = RealTime()
        end
    end

    return(false)   -- We never match through return value, instead we send the tag notification for matching
end