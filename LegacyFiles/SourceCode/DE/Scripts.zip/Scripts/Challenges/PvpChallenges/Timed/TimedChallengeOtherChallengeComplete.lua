ChallengeInstanceID = String()  --will get set by the challengeManager
MyPlayer = Instance() --will get set by the challengeManager
DifficultyModeFilter = String()

local obj = nil

local TimedChallengeSimpleCounter = require "Lotus.Scripts.Challenges.PvpChallenges.Timed.TimedChallengeSimpleCounter"

function Start()
    obj = TimedChallengeSimpleCounter.OnStart(ChallengeInstanceID,MyPlayer) 
end

local function GetPlayerProfileData()
    local playerProfile = gPlayerProfileMgr:GetPlayerProfile(0)
    local lotusProfileData = nil
    if not IsNull(playerProfile) then
        lotusProfileData = playerProfile:GetGameSpecificData()
    end
    return lotusProfileData
end

local function GetPlayerWorldState()
    local lotusProfileData = GetPlayerProfileData()
    if IsNull(lotusProfileData) then
    end
    local worldState = lotusProfileData:GetWorldState()
    return worldState
end


function OnChallengeCompleted(completedChallengeInstanceID)

    --find the challengeType for the instanceid
    local worldState = GetPlayerWorldState()
    if IsNull(worldState) then
         return
    end    

    local mongoBinID = MongoBinId()
    mongoBinID:Parse(completedChallengeInstanceID)
    
    local challengeInstance = worldState:FindChallengeInstance(mongoBinID)
    if not IsNull(challengeInstance) then
    
        if challengeInstance.mCategory == Lotus_Game.PVPChallengeTypeCategory_DAILY then    
            local challengeType = Resource(challengeInstance.mChallengeTypeRefID) --shouuuuld be loaded already
             
            if DifficultyModeFilter=="" or Lotus_Game.PVPChallengeTypeDifficultyGroup2String(challengeType.mDifficultyGroup) == DifficultyModeFilter then
                TimedChallengeSimpleCounter.AddToScore(obj)
            end
        end
    end
    
end
