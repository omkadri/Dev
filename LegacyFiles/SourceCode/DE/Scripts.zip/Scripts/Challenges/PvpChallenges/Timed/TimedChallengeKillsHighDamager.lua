ChallengeInstanceID = String()  --will get set by the challengeManager
MyPlayer = Instance() --will get set by the challengeManager
ChallengeType = Resource() --will get set by the challengeManager

local TimedChallengeKillsCommon = require "Lotus.Scripts.Challenges.PvpChallenges.Timed.TimedChallengeKillsCommon"
local obj = nil
local damageInfo = {}

local DAMAGE_TIMERANGE = 5
local DAMAGE_REQUIRED = 100

function Start()
    obj = TimedChallengeKillsCommon.OnStart(ChallengeInstanceID,MyPlayer)
    
    obj.CallBackOnKillEx = function(victimPlayer, attackingPlayer, hitType, hitPart)
        local victimName = victimPlayer:GetPlayerName()
        local attackerName = attackingPlayer:GetPlayerName()

        -- had enough damage recently?
        if damageInfo[victimName] then
            for key,info in pairs(damageInfo[victimName]) do
                local sum = 0
                local i = 1
                while i <= #info do
                    if info[i].time < RealTime() - DAMAGE_TIMERANGE then
                        break
                    end

                    sum = sum + info[i].amount
                    i = i + 1                   
                end
            
                if sum > DAMAGE_REQUIRED then
                    TimedChallengeKillsCommon.AddToScore(obj)
                    break
                end
            end
            
            --clear on death
            damageInfo[victimName] = {}
        end
    end
    
    obj.CallBackOnDamageEx = function(victimPlayer, attackingPlayer, hitType, hitPart, otherhitType, hitTypeEx, damageAmount, isEstimate)
        --track individiual damage from an enemy to your team
        if not IsNull(attackingPlayer:GetAvatar()) and not IsNull(MyPlayer:GetAvatar()) and not isEstimate then
            if attackingPlayer:GetAvatar():GetFaction() ~= MyPlayer:GetAvatar():GetFaction() then
                local victimName = victimPlayer:GetPlayerName()
                local attackerName = attackingPlayer:GetPlayerName()
            
                if not damageInfo[attackerName] then
                    damageInfo[attackerName] = {}
                end
                
                if not damageInfo[attackerName][victimName] then
                    damageInfo[attackerName][victimName] = {}
                end             
                
                local info = damageInfo[attackerName][victimName]
                table.insert(info, { time = RealTime(), amount =  damageAmount })           
            end
        end
    end
end

function MatchAttackEvent(damageData, attackingPlayer, isEstimate)
    if obj then
        TimedChallengeKillsCommon.OnAttackEvent(obj, damageData, attackingPlayer, isEstimate)
    end
end

function Update(player, delta)
    local curtime = RealTime()
    
    -- clear out old entries...slowly
    for key, value in pairs(damageInfo) do
        for key2, info in pairs(value) do
            if #info > 0 then
                if info[1].time < RealTime() - DAMAGE_TIMERANGE then
                    table.remove(info, 1)
                end
            end
        end
    end
end
