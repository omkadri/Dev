module(..., package.seeall)

function HandleAroundFlagOnDamage(flagFaction, victimPlayer)
    if not IsNull(_T.PVPObject) then
        
        --note: does not find it if it's being held
        local pickup = _T.PVPObject:GetFactionFlagPickup(flagFaction)
        
        --someone is holding it...
        if IsNull(pickup) then
            --note: this actually returns the avatar of the holder
            pickup = _T.PVPObject:FindFlagHolderAvatarForFaction(_T.PVPObject:GetEnemyFaction(flagFaction))
        end
        
        if not IsNull(pickup) then
            local validRange
            
            if _T.PVPObject:IsFlagSafe(flagFaction) then
                validRange = 20
            else
                validRange = 10
            end
            
            local d = Distance(victimPlayer:GetAvatar():GetPosition(), pickup:GetPosition())
            
            if d <= validRange then
                return true
            end
            
        end

    end
    
    return false
end
