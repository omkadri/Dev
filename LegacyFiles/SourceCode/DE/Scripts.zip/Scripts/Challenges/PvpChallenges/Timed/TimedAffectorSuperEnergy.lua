ChallengeInstanceID = String()  --will get set by the challengeManager

function Start()
    if gRegion:IsMaster() then
        local gameRules = gGameRules
        gameRules:SetNetPersistentVar(Symbol("PvpSuperEnergyMode"), 1)
    end
end 

function OnPlayerSpawned(player)

    local avatar = player:GetAvatar()
    if not IsNull(avatar) then
        local ic = avatar:InventoryControl()  
        if not IsNull(ic) then
            --energy gain
            ic:AddUpgrade(Game.AVATAR_POWER_RATE, Game.ADD, .75)
        end
    end

end
