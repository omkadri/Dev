ChallengeInstanceID = String()  --will get set by the challengeManager
MyPlayer = Instance() --will get set by the challengeManager

local obj = nil

local TimedChallengeSimpleCounter = require "Lotus.Scripts.Challenges.PvpChallenges.Timed.TimedChallengeSimpleCounter"

function Start()
    obj = TimedChallengeSimpleCounter.OnStart(ChallengeInstanceID,MyPlayer) 
end


function MatchTagEvent(player, tag, howMany, source)
    if tag == "ROUND_ENDED" and player:IsLocal() then
        TimedChallengeSimpleCounter.AddToScore(obj)
    end
end
