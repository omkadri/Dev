module(..., package.seeall)

HITTYPE_MELEE = 0
HITTYPE_POWER = 1
HITTYPE_WEAPON = 2
HITTYPE_NUM = 3

HITTYPE_EX_NONE = 0
HITTYPE_EX_WEAPON_PRIMARY = 1
HITTYPE_EX_WEAPON_SECONDARY = 2

function OnStart(ChallengeInstanceID, MyPlayer)
    local self = {}

    self.curNumHits = 0
    self.maxNumHits = 1

    self.DamageHistory = {}
    self.KillStreaks = {}
    self.KillStreaksBetweenPlayer = {}
    self.LastKilledBy = {}

    self.MyPlayer = MyPlayer
    
    self.challengeInstance = gChallengeMgr:GetChallengeInstanceByStr(ChallengeInstanceID)
    if IsNull(self.challengeInstance) then
        return self
    end

    self.challengeUserState = gChallengeMgr:GetChallengeInstanceUserStateByStr(ChallengeInstanceID)
    if IsNull(self.challengeUserState) then
        return self
    end

    if not self.challengeUserState:HasParam("curNumHits") then
        self.challengeUserState:SetParamInt("curNumHits", 0)
    end

    self.curNumHits = self.challengeUserState:GetParamInt("curNumHits")
    self.maxNumHits = self.challengeInstance:GetParamInt("ScriptParamValue")

    self.DamageHistory = {}
    self.KillStreaks = {}
    self.KillStreaksBetweenPlayer = {}
    self.LastKilledBy = {}

    return self
end

function OnAttackEvent(self, damageData, attackingPlayer, isEstimate)
    local victimAvatar = damageData:GetVictim()
    if IsNull(victimAvatar) or IsNull(attackingPlayer) then
        return
    end
    
    local victimPlayer = victimAvatar:GetPlayer()
    if IsNull(victimPlayer) then
        return
    end

    local sourceObject = damageData:GetSourceObject()
    if IsNull(sourceObject) then -- i don't know!....ignore so you don't crash!!!
        return
    end

    local attackerName = attackingPlayer:GetPlayerName()
    local victimName = victimPlayer:GetPlayerName()

    local statSource = sourceObject
    if sourceObject:IsA(gLotusWeaponType) and not IsNull(sourceObject:GetDamageSource()) then
        statSource = sourceObject:GetDamageSource()
    end

    local hitType
    local hitTypeEx = HITTYPE_EX_NONE
    if statSource:IsA(gLotusMeleeWeaponType) then
        hitType = HITTYPE_MELEE
    elseif statSource:IsA(gPowerSuitType) then
        hitType = HITTYPE_POWER
    else
        hitType = HITTYPE_WEAPON
        if sourceObject:IsA(gLotusPistolType) then
            hitTypeEx = HITTYPE_EX_WEAPON_SECONDARY
        else
            hitTypeEx = HITTYPE_EX_WEAPON_PRIMARY
        end

    end

    local isDeath = damageData:IsDeathInjury()
    local isTheAttacker = self.MyPlayer:GetPlayerName() == attackerName

    -- handle damage history
    if not isEstimate then
        if self.DamageHistory[attackerName] == nil then
            self.DamageHistory[attackerName] = {}
        end

        if self.DamageHistory[attackerName][victimName] == nil then
            self.DamageHistory[attackerName][victimName] = { hitTypes = {}, lastHitTime = RealTime() - 10000, lastDeathTime = RealTime() - 10000 }
        end
        
        if not self.DamageHistory[attackerName][victimName].hitTypes[hitType] then
            self.DamageHistory[attackerName][victimName].hitTypes[hitType] = 0
        end
        self.DamageHistory[attackerName][victimName].hitTypes[hitType] = self.DamageHistory[attackerName][victimName].hitTypes[hitType] + 1
        
        if not isDeath then
            self.DamageHistory[attackerName][victimName].lastHitTime = RealTime()
        else
            self.DamageHistory[attackerName][victimName].lastDeathTime = RealTime()
        end
    end
    
    -------------------

    if self.CallBackOnDamageEx then
        if gRegion:IsMaster() then
            self.CallBackOnDamageEx(victimPlayer, attackingPlayer, hitType, damageData:GetHitPart(), damageData:GetHitType(), hitTypeEx, damageData:GetAmount(), true)
        end     
        self.CallBackOnDamageEx(victimPlayer, attackingPlayer, hitType, damageData:GetHitPart(), damageData:GetHitType(), hitTypeEx, damageData:GetAmount(), isEstimate)
    end
    
    if isEstimate then
        return 
    end
    
    if isDeath then
        -- clear your victims streak against you [if they even had one]
        if not self.KillStreaksBetweenPlayer[victimName] then
            self.KillStreaksBetweenPlayer[victimName] = {}
        end
        self.KillStreaksBetweenPlayer[victimName][attackerName] = 0
        
        -- increase your streak against your victim
        if not self.KillStreaksBetweenPlayer[attackerName] then
            self.KillStreaksBetweenPlayer[attackerName] = {}
        end
        if not self.KillStreaksBetweenPlayer[attackerName][victimName] then
            self.KillStreaksBetweenPlayer[attackerName][victimName] = 0
        end
        self.KillStreaksBetweenPlayer[attackerName][victimName] = self.KillStreaksBetweenPlayer[attackerName][victimName] + 1
        
        -- advance your overall kill streak
        if not self.KillStreaks[attackerName] then
            self.KillStreaks[attackerName] = 0
        end
        self.KillStreaks[attackerName] = self.KillStreaks[attackerName] + 1
        
        -- remember who kills the victim last
        self.LastKilledBy[victimName] = attackerName
        
        -- trigger the callback now!
        if isTheAttacker then
            if self.CallBackOnKill then
                self.CallBackOnKill(victimPlayer, hitType, damageData:GetHitPart(), damageData:GetHitType(), hitTypeEx)
            end 
        end

        if self.CallBackOnKillEx then
            self.CallBackOnKillEx(victimPlayer, attackingPlayer, hitType, damageData:GetHitPart(), damageData:GetHitType(), hitTypeEx)
        end
    
        -- should be ok to clear this info now, just in case the callback needed it [for damageHistory mainly]
        -- clear history after death.  Should have already used it by now..if it was even useful!
        if self.DamageHistory[attackerName][victimName] then
            self.DamageHistory[attackerName][victimName].hitTypes = {}
            self.DamageHistory[attackerName][victimName].lastHitTime = RealTime() - 10000
        end
        
        -- clear your overall kill streak if you died [note: KillStreaksBetweenPlayer will still preserve perPlayer tracked streaks]
        self.KillStreaks[victimName] = 0
        
        -- clear it if you just killed your last killer of you
        if self.LastKilledBy[attackerName] == victimName then
            self.LastKilledBy[attackerName] = nil
        end
    end
end

function ComputeNumHitTypes(self, attackerName, victimName)
    local numHitTypes = 0
    for i = 0, HITTYPE_NUM - 1 do
        if self.DamageHistory[attackerName] then
            if self.DamageHistory[attackerName][victimName] then
                if self.DamageHistory[attackerName][victimName].hitTypes[i] then
                    numHitTypes = numHitTypes + 1
                end
            end
        end
    end
    
    return numHitTypes
end

function AddToScore(self, amount)
    if not amount then
        amount = 1
    end
    
    self.curNumHits = self.curNumHits + amount

    if not IsNull(self.challengeUserState) then
        self.challengeUserState:SetParamInt("curNumHits", self.curNumHits)
        self.challengeUserState:SetProgress(self.curNumHits / self.maxNumHits)
    end
end
