ChallengeInstanceID = String()  --will get set by the challengeManager
MyPlayer = Instance() --will get set by the challengeManager

local TimedChallengeKillsCommon = require "Lotus.Scripts.Challenges.PvpChallenges.Timed.TimedChallengeKillsCommon"

local obj = nil

function Start()
    obj = TimedChallengeKillsCommon.OnStart(ChallengeInstanceID,MyPlayer)
    obj.CallBackOnKill = function(victimPlayer, hitType, hitPart, otherhitType, hitTypeEx)
        
        local myAvatar = MyPlayer:GetAvatar()
        if not IsNull(myAvatar) then
            local posture = myAvatar:GetPosture()
            if posture == Engine.SLIDE then
                TimedChallengeKillsCommon.AddToScore(obj)
                
                --if not IsNull(MyPlayer:GetAvatar()) and not IsNull(victimPlayer:GetAvatar()) then
                --  MyPlayer:GetAvatar():InventoryControl():GiveXP(50, victimPlayer:GetAvatar(), ChallengeType.mLocName);
                --end
                
            end
        end
            
    end 
end

function MatchAttackEvent(damageData, attackingPlayer, isEstimate)
    if obj then
        TimedChallengeKillsCommon.OnAttackEvent(obj, damageData, attackingPlayer, isEstimate)
    end
end
