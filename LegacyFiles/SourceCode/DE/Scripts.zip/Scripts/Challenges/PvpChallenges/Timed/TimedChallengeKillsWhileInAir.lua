ChallengeInstanceID = String()  --will get set by the challengeManager
MyPlayer = Instance() --will get set by the challengeManager

local TimedChallengeKillsCommon = require "Lotus.Scripts.Challenges.PvpChallenges.Timed.TimedChallengeKillsCommon"

local obj = nil

function Start()
    obj = TimedChallengeKillsCommon.OnStart(ChallengeInstanceID,MyPlayer)
    obj.lastHitWhileFalling = {}
    obj.CallBackOnKill = function(victimPlayer, hitType, hitPart, otherhitType, hitTypeEx)
        if not IsNull(MyPlayer:GetAvatar()) then
            if obj.lastHitWhileFalling[victimPlayer:GetPlayerName()] then
                TimedChallengeKillsCommon.AddToScore(obj)               
            end
        end
    end 
    
    obj.CallBackOnDamageEx = function(victimPlayer, attackingPlayer, hitType, hitPart, otherhitType, hitTypeEx, damageAmount, isEstimate)
        if not IsNull(MyPlayer:GetAvatar()) and isEstimate and attackingPlayer:GetPlayerName() == MyPlayer:GetPlayerName() then
            obj.lastHitWhileFalling[victimPlayer:GetPlayerName()] = MyPlayer:GetAvatar():IsFalling()
        end
    end
end

function MatchAttackEvent(damageData, attackingPlayer, isEstimate)
    if obj then
        TimedChallengeKillsCommon.OnAttackEvent(obj, damageData, attackingPlayer, isEstimate)
    end
end
