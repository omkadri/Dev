ChallengeInstanceID = String()  --will get set by the challengeManager
MyPlayer = Instance() --will get set by the challengeManager
ChallengeType = Resource() --will get set by the challengeManager

local TimedChallengeKillsCommon = require "Lotus.Scripts.Challenges.PvpChallenges.Timed.TimedChallengeKillsCommon"

local obj = nil

function Start()
    obj = TimedChallengeKillsCommon.OnStart(ChallengeInstanceID,MyPlayer)
    
    obj.CallBackOnKill = function(victimPlayer, hitType, hitPart, otherhitType, hitTypeEx)
        
        local curTime = RealTime()
        
        if not IsNull(_T.PVPObject) then
        
            --check for any valid damage done to my current team flag holder
            
            if not IsNull(MyPlayer:GetAvatar()) then
            
                --get flag holder
                local flagHolderAvatar = _T.PVPObject:FindFlagHolderAvatarForFaction(MyPlayer:GetAvatar():GetFaction())
                if not IsNull(flagHolderAvatar) and flagHolderAvatar ~= MyPlayer:GetAvatar() then   --has a flag holder for my team..that isn't me
                
                    if not IsNull(flagHolderAvatar:GetPlayer()) then
                        --person i killed.... recently attacked flag holder
                        if obj.DamageHistory[victimPlayer:GetPlayerName()][flagHolderAvatar:GetPlayer():GetPlayerName()] then
                            if curTime - obj.DamageHistory[victimPlayer:GetPlayerName()][flagHolderAvatar:GetPlayer():GetPlayerName()].lastHitTime <= 5.0 then
                                TimedChallengeKillsCommon.AddToScore(obj)
                            end
                        end
                    end
                    
                end
                
            end
            
        end
        
    end 
end

function MatchAttackEvent(damageData, attackingPlayer, isEstimate)
    if obj then
        TimedChallengeKillsCommon.OnAttackEvent(obj, damageData, attackingPlayer, isEstimate)
    end
end
