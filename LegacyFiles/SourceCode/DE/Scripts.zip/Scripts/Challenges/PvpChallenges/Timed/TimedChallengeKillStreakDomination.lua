ChallengeInstanceID = String()  --will get set by the challengeManager
MyPlayer = Instance() --will get set by the challengeManager

local TimedChallengeKillsCommon = require "Lotus.Scripts.Challenges.PvpChallenges.Timed.TimedChallengeKillsCommon"

local obj = nil

local KILLS_FOR_DOMINATION = 2

function Start()
    obj = TimedChallengeKillsCommon.OnStart(ChallengeInstanceID,MyPlayer)   
    obj.CallBackOnKill = function(victimPlayer, hitType, hitPart)
        local victimName = victimPlayer:GetPlayerName()
        if obj.KillStreaksBetweenPlayer[MyPlayer:GetPlayerName()] then
            if obj.KillStreaksBetweenPlayer[MyPlayer:GetPlayerName()][victimName] then

                if obj.KillStreaksBetweenPlayer[MyPlayer:GetPlayerName()][victimName] >= KILLS_FOR_DOMINATION then    --domination
                    TimedChallengeKillsCommon.AddToScore(obj)
                end
            end
        end

    end 
end

function MatchAttackEvent(damageData, attackingPlayer, isEstimate)
    if obj then
        TimedChallengeKillsCommon.OnAttackEvent(obj, damageData, attackingPlayer, isEstimate)
    end
end
