ChallengeInstanceID = String()  --will get set by the challengeManager
MyPlayer = Instance() --will get set by the challengeManager
ChallengeType = Resource() --will get set by the challengeManager

local TimedChallengeKillsCommon = require "Lotus.Scripts.Challenges.PvpChallenges.Timed.TimedChallengeKillsCommon"

local obj = nil

local ASSIST_MAX_TIME = 3

function Start()
    obj = TimedChallengeKillsCommon.OnStart(ChallengeInstanceID,MyPlayer)   
    obj.CallBackOnKillEx = function(victimPlayer, attackingPlayer, hitType, hitPart)
        local victimName = victimPlayer:GetPlayerName()
        local attackerName = attackingPlayer:GetPlayerName()
        local curTime = RealTime()
        if obj.DamageHistory[MyPlayer:GetPlayerName()][victimName] then
            if MyPlayer:GetPlayerName() ~= attackerName and curTime - obj.DamageHistory[MyPlayer:GetPlayerName()][victimName].lastHitTime <= ASSIST_MAX_TIME then
                TimedChallengeKillsCommon.AddToScore(obj)
            end
        end
    end 
end

function MatchAttackEvent(damageData, attackingPlayer, isEstimate)
    if obj then
        TimedChallengeKillsCommon.OnAttackEvent(obj, damageData, attackingPlayer, isEstimate)
    end
end
