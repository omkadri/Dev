ChallengeInstanceID = String()  --will get set by the challengeManager

function Start()
    if gRegion:IsMaster() then
        local gameRules = gGameRules
        gameRules:SetNetPersistentVar(Symbol("PvpSuperEnergyMode"), 1)
    end
end 

function OnPlayerSpawned(player)

    local avatar = player:GetAvatar()
    if not IsNull(avatar) then
        local ic = avatar:InventoryControl()  
        if not IsNull(ic) then
            ic:AddUpgrade(Game.WEAPON_MELEE_DAMAGE, Game.STACKING_MULTIPLY, 1)
            --ic:AddUpgrade(Game.AVATAR_PARKOUR_BOOST, Game.STACKING_MULTIPLY, 2)
            ic:AddUpgrade(Game.WEAPON_DAMAGE_AMOUNT, Game.STACKING_MULTIPLY, 1, gLotusPistolType)
            ic:AddUpgrade(Game.AVATAR_ABILITY_STRENGTH, Game.STACKING_MULTIPLY, 1)
            ic:AddUpgrade(Game.AVATAR_POWER_RATE, Game.ADD, .75)
        end
    end

end
