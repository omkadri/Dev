module(..., package.seeall)

function OnStart(ChallengeInstanceID, MyPlayer)
    local self = {}

    self.MyPlayer = MyPlayer
    self.ChallengeInstanceID = ChallengeInstanceID
    self.curNumHits = 0
    self.maxNumHits = 1

    self.challengeInstance = gChallengeMgr:GetChallengeInstanceByStr(ChallengeInstanceID)
    if IsNull(self.challengeInstance) then
        return self
    end

    self.challengeUserState = gChallengeMgr:GetChallengeInstanceUserStateByStr(ChallengeInstanceID)
    if IsNull(self.challengeUserState) then
        return self
    end

    if not self.challengeUserState:HasParam("curNumHits") then
        self.challengeUserState:SetParamInt("curNumHits",0)
    end

    self.curNumHits = self.challengeUserState:GetParamInt("curNumHits")
    self.maxNumHits = self.challengeInstance:GetParamInt("ScriptParamValue")

    return self
end

function AddToScore(self, amount)
    if not amount then
        amount = 1
    end
    
    self.curNumHits = self.curNumHits + amount

    --note: there are cases were the user state object is remade..so need to re-get this
    self.challengeUserState = gChallengeMgr:GetChallengeInstanceUserStateByStr(self.ChallengeInstanceID)
    if not IsNull(self.challengeUserState) then
        self.challengeUserState:SetParamInt("curNumHits", self.curNumHits)
        self.challengeUserState:SetProgress(self.curNumHits/self.maxNumHits)
    end
end

