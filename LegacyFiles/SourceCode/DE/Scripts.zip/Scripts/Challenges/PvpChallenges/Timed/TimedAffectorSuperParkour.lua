ChallengeInstanceID = String()  --will get set by the challengeManager
MyPlayer = Instance() --will get set by the challengeManager
ChallengeType = Resource() --will get set by the challengeManager
function Start()
end 

function OnPlayerSpawned(player)

    local avatar = player:GetAvatar()
    if not IsNull(avatar) then
        local ic = avatar:InventoryControl()  
        if not IsNull(ic) then
            ic:AddUpgrade(Game.AVATAR_PARKOUR_BOOST, Game.STACKING_MULTIPLY, 1.25)
        end
    end

end
