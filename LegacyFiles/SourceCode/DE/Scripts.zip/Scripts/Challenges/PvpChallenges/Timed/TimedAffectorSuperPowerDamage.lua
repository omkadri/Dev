ChallengeInstanceID = String()  --will get set by the challengeManager


function Start()
end 

function OnPlayerSpawned(player)

    local avatar = player:GetAvatar()
    if not IsNull(avatar) then
        local ic = avatar:InventoryControl()  
        if not IsNull(ic) then
            ic:AddUpgrade(Game.AVATAR_ABILITY_STRENGTH, Game.STACKING_MULTIPLY, 1)
        end
    end

end
