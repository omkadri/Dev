ChallengeInstanceID = String()  --will get set by the challengeManager
MyPlayer = Instance() --will get set by the challengeManager
ChallengeType = Resource() --will get set by the challengeManager

local TimedChallengeKillsCommon = require "Lotus.Scripts.Challenges.PvpChallenges.Timed.TimedChallengeKillsCommon"

local obj = nil

function Start()
    obj = TimedChallengeKillsCommon.OnStart(ChallengeInstanceID,MyPlayer)
    obj.CallBackOnKill = function(victimPlayer, hitType, hitPart, otherhitType, hitTypeEx)

        local curTime = RealTime()
        
        --search for any caused deaths within time limit
        if obj.DamageHistory[victimPlayer:GetPlayerName()] then
            for key,value in pairs(obj.DamageHistory[victimPlayer:GetPlayerName()]) do
                if curTime - value.lastDeathTime < 5 then
                    TimedChallengeKillsCommon.AddToScore(obj)
                    break
                end
            end
        end
        
    end 
end

function MatchAttackEvent(damageData, attackingPlayer, isEstimate)
    if obj then
        TimedChallengeKillsCommon.OnAttackEvent(obj, damageData, attackingPlayer, isEstimate)
    end
end
