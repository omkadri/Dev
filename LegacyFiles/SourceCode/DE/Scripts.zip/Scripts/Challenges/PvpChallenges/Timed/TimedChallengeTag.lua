ChallengeInstanceID = String()  --will get set by the challengeManager
MyPlayer = Instance() --will get set by the challengeManager

challengeTag = String()

local obj = nil

local TimedChallengeSimpleCounter = require "Lotus.Scripts.Challenges.PvpChallenges.Timed.TimedChallengeSimpleCounter"

function Start()
    obj = TimedChallengeSimpleCounter.OnStart(ChallengeInstanceID,MyPlayer) 
end

function MatchTagEvent(player, tag, howMany, source)
    if tag == challengeTag and player:IsLocal() then
        TimedChallengeSimpleCounter.AddToScore(obj, howMany)
    end
end
