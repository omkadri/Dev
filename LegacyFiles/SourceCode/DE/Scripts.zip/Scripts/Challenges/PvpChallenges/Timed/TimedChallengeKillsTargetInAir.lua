ChallengeInstanceID = String()  --will get set by the challengeManager
MyPlayer = Instance() --will get set by the challengeManager

local TimedChallengeKillsCommon = require "Lotus.Scripts.Challenges.PvpChallenges.Timed.TimedChallengeKillsCommon"

local obj = nil

function Start()
    obj = TimedChallengeKillsCommon.OnStart(ChallengeInstanceID,MyPlayer)
    
    -- used to track last client-side known hit on a someone...to better see if the last kill [which should also be the kill...was in the air as far as the client saw!]
    obj.lastHitWasFalling = {}
    obj.CallBackOnKill = function(victimPlayer, hitType, hitPart, otherhitType, hitTypeEx)
        if not IsNull(victimPlayer) then
            if obj.lastHitWasFalling[victimPlayer:GetPlayerName()] then
                TimedChallengeKillsCommon.AddToScore(obj)
            end
        end
        
    end
    
    obj.CallBackOnDamageEx = function(victimPlayer, attackingPlayer, hitType, hitPart, otherhitType, hitTypeEx, damageAmount, isEstimate)
        if not IsNull(victimPlayer:GetAvatar()) and isEstimate and attackingPlayer:GetPlayerName() == MyPlayer:GetPlayerName() then
            obj.lastHitWasFalling[victimPlayer:GetPlayerName()] = victimPlayer:GetAvatar():IsFalling()
        end
    end
end

function MatchAttackEvent(damageData, attackingPlayer, isEstimate)
    if obj then
        TimedChallengeKillsCommon.OnAttackEvent(obj, damageData, attackingPlayer, isEstimate)
    end
end
