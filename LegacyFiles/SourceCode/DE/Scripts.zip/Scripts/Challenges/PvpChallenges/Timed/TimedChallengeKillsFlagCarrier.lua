ChallengeInstanceID = String()  --will get set by the challengeManager
MyPlayer = Instance() --will get set by the challengeManager
ChallengeType = Resource() --will get set by the challengeManager

local TimedChallengeKillsCommon = require "Lotus.Scripts.Challenges.PvpChallenges.Timed.TimedChallengeKillsCommon"

local obj = nil

function Start()
    obj = TimedChallengeKillsCommon.OnStart(ChallengeInstanceID,MyPlayer)
    obj.CallBackOnKill = function(victimPlayer, hitType, hitPart, otherhitType, hitTypeEx)
    
        if not IsNull(_T.PVPObject) then
            if _T.PVPObject:AvatarHasFlag(victimPlayer:GetAvatar()) then
                TimedChallengeKillsCommon.AddToScore(obj)
            end
        end
        
    end 
end

function MatchAttackEvent(damageData, attackingPlayer, isEstimate)
    if obj then
        TimedChallengeKillsCommon.OnAttackEvent(obj, damageData, attackingPlayer, isEstimate)
    end
end
