ChallengeInstanceID = String()  --will get set by the challengeManager
MyPlayer = Instance() --will get set by the challengeManager

local TimedChallengeKillsCommon = require "Lotus.Scripts.Challenges.PvpChallenges.Timed.TimedChallengeKillsCommon"

local obj = nil

function Start()
    obj = TimedChallengeKillsCommon.OnStart(ChallengeInstanceID,MyPlayer)
    obj.CallBackOnKill = function(victimPlayer, hitType, hitPart, otherhitType, hitTypeEx)
    
        if hitTypeEx == TimedChallengeKillsCommon.HITTYPE_EX_WEAPON_SECONDARY then
            TimedChallengeKillsCommon.AddToScore(obj)
        end
        
    end 
end

function MatchAttackEvent(damageData, attackingPlayer, isEstimate)
    if obj then
        TimedChallengeKillsCommon.OnAttackEvent(obj, damageData, attackingPlayer, isEstimate)
    end
end
