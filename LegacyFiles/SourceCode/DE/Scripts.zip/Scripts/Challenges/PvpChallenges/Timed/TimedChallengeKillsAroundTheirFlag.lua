ChallengeInstanceID = String()  --will get set by the challengeManager
MyPlayer = Instance() --will get set by the challengeManager
ChallengeType = Resource() --will get set by the challengeManager

local TimedChallengeKillsCommon = require "Lotus.Scripts.Challenges.PvpChallenges.Timed.TimedChallengeKillsCommon"
local KillsAroundFlagHelper = require "Lotus.Scripts.Challenges.PvpChallenges.Timed.KillsAroundFlagHelper"

local obj = nil

function Start()
    obj = TimedChallengeKillsCommon.OnStart(ChallengeInstanceID, MyPlayer)
    
    obj.CallBackOnDamageEx = function(victimPlayer, attackingPlayer, hitType, hitPart, otherhitType, hitTypeEx, damageAmount, isEstimate)
        if not IsNull(_T.PVPObject) and not isEstimate then
            if not IsNull(MyPlayer:GetAvatar()) then
                if KillsAroundFlagHelper.HandleAroundFlagOnDamage(_T.PVPObject:GetEnemyFaction(MyPlayer:GetAvatar():GetFaction()), victimPlayer) then
                    TimedChallengeKillsCommon.AddToScore(obj, damageAmount)
                end
            end
        end
    end
end

function MatchAttackEvent(damageData, attackingPlayer, isEstimate)
    if obj then
        TimedChallengeKillsCommon.OnAttackEvent(obj, damageData, attackingPlayer, isEstimate)
    end
end
