ChallengeInstanceID = String()  --will get set by the challengeManager
MyPlayer = Instance() --will get set by the challengeManager

local TimedChallengeKillsCommon = require "Lotus.Scripts.Challenges.PvpChallenges.Timed.TimedChallengeKillsCommon"

local obj = nil

function Start()
    obj = TimedChallengeKillsCommon.OnStart(ChallengeInstanceID,MyPlayer)   
    obj.CallBackOnKill = function(victimPlayer, hitType, hitPart)
    
        --every 3 kills in a row starting at 3
        if obj.KillStreaks[MyPlayer:GetPlayerName()] and obj.KillStreaks[MyPlayer:GetPlayerName()] > 0 and (obj.KillStreaks[MyPlayer:GetPlayerName()])%3 == 0 then
            TimedChallengeKillsCommon.AddToScore(obj)
        end

    end 
end

function MatchAttackEvent(damageData, attackingPlayer, isEstimate)
    if obj then
        TimedChallengeKillsCommon.OnAttackEvent(obj, damageData, attackingPlayer, isEstimate)
    end
end
