ChallengeInstanceID = String()  --will get set by the challengeManager

local curNum = 0
local maxNum = 1

local challengeInstance
local challengeUserState

function Start()
    print("PVPChallengeFlagCapture Start")
    challengeInstance = gChallengeMgr:GetChallengeInstanceByStr(ChallengeInstanceID)
    if IsNull(challengeInstance) then
        return
    end
    challengeUserState = gChallengeMgr:GetChallengeInstanceUserStateByStr(ChallengeInstanceID)
    if IsNull(challengeUserState) then
        return
    end

    if not challengeUserState:HasParam("curNum") then
        challengeUserState:SetParamInt("curNum", 0)
    end
    curNum = challengeUserState:GetParamInt("curNum")
    maxNum = challengeInstance:GetParamInt("ScriptParamValue")
end

function MatchTagEvent(player, tag, howMany, source)
    if tag == "FLAG_DEPOSIT" and player:IsLocal() then
        print("PVPChallengeFlagCapture advance the number!")
        curNum = curNum + 1
        if not IsNull(challengeUserState) then
            challengeUserState:SetParamInt("curNum", curNum)
            challengeUserState:SetProgress(curNum/maxNum)
        end     
    end
end
