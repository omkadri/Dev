numTypesForMatch = 2    -- How many different damage types (of melee, power, weapon) are needed to make the match
matchingTypeSym = Symbol("Melee")    -- Which type to match, valid only when numTypesForMatch is 1. Currently 'Melee' or 'Power' supported

local COMBO_TYPES = {"Melee", "Power", "Weapon" }

function MatchAttackEvent(damageData, player)
    local attackerName = player:GetPlayerName()
    local victim = damageData:GetVictim()

    local sourceObject = damageData:GetSourceObject()
    
    local matchingType = tostring(matchingTypeSym)

    local challengeDataName = ""
    if numTypesForMatch == 1 then
        if matchingType == "Melee" then
            challengeDataName = "MeleeKillData"
        elseif matchingType == "Power" then
            challengeDataName = "PowerKillData"
        end
    elseif numTypesForMatch == 2 then
        challengeDataName = "ComboKillData"
    elseif numTypesForMatch == 3 then
        challengeDataName = "MultiToolKillData"
    end

    if challengeDataName == "" then
        print("Bad parameters for Combo.lua")
        return(false)
    end

    if not IsNull(victim:GetPlayer()) and not IsNull(sourceObject) then  -- Should always be the case
        local victimName = victim:GetPlayer():GetPlayerName()
        
        if _T[challengeDataName] == nil then
            _T[challengeDataName] = {}
        end

        if _T[challengeDataName][victimName] == nil then
            _T[challengeDataName][victimName] = {} 
        end

        if _T[challengeDataName][victimName][attackerName] == nil then
            _T[challengeDataName][victimName][attackerName] = {}
        end

        local statSource = sourceObject
        if sourceObject:IsA(gLotusWeaponType) and not IsNull(sourceObject:GetDamageSource()) then
            statSource = sourceObject:GetDamageSource()
        end
        
        local type = ""
        if statSource:IsA(gLotusMeleeWeaponType) then
            type = COMBO_TYPES[1]
        elseif statSource:IsA(gPowerSuitType) then
            type = COMBO_TYPES[2]
        else
            type = COMBO_TYPES[3]
        end

        _T[challengeDataName][victimName][attackerName][type] = true

        if damageData:IsDeathInjury() then
            local numTypes = 0
            for i = 1, #COMBO_TYPES do
                if _T[challengeDataName][victimName][attackerName][COMBO_TYPES[i]] then
                    numTypes = numTypes + 1
                end
            end

            local isMatch = false

            if numTypes == numTypesForMatch then
                if numTypesForMatch ~= 1 or _T[challengeDataName][victimName][attackerName][matchingType] then
                    isMatch = true
                end
            end

            -- Clear info
            _T[challengeDataName][victimName] = nil

            return(isMatch)
        end
    end

    return(false)
end