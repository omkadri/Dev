endMissionMovie = Resource()
endMissionDialog = Instance()
kneelAnim = Resource()
endMissionTrans = Type()
failMissionTrans = Type()
backupAiSpec = Resource()
spawnEffect = Type()
enemyProjectorFX = Type()
eximusEnemyProjectorFX = Type()

collectibleType = Type()
collectibleLargeType = Type()

isLarge = false

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local CROOM = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"

local sCollectible = Symbol("CollectibleSpawn")
local sCollectibleLarge = Symbol("CollectibleSpawnLarge")
local sTimer = Symbol("Timer")
local sBankAction = Symbol("BankAction")
local sRandomTeam = Symbol("RandomTeam")
local sModifier = Symbol("Modifier")

local collectObjLoc = "/Lotus/Language/Game/MasteryCollectObjective"
local pointsBankedLoc = "/Lotus/Language/Game/MasteryCollectTotalBanked"
local bankedPointsLoc = "/Lotus/Language/Game/MasteryCollectBanked"
local damageLoc = "/Lotus/Language/Game/MasteryCollectDamageMultiplier"
local enemyLevelsLoc = "/Lotus/Language/Game/MasteryCollectEnemyLevels"
local pointsHeldLoc = "/Lotus/Language/Game/MasteryCollectPointsHeld"

local mAiDir = nil
local mPlayer = nil
local mPlayerAv = nil
local mHudStatus = nil
local mBankAction = nil

local mGameRules = gGameRules
local mTimerMgr = TIMER.CreateTimerMgr()
local mIncomingDamageTracker = nil
local mLevelTracker = nil
local mTimeElapsed = 0

local mEnemyMinLevel = 0
local mEnemyMaxLevel = 0

local mCollectibleSpawnPoints = nil
local mCollectibleLargeSpawnPoints = nil
local mCollected = 0
local mBanked = 0
local mDamageModifier = 1
local mEnemyLevelScale = 1

local mEximusToSpawn = 0
local mNumAgentsToSpawn = 0
local mAgents = {}


local MAX_SPAWN = 10
local SPAWN_TIME = 2
local MIN_SQUAD_SIZE = 3
local MAX_SQUAD_SIZE = 5


local SMALL_ITEM_VALUE = 1
local LARGE_ITEM_VALUE = 3
local NUM_TO_BANK = 100
local DAMAGE_MODIFIER_PER_ITEM = 0.1
local ENEMY_SCALE = 0.2 --enemy level increase per second

local TIME_TO_COLLECT = 300

local mState = 0
local COLLECT_STAGE_A = 1
local COLLECT_STAGE_B = 2
local COLLECT_STAGE_C = 3
local COMPLETE_OBJECTIVE = 4
local FAILED = 5
local SetState = nil

local function UpdateTrackers()
    mIncomingDamageTracker.SetLabel(mIncomingDamageTracker.Localize(damageLoc, { PERCENT = string.format("%.0f", mDamageModifier * 100)}))
    mLevelTracker.SetLabel(mLevelTracker.Localize(enemyLevelsLoc, { INCREASE = mAiDir:GetMinEnemyLevel() - mEnemyMinLevel} ))
    OBJTXT.UpdateObjProgressBar(mBanked, NUM_TO_BANK)
    mHudStatus:SetGenericMessage(Localize(pointsHeldLoc, { COUNT = mCollected }))
end

local function SpawnCollectibles()
    local remainingCollectibles = gRegion:FindAll(collectibleType)
    for i, collectible in ipairs(remainingCollectibles) do
        collectible:Destroy()
    end

    for i, point in ipairs(mCollectibleSpawnPoints) do
        gRegion:CreateEntity(collectibleType, point:GetPosition(), ZERO_ROTATION)
    end
    
    for i, point in ipairs(mCollectibleLargeSpawnPoints) do
        gRegion:CreateEntity(collectibleLargeType, point:GetPosition(), ZERO_ROTATION)
    end
end

local function OnStateChanged()
    if mState == COLLECT_STAGE_A then
        OBJTXT.SetSecondaryObjText(collectObjLoc)
        OBJTXT.SetObjProgressBar(pointsBankedLoc, 0, NUM_TO_BANK)
        mIncomingDamageTracker = _T.AddHudTracker("DamageTracker", LOTUS_UTIL.HT_LABEL)
        mLevelTracker = _T.AddHudTracker("LevelTracker", LOTUS_UTIL.HT_LABEL)
        mGameRules:SetMissionTimer(sTimer, Symbol(collectObjLoc), TIME_TO_COLLECT, false, true)
    
        SpawnCollectibles()
        
    elseif mState == COLLECT_STAGE_B then
        SpawnCollectibles()
        
    elseif mState == COLLECT_STAGE_C then
        SpawnCollectibles()
    
    elseif mState == COMPLETE_OBJECTIVE then
        OBJTXT.ClearPrimaryObjText()
        OBJTXT.RemoveObjProgressBar()
        
        local remainingCollectibles = gRegion:FindAll(collectibleType)
        for i, collectible in ipairs(remainingCollectibles) do
            collectible:Destroy()
        end
        mCollected = 0

        mGameRules:SetPausedMissionTimer(sTimer, true)        
    
    elseif mState == FAILED then
        mGameRules:RemoveMissionTimer(sTimer)
        mPlayerAv:GiveItem(failMissionTrans, true)
    end
end

SetState = function(newState)
    if newState ~= mState then
        mState = newState
        OnStateChanged()
    end
end

function OnKilled(avatar)
    local agent = avatar:GetAgent()
    if not IsNull(agent) and agent:GetGenusFromAvatarType(avatar:GetType()) == Engine.EXIMUS then
        gRegion:CreateEntity(collectibleLargeType, avatar:GetPosition() + Vector(0, 1.5, 0), ZERO_ROTATION)
    elseif IsNull(agent) then
        mCollected = 0
        mTimerMgr:AddTimer(2, function() mGameRules:RespawnPlayer(mPlayer, false) end)
    end
end

local PRIMARY_ONLY = 1
local SECONDARY_ONLY = 2
local MELEE_ONLY = 3

local function SetRestriction(restrictionType)
    local inv = mPlayerAv:InventoryControl()
        
    local ammoType = nil

    if restrictionType == PRIMARY_ONLY then
        Broadcast("Primary")
        inv:GetActivePowerSuit():SetAbilityIdentifiersBlocked(true)
        inv:SetWeaponDisabled(Engine.SLOT_1)
        inv:SetWeaponEnabled(Engine.SLOT_2)
        inv:SetWeaponDisabled(Engine.SLOT_6)
        
        local weap = inv:GetWeaponInSlot(Engine.SLOT_2)
        ammoType = weap:GetAmmoExType()
        weap:SetAmmoInClip(weap:GetClipSize())
        
    elseif restrictionType == SECONDARY_ONLY then
        Broadcast("Secondary")
        inv:GetActivePowerSuit():SetAbilityIdentifiersBlocked(true)
        inv:SetWeaponEnabled(Engine.SLOT_1)
        inv:SetWeaponDisabled(Engine.SLOT_2)
        inv:SetWeaponDisabled(Engine.SLOT_6)
        
        local weap = inv:GetWeaponInSlot(Engine.SLOT_1)
        ammoType = weap:GetAmmoExType()
        weap:SetAmmoInClip(weap:GetClipSize())
        
    elseif restrictionType == MELEE_ONLY then
        Broadcast("Melee")
        inv:GetActivePowerSuit():SetAbilityIdentifiersBlocked(true)
        inv:SetWeaponDisabled(Engine.SLOT_1)
        inv:SetWeaponDisabled(Engine.SLOT_2)
        inv:SetWeaponEnabled(Engine.SLOT_6)
        
    end
    
    inv:EquipBestWeapon(false, true)
end

local function SpawnDelay()
    if mAiDir:GetLiveAICount() < MAX_SPAWN then
        mEximusToSpawn = 1
        mNumAgentsToSpawn = RandomInt(MIN_SQUAD_SIZE, MAX_SQUAD_SIZE)
    end
end

local function UpdateModifiers(delta)
    if not IsNull(mPlayerAv) then
        mDamageModifier = 1.0 + (mCollected * DAMAGE_MODIFIER_PER_ITEM)
        mPlayerAv:DamageControl():AddShieldHealthDamageModifier(sModifier, Engine.DT_ANY, Engine.ANY_PART, Engine.DHT_NONE, mDamageModifier)
    end
    
    mEnemyLevelScale = 1 * (mTimeElapsed * ENEMY_SCALE)
    mAiDir:SetEnemyLevelMinMax(mEnemyMinLevel + mEnemyLevelScale, mEnemyMaxLevel + mEnemyLevelScale)
end

local function CollectedItemLocal(isLargeItem)
    if isLargeItem then
        mCollected = mCollected + LARGE_ITEM_VALUE
    else
        mCollected = mCollected + SMALL_ITEM_VALUE
    end
end

local function BankItemsLocal()
    mBanked = mBanked + mCollected
    
    if mBanked < NUM_TO_BANK then
        _T.ShowImpactMessage(Localize(bankedPointsLoc, {COUNT = mCollected}), 3)
    end
    mCollected = 0
end

local function UpdateSpawning()
    local agent = nil
    local fx = nil
    if mEximusToSpawn > 0 then
        mEximusToSpawn = mEximusToSpawn - 1
        agent = mAiDir:CreateRandomAgent(nil, sRandomTeam, 0, nil, Engine.EXIMUS)
        fx = eximusEnemyProjectorFX
    elseif mNumAgentsToSpawn > 0 then
        mNumAgentsToSpawn = mNumAgentsToSpawn - 1
        agent = mAiDir:CreateRandomAgent(nil, sRandomTeam, 0, nil, Engine.STANDARD)
        fx = enemyProjectorFX
    end
    
    if not IsNull(agent) then
        local avatar = agent:GetAvatar()
        CROOM.SetupEnemy(avatar, spawnEffect, fx)
        ObjectPortHandler(avatar, "OnKilled")
        table.insert(mAgents, agent)
    end
end

function RunChallenge()
    collectibleLargeType = collectibleLargeType 
    
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    mPlayer = gRegion:GetLocalPlayer()
    mPlayerAv = mPlayer:GetAvatar()
    ObjectPortHandler(mPlayerAv, "OnKilled")
    
    mPlayer:AddTimerOfInterest(sTimer)
    mCollectibleSpawnPoints = gRegion:FindTagged(sCollectible)
    mCollectibleLargeSpawnPoints = gRegion:FindTagged(sCollectibleLarge)
    mBankAction = gRegion:FindFirstTagged(sBankAction)
    mHudStatus = mPlayer:GetHudStatus()
    
    mGameRules:SetSaveMatchStatsDisabled(true)
    mGameRules:SetShowReviveScreenOnDeath(false)
    
    mAiDir:Enable(true)
    mAiDir:SetLevelAlert(true)
    mAiDir:SetObjective(mPlayerAv)
    mAiDir:SetEnemyLevelMinMax(25,30)
    mAiDir:SetCustomSpawnSelectionFilter(10, 100, 0, 5, false, false, false)
    mAiDir:SetUseCustomSpawnSelectionFilter(true)
    mAiDir:SetEnableAutoSpawns(false)
    local aiList = mGameRules:GetMissionAI()
    if IsNull(aiList) then
        aiList = backupAiSpec:GetEnemies()
    end
    
    for i, enemy in ipairs(aiList) do
        mAiDir:AddMissionAIType(enemy.agent, enemy.probability, enemy.maxSimultaneous, enemy.tier)
    end
    
    mTimerMgr:AddTimer(SPAWN_TIME, SpawnDelay, true)
    
    _T.CollectedItem = CollectedItemLocal
    _T.BankItems = BankItemsLocal
    
    mEnemyMinLevel = mAiDir:GetMinEnemyLevel()
    mEnemyMaxLevel = mAiDir:GetMaxEnemyLevel()
    
    SetState(COLLECT_STAGE_A)
    
    while true do
        mTimerMgr:Update(DeltaTime())
        
        if IsNull(mPlayerAv) then
            mPlayerAv = mPlayer:GetAvatar()
            ObjectPortHandler(mPlayerAv, "OnKilled")
        end
        
        if mGameRules:GetMissionTimeLeft(sTimer) <= 0 then
            SetState(FAILED)
        end
        
        mTimeElapsed = mTimeElapsed + DeltaTime()
        
        UpdateSpawning()
        UpdateModifiers(DeltaTime())
        UpdateTrackers()
    
        if mState == COLLECT_STAGE_A then
            if mBanked >= NUM_TO_BANK / 3 then
                SetState(COLLECT_STAGE_B)
            end
            
        elseif mState == COLLECT_STAGE_B then
            if mBanked >= NUM_TO_BANK / 3 * 2 then
                SetState(COLLECT_STAGE_C)
            end
            
        elseif mState == COLLECT_STAGE_C then
            if mBanked >= NUM_TO_BANK then
                SetState(COMPLETE_OBJECTIVE)
            end
            
        elseif mState == COMPLETE_OBJECTIVE then
            for i, agent in ipairs(mAgents) do
                if not IsNull(agent) then
                    agent:GetAvatar():Destroy()
                end
            end
            LOTUS_UTIL.OnChallengePassed(mPlayerAv, kneelAnim, endMissionTrans, endMissionMovie, endMissionDialog)
            return
            
        elseif mState == FAILED then
            CROOM.ChallengeFailed()
            mPlayerAv:GiveItem(failMissionTrans, true)
            return
        end
        
        Sleep(0)
    end
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end

function CollectedItem()
    _T.CollectedItem(isLarge)
end

function BankItems()
    _T.BankItems()
end
