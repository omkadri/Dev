tags = {Symbol()}


function MatchTagEvent(player, tag)
    if tag and tag ~= "" then
        for i=1,#tags do
            if tag == tags[i]:c_str() then
                return true
            end
        end
    end

    return false
end
