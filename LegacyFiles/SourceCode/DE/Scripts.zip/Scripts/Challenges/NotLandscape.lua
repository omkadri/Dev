function MatchTagEvent(player, tag)
    return gGameRules:GetMission().missionType ~= Lotus_Game.MT_LANDSCAPE
end
