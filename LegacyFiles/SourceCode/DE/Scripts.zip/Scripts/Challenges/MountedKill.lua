dropshipTypes = { WeakResource() }

function MatchAttackEvent(scriptDamageData, player)
    local victim = scriptDamageData:GetVictim()
    local parent = victim:GetAttachParent()
    
    if IsNull(parent) then
        return false
    end
    
    for _, shipType in ipairs(dropshipTypes) do
        if parent:IsA(shipType) then
            return true
        end
    end
    
    return false
end
