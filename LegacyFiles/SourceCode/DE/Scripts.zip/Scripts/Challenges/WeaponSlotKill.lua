-- Only considers kills done with a weapon from a specified slot

weaponSlot = Engine.SLOT_1

-- if true, won't use the actual item in the slot to match attack events. Will only check the slotted item to determine if this challenge is ok to use.
-- this lets "melee kills" still count for power melee weapons like exalted blade or hysteria
checkSlotForPreconditionOnly = false 

ignoredWeaponTypes = { WeakResource() }

local initialWeaponsRetrieved = false
local weaponObj = nil

local function _IsIgnored(obj)
    for i = 1, #ignoredWeaponTypes do
        if obj:IsA(ignoredWeaponTypes[i]) then
            return true
        end
    end
    return false
end

function CheckPreconditions(player)
    local av = player:GetAvatar()
    if IsNull(av) then
        return false 
    end

    -- hack for archwing missions: your archwing inventory is given *after* this script is called
    local missionInfo = gGameRules:GetMission()
    if missionInfo.archwingRequired then
        if weaponSlot == Engine.SLOT_1 then
            return false -- archwing has no secondary
        end
        
        return true -- can't unequip primary or melee in archwing
    else
        local weapon = av:InventoryControl():GetWeaponInSlot(weaponSlot)
        return not IsNull(weapon)
    end
end

function Update(player, delta)

    if checkSlotForPreconditionOnly then
        return 0.0
    end

    if (not initialWeaponsRetrieved or IsNull(weaponObj)) and not IsNull(player) then
        local avatar = player:GetAvatar()
        if IsNull(avatar) then
            return 0.0
        end
        local ic = avatar:InventoryControl()
        if ic == nil or IsNull(ic) then
            return 0.0
        end

        weaponObj = ic:GetWeaponInSlot(weaponSlot)
        if IsNull(weaponObj) then
            if not initialWeaponsRetrieved then
                print("Could not find weapon in specified slot ("..tostring(weaponSlot)..")")
            end
        else
            if _IsIgnored(weaponObj) then
                weaponObj = nil
            end
        end

        initialWeaponsRetrieved = true
    end
    
    return 0.0
end

function MatchAttackEvent(scriptDamageData, player)
    if checkSlotForPreconditionOnly then
        return true
    end

    local sourceObject = scriptDamageData:GetSourceObject()
    
    if not IsNull(sourceObject) then
        if sourceObject:IsA(gProjectileType) then
            sourceObject = sourceObject:GetInstigatorItem()
        end
    
        if sourceObject == weaponObj then
            return true
        end
    end

    return false
end
