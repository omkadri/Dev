consoleTag = Symbol()

function CheckPreconditions()
    local missionType = gGameRules:GetMissionType()
    
    -- excluded in Survival, Hijack, and Defection because those mission types require you to hack a console just to get started, so you'd get this done basically for free
    -- other mission types like spy or void sabotage require hacking consoles too, but at least you have to work to get to them
    if missionType == Lotus_Game.MT_SURVIVAL or 
       missionType == Lotus_Game.MT_RETRIEVAL or 
       missionType == Lotus_Game.MT_EVACUATION or
       missionType == Lotus_Game.MT_RAID then
        return false
    end

    -- maybe check to see if there
    local console = gRegion:FindFirstTagged(consoleTag)
    if not IsNull(console) then
        return true
    end

    return false
end