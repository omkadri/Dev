matchObjectTypes = {WeakResource()}
matchAttachParent = false
instanceTrackingBucket = Symbol()


function MatchTagEvent(player, tag, howMany, object)
    if IsNull(object) then
        return false
    end
    
    if matchAttachParent then
        local attachParent = object:GetAttachParent()
        if not IsNull(attachParent) then
            object = attachParent
        end
    end
    
    for i=1,#matchObjectTypes do
        if object:IsA(matchObjectTypes[i]) then
            if instanceTrackingBucket:IsValid() then
                local bucket = instanceTrackingBucket:c_str()
                local globalTable = _T.ChallengeMatchObjectTypes or {}
                _T.ChallengeMatchObjectTypes = globalTable
                local instanceTracking = globalTable[bucket] or {}
                globalTable[bucket] = instanceTracking
                
                for j=#instanceTracking,1,-1 do
                    local instance = instanceTracking[j]
                    if IsNull(instance) then
                        table.remove(instanceTracking, j)
                    elseif instance == object then
                        return false
                    end
                end
                
                table.insert(instanceTracking, object)
            end
            
            return true
        end
    end
    
    return false
end