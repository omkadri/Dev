periodicMissionTag = Symbol()


function MatchTagEvent(player, tag)
    return not IsNull(gGameRules) and gGameRules:GetMission().periodicMissionTag == periodicMissionTag
end
