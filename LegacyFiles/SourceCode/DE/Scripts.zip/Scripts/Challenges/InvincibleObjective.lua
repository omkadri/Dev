startTag = Symbol()
endTag = Symbol()

local function GetRecordName()
    return (tostring(startTag) .. tostring(endTag))
end

function MatchAttackEvent(scriptDamageData, player)
    local recordName = GetRecordName()
    if _T[recordName] == true then
        _T[recordName] = nil
    end
    return false
end

function MatchTagEvent(player, tag)
    if tag == tostring(startTag) then
        local recordName = GetRecordName()
        _T[recordName] = true
    elseif tag == tostring(endTag) then
        local recordName = GetRecordName()
        if _T[recordName] == true then
            _T[recordName] = nil
            return true
        end
        _T[recordName] = nil
    end
    return false
end