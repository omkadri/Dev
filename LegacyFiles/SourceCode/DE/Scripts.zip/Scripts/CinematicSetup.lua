GrineerShipMeshes = {WeakResource()}
GrineerAssMeshes = {WeakResource()}
GrineerOceanMeshes = {WeakResource()}
CorpusShipMeshes = {WeakResource()}
InfestedShipMeshes = {WeakResource()}
DerelictShipMeshes = {WeakResource()}
VoidShipMeshes = {WeakResource()}

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

function ShipSetup()
    local players = gRegion:GetHumanPlayers()
    local tempLabels = { Symbol("Player1"), Symbol("Player2"), Symbol("Player3"), Symbol("Player4"), Symbol("Player5"), Symbol("Player6"), Symbol("Player7"), Symbol("Player8") }

    local allShips = {}
    for x=1,#tempLabels do
        local liset = gRegion:FindTagged(tempLabels[x])
        if not IsNull(liset) then
            liset[1]:SetVisibility(false, true)
            table.insert(allShips, liset[1])
        end
    end

    -- We want the ships with customizations go first    
    table.sort(allShips,
        function(a, b)
            local aHasRes = not IsNull(a:GetShipItemRes())
            local bHasRes = not IsNull(b:GetShipItemRes())

            if aHasRes ~= bHasRes then
                if aHasRes then
                    return true
                else
                    return false
                end
            end

            return a:GetInstance() < b:GetInstance()
        end)

    local MAX_PLAYERS = 8
    local numPlayers = 0

    for k,v in ipairs(players) do
        if numPlayers < MAX_PLAYERS and not IsNull(v) and v:GetPlayerName() ~= LOTUS_UTIL.HIDDEN_PLAYER_NAME then
            numPlayers = numPlayers + 1
        end
    end
    
    for x=1,numPlayers do
        local liset = allShips[x]
        if not IsNull(liset) then
            liset:SetVisibility(true, true)
        end
    end

    local firstCinematic = gRegion:GetPlayingCinematic()
    local waitingToStart = IsNull(firstCinematic)
    local cinematicPlaying = (not waitingToStart)
    while waitingToStart or cinematicPlaying do
        if waitingToStart then
            firstCinematic = gRegion:GetPlayingCinematic()
            waitingToStart = IsNull(firstCinematic)
        end

        if not waitingToStart then
            local newCinematic = gRegion:GetPlayingCinematic()
            cinematicPlaying = (not IsNull(newCinematic))
            if newCinematic ~= firstCinematic then
                break
            end
        end

        Sleep(0.0)
    end

    for i, v in ipairs(allShips) do
        if not IsNull(v) then
            v:StopAllSounds()
        end
    end
end


function FactionShipSetup(entity)
--  local temp = RandomInt(1, #ShipMeshes)
--  entity:SetMesh(ShipMeshes[temp],false,false)

    local levelName = gRegion:GetLevel():GetFullName()

    print("Level="..tostring(levelName))

    -- Choose ship first
    local shipMesh = nil
    if string.find(levelName, "Derelict") ~= nil then
        local temp = RandomInt(1, #DerelictShipMeshes)
        shipMesh = DerelictShipMeshes[temp]
    elseif string.find(levelName, "Infested") ~= nil then
        local temp = RandomInt(1, #InfestedShipMeshes)
        shipMesh = InfestedShipMeshes[temp]
    elseif string.find(levelName, "GrineerAsteroid") ~= nil then
        local temp = RandomInt(1, #GrineerAssMeshes)
        shipMesh = GrineerAssMeshes[temp]
    elseif string.find(levelName, "Ocean") ~= nil then
        local temp = RandomInt(1, #GrineerOceanMeshes)
        shipMesh = GrineerOceanMeshes[temp]
    elseif string.find(levelName, "Grineer") ~= nil then
        local temp = RandomInt(1, #GrineerShipMeshes)
        shipMesh = GrineerShipMeshes[temp]
    elseif string.find(levelName, "Corpus") ~= nil then
        local temp = RandomInt(1, #CorpusShipMeshes)
        shipMesh = CorpusShipMeshes[temp]
    elseif string.find(levelName, "OrokinTower") ~= nil then
        local temp = RandomInt(1, #VoidShipMeshes)
        shipMesh = VoidShipMeshes[temp]
    end

    if IsNull(shipMesh) then
        print("FactionShipSetup - No mesh")
        return
    end

    local loader = UISys.ScriptResLoader_Create({shipMesh:GetFullName() })
    local timeElapsed = 0.0
    while not IsNull(loader) and not loader:IsDone() do
        Sleep(0.0)
        timeElapsed = timeElapsed + RealDeltaTime()
    end
    
    local shipMeshStrong = Resource(shipMesh)

    if timeElapsed < 1 then
        Sleep(1 - timeElapsed)
    end
    
    if not IsNull(entity) and not IsNull(shipMeshStrong) then
        entity:SetMesh(shipMeshStrong, false, false)
        entity:RemoveAllOverrideMaterials(false)
    end
end


