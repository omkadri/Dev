objectTable = {Instance()}
dissolveTime = 1

local function _DissolveIn(objects)

    local numObjects = #objects

    if dissolveTime > 0 then
        for i=1,numObjects do
            local object = objects[i]
            if not IsNull(object) then
                object:SetDissolve(1)
            end
        end

        local t = 0
        while t < 1 do
            Sleep(0)
            t = t + DeltaTime() / dissolveTime
            for i=1,numObjects do
                local object = objects[i]
                if not IsNull(object) then
                    object:SetDissolve(Clamp(1 - t, 0, 1))
                end
            end
        end
    end
    
    for i=1,numObjects do
        local object = objects[i]
        if not IsNull(object) then
            object:SetDissolve(0)
        end
    end

end

local function _DissolveOut(objects)

    local numObjects = #objects
    
    if dissolveTime > 0 then
        for i=1,numObjects do
            local object = objects[i]
            if not IsNull(object) then
                object:SetDissolve(0)
            end
        end

        local t = 0
        while t < 1 do
            Sleep(0)
            t = t + DeltaTime() / dissolveTime
            for i=1,numObjects do
                local object = objects[i]
                if not IsNull(object) then
                    object:SetDissolve(Clamp(t, 0, 1))
                end
            end
        end
    end
    
    for i=1,numObjects do
        local object = objects[i]
        if not IsNull(object) then
            object:SetDissolve(1)
        end
    end

end

function DissolveIn()
    _DissolveIn(objectTable)
end

function DissolveOut()
    _DissolveOut(objectTable)
end

function Start()

    _DissolveIn(objectTable)

end

function LoopingDissolve()

    while true do
        _DissolveIn(objectTable)
        _DissolveOut(objectTable)
        Sleep(0)
    end
    
end

function ResetDissolve()
    for i, object in ipairs(objectTable) do
        if not IsNull(object) then
            object:SetDissolve(0)
        end
    end
end