

function RandomCapitalShip(deco)

    while true do
    
        Sleep(0.0)
    end

end
