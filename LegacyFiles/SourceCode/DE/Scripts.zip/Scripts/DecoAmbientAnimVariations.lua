IdleAnim = Resource()
VariationAnims = {Resource()}
minTimeBetweenVariations = 5
maxTimeBetweenVariations = 10

function PlayIdleVariations(self)

    while true do
        self:PlayAnimation(IdleAnim, false, true)
        
        local timeToWait = Random(minTimeBetweenVariations, maxTimeBetweenVariations)
        Sleep(timeToWait)

        local selectedAnim = RandomInt(1, #VariationAnims)
        if not IsNull(VariationAnims[selectedAnim]) then
            self:PlayAnimation(VariationAnims[selectedAnim], true)
        end
    end    
end
