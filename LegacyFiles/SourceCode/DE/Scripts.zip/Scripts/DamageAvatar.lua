damageAmount = 0

function applyDamageToAvatar(avatar)
    avatar:Damage(damageAmount)
end