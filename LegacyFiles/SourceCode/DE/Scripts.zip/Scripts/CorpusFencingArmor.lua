
openPose = Resource()
closePose = Resource()

hideIfForearmWeapon = false

largeWarframes = { WeakResource() }

local MIN_UNLIT_ATTEN = 0.5
local MAX_UNLIT_ATTEN = 4.0
local FADE_RATIO = 3.0
local FLICKER_FADE = 16.0

local ACTIVE_TIME = 5.0

local OPEN_STATE_CLOSE_TIME = 4

local chanOffParamValues = {0.08, -0.32, 1, 1}
local chanOnParamValues = {0.28, 0.52, 1.5, 1.5}
local chanParam = Symbol("RipplePan")

local function GetIdentifier(suitAttachment, avatar)
    return(suitAttachment:GetName() .. avatar:GetInstance())
end

function Init(suitAttachment, avatar)
    if IsNull(suitAttachment) or IsNull(avatar) or (not avatar:IsA(gAvatarType)) or avatar:IsKilled() then
        return
    end

    local identifier = GetIdentifier(suitAttachment, avatar)
    _T[identifier] = {wasActive = false, closeDelay = 0, targetAtten = MIN_UNLIT_ATTEN, timer = 0.0, sliding = false}
    
    suitAttachment:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, MIN_UNLIT_ATTEN)
    
    if gGameRules:IsA(gLotusHubGameRulesType) then
        return
    end
    
    local atten = MIN_UNLIT_ATTEN
    local damagecontroller = avatar:DamageControl()
    local wasMeleeEquipped = false
    local wasMeleeing = false
    local wasChanneling = false
    
    local nextFlicker = -1.0
    local flickerOn = false
    local flickerAtten = MIN_UNLIT_ATTEN
    local flare = suitAttachment:GetAttachment(gLensFlareType)
    
    while true do
        local visible = suitAttachment:IsVisible()
        if nextFlicker < 0.0 then
            nextFlicker = Random(0.2, 8.0)
        end
        
        if not flickerOn then
            nextFlicker = nextFlicker - DeltaTime()
            flickerAtten = math.max(flickerAtten - DeltaTime() * FLICKER_FADE, MIN_UNLIT_ATTEN)
            
            if nextFlicker < 0.0 then
                flickerOn = true
            end
        else
            flickerAtten = math.min(flickerAtten + DeltaTime() * FLICKER_FADE, MAX_UNLIT_ATTEN)
            if flickerAtten == MAX_UNLIT_ATTEN then
                flickerOn = false
            end
        end
        
        if avatar:HasPostureModifier(Engine.PM_AIM) then
            flickerAtten = MIN_UNLIT_ATTEN
        end
        
        local meleeWeapon = avatar:InventoryControl():GetMeleeWeapon()
        local parrying = not IsNull(meleeWeapon) and meleeWeapon:IsParrying()
        local channeling = not IsNull(meleeWeapon) and meleeWeapon:GetChanneling()
        local meleeing = avatar:InventoryControl():IsMeleeing()
        local meleeEquipped = not IsNull(meleeWeapon) and (avatar:InventoryControl():GetWeaponInHand(Engine.MAIN_HAND) == meleeWeapon)
        
        if (meleeEquipped and not wasMeleeEquipped) or (meleeing and not wasMeleeing) or parrying or channeling then
            _T[identifier].timer = ACTIVE_TIME
        end
        
        if channeling and not wasChanneling then
            suitAttachment:SetMaterialParam(chanParam, chanOnParamValues[1], chanOnParamValues[2], chanOnParamValues[3], chanOnParamValues[4])
        end
        
        if not channeling and wasChanneling then
            suitAttachment:SetMaterialParam(chanParam, chanOffParamValues[1], chanOffParamValues[2], chanOffParamValues[3], chanOffParamValues[4])
        end
        
        wasMeleeing = meleeing
        wasMeleeEquipped = meleeEquipped
        wasChanneling = channeling
        
        if _T[identifier].timer > 0 and damagecontroller:GetShield() > 0 then
            atten = MAX_UNLIT_ATTEN
            
            if channeling then
                atten = MAX_UNLIT_ATTEN + 2.0
            end
            
            if not _T[identifier].wasActive then
                -- Play the open animation
                suitAttachment:PlayAnimation(openPose, false, false)
                _T[identifier].wasActive = true
            end
            
            
            _T[identifier].timer = _T[identifier].timer - DeltaTime()
        else
            _T[identifier].timer = 0
            
            if _T[identifier].wasActive then
                -- Start the delay for the close anim
                _T[identifier].wasActive = false
                _T[identifier].closeDelay = OPEN_STATE_CLOSE_TIME
            elseif _T[identifier].closeDelay > 0 then
                _T[identifier].closeDelay = _T[identifier].closeDelay - DeltaTime()
                if _T[identifier].closeDelay < 0 then
                    -- Play the close animation
                    suitAttachment:PlayAnimation(closePose, false, false)
                end
            end
            
            atten = math.max(atten - DeltaTime() * FADE_RATIO, MIN_UNLIT_ATTEN)
        end
        
        suitAttachment:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, math.max(flickerAtten, atten))
        if not IsNull(flare) then
            flare:SetOpacity(math.min(1, math.max(flickerAtten, atten)))
        end

        if hideIfForearmWeapon then
            local shouldBeVisible = true
            local mainHandWeapon = avatar:InventoryControl():GetWeaponInHand(Engine.MAIN_HAND)
            if not IsNull(mainHandWeapon) then
                if mainHandWeapon:GetGripType() == Engine.GUN_ONE_HAND and mainHandWeapon:GetAnimWeaponType() == Engine.WEAPONTYPE_PORTABLE_SCANNER then
                    shouldBeVisible = false
                end
            end

            if visible ~= shouldBeVisible then
                suitAttachment:SetVisibility(shouldBeVisible)
            end
        end
        
        Sleep(0)
    end
end

function OnDamaged(suitAttachment, avatar)
    if IsNull(suitAttachment) or IsNull(avatar) then
        return
    end

    local identifier = GetIdentifier(suitAttachment, avatar)
    if _T[identifier] ~= nil then
        _T[identifier].timer = ACTIVE_TIME
    end
end

function HideWhenAiming(deco)
    local avatar = deco:GetAttachParent()
    if IsNull(avatar) or not avatar:IsA(gLotusAvatarType) or not avatar:ReplicaLocallyControlled() then
        return
    end
    
    local suit = avatar:InventoryControl():GetActivePowerSuit()
    local isLarge = false
    if not IsNull(suit) then
        for i=1, #largeWarframes do
            if suit:IsA(largeWarframes[i]) then
                isLarge = true
                break
            end
        end
    end
    if not isLarge then
        return
    end
    local dissolve = 0
    while not IsNull(deco) and not IsNull(avatar) do
        if avatar:HasPostureModifier(Engine.PM_AIM) then
            dissolve = math.min(dissolve + DeltaTime() * 4, 1)
        else
            dissolve = math.max(dissolve - DeltaTime() * 4, 0)
        end
        deco:SetDissolve(dissolve)
        Sleep(0)
    end
end