
deathFx = Type()
avatarType = Type()
ragdollType = Type()
hitProxyPhysicsType = Type()

excludedAvatarTypes = { WeakResource() }

function Dissolve(entity)
    if IsNull(entity) or IsNull(entity:GetInstigator()) or not entity:GetInstigator():ReplicaLocallyControlled() then
        return
    end
    
    Sleep(0)
    local hitEntity = entity:GetLastHitAvatar()
    if IsNull(hitEntity) then
        return
    end
    
    local avatar = nil
    local ragdoll = nil
    
    if hitEntity:IsA(avatarType) then
        avatar = hitEntity
    elseif hitEntity:IsA(ragdollType) then
        ragdoll = hitEntity
    elseif hitEntity:IsA(hitProxyPhysicsType) then
        ragdoll = hitEntity:GetRagdoll()
    end
    
    if not IsNull(ragdoll) then
        avatar = ragdoll:GetAvatarOwner()
    end
    
    if IsNull(avatar) then
        return
    end
    
    for i=1, #excludedAvatarTypes do
        if avatar:IsA(excludedAvatarTypes[i]) then
            return
        end
    end
    
    local Instigator = entity:GetInstigatorItem()--gross hack need to rearrange fx 
    local creator = Instigator:GetOwner()
    
    local maxDamage = creator:InventoryControl():GetUpgradeModifiedValue(75, Game.WEAPON_DAMAGE_AMOUNT, Instigator:GetType(), Instigator)
    

    local d = 0.0
    local dissolveTime = 4
    local damage = maxDamage / dissolveTime
    
    local ragdoll
    
    -- deal damage over time
   -- if not avatar:IsKilled() then
    --   local dd = Engine.DamageData()
     --   dd.baseAmount = damage
     --   dd:SetDamagePct(Engine.DT_POISON, 1.0)
    --    dd:SetSource(creator)
     --   dd:SetSourceObject(Instigator)
     --   dd:SetHitPart(Engine.TORSO)
        
     --   avatar:DamageControl():DOT(dd, dissolveTime, 1.0)
 --  end
    
    while not IsNull(avatar) and not avatar:IsKilled() and d <= dissolveTime do
        ragdoll = avatar:GetRagdoll()
        
        if avatar:IsKilled() then
            if IsNull(ragdoll) then
                avatar:Attach(deathFx, EMPTY_SYMBOL)
            else
                ragdoll:Attach(deathFx, EMPTY_SYMBOL)
            end
            break
        end
        
        Sleep(0)
        d = d + DeltaTime() 
    end
    
    -- if dead, start dissolving
    if not IsNull(avatar) and avatar:IsKilled() then
        avatar:SetMaterialParam(Symbol("CloakHDR"), 10, 10, 0, 0)
        avatar:SendStartDissolve(dissolveTime)
    end
end