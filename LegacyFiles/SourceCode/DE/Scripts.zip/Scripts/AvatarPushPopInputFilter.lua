inputFilter = Resource()


function AvatarPushInputFilter(avatar)
    if not IsNull(avatar) and avatar:IsA(gTennoAvatarType) then
        avatar:PushInputFilter(inputFilter)
    end
end

function AvatarPopInputFilter(avatar)
    if not IsNull(avatar) and avatar:IsA(gTennoAvatarType) then
        avatar:PopInputFilter(inputFilter)
    end
end