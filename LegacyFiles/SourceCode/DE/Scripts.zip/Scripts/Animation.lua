anim = Resource()
tempAvatar = Type()
deco = Type()
offSet = Vector()
rot = Rotation()
bone = Symbol()
Cin = Instance()
Music = Instance()
SpawnA = Instance()
ScriptTrigger = Instance()
FadeScriptTrigger = Instance()
shuttleType = Type()
entityType = Type()
isVisible = true
PlayerInputFilter = Type()
waitForSpawn = false
localOnly = true
GrineerType = Type()
entityInstance = Instance()
cameraSpot = Instance()
StartRate = 0.0
EndRate = 1.0
Duration = 1.0

--[[
    only works if triggered from something that passes in the agent!
        A context action?
--]]
function PlayIdleAnimation(agent)
    local avatar = agent:GetAvatar()
    if not IsNull(agent) then
        while true do
            avatar:PlayAnimation(anim, true, Engine.ATMM_ANIMATION_DRIVEN)      
            Sleep(0)
        end
    end
end

--[[
    only works if triggered from something that passes in the agent!
        A context action?
--]]
function PlayTriggeredAnimation(trigger, avatar)
    if not IsNull(avatar) then  
        avatar:PlayAnimation(anim, true, Engine.ATMM_ANIMATION_DRIVEN)
        Sleep(0)
    end
end

function AttachDeco()
    if not IsNull(deco) then
        local avatars = gRegion:FindAll(tempAvatar)
        print("Attach Deco to all "..tempAvatar:GetName())
        if not IsNull(avatars) then 
            local tempDeco = avatars[1]:GetAttachment(deco)
            if not IsNull(tempDeco) then
                print("Avatar "..avatars[1]:GetFullName().." already has deco "..deco:GetName().." attached")
            else
                print("Attaching deco "..deco:GetName().." to avatar "..avatars[1]:GetFullName())
                avatars[1]:Attach(deco, bone, offSet, rot, localOnly) 
            end
        end
    end
end

function RemoveDeco()
    local avatars = gRegion:FindAll(tempAvatar)
    if not IsNull(avatars) then 
        local tempDeco = avatars[1]:GetAttachment(deco)
        if not IsNull(tempDeco) then
            print("Removing deco: "..tempDeco:GetFullName().." from avatar "..avatars[1]:GetFullName())
            tempDeco:Destroy()
        end
    end
end

function GastoBridge()
    local gameRules = gGameRules
    local Tenno = gameRules:GetTenno()
    local TennoAlt = gameRules:GetTennoAlt()
    local x = 0
    Tenno:DamageControl():SetDazeDuration(6000) 
    while true do
        x = 0
        if Tenno:HasPostureModifier(Engine.PM_PARALYZED) or Tenno:HasPostureModifier(Engine.PM_STUN) then
            Tenno:RequestFrameUpdates(0.5)
            x = 1
        end
        if IsNull(TennoAlt) == false then   
            if TennoAlt:IsPreDeath() == true or TennoAlt:HasPostureModifier(Engine.PM_PARALYZED) then
                TennoAlt:RequestFrameUpdates(0.5)
                --x = x + 1
            end
        end
        if x == 1 then
            if not IsNull(ScriptTrigger) then
                ScriptTrigger:FirePort("Execute")
            end
            
            local avatarList = gRegion:GetAvatars()
            if not IsNull(avatarList) then
                for i = 1, #avatarList do
                    local avatar = avatarList[i]
                    if not IsNull(avatar) then
                        if avatar:IsA(GrineerType) then
                            local agent = avatar:GetAgent()
                            if IsNull(agent) == false then
                                agent:ClearTarget()
                                agent:SetEnginePaused(true, Symbol("ANIMATION"))
                            end
                        end
                    end
                end
            end
                                
            Music:FirePort("Disable")
            gameRules:RequestSlomo()
            break
        end
        Sleep(0)
    end
    
    Tenno:DamageControl():SetDazed(false)
    TennoAlt:DamageControl():SetDazed(false)    
    Tenno:DestroyAgent()
    if not IsNull(TennoAlt) then        
        TennoAlt:DestroyAgent()
    end
    
    Sleep(2)
    
    if not IsNull(FadeScriptTrigger) then
        FadeScriptTrigger:FirePort("Execute")
    end
    
    gameRules:CancelSlomo()
    Sleep(2)
    
    Cin:FirePort("StartPlaying")
    Sleep(1)
    Tenno:Revive(Tenno:GetMaxHealth())
    TennoAlt:Revive(TennoAlt:GetMaxHealth())
    
end

function FadeOutAndIn()
    local levelInfo = gRegion:GetLevelInfo()
    for i=0, Engine.SSID_MaxNumPlayers - 1 do
        levelInfo:GetPostProcessInfo(i).fade = 1
    end
    Sleep(3)
    for i=0, Engine.SSID_MaxNumPlayers - 1 do
        levelInfo:GetPostProcessInfo(i).fade = 0
    end
end

function GrineerAmbust()
    local gameRules = gGameRules
    local Tenno = gameRules:GetTenno()
    
    while true do
        local camFacing = Tenno:GetCameraView()
        local direction = AngleToDirection(camFacing)
        local inFront = Tenno:GetPosition() + direction * 4.0

        SpawnA:SetPosition(inFront)
        --SpawnB:SetPosition(TempPosB)
        Sleep(0)
    end
end


function ChangeAvatars()

    local rules = gGameRules
    local shuttle = gRegion:FindAll(shuttleType) 
    
    local localAvatars = gRegion:GetLocalPlayerAvatars()
    
    local humanPlayers = gRegion:GetHumanPlayers()
    
    for i = 1, #localAvatars do
        local avatar = localAvatars[i]
        -- if 2 players, get the one that is controlling Tenno
        if #humanPlayers == 2 then
            avatar = rules:GetTenno()
        end
        if IsNull(avatar) then
            print("ERROR: avatar type is null, bad things will happen when you try and switch bad");
        end
        for x = 1, #humanPlayers do
            local avatarTemp = humanPlayers[x]:GetAvatar()
            if avatarTemp == avatar then
                _T.ShuttlingAvatar = avatar;
                humanPlayers[x]:ControlAvatar(shuttle[1], true)
                _T.ShuttlingPlayer = x
            end
        end
    end     
end
    
function ChangeAvatarBack()
    local players = gRegion:GetHumanPlayers()
    local humanplayerindex = _T.ShuttlingPlayer
    if humanplayerindex == nil then
        return;
    end
    
    for i = 1, #players do
        local prevAvatar = nil
        if players[i]:GetAvatar():IsA(shuttleType) then
             prevAvatar = players[i]:GetPreviousControlledAvatar()
             if IsNull(prevAvatar) then
                prevAvatar = _T.ShuttlingAvatar
                print("This probably should not happen, our player has no previous avatar");
                print("Defaulting to the saved shuttle avatar");
             end
             if not IsNull(prevAvatar) then
                players[i]:ControlAvatar(prevAvatar)
                
                 if not IsNull(PlayerInputFilter) then
                    prevAvatar:PushInputFilter(PlayerInputFilter)
                 end
             else
                print("ERROR: trying to switch player back to a null value")
             end
        end
    end
end

function ChangeVisibility()
    local entity = gRegion:FindAll(entityType)
    if not IsNull(entity) and not IsNull(entity[1]) then 
        entity[1]:SetVisibility(isVisible, true)
    end
end

function Destroy()
    local entity = gRegion:FindAll(entityType)
    if not IsNull(entity) and not IsNull(entity[1]) then 
        print("Destroying entity: "..entity[1]:GetName())
        entity[1]:Destroy()
    end
end

function DestroyInstance()
    if IsNull(entityInstance) then
        print("Tried to destroy null instance!")
        return
    end
    
    print("Destroying entity: "..entityInstance:GetName())
    entityInstance:Destroy()
end

function HideTennoAndTennoAltAvatars()
    local gameRules = gGameRules
    local Tenno = nil
    repeat
        Tenno = gameRules:GetTenno()
        if IsNull(Tenno) and waitForSpawn then
            Sleep(0)
        end     
    until not IsNull(Tenno) and waitForSpawn or not waitForSpawn
    
    print("INFO: HIDING Tenno AVATAR")
    
    if not IsNull(Tenno) then
        print("Tenno WAS NOT NULL")
        Tenno:SetVisibility(false, true)
    end
    
    local TennoAlt = nil
    repeat
        TennoAlt = gameRules:GetTennoAlt()
        if IsNull(TennoAlt) and waitForSpawn then
            Sleep(0)
        end
    until not IsNull(TennoAlt) and waitForSpawn or not waitForSpawn
    
    print("INFO: HIDING TennoAlt AVATAR")
    
    if not IsNull(TennoAlt) then
        print("TennoAlt WAS NOT NULL")
        TennoAlt:SetVisibility(false, true)
    end
end

function ShowTennoAndTennoAltAvatars()
    local gameRules = gGameRules
    local Tenno = gameRules:GetTenno()
    local TennoAlt = gameRules:GetTennoAlt()
    print("INFO: SHOWING Tenno AND TennoAlt AVATARS(1 each)")
    if not IsNull(Tenno) then
        print("Tenno WAS NOT NULL")
        Tenno:SetVisibility(true, true)
    end
    if not IsNull(TennoAlt) then
        print("TennoAlt WAS NOT NULL")
        TennoAlt:SetVisibility(true, true)
    end
end

function ActivateCameraSpotForAvatar(trigger, avatar)
    if not IsNull(avatar) then
        if avatar:IsMaster() then
            cameraSpot:SetAvatar(avatar)
            cameraSpot:FirePort("Activate")
            print("Activated cameraspot")
        end
    else
        print("Setting cameraspot for null avatar")
    end
end

local function easeInQuad(t, b, c, d)
    t=t/d
    return c*t*t + b
end

function changeAnimationRateOverTime(this)
    local val = 0
    local t = 0
    while true do
        val = easeInQuad(t,StartRate, EndRate, Duration)
        t = t + DeltaTime()
        if val > EndRate then
            val = EndRate
        end 
        this:SetAnimRate(0,val)
        Sleep(0)
    end
    Sleep(0)
end
