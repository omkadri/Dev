-- Spawning Platforms
AmbulasSpawnPoints = { Instance() }

-- Boss Tracking
MaxShipHealth = 5
MaxAmbulasFailed = 5

ambulasAgentType = Type()
ambulasAvatarType = WeakResource()
ambulasBossMarkerInfo = Type()
ambulasHackedMarkerInfo = Type()
ambulasSpawnerFX = Type()

-- Adds Tracking
addSpawnerTrigger = Instance()
securityTeamSpawnerTrigger = Instance()
droneTeamSpawnerTrigger = Instance()

hackingDroneType = Type()
hackingDroneAvatarType = WeakResource()

addsPhase1 = { Type() }
addsPhase2 = { Type() }
addsPhase3 = { Type() }

securityTeam = { Type() }
droneStrikeTeam = { Type() }

addSpawnCliffWest = { Instance() }
addSpawnCliffEast = { Instance() }
addSpawnBuildingWest = { Instance() }
addSpawnBuildingEast = { Instance() }
addSpawnBuildingSouth = { Instance() }
addSpawnFrequency = 3

maxAddSpawns = 8

-- Cargo Ship
CargoShipSpawnPoint = Instance()
CargoShipTag = Symbol("AmbulasDropShip")
tractorBeamTrigger = Instance()
tractorBeamPulseFX = Type()
tractorBeamPulseSound = Resource()
tractorBeamPulseDeco = Type()
tractorBeamBuffFX = Type()
tractorBeamSeq = Type("/Lotus/Sounds/Enemies/Corpus/DropShip/CrpDropShipTractorBeamLoopSeq")
tractorBeamBeamFX = Type()
tractorBeamEndpointFX = Type()
tractorBeamProjFX = Type()
tractorBeamMoverEntity = Type()

local ambulasSpawningLoc = "/Lotus/Language/Game/AmbulasSpawning"
local ambulasMaxLoc = "/Lotus/Language/Game/AmbulasMaxCount"
local ambulasRemainingLoc = "/Lotus/Language/Game/AmbulasRemainingCount"
local ambulasDeliveredLoc = "/Lotus/Language/Game/AmbulasDelivery"
local ambulasSecurityTeamLoc = "/Lotus/Language/Game/AmbulasSecurityTeam"

local cargoAttachType = Type("/Lotus/Types/Gameplay/Corpus/CargoMoverAttachPoint")
local ambulasIdleStartAnim = Resource("/Lotus/Animations/Corpus/RiotMoa/RiotModeStart01_anim.fbx")
local ambulasIdleLoopAnim = Resource("/Lotus/Animations/Corpus/RiotMoa/RiotModeIdle_anim.fbx")

-- Orbital Strike
capitalShipCinDeathTrigger = Instance()
capitalShipCinLeaveTrigger = Instance()
missileBarrageTrigger = Instance()
orbitalLaserTrigger = Instance()

-- Timers
AddArrivalTime = 30
AirStrikeArrivalTime = 30
CargoShipLaunchTime = 60
CargoShipArrivalTime = 60
CargoShipPickupTime = 60
CargoShipReturnTime = 60
StrikeTeamActiveTime = 20

--Transmissions
transmissionSet = Resource()

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local UTIL = require "EE.Interface.Utilities"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
--local mTimerMgr = nil
--local TIMER = require "Lotus.Scripts.Libs.TimerLib"
local sCargoTime = Symbol("CargoShipTimer")
local sRoundTime = Symbol("RoundTimer")

local NV_AMBULAS_REMAINING = Symbol('AmbulasRemaining')
local NV_AMBULAS_HACKED = Symbol('AmbulasHacked')
local NV_AMBULAS_FIGHT_STAGE = Symbol('AmbulasFightStage')
local NV_SHIP_HEALTH = Symbol('AmbulasShipHealth')
local NV_SHIP_MAXHEALTH = Symbol('AmbulasShipMaxHealth')
local NV_CURRENT_CYCLE = Symbol('AmbulasFightCycle')
local NV_ADDS_SPAWNING = Symbol('AmbulasAddSpawning')
local NV_PLAYERCOUNT = Symbol('AmbulasPlayerCount')
local NV_PICKUP_STAGE = Symbol('AmbulasPickupStage')
local NV_MIDFIGHT_TRANS = Symbol('AmbulasMidFight')
local NV_AMBULAS_HACKORDERS = Symbol('AmbulasHackOrders')

local gameRules = gGameRules
local npcManager = gRegion:GetNpcMgr()
local aiDir = gRegion:GetNpcMgr():GetAiDirector()

local function Round(num, idp)
    local mult = 10^(idp or 0)
    return math.floor(num * mult + 0.5) / mult
end

function OnSpawned(avatar)
    print("SPAWNED PACK AVATAR")
    
    if not IsNull(avatar) then
        avatar:AddInvisibilityRequest()
    end
    
    local ambulasHUDTrigger = gRegion:FindTagged(Symbol("AmbulasStartupLogic"))
    local ambulasFightTrigger = gRegion:FindTagged(Symbol("AmbulasFightLogic"))

    if ambulasHUDTrigger and not IsNull(ambulasHUDTrigger[1]) then
        ambulasHUDTrigger[1]:FirePort("Execute")
    end
    
    if ambulasFightTrigger and not IsNull(ambulasFightTrigger[1]) then
        ambulasFightTrigger[1]:FirePort("Execute")
    end
end

function BossHud()
    while IsNull(gameRules) do
        Sleep(0)
        gameRules = gGameRules        
    end
    
    --local aiDir = npcManager:GetAiDirector()
    --aiDir:SetEnemyLevelMinMax(30, 30)

    local hud = gameRules:GetHudMovieInstance()
    if hud == nil then
        return
    end

    -- Progress Bar
    local progressBar = _T.AddHudTracker("AmbulasProgressBar", LOTUS_UTIL.HT_PROGRESS_BAR, 0.2, false, false)
    progressBar.SetFlareColor(_G.UIColor_DarkBlue)
    progressBar.SetLabel(ambulasMaxLoc, 1)
    
    -- Failure Bar Label
    local hudMessage = Localize(ambulasRemainingLoc, false)
    local failureLabel = _T.AddHudTracker("AmbulasArenaHud", LOTUS_UTIL.HT_LABEL, 0.15, false, false)
    failureLabel.SetLabel(hudMessage)
    
    -- Failure Bar
    local failureBar = _T.AddHudTracker("AmbulasFailureBar", LOTUS_UTIL.HT_ICON_BAR, 0.2, false, false)
    failureBar.SetOffset(0, -15)
    failureBar.List.mCurrProgress = 0
    failureBar.List.mCompletedColorObj = UTIL.ConvertColorNumberToProceduralRGB(_G.UIColor_Red)
    failureBar.SetCustomDrawFunction(
        function(pMovie, pList, pElement)
            pMovie:OverrideMaterial(pElement.mClipName .. ".Bg", _G.UIMaterial_RectangleNoDepth)

            local isCompleted = pElement.Id <= pList.mCurrProgress
            local innerAlpha = isCompleted and 0.5 or 0
            local rectColor = isCompleted and pList.mCompletedColorObj or _G.UIColorObject_White

            pMovie:SetShaderVariable(pElement.mClipName .. ".Bg", "RectInnerColor", rectColor.r, rectColor.g, rectColor.b, innerAlpha)
            pMovie:SetShaderVariable(pElement.mClipName .. ".Bg", "RectEdgeColor", rectColor.r, rectColor.g, rectColor.b, .9)
        end
    )
    failureBar.UpdateData()
    failureBar.List:Redraw()
    
    for i=1, MaxAmbulasFailed do
        failureBar.AddIcon(nil, {Rotation = 45})
    end
    
    while not IsNull(gameRules) and gameRules:GetNetPersistentVar(NV_AMBULAS_FIGHT_STAGE, 0) ~= 99 do    
        local maxHealth = gameRules:GetNetPersistentVar(NV_SHIP_MAXHEALTH, 0)
        local curHealth = maxHealth - gameRules:GetNetPersistentVar(NV_SHIP_HEALTH, 0)
        
        failureBar.List.mCurrProgress = gameRules:GetNetPersistentVar(NV_AMBULAS_REMAINING, 0)
        failureBar.List:Redraw(nil, true, true)
        failureBar.UpdateData()
        
        progressBar.SetGoalLabel(progressBar.Localize("/Lotus/Language/Menu/ProgressXOfY", { CURRENT = curHealth, TOTAL = maxHealth }))
        progressBar.SetValue(curHealth / maxHealth)

        Sleep(0)
    end
    
    if not IsNull(gameRules) then
        _T.RemoveHudTracker(progressBar)
        _T.RemoveHudTracker(failureLabel)
        _T.RemoveHudTracker(failureBar)
    end
end

local function SpawnBossIntro(waypoint)
    local agent 
    local bossLevel = gameRules:GetMission().maxEnemyLevel
    local players = gRegion:GetHumanPlayers()
    bossLevel = bossLevel + ((#players - 1) * 4)
    
    agent = npcManager:CreateAgent(ambulasAgentType, waypoint, Symbol("RandomTeam"), bossLevel)
    if not IsNull(agent) then
        agent:SetAlert()
        local avatar = agent:GetAvatar()
        if not IsNull(ambulasBossMarkerInfo) and not IsNull(avatar) then
            local marker = avatar:GetAttachment(ambulasBossMarkerInfo)
            if IsNull(marker) then
                marker = avatar:Attach(ambulasBossMarkerInfo, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, avatar)
            end
            -- recheck
            if not IsNull(marker) then
                marker:Enable()
            end
        end
    end
end

local function SpawnBoss(ambulasPointList)
    local agent 
    local bossLevel = gameRules:GetMission().maxEnemyLevel
    local players = gRegion:GetHumanPlayers()
    bossLevel = bossLevel + ((#players - 1) * 4)

    for i=1, #ambulasPointList do
        if not IsNull(ambulasPointList[i]) then
            agent = npcManager:CreateAgent(ambulasAgentType, ambulasPointList[i], Symbol("RandomTeam"), bossLevel)
            if not IsNull(agent) then
                agent:SetAlert()
                local avatar = agent:GetAvatar()
                if not IsNull(ambulasBossMarkerInfo) and not IsNull(avatar) then
                    local marker = avatar:GetAttachment(ambulasBossMarkerInfo)
                    if IsNull(marker) then
                        marker = avatar:Attach(ambulasBossMarkerInfo, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, avatar)
                    end
                    -- recheck
                    if not IsNull(marker) then
                        marker:Enable()
                    end
                end
            end
        end
    end
end

local function StepFightStage(stage)
    stage = stage + 1
    print("Advancing Ambulas fight stage to ", stage)
    gameRules:SetNetPersistentVar(NV_AMBULAS_FIGHT_STAGE, stage)
    return stage
end

local function ResetFightStage(stage)
    stage = 1
    print("Resetting Ambulas fight stage to ", stage)
    gameRules:SetNetPersistentVar(NV_AMBULAS_FIGHT_STAGE, stage)
    
    local ambulasList = gRegion:FindAll(ambulasAvatarType)            
    for i=1, #ambulasList do
         if not IsNull(ambulasList[i]) then
            ambulasList[i]:Destroy()
        end                            
    end
            
    return stage
end

function ReinforcementWave(self)

    if not gRegion:IsMaster() then
        return
    end
    
    gameRules:SetNetPersistentVar(NV_ADDS_SPAWNING, 1)
    
    local maxHealth = gameRules:GetNetPersistentVar(NV_SHIP_MAXHEALTH, 0)
    local stage = gameRules:GetNetPersistentVar(NV_AMBULAS_FIGHT_STAGE, 0)
    local shipHealth = gameRules:GetNetPersistentVar(NV_SHIP_HEALTH, 0)
    local shipPercent = shipHealth / maxHealth
    local players = gRegion:GetHumanPlayers()
    local enemyLevel = gameRules:GetMission().minEnemyLevel - 10
    if enemyLevel < 0 then
        enemyLevel = 1
    end
    
    local spawnLocs = {}
    
    local spawnLocsActive = {}
    table.insert(spawnLocsActive, addSpawnBuildingWest)
    table.insert(spawnLocsActive, addSpawnBuildingEast)
    table.insert(spawnLocsActive, addSpawnBuildingSouth)
    
    local spawnLocsInactive = {}
    table.insert(spawnLocsInactive, addSpawnCliffWest)
    table.insert(spawnLocsInactive, addSpawnCliffEast)
    table.insert(spawnLocsInactive, addSpawnBuildingWest)
    table.insert(spawnLocsInactive, addSpawnBuildingEast)
    
    spawnLocs = spawnLocsInactive
    
    local spawnCount = 2 + (#players - 1)
    local droneCount = 1
    local addList
    
    if shipPercent > 0.7 then 
        addList = addsPhase1
    elseif shipPercent > 0.4 then
        addList = addsPhase2
    else 
        addList = addsPhase3            
    end

    local spawnLimit = maxAddSpawns + ((#players - 1) * 2)
     
    local spawnGroup = {}
    spawnGroup = spawnLocs[RandomInt(1, #spawnLocs)]
    local prevSpawnGroup = {}
        
    local shouldSpawnDrones    
    local activeAmbulas = gRegion:FindTagged(Symbol("Ambulas"))
    
    local totalSpawns
    local spawnFrequency = addSpawnFrequency
    
    while stage > 0 and stage < 9 do
        stage = gameRules:GetNetPersistentVar(NV_AMBULAS_FIGHT_STAGE, 0)
        
        shouldSpawnDrones = false
        if #activeAmbulas > 0 then
            for i=1, #activeAmbulas do
                if not IsNull(activeAmbulas[i]) then
                    shouldSpawnDrones = activeAmbulas[i]:IsPreDeath()
                    if shouldSpawnDrones == true then
                        break
                    end
                end
            end
        end
        
        if shouldSpawnDrones then
            spawnLocs = spawnLocsActive
        else
            spawnLocs = spawnLocsInactive
        end
        
        while spawnGroup == prevSpawnGroup do
            spawnGroup = spawnLocs[RandomInt(1, #spawnLocs)]
        end
        prevSpawnGroup = spawnGroup
        
        totalSpawns = aiDir:GetActiveAICount()
        totalSpawns = totalSpawns - #activeAmbulas
        
        local prevAdd = 0

        local j = 1
        for i=1, (spawnCount + droneCount) do
            if stage > 9 then
                break
            end

            local newAgent
            if i <= spawnCount then 
                if not IsNull(addList) and totalSpawns < spawnLimit then
                    local addToSpawn = RandomInt(1, #addList)
                    while addToSpawn == prevAdd do
                        addToSpawn = RandomInt(1, #addList)
                    end
                    prevAdd = addToSpawn
                    newAgent = npcManager:CreateAgent(addList[addToSpawn], spawnGroup[j], Symbol("RandomTeam"), enemyLevel)
                end
            else
                if not IsNull(hackingDroneType) and shouldSpawnDrones and totalSpawns < (spawnLimit + 1) then
                    local hackingDroneCheck = gRegion:FindAll(hackingDroneAvatarType)
                    if #hackingDroneCheck < 4 then
                        newAgent = npcManager:CreateAgent(hackingDroneType, spawnGroup[j], Symbol("RandomTeam"), enemyLevel)
                    end
                end
            end                
                    
            if not IsNull(newAgent) then
                totalSpawns = totalSpawns + 1
                newAgent:SetAlert()
                if not IsNull(activeAmbulas) and #activeAmbulas > 0 then
                    newAgent:StormTarget(activeAmbulas[RandomInt(1, #activeAmbulas)])
                else
                    newAgent:StormTarget(players[RandomInt(1, #players)]:GetAvatar())
                end
            end
        
            j = j + 1
            
            if j > #spawnGroup then
                j = 1
            end
            
            Sleep(RandomInt(0,1))            
        end
        
        Sleep(spawnFrequency)
    end    
    
    gameRules:SetNetPersistentVar(NV_ADDS_SPAWNING, 0)
end

function SpawnSecurityTeam(self)

    if not gRegion:IsMaster() then
        return
    end 
    
    local players = gRegion:GetHumanPlayers()
    for i=1, #players do
        local impactMessageSound = WeakResource("/Lotus/Sounds/Levels/Missions/Defense/DefenseWaveCleared")
        gameRules:DisplayMessage(players[i], ambulasSecurityTeamLoc, "", 0, 2.5, true,"","",impactMessageSound)
    end
    --_T.ShowImpactMessage(ambulasSecurityTeamLoc, 2.5, true, nil, false)

    local maxHealth = gameRules:GetNetPersistentVar(NV_SHIP_MAXHEALTH, 0)
    local stage = gameRules:GetNetPersistentVar(NV_AMBULAS_FIGHT_STAGE, 0)
    local shipHealth = gameRules:GetNetPersistentVar(NV_SHIP_HEALTH, 0)
    local shipPercent = shipHealth / maxHealth
    local players = gRegion:GetHumanPlayers()
    local enemyLevel = gameRules:GetMission().minEnemyLevel
    
    local spawnLocs = {}
    table.insert(spawnLocs, addSpawnBuildingWest)
    table.insert(spawnLocs, addSpawnBuildingEast)
    table.insert(spawnLocs, addSpawnBuildingSouth)
    
    local spawnCount
    local addList = securityTeam   
    
    if shipPercent > 0.5 then 
        spawnCount = 2 + #players
    else
        spawnCount = 3 + #players     
    end
     
    local spawnGroup = {}
    spawnGroup = spawnLocs[RandomInt(1, #spawnLocs)]
    
    local currentCount = spawnCount
    while currentCount > 0 do                                        
        local i = 1
        local newAgent
        if not IsNull(addList) and #addList > 0 then
            local addToSpawn = RandomInt(1, #addList)
            spawnGroup = spawnLocs[RandomInt(1, #spawnLocs)]
            newAgent = npcManager:CreateAgent(addList[addToSpawn], spawnGroup[i], Symbol("RandomTeam"), enemyLevel)
        end
        if not IsNull(newAgent) then
            newAgent:SetAlert()
            local stormPlayer = players[RandomInt(1, #players)]
            if not IsNull(stormPlayer) then
                newAgent:StormTarget(stormPlayer:GetAvatar())
            end
        end
        
        i = i + 1
            
        if i > #spawnGroup then
            i = 1
        end
            
        currentCount = currentCount - 1
        
        Sleep(0.5)          
    end
end

function SpawnDroneTeam(self)
    if not gRegion:IsMaster() then
        return
    end   
    
    local players = gRegion:GetHumanPlayers()
    for i=1, #players do
        local impactMessageSound = WeakResource("/Lotus/Sounds/Levels/Missions/Defense/DefenseWaveCleared")
        gameRules:DisplayMessage(players[i], ambulasSecurityTeamLoc, "", 0, 2.5, true,"","",impactMessageSound)
    end
    --_T.ShowImpactMessage(ambulasSecurityTeamLoc, 2.5, true, nil, false)
    
    local maxHealth = gameRules:GetNetPersistentVar(NV_SHIP_MAXHEALTH, 0)
    local stage = gameRules:GetNetPersistentVar(NV_AMBULAS_FIGHT_STAGE, 0)
    local shipHealth = gameRules:GetNetPersistentVar(NV_SHIP_HEALTH, 0)
    local shipPercent = shipHealth / maxHealth
    local players = gRegion:GetHumanPlayers()
    local enemyLevel = gameRules:GetMission().minEnemyLevel
    
    local spawnLocs = {}
    table.insert(spawnLocs, addSpawnBuildingWest)
    table.insert(spawnLocs, addSpawnBuildingEast)
    table.insert(spawnLocs, addSpawnBuildingSouth)
    
    local spawnCount
    local addList = droneStrikeTeam
    
    if shipPercent > 0.5 then 
        spawnCount = 4 + #players
    else
        spawnCount = 6 + #players       
    end
     
    local spawnGroup = {}
    spawnGroup = spawnLocs[RandomInt(1, #spawnLocs)]
    
    local currentCount = spawnCount
    while currentCount > 0 do                                        
        local i = 1
        local newAgent
        if not IsNull(addList) and #addList > 0 then
            local addToSpawn = RandomInt(1, #addList)
            spawnGroup = spawnLocs[RandomInt(1, #spawnLocs)]
            newAgent = npcManager:CreateAgent(addList[addToSpawn], spawnGroup[i], Symbol("RandomTeam"), enemyLevel)
        end
        if not IsNull(newAgent) then
            newAgent:SetAlert()
            local stormPlayer = players[RandomInt(1, #players)]
            if not IsNull(stormPlayer) then
                newAgent:StormTarget(stormPlayer:GetAvatar())
            end
        end
        
        i = i + 1
            
        if i > #spawnGroup then
            i = 1
        end
            
        currentCount = currentCount - 1
        
        Sleep(0.5)          
    end
end

local function TractorBeam(ambulasAvatar, attachTarget)    
            
    if gRegion:IsMaster() then
        print("Starting Ambulas tractor beam on host")
    else
        print("Starting Ambulas tractor beam on client")
    end
    
    ambulasAvatar:EnablePhysics(false)
    
    local t = 0.0
    local tempTime
    
    local ambulasPosition = ambulasAvatar:GetPosition()
    local destination = Vector(ambulasPosition.x, ambulasPosition.y + 5, ambulasPosition.z)
    
    local prevPosition
    local newPosition
    
    local newRotation = ambulasAvatar:GetRotation()

    local tractorBeamMover = gRegion:CreateEntity(tractorBeamMoverEntity, ambulasPosition, newRotation)
    ambulasAvatar:AttachToInPlace(tractorBeamMover, Symbol())

    --raise up       
    while t < 2.0 do
        t = t + DeltaTime()
        tempTime = t / 2.0
        
        newPosition = LerpVector(ambulasPosition, destination, tempTime)
        prevPosition = newPosition
        newRotation = LerpRotation(newRotation, attachTarget:GetRotation(), tempTime)
        tractorBeamMover:Teleport(newPosition, newRotation)
        Sleep(0)        
    end
    
    local pulseFX = ambulasAvatar:GetAttachment(tractorBeamBuffFX)    
    if not IsNull(pulseFX) then
        pulseFX:Destroy()
    end
    
    destination = attachTarget:GetPosition()
    local beam = ambulasAvatar:Attach(tractorBeamBeamFX, Symbol("GAME_C1_SPINE1"))
    if not IsNull(beam) then
        beam:SetEndPoint(destination)
    end
    
    local beamProj = ambulasAvatar:Attach(tractorBeamProjFX, EMPTY_SYMBOL)
    local beamEndPoint = attachTarget:Attach(tractorBeamEndpointFX, EMPTY_SYMBOL)
    
    t = 0.0
    
    while t < 2.0 do
       t = t + DeltaTime()
        tempTime = t / 2.0
       
        newPosition = LerpVector(prevPosition, destination, tempTime)
        tractorBeamMover:Teleport(newPosition, attachTarget:GetRotation())
        Sleep(0)        
    end

    ambulasAvatar:Unattach()
    ambulasAvatar:AttachToInPlace(attachTarget, Symbol())
    --tractorBeamMover:AttachToInPlace(attachTarget, Symbol())
    
    if not IsNull(tractorBeamMover) then
        tractorBeamMover:Destroy()
    end
    
    if not IsNull(beam) then
        beam:Destroy()
    end
    
    if not IsNull(beamProj) then
        beamProj:Destroy()
    end
    
    if not IsNull(beamEndPoint) then
        beamEndPoint:Destroy()
    end
end

function ReadyForPickup(ambulas)
    if gRegion:IsMaster() then
        print("Starting Ambulas pickup on host")
    else
        print("Starting Ambulas pickup on client")
    end
    
    ambulas:SetPostureModifier(Engine.PM_HELD, true)
    ambulas:DisableHackPanel()
        
    local isHacked = not ambulas:DamageControl():IsAutoReviving() and ambulas:IsPreDeath()
    if not isHacked then        
        ambulas:PlayAnimation(ambulasIdleStartAnim, true, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_ONCE, true)
        if not ambulas:IsPlayingAnimation(ambulasIdleStartAnim) then
            while ambulas:IsPlayingBlockingAnimation() do
                Sleep(0)
            end
            ambulas:PlayAnimation(ambulasIdleStartAnim, true, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_ONCE, true)
        end        
        ambulas:PlayAnimation(ambulasIdleLoopAnim, false, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_LOOP, true)        
    end
    ambulas:AddDeltaAttenuation(Symbol("AMBULAS_TRACTOR_BEAM"), 0.0)
    ambulas:Attach(tractorBeamBuffFX, Symbol("GAME_C1_SPINE1"))
    ambulas:Attach(tractorBeamSeq, EMPTY_SYMBOL)
    ambulas:SetAgentPaused(true)
end

function StartTractorBeams()

    -- grab the spawned cargo ship
    local cargoShip = gRegion:FindTagged(CargoShipTag)
    
    if IsNull(cargoShip) then
        return
    end
    
    local cargoShipAvatar
    if not IsNull(cargoShip[1]) then
        cargoShipAvatar = cargoShip[1]
    end
    
    if IsNull(cargoShipAvatar) then
        return
    end

    -- check active Ambulas
    local attachPoints = cargoShipAvatar:GetAllAttachments(cargoAttachType)
    local attachTable = { }            
    
    for i=1, #attachPoints do
        if not IsNull(attachPoints[i]) then
            table.insert(attachTable, attachPoints[i])
        end
    end   
    
    local ambulasCheck = gRegion:FindAll(ambulasAvatarType)
    local activeAmbulas = {}
    
    if gRegion:IsMaster() then              
        for i=1, #ambulasCheck do
            local tempAmbulas = ambulasCheck[i]
            if not IsNull(tempAmbulas) then
                table.insert(activeAmbulas, tempAmbulas)
            end
        end
    end

    local spawnPos = cargoShipAvatar:GetPosition()
    cargoShipAvatar:PlaySound(tractorBeamPulseSound, false)
    gRegion:CreateEntity(tractorBeamPulseFX, spawnPos, ZERO_ROTATION)
    local effectDeco = gRegion:CreateEntity(tractorBeamPulseDeco, spawnPos, ZERO_ROTATION)
    
    local baseRange = 20
    local baseGrowthRate = 40
    local baseGrowthDuration = 3
        
    while baseGrowthDuration > 0 do            
        if not IsNull(effectDeco) then
            effectDeco:SetMeshScale(baseRange / 10)
            effectDeco:SetMaterialParam(Symbol("UnlitAtten"), math.min(1.0, baseGrowthDuration))
        end            
        Sleep(0)
        baseGrowthDuration = baseGrowthDuration - DeltaTime()
        baseRange = baseRange + DeltaTime() * baseGrowthRate
        
        if gRegion:IsMaster() then
            if #activeAmbulas > 0 then
                for i=1, #activeAmbulas do
                    local tempAmbulas = activeAmbulas[i]
                    if not IsNull(tempAmbulas) and tempAmbulas:DistanceToPoint(spawnPos) <= baseRange and not tempAmbulas:GetAgent():IsPaused() then
                        tempAmbulas:ScriptRunChildScript(Symbol("ReadyForPickup"), false)
                        table.remove(activeAmbulas, i)
                    end
                end
            end
        end
    end
    
    if not IsNull(effectDeco) then
        effectDeco:Destroy()
    end   
    
    -- Disable any that didn't get hit by the pulse
    if gRegion:IsMaster() then    
        while #activeAmbulas > 0 do
            local tempAmbulas = activeAmbulas[1]
            if not IsNull(tempAmbulas) and not tempAmbulas:GetAgent():IsPaused() then
                tempAmbulas:ScriptRunChildScript(Symbol("ReadyForPickup"), false)                  
            end
            table.remove(activeAmbulas, 1)
        end
    end
    
    local hacked = 0
    
    -- Beam them up           
    if not IsNull(ambulasCheck) and #ambulasCheck > 0 then
        for i=1, #ambulasCheck do
            local tempAmbulas = ambulasCheck[i]
            if not IsNull(tempAmbulas) then
                
               if gRegion:IsMaster() then
                    local isHacked = not tempAmbulas:DamageControl():IsAutoReviving() and tempAmbulas:IsPreDeath()
                    if isHacked then
                        hacked = hacked + 1
                        gameRules:SetNetPersistentVar(NV_AMBULAS_HACKED, hacked)
                        print("Transporting Hacked Ambulas ")
                    else
                        gameRules:SetNetPersistentVar(NV_AMBULAS_REMAINING, gameRules:GetNetPersistentVar(NV_AMBULAS_REMAINING, 0) + 1)
                        print("Transporting Unhacked Ambulas ")
                    end                        
                end
                
                -- TODO: Pull Ambulas to Cargo Ship
                if not IsNull(attachTable[1]) then
                    
                    TractorBeam(tempAmbulas, attachTable[1])
                    table.remove(attachTable, 1)
                else
                    TractorBeam(tempAmbulas, attachPoints[1]) 
                end
                Sleep(0.5)
            end
        end
    end
    
    if gRegion:IsMaster() then
        local stage = gameRules:GetNetPersistentVar(NV_AMBULAS_FIGHT_STAGE, 0)
        StepFightStage(stage)  
    end
end

function OnPlayersChanged()
    local players = gRegion:GetHumanPlayers()
    for i=1, #players do
        players[i]:AddTimerOfInterest(sCargoTime)
    end
end

function LockBossFight()
    gGameRules:HideGameSession(true)
end

function ManageBossFight(self)

    if not gRegion:IsMaster() then
        return
    end
    
    if not _T.InWorldTransmissionQueue then
        _T.InWorldTransmissionQueue = {}
    end
    
    while IsNull(gameRules) do
        Sleep(0)
        gameRules = gGameRules
    end
    
    _T.TransmissionSet = transmissionSet
    gRegion:AddPlayersChangedBasicCallback("OnPlayersChanged")

    local stage = gameRules:GetNetPersistentVar(NV_AMBULAS_FIGHT_STAGE, 0)
    local players = gRegion:GetHumanPlayers()
    
    if stage == 0 then
        gameRules:SetNetPersistentVar(NV_AMBULAS_REMAINING, 0)
        
        local startingHealth = MaxShipHealth + (#players - 1)
        if startingHealth > 6 then
            startingHealth = 6
        end

        gameRules:SetNetPersistentVar(NV_SHIP_MAXHEALTH, startingHealth)
        gameRules:SetNetPersistentVar(NV_SHIP_HEALTH, startingHealth)
        gameRules:SetNetPersistentVar(NV_AMBULAS_HACKED, 0)
        gameRules:SetNetPersistentVar(NV_CURRENT_CYCLE, 1)
        gameRules:SetNetPersistentVar(NV_ADDS_SPAWNING, 0)
        gameRules:SetNetPersistentVar(NV_PLAYERCOUNT, #players)
        gameRules:SetNetPersistentVar(NV_PICKUP_STAGE, 1)
        gameRules:SetNetPersistentVar(NV_MIDFIGHT_TRANS, 0)
        gameRules:SetNetPersistentVar(NV_AMBULAS_HACKORDERS, 0)        
        
        stage = StepFightStage(stage) 
        
        local avatars = gRegion:FindAll(gBaseAvatarType, self:GetPosition(), 0, 500)
        for i = 1, #avatars do
            if avatars[i]:GetFaction() ~= Symbol("TENNO") and avatars[i]:GetTag() ~= Symbol("AmbulasPack") then
                avatars[i]:Destroy()
            end
        end
    else
        if gPromotedToHost then
            Sleep(0)
            -- re-add Ambulas markers on host migration
            local startingAmbulas = gRegion:FindTagged(Symbol("Ambulas"))
            for i=1, #startingAmbulas do
                if not IsNull(startingAmbulas[i]) then
                    local isHacked = not startingAmbulas[i]:DamageControl():IsAutoReviving() and startingAmbulas[i]:IsPreDeath()
                    if isHacked then
                        if not IsNull(ambulasHackedMarkerInfo) then
                            local marker = startingAmbulas[i]:GetAttachment(ambulasHackedMarkerInfo)
                            if IsNull(marker) then
                                marker = startingAmbulas[i]:Attach(ambulasHackedMarkerInfo, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, startingAmbulas[i])
                            end
                            -- recheck
                            if not IsNull(marker) then
                                marker:Enable()
                            end
                        end
                    else
                        if not IsNull(ambulasBossMarkerInfo) then
                            local marker = startingAmbulas[i]:GetAttachment(ambulasBossMarkerInfo)
                            if IsNull(marker) then
                                marker = startingAmbulas[i]:Attach(ambulasBossMarkerInfo, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, startingAmbulas[i])
                            end
                            -- recheck
                            if not IsNull(marker) then
                                marker:Enable()
                            end
                        end
                    end
                end
            end
            if stage > 3 and stage < 9  or gameRules:GetNetPersistentVar(NV_ADDS_SPAWNING, 0) > 0 then
                addSpawnerTrigger:FirePort("Execute")
            end
        end
    end

    local fullRoundTimer = AddArrivalTime + AirStrikeArrivalTime + CargoShipLaunchTime + CargoShipArrivalTime + CargoShipPickupTime + CargoShipReturnTime + StrikeTeamActiveTime
    
    local addArrivalTimer = fullRoundTimer - AddArrivalTime
    local airstrikeArrivalTimer = addArrivalTimer - AirStrikeArrivalTime
    local cargoLaunchTimer = airstrikeArrivalTimer - CargoShipLaunchTime
    local cargoArrivalTimer = cargoLaunchTimer - CargoShipArrivalTime
    local cargoPickupTimer = cargoArrivalTimer - CargoShipPickupTime
    local cargoReturnTimer = cargoPickupTimer - CargoShipReturnTime
    local responseEventTimer = cargoReturnTimer - StrikeTeamActiveTime
    
    local fullDisplayTimer = AddArrivalTime + AirStrikeArrivalTime + CargoShipLaunchTime + CargoShipArrivalTime + CargoShipPickupTime

    local shipHealth = gameRules:GetNetPersistentVar(NV_SHIP_HEALTH, 0)
    local maxHealth = gameRules:GetNetPersistentVar(NV_SHIP_MAXHEALTH, 0)
    
    for i=1, #players do
        players[i]:AddTimerOfInterest(sCargoTime)
    end
    local startingPlayerCount = gameRules:GetNetPersistentVar(NV_PLAYERCOUNT, 0)
 
    while gameRules:GetNetPersistentVar(NV_SHIP_HEALTH, 0) > 0 and gameRules:GetNetPersistentVar(NV_AMBULAS_REMAINING, 0) < MaxAmbulasFailed do   
    
        -- 1 - Spawn Ambulas group ------------------------------------------------------------------------------------------------------------------------------------------------------------------
        
        shipHealth = gameRules:GetNetPersistentVar(NV_SHIP_HEALTH, 0)--temp
        local shipPercent = shipHealth / maxHealth
        local currentCycle = gameRules:GetNetPersistentVar(NV_CURRENT_CYCLE, 0)
        gGameRules:SetNetPersistentVar(NV_AMBULAS_HACKORDERS, 0)

        --local cargoShipEntity
        if stage <= 1 then
        
            print("Spawning Boss ")
  
            if currentCycle == 1 then
                SpawnBossIntro(AmbulasSpawnPoints[1])
            else
                players = gRegion:GetHumanPlayers()
                for i=1, #players do
                    local impactMessageSound = WeakResource("/Lotus/Sounds/Levels/Missions/Defense/DefenseWaveCleared")
                    gameRules:DisplayMessage(players[i], ambulasSpawningLoc, "", 0, 2.5, true,"","",impactMessageSound)
                end
                --_T.ShowImpactMessage(ambulasSpawningLoc, 2.5, true, nil, false) 
                
                Sleep(1)
                
                local spawnBossCount = 1

                if startingPlayerCount == 1 then
                    if shipPercent < 0.3 then
                        spawnBossCount = 2
                    end
                elseif startingPlayerCount == 2 then
                    if shipPercent < 0.7 then
                        spawnBossCount = 2
                    end
                elseif startingPlayerCount == 3 then
                    if shipPercent < 0.7 then
                        spawnBossCount = 2
                    end
                elseif startingPlayerCount == 4 then
                    if shipPercent < 1.0 then
                        spawnBossCount = 2
                    end
                end

                local randomNum
                local spawnPoint
        
                local spawnPointList = { }
                local ambulasPointList = { }
                local bossLevel = gameRules:GetMission().maxEnemyLevel
        
                for i=1, #AmbulasSpawnPoints do
                    table.insert(spawnPointList, AmbulasSpawnPoints[i])
                end

                while spawnBossCount > 0 do
                    randomNum = SRandomInt(1, #spawnPointList)
                    if not IsNull(spawnPointList[randomNum]) then
                        spawnPoint = spawnPointList[randomNum]
                        spawnPoint:Attach(ambulasSpawnerFX, EMPTY_SYMBOL)
                        --spawnPoint:PlaySound(ambulasSpawnerSound, false)
                        local spawnAlarmSeq = gRegion:FindFirstTagged(Symbol("AmbulasSpawnAlarm"))
                        if not IsNull(spawnAlarmSeq) then
                            spawnAlarmSeq:Enable()
                        end
                        table.insert(ambulasPointList, spawnPoint)                
                        table.remove(spawnPointList, randomNum)
                        spawnBossCount = spawnBossCount - 1
                    end
                end
                
                Sleep(3.0)
                
                SpawnBoss(ambulasPointList)
            end
            
            if shipHealth == 1 then
                DIALOG.PlayGlobalTransmission(_T.TransmissionSet, Symbol("AmbulasBossLastOne"), 0)
            end
            
            -- Set time
            if gRegion:IsMaster() then
                gameRules:SetMissionTimer(sCargoTime, Symbol(), fullDisplayTimer, false, true, false)
                gameRules:SetMissionTimerSurvivesMigration(sCargoTime, true)
                gameRules:SetMissionTimer(sRoundTime, Symbol(), fullRoundTimer, false, true, false)
                gameRules:SetMissionTimerSurvivesMigration(sRoundTime, true)
            end
            
            stage = StepFightStage(stage)        
        end
        
        -- 2 - Wait to progress to Stage 3 -------------------------------------------------------------------------------------------------------------------------------------------------------------
        if stage <= 2 then
            local activeAmbulas = gRegion:FindTagged(Symbol("Ambulas"))
            local shouldSpawnAdds = gameRules:GetNetPersistentVar(NV_ADDS_SPAWNING, 0)
            
            while gameRules:GetMissionTimeLeft(sRoundTime) >= addArrivalTimer do
                Sleep(0)
                
                if shouldSpawnAdds == 0 then
                    for i=1, #activeAmbulas do
                        if not IsNull(activeAmbulas[i]) then
                            if activeAmbulas[i]:IsPreDeath() then
                                shouldSpawnAdds = 1
                                gameRules:SetNetPersistentVar(NV_ADDS_SPAWNING, shouldSpawnAdds)
                                addSpawnerTrigger:FirePort("Execute")
                                break
                            end
                        end
                    end
                    shouldSpawnAdds = gameRules:GetNetPersistentVar(NV_ADDS_SPAWNING, 0)
                end

            end
            
            stage = StepFightStage(stage)
        end
        
        -- 3 - Spawn adds -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if stage <= 3 then
            print("Spawning Adds ")
            
            -- Spawn attack adds
            if gameRules:GetNetPersistentVar(NV_ADDS_SPAWNING, 0) == 0 then
                addSpawnerTrigger:FirePort("Execute")
            end

            stage = StepFightStage(stage)  
        end
        
        -- 4 - Wait to progress to Stage 5 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if stage <= 4 then
            while gameRules:GetMissionTimeLeft(sRoundTime) >= airstrikeArrivalTimer do
                Sleep(0)
            end
            stage = StepFightStage(stage) 
        end
        
        -- 5 - Air Strike #1 -----------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if stage <= 5 then    
            print("Air Strike Starting ")
            if shipPercent < 0.9 then
                -- capital ship barrage alarm sound
                local barrageAlarmSeq = gRegion:FindFirstTagged(Symbol("CapitalShipAlarm"))
                if not IsNull(barrageAlarmSeq) then
                    barrageAlarmSeq:Enable()
                end
                
                --local impactMessageSound = Resource("/Lotus/Sounds/Levels/Missions/Defense/DefenseWaveCleared")
                --UTIL.PlaySound(impactMessageSound)
                DIALOG.PlayGlobalTransmission(_T.TransmissionSet, Symbol("AmbulasBossOrbitalStrike"), 0)
                
                if shipPercent > 0.7 then 
                    missileBarrageTrigger:FirePort("Execute")
                else
                    if shipPercent > 0.4 then                        
                        orbitalLaserTrigger:FirePort("Execute")
                    else
                        missileBarrageTrigger:FirePort("Execute")   
                        orbitalLaserTrigger:FirePort("Execute")
                    end 
                end
            end
            
            stage = StepFightStage(stage)
        end
        
        -- 6 - Wait to progress to Stage 7 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if stage <= 6 then
            while gameRules:GetMissionTimeLeft(sRoundTime) >= cargoLaunchTimer do
                Sleep(0)
            end
            stage = StepFightStage(stage) 
        end

        -- 7 - Cargo Ship Launch -----------------------------------------------------------------------------------------------------------------------------------------------------
        if stage <= 7 then    
 
            print("Launching Cargo Ship!")
            players = gRegion:GetHumanPlayers()
            --for i=1, #players do
                --gameRules:DisplayMessage(players[i], ambulasCargoShipLoc, "", 0, 2.5, true)
                -- impact message sound
                --local impactMessageSound = Resource("/Lotus/Sounds/Levels/Missions/Defense/DefenseWaveCleared")
                --UTIL.PlaySound(impactMessageSound)
            --end
            DIALOG.PlayGlobalTransmission(_T.TransmissionSet, Symbol("AmbulasBossDropship"), 0)
            
            --_T.ShowImpactMessage(ambulasCargoShipLoc, 2.5, true, nil, false) 
            CargoShipSpawnPoint:FirePort("Reset")

            stage = StepFightStage(stage)
        end

        -- 8 - Wait to progress to Stage 9 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if stage <= 8 then
            while gameRules:GetMissionTimeLeft(sRoundTime) >= cargoArrivalTimer do
                Sleep(0)
            end
            stage = StepFightStage(stage) 
        end
        
        -- 9 - Cargo Ship Arrival / Drop Off Troops -----------------------------------------------------------------------------------------------------------------------------------------------------
        if stage <= 9 then    
            -- call in ship

            print("Cargo Ship arrived ")
            
            while gameRules:GetMissionTimeLeft(sRoundTime) >= cargoPickupTimer do
                Sleep(0)
            end
            
            stage = StepFightStage(stage)
        end
            
        -- 10 - Pick Up Ambulas ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if stage <= 10 then 
            
            gameRules:RemoveMissionTimer(sCargoTime)
            gGameRules:SetPausedMissionTimer(sRoundTime, true)
            
            tractorBeamTrigger:FirePort("Execute")
            
            stage = StepFightStage(stage) 
        end

        -- 11 - Wait on Tractor Beam -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if stage <= 11 then
            while gameRules:GetNetPersistentVar(NV_AMBULAS_FIGHT_STAGE, 0) == 11 do
                Sleep(0)
            end
            stage = StepFightStage(stage) 
        end
        
        -- 12 - Process Ambulas -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if stage <= 12 then            
            -- check number of hacked Ambulas
            print("Cargo Ship delivering ")
            local numHacked = gameRules:GetNetPersistentVar(NV_AMBULAS_HACKED, 0)
            if numHacked > 0 then
                players = gRegion:GetHumanPlayers()
                for i=1, #players do
                    local impactMessageSound = WeakResource("/Lotus/Sounds/Levels/Missions/Defense/DefenseWaveCleared")
                    gameRules:DisplayMessage(players[i], ambulasDeliveredLoc, "", 0, 2.5, true,"","",impactMessageSound)
                end
                --_T.ShowImpactMessage(ambulasDeliveredLoc, 2.5, true, nil, false)  
                shipHealth = shipHealth - numHacked
                -- TODO: handle damage event, barks, etc.
                if shipHealth < 0 then
                    shipHealth = 0
                end
                
                gameRules:SetNetPersistentVar(NV_SHIP_HEALTH, shipHealth)
                
                shipPercent = shipHealth / maxHealth
                local transmissionStage = gameRules:GetNetPersistentVar(NV_PICKUP_STAGE, 0)                
                
                if shipPercent > 0.75 and transmissionStage == 1 then
                    DIALOG.PlayGlobalTransmission(_T.TransmissionSet, Symbol("AmbulasBossPickup1"), 0)
                    gameRules:SetNetPersistentVar(NV_PICKUP_STAGE, 2)
                elseif shipPercent <= 0.75 and shipPercent > 0.5 and transmissionStage == 1 then
                    DIALOG.PlayGlobalTransmission(_T.TransmissionSet, Symbol("AmbulasBossPickup1"), 0)
                    gameRules:SetNetPersistentVar(NV_PICKUP_STAGE, 3)  
                elseif shipPercent <= 0.75 and shipPercent > 0.5 and transmissionStage == 2 then
                    DIALOG.PlayGlobalTransmission(_T.TransmissionSet, Symbol("AmbulasBossPickup2"), 0)
                    gameRules:SetNetPersistentVar(NV_PICKUP_STAGE, 3)  
                elseif shipPercent <= 0.5 and shipPercent > 0.25 and transmissionStage == 3 then
                    DIALOG.PlayGlobalTransmission(_T.TransmissionSet, Symbol("AmbulasBossPickup3"), 0)
                    gameRules:SetNetPersistentVar(NV_PICKUP_STAGE, 4)  
                elseif shipPercent <= 0.25 and shipPercent > 0 and transmissionStage == 4 then
                    DIALOG.PlayGlobalTransmission(_T.TransmissionSet, Symbol("AmbulasBossPickup4"), 0)
                    gameRules:SetNetPersistentVar(NV_PICKUP_STAGE, 5)  
                elseif shipPercent <= 0 then
                    DIALOG.PlayGlobalTransmission(_T.TransmissionSet, Symbol("AmbulasBossPickupVictory"), 0)
                end
            else
                local randTransmission = SRandomInt(0,2)
                if randTransmission == 0 then
                    DIALOG.PlayGlobalTransmission(_T.TransmissionSet, Symbol("AmbulasUnhackedDelivered"), 0)
                end
            end
            
            -- reset hacked count
            numHacked = 0
            gameRules:SetNetPersistentVar(NV_AMBULAS_HACKED, numHacked)
            
            print("Current Ship Health: ", shipHealth)

            gGameRules:SetPausedMissionTimer(sRoundTime, false)            
            stage = StepFightStage(stage) 
        end
        
        -- 13 - Cargo Ship Leaves  --------------------------------------------------------------------------------------------------------------------------------------------
        if stage <= 13 then
            -- Recall ship            
            print("Cargo Ship leaving ")
            
            while gameRules:GetMissionTimeLeft(sRoundTime) >= cargoReturnTimer do
                Sleep(0)
            end

            stage = StepFightStage(stage)
        end
        
        -- 14 - Variable Response Event -----------------------------------------------------------------------------------------------------------------------------------------------
        if stage <= 14 and gameRules:GetNetPersistentVar(NV_SHIP_HEALTH, 0) > 0 and gameRules:GetNetPersistentVar(NV_AMBULAS_REMAINING, 0) < MaxAmbulasFailed then
        
            -- Choose between a list of events
            if currentCycle > 1 then
                shipPercent = gameRules:GetNetPersistentVar(NV_SHIP_HEALTH, 0) / maxHealth
                if shipPercent <= 0.65 then
                    if gameRules:GetNetPersistentVar(NV_MIDFIGHT_TRANS, 0) == 0 then
                        DIALOG.PlayGlobalTransmission(_T.TransmissionSet, Symbol("AmbulasBossMidFight1"), 0)
                        gameRules:SetNetPersistentVar(NV_MIDFIGHT_TRANS, 1)
                    elseif gameRules:GetNetPersistentVar(NV_MIDFIGHT_TRANS, 0) == 1 then
                        DIALOG.PlayGlobalTransmission(_T.TransmissionSet, Symbol("AmbulasBossMidFight2"), 0)
                        gameRules:SetNetPersistentVar(NV_MIDFIGHT_TRANS, 2)
                    end
                end
            
                local responseCheck
                if currentCycle == 2 then
                    responseCheck = 1
                elseif currentCycle == 3 then
                    responseCheck = 2
                else
                    responseCheck = SRandomInt(1,2)
                end
                
                if responseCheck == 1 then
                    droneTeamSpawnerTrigger:FirePort("Execute")
                elseif responseCheck == 2 then
                    securityTeamSpawnerTrigger:FirePort("Execute")
                end
                
                while gameRules:GetMissionTimeLeft(sRoundTime) >= responseEventTimer do
                    Sleep(0)
                end
                
                gameRules:RemoveMissionTimer(sRoundTime)
                gameRules:SetNetPersistentVar(NV_CURRENT_CYCLE, gameRules:GetNetPersistentVar(NV_CURRENT_CYCLE, 0) + 1)
                stage = ResetFightStage(stage)
            else
                gameRules:RemoveMissionTimer(sRoundTime)
                gameRules:SetNetPersistentVar(NV_CURRENT_CYCLE, gameRules:GetNetPersistentVar(NV_CURRENT_CYCLE, 0) + 1)
                stage = ResetFightStage(stage)
            end
        end
    end
    if gameRules:GetNetPersistentVar(NV_SHIP_HEALTH, 0) <= 0 then
        if stage == 99 then
            Sleep(5)
            local packavatars = gRegion:FindTagged(Symbol("AmbulasPack"))
            if not IsNull(packavatars[1]) then
                packavatars[1]:Destroy()
            end
            DIALOG.PlayGlobalTransmission(_T.TransmissionSet, Symbol("AmbulasBossVictory4"), 0)
        else
            gameRules:SetNetPersistentVar(NV_AMBULAS_FIGHT_STAGE, stage)
            local packavatars = gRegion:FindTagged(Symbol("AmbulasPack"))
            Sleep(10)
            -- play capital ship animation
            DIALOG.PlayGlobalTransmission(_T.TransmissionSet, Symbol("AmbulasBossVictory3"), 0)
            capitalShipCinDeathTrigger:FirePort("StartPlaying")
            -- TODO: capital ship explosion FX
            stage = 99
            gameRules:SetNetPersistentVar(NV_AMBULAS_FIGHT_STAGE, stage)
            Sleep(15)
            packavatars[1]:Destroy()
            DIALOG.PlayGlobalTransmission(_T.TransmissionSet, Symbol("AmbulasBossVictory4"), 0)
        end        
    elseif gameRules:GetNetPersistentVar(NV_AMBULAS_REMAINING, 0) >= MaxAmbulasFailed then
        if stage == 99 then
            Sleep(5)
            gGameRules:EndGame(Engine.GameRules_GS_FAILURE)
        else
            gameRules:SetNetPersistentVar(NV_AMBULAS_FIGHT_STAGE, stage)
            -- play capital ship animation
            DIALOG.PlayGlobalTransmission(_T.TransmissionSet, Symbol("AmbulasBossFailure"), 0)
            capitalShipCinLeaveTrigger:FirePort("StartPlaying")
            stage = 99
            gameRules:SetNetPersistentVar(NV_AMBULAS_FIGHT_STAGE, stage)
            Sleep(15)
            gGameRules:EndGame(Engine.GameRules_GS_FAILURE)
        end
    end    
end
