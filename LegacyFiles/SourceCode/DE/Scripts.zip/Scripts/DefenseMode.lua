lockDownCooldown = 180.0

function Unlock()
    local DoorHintTags = gRegion:FindTagged(Symbol("DoorHint")) --Enable door hints
        if not IsNull(DoorHintTags) then
        for x=1,#DoorHintTags do
            DoorHintTags[x]:FirePort("Unlock")
        end
    end
    
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()
    aiDir:SetLockDown(false, lockDownCooldown)
    
end

function Lockdown()
     
   --local DoorHintTags = gRegion:FindTagged(Symbol("DoorHint"))
    --if not IsNull(DoorHintTags) then
        --for x=1,#DoorHintTags do
            --DoorHintTags[x]:FirePort("Lock")
        --end
    --end
    
 


    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()
    aiDir:SetLockDown(true, lockDownCooldown)
    
end

