rockDecoType = Type()
submergeAnim = Resource()

function RocksSubmerge(spawner)
    --Find the rock deco, play the submerge anim, kill the deco
    local decoArray = gRegion:FindAll(rockDecoType, spawner:GetPosition(), 0, 5)
    --local rDeco = parent:GetAttachment(rockDecoType)
    --deco isn't attached, gRegion search instead
    local rDeco
    if not IsNull(decoArray) then
        rDeco = decoArray[1]
        if not IsNull(decoArray[2]) then
            local temp = decoArray[2]
            temp:Destroy()
        end
        if not IsNull(rDeco) then
            rDeco:PlayAnimation(submergeAnim, true, false)
        end
        if not IsNull(rDeco) then
            rDeco:Destroy()
        end
    end
    spawner:Destroy() --Spawner is set to permanent to keep script running through animations
end