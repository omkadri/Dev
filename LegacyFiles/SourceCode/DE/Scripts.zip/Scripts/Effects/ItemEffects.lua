param = Symbol()
startingValue = 1
energyMultValue = 1

local function _CheckForHub()
    local gameRules = gGameRules
    return(gameRules:IsA(gLotusHubGameRulesType) or gameRules:IsA(gLotusAttractModeGameRulesType))
end

function UpdateWithEnergyLevel(entity)

    if IsNull(entity) then
        return
    end
    
    Sleep(0)
    local IsInHub = _CheckForHub()
    if IsInHub then
        return
    end
    
    local avatar = entity:GetAttachRoot()

    if IsNull(avatar) then
        return
    end

    local suit = avatar:InventoryControl():GetActivePowerSuit()
    if IsNull(suit) then
        return
    end

    local meleeWeapon = avatar:InventoryControl():GetMeleeWeapon()
    local value = 1
    
    while not IsNull(entity) and not IsNull(suit) do
        if (not IsNull(meleeWeapon) and meleeWeapon:GetChanneling()) then
            value = startingValue + energyMultValue
        else
            value = startingValue + energyMultValue * suit:GetCurEnergy() / suit:GetMaxEnergy()
        end
        entity:SetMaterialParam(param, value)
        Sleep(0.05)
    end
end