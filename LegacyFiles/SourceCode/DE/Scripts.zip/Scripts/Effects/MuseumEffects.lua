

function VitruvianDeco(deco)
    local pos = deco:GetSimPosition()
    local t = FRand() * 5
    local speed = Random(0.2, 0.5)
    local movementScaleX = Random(-1, 1)
    local movementScaleZ = (1 - math.abs(movementScaleX))
    if FRand() > 0.5 then
        movementScaleZ = -movementScaleZ
    end
    local movementScaleY = -1
    if FRand() > 0.5 then --Some will go up
        movementScaleY = 1
        pos.y = pos.y - 2
    end
    while true do
        local dt = DeltaTime()
        local s = math.sin(t)
        s = s * s * s * s
        pos.y = pos.y + dt * (1 - s) * movementScaleY
        pos.x = pos.x - dt * s * movementScaleX
        pos.z = pos.z - dt * s * movementScaleZ
        deco:SetPosition(pos)
        Sleep(0)
        t = t + dt * speed
    end
end

function ProjUpdate(proj)
    local parent = proj:GetAttachParent()
    if IsNull(parent) then
        return
    end
    local children = parent:GetAttachedChildren()
    for i, child in ipairs(children) do
        if not IsNull(child:GetMesh()) then
            proj:AddProjectorToEntity(child, EMPTY_SYMBOL)
        end
    end
end