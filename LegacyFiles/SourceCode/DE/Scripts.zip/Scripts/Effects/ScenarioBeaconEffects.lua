laserType = Type()
spawnBeamType = Type()

function CondrixScan(deco)
    local numLasers = 1
    local basePitch = -25
    local lasers = {}
    for i=1, numLasers do
        local laser = deco:Attach(laserType, EMPTY_SYMBOL)
        table.insert(lasers, laser)
    end
    local t = 0
    local laserRot = Rotation()
    while true do
        for i, laser in ipairs(lasers) do
            laserRot.heading = math.sin(i * 1 / math.pi + t * 0.4) * 30
            laserRot.pitch = - i * 8 + basePitch
            laser:SetAttachLocalSpace(ZERO_VECTOR, laserRot)
        end
        Sleep(0)
        t = t + DeltaTime()
    end
end

function SpawnEffect(spawner)
    local pos = spawner:GetPosition()
    local condrixWeakPoint = gRegion:FindFirstTaggedInRadius(Symbol("CondrixWeakPoint"), pos, 0, 40)
    if IsNull(condrixWeakPoint) then
        return
    end

    local beam = gRegion:CreateEntity(spawnBeamType, pos, Rotation(0, -90, 0))
    if not IsNull(beam) then
        beam:SetEndPoint(condrixWeakPoint:GetPosition())
    end
end