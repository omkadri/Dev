beamType = Type()
smallBeamType = Type()
trailType = Type()
questTrailSound = Type("/Lotus/Sounds/Gameplay/BardQuest/MissionTwo/BardQuestFlyingMusicLoopSeq")
questTrailBits = Type("/Lotus/Fx/Quests/Bard/BardQuestThingBitsPS")

local sFadeParams = Symbol("FadeParams")

function LaserEffects(laser)

    local beams = {}
    local timers = {}
    for i=1, 6 do
        local beam = laser:Attach(beamType, EMPTY_SYMBOL)
        if not IsNull(beam) then
            table.insert(beams, beam)
            table.insert(timers, FRand())
            beam:SetMaterialParam(sFadeParams, 15 + 15 * i, 10)
        end
    end
    
    local cVec = Vector(0, 0, 50)
    local rRot = Rotation()
    for i=1, 10 do
        local beam = laser:Attach(smallBeamType, EMPTY_SYMBOL)
        if not IsNull(beam) then
            rRot.heading = Random(-180, 180)
            rRot.pitch = Random(-20, 180)
            rRot.bank = Random(-180, 180)
            beam:SetEndPoint(RotateVector(cVec, rRot))
        end
    end
    
    local trailRot = Rotation(0, -90, 0)
    local trail = laser:Attach(trailType, EMPTY_SYMBOL, ZERO_VECTOR, trailRot)
    local endPoint = Vector()
    local thisEnd = Vector()
    local curvePoint = Vector(5, 5, 0.5)
    while not IsNull(laser) do
        endPoint = laser:GetEndPoint()
        if not IsNull(trail) then
            trail:SetAttachLocalSpace(Vector(0, 0, Length(endPoint)), trailRot)
        end
        for i=1, #beams do
            thisEnd = endPoint * (0.4 + i * 0.1)
            local beam = beams[i]
            if not IsNull(beam) then
                beam:SetEndPoint(thisEnd)
            end
            if timers[i] < 0 then
                beam:SetCurvePoint(curvePoint, math.random(0, 1))
                timers[i] = 3 + FRand() * 3
            end
            timers[i] = timers[i] - DeltaTime()
        end
        Sleep(0)
    end
end

function QuestTrail(deco)
    
    local seq = deco:Attach(questTrailSound, Symbol("GAME_SWARMJOINT_2"))
    local soundInst = nil
    while soundInst == nil do
        soundInst = seq:GetSoundInstance()
        Sleep(0)
    end
    local attachments = deco:GetAllAttachments(gLensFlareType)
    local bitsAttach = deco:GetAllAttachments(questTrailBits)
    while not IsNull(soundInst) do
        local amplitude = soundInst:GetCurAmplitude()
        --print(amplitude)
                
        for i=1,#attachments do
            local lensFlare = attachments[i]
            lensFlare:SetOpacity(Lerp(0.3, 5.0, amplitude))
        end
        for i=1,#bitsAttach do
            local bits = bitsAttach[i]
            local spew = math.pow(amplitude * 30, 2)
            if spew > 120 then spew = 120 end
            --local speed = Lerp(0.5, 5, amplitude)
            --local life = Lerp(0.3, 1.5, amplitude)
            local size = Lerp(0.1, 0.5, amplitude)
            
            --print(life)
            bits:SetSpewCount(spew,spew, false)
            --bits:SetSpeed(speed, speed)
            --bits:SetLifeSpan(life)
            bits:SetSize(size,size,false)
        end
        Sleep(0.06)
    end
    
end