leadUpFxToKill = {WeakResource()}
baseEnergyColor = Color(246, 104, 0, 255)  
timeLength = 1.25

local CLOAKHDR = Symbol("CloakHDR")

local ragdollType = Type("/EE/Types/Physics/Ragdoll")
local effectTag = Symbol("EffectsDeco")
local tennoAvatarType = WeakResource("/Lotus/Types/Player/TennoAvatar")   

local function AllAttachments(avatar)
    local attachments = avatar:GetAllAttachments(gDecorationType)
    local finalItems = {}
    for i, temp in ipairs(attachments) do
        local material = temp:GetMaterialInSlot(0)
        local atten = material:GetParam("UnlitAtten", 0)
        if (atten > 100) and not (temp:GetTag() == effectTag) then -- If these are true, it's an effect, so don't attach
            table.insert(finalItems, temp)
        end
    end
    table.insert(finalItems, avatar)
    return finalItems
end

function DissolveTheEnemy(spawner)
    Sleep(0)
    if IsNull(spawner) then
        return
    end
    local avatar = spawner:GetAttachRoot()
    local entity = avatar
    if IsNull(entity) then
        return
    end
      
    --Find the source, do we care?
    if entity:IsA(ragdollType) then
        avatar = entity:GetAvatarOwner()
    end
    
    if IsNull(avatar) or not avatar:IsA(gBaseAvatarType) then
        return
    end
    
    local weapon = spawner:GetCreator()
    local energyColor = baseEnergyColor
    if not IsNull(weapon) and weapon:IsA(gLotusWeaponType) then
        local playerCustomization = weapon:GetCustomization()
        local colors = playerCustomization:GetColors(Lotus_Game.PrimaryColors)
        if colors:Initialized(Lotus_Game.EnergyColor) then
            energyColor = Color(colors.mEnergyColor)
        end
    end
    
    local killed = false
    local ragdoll = nil
    avatar:SetMaterialParam(CLOAKHDR, energyColor.red / 50, energyColor.green / 50, energyColor.blue / 50, 1)
    
    local numRagdolls = avatar:GetNumRagdolls()
    if numRagdolls > 0 then
        for i = 0, numRagdolls - 1 do
            ragdoll = avatar:GetRagdollByIndex(i)
            if not IsNull(ragdoll) then
                ragdoll:SetMaterialParam(CLOAKHDR, energyColor.red / 50, energyColor.green / 50, energyColor.blue / 50, 1)
            end
        end
    end

    local t = 0
    local setupRagdollCount = 0
    while t < timeLength and not IsNull(avatar) do
        if not IsNull(avatar) then
            if (avatar:GetHealth() <= 0 and not killed) then
                killed = true
            end
        end
        if killed and not IsNull(avatar) then
            numRagdolls = avatar:GetNumRagdolls()
            if numRagdolls > 0 then
                for i = 0, numRagdolls - 1 do
                    ragdoll = avatar:GetRagdollByIndex(i)
                    if not IsNull(ragdoll) then
                        if setupRagdollCount < 5 then
                            ragdoll:SetMaterialParam(CLOAKHDR, energyColor.red / 50, energyColor.green / 50, energyColor.blue / 50, 1)
                            for i=1, #leadUpFxToKill do
                                local temp = ragdoll:GetAttachment(leadUpFxToKill[i])
                                if not IsNull(temp) then
                                    temp:Destroy()
                                end
                            end
                        end
                        ragdoll:SetDissolve(t / timeLength)
                    end
                end
                --haveRagdoll = true
                setupRagdollCount = setupRagdollCount + 1
            end
        end
        avatar:SetDissolve(t / timeLength)
        t = t + DeltaTime()
        Sleep(0)
    end
    
    Sleep(2)
    if IsNull(avatar) then
        return
    end
    local numRagdolls = avatar:GetNumRagdolls()
    if numRagdolls > 0 then
        for i = 0, numRagdolls - 1 do
            local rag = avatar:GetRagdollByIndex(i)
            rag:Destroy()
        end
    else
        --Need this check in PvP to ensure that we don't destroy player avatars (is this necessary in PvE anyways?)
        local npcAgent = avatar:GetAgent()
        local player = avatar:GetPlayer()
            
        if IsNull(npcAgent) then
            return
        end
            
        if not IsNull(player) then
            return
        end
            
        if avatar:IsA(tennoAvatarType) then
            return
        end
            
        if not IsNull(avatar) then
            avatar:Destroy()
        end
    end
end