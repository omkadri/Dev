local aiLib = require "Lotus.Scripts.Libs.AILib"

Origin = Symbol("TeleportEffectOrigin")
TimeLength = 2.0
PeakStart = 0.5
PeakEnd = 1.5
MaxDistance = 500

--TeleportSpawnTarget
--teleportDecoration = Type()           --  "/Lotus/Fx/Grineer/Teleport/TeleportSplineSkelDecoAutonomous"       - Non-Replicated Decoration type to spawn 
--beamOutEffectSpawner = Type() -- "/Lotus/Fx/Grineer/Teleport/TeleportLeaveAutonomous" --  One-Shot Non-Replicated Spawner to fire when the avatar departs 
--beamInEffectSpawner = Type()      -- "/Lotus/Fx/Grineer/Teleport/TeleportArriveAutonomous"    --  One-Shot Non-Replicated Spawner to fire when the avatar arrives
--departAnimation = Resource()      -- "/Lotus/Animations/VS/Grineer/AggressiveLoop_anim.fbx"           -- Do not use any other animations
--arriveAnimation = Resource()          -- "/Lotus/Animations/VS/Grineer/HeavyLandingDisplacer_anim.fbx"    -- Do not use any other animations in the spawn control

-- New Code Driven Method
beamPoint = Instance()          --  The point the beam travels To/From when teleporting Out/In (Probably a displacer nozzle)
warpPoint = Instance()          --  The point to teleport the instigator to (either their destination, or a hidden location if teleporting OUT)
warpRes = Resource()            --  'WarpMovementType' or one of its sub-types

local UVSCALAR = Symbol("uvScalar")
local FADETIME = Symbol("FadeTime")

--[[
    SetupWarpEffect
        Create, stretch and align a warp effect based on a start and end point
--
local function SetupWarpEffect( startPos, endPos )

    --  Create Decoration
    local warpDeco = gRegion:CreateEntity(teleportDecoration, endPos, ZERO_ROTATION)
    
    -- Scale UV so it doesn't look stretched
    local distance = Distance(startPos, endPos)
    local uvScaleValue = distance/50
    warpDeco:SetMaterialParam(UVSCALAR, 1, uvScaleValue)

    -- Calculate morphs
    local amountOne = math.random()
    local amountTwo = math.random()*(1-amountOne)
    local amountThree = 1 - amountOne - amountTwo

    warpDeco:SetMorphValue(Symbol("TendrilMorphs.MorphOne"), amountOne*distance/MaxDistance)
    warpDeco:SetMorphValue(Symbol("TendrilMorphs.MorphTwo"), amountTwo*distance/MaxDistance)
    warpDeco:SetMorphValue(Symbol("TendrilMorphs.MorphThree"), amountThree*distance/MaxDistance)


    -- Rotate to face the target
    warpDeco:FaceTo( startPos )

    return warpDeco
end--]]

--[[
    RunWarpEffect
        Runs through the warp effect over Time
--
local function RunWarpEffect( targetAvatar, teleportPos, warpDeco, outPos, inPos, outEffectType, inEffectType, maxTime, fadeInTime, fadeOutTime, startsHidden )

    local hasArrived = false
    local hasMaterialized = false
    local session = gMatchingService:GetSession()

    --  Freeze the agent
    if IsNull(session) or gMatchingService:IsHost() then 
        local targetAgent = targetAvatar:GetAgent()
        if not IsNull( targetAgent ) then
            targetAgent:SetPaused(true, powerSymbol)
        end
    end

    -- Play the startup effects. 
    if targetAvatar:IsLocallyAuthoritative() then
        targetAvatar:SetVisibility(not startsHidden, true)
        targetAvatar:MotionControl():SetSpeedMultiplier(0.0)                                        --Freeze the character in place (good for AI)
        targetAvatar:PlayAnimation(departAnimation, false, Engine.ATMM_PHYSICS_DRIVEN)
    end    
    
    if not IsNull( outEffectType ) then         --  Play beam out effect
        local outSpawner = gRegion:CreateEntity(outEffectType, outPos, ZERO_ROTATION)
        -- Consider doing an attach: effect->AttachTo(mAvatar, EMPTY_SYMBOL);
        outSpawner:FirePort("Enable")           --  Spawner should clean itself up. 
    end
           
    -- Run the effect
    local curTime = 0
    local fadePcnt, materialPcnt
    while curTime < maxTime do
    
        --  Beam has arrived. Play arrival effects
        if not hasArrived and curTime > fadeInTime then

            hasArrived = true

            if not IsNull( inEffectType ) then          --  Play beam in effect
                local inSpawner = gRegion:CreateEntity(inEffectType, inPos, ZERO_ROTATION)  --  Spawn effect where the beam ends up
                inSpawner:FirePort("Enable")            --  Spawner should clean itself up. 
            end

            if targetAvatar:IsLocallyAuthoritative() then
    --            targetAvatar:WallSlideControl():ExitWallSlide( Engine.CET_NONE, true )
                targetAvatar:Teleport( teleportPos )                                            -- Physical teleportation
    --          targetAvatar:MotionControl():SetTorsoFromView( teleportPoint:GetRotation() )        -- Physical rotation
            end

        end 
    
        -- Grineer has started fading back in. Animate, orientate, open fire.
        if not hasMaterialized and curTime > maxTime - fadeOutTime then
            hasMaterialized = true

            if targetAvatar:IsLocallyAuthoritative() then
                targetAvatar:SetVisibility(true, true)          
                targetAvatar:MotionControl():SetSpeedMultiplier( 1.0 )                              --  Unfreeze the avatar
                targetAvatar:PlayAnimation(arriveAnimation, false, Engine.ATMM_ANIMATION_DRIVEN)    
            end
        end

        fadePcnt = mathsLib:CalcFadeEnvelope( curTime, maxTime, fadeInTime, fadeOutTime )

        -- Advance the effect
        if hasArrived then
            warpDeco:SetMaterialParam( FADETIME, Lerp( 1.0, 0.5, fadePcnt ) )
        else
            warpDeco:SetMaterialParam( FADETIME, Lerp( 0.0, 0.5, fadePcnt ) )
        end 

        -- Fade the Avatar
        targetAvatar:SetDissolve( fadePcnt )       
        
        curTime = curTime + DeltaTime() 
        
        Sleep(0)

    end 

    -- Tidy up Agent
    if IsNull(session) or gMatchingService:IsHost() then 
        local targetAgent = targetAvatar:GetAgent()
        if not IsNull( targetAgent ) then         
            targetAgent:SetPaused(false, powerSymbol)
            targetAgent:StopCurrentBehavior() 
        end
    end

    targetAvatar:SetDissolve( 0 )

end--]]

--[[    Must be run on Instigator! Run on BOTH.
    TeleportIn_OnInstigator
        Teleport a Grineer hidden offscreen into the scene, with the effect coming from a displacer
--]]
function Teleport_IN_OnInstigator(instigator)
    
    local beamStartPos = beamPoint:GetPosition()
    local beamEndPos = warpPoint:GetPosition()
    local warpPos = warpPoint:GetPosition()
    local warpRot = warpPoint:GetRotation()
   
    instigator:MotionControl():ScriptStartWarpMovement(warpRes, beamStartPos, beamEndPos, warpPos, warpRot)
    
end--]]


--[[    Must be run on Instigator! Run on BOTH.
    Teleport_ACCROSS_OnInstigator
        Transport target avatar to a specified waypoint
        When run, This creates, stretches and aligns a warp effect with all the trimmings. 
    
            Only has minimal set up for AI currently. See TransporterBeam.lua for a more complete setup if necessary
--]]
function Teleport_ACCROSS_OnInstigator(instigator)
    
    local beamStartPos = instigator:GetPosition()
    local beamEndPos = warpPoint:GetPosition()
    local warpPos = warpPoint:GetPosition()
    local warpRot = warpPoint:GetRotation()
   
    instigator:MotionControl():ScriptStartWarpMovement(warpRes, beamStartPos, beamEndPos, warpPos, warpRot)
    
end--]]


--[[    Must be run on Instigator! Run on BOTH.
    TeleportOut_OnInstigator
        Teleports the Grineer out of sight, so they can be removed. The effect is designed to go through a displacer
--]]
function Teleport_OUT_OnInstigator(instigator)
    
    local beamStartPos = instigator:GetPosition()
    local beamEndPos = beamPoint:GetPosition()
    local warpPos = warpPoint:GetPosition()
    local warpRot = warpPoint:GetRotation()
   
    instigator:MotionControl():ScriptStartWarpMovement(warpRes, beamStartPos, beamEndPos, warpPos, warpRot)
    
end--]]


--[[    SPECIAL: Run on instigator via a ScriptInstigator.lua function that is place in the OnSpawn slot. Run on BOTH.
    Teleport_SPAWN_OnInstigator
        A warp effect designed to be run when spawning an enemy.
            The enemy spawns (hidden) at the teleport destination, and they are fake-warped there. 
--]]
function Teleport_SPAWN_OnInstigator(instigator)

    local beamStartPos = beamPoint:GetPosition()
    local beamEndPos = instigator:GetPosition()
    local warpPos = instigator:GetPosition()
    local warpRot = instigator:GetRotation()
   
    instigator:MotionControl():ScriptStartWarpMovement(warpRes, beamStartPos, beamEndPos, warpPos, warpRot)
    
end--]]




--[[
    Morph Functions
        The following functions are placed in the EntityScript slot of certain tendril variants. They fire the moment a tendril is created and morph its path autonomously.
--]]
function MorphTendril(deco)
    local t = 0.0
    local fading = 0.0
    local val = 0.0
    local v = 0.0
    local originPoints = gRegion:FindTagged(Origin)
    --Dirty!  Need code support to feed this value since we can find multiple Origins
    if not IsNull(originPoints) then
        local oTemp = originPoints[1]
        local oPos = oTemp:GetPosition()
        local dPos = deco:GetPosition()
        local distance = Distance(oPos, dPos)
        
        --Scale UV so it doesn't look stretched
        local uvScaleValue = 0.5 + distance/35
        deco:SetMaterialParam(UVSCALAR, 1, uvScaleValue)
        
        local amountOne = math.random()
        local amountTwo = math.random()*(1-amountOne)
        local amountThree = 1 - amountOne - amountTwo
        deco:SetMorphValue(Symbol("TendrilMorphs.MorphOne"), amountOne*distance/MaxDistance)
        deco:SetMorphValue(Symbol("TendrilMorphs.MorphTwo"), amountTwo*distance/MaxDistance)
        deco:SetMorphValue(Symbol("TendrilMorphs.MorphThree"), amountThree*distance/MaxDistance)
        while t < TimeLength do
            if t < PeakStart then
                fading = t/PeakStart
            else if t < PeakEnd then
                    fading = 1
                else
                    v = 1.0
                    fading = 1 - (t-PeakEnd)/(TimeLength-PeakEnd)
                end
            end
            if fading < 0 then
                fading = 0
            end
            val = Lerp(v, 0.5, fading)
            deco:SetMaterialParam(FADETIME, val)
            t = t + DeltaTime() 
            Sleep(0.0)
        end
    end
end

--Useless function to loop the effect for testing purposes
function TestMorph(deco)
    local t = 0.0
    local fading = 0.0
    local val = 0.0
    local v = 0.0
    while true do
        --Lets test this
        t = 0.0
        v = 0.0
        local distance = math.random(10,80)
        
        local uvScaleValue = 0.5 + distance/35
        deco:SetMaterialParam(UVSCALAR, 1, uvScaleValue)
        
        local amountOne = math.random()
        local amountTwo = math.random()*(1-amountOne)
        local amountThree = 1 - amountOne - amountTwo
        deco:SetMorphValue(Symbol("TendrilMorphs.MorphOne"), amountOne*distance/MaxDistance)
        deco:SetMorphValue(Symbol("TendrilMorphs.MorphTwo"), amountTwo*distance/MaxDistance)
        deco:SetMorphValue(Symbol("TendrilMorphs.MorphThree"), amountThree*distance/MaxDistance)
        while t < TimeLength do
            if t < PeakStart then
                fading = t/PeakStart
            else if t < PeakEnd then
                    fading = 1
                else
                    v = 1.0
                    fading = 1 - (t-PeakEnd)/(TimeLength-PeakEnd)
                end
            end
            if fading < 0 then
                fading = 0
            end
            val = Lerp(v, 0.5, fading)
            deco:SetMaterialParam(FADETIME, val)
            t = t + DeltaTime() 
            --t = t%1
            Sleep(0.0)
        end
        Sleep(0.0)
    end
end

--Search for tagged Spawner decorations in level and morph to it
function MorphTendrilFromSpawner(deco)
    local t = 0.0
    local fading = 0.0
    local val = 0.0
    local v = 0.0
    local spawnerToUse = gRegion:FindNearestTagged(Origin, deco:GetPosition())
    
    
    if not IsNull(spawnerToUse) then
        local oPos = spawnerToUse:GetPosition()
        local dPos = deco:GetPosition()
        local distance = Distance(oPos, dPos)
            
        
        --Scale UV so it doesn't look stretched
        local uvScaleValue = distance/50
        deco:SetMaterialParam(UVSCALAR, 1, uvScaleValue)
        
        --Calculate morphs
        local horizDis = Distance(Vector(oPos.x, dPos.y, oPos.z), dPos)
        local vertDis = math.abs(oPos.y - dPos.y)
        deco:SetMorphValue(Symbol("TendrilMorphs.MorphOne"), horizDis/MaxDistance)
        deco:SetMorphValue(Symbol("TendrilMorphs.MorphTwo"), vertDis/MaxDistance)
        
        --Rotate to face spawner
        local tempX = oPos.x - dPos.x
        local tempZ = oPos.z - dPos.z
        local decoHead = math.atan2(tempX, tempZ)
        local decoRot = Rotation()
        decoRot.heading = math.deg(decoHead)
        deco:SetRotation(decoRot)
        
        --Fade material
        while t < TimeLength do
            if t < PeakStart then
                fading = t/PeakStart
            else if t < PeakEnd then
                    fading = 1
                else
                    v = 1.0
                    fading = 1 - (t-PeakEnd)/(TimeLength-PeakEnd)
                end
            end
            if fading < 0 then
                fading = 0
            end
            val = Lerp(v, 0.5, fading)
            deco:SetMaterialParam(FADETIME, val)
            t = t + DeltaTime() 
            Sleep(0.0)
        end
    end
end
