effectType = Type()
animEvent = String()

local mEffect = nil

function EMO_START(avatar)
    if IsNull(avatar) then
        return
    end
    local suit = avatar:InventoryControl():GetActivePowerSuit()
    if IsNull(suit) then
        return
    end

    if not IsNull(animEvent) then
        avatar:SuspendScriptUntilAnimEvent(animEvent, 1)
    end
    mEffect = avatar:Attach(effectType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, suit)
end

function EMO_LOOP(avatar, emoteType)
    while not IsNull(mEffect) do
        Sleep(0.25)
    end
end

function EMO_END(avatar)
    if not IsNull(mEffect) then
        mEffect:Destroy()
    end
end