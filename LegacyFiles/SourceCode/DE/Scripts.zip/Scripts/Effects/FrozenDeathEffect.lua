effectsToCreate = {Type()}
effectDeco = Type()
frozenMaterial = WeakResource()
smallShatter = Type()
largeShatter = Type()
sleepTime = 2.0
dissolveSpeed = 0.25


local HeightTotalParam = Symbol("HeightTotal")
local HeightThresholdParam = Symbol("HeightThreshold")


local function SetDissolve(entity, t)
    entity:SetDissolve(t)
    local children = entity:GetAllAttachments(gEntityType)
    for i=1,#children do
        children[i]:SetDissolve(t)
    end
end

local function FindHeight(entity)
    local boundsMin = entity:GetBoundsMin()
    local boundsMax = entity:GetBoundsMax()
    local h = boundsMax.y - boundsMin.y
    return h
end

local function MaterialHeight(entity, param, val)
    entity:SetMaterialParam(param, val)
    local extras = entity:GetAllAttachments(gDecorationType)
    for i, temp in ipairs(extras) do
        local c = temp:GetCenter()
        gRegion:CreateEntity(smallShatter, c, ZERO_ROTATION) --Remove extras because they look glitchy
        temp:SetMaterialParam(HeightThresholdParam, 1)
    end
end

local function MaterialEffects(entity, param, val)
    entity:SetMaterialParam(param, val)
end

function FxMonitor(entity)
    Sleep(0)
    local c = entity:GetCreator()
    while not IsNull(c) do
        if c:IsA(gBaseAvatarType) and not IsNull(c:GetRagdoll()) then --Frozen avatar turned into a ragdoll, exit the fx
            entity:Destroy()
        end
        Sleep(0)
    end
    entity:Destroy()
end

function Dissolve(spawner)
    Sleep(2)
    local t = 0
    local ragdoll = spawner:GetAttachParent()

    if not IsNull(ragdoll) then
        
        local proj = ragdoll:GetAllAttachments(gDynamicProjectorType)
        for i=1, #proj do
            local temp = proj[i]
            temp:Destroy()
        end
        
        local height = FindHeight(ragdoll)
        MaterialHeight(ragdoll, HeightTotalParam, height)
        
        local pos = ragdoll:GetSimPosition()
        local fxPos = pos + Vector(0, height, 0)
        local effects = {}
        local symFxMonitor = Symbol("FxMonitor")
        for i=1, #effectsToCreate do
            local temp = gRegion:CreateEntity(effectsToCreate[i], fxPos, ZERO_ROTATION, ragdoll)
            if not IsNull(temp) then
                temp:ScriptRunChildScript(symFxMonitor, false)
                table.insert(effects, temp)
            end
        end
        local deco = gRegion:CreateEntity(effectDeco, pos + Vector(0, 0, 0.5), Rotation(0, 90, 0))
        if not IsNull(deco) then
            deco:ScriptRunChildScript(symFxMonitor, false)
            table.insert(effects, deco)
        end
        
        local health = 0
        local isAvatar = false
        local isPlayer = false
        if ragdoll:IsA(gBaseAvatarType) then
            ragdoll:DamageControl():SetCanRagdoll(false)  --Once melting has started, let's not form a ragdoll if destroyed (just shatter and leave it be)
            health = ragdoll:GetHealth()
            isAvatar = true
            isPlayer = ragdoll:GetPlayer()
        end
    
        while t < 1 and not IsNull(ragdoll) do
            MaterialEffects(ragdoll, HeightThresholdParam, t)
            local fxPos = pos + Vector(0, height * (1 - t) - 0.3, 0)
            for i, temp in ipairs(effects) do
                if not IsNull(temp) then
                    temp:SetPosition(fxPos)
                end
            end
            
            if isAvatar then
                if (ragdoll:GetHealth() < health) then --Was hit, so let's destroy
                    if t > 0.6 then --Mesh is almost melted, play a smaller effect
                        gRegion:CreateEntity(smallShatter, pos + Vector(0, 0.5 * height * (1 - t) - 0.3, 0), ZERO_ROTATION)
                    else
                        gRegion:CreateEntity(largeShatter, pos + Vector(0, 0.5 * height * (1 - t), 0), ZERO_ROTATION)
                    end
                    if not isPlayer then
                        ragdoll:Destroy()
                    end
                end
            end
            Sleep(0.0)
            t = t + DeltaTime() * 0.25
        end
        
        for i, temp in ipairs(effects) do
            --temp:Destroy()
        end
        
        if not IsNull(ragdoll) then
            if isPlayer then
                -- Can't destroy, we'll need it to respawn/control camera
                ragdoll:SetVisibility(false, true)
            else
                ragdoll:Destroy()
            end
        end
    end
end


function DissolveStone(spawner)
    Sleep(sleepTime)
    local t = 0
    local ragdoll = spawner:GetAttachParent()
    while IsNull(ragdoll) do
        Sleep(0)
        ragdoll = spawner:GetAttachParent()
    end
    if not IsNull(ragdoll) then
        
        local proj = ragdoll:GetAllAttachments(gDynamicProjectorType)
        for i=1, #proj do
            local temp = proj[i]
            temp:Destroy()
        end
        
        local height = FindHeight(ragdoll)

        local pos = ragdoll:GetSimPosition()

        local health = 0
        local isAvatar = false
        local isPlayer = false
        if ragdoll:IsA(gBaseAvatarType) then
            ragdoll:DamageControl():SetCanRagdoll(false)  --Once melting has started, let's not form a ragdoll if destroyed (just shatter and leave it be)
            health = ragdoll:GetHealth()
            isAvatar = true
            isPlayer = ragdoll:GetPlayer()
        end
    
        while t < 1 and not IsNull(ragdoll) do
            ragdoll:SetDissolve(t)

            if isAvatar then
                if (ragdoll:GetHealth() < health) then --Was hit, so let's destroy
                    if t > 0.6 then --Mesh is almost melted, play a smaller effect
                        gRegion:CreateEntity(smallShatter, pos + Vector(0, 0.5 * height * (1 - t) - 0.3, 0), ZERO_ROTATION)
                    else
                        gRegion:CreateEntity(largeShatter, pos + Vector(0, 0.5 * height * (1 - t), 0), ZERO_ROTATION)
                    end
                    if not isPlayer then
                        ragdoll:Destroy()
                    end
                end
            end
            Sleep(0.0)
            t = t + DeltaTime() * dissolveSpeed
        end

        if not IsNull(ragdoll) then
            if isPlayer then
                -- Can't destroy, we'll need it to respawn/control camera
                ragdoll:SetVisibility(false, true)
            else
                ragdoll:Destroy()
            end
        end
    end
end

function LeadUpFrozenCheck(spawner)
    local parent = spawner:GetAttachRoot()
    if not IsNull(parent) then
        local material = parent:GetMaterialInSlot(0)
        if IsNull(material) then
            return
        end
        if material:IsA(frozenMaterial) then
            spawner:Destroy()
        end
    end
end

function SmallShatterFade(spawner)
    local parent = spawner:GetAttachRoot()
    if IsNull(parent) then
        return
    end
    parent:SetMaterialParam(HeightTotalParam, 1)
    local t = 0
    while t < 1 do
        parent:SetMaterialParam(HeightThresholdParam, t)
        t = t + DeltaTime() * 3
        Sleep(0)
    end
end

function SmallStoneShatterFade(spawner)
    local parent = spawner:GetAttachRoot()
    if IsNull(parent) then
        return
    end
    local t = 0
    while t < 1 do
        parent:SetDissolve(t)
        t = t + DeltaTime() * 3
        Sleep(0)
    end
end