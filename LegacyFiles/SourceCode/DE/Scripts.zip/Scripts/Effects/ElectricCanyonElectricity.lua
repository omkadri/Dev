DoRotation = false

RotRandLoZ = 0
RotRandHiZ = 360

DoOpacity = true
--UAParam = String("UnlitAtten")
UADelay = 0
UABegin = 1
UAEnd = 0
DoRandOTime = true
UATimeLength = 0.2
UATimeLengthH = 0.5

RandUVFlip = true

DoRandomNoise = true 
RandomOffsetL = 1
RandomOffsetH = 8
NoiseSpeedL = 1
NoiseSpeedH =  10
nAmtL = 0
nAmtH = 10
nFrqL = Vector()
nFrqH = Vector()
nSclL = Vector()
nSclH = Vector(3,3,3)

local PANANDSCALESECOND = Symbol("PanAndScaleSecond")
local RANDOMOFFSET = Symbol("randomOffset")
local NOISESPEED = Symbol("NoiseSpeed")
local NOISESCALE = Symbol("NoiseScale")

local function easeOutExpo(t, b, c, d)
    if (t==d) then
        return b+c
    else
        return c * (-math.pow(2, -10 * t/d) + 1) + b
    end
end

function Combined(deco)
    if DoRotation == true then
        deco:ScriptRunChildScript(Symbol "MeshRotation", false)
    end
    if DoOpacity == true then
        deco:ScriptRunChildScript(Symbol "Opacity", false)
    end
    if RandUVFlip == true then
        local UVFlip = math.random(0,1)
        if UVFlip < 1 then
            deco:SetMaterialParam(PANANDSCALESECOND, -2, 0, 0.3, 1)
        end
    end
    if DoRandomNoise == true then
        local randOff = math.random(RandomOffsetL, RandomOffsetH)
        local nSpeed = math.random(NoiseSpeedL, NoiseSpeedH)
        local noiseAmount = (math.random(nAmtL*1000,nAmtH*1000))/1000
        local noiseFrqX = (math.random(nFrqL.x*1000,nFrqH.x*1000))/1000
        local noiseFrqX = (math.random(nFrqL.y*1000,nFrqH.y*1000))/1000
        local noiseFrqX = (math.random(nFrqL.z*1000,nFrqH.z*1000))/1000
        local noiseSclX = (math.random(nSclL.x*1000,nSclH.x*1000))/1000
        local noiseSclY = (math.random(nSclL.y*1000,nSclH.y*1000))/1000
        local noiseSclZ = (math.random(nSclL.z*1000,nSclH.z*1000))/1000
        deco:SetMaterialParam(RANDOMOFFSET, randOff)
        deco:SetMaterialParam(NOISESPEED, nSpeed)
        --deco:SetMaterialParam(NOISEFREQ, noiseFrq)
        deco:SetMaterialParam(NOISESCALE, noiseSclX, noiseSclY, noiseSclZ)
    end

end
    
function Opacity(deco)
    Sleep(UADelay)
    local t = 0
    local val
    local TimeLength = UATimeLength
    if DoRandOTime ==true then
        TimeLength = (math.random(UATimeLength*100,UATimeLengthH*100))/100
    end
    while t < UATimeLength do
        val = easeOutExpo(t, UABegin, UAEnd-UABegin, TimeLength)        
        deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, val)
        t = t + DeltaTime()
        Sleep(0)
    end
    while t > UATimeLength do
        val = UAEnd
        deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, val)
        t = t + DeltaTime()
        Sleep(0)
    end
end

-- Rotate deco to get faster or slower as it spins on Y, random values for x & z
function MeshRotation(deco)
    local RotRandZ = math.random (RotRandLoZ, RotRandHiZ)
    local decoRot = Rotation()
    decoRot.bank =  -90
    decoRot.heading =  0
    decoRot.pitch =  RotRandZ
    deco:SetRotation(decoRot)
    Sleep(0)
end