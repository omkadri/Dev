Delay = 0
trailType = Resource()
labelType = Resource("/Lotus/Types/Game/MarkerInfos/SpaceEnemyMarkerInfo")
doDissolve = false
dissolveDuration = 5
materialOverride = Resource()
--~ RemoveOnDeathFlareTag = Symbol("RemoveOnDeathFlare")
RemoveOnDeathFxTag = Symbol("RemoveOnDeathFx")
RemoveTrail = true
DoSectionDislodge = true
DoSectionDislodgePop = true
SectionDislodgeFx = Type()
DoDislodgeDamage = true
DislodgeDamage = Type()
SectionShrinkBones = {Symbol()}
SectionDecos = {Resource()}
DoFinalExplosion = true
deathSpawner = Resource()
DebugPlz = false

Timelength = 1.5
TrailHiLow = Vector(1,12, 0)

preDeathSound = Resource()

local fireCovering = Resource("/Lotus/Fx/Enemies/Grineer/Railjack/GrnShipFlameProj")
local mSecondParams = Symbol("SecondParams")
local mYVale = Symbol("yValue")
local mEmissiveMapAtten = Symbol("EmissiveMapAtten")
local hitProxyType = Type("/EE/Types/Engine/HitProxy")
--mTintColor0 = Symbol("TintColor0") -- Only different for Elites
--mTintColor1 = Symbol("TintColor1") -- Main Color
--mTintColor2 = Symbol("TintColor2") -- Probably Unused
--mTintColor3 = Symbol("TintColor3") -- Detail Color
IgnoreFlareTypes = {Type()}
TintEmissiveDecos = {Type()}
local LotusDynamicProjector = Type("/Lotus/Types/Game/LotusDynamicProjector")
local LotusWeaponTrail = Type("/Lotus/Types/Game/LotusWeaponTrail")
local mEmissiveTintColor = Symbol("EmissiveTintColor")
local mTintColor = Symbol("TintColor")
local mSecondTintColor = Symbol("SecondTintColor")
local mLowColor = Symbol("LowColor")
local mHighColor = Symbol("HighColor")
NoRecolor = Symbol("NoRecolor")

local function tableShuffle(t)
    for n = #t, 1, -1 do
        local k = math.random(n)
        t[n], t[k] = t[k], t[n]
    end
    return t
end

local function SetEnergyColor(avatar, newEnergyColor)
    local suit = avatar:InventoryControl():GetActivePowerSuit()
    if IsNull(suit) then
        return
    end
    local playerCustomization = suit:GetCustomization()
    local colors = playerCustomization:GetColors(Lotus_Game.PrimaryColors)
    colors:SetColor(4, newEnergyColor)
    colors:SetInitialized(4, true)
    playerCustomization:SetColors(Lotus_Game.PrimaryColors, colors)
    suit:SetCustomization(playerCustomization) 
end

function SetChildrenColors(avatar)
    local children = avatar:GetAttachedChildren()
    local testColor = Color(255, 0, 255, 255)
    SetEnergyColor(avatar, testColor)
end

function DissolveParentOnPreDeath(spawner)
    Sleep(0)
    local avatar = spawner:GetAttachParent()
    if not IsNull(avatar) then
        local t = 0
        local val = 0
        local deathExplosion = nil
        local trails = avatar:GetAllAttachments(trailType)
        for i=1, #trails do
            trails[i]:SetSpewCount(0,0,false)
        end
        local label = avatar:GetAttachment(labelType)
        if not IsNull(label) then
            label:Destroy()
        end        
        if Delay > 0 then Sleep(Delay) end
        if not IsNull(deathSpawner) and not IsNull(avatar) then 
            deathExplosion = avatar:Attach(deathSpawner, EMPTY_SYMBOL)
        end
        if doDissolve then
            while t <= dissolveDuration and not IsNull(avatar) do
                -- val = EASING.inExpo(t, 0, 1, dissolveDuration)
                val = Lerp(0,1, t/dissolveDuration)
                avatar:SetDissolve(val)
                t = t + DeltaTime()
                Sleep(0)
            end
        end
    end
end

function TrailFade(WeaponTrail)
    local t,val = 0,0
    local timelength = 1
    while t <= timelength do
        val = Lerp(1,0,t/timelength)
        WeaponTrail:SetLength(val*2)
        WeaponTrail:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, val*8)
        t = t + DeltaTime()
        Sleep(0)
    end
    WeaponTrail:Destroy()
end

function DistantFlareFade(LensFlare)
    LensFlare:FadeOutWithDuration(1)
    Sleep(2.2)
    print(LensFlare:GetFullName().."IS SO AMAZINGLY AWESOME")
--~     LensFlare:Destroy()
end

function fadeSecondTex(ParticleSys)
    local t,val = 0,0
    local timelength = 2
    while t <= timelength do
        val = Lerp(1,0,t/timelength)
        ParticleSys:SetMaterialParam(mSecondParams, 0, 0, 1, val)
        t = t + DeltaTime()
        Sleep(0)
    end
end   

function fadeSecondTexFighter(ParticleSys)
    local t,val = 0,0
    local timelength = 1.5
    while t <= timelength do
        val = Lerp(1,0,t/timelength)
        ParticleSys:SetMaterialParam(mSecondParams, 0, 0, 1, val)
        t = t + DeltaTime()
        Sleep(0)
    end
end   

function yValFade(ParticleSys)
    local t,val = 0,0
    local timelength = 2
    while t <= timelength do
        val = Lerp(0,1,t/timelength)
        ParticleSys:SetMaterialParam(mYVale, val)
        t = t + DeltaTime()
        Sleep(0)
    end
end 

function emissiveFadeIn(entity)
    entity:SetOverrideMaterialForAllSections(materialOverride, false)
    local t,val = 0,0
    local timelength = 1.5
    while t <= timelength do
        val = Lerp(0,0.2,t/timelength)
        entity:SetMaterialParam(mEmissiveMapAtten, val)
        t = t + DeltaTime()
        Sleep(0)
    end
end 

function particleFadeStuff(particleSys)
    particleSys:ScriptRunChildScript(Symbol("fadeSecondTex"), false)
    particleSys:ScriptRunChildScript(Symbol("yValFade"), false)
end

function particleFadeStuffFighter(particleSys)
    particleSys:ScriptRunChildScript(Symbol("fadeSecondTexFighter"), false)
--~     particleSys:ScriptRunChildScript(Symbol("yValFade"), false)
end

-- crewship TC stuff for final death

function csfadeSecondTex(particleSys)
    local t,val = 0,0
    local timelength = 3
    while t <= timelength do
        val = Lerp(1,0,t/timelength)
        particleSys:SetMaterialParam(mSecondParams, 0, 0, 2, val)
        t = t + DeltaTime()
        Sleep(0)
    end
end   

function csyValFade(particleSys)
    Sleep(0)
    local t,val = 0,0
    local timelength = 8
    while t <= timelength do
        val = SmoothStep(t/timelength)
        particleSys:SetMaterialParam(mYVale, val)
        t = t + DeltaTime()
        Sleep(0)
    end
end 

function crewshipBigFlames(particleSys)
    particleSys:ScriptRunChildScript(Symbol("csfadeSecondTex"), false)
    particleSys:ScriptRunChildScript(Symbol("csyValFade"), false)
end


-- crewship TC stuff for final death

function csfadeSecondTexA(particleSys)
    local t,val = 0,0
    local timelength = 5
    while t <= timelength do
        val = Lerp(1,0,t/timelength)
        particleSys:SetMaterialParam(mSecondParams, 0, 0.1, 1, val)
        t = t + DeltaTime()
        Sleep(0)
    end
end   

function csyValFadeA(particleSys)
    Sleep(0)
    local t,val = 0,0
    local timelength = 8
    while t <= timelength do
        val = SmoothStep(t/timelength)
        particleSys:SetMaterialParam(mYVale, val)
        t = t + DeltaTime()
        Sleep(0)
    end
end 

function crewshipBigFlamesA(particleSys)
    particleSys:ScriptRunChildScript(Symbol("csfadeSecondTexA"), false)
    particleSys:ScriptRunChildScript(Symbol("csyValFadeA"), false)
end

local function DisconnectSection(parent, id, DoSectionDislodgePop)
    local section = parent:Attach(SectionDecos[id], Symbol("Game_C1_COG")) -- SectionAttachBones[id], ZERO_VECTOR, ZERO_ROTATION)
    if not IsNull(SectionDislodgeFx) and DoSectionDislodgePop then
        parent:Attach(SectionDislodgeFx, Symbol("Game_C1_COG"))
    end
    section:Unattach()
    -- Apply force
--~     local parentRot = parent:GetRotation()
    local vel = parent:GetVelocity()
    local low,hi =1,2
    vel.x = vel.x * math.random(low,hi)
    vel.y = vel.y * math.random(low,hi)
    vel.z = vel.z * math.random(low,hi)
    section:SetVelocity(vel)
    local torque = Vector(math.random(-1200,1200),math.random(-1200,1200),math.random(-1200,1200))
    section:ApplyTorque(torque, Engine.FT_IMPULSE)
    -- Shrink bone
    parent:SetBoneDirectorEx(SectionShrinkBones[id], ZERO_ROTATION, ZERO_VECTOR, ZERO_VECTOR)
    section:SetLifeSpan(2)
    Sleep(1)
    if not IsNull(section) then section:PlayTriggeredFade() end
end

function disableEngineEffects(entity)
    local parent = entity:GetAttachParent()    
    local IsDeco = false
    local children = {}
    local damageCtrl = nil
    if not IsNull(parent) then
        children = parent:GetAttachedChildren()
        IsDeco = parent:IsA(gDecorationType)
        if not IsDeco then
            damageCtrl = parent:DamageControl()
        end
        if not IsNull(preDeathSound) then parent:PlaySound(preDeathSound, false) end
    end
    
    if damageCtrl ~= nil then
        damageCtrl:SetPreDeathHealthThreshold(parent:GetMaxHealth(true) + 1) --No getting back up!
    end
    
    if DebugPlz then
        print("\n\n\n",parent:GetFullName()," REPORTS THE FOLLOWING:")
        print("Ragdolls:",parent:GetNumRagdolls())
    end
    
    local label = parent:GetAttachment(labelType)
    if not IsNull(label) then
        label:Destroy()
    end
            
    local preBreak = false
--~     if math.random() > 0.5 then
--~         preBreak = true
--~     end
    
    -- Turn off texture emissives
    if not IsNull(parent) then
        parent:ScriptRunChildScript(Symbol("emissiveFadeIn"), false)
    end
        
    if DoSectionDislodge and preBreak and not IsNull(parent) then
--~         local partPop = math.random(1,4)
        local partPopCount = math.random(0,#SectionDecos)

        
        local partOrder = {1,2,3,4}
        tableShuffle(partOrder)
                
        parent:Attach(fireCovering, EMPTY_SYMBOL)
        
        if DoDislodgeDamage then
            parent:Attach(DislodgeDamage, Symbol("GAME_C1_COG"))
        end
        
        for i=partPopCount, 1, -1 do
--~             local partPause = math.random(0.0,0.1)
            local part = partOrder[i]
            if not IsNull(parent) then DisconnectSection(parent, part, DoSectionDislodgePop) end
        end
    end
    
    local pause = math.random(1, 3)

    if not IsNull(parent) then
        local parentPreDeathSourceObjectType = parent:DamageControl():GetPredeathSourceObjectType()
        if parentPreDeathSourceObjectType and parentPreDeathSourceObjectType:IsA(gCrewShipType) then
            pause = 0.0
        end
    end

    Sleep(pause)
    
        if not IsNull(parent) then
            for i=1, #children do
                if not IsNull(children[i]) then
                    local child = children[i]
                    local tag = child:GetTag()
                
                -- Disable Engine Lotus Effects Decos
                    if tag == RemoveOnDeathFxTag then
                        if child:IsA(gLotusEffectDecorationType) then
                            child:PlayTriggeredFade()
                        elseif child:IsA(gParticleSysType) then
                            child:Disable()
                        end
                        
                -- Disable Flare
                    elseif child:IsA(gLensFlareType) then --tag == RemoveOnDeathFlareTag then
                        child:ScriptRunChildScript(Symbol("DistantFlareFade"), false)
                        if DebugPlz then print("!!! FLARE is located & fading") end

                -- Unattach & fade out Trail
                    elseif child:IsA(gWeaponTrailType) and RemoveTrail then
                        child:ScriptRunChildScript(Symbol("TrailFade"), false)
                        if DebugPlz then print("!!! TRAIL is located & fading") end
                    end
                end
            end
    
        if not IsNull(deathSpawner) and DoFinalExplosion and not IsDeco then --and math.random() >= 0.03 then
            parent:Attach(deathSpawner, Symbol("GAME_C1_COG"))
            Sleep(0.1)
            if not IsNull(parent) then 
                parent:SetVisibility(false, false) 
                --Let a natural death occur, that will allow post-predeath death code to properly occur (like giving player XP)
                parent:DamageControl():SetPreDeathHealthLeft(0)
            end
            
            if DoSectionDislodge and not preBreak then
--~                 local partPop = math.random(1,4)
                local partPopCount = math.random(0,#SectionDecos)
            
                local partOrder = {1,2,3,4}
                tableShuffle(partOrder)
                
                -- Turn off texture emissives
                parent:SetOverrideMaterialForAllSections(materialOverride, false)
                parent:Attach(fireCovering, EMPTY_SYMBOL)
                if DoDislodgeDamage then
                    parent:Attach(DislodgeDamage, Symbol("GAME_C1_COG"))
                end
                
                for i=partPopCount, 1, -1 do
                    local partPause = math.random(0.0,0.6)
                    local part = partOrder[i]
                    Sleep(partPause)
                    if not IsNull(parent) then DisconnectSection(parent, part, false) end
                end
            end
            
            Sleep(0.1)
            if not IsNull(parent) and not parent:IsKilled() then
                parent:Suicide()
            end
        else
            if not IsNull(deathSpawner) and DoFinalExplosion then
                parent:Attach(deathSpawner, Symbol("GAME_C1_COG"))
            end
        end
    end
end

function fadeTrailLength(trail)
    local t,val = 0
    while t < Timelength do
        val = Lerp(TrailHiLow.x,TrailHiLow.y,t/Timelength)
        trail:SetLength(val)
        trail:SetEdgeTime(Lerp(.5,2,t/Timelength))
--~         print(val)
        t = t + DeltaTime()
        Sleep(0)
    end
end

function SetFighterAttachedEmissiveTints(deco)
    local parent = deco:GetAttachRoot()
    if not IsNull(parent) then
        local emissiveTint = Vector()
        if parent:HasMaterialParam(mEmissiveTintColor) then
            emissiveTint.x = parent:GetMaterialParam(mEmissiveTintColor, 1)/2
            emissiveTint.y = parent:GetMaterialParam(mEmissiveTintColor, 2)/2
            emissiveTint.z = parent:GetMaterialParam(mEmissiveTintColor, 3)/2
        else
            local material = parent:GetMaterialInSlot(0)
            emissiveTint.x = material:GetParam(mEmissiveTintColor, 1)/2
            emissiveTint.y = material:GetParam(mEmissiveTintColor, 2)/2
            emissiveTint.z = material:GetParam(mEmissiveTintColor, 3)/2
        end
        deco:SetMaterialParam(mTintColor, emissiveTint.x, emissiveTint.y, emissiveTint.z, 1.0)
    end
end

function SetFighterChildrenEmissiveTints(avatar)
    Sleep(0)
    if not IsNull(avatar) then
        local children = avatar:GetAttachedChildren()
        local emissiveTint = Vector(0.0,0.0,0.0)
        if avatar:HasMaterialParam(mEmissiveTintColor) then
            emissiveTint.x = avatar:GetMaterialParam(mEmissiveTintColor, 1)
            emissiveTint.y = avatar:GetMaterialParam(mEmissiveTintColor, 2)
            emissiveTint.z = avatar:GetMaterialParam(mEmissiveTintColor, 3)
        else
            local material = avatar:GetMaterialInSlot(0)
            emissiveTint.x= material:GetParam(mEmissiveTintColor, 1)
            emissiveTint.y = material:GetParam(mEmissiveTintColor, 2)
            emissiveTint.z = material:GetParam(mEmissiveTintColor, 3)
        end
--~         emissiveTint = Color(0,1,0,1)
        for i=1, #children do
            local child = children[i]
            if not child:HasTag(NoRecolor) then
    --~             Is child a flare?
                if child:IsA(gLensFlareType) then
                    local colMult = 255
                    local flareEmissiveTint = Color(emissiveTint.x*colMult, emissiveTint.y*colMult, emissiveTint.z*colMult, colMult)
                    child:SetTint(flareEmissiveTint)
                end
    --~             Is child a trail?
                if child:IsA(LotusWeaponTrail) then
                    local trailEmissiveTint = Color(emissiveTint.x*255, emissiveTint.y*255, emissiveTint.z*255, 255)
                    child:SetTint(trailEmissiveTint)
                end
    --~             Is child a /Lotus/Types/Game/LotusDynamicProjector?
                if child:IsA(LotusDynamicProjector) then
                    child:SetMaterialParam(mTintColor, emissiveTint.x, emissiveTint.y, emissiveTint.z, 1.0)
                    child:SetMaterialParam(mSecondTintColor, emissiveTint.x, emissiveTint.y, emissiveTint.z, 1.0)
                end
    --~             Is child an emissive deco
                if child:IsA(gDecorationType) then
                            local emissiveTint = emissiveTint
                            child:SetMaterialParam(mTintColor, emissiveTint.x, emissiveTint.y, emissiveTint.z, 1.0)
                            child:SetMaterialParam(mLowColor, emissiveTint.x, emissiveTint.y, emissiveTint.z, 1.0)
                            child:SetMaterialParam(mHighColor, emissiveTint.x, emissiveTint.y, emissiveTint.z, 1.0)
                end
            end
        end
    end
end