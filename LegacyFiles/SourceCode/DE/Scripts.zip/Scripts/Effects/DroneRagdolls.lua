beamType = Type()
attachEffect = Type("/Lotus/Fx/Enemies/Drones/DroneRagdollSparksAttach")

local sRightBone = Symbol("GAME_R1_ENGINE")
local sLeftBone = Symbol("GAME_L1_ENGINE")

local function DisableEffects(entity, bone)
    local pSys = entity:GetAllAttachments(gParticleSysType)
    for i, particle in ipairs(pSys) do
        if not IsNull(particle) and particle:GetAttachBone() == bone then
            particle:Disable()
        end
    end
end

function RagdollForces(ragdoll)
    local attenA = Vector(Random(40, 120), Random(5, 45), Random(-70, 70))
    local attenB = Vector(Random(-100, 100), Random(5, 45), Random(-20, 130))
    local disableA = Random(0.1, 0.6)
    local disableB = Random(0.1, 0.6)
    local t = 1
    local proxy = ragdoll:GetProxyFromBodyPart(Engine.Ragdoll_ARM_RIGHT)
    if not IsNull(proxy) then
        local beam = ragdoll:Attach(beamType, sLeftBone)
        if not IsNull(beam) then
            beam:SetEndPointEntity(proxy, EMPTY_SYMBOL)
        end
    end
    local effectA = ragdoll:Attach(attachEffect, sRightBone)
    local effectB = ragdoll:Attach(attachEffect, sLeftBone)
    while not IsNull(ragdoll) and t > 0 do
        local val = math.pow(t, 3)
        local dx = Noise(Time() * 0.2) * val
        local dy = (1 + AbsNoise((Time() + 3) * 0.2)) * val
        local dz = Noise((Time() + 7)  * 0.2) * val
        if disableA > 0 then
            ragdoll:ApplyForce(Vector(dx * attenA.x, dy * attenA.y, dz * attenA.z), Engine.Ragdoll_FOREARM_RIGHT)
        end
        if disableB > 0 then
            ragdoll:ApplyForce(Vector(dz * attenB.x, dy * attenB.y, dx * attenB.z), Engine.Ragdoll_FOREARM_LEFT)
        end
        if t < disableA then
            attenA = Vector()
            if not IsNull(effectA) then
                effectA:Destroy()
            end
            DisableEffects(ragdoll, sRightBone)
            disableA = -1
        end
        if t < disableB then
            attenB = Vector()
            if not IsNull(effectB) then
                effectB:Destroy()
            end
            DisableEffects(ragdoll, sLeftBone)
            disableB = -1
        end
        t = t - DeltaTime() * 0.35
        Sleep(0)
    end
end