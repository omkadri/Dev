AvatarEffect = Type()
AvatarAttachmentBone = Symbol()
DebugPlease = false

function AttachIcyBreath()
    Sleep(0)
    print("Icy Breath begin")
    local localPlayerAvatar
    
    while IsNull(localPlayerAvatar) do
        localPlayerAvatar = gRegion:GetLocalPlayerAvatar()
        if DebugPlease == true then
            print("No avatar found yet...")
        end
        Sleep(0)
    end

    if not IsNull(localPlayerAvatar) then
        if DebugPlease == true then
            print("Avatar attach commencing...")
        end
        localPlayerAvatar:Attach(AvatarEffect, AvatarAttachmentBone)
    end
end