deathEffectA = Type()

function OnDeath(kubrow)
    if not IsNull(kubrow) then
        --to do, get energy color
        --An animation is coming in for the death
        local attachedChildren = kubrow:GetAttachedChildren()
        kubrow:Attach(deathEffectA, EMPTY_SYMBOL)
        local t = 0
        while t < 1 do
            if IsNull(kubrow) then
                break
            end
            for i=1,#attachedChildren do
                if not IsNull(attachedChildren[i]) then
                    attachedChildren[i]:SetDissolve(t)
                end
            end
            kubrow:SetDissolve(t)
            t = t + DeltaTime() * 0.25
            Sleep(0)
        end
    end
end