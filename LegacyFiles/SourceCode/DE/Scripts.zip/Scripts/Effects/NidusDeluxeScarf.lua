

local sDilation = Symbol("Dilation")

function ScarfUpdate(scarf)
    local avatar = scarf:GetRootOwner()
    if IsNull(avatar) or not avatar:IsA(gBaseAvatarType) then
        return
    end
    
    local gameRules = gGameRules
    if gameRules:IsA(gLotusHubGameRulesType) or gameRules:IsA(gLotusAttractModeGameRulesType) then
        return
    end
    
    local suit = avatar:InventoryControl():GetActivePowerSuit()
    if IsNull(suit) then
        return
    end
    
    local damageController = avatar:DamageControl()
    if IsNull(damageController) then
        return
    end
    
    local maxEnergy = suit:GetMaxEnergy()
    if maxEnergy == 0 then
        maxEnergy = damageController:GetMaxShield(false)
        if maxEnergy == 0 then
            maxEnergy = 0.0001
        end
        while not IsNull(scarf) and not IsNull(suit) do
            local currentEnergy = damageController:GetShield()
            scarf:SetMaterialParam(sDilation, currentEnergy / maxEnergy, 0, 0, 0, true)
            Sleep(0.1)
        end 
    else
        while not IsNull(scarf) and not IsNull(suit) do
            local currentEnergy = suit:GetCurEnergy()
            scarf:SetMaterialParam(sDilation, currentEnergy / maxEnergy, 0, 0, 0, true)
            Sleep(0.1)
        end
    end
end
