EaseInFadeUA = true
Delay = 0
StartValue = 1 
EndValue = 0
TimeLength = 1
Param = Symbol("UnlitAtten")

Scalar2Fade = true
Scalar2StartValue = 0
Scalar2EndValue = 0.5
Scalar2TimeLength = 3

ValleyValue = 0
Peak = 0.3
PeakValue = 1


--ColorLerp
ColorChange = true
ColorTimeLength = 1
ColorDelay = 0
ColorValleyValue = Color(200,200,100,255)
ColorValleyEndValue = Color(70,30,0,255)

local SCALAR2 = Symbol("Scalar2")

local function easeInQuad(t, b, c, d)
    t=t/d
    return c*t*t + b
end

local function easeOutExpo(t, b, c, d)
    if (t==d) then
        return b+c
    else
        return c * (-math.pow(2, -10 * t/d) + 1) + b
    end
end

-- quadratic easing out - decelerating to zero velocity
local function easeOutQuad(t, b, c, d)
    t=t/d
    return -c * t*(t-2) + b
end

function combiner(deco)
    if Scalar2Fade == true then
        deco:ScriptRunChildScript(Symbol("easeInScalar2Fade"), false)
    end
    if EaseInFadeUA == true then
        deco:ScriptRunChildScript(Symbol("easeInFade"), false)
    end
    if ColorChange == true then
        deco:ScriptRunChildScript(Symbol("ColorLerp"), false)
    end
end

function easeOutFade(deco)
    Sleep(0)
    deco:SetMaterialParam(Param, StartValue)
    Sleep(Delay)
    local t = 0
    local val
    while t < TimeLength do
        val = easeOutExpo(t, StartValue, EndValue - StartValue, TimeLength)
        deco:SetMaterialParam(Param, val)
        t = t + DeltaTime() 
        Sleep(0)
    end
end

function easeInFade(deco)
    Sleep(0)
    deco:SetMaterialParam(Param, StartValue)
    Sleep(Delay)
    local t = 0
    local val
    while t < TimeLength do
        val = easeInQuad(t, StartValue, EndValue - StartValue, TimeLength)
        deco:SetMaterialParam(Param, val)
        t = t + DeltaTime() 
        Sleep(0)
    end
end

function easeInScalar2Fade(deco)
    Sleep(0)
    deco:SetMaterialParam(Param, Scalar2StartValue)
    Sleep(Delay)
    local t = 0
    local val
    while t < Scalar2TimeLength do
        val = easeInQuad(t, Scalar2StartValue, Scalar2EndValue - Scalar2StartValue, Scalar2TimeLength)
        deco:SetMaterialParam(SCALAR2, val)
        t = t + DeltaTime() 
        Sleep(0)
    end
end

function easeOutLightFade(deco)
    Sleep(0)
    deco:SetBrightness(StartValue)
    Sleep(Delay)
    local t = 0
    local val
    while t < TimeLength do
        val = easeOutExpo(t, StartValue, EndValue - StartValue, TimeLength)
        deco:SetBrightness(val)
        t = t + DeltaTime() 
        Sleep(0)
    end
end

function EaseInLight(deco)
    Sleep(0)
    deco:SetBrightness(StartValue)
    Sleep(Delay)
    local t = 0
    local val
    while t < TimeLength do
        val = easeInQuad(t, StartValue, EndValue - StartValue, TimeLength)
        deco:SetBrightness(val)
        t = t + DeltaTime() 
        Sleep(0)
    end
end

function MaterialFadePeak(deco)
    Sleep(Delay)
    local t = 0
    local fading
    local val
    while t < TimeLength do
        if t < Peak then
            fading = t/Peak
        else
            fading = 1 - (t-Peak)/(TimeLength-Peak)
        end
        if fading < 0 then
            fading = 0
        end
        val = Lerp(ValleyValue, PeakValue, fading)
        deco:SetMaterialParam(Param, val)
        t = t + DeltaTime() 
        Sleep(0)
    end
end

function MaterialFadePeakHide(deco)
    Sleep(Delay)
    local t = 0
    local fading
    local val
    while t < TimeLength do
        if t < Peak then
            fading = t/Peak
        else
            fading = 1 - (t-Peak)/(TimeLength-Peak)
        end
        if fading < 0 then
            fading = 0
        end
        val = Lerp(ValleyValue, PeakValue, fading)
        deco:SetMaterialParam(Param, val)
        t = t + DeltaTime() 
        Sleep(0)
    end
    while t > TimeLength do
        deco:SetVisibility(false, true)
        t = t + DeltaTime() 
        Sleep(0)
    Sleep(0)
    end
end

-- Color Flat Peak
function ColorLerp(deco)
    local t = 0
    local r = ColorValleyValue.red/255
    local g = ColorValleyValue.green/255
    local b = ColorValleyValue.blue/255
    local a = ColorValleyValue.alpha/255
    deco:SetMaterialParam(Lotus_Game.TINT_COLOR, r,g,b,a)
    Sleep(ColorDelay)
    while t < ColorTimeLength do
                r = easeInQuad(t,ColorValleyValue.red/255, ColorValleyEndValue.red/255-ColorValleyValue.red/255, ColorTimeLength)
                g= easeInQuad(t,ColorValleyValue.green/255, ColorValleyEndValue.green/255-ColorValleyValue.green/255, ColorTimeLength)
                b = easeInQuad(t,ColorValleyValue.blue/255, ColorValleyEndValue.blue/255-ColorValleyValue.blue/255, ColorTimeLength)
                a = 1
        deco:SetMaterialParam(Lotus_Game.TINT_COLOR, r,g,b,a)
        t = t + DeltaTime() 
        Sleep(0)
    end
end
