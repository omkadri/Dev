TimeLength = 1.0
Delay = 0.0

function AttractorGrow(attr)
    Sleep(Delay)
    attr:StartChangingRadius()
end