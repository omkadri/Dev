debugEnabled = false
NoiseSpeedMultiplier = 0.5
NoiseSizeMultiplier = 1
NoiseOffset = 0
TargetDeco = {Instance()}
randomSleepRange = Vector(0,3,0)
randomJitterLengthRange = Vector(0,0.5,0)
randomScaleRange = Vector(0,1,2)
UAParam = Symbol("UnlitAtten")
BrokenHologramTag = Symbol("BrokenHologram")

function scaleRandom(deco)
    local t = 0
    local randomSleepTime = math.random(randomSleepRange.x*100, randomSleepRange.y*100)/100
    local randomJitterLength = math.random(randomJitterLengthRange.x*100, randomJitterLengthRange.y*100)/100
    local rArray = gRegion:FindTagged(BrokenHologramTag)
    local xScale, yScale, zScale
    
    if debugEnabled then
        print("Startup Sleep: ", randomSleepTime)
    end
    
    Sleep(randomSleepTime)

    while t == 0 do

            while t <  randomJitterLength do

            local randomScale = math.random(randomScaleRange.x*100, randomScaleRange.y*100)/100
            local otherAxisScale = 1+((1-randomScale)/randomScaleRange.z)
            
            local keyAxis = math.random(0, 2)
            
            if keyAxis == 0 then
               xScale = randomScale
               yScale = otherAxisScale
               zScale = otherAxisScale
            elseif keyAxis == 1 then
               yScale = randomScale
               xScale = otherAxisScale
               zScale = otherAxisScale
            else
               zScale = randomScale
               xScale = otherAxisScale
               yScale = otherAxisScale
            end
                
            for i = 1, #rArray, 1 do
                local temp = rArray[i]
                temp:SetMaterialParam(Lotus_Game.V_SCALES, xScale, yScale, zScale)
                temp:SetMaterialParam(UAParam, randomScale * 4)
            end

            if debugEnabled then
                print("CurrentJitterTimeLength: ", randomJitterLength)
                print("CurrentJitter: ", randomScale)
            end
            t = t + DeltaTime()
            Sleep(0)
        end

        randomSleepTime = math.random(randomSleepRange.x*100, randomSleepRange.y*100)/100
        randomJitterLength = math.random(randomJitterLengthRange.x*100, randomJitterLengthRange.y*100)/100
        
        for i = 1, #rArray, 1 do
            local temp = rArray[i]
            temp:SetMaterialParam(Lotus_Game.V_SCALES, 1, 1, 1)
            temp:SetMaterialParam(UAParam, 1)
        end
        
        if debugEnabled then
            print("Sleep: ", randomSleepTime)
        end
        
        Sleep(randomSleepTime)      
        t = 0
    end
end

function materialParamNoise()
    Sleep(0)
    local val
    local targetOffsets = {}
    
    for i = 1, #TargetDeco do
        targetOffsets[i] = math.random(0,100)
        if debugEnabled then print("HEY!!!: "..targetOffsets[i]) end
    end
    
    while true do
        for i = 1, #TargetDeco do
            local temp = TargetDeco[i]
            val = math.abs(Noise((Time()+targetOffsets[i])*NoiseSpeedMultiplier))*NoiseSizeMultiplier + NoiseOffset
            temp:SetMaterialParam(UAParam, val)
                   
            if debugEnabled then print("val: "..val) end
        end
        Sleep(0)
    end
end