

function SetBeamLength(beam)

    local parentBeam = beam:GetAttachParent();
    
    local parentBeamEndPoint = Vector()
    while not IsNull(parentBeam) do
        parentBeamEndPoint = parentBeam:GetEndPoint();
        beam:SetEndPoint(parentBeamEndPoint);
        Sleep(0.1);
    end
    
end