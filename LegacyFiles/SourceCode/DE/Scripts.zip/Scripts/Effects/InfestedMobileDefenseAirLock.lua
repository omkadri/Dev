ParticleType = Symbol()
SearchRadius = 20
NewMinSpeed = 3
NewMaxSpeed = 4
AirlockGasTag = AirlockGas

function SetSpeedAirlockGas(entity)
    
    Sleep(0)

    local gasArray = gRegion:FindTaggedInRadius(ParticleType, entity:GetPosition(), 0, SearchRadius)
    
    if not IsNull(gasArray) then 
        for i=1, #gasArray do
            local temp = gasArray[i]
            temp:setSpeed(NewMinSpeed, NewMaxSpeed)
            Sleep(0)
        end
    end
    
end