sleepFirst = false
minScale = 0.6
colorArray = {Color()}
flareToCreate = Type()

function ApplyRandomColor(deco)
    if sleepFirst then
        Sleep(0.0)
    end
    local newColor = Color(223, 204, 76, 255)
    local count = #colorArray
    local randNum = math.random(1, count)
    if count > 0 then
        newColor = colorArray[randNum]
    end
    local flare = gRegion:CreateEntity(flareToCreate, deco:GetPosition(), ZERO_ROTATION)
    if not IsNull(flare) then
        flare:AttachTo(deco, EMPTY_SYMBOL)
        flare:SetTint(newColor)
    end
    local minColor = Color()
    if not IsNull(newColor) then
        minColor.red = newColor.red * minScale
        minColor.green = newColor.green * minScale
        minColor.blue = newColor.blue * minScale
        minColor.alpha = newColor.alpha
        deco:SetColorMinMax(minColor, newColor)
        Effects.SetColorMinMaxChildParticleSystems(deco, gEffectType, minColor, newColor)
    end
end