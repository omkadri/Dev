-- Outdoor level options
fogDensity = 0.5
fogColor = Color()
skyFogColor = Color()
skyboxFogMeshType = Type()
skyFog = 0.5
keepUpdatingFog = true
updateInterval = 2
clampDynamicExposure = true

-- Fog ---------------------------------------------------------------------------------------------------------------------------------------------------------

local function UpdateFog()

    local zoneAttribs = gRegion:FindAll(gZoneAttribsType)
    local zones = {}
    
    --Get Zones
    for i = 1, #zoneAttribs do
        if not IsNull(zoneAttribs[i]) then
            local tag = zoneAttribs[i]:GetTag()
            if tag ~= Symbol("Backdrop") and tag ~= Symbol("Cinematics") then
                table.insert(zones, zoneAttribs[i]:GetZone())
            end
        end
    end
       
    -- Tint skybox
    if not IsNull(skyboxFogMeshType) then
        local skyboxDecos = gRegion:FindAll(skyboxFogMeshType)
        for i, deco in ipairs(skyboxDecos) do
            deco:SetMaterialParam(Lotus_Game.TINT_COLOR, skyFogColor.red/255, skyFogColor.green/255, skyFogColor.blue/255, skyFogColor.alpha/255)
            deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, skyFog)
        end
    end
    
    -- Update fog
    for i = 1, #zones do
        if not IsNull(zones[i]) then
            --zones[i]:SetOverrideLevelFog(true)
            zones[i]:SetFogColor(fogColor)
            zones[i]:SetDistanceFogDensity(fogDensity)
            Sleep(0)
        end
    end

    -- keep dynamic exposure within a reasonable range, otherwise fog gets completly blown out (close up objects appear as untextured gray polys)
    if clampDynamicExposure then
        local avatar = gRegion:GetLocalPlayerAvatar()
        if not IsNull(avatar) then
            local postInfo = avatar:CameraControl():ScriptGetCurrentPostProcessInfo()
            postInfo.dynamicExposure.minValue = 1
            postInfo.dynamicExposure.maxValue = 1
            postInfo.horizonFog = 1
            postInfo.horizonFogRadius = 1
            postInfo:ClearFogTexture()
        end
    end
end

local function SetupFog()

    -- Wait for players (hack to prevent other scripts overriding level fog)
    --[[if waitForCinematicEnd then
        while not IsNull(gRegion:GetPlayingCinematic()) do
            Sleep(0)
        end
    end]]

    -- Zone fog settings 
    local zoneAttribs = gRegion:FindAll(gZoneAttribsType)
    for i = 1, #zoneAttribs do
        local zone = zoneAttribs[i]:GetZone()
        local tag = zoneAttribs[i]:GetTag()
        if not IsNull(zone) then
            if tag ~= Symbol("Backdrop") and tag ~= Symbol("Cinematics") then
                zone:SetOverrideLevelFog(true)
                zone:SetFogColor(fogColor)
                zone:SetDistanceFogDensity(fogDensity)
            end
        end
    end

    -- Spawn skybox sphere
    if not IsNull(skyboxFogMeshType) then
        if gRegion:IsMaster() then -- Host
            for i = 1, #zoneAttribs do
                local tag = zoneAttribs[i]:GetTag()
                if tag == Symbol("Backdrop") and tag ~= Symbol("Cinematics") then
                    local pos = zoneAttribs[i]:GetPosition()
                    local rot = zoneAttribs[i]:GetRotation()
                    local fogSphere = gRegion:CreateEntity(skyboxFogMeshType, pos, rot)
                    fogSphere:SetMaterialParam(Lotus_Game.TINT_COLOR, skyFogColor.red/255, skyFogColor.green/255, skyFogColor.blue/255, skyFogColor.alpha/255)
                    fogSphere:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, skyFog)
                end
            end
        else -- Client
            local skyboxDecos = gRegion:FindAll(skyboxFogMeshType)
            local t = 0
            while (IsNull(skyboxDecos) or #skyboxDecos == 0) and t < 10 do -- Wait until fog spheres are spawned on host
                skyboxDecos = gRegion:FindAll(skyboxFogMeshType)
                t = t + DeltaTime()
                Sleep(0)
            end
            for i, deco in ipairs(skyboxDecos) do
                deco:SetMaterialParam(Lotus_Game.TINT_COLOR, fogColor.red/255, fogColor.green/255, fogColor.blue/255, fogColor.alpha/255)
                deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, skyFog)
            end
        end
    end
    
    -- Keep trying to update fog
    if keepUpdatingFog then
        while true do
            UpdateFog()

            Sleep(updateInterval)
        end
    end
end

function SetupFogFromScript()
    SetupFog()
end

function OnPlayerSpawned(gameRules, player)
    SetupFog()
end