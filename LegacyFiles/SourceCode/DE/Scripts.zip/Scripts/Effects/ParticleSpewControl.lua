Delay = 0
Timelength = 10
SpewStart = 30
SpewEnd = 0
ParticleArray = {Instance()}

function SetSpew(ParticleSystem)
    Sleep(Delay)
    local t = 0
    while t < Timelength do
        local spew = Lerp(SpewStart, SpewEnd, t/Timelength)
        ParticleSystem:SetSpewCount(spew, spew, false)
        t = t + DeltaTime()
        Sleep(0)
    end
end

function SetArraySpew()
    Sleep(Delay)
    local t = 0
    local array = ParticleArray
    if not IsNull(array) then
        while t < Timelength do
            local spew = Lerp(SpewStart, SpewEnd, t/Timelength)
            for count = 1, #array do
                local temp = array[count]
                temp:SetSpewCount(spew, spew, false)
                Sleep(0)
            end
            t = t + DeltaTime()
        end
    end
end
