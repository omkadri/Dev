attachEffect = Type()

function AttachRandomExplosions()
    Sleep(0)
    local playerAvatar = gRegion:GetLocalPlayerAvatars()[1]
    if not IsNull(playerAvatar) then
        playerAvatar:Attach(attachEffect, EMPTY_SYMBOL)
    end
end