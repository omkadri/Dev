FogTag = Symbol("Fog")
DistanceFogDensity = 1
HeightFogDensity = 0
FogColor = Color(255,0,0,255)
SearchMaxDistance = 20
DebugMsgs = false

function ChangeFog(entity)

    Sleep(0)
    local pos = entity:GetPosition()
    local zones = gRegion:FindTaggedInRadius(FogTag,pos,0,SearchMaxDistance)
    
    if DebugMsgs == true then
        print("ChangeFog Started")
    end
    -- local t = 0
    
    if not IsNull(zones) then
        if DebugMsgs == true then
            print("Found some zones")
        end
        local localPlayers = gRegion:GetLocalPlayerAvatars()
        if not IsNull(localPlayers) then
            if DebugMsgs == true then
                print("Found a local player")
            end
            for i = 1, #zones do
                local temp =  zones[i]:GetZone()
                
                -- while t < TimeLength do
                    -- local lerpVal = Lerp(0,1,t/TimeLength)
                    temp:SetDistanceFogDensity(DistanceFogDensity)
                    temp:SetHeightFogDensity(HeightFogDensity)
                    temp:SetFogColor(FogColor)
                -- end
            end
            -- t = t + DeltaTime()
            Sleep(0)
        end
    end
    
end