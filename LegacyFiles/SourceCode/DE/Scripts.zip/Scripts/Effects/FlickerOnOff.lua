delay = 0
flickerLight = Instance()
lightDeco = Instance()
transitionTime = 1

flickerBrightness = 0.2
flickerBrightnessMultiplier = 20
maxBrightness = 1

maxEmissiveness = 1

DoFlicker = true
DecoParam = Symbol("UnlitAtten")
FlickerTag = Symbol("Flicker")
FlickerTagRadius = 3
flickerBrightnessOffset = 0

local function localFlickerLight(light, deco, loop)

    if IsNull(light) and IsNull(deco) then
        return
    end

    while true do
        local t = 0
        while t < 1 do

            local b = Abs(Noise(t))
            local v = flickerBrightness + math.pow(0.1, b)
            
            if not IsNull(light) then
                light:SetBrightness(v * flickerBrightnessMultiplier)
            end
            
            if not IsNull(deco) then
                deco:SetMaterialParam(Lotus_Game.EMISSIVE_MAP_ATTEN, v)
            end
            
            -- sleep til next frame
            t = t + DeltaTime() / transitionTime
            Sleep(0.0)
        end
        
        if loop == false then
            break
        end
        
    end

end

function FlickerOn()

    Sleep(delay)
    
    if IsNull(flickerLight) or not flickerLight:IsA(gLightType) then
        return
    end

    localFlickerLight(flickerLight, lightDeco, false)
    flickerLight:SetBrightness(maxBrightness)
    flickerLight:TurnOn()
    if IsNull(lightDeco) == false then
        lightDeco:SetMaterialParam("EmissiveMapAtten", maxEmissiveness)
    end

end


function FlickerOff()

    Sleep(delay)
    localFlickerLight(flickerLight, lightDeco, false)
    flickerLight:SetBrightness(0)
    flickerLight:TurnOff()
    if IsNull(lightDeco) == false then
        lightDeco:SetMaterialParam("EmissiveMapAtten", 0)
    end

end

function FlickerLoop(deco)

    Sleep(delay)

    if not IsNull(lightDeco) then
        deco = lightDeco
    end 
    localFlickerLight(flickerLight, deco, true)
    
end

function FlickerEmissive(deco)
    local offset = math.random()
    while not IsNull(deco) do
        local t = offset + (Time() * 0.5)
        local b = math.max(0, Abs(Noise(t)) - 0.1)
        deco:SetMaterialParam(Lotus_Game.EMISSIVE_MAP_ATTEN, b * 3)
        Sleep(0.0)
    end
end

function FlickerLoopDecoAttached(light)

    Sleep(0)
    local pos = light:GetPosition()
    local rArray = gRegion:FindTaggedInRadius(FlickerTag, pos, 0, 3)
    if IsNull(rArray) then
        return
    end
    
    while DoFlicker == true do
        local t = 0
        while t < 1 do
            local b = light:GetSourceLuminance()
            b = b * flickerBrightnessMultiplier
            for i = 1, #rArray do
                rArray[i]:SetMaterialParam(DecoParam, b)
            end
                    
            t = t + DeltaTime() / transitionTime
            Sleep(0.0)
        end
    end
    
end

function FlickerLoopDecoAttachedExtraParams(light)

    Sleep(0)
    local pos = light:GetPosition()
    local rArray = gRegion:FindTaggedInRadius(FlickerTag, pos, 0, FlickerTagRadius)
    if IsNull(rArray) then
        return
    end
    
    while DoFlicker == true do
        local t = 0
        while t < 1 do
            local b = light:GetSourceLuminance()
            b = b * flickerBrightnessMultiplier + flickerBrightnessOffset
            for i = 1, #rArray do
                rArray[i]:SetMaterialParam(DecoParam, b)
            end
                    
            t = t + DeltaTime() / transitionTime
            Sleep(0.0)
        end
    end
    
end
