DoDouble = true
DoSingle = true
TwoParamDelay = 0
SingleParamDelay = 0
TwoParamTimelength = 3
SingleParamTimelength = 3
TwoParam = Symbol()
SingleParam = Symbol()
TwoParamStartX = 1
TwoParamStartY = 1
SingleParamStart = 1
TwoParamEndX = 3
TwoParamEndY = 3
SingleParamEnd = 3

function DoubleAndSingle(Deco)
    if DoDouble then
        Deco:ScriptRunChildScript(Symbol("DoubleParamTransition"), false)
    end
    if DoSingle then
        Deco:ScriptRunChildScript(Symbol("SingleParamTransition"), false)
    end
end
    
    
function DoubleParamTransition(Deco)
    Sleep(TwoParamDelay)
    local t = 0
    local valX = TwoParamStartX
    local valY = TwoParamStartY
    while t < TwoParamTimelength do
        local currentTime = t/TwoParamTimelength
        valX = Lerp(TwoParamStartX, TwoParamEndX, currentTime)
        valY = Lerp(TwoParamStartY, TwoParamEndY, currentTime)
        Deco:SetMaterialParam(TwoParam, valX, valY, 1, 1)
        t = t + DeltaTime()
        Sleep(0)
    end
end

function SingleParamTransition(Deco)
    Sleep(SingleParamDelay)
    local t = 0
    local val = SingleParamStart
    while t < SingleParamTimelength do
        val = Lerp(SingleParamStart, SingleParamEnd, t/SingleParamTimelength)
        Deco:SetMaterialParam(SingleParam, val)
        t = t + DeltaTime()
        Sleep(0)
    end
end