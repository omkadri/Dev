ringParticleType = Type()
beamType = Type()
beamEndPointType = Type()
iceDecoType = Type()
localOnlyDecoType = Type()
firePointEffect = Type()

local COLOR_UTIL = require "Lotus.Scripts.Effects.EffectsColorUtilities"
local BulletJumpTrail = WeakResource("/Lotus/Fx/Gameplay/Movement/BulletJumpTrailA")
local attachBones =     {
                                Symbol("GAME_L1_LEG2"),
                                Symbol("GAME_R1_LEG2"),
                                Symbol("GAME_L1_ARM2"),
                                Symbol("GAME_R1_ARM2"),
                                Symbol("GAME_C1_SPINE1"),
                                Symbol("GAME_C1_SPINE2"),
                                Symbol("GAME_C1_HEAD1")
                                }
local raycastIgnoreTypes = {
    WeakResource("/EE/Types/Game/Avatar"),
    WeakResource("/EE/Types/Engine/HitProxy"),
    WeakResource("/EE/Types/Physics/Ragdoll"),
    WeakResource("/EE/Types/Game/PickUp")
}

function BulletJumpEffects(spawner)
    local avatar = spawner:GetAttachRoot()
    if IsNull(avatar) or not avatar:IsA(gLotusAvatarType) or not avatar:ReplicaLocallyControlled() then
        return
    end
    local levelInfo = gRegion:GetLevelInfo()
    local postProcessBias = levelInfo:GetPostProcessBias()
    local t = 0
    while t < 1 do
        if IsNull(levelInfo) then
            return
        end
        t = t + DeltaTime()
        local r = 1.0 - math.abs(math.pow(t, 0.3) * 2 - 1)
        postProcessBias.radialBlurStrength = r * 0.75
        Sleep(0)
    end
    if not IsNull(levelInfo) then
        postProcessBias.radialBlurStrength = 0
    end
end

function BulletJumpEffectsDisabled(spawner)
    local avatar = spawner:GetAttachParent()
    if IsNull(avatar) then
        return
    end
    for i=1, #attachBones do
        --avatar:Attach(trailType, attachBones[i])
    end
    
    local oldPosition = avatar:GetCenter()
    local currentPosition = oldPosition
    local newRotation = Rotation()
    local speed = 0
    
    local rings = gRegion:CreateEntity(ringParticleType, oldPosition, avatar:GetSimRotation(), avatar)
    Sleep(0)
    
    while not IsNull(rings) and not IsNull(avatar) do
        currentPosition = avatar:GetCenter()
        oldPosition = LerpVector(oldPosition, currentPosition, 0.3) --Making it lag a bit to smooth out the arc
        newRotation = LookTo(oldPosition, currentPosition)
        speed = math.min(20, avatar:GetSpeed())
        rings:SetSpeed(speed * 0.5, speed * 0.8)
        rings:SetSpewCount(3 * speed, 6 * speed, false)
        rings:SetPosition(oldPosition)
        rings:SetRotation(newRotation)
        --oldPosition = currentPosition
        Sleep(0)
    end
end


local function GetNearbyPoint(pos)
    local toPos = Vector(pos.x + math.random(-6,6), pos.y - math.random(-6,6), pos.z + math.random(-6,6))
    local rayCastHit = Vector()
    local count = 0
    while count < 2 do --Max raycasts before this one fails
        if gRegion:RaycastIgnoreTypes(pos, toPos, raycastIgnoreTypes, nil, rayCastHit) then
            count = 5
        else
            count = count + 1
            toPos = Vector(pos.x + math.random(-5,5), pos.y + math.random(-5,5), pos.z + math.random(-5,5))
        end
    end

    return rayCastHit
end

function ElectricalAttach(spawner)
    local avatar = spawner:GetAttachParent()
    local pQ = COLOR_UTIL.ParticleQuality()
    if pQ == 0 or IsNull(avatar) then
        return
    end
    
    local effectTimer = 1
    local effectThreshold = 0.05
    local duration = 0.6
    while (duration > 0) and not IsNull(avatar) do
        if effectTimer >  effectThreshold then
            local boneName = attachBones[math.random(1,#attachBones)] 
            local newEndPoint = GetNearbyPoint(avatar:GetBonePosition(boneName))
            if newEndPoint ~= ZERO_VECTOR then
                local ambientBeam = avatar:Attach(beamType, boneName, ZERO_VECTOR, ZERO_ROTATION, avatar)
                if not IsNull(ambientBeam) then
                    ambientBeam:SetEndPoint(newEndPoint)
                    gRegion:CreateEntity(beamEndPointType, newEndPoint, ZERO_ROTATION)
                end
            end
            effectTimer = 0
            effectThreshold = Random(0.08, 0.12) / pQ --Particle quality of 2 will get more
        end
        Sleep(0)
        duration = duration - DeltaTime()
        effectTimer = effectTimer + DeltaTime() 
    end
end

function ElectricalHop(spawner)
    local avatar = spawner:GetAttachParent()
    local pQ = COLOR_UTIL.ParticleQuality()
    if pQ == 0 or IsNull(avatar) then
        return
    end

    local boneName = spawner:GetAttachBone()
    local newEndPoint = spawner:GetSimPosition()
    local ambientBeam = avatar:Attach(beamType, boneName, ZERO_VECTOR, ZERO_ROTATION, avatar)
    if not IsNull(ambientBeam) then
        ambientBeam:SetEndPoint(newEndPoint)
    end
    --[[
    local newEndPoint = GetNearbyPoint(avatar:GetBonePosition(boneName))
    local newEndPoint = spawner:GetSimPosition()
    if newEndPoint ~= ZERO_VECTOR then
        local ambientBeam = avatar:Attach(beamType, boneName, ZERO_VECTOR, ZERO_ROTATION, avatar)
        if not IsNull(ambientBeam) then
            ambientBeam:SetEndPoint(newEndPoint)
            gRegion:CreateEntity(beamEndPointType, newEndPoint, ZERO_ROTATION)
        end
    end
    ]]--
end

function IceAttach(spawner)
    local avatar = spawner:GetAttachParent()
    local pQ = COLOR_UTIL.ParticleQuality()
    if pQ == 0 or IsNull(avatar) then
        return
    end
    local pos = avatar:GetSimPosition() - Vector(0,0.2,0)
    local aimPos = avatar:InventoryControl():GetAimEndPoint()
    local rot = LookTo(pos, aimPos)
    rot.pitch = rot.pitch - 114
    if rot.pitch < -180 then
        rot.pitch = rot.pitch + 360
    end
    local posAdjust = pos - aimPos
    Normalize(posAdjust)
    local amount = 0.2
    posAdjust = Vector(posAdjust.x * amount, posAdjust.y * amount, posAdjust.z * amount)
    gRegion:CreateEntity(iceDecoType, pos + posAdjust, rot)
    avatar:Attach(localOnlyDecoType, Symbol("GAME_C1_HIP1"))
end

function FireAttach(spawner)
    local avatar = spawner:GetAttachParent()
    local pQ = COLOR_UTIL.ParticleQuality()
    if pQ == 0 or IsNull(avatar) then
        return
    end
    
    local effectTimer = 1
    local effectThreshold = 0.05
    local duration = 0.8
    while duration > 0 and not IsNull(avatar) do
        if effectTimer >  effectThreshold then
            local boneName = attachBones[math.random(1,#attachBones)] 
            local newEndPoint = GetNearbyPoint(avatar:GetBonePosition(boneName))
            if newEndPoint ~= ZERO_VECTOR then
                gRegion:CreateEntity(firePointEffect, newEndPoint, LookTo(newEndPoint, avatar:GetCenter()))
            end
            effectTimer = 0
            effectThreshold = Random(0.05, 0.08) / pQ --Particle quality of 2 will get more
        end
        local val = 0.8 - duration
        if val < 0.25 then
            local trails = avatar:GetAllAttachments(BulletJumpTrail)
            for i=1, #trails do
                trails[i]:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, val * 8)
                trails[i]:SetMaterialParam(Lotus_Game.ALPHA_ATTEN, 0.2 + 3.2 * val)
            end
        end
        Sleep(0)
        duration = duration - DeltaTime()
        effectTimer = effectTimer + DeltaTime() 
    end
end