module(..., package.seeall)

function Piecewise(x, points)
    local NUM_POINTS = #points
    local SEGMENT_LEN = 1.0/(NUM_POINTS - 1)
    local SEGMENT_NORMALIZE = 1.0/SEGMENT_LEN
    local count = 1
    while count < NUM_POINTS do
        if x < SEGMENT_LEN * count then
            return(Lerp(points[count], points[count + 1], (x-SEGMENT_LEN * (count - 1))*SEGMENT_NORMALIZE))
        end
        count = count + 1
    end
    return (points[NUM_POINTS])
end

function UpdateWorldPos(entity, param)
     if IsNull(entity) then
        return
    end
    while not IsNull(entity) do
        local pos = entity:GetSimPosition()
        entity:SetMaterialParam(param, pos.x, pos.y, pos.z)
        Sleep(0)
    end
end