module(..., package.seeall)

local function _GetDamageTypeFromColour(colour)
    local maxColour = math.max(colour.red, math.max(colour.green, colour.blue))
    local minColour = math.min(colour.red, math.min(colour.green, colour.blue))
    local deltaVal = maxColour - minColour
    local S = 0
    if (maxColour > 0) then
        S = deltaVal / maxColour
    end
    if S < 0.20 then
        return(Engine.DT_FREEZE)
    elseif maxColour == colour.red then
        return(Engine.DT_FIRE)
    elseif maxColour == colour.green then
        return(Engine.DT_POISON)
    else
        return(Engine.DT_ELECTRICITY)
    end
end

function GetDamageTypeFromColour(colour)
    return(_GetDamageTypeFromColour(colour))
end

function GetDefaultDamageType()
    return Engine.DT_FIRE
end

function ElementType(suit, defaultOverride)
    local eType = Engine.DT_FIRE
    if defaultOverride ~= nil then
        eType = defaultOverride
    end

    if not IsNull(suit) then
        local customization = suit:GetCustomization()
        local colors = customization:GetColors(Lotus_Game.PrimaryColors)
        if colors:Initialized(Lotus_Game.EmissiveColor0) then
            local colour
            if IsNull(gGameRules) or gGameRules:IsA(gLotusAttractModeGameRulesType) or _T.InSimulacrum then
                colour = colors.mEmissiveColor0
            else
                colour = suit:GetEnergyElementColor()
            end
            eType = _GetDamageTypeFromColour(colour)
        end
    end
    
    return eType
end

function ElementFxIdx(eType)
    if eType == Engine.DT_POISON then
        return 2
    elseif eType == Engine.DT_FREEZE then
        return 3
    elseif eType == Engine.DT_ELECTRICITY then
        return 4
    end
    
    return 1    -- DT_FIRE
end