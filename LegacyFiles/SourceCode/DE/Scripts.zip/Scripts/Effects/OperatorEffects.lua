OperatorDeco = WeakResource()
animToPlay = Resource()
loopAnimToPlay = Resource()
endingLocalOffset = Vector()
speed = 1.0
tennoAvatarType = Type()
tennoAnimToPlay = Resource()
tennoLoopAnimToPlay = Resource()
despawnEffect = Type()
beamType = Type()
spawnDecoTypes = {Type()}
colorCorrection = Resource()
projectorType = Type()
scarfType = Type()
hairType = WeakResource()
axis = Vector(0, 1, 0)
isCinematic = false
hairMask = Resource()
hairObjectsToHide = { Type() }
hairObjectsToSwitch = { WeakResource() }
hairObjectsNewMesh = { Resource() }
cinematicUseOverrideBone = false
cinematicBoneOverride = Symbol()
pinchLengthAtten = 1.0

local sRightWeaponBone = Symbol("GAME_R1_WEAPON1")
local sLeftWeaponBone = Symbol("GAME_L1_WEAPON1")
local ambientShakeAmount = 4
local ambientShakeSpeed = 2
local sPinchAtten = Symbol("PinchAtten")
local sUnlitAtten = Symbol("UnlitAtten")
local sAxisVector = Symbol("AxisVector")
local sPinchLength = Symbol("PinchLength")
local sPinchOverridePoint = Symbol("PinchOverridePoint")
local sHipBone = Symbol("GAME_C1_HIP1")

local startingLocalOffset = Vector(-0.5, 0, -3)

function OperatorAnimations(operator)
    if not IsNull(operator) then
        operator:PlayAnimation(animToPlay, true, false)
    end
    if not IsNull(operator) then
        operator:PlayAnimation(loopAnimToPlay, false, true)
    end
end

function TennoAnimations(tenno)
    if not IsNull(tenno) then
        tenno:PlayAnimation(tennoAnimToPlay, true, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_FREEZE, true)
    end
    tenno:PlayAnimation(tennoLoopAnimToPlay, true, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_LOOP, true)
end

function DissolveIn(spawner)
    local avatar = spawner:GetAttachParent()
    if IsNull(avatar) then
        return
    end
    
    local suit = avatar:InventoryControl():GetActivePowerSuit()
    local operatorSuit = avatar:InventoryControl():GetWeaponInSlot(Engine.SLOT_10)
    
    if not IsNull(suit) then
        -- Returns us to our original anim controller
        local customAnimController = suit:GetAnimControllerOverride()
        if customAnimController then
            avatar:SetCustomAnimController(customAnimController)
        else
            avatar:SetCustomAnimController(nil)
        end
        
        local suitCollision = suit:GetSimCollision()
        if not IsNull(suitCollision) then
            avatar:SetSimCollision(suitCollision)
        end
        
        suit:SetCustomizationEntity(nil)
        suit:CreateAllAttachments(avatar)
        Sleep(0)
    end
    
    local startPos =  Vector()
    local dir = Vector()
    local operator = avatar:GetAttachment(OperatorDeco)
    local allDecos = {}
    local proj
    local scarf
    local hair
    if not IsNull(operator) then
        if not IsNull(operator) then
            operator:Unattach()
        end
        startPos = operator:GetSimPosition()
        dir = AngleToDirection(operator:GetRotation())
        operator:PlayAnimation(animToPlay, false, false)
        allDecos = operator:GetAllAttachments(gDecorationType)
        proj = operator:Attach(projectorType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, operatorSuit)
        scarf = operator:GetAttachment(scarfType)
        hair = operator:GetAttachment(hairType)
    end
    
    local player = avatar:GetPlayer()
    local tenno
    if not IsNull(player) then
        local playerId = player:GetPlayerID()
        if not IsNull(_T.focusKneelingAvatar) and not IsNull(_T.focusKneelingAvatar[playerId]) then
            tenno = _T.focusKneelingAvatar[playerId]
            _T.focusKneelingAvatar[playerId] = nil
            tenno:PlayAnimation(tennoAnimToPlay, false)
        end
    end
    
    if avatar:ReplicaLocallyControlled() then
        local postProcess = gRegion:GetLevelInfo().postProcess
        postProcess.viewShake.mShakeSpeed = 0
        postProcess.viewShake.mShakeAmbient = 0
        local cameraControl = avatar:CameraControl()
        cameraControl:RemoveColorCorrection(colorCorrection)
        cameraControl:AttenuateFOV(1.0)
    end
    
    local t = 0
    local doneSwap = false
    local endPos = startPos - Vector(1 * dir.x, 0, 1 * dir.z)
    local pAtten
    while t < 1 and not IsNull(operator) and not IsNull(avatar) do
        if t > 0.7 and not doneSwap then --Animation is 0.87 seconds, let's switch over at 0.7 seconds
            avatar:RemoveInvisibilityRequest()
            gRegion:CreateEntity(despawnEffect, operator:GetBonePosition(Symbol("GAME_C1_SPINE5")), ZERO_ROTATION, operatorSuit)
            if not IsNull(tenno) then
                local pos = tenno:GetSimPosition()
                local attachedParent = tenno:GetAttachParent() -- see if we're on a mover, move us up a bit in case it's elevator stuff going on
                if not IsNull(attachedParent) and attachedParent:IsA(gMoverType) and attachedParent:GetMoverVelocity().y > 0 then
                    pos.y = pos.y + 1.5
                end
                avatar:Teleport(pos, tenno:GetSimRotation())
                avatar:SetView(tenno:GetView())
                tenno:Destroy()
            end
            doneSwap = true
        end
        --operator:SetDissolve(t)
        pAtten = 0.5 - 0.5 * t
        operator:SetMaterialParam(sPinchAtten, pAtten)
        for i, temp in ipairs(allDecos) do
            if not IsNull(temp) then
                temp:SetMaterialParam(sPinchAtten, pAtten)
            end
        end
        if not IsNull(proj) then
            proj:SetMaterialParam(sPinchAtten, pAtten)
        end
        if not IsNull(scarf) then
            scarf:SetMaterialParam(sUnlitAtten, math.max(0, 2 - t * 4))
        end
        if not IsNull(hair) then
            hair:SetDissolve(math.pow(t, 4))
        end
        operator:SetPosition(LerpVector(startPos, endPos, 1 - math.pow(1 - t, 2)))
        t = t + DeltaTime() * 1
        Sleep(0)
    end
    if not IsNull(operator) then
        operator:Destroy()
    end
end

function OperatorCustomization(operator)
    local avatar = operator:GetAttachParent()
    if IsNull(avatar) then
        return
    end
    
    local suit = avatar:InventoryControl():GetActivePowerSuit()
    if not IsNull(operator) then
        operator:ScriptRunChildScript(Symbol("OperatorAnimations"), false)
    end
    
    local operatorSuit = avatar:InventoryControl():GetWeaponInSlot(Engine.SLOT_10)
    if not IsNull(operatorSuit) then
        local newCollision = operatorSuit:GetSimCollision()
        if not IsNull(newCollision) then
            avatar:SetSimCollision(newCollision)
        end
        operatorSuit:SetCustomizationEntity(operator)
        operatorSuit:CreateAllAttachments(avatar)
    end
    
    local playerId = avatar:GetAuthoritativePlayer():GetPlayerID()
    if IsNull(_T.focusKneelingAvatar) then
        _T.focusKneelingAvatar = {}
    end
            
    --local tenno = gRegion:CreateEntity(tennoDecoType, avatar:GetSimPosition(), avatar:GetSimRotation(), avatar)
    local tenno = gRegion:CreateEntity(tennoAvatarType, avatar:GetSimPosition(), avatar:GetSimRotation(), avatar)
    local mover = avatar:MotionControl():GetMover()
    if not IsNull(mover) then
        tenno:AttachToInPlace(mover, EMPTY_SYMBOL)
    end
    tenno:SetAuthoritativePlayer(avatar:GetPlayer())
    if not IsNull(tenno) then
        tenno:SetView(avatar:GetView())
        tenno:SetFaction(avatar:GetFaction())
        tenno:SetThreatModifier(-1)
        tenno:DamageControl():SetExclusiveDamageSource(tenno)
        
        tenno:ScriptRunChildScript(Symbol("TennoAnimations"), false)
        _T.focusKneelingAvatar[playerId] = tenno
    end
    
    avatar:AddInvisibilityRequest()
    
    if avatar:ReplicaLocallyControlled() then
        local postProcess = gRegion:GetLevelInfo().postProcess
        postProcess.viewShake.mShakeSpeed = ambientShakeSpeed
        postProcess.viewShake.mShakeAmbient = ambientShakeAmount
        
        local cameraControl = avatar:CameraControl()
        cameraControl:RadialBlurView(1.25, 1.05, 1.05, 3.5)
        cameraControl:PushColorCorrection(colorCorrection, 1.0, -1.0, 1.0)
        cameraControl:AttenuateFOV(1.1)
    end
    
    local allDecos = operator:GetAllAttachments(gDecorationType)
    local proj = operator:Attach(projectorType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, operatorSuit)
    local pAtten
    local t = 0
    operator:SetMaterialParam(sPinchOverridePoint, 0, 0, 0, 0)
    for i, temp in ipairs(allDecos) do
        if not IsNull(temp) then
            temp:SetMaterialParam(sPinchOverridePoint, 0, 0, 0, 0)
        end
    end
    while t < 1 and not IsNull(avatar) do
        if not IsNull(operator) then
            local val = math.pow(1 - t, 3)
            local newPos = LerpVector(endingLocalOffset, startingLocalOffset, val)
            operator:SetAttachLocalSpace(newPos, ZERO_ROTATION)
            pAtten = 0.5 * t
            operator:SetMaterialParam(sPinchAtten, pAtten)
            if #allDecos == 1 then  --Items from customization haven't been created yet
                allDecos = operator:GetAllAttachments(gDecorationType)
            end
            for i, temp in ipairs(allDecos) do
                if not IsNull(temp) then
                    temp:SetMaterialParam(sPinchAtten, pAtten)
                end
            end
            if not IsNull(proj) then
                proj:SetMaterialParam(sPinchAtten, pAtten)
            end
        end
        t = t + DeltaTime() * speed
        Sleep(0)
    end
    for i, temp in ipairs(allDecos) do
        if not IsNull(temp) then
            temp:SetMaterialParam(sPinchAtten, 0.5)
        end
    end
    
    Sleep(0)
    --Running this again to fix the first cast not getting updated properly
    if not IsNull(operatorSuit) and not IsNull(avatar) then
        local newCollision = operatorSuit:GetSimCollision()
        if not IsNull(newCollision) then
            avatar:SetSimCollision(newCollision)
        end
    end
end

function TennoDecoCustomization(deco)  --Maybe this should be an avatar?
    local instigatorAvatar = deco:GetCreator()
    if IsNull(instigatorAvatar) then
        return
    end
    local suit = instigatorAvatar:InventoryControl():GetActivePowerSuit()
    if IsNull(suit) then
        return
    end
    --Do shit here
end

function TennoCustomization(decoyAvatar)
    local instigatorAvatar = decoyAvatar:GetCreator()
    if IsNull(instigatorAvatar) then
        return
    end
    local suit = instigatorAvatar:InventoryControl():GetActivePowerSuit()
    if IsNull(suit) then
        return
    end
    -- disable auras so that the effects don't double up from the loadout copy
    decoyAvatar:InventoryControl():AddUpgrade(Game.AVATAR_AURA_STRENGTH, Game.SET, 0)
    decoyAvatar:InventoryControl():CopyLoadoutFromPlayer(instigatorAvatar:GetPlayer(), false, false)
    --Do shit here

    local decoySuit = decoyAvatar:InventoryControl():GetActivePowerSuit()
    if not IsNull(decoySuit) and decoySuit:IsA(WeakResource("/Lotus/Powersuits/YinYang/YinYang")) then
        local POLARITY = require "Lotus.Scripts.Effects.Polarity"
        if POLARITY.IsYin(suit) then
            POLARITY.ForceYin(decoySuit)
        elseif POLARITY.IsYang(suit) then
            POLARITY.ForceYang(decoySuit)
        end
    end
end

function OperatorSpawnEffect(spawner)
    local operator = spawner:GetAttachParent()
    if IsNull(operator) then
        return
    end
    local avatar = operator:GetAttachRoot()
    
    local operatorSuit = avatar:InventoryControl():GetWeaponInSlot(Engine.SLOT_10)
    
    local beam = operator:Attach(beamType, sRightWeaponBone, Vector(0, -0.05, 0), ZERO_ROTATION, operatorSuit)
    if not IsNull(beam) then
        beam:SetEndPointEntity(operator, Symbol("GAME_L1_ARM3"))
    end
    
    local sDecos = {}
    for i=1, #spawnDecoTypes do
        local deco = gRegion:CreateEntity(spawnDecoTypes[i], operator:GetSimPosition(), ZERO_ROTATION, operatorSuit)
        if not IsNull(deco) then
            table.insert(sDecos, deco)
        end
    end
    
    local t = 0
    local pos = Vector()
    while t < 1.2 and not IsNull(operator) do
        pos = LerpVector(operator:GetBonePosition(sRightWeaponBone), operator:GetBonePosition(sLeftWeaponBone), 0.5)
        for i=1, #sDecos do
            if not IsNull(sDecos[i]) then
                sDecos[i]:SetPosition(pos)
            end
        end
        t = t + DeltaTime()
        Sleep(0)
    end
end

local function AllItems(avatar)
    local allDecos = avatar:GetAllAttachments(gDecorationType)
    local allCloth = avatar:GetAllAttachments(gSkeletalClothExType)
    local allWeapons = avatar:GetAllAttachments(gLotusWeaponAttachmentType)
    local items = {}
    for i, temp in ipairs(allDecos) do
        if not IsNull(temp) then
            table.insert(items, temp)
        end
    end
    for i, temp in ipairs(allCloth) do
        if not IsNull(temp) then
            table.insert(items, temp)
        end
    end
    for i, temp in ipairs(allWeapons) do
        if not IsNull(temp) then
            table.insert(items, temp)
        end
    end
    local proj = avatar:Attach(projectorType, EMPTY_SYMBOL)
    if not IsNull(proj) then
        table.insert(items, proj)
    end
    table.insert(items, avatar)
    return items
end

function OperatorCinematicSpawnIn(spawner)
    Sleep(0)
    local operator = spawner:GetAttachRoot()
    if IsNull(operator) then
        return
    end
    local bone = sHipBone
    if cinematicUseOverrideBone then
        bone = cinematicBoneOverride
    end
    Effects.SetChildVisibleByRes(operator, gParticleSysType, true, false)
    local pos = operator:GetBonePosition(bone)
    local allDecos = AllItems(operator, projectorType)
    for i, temp in ipairs(allDecos) do
        if not IsNull(temp) then
            temp:SetMaterialParam(sPinchLength, 1.6 * pinchLengthAtten)
            temp:SetDissolve(0)
        end
    end
    local pAtten
    local t = 0
    local adjustedAxis = Vector(0, 1, 0)
    while t < 1 and not IsNull(operator) do
        pAtten = 0.5 * math.pow(t, 3)
        pos = operator:GetBonePosition(bone)
        --pos.y = pos.y - t * 1
        if not isCinematic then
            adjustedAxis = operator:GetForwardVector() + axis
        end
        pAtten = 1 - pAtten

        if #allDecos < 3 then  --Items from customization haven't been created yet
            allDecos = AllItems(operator)
        end
        for i, temp in ipairs(allDecos) do
            if not IsNull(temp) then
                temp:SetMaterialParam(sPinchAtten, pAtten)
                temp:SetMaterialParam(sPinchOverridePoint, pos.x, pos.y, pos.z, 1)
                temp:SetMaterialParam(sAxisVector, adjustedAxis.x, adjustedAxis.y, adjustedAxis.z)
            end
        end
        t = t + DeltaTime() * speed
        Sleep(0)
    end
    for i, temp in ipairs(allDecos) do
        if not IsNull(temp) then
            temp:SetMaterialParam(sPinchAtten, 0.5)
        end
    end
    spawner:Destroy()
end

function Scene12OperatorCinematicSpawnIn(spawner)
    Sleep(0)
    local operator = spawner:GetAttachRoot()
    if IsNull(operator) then
        return
    end
    local queen = gRegion:FindFirstTagged(Symbol("IntroQueen"))
    if IsNull(queen) then
        return
    end
    local pos = queen:GetBonePosition(Symbol("GAME_C1_SPINE5"))
    local allDecos = operator:GetAllAttachments(gDecorationType)
    local allCloth = operator:GetAllAttachments(gSkeletalClothExType)
    operator:SetMaterialParam(sAxisVector, axis.x, axis.y, axis.z)
    operator:SetMaterialParam(sPinchLength, 2)
    operator:SetMaterialParam(sPinchOverridePoint, pos.x, pos.y, pos.z, 1)
    local pLength = 1.0
    local proj = operator:Attach(projectorType, EMPTY_SYMBOL)
    for i, temp in ipairs(allDecos) do
        if not IsNull(temp) then
            temp:SetMaterialParam(sAxisVector, axis.x, axis.y, axis.z)
            temp:SetMaterialParam(sPinchLength, pLength)
            temp:SetMaterialParam(sPinchOverridePoint, pos.x, pos.y, pos.z, 1)
        end
    end
    for i, temp in ipairs(allCloth) do
        if not IsNull(temp) then
            temp:SetMaterialParam(sAxisVector, axis.x, axis.y, axis.z)
            temp:SetMaterialParam(sPinchLength, pLength)
            temp:SetMaterialParam(sPinchOverridePoint, pos.x, pos.y, pos.z, 1)
        end
    end
    if not IsNull(proj) then
        proj:SetMaterialParam(sAxisVector, axis.x, axis.y, axis.z)
        proj:SetMaterialParam(sPinchLength, pLength)
        proj:SetMaterialParam(sPinchOverridePoint, pos.x, pos.y, pos.z, 1)
    end
    local pAtten
    local t = 0
    while t < 1 and not IsNull(operator) do
        local val = math.pow(1 - t, 3)
        pAtten = 0.1 + 0.4 * t
        pos = queen:GetBonePosition(Symbol("GAME_C1_SPINE5")) + Vector(0, 0, -0.25)
        operator:SetMaterialParam(sPinchOverridePoint, pos.x, pos.y, pos.z, 1)
        operator:SetMaterialParam(sPinchAtten, pAtten)
        if #allDecos == 1 then  --Items from customization haven't been created yet
            allDecos = operator:GetAllAttachments(gDecorationType)
        end
        for i, temp in ipairs(allDecos) do
            if not IsNull(temp) then
                temp:SetMaterialParam(sPinchAtten, pAtten)
                temp:SetMaterialParam(sPinchOverridePoint, pos.x, pos.y, pos.z, 1)
            end
        end
        for i, temp in ipairs(allCloth) do
            if not IsNull(temp) then
                temp:SetMaterialParam(sPinchAtten, pAtten)
                temp:SetMaterialParam(sPinchOverridePoint, pos.x, pos.y, pos.z, 1)
            end
        end
        if not IsNull(proj) then
            proj:SetMaterialParam(sPinchAtten, pAtten)
            proj:SetMaterialParam(sPinchOverridePoint, pos.x, pos.y, pos.z, 1)
        end
        t = t + DeltaTime() * speed
        Sleep(0)
    end
    operator:SetMaterialParam(sPinchAtten, 0.5)
    for i, temp in ipairs(allDecos) do
        if not IsNull(temp) then
            temp:SetMaterialParam(sPinchAtten, 0.5)
        end
    end
    for i, temp in ipairs(allCloth) do
        if not IsNull(temp) then
            temp:SetMaterialParam(sPinchAtten, 0.5)
        end
    end
end

function OperatorCinematicSpawnOut(spawner)
    Sleep(0)
    local operator = spawner:GetAttachRoot()
    if IsNull(operator) then
        return
    end
    local pLength = 1.2
    local pos = operator:GetBonePosition(sHipBone)
    local allDecos = AllItems(operator, projectorType)
    for i, temp in ipairs(allDecos) do
        if not IsNull(temp) then
            temp:SetMaterialParam(sAxisVector, axis.x, axis.y, axis.z)
            temp:SetMaterialParam(sPinchLength, pLength)
        end
    end
    local pAtten
    local t = 1
    while t > 0 and not IsNull(operator) and not _T.transferenceInterrupted do
        pAtten = 0.5 * t
        pos = operator:GetBonePosition(sHipBone)
        for i, temp in ipairs(allDecos) do
            if not IsNull(temp) then
                temp:SetMaterialParam(sPinchAtten, pAtten)
                temp:SetMaterialParam(sPinchOverridePoint, pos.x, pos.y, pos.z, 1)
                temp:SetDissolve(1 - t)
            end
        end
        t = t - DeltaTime() * speed
        Sleep(0)
    end
    
    if not _T.transferenceInterrupted then
        for i, temp in ipairs(allDecos) do
            if not IsNull(temp) then
                temp:SetMaterialParam(sPinchAtten, 0.5)
            end
        end
    else
        _T.transferenceInterrupted = nil
    end
    
    Effects.SetChildVisibleByRes(operator, gParticleSysType, false, false)
end


function OperatorDeathSpawnOut(spawner)
    Sleep(0.5)
    local operator = spawner:GetAttachRoot()
    if IsNull(operator) then
        return
    end
    local pLength = 1.2
    local pos = operator:GetBonePosition(sHipBone)
    local adjustedAxis = operator:GetForwardVector()
    local allDecos = AllItems(operator, projectorType)
    for i, temp in ipairs(allDecos) do
        if not IsNull(temp) then
            temp:SetMaterialParam(sAxisVector, adjustedAxis.x, adjustedAxis.y, adjustedAxis.z)
            temp:SetMaterialParam(sPinchLength, pLength)
            temp:SetMaterialParam(sPinchOverridePoint, pos.x, pos.y, pos.z, 1)
        end
    end
    local pAtten
    local t = 1
    
    while t > 0 and not IsNull(operator) do
        local val = math.pow(1 - t, 3)
        pAtten = 0.5 * t
        pos = operator:GetBonePosition(sHipBone)
        adjustedAxis = operator:GetForwardVector()

        for i, temp in ipairs(allDecos) do
            if not IsNull(temp) then
                temp:SetMaterialParam(sPinchAtten, pAtten)
                temp:SetMaterialParam(sPinchOverridePoint, pos.x, pos.y, pos.z, 1)
            end
        end
        t = t - DeltaTime() * speed
        Sleep(0)
    end
    for i, temp in ipairs(allDecos) do
        if not IsNull(temp) then
            temp:SetMaterialParam(sPinchAtten, 0.5)
        end
    end
end

function MaskHair(deco)
    local avatar = deco:GetAttachRoot()
    if IsNull(avatar) then
        return
    end
    local hair = avatar:GetAllAttachments(hairType)
    if IsNull(hair) or #hair < 1 then
        Sleep(0)
        hair = avatar:GetAllAttachments(hairType)
    end
    if IsNull(hair) then
        hair = {}
        Sleep(0) --Wait for attachments
        local newHairSymbol = Symbol("DoNotMirror")
        local allDecos = avatar:GetAllAttachments(gDecorationType)
        for i=1, #allDecos do
            if allDecos[i]:HasTag(newHairSymbol) then --Can be multiple decos, collect all
                table.insert(hair, allDecos[i])
                local hairOnThisDeco = allDecos[i]:GetAllAttachments(gSkeletalClothExType)
                for j=1, #hairOnThisDeco do
                    if not hairOnThisDeco[j]:HasTag(newHairSymbol) then --Tagged ones found below
                        table.insert(hair, hairOnThisDeco[j])
                    end
                end
            end
        end
        --Now check for cloth
        allDecos = avatar:GetAllAttachments(gSkeletalClothExType)
        for i=1, #allDecos do
            if allDecos[i]:HasTag(newHairSymbol) then
                table.insert(hair, allDecos[i]) --Some hair is multiple attached skelcloth with no parent
            end
        end
    end
    for i=1, #hair do
        local temp = hair[i]
        if not IsNull(temp) and not IsNull(hairMask) then
            temp:SetTextureOverride(0, "SphericalMap", hairMask)
            temp:SetTextureOverride(1, "SphericalMap", hairMask)
            temp:SetTextureOverride(2, "SphericalMap", hairMask)
            temp:SetTextureOverride(3, "SphericalMap", hairMask) --HairR has 4 slots
        end
    end
    for i=1, #hairObjectsToHide do
        --Hide certain hair bands, etc
        local hairDeco = avatar:GetAttachment(hairObjectsToHide[i])
        if not IsNull(hairDeco) then
            hairDeco:SetVisibility(false, false)
        end
    end
    if IsNull(hair) or #hair < 1 then
        return
    end
    local hairMainDeco = hair[1]
    if not IsNull(hairMainDeco) and (#hairObjectsToSwitch > 0) and #hairObjectsNewMesh == #hairObjectsToSwitch then
        for i=1, #hairObjectsToSwitch do
            --Hide certain hair bands, etc
            if hairMainDeco:IsA(hairObjectsToSwitch[i]) then
                local newMesh = hairObjectsNewMesh[i]
                hairMainDeco:SetMesh(newMesh, false, false)
            end
        end
    end
end