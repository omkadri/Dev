avatarType = WeakResource()
applyEnergyColor = false
speedMult = 1.0 
decoType = Type()
MuzzleAttachedEffects = Type()
rotateBeamTowardsEnd = false

local IllusionAvatar = WeakResource("/Lotus/Powersuits/Harlequin/IllusionMirrorAvatar")

local COLOR_UTIL = require "Lotus.Scripts.Effects.EffectsColorUtilities"
local FlowTag = Symbol("FlowSparks")

local function ReduceTerm(input, t, drag)
    if t == 0 then
        return(input)
    else
        local result = ReduceTerm(input, t-1, drag)
        return(result - (result * drag))
    end
end

-- Limits how far we spew the fire particles without having to give those particles collision
function MatchParticleSpeedToBeamLength(particleSys)
    local avatar = particleSys
    local beamParent = particleSys:GetAttachParent()
    
    while not IsNull(avatar) and not avatar:IsA(avatarType) do
        avatar = avatar:GetAttachParent()
    end
    
    if IsNull(avatar) then
        return
    end
    
    if avatar:IsA(IllusionAvatar) then
        local pQ = COLOR_UTIL.ParticleQuality()
        if pQ ~= 2 then --Only render these for High
            particleSys:Destroy()
        end
        return
    end
    
    local weapon = avatar:InventoryControl():GetWeaponInHand(Engine.MAIN_HAND)
    
    if IsNull(weapon) then
        return
    end

    local drag = particleSys:GetDrag()

    -- Figuring out how much speed to give the particles is complicated... particle life
    -- can vary and drag is non-constant deceleration based on current speed.
    -- Actually requires solving a differential equation which I don't feel like remembering
    -- how to do, so using a gross dumb discrete approximation.
    -- Editor's note: at least you could call this only once (~2000 function calls!)
    local iterations = 32
    local constantTimesV0 = 0
    for i=1, iterations do
        local result = ReduceTerm(1, i - 1, drag / iterations)
        constantTimesV0 = constantTimesV0 + (result / iterations)
    end
    
    if applyEnergyColor then
        weapon:ApplyEnergyColor(particleSys)
    end
    while not IsNull(beamParent) and not IsNull(particleSys) do
        local traceDistance = beamParent:DistanceToPoint(beamParent:GetEndPoint())
        
        local maxSpeed = speedMult * traceDistance / constantTimesV0
        local minSpeed = speedMult * maxSpeed / 5.0
        
        particleSys:SetSpeed(minSpeed, maxSpeed)
        Sleep(0)
    end
end

function BeamMain(beam)
    Sleep(0)
    local weapon = beam:GetCreator()
    if IsNull(weapon) then
        return
    end
    
    local avatar = weapon:GetOwner()
    if IsNull(avatar) then
        return
    end
    
    local newSpew = 6
    local pQ = COLOR_UTIL:ParticleQuality()
    if avatar:IsA(IllusionAvatar) then
        if pQ == 1 then
            newSpew = 9
        elseif pQ == 2 then
            newSpew = 12
        end
    end
    
    local pFx = beam:GetAllAttachments(gParticleSysType)
    for i=1, #pFx do
        local temp = pFx[i]
        if avatar:IsA(IllusionAvatar) then
            if temp:GetTag() == FlowTag then
                temp:SetSpewCount(newSpew * 10, newSpew * 10, false)
            else
                temp:SetSpewCount(newSpew, newSpew, false)
            end
        end
    end
    
    if not IsNull(MuzzleAttachedEffects) then
        beam:Attach(MuzzleAttachedEffects, EMPTY_SYMBOL)
    end

    local drag = 4
    
    local iterations = 32
    local constantTimesV0 = 0
    for i=1, iterations do
        local result = ReduceTerm(1, i - 1, drag / iterations)
        constantTimesV0 = constantTimesV0 + (result / iterations)
    end
    
    local avatarInstance = avatar:GetInstance()
    local endPoint = Vector()
    local attachVec = Vector()
    local rot = Rotation()
    if rotateBeamTowardsEnd then
        attachVec = beam:GetLocalAttachPosition()
    end
    while not IsNull(weapon) and weapon:IsFiring() do
        endPoint = beam:GetEndPoint()
        local traceDistance = math.max(1, beam:DistanceToPoint(endPoint))
        
        if rotateBeamTowardsEnd then
            rot = LookTo(beam:GetPosition(), endPoint)
            beam:SetAttachLocalSpace(RotateVector(attachVec, rot), rot)
        end
        
        local maxSpeed = math.max(16.0, speedMult * traceDistance / constantTimesV0)
        local minSpeed = speedMult * maxSpeed / 5.0

        for i=1, #pFx do
            if not IsNull(pFx[i]) then
                pFx[i]:SetSpeed(minSpeed, maxSpeed)
            end
        end
        
        if not (_T.flameThrowerGlow == nil) and not IsNull(_T.flameThrowerGlow[avatarInstance]) then
            _T.flameThrowerGlow[avatarInstance] = math.min(4.0, _T.flameThrowerGlow[avatarInstance] + DeltaTime() * 0.8)
        end
        Sleep(0)
    end
    
    for i=1, #pFx do
        if not IsNull(pFx[i]) then
            pFx[i]:Disable()
        end
    end
    beam:Destroy()
end

function ConstantGlow(weaponAttachment)
    Sleep(0)
    local weapon = weaponAttachment:GetWeapon()
    if IsNull(weapon) or not weapon:IsA(gLotusWeaponType) then
        return
    end
    local avatar = weapon:GetAvatarOwner()
    
    if IsNull(avatar) then
        return
    end
    
    if _T.flameThrowerGlow == nil then
        _T.flameThrowerGlow = {}
    end
    
    if _T.flameThrowerGlow[avatar:GetInstance()] == nil then
        _T.flameThrowerGlow[avatar:GetInstance()] = 0.05 --Make sure it'll run through and set it to 0 initially
    end

    while IsNull(gGameRules) do
        Sleep(0)
    end

    if gGameRules:IsA(gLotusHubGameRulesType) then
        return -- May need to run an initial set up or update certain weapons
    end
    
    local glowDeco = weaponAttachment:Attach(decoType, EMPTY_SYMBOL, Vector(0, 0.1, 0.73))

    local avatarInstance = avatar:GetInstance()

    while not IsNull(avatar) and not IsNull(glowDeco) do
        local flameThrowerGlow = _T.flameThrowerGlow[avatarInstance]
        local t = math.max(0, flameThrowerGlow)
        
        if t > 0 then    
            glowDeco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, t)
            Sleep(0.0)
            _T.flameThrowerGlow[avatarInstance] = math.max(0, flameThrowerGlow - DeltaTime() * 0.5)
        else
            Sleep(0.0)
        end
    end
end