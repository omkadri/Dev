idleEffect = Type()
beamType = Type()
timerBase = 0.3
timerRange = 0.4

local attachBones = {
    Symbol("GAME_C1_SPINE1"),
    Symbol("GAME_C1_SPINE2"),
    Symbol("GAME_C1_SPINE1"),
    Symbol("GAME_C1_SPINE2"),
    Symbol("GAME_C1_SPINE3"),
    Symbol("GAME_R1_LEG1"),
    Symbol("GAME_L1_LEG1"),
    Symbol("GAME_R1_LEG2"),
    Symbol("GAME_L1_LEG2"),
    Symbol("GAME_L1_ARM1")
}
local jetPackType = WeakResource("/Lotus/Types/Game/FlightJetPack")

function PrimeA(spawner)
    Sleep(0.2)
    if IsNull(gGameRules) then
        return
    end
    local avatar = spawner:GetAttachRoot()
    if IsNull(avatar) or not avatar:IsA(gLotusAvatarType) then
        return
    end
    if not IsNull(avatar:GetAttachment(WeakResource("/Lotus/Types/Game/FlightJetPack"))) then
        return
    end
    local suit = avatar:InventoryControl():GetActivePowerSuit()
    if IsNull(suit) then
        return
    end
    Engine.EnableZoneCull(avatar)
    local creator = spawner:GetCreator()
    local isInArsenal = _T.ArsenalOpen
    local timer = 0.3
    local pos = Vector()
    local oldPos = avatar:GetSimPosition()
    local localAvatar = gRegion:GetLocalPlayerAvatar()
    while not IsNull(avatar) do
        if isInArsenal and IsNull(creator) then
            return
        end
        pos = avatar:GetSimPosition()
        local dist = avatar:DistanceToPoint(oldPos)
        oldPos = pos
        if (dist / DeltaTime()) < 0.5 and not avatar:HasPostureModifier(Engine.PM_CLOAK) then
            timer = timer - DeltaTime()
            if timer < 0 then
                if IsNull(localAvatar) then
                    localAvatar = gRegion:GetLocalPlayerAvatar()
                elseif localAvatar:DistanceToEntity(avatar) < 50 then
                    avatar:Attach(beamType, attachBones[math.random(1, #attachBones)], ZERO_VECTOR, ZERO_ROTATION, suit)
                end
                timer = timerBase + FRand() * timerRange
            end
            Sleep(0)
        else
            Sleep(0.2)
        end
    end
end

function CreateIdleEffect(spawner)
    Sleep(0.2)
    if IsNull(gGameRules) then
        return
    end
    local avatar = spawner:GetAttachRoot()
    if IsNull(avatar) or not avatar:IsA(gLotusAvatarType) then
        return
    end
    local suit = avatar:InventoryControl():GetActivePowerSuit()
    if IsNull(suit) then
        return
    end
    Engine.EnableZoneCull(avatar)
    local effect = nil
    local wasIdle = false
    while not IsNull(avatar) do
        local isIdle = avatar:IsIdle()
        local cooldown = 0.1
        if isIdle and not wasIdle then
            effect = avatar:GetAttachment(idleEffect)
            if IsNull(effect) then
                effect = avatar:Attach(idleEffect, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, suit)
            end
            cooldown = 1
        elseif not isIdle and wasIdle then
            if not IsNull(effect) then
                effect:Destroy()
            end
            cooldown = 1
        end
        wasIdle = isIdle
        Sleep(cooldown)
    end
end