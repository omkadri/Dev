shakeAmplitude = 6
shakeSpeed = 2
speed = 0.2
maxDistance = 1200

function GiantExplosion(spawner)

    local pos = spawner:GetPosition()
    local avatar = gRegion:GetLocalPlayerAvatar()
    if IsNull(avatar) then
        return
    end
    local postProcess = gRegion:GetLevelInfo().postProcess
     
    local distance = avatar:DistanceToPoint(pos)
    distance = math.min(distance / maxDistance, 1)
    
    postProcess.viewShake.mShakeSpeed = shakeSpeed
    
    local t = 1
    while t > 0 and not IsNull(avatar) do
        if (1 - t) > distance then --delay the shake
            postProcess.viewShake.mShakeAmbient = t  * shakeAmplitude
        end
        postProcess.fade = -t * (1 - distance) --atten by view angle?
        Sleep(0)
        t = t - DeltaTime() * speed
    end
    
    postProcess.fade = 0
    postProcess.viewShake.mShakeSpeed = 1
    postProcess.viewShake.mShakeAmbient = 0
end