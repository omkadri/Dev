animatedDecoType = Type()
pickupGlowType = Type()
fakeCreditChips = Type()
beamType = Type()
sparkBurst = Type()

local bones = {
            Symbol("SimJoint_1"),
            Symbol("SimJoint_3"),
            Symbol("SimJoint_5"),
            Symbol("SimJoint_7"),
            Symbol("SimJoint_8"),
            Symbol("SimJoint_9"),
            Symbol("SimJoint_11"),
            Symbol("SimJoint_12"),
            Symbol("SimJoint_15"),
            Symbol("SimJoint_17")
}

local circuitBones = {
            Symbol("SimJoint_1"),
            Symbol("SimJoint_2"),
            Symbol("SimJoint_3"),
            Symbol("SimJoint_4"),
            Symbol("SimJoint_5"),
            Symbol("SimJoint_6"),
            Symbol("SimJoint_7"),
            Symbol("SimJoint_8"),
            Symbol("SimJoint_9"),
            Symbol("SimJoint_10"),
            Symbol("SimJoint_11"),
            Symbol("SimJoint_12"),
            Symbol("SimJoint_13"),
            Symbol("SimJoint_14"),
            Symbol("SimJoint_15"),
            Symbol("SimJoint_16"),
            Symbol("SimJoint_17"),
            Symbol("SimJoint_18"),
            Symbol("SimJoint_19"),
            Symbol("SimJoint_20"),
            Symbol("SimJoint_21"),
            Symbol("SimJoint_22")
}

function CreditPickup(pickup)
    pickup:SetDissolve(1)
    local aDeco = gRegion:CreateEntity(animatedDecoType, pickup:GetSimPosition(), pickup:GetSimRotation(), nil, pickup)
    local t = 0
    local fakeCount = 0
    local rRot = Rotation()
    local rForce = Vector()
    while not IsNull(pickup) and not IsNull(aDeco) and t < 2 do
        if fakeCount < 10 then
            rRot.heading = Random(-180, 180)
            rRot.pitch = Random(-180, 180)
            rRot.bank = Random(-180, 180)
            local fake = gRegion:CreateEntity(fakeCreditChips, aDeco:GetBonePosition(bones[math.random(1, #bones)]), rRot, pickup, pickup)
            if not IsNull(fake) then
                rForce.x = Random(-100, 100)
                rForce.z = Random(-100, 100)
                fake:ApplyForce(rForce)
            end
            fakeCount = fakeCount + 1
        end
        aDeco:SetDissolve(math.max(1 - t, 0))
        local rot = pickup:GetSimRotation()
        local pos = LerpVector(aDeco:GetSimPosition(), pickup:GetSimPosition(), 0.02 + 0.05 * t) -- + math.max(0, 0.04 - pickup:GetSpeed()))
        aDeco:SetPosition(pos)
        rot.heading = rot.heading * t * 0.5
        rot.pitch = rot.pitch * t * 0.5
        rot.bank = rot.bank * t * 0.5
        aDeco:SetRotation(rot)
        t = t + DeltaTime()
        Sleep(0)
    end
    pickup:SetDissolve(0)
    pickup:Attach(pickupGlowType, EMPTY_SYMBOL)
    if not IsNull(aDeco) then
        aDeco:Destroy()
    end
end

function CircuitsPickup(deco)
    local t = 0
    local boneA = Symbol()
    local boneB = Symbol()
    while t < 4.5 and not IsNull(deco) do
        boneA = circuitBones[math.random(1, #circuitBones)]
        boneB = circuitBones[math.random(1, #circuitBones)]
        local beam = deco:Attach(beamType, boneA)
        if not IsNull(beam) then
            beam:SetEndPointEntity(deco, boneB)
        end
        --deco:Attach(sparkBurst, boneA)
        deco:Attach(sparkBurst, boneB)
        local toSleep = Random(0.1, 0.3)
        Sleep(toSleep)
        t = t + toSleep
    end
end