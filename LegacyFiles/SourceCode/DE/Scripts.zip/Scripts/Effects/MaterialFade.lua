-- ramp a material value up or down

OriginalValue = 1 
NewValue = 2 
TimeLength = 1
OriginalScale = 0.1
NewScale = 1
Peak = 0.5
PeakEnd = 0.8
PeakValue = 1
ValleyValue = 0
ValleyEndValue = 0
Param = Symbol()
TargetDeco = {Instance()}
Delay = 0
OriginalValueTwo = 1 
NewValueTwo = 2 
ParamTwo = Symbol()
destroyAtEnd = false
showAtStart = false
hideAtEnd = false
meshScaleValley = 0.1
meshScalePeak = 1.0
applyEnergyColor = false
energyColorParam = Symbol("TintColor")
getParentFirst = false
applyToParent = false
applyToChildren = false
checkInstigator = false
instigatorDuration = {0,0}
instigatorPower = 1
isMeleeWeapon = false
isWeapon = false
alphaMult = 1
getCastingSpeed = false
gcsGetCreator = false
applyLowHigh = true
scaleForExplosionMod = false
isArchwing = false
powScale = false
invertPowScale = false
powerAmount = 3
isRandomMeshScale = false
checkKilled = false

local COLOR_UTIL = require "Lotus.Scripts.Effects.EffectsColorUtilities"

local function EnergyColor(deco, mParam, pFirst)
    local lotusAvatar
    local parent
    if pFirst then
        parent = deco:GetAttachRoot()
    else
        parent = deco:GetCreator()
    end
    if IsNull(parent) then
        return
    end
    local replicantAvatar = WeakResource("/Lotus/Types/Enemies/TennoReplicants/TennoReplicantAvatar")
    if parent:IsA(replicantAvatar) then
        deco:SetMaterialParam(mParam, 5 / 255, 145 / 255, 175 / 255, alphaMult * 1)
        return
    end
    if parent:IsA(gLotusAvatarType) then
        lotusAvatar = parent
    else
        local parentTwo = nil
        if parent:IsA(gPowerSuitType) then
            parentTwo = parent
        else
            parentTwo = parent:GetCreator()
        end
        if isWeapon then
            local weaponType = WeakResource("/Lotus/Types/Game/LotusWeapon")
            if not parentTwo:IsA(weaponType) then
                return nil
            end
            lotusAvatar = parentTwo
        elseif not IsNull(parentTwo) and parentTwo:IsA(gPowerSuitType)then
            lotusAvatar = parentTwo:GetOwner()
        else
            if not IsNull(parentTwo) then
                lotusAvatar = parentTwo:GetAttachRoot()
            else
                lotusAvatar = parent:GetAttachRoot()
            end
        end
        if lotusAvatar:IsA(replicantAvatar) then
            deco:SetMaterialParam(mParam, 5 / 255, 145 / 255, 175 / 255, alphaMult * 1)
            if applyLowHigh then
                COLOR_UTIL.ApplyHighLow(deco, Color(5, 145, 175, alphaMult * 1))
            end
            return
        end
    end
    if not lotusAvatar:IsA(gLotusAvatarType) and not isWeapon then
        return nil
    end
    if not IsNull(lotusAvatar) then
        local powersuit
        if isWeapon then
            powersuit = lotusAvatar
        else
            if isArchwing then
                powersuit = lotusAvatar:InventoryControl():GetAlternatePowerSuit()
            else
                powersuit = lotusAvatar:InventoryControl():GetActivePowerSuit()
            end
        end
        if isMeleeWeapon then
            powersuit = lotusAvatar:InventoryControl():GetMeleeWeapon()
        end
        if scaleForExplosionMod and lotusAvatar:IsA(gLotusWeaponType) then
            local baseScale = deco:GetMeshScale()
            local creator = lotusAvatar:GetOwner() --If you're here, lotusAvatar is a weapon at this point
            local attenuatedScale = creator:InventoryControl():GetUpgradeModifiedValue(baseScale, Game.WEAPON_EXPLOSION_RADIUS, lotusAvatar:GetType(),lotusAvatar)
            deco:SetMeshScale(attenuatedScale)
        end
        if not IsNull(powersuit) then
            local playerCustomization = powersuit:GetCustomization()
            local colors = playerCustomization:GetColors(Lotus_Game.PrimaryColors)
            if colors:Initialized(Lotus_Game.EnergyColor) then
                local energyColor = colors.mEnergyColor
                deco:SetMaterialParam(mParam, COLOR_UTIL.SRGBToLinear(energyColor.red), COLOR_UTIL.SRGBToLinear(energyColor.green), COLOR_UTIL.SRGBToLinear(energyColor.blue), alphaMult * energyColor.alpha / 255)
                if applyLowHigh then
                    COLOR_UTIL.ApplyHighLow(deco, energyColor)
                end
            end
        end
    end
end

function MaterialFade(deco)
    if Delay >= 0 then
        Sleep(Delay)
    end
    if applyToParent then
        local temp = deco:GetAttachParent()
        if not IsNull(temp) then
            deco = temp
        end
    end
    if applyEnergyColor then
        EnergyColor(deco, energyColorParam, getParentFirst)
    end
    local t = 0
    local val
    local castingSpeedOverride = 1
    if getCastingSpeed == true then --atm must be attached to the avatar
        local instigatorAvatar
        if gcsGetCreator then
            instigatorAvatar = deco:GetCreator() 
        else
            instigatorAvatar = deco:GetAttachRoot() 
        end
        if not IsNull(instigatorAvatar) then
            local inventoryControl = instigatorAvatar:InventoryControl()
            local suit = inventoryControl:GetActivePowerSuit()
            castingSpeedOverride = instigatorAvatar:InventoryControl():GetUpgradeModifiedValue(1, Game.AVATAR_CASTING_SPEED, suit:GetType(), suit)
        end
    end
    if showAtStart then
        deco:SetVisibility(true)
    end
    while t < TimeLength do
        val = Lerp(OriginalValue, NewValue, t/TimeLength)
        deco:SetMaterialParam(Param, val, 0, 0, 0, applyToChildren)
        t = t + DeltaTime() * castingSpeedOverride
        Sleep(0)
    end
    
    if not IsNull(deco) then
        deco:SetMaterialParam(Param, NewValue, 0, 0, 0, applyToChildren)
        if destroyAtEnd then
            deco:Destroy()
        elseif hideAtEnd then
            deco:SetVisibility(false)
        end
    end
end

function MaterialFadeMeshScale(deco)
    if Delay >= 0 then
        Sleep(Delay)
    end
    if applyEnergyColor then
        EnergyColor(deco, energyColorParam, getParentFirst)
    end
    local t = 0
    local val
    while t < TimeLength do
        val = Lerp(OriginalValue, NewValue, t/TimeLength)
        deco:SetMaterialParam(Param, val)
        val = Lerp(OriginalScale, NewScale, t/TimeLength)
        deco:SetMeshScale(val)
        t = t + DeltaTime() 
        Sleep(0)
    end
    if destroyAtEnd and not IsNull(deco) then
        deco:Destroy()
    end
end

function MaterialFadePeak(deco)
    if Delay >= 0 then
        Sleep(Delay)
    end
    if applyEnergyColor then
        EnergyColor(deco, energyColorParam, getParentFirst)
    end
    if showAtStart then
        deco:SetVisibility(true)
    end
    local t = 0
    local fading
    local val
    while t < TimeLength do
        if t < Peak then
            fading = t/Peak
        else
            fading = 1 - (t-Peak)/(TimeLength-Peak)
        end
        if fading < 0 then
            fading = 0
        end
        val = Lerp(ValleyValue, PeakValue, fading)
        deco:SetMaterialParam(Param, val)
        t = t + DeltaTime() 
        Sleep(0)
    end
    if destroyAtEnd and not IsNull(deco) then
        deco:Destroy()
    elseif hideAtEnd then
        deco:SetVisibility(false)
    end
end

function MaterialFadeFlatPeak(deco)
    if Delay >= 0 then
        Sleep(Delay)
    end
    if applyToParent then
        local temp = deco:GetAttachParent()
        if not IsNull(temp) then
            deco = temp
        end
    end
    if applyEnergyColor then
        EnergyColor(deco, energyColorParam, getParentFirst)
    end
    local t = 0
    local fading
    local val
    local v = ValleyValue
    if checkInstigator == true then
        local instigatorAvatar = deco:GetCreator() 
        local suit 
        local level =1
        local inventoryControl
        if not IsNull(instigatorAvatar) then
            inventoryControl = instigatorAvatar:InventoryControl()
            suit = inventoryControl:GetActivePowerSuit()
            level = Clamp(suit:GetAbilityLevel(instigatorPower), 1, #instigatorDuration)
        end
        local endFadeLength = TimeLength - PeakEnd
        TimeLength = instigatorAvatar:InventoryControl():GetUpgradeModifiedValue(instigatorDuration[level], Game.AVATAR_ABILITY_DURATION, suit:GetType(), suit)
        PeakEnd = TimeLength - endFadeLength
    end
    
    while t < TimeLength do
        if t < Peak then
            fading = t/Peak
        else if t < PeakEnd then
                fading = 1
            else
                v = ValleyEndValue
                fading = 1 - (t-PeakEnd)/(TimeLength-PeakEnd)
            end
        end
        if fading < 0 then
            fading = 0
        end
        val = Lerp(v, PeakValue, fading)
        deco:SetMaterialParam(Param, val)
        t = t + DeltaTime() 
        Sleep(0)
    end
    if destroyAtEnd and not IsNull(deco) then
        deco:Destroy()
    end
end

function MaterialFadeTargetted()
    if Delay >= 0 then
        Sleep(Delay)
    end
    if showAtStart and not IsNull(TargetDeco) then
        for j = 1, #TargetDeco do
            local temp = TargetDeco[j]
            temp:SetVisibility(true)
        end
    end
    local t = 0
    local val
    while t < TimeLength do
        val = Lerp(OriginalValue, NewValue, t/TimeLength)
        if not IsNull(TargetDeco) then
            for j = 1, #TargetDeco do
                local temp = TargetDeco[j]
                temp:SetMaterialParam(Param, val)
                if applyToChildren then
                    local children = temp:GetAllAttachments(gDecorationType)
                    for i=1, #children do
                        local temp = children[i]
                        if not IsNull(temp) then
                            temp:SetMaterialParam(Param, val)
                        end
                    end
                end
            end
        end
        t = t + DeltaTime() 
        Sleep(0)
    end
    if destroyAtEnd and not IsNull(TargetDeco) then
        for j = 1, #TargetDeco do
            local temp = TargetDeco[j]
            temp:Destroy()
        end
    elseif hideAtEnd and not IsNull(TargetDeco) then
        for j = 1, #TargetDeco do
            local temp = TargetDeco[j]
            temp:SetVisibility(false)
        end
    end
end

function MaterialFadePeakTargetted()
    if Delay >= 0 then
        Sleep(Delay)
    end
    if showAtStart and not IsNull(TargetDeco) then
        for j = 1, #TargetDeco do
            local temp = TargetDeco[j]
            temp:SetVisibility(true)
        end
    end
    local t = 0
    local fading
    local val
    while t < TimeLength do
        if t < Peak then
            fading = t/Peak
        else
            fading = 1 - (t-Peak)/(TimeLength-Peak)
        end
        if fading < 0 then
            fading = 0
        end
        val = Lerp(ValleyValue, PeakValue, fading)
        if not IsNull(TargetDeco) then
            for j = 1, #TargetDeco do
                local temp = TargetDeco[j]
                temp:SetMaterialParam(Param, val)
            end
        end
        t = t + DeltaTime() 
        Sleep(0)
    end
    if destroyAtEnd and not IsNull(TargetDeco) then
        for j = 1, #TargetDeco do
            local temp = TargetDeco[j]
            temp:Destroy()
        end
    end
     if hideAtEnd and not IsNull(TargetDeco) then
        for j = 1, #TargetDeco do
            local temp = TargetDeco[j]
            temp:SetVisibility(false)
        end
    end   
end

function DissolveFadeTargetted()
    if Delay >= 0 then
        Sleep(Delay)
    end
    local t = 0
    local val
    while t < TimeLength do
        val = Lerp(OriginalValue, NewValue, t/TimeLength)
        if not IsNull(TargetDeco) then
            for j = 1, #TargetDeco do
                if not IsNull(TargetDeco[j]) then
                    TargetDeco[j]:SetDissolve(val)
                end
            end
        end
        t = t + DeltaTime() 
        Sleep(0)
    end
end

function DissolveFade(deco)
    if checkKilled then
        if deco:IsA(gRagdollType) then
            local avatar = deco:GetAvatarOwner()
            while not IsNull(deco) and not IsNull(avatar) and not avatar:IsKilled() do
                Sleep(0)
            end
            if IsNull(deco) then
                return
            end
        end
    end
    if Delay >= 0 then
        Sleep(Delay)
    end
    if applyEnergyColor then
        EnergyColor(deco, energyColorParam, getParentFirst)
    end
    local t = 0
    local val
    while t < TimeLength do
        val = Lerp(OriginalValue, NewValue, t/TimeLength)
        deco:SetDissolve(val)
        t = t + DeltaTime() 
        Sleep(0)
    end

    if not IsNull(deco) then
        deco:SetDissolve(NewValue)
    end
    if destroyAtEnd and not IsNull(deco) then
        deco:Destroy()
    end
end

function DissolveFadeMeshScale(deco)
    if isRandomMeshScale then
        deco:SetMeshScale(Random(OriginalScale, NewScale))
    end
    if Delay >= 0 then
        Sleep(Delay)
    end
    if applyEnergyColor then
        EnergyColor(deco, energyColorParam, getParentFirst)
    end
    local t = 0
    local val
    while t < TimeLength do
        val = Lerp(OriginalValue, NewValue, t/TimeLength)
        deco:SetDissolve(val)
        if not isRandomMeshScale then
            val = Lerp(OriginalScale, NewScale, t/TimeLength)
            deco:SetMeshScale(val)
        end
        t = t + DeltaTime() 
        Sleep(0)
    end
    if destroyAtEnd and not IsNull(deco) then
        deco:Destroy()
    end
end

function SetValueTargetted()
    if Delay >= 0 then
        Sleep(Delay)
    end
    for j = 1, #TargetDeco do
        local temp = TargetDeco[j]
        temp:SetMaterialParam(Param, NewValue)
    end
end

function SetDissolveTargetted()
    if Delay >= 0 then
        Sleep(Delay)
    end
    for j = 1, #TargetDeco do
        local temp = TargetDeco[j]
        temp:SetDissolve(NewValue)
    end
end

function DissolveFadeParent(deco)
    if Delay >= 0 then
        Sleep(Delay)
    end
    local t = 0
    local val
    local decoParent = deco:GetAttachParent()
    if not IsNull(decoParent) then
        while t < TimeLength do
            val = Lerp(OriginalValue, NewValue, t/TimeLength)
            if not IsNull(decoParent) then
                decoParent:SetDissolve(val)
            end
            t = t + DeltaTime() 
            Sleep(0)
        end
        if not IsNull(decoParent) then
            decoParent:SetDissolve(NewValue)
        end
    end
    if destroyAtEnd and not IsNull(decoParent) then
        decoParent:Destroy()
    end
end

function MaterialFadeTwoParams(deco)
    deco:SetMaterialParam(Param, OriginalValue)
    deco:SetMaterialParam(ParamTwo, OriginalValueTwo)
    if applyEnergyColor then
        EnergyColor(deco, energyColorParam, getParentFirst)
    end
    if Delay >= 0 then
        Sleep(Delay)
    end
    local castingSpeedOverride = 1
    if getCastingSpeed == true then --atm must be attached to the avatar
        local instigatorAvatar
        if gcsGetCreator then
            instigatorAvatar = deco:GetCreator() 
        else
            instigatorAvatar = deco:GetAttachRoot() 
        end
        if not IsNull(instigatorAvatar) then
            local inventoryControl = instigatorAvatar:InventoryControl()
            local suit = inventoryControl:GetActivePowerSuit()
            castingSpeedOverride = instigatorAvatar:InventoryControl():GetUpgradeModifiedValue(1, Game.AVATAR_CASTING_SPEED, suit:GetType(), suit)
        end
    end
    local t = 0
    local val
    local valTwo
    while t < TimeLength do
        local lerpVal = t/TimeLength
        if powScale then
            if invertPowScale then
                lerpVal = 1 - math.pow(1 - lerpVal, powerAmount)
            else
                lerpVal = math.pow(lerpVal, powerAmount)
            end
        end
        val = Lerp(OriginalValue, NewValue, lerpVal)
        valTwo = Lerp(OriginalValueTwo, NewValueTwo, lerpVal)
        deco:SetMaterialParam(Param, val)
        deco:SetMaterialParam(ParamTwo, valTwo)
        t = t + DeltaTime() * castingSpeedOverride
        Sleep(0)
    end
    if destroyAtEnd and not IsNull(deco) then
        deco:Destroy()
    end
end

function DissolveFadeFlatPeak(deco)
    if Delay >= 0 then
        Sleep(Delay)
    end
    local t = 0
    local fading
    local val
    local v = ValleyValue
    while t < TimeLength do
        if t < Peak then
            fading = t/Peak
        else if t < PeakEnd then
                fading = 1
            else
                v = ValleyEndValue
                fading = 1 - (t-PeakEnd)/(TimeLength-PeakEnd)
            end
        end
        if fading < 0 then
            fading = 0
        end
        val = Lerp(v, PeakValue, fading)
        deco:SetDissolve(val)
        t = t + DeltaTime() 
        Sleep(0)
    end
    if destroyAtEnd and not IsNull(deco) then
        deco:Destroy()
    end
end

function DissolveFadeFlatPeakMeshScale(deco)
    if Delay >= 0 then
        Sleep(Delay)
    end
    local t = 0
    local fading
    local val
    local v = ValleyValue
    local vScale = meshScaleValley
    while t < TimeLength do
        if t < Peak then
            fading = t/Peak
        else if t < PeakEnd then
                fading = 1
            else
                v = ValleyEndValue
                fading = 1 - (t-PeakEnd)/(TimeLength-PeakEnd)
            end
        end
        if fading < 0 then
            fading = 0
        end
        val = Lerp(v, PeakValue, fading)
        deco:SetDissolve(val)
        val = Lerp(vScale, meshScalePeak, fading)
        deco:SetMeshScale(val)
        t = t + DeltaTime() 
        Sleep(0)
    end
    if destroyAtEnd and not IsNull(deco) then
        deco:Destroy()
    end
end

function DissolveFadeFlatPeakRandomMeshScale(deco)
    if Delay >= 0 then
        Sleep(Delay)
    end
    local t = 0
    local fading
    local val
    local v = ValleyValue
    if applyEnergyColor then
        EnergyColor(deco, energyColorParam, getParentFirst)
    end
    deco:SetMeshScale(Random(meshScaleValley, meshScalePeak))
    while t < TimeLength do
        if t < Peak then
            fading = t/Peak
        else if t < PeakEnd then
                fading = 1
            else
                v = ValleyEndValue
                fading = 1 - (t-PeakEnd)/(TimeLength-PeakEnd)
            end
        end
        if fading < 0 then
            fading = 0
        end
        val = Lerp(v, PeakValue, fading)
        deco:SetDissolve(val)        
        t = t + DeltaTime() 
        Sleep(0)
    end
    if destroyAtEnd and not IsNull(deco) then
        deco:Destroy()
    end
end

function MaterialFadeWithAttractorParent(deco)
    if Delay >= 0 then
        Sleep(Delay)
    end
    if IsNull(deco) then
        return
    end 
    if applyEnergyColor then
        EnergyColor(deco, energyColorParam, getParentFirst)
    end
    local attractor = deco:GetAttachParent()
    if not IsNull(attractor) then
        Sleep(attractor:GetLifeSpan() - Delay - 1)
    end
    local t = 0
    local val
    while t < TimeLength do
        if IsNull(deco) then
            return
        end
        val = Lerp(OriginalValue, NewValue, t/TimeLength)        
        deco:SetMaterialParam(Param, val)
        t = t + DeltaTime() 
        Sleep(0)
    end
end

function MaterialCurveFadePeakTargetted()
    if Delay >= 0 then
        Sleep(Delay)
    end
    if showAtStart and not IsNull(TargetDeco) then
        for j = 1, #TargetDeco do
            local temp = TargetDeco[j]
            temp:SetVisibility(true)
        end
    end
    local t = 0
    local fading
    local val
    while t < TimeLength do
        if t < Peak then
            fading = t/Peak
        else
            fading = 1 - (t-Peak)/(TimeLength-Peak)
        end
        if fading < 0 then
            fading = 0
        end
        val = Lerp(ValleyValue, PeakValue, fading)
        if not IsNull(TargetDeco) then
            for j = 1, #TargetDeco do
                local temp = TargetDeco[j]
                temp:SetMaterialParam(Param, val)
            end
        end
        t = t + DeltaTime() 
        Sleep(0)
    end
    if destroyAtEnd and not IsNull(TargetDeco) then
        for j = 1, #TargetDeco do
            local temp = TargetDeco[j]
            temp:Destroy()
        end
    end
     if hideAtEnd and not IsNull(TargetDeco) then
        for j = 1, #TargetDeco do
            local temp = TargetDeco[j]
            temp:SetVisibility(false)
        end
    end   
end
