positionalNoise = Vector()
positionalSpeed = 0
rotationalNoise = Vector()
rotationalSpeed = 0
decayTime = 1
radius = 1
exitAfterDecay = false
target = Instance()

local function LocalSway(mesh)
    local decaying = false
    local avatarWasNear = false
    Engine.EnableZoneCull(mesh)
    local pos = mesh:GetPosition()
    while not IsNull(mesh) do
        local avatar = gRegion:FindNearest(gLotusAvatarType, pos, radius)
        if not IsNull(avatar) then  
            avatarWasNear = true
            if avatar:GetVelocity() == ZERO_VECTOR then
                if not decaying then
                    mesh:SetNoiseEnable(false)
                    mesh:NoiseBoost(positionalNoise, positionalSpeed, rotationalNoise, rotationalSpeed, 0, decayTime)
                    decaying = true
                else
                    Sleep(0)
                end
            else
                if decaying then
                    mesh:NoiseBoost(Vector(), 0, Vector(), 0, 0, 0.1)
                    decaying = false
                end
                mesh:SetNoiseEnable(true)
            end
        else
            mesh:SetNoiseEnable(false)
            if avatarWasNear then
                mesh:NoiseBoost(positionalNoise, positionalSpeed, rotationalNoise, rotationalSpeed, 0, decayTime)
                avatarWasNear = false
            end
        end
        
        if exitAfterDecay then
            break
        end
        
        Sleep(0)
    end
end

function Sway(mesh)
    if IsNull(mesh) then
        return
    end
    local gameRules = gGameRules
    if not IsNull(gameRules) and not gameRules:IsA(gLotusHubGameRulesType) then
        LocalSway(mesh)
    end
end

function TargetedSway()

    if IsNull(target) or gGameRules:IsA(gLotusHubGameRulesType) then
        return
    end
    
    LocalSway(target)

end
