moundEffect = Resource()
toxicScatDecoType = Type()
burrowSeqType = WeakResource("/Lotus/Sounds/Characters/HuntingCritters/Predator/Burrow/PredatorBurrowSnowLoopSeq")

moundSpacing = 1
moundOffset = Vector(0.0, -0.2, 0.0)
delay = 1

poopChance = 7

transTag = Symbol("transMound")
moundOutAnim = Resource()
Debug = false

local lastPos
local mounds = {}

local function createMoundAndToxicScat(pos)
    local ignoreEntity = nil
    local ignoreTypes = nil --{gBaseAvatarType, gPickUpType, gRagdollType, gHitProxyType}
    local raycastStartPosition = pos + Vector(0.0, 2.0, 0.0)
    local raycastEndPosition = pos - Vector(0.0, 2.0, 0.0)
    
    local hitEntity = nil
    local hitPoint = Vector()
    local hitAngle = Rotation()
    local foundPlaceablePosition = gRegion:RaycastWithHitAngle(raycastStartPosition, raycastEndPosition, ignoreEntity, ignoreTypes, hitEntity, hitPoint, hitAngle, true)
    
    if foundPlaceablePosition then
        if Debug then print("Hit: ", hitAngle) end
        
--        Rotation(heading, pitch, bank)
        local randMoundRot = Rotation(math.random(0,3600)/10, hitAngle.pitch, hitAngle.bank)
        local mound = gRegion:CreateEntity(moundEffect, hitPoint + moundOffset, randMoundRot)
        
        local doPoop = math.random(0,10)
        if doPoop >= poopChance and not IsNull(toxicScatDecoType) then
            local randPoopRot = Rotation(hitAngle.heading, hitAngle.pitch, math.random(0,3600)/10)
            local toxicScat = gRegion:CreateEntity(toxicScatDecoType, hitPoint, randPoopRot)
        end
        lastPos = pos
        table.insert(mounds, mound)
    
    end
end

function OrientToGround(entity)
    if not IsNull(entity) then
        local pos = entity:GetPosition()
        local ignoreEntity = nil
        local ignoreTypes = {gBaseAvatarType, gPickUpType, gRagdollType, gHitProxyType}
        local raycastStartPosition = pos + Vector(0.0, 2.0, 0.0)
        local raycastEndPosition = pos - Vector(0.0, 2.0, 0.0)
        
        local hitEntity = nil
        local hitPoint = Vector()
        local hitAngle = Rotation()
        local foundPlaceablePosition = gRegion:RaycastWithHitAngle(raycastStartPosition, raycastEndPosition, ignoreEntity, ignoreTypes, hitEntity, hitPoint, hitAngle, true)
       
        if foundPlaceablePosition then
            if Debug then print("Hit: ", hitAngle) end

    --        Rotation(heading, pitch, bank)
            local randMoundRot = Rotation(math.random(0,3600)/10, hitAngle.pitch, hitAngle.bank)
            entity:SetRotation(randMoundRot)
        end
    end
    
end

function SpawnMoundDigging(entity, animEventParam)
    if not IsNull(entity) then
        local burrowSeq = entity:GetAttachment(burrowSeqType)
        if not IsNull(burrowSeq) and burrowSeq:IsEnabled() == false then
               burrowSeq:Enable()
        end
    end
    
    while not IsNull(entity) do
        local pos = entity:GetPosition()
        local dist
               
        if not IsNull(lastPos) then
            dist = Distance(pos, lastPos)
            if dist >= moundSpacing then
                createMoundAndToxicScat(pos)                      
            end
           
        else
            createMoundAndToxicScat(pos)     
        end
            
        Sleep(delay)
    end
end

function PlayAnimationOnSubmerge(entity, animEventParam)
    while not IsNull(entity) do
        local found = gRegion:FindTaggedInRadius(transTag, entity:GetPosition(), 0, 8)
          
        if found then
            entity:PlayAnimation(moundOutAnim, false)           
            break
        end
        Sleep(0)
    end
end

function StopTunnelingSeq(entity, animEventParam)
    if not IsNull(entity) then
        local burrowSeq = entity:GetAttachment(burrowSeqType)
        if not IsNull(burrowSeq) and burrowSeq:IsEnabled() == true then
            burrowSeq:Disable()
        end
    end
end
