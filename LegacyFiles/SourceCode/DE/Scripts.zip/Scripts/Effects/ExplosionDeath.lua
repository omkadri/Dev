pFX = {Type()}
decoFx = {Type()}
timeLength = 1.25
effectsToRemove = {Type()}
cloakScale = 50
radialCloak = false
isCinematic = false
cinematicColor = Color(246, 104, 0, 255)   

local CLOAKHDR = Symbol("CloakHDR")
local CLOAKVECTOR = Symbol("CloakVector")
    
local COLOR_UTIL = require "Lotus.Scripts.Effects.EffectsColorUtilities"
local ragdollType = Type("/EE/Types/Physics/Ragdoll")
local effectTag = Symbol("EffectsDeco")

local function AllAttachments(avatar)
    local attachments = avatar:GetAllAttachments(gDecorationType)
    local finalItems = {}
    for i, temp in ipairs(attachments) do
        local material = temp:GetMaterialInSlot(0)
        local atten = material:GetParam(Lotus_Game.UNLIT_ATTEN, 0)
        if (atten > 100) and not (temp:GetTag() == effectTag) then -- If these are true, it's an effect, so don't attach
            table.insert(finalItems, temp)
        end
    end
    table.insert(finalItems, avatar)
    return finalItems
end

local function DissolvePosLoop(boneName, parent) --Update material with bone's local position
    local vec = parent:GetBonePosition(boneName)
    parent:SetMaterialParam(CLOAKVECTOR, vec.x, vec.y, vec.z, 2.5)
end

function DissolveTheEnemy(spawner)
    Sleep(0)
    if IsNull(spawner) then
        return
    end
    local avatar = spawner:GetAttachRoot()
    local entity = avatar
    if IsNull(entity) then
        return
    end
    local energyColor = Color(246, 104, 0, 255) 
    local attachBone = Symbol("GAME_C1_HIP1")   

    if isCinematic then
        energyColor = cinematicColor
        avatar = nil
    else
        --Find the source, do we care?
        if entity:IsA(ragdollType) then
            avatar = entity:GetAvatarOwner()
            if not IsNull(avatar) and avatar:GetNumRagdolls() > 1 then
                local spawnerType = spawner:GetTypeRes()
                for i = 0, avatar:GetNumRagdolls() - 1 do
                    local ragdoll = avatar:GetRagdollByIndex(i)
                    local thisEffect = ragdoll:GetAttachment(spawnerType)
                    if IsNull(thisEffect) then
                        --ragdoll:Attach(spawnerType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, spawner:GetCreator())
                    end
                end
            end
        elseif not entity:IsA(gBaseAvatarType) then
            return
        end
        
        
        if not IsNull(avatar) then
            local damageControl = avatar:DamageControl()
            if not IsNull(damageControl) then
                local deathInjury = damageControl:GetDeathInjury()
                if not IsNull(deathInjury) then
                    local deathInjuryWeapon = deathInjury:GetSourceObject()
                
                    if not IsNull(deathInjuryWeapon) and deathInjuryWeapon:IsA(gLotusWeaponType) then
                        local playerCustomization = deathInjuryWeapon:GetCustomization()
                        
                        local colorPalette = Lotus_Game.PrimaryColors
                        
                        if deathInjuryWeapon:IsA(gPowerSuitType) and deathInjuryWeapon:IsOperatorSuit() then
                            colorPalette = Lotus_Game.Attachments
                        end
                        
                        local colors = playerCustomization:GetColors(colorPalette)
                        if colors:Initialized(Lotus_Game.EnergyColor) then
                            energyColor = Color(colors.mEnergyColor)
                        end
                    end
                    attachBone = damageControl:GetProxyBoneForPart(Engine.TORSO)
                end
            end
        end
    end
    
    
    local hiColor = COLOR_UTIL.EnergyHighColor(energyColor)
    local loColor = COLOR_UTIL.EnergyLowColor(energyColor)

    for i=1, #pFX do
        local effect = entity:Attach(pFX[i], attachBone)
        if not IsNull(effect) then
            if effect:IsA(gParticleSysType) then
                effect:SetColorMinMax(energyColor, energyColor)
            end
            COLOR_UTIL.ApplyEnergyTints(effect, energyColor, hiColor, loColor)
        end
    end
    
    if not IsNull(avatar) then
        for i=1, #decoFx do
            local effect = gRegion:CreateEntity(decoFx[i], avatar:GetBonePosition(attachBone), ZERO_ROTATION)
            if not IsNull(effect) then
                COLOR_UTIL.ApplyEnergyTints(effect, energyColor, hiColor, loColor)
            end
        end
    end
    
    local killed = false
    local haveRagdoll = false
    local ragdolls = {}
    entity:SetMaterialParam(CLOAKHDR, energyColor.red / cloakScale, energyColor.green / cloakScale, energyColor.blue / cloakScale, 1)
    local t = 0
    local vec = Vector()
    --Todo.  Can we find the direction and apply impulse?
    while t < timeLength do
        if not IsNull(avatar) then
            if (avatar:GetHealth() <= 0 and not killed) then
                killed = true
            end
        end
        if killed and not haveRagdoll and not IsNull(avatar) then
            for i = 0, avatar:GetNumRagdolls() - 1 do
                local ragdoll = avatar:GetRagdollByIndex(i)
                if not IsNull(ragdoll) then
                    haveRagdoll = true
                    entity = nil
                    ragdoll:SetMaterialParam(CLOAKHDR, energyColor.red / cloakScale, energyColor.green / cloakScale, energyColor.blue / cloakScale, 1)
                    for j=1, #effectsToRemove do
                        local fx = ragdoll:GetAttachment(effectsToRemove[j])
                        if not IsNull(fx) then
                            fx:Destroy()
                        end
                    end
                    table.insert(ragdolls, ragdoll)
                end
            end
        end
        if not IsNull(entity) then
            entity:SetDissolve(t / timeLength)
            if radialCloak then
                vec = entity:GetCenter()
                entity:SetMaterialParam(CLOAKVECTOR, vec.x, vec.y, vec.z, 2.5)
            end
        end
        for i, temp in ipairs(ragdolls) do
            if not IsNull(temp) then
                temp:SetDissolve(t / timeLength)
                if radialCloak then
                    vec = temp:GetCenter()
                    temp:SetMaterialParam(CLOAKVECTOR, vec.x, vec.y, vec.z, 2.5)
                end
            end
        end
        t = t + DeltaTime()
        Sleep(0)
    end
    Sleep(2)
    if haveRagdoll then
        for i, temp in ipairs(ragdolls) do
            if not IsNull(temp) then
                temp:UnRegisterProxies()
                temp:ClearDeathEffect()
            end
        end
    end
end
