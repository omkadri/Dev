Debug = false
VelThreshold = 0.6

function fadeByVel(pSys)
    local parent = pSys:GetCreator()
    
    while true do
        if not IsNull(parent) then
            local dt = DeltaTime()
            local mag = parent:GetSpeed()
            local t = 0
            
            if Debug then
                print("Mag:"..mag )
            end
            
            if mag > VelThreshold then
                pSys:SetSpewCount(30,30,false)
            else
                pSys:SetSpewCount(2,2,false)
            end
        end
        Sleep(0)
    end
end