respawnProjector = Type()
nekrosRespawnFx = Type()

local fxSpawner = nil
function CreateWaitDestroy(avatar)
    local attachedFx = nil
    local gameRules = gGameRules
    if
        not IsNull(gameRules) and
        gameRules:IsA(gLotusPvpGameRulesType) and
        gameRules:GetPreRespawnTimer(avatar:GetPlayer()) > gameRules:GetPreRespawnTimer()
    then
        attachedFx = avatar:Attach(nekrosRespawnFx, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, avatar)
    else
        attachedFx = avatar:Attach(respawnProjector, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, avatar)
    end
    
    while not IsNull(avatar) and not avatar:IsKilled() and not IsNull(fxSpawner) do
        Sleep(0)
    end
    
    if not IsNull(attachedFx) then
        attachedFx:Destroy()
    end
end

function OnRespawn(spawner)
    local avatar = nil
    while not IsNull(spawner) do
        avatar = spawner:GetAttachRoot()
        if avatar ~= spawner then
            break
        end
        Sleep(0)
    end
    
    if IsNull(avatar) or IsNull(avatar:GetPlayer()) then
        return
    end
    
    fxSpawner = spawner
    avatar:ScriptRunChildScript(Symbol("CreateWaitDestroy"), false)
end