effectType = Type()
kidSpawnEffectType = Type()

local sUnlitAtten = Symbol("UnlitAtten")
local sTintColor = Symbol("TintColor")
local mixingColor = Vector(0.1, -0.8, -0.7) --Add to tintcolor whichis white
local atten = 0.57
local completedAtten = 0.40

function ReliquaryActivate(cinematic)
    local drive = gRegion:FindFirstTagged(Symbol("ReliquaryCinematicDrive"))
    local veil = gRegion:FindFirstTagged(Symbol("ReliquaryVeil"))
    if IsNull(veil) or IsNull(drive) then
        return
    end
    
    --stuff at the start
    local attachEffect = veil:Attach(effectType, EMPTY_SYMBOL)
    
    local t = 0

    while t < 1 and not IsNull(veil) and not IsNull(drive) do
        local blend = SmoothStep(t)
        veil:SetMaterialParam(sTintColor, 1 + blend * mixingColor.x, 1 + blend * mixingColor.y, 1 + blend * mixingColor.z, 1)
        Sleep(0)
        t = t + DeltaTime() / 43 --seconds
    end

    if not IsNull(attachEffect) then
        attachEffect:Destroy()
    end
end

function ReliquaryClear(cinematic)
    local drive = gRegion:FindFirstTagged(Symbol("ReliquaryCinematicDrive"))
    local veil = gRegion:FindFirstTagged(Symbol("ReliquaryVeil"))
    if IsNull(veil) or IsNull(drive) then
        return
    end

    local t = 1
    local clearSmokeScale = 0.45

    while t > 0 and not IsNull(veil) and not IsNull(drive) do
        local blend = SmoothStep(t)
        veil:SetMaterialParam(sUnlitAtten, clearSmokeScale + (atten - clearSmokeScale) * blend)
        Sleep(0)
        t = t - DeltaTime() / 0.5 --seconds
    end
    
    Sleep(1)
    --Will it blend? Yes, it did, go back to normal
    while t < 1 and not IsNull(veil) and not IsNull(drive) do
        local blend = SmoothStep(t)
        veil:SetMaterialParam(sUnlitAtten, clearSmokeScale + (completedAtten - clearSmokeScale) * blend)
        local blendMix = 1 - blend
        veil:SetMaterialParam(sTintColor, 1 + blendMix * mixingColor.x, 1 + blendMix * mixingColor.y, 1 + blendMix * mixingColor.z, 1)
        Sleep(0)
        t = t + DeltaTime() / 8 --seconds
    end
end

function CreateSpawnerIfKid()
    local kid = gRegion:FindFirstTagged(Symbol("EvilTwin"))
    if not IsNull(kid) then
        kid:Attach(kidSpawnEffectType, EMPTY_SYMBOL)
    end    
end

function UnequipWeapons()
    local playerAv = gRegion:GetLocalPlayerAvatar()
    local inv = playerAv:InventoryControl()
    inv:Unequip(Engine.MAIN_HAND, Engine.InventoryControllerBase_ES_INSTANT_EQUIP)
    inv:SetWeaponsEnabled(false)
    
    local powerSuit = inv:GetActivePowerSuit()
    powerSuit:SetAbilityIdentifiersBlocked(true)
    
    local cin = nil
    while IsNull(cin) do
        Sleep(0)
        cin = gRegion:GetPlayingCinematic()
    end
    
    while cin:IsPlaying() do
        Sleep(0)
    end
    
    powerSuit:DeactivateAbilitiesSendRMI()
    inv:SetWeaponsEnabled(true)
    
    if not IsNull(inv:GetWeaponInSlot(Engine.SLOT_2)) then
        inv:Equip(Engine.SLOT_2, Engine.MAIN_HAND, Engine.InventoryControllerBase_ES_PLAY_EQUIP_ANIM)
    elseif not IsNull(inv:GetWeaponInSlot(Engine.SLOT_1)) then
        inv:Equip(Engine.SLOT_1, Engine.MAIN_HAND, Engine.InventoryControllerBase_ES_PLAY_EQUIP_ANIM)
    else
        inv:Equip(Engine.SLOT_6, Engine.MAIN_HAND, Engine.InventoryControllerBase_ES_PLAY_EQUIP_ANIM)
    end
    
    powerSuit:SetAbilityIdentifiersBlocked(false)
end