spawnerType = Type()

function HoodNUpdate(deco)
    Sleep(0)
    local avatar = deco:GetAttachRoot()
    if IsNull(avatar) or not avatar:IsA(gLotusAvatarType) or gGameRules:IsA(gLotusHubGameRulesType) then
        return
    end
    local suit = avatar:InventoryControl():GetActivePowerSuit()
    
    local spawner = nil
    local hasEffect = deco:HasAttachment(spawnerType)
    while not IsNull(deco) and not IsNull(avatar) do
        local needFx = avatar:IsVisible() and (avatar:HasPostureModifier(Engine.PM_DODGE) or avatar:IsFalling())
        if needFx and not hasEffect then
            spawner = deco:Attach(spawnerType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, suit)
            hasEffect = true
        elseif not needFx and hasEffect then
            if not IsNull(spawner) then
                spawner:Destroy()
            end
            hasEffect = false
        end
        Sleep(0)
    end
end