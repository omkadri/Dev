doCustomDayTint = false
nightOverride = false
dayTint = Color(255, 255, 0, 255)
nightTint = Color(0, 0, 255, 255)

function dayNightTint(Deco)
    Sleep(0)

    local gameRules = gGameRules
    while IsNull(gameRules) do 
        gameRules = gGameRules 
        Sleep(0)
    end
    
    local NV_DAY_NIGHT = Symbol("DayNight") 
    local dayNight = gameRules:GetNetPersistentVar(NV_DAY_NIGHT, 9999) 
    
    while dayNight == 9999 do -- poll until var arrives 
        Sleep(0) 
        dayNight = gameRules:GetNetPersistentVar(NV_DAY_NIGHT, 9999) 
    end
    
    -- print("Day 1 & Night 0. It's now", dayNight,"\n")
    if dayNight ~= 0 then -- if not night
        if doCustomDayTint == true then
            Deco:SetMaterialParam(Lotus_Game.TINT_COLOR, dayTint.red/255, dayTint.green/255, dayTint.blue/255, dayTint.alpha/255)
        end
    elseif dayNight == 0 then -- if night (0)
        Deco:SetMaterialParam(Lotus_Game.TINT_COLOR, nightTint.red/255, nightTint.green/255, nightTint.blue/255, dayTint.alpha/255)
    elseif nightOverride == true then
        Deco:SetMaterialParam(Lotus_Game.TINT_COLOR, nightTint.red/255, nightTint.green/255, nightTint.blue/255, dayTint.alpha/255)
    end
end