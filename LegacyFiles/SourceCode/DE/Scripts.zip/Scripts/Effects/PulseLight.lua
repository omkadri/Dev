delay = 0
lightDeco = Instance()
lightInstance = Instance()
transitionTime = 1

flickerBrightness = 0.2
flickerBrightnessMultiplier = 20
maxBrightness = 1

flickerEmissiveness = 0.2
maxEmissiveness = 1


local function localFlickerLight(light, deco, loop)

    while true do
        local t = 0
        while t < 1 do

            local b = Abs(Noise(t))
            local v = flickerBrightness + math.pow(0.1, b)
            light:SetBrightness(v * flickerBrightnessMultiplier)
            if not IsNull(deco) then
                deco:SetMaterialParam("EmissiveMapAtten", v)
            end
            
            -- sleep til next frame
            t = t + DeltaTime() / transitionTime
            Sleep(0.0)
        end
        
        if loop == false then
            break
        end
        
    end

end

local function localPulseLight(light, deco, loop)

    Sleep(0)
    
    if IsNull(light) then
        return
    end
    
    while true do
        local t = 0
        while t < 1 do

            local v = t
            light:SetBrightness(v * flickerBrightnessMultiplier)
            if not IsNull(deco) then
                deco:SetMaterialParam(Lotus_Game.EMISSIVE_MAP_ATTEN, v * flickerBrightnessMultiplier * 0)
            end
            
            -- sleep til next frame
            t = t + DeltaTime() / transitionTime
            Sleep(0.0)
        end
        
        if loop == false then
            break
        end
        
    end

end


function PulseLoop(light)
    
    Sleep(delay)
    localPulseLight(light, lightDeco, true)

end

function PulseLoopOnDeco(deco)
    Sleep(delay)
    localPulseLight(lightInstance, deco, true)
end
