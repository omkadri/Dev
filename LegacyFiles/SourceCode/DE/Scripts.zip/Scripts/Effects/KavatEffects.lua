
function ApplyEyeColor(suit)
    Sleep(0.5)
    if IsNull(suit) then
        return
    end
    local customization = suit:GetCustomization()
    if IsNull(customization) then
        return
    end
    local colors = customization:GetColors(Lotus_Game.PrimaryColors)

    --Apply energy color to emissives as that is where eye color has been stored.
    if colors:Initialized(Lotus_Game.EnergyColor) and not colors:Initialized(Lotus_Game.EmissiveColor0) then
        local newColor = Color(colors.mEnergyColor)
        newColor.alpha = 255

        colors:SetColor(Lotus_Game.EmissiveColor0, newColor)
        colors:SetInitialized(Lotus_Game.EmissiveColor0, true)
        customization:SetColors(Lotus_Game.PrimaryColors, colors)
        
        local avatar = suit:GetAvatarOwner()
        if not IsNull(avatar) then
            customization:ApplyCustomization(avatar)
        end
    end
end
