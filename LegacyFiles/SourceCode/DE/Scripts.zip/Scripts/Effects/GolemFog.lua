DistanceFogDensity = 1
FogColor = Color(255,0,0,255)
SearchMaxDistance = 30
TimeLength = 1
DebugMsgs = false
fogEnabled = true

function printStuff(trigger, instigatorAvatar)
    while not IsNull(instigatorAvatar) do
        print("I see you")
        Sleep(0.3)
    end
end

function ChangeFog(trigger, instigatorAvatar)
    local hasEntered = false
    local avatar = instigatorAvatar
    
    Sleep(0)
    if IsNull(avatar) or not avatar:IsA(gLotusAvatarType) or not avatar:ReplicaLocallyControlled() then
        return
    end
    
    local pos = avatar:GetPosition()
    local zoneAttribs = gRegion:FindAll(gZoneAttribsType)
    local zones = {}
    local bgSym = Symbol("Backdrop")
    local flyInSym = Symbol("FlyIn")
    
    --Get Zones
    for i = 1, #zoneAttribs do
        if not IsNull(zoneAttribs[i]) then
            if zoneAttribs[i]:GetTag() ~= bgSym and zoneAttribs[i]:GetZoneId() ~= flyInSym then
                table.insert(zones, zoneAttribs[i]:GetZone())
            end
        end
    end
    
    if DebugMsgs == true then
        print("ChangeFog Started")
    end
    
    if not IsNull(zones) then
        if DebugMsgs == true then
            print("Found some zones")
        end
        if not IsNull(avatar) then
            if DebugMsgs == true then
                print("Found a local player")
            end
        end
        
        local t = 0
        while t < 1 do
            if not trigger:IsTouching(avatar) then
                for i = 1, #zones do
                    local temp =  zones[i]:GetZone()
                    if DebugMsgs == true then
                        print("changing now")
                    end
                    temp:SetDistanceFogDensity(DistanceFogDensity)
                    temp:SetFogColor(FogColor)
                end
            end
        end
    end
end
    --[[
    while trigger:IsTouching(avatar) and not IsNull(avatar) do
        if not hasEntered then
            hasEntered = true
            if fogEnabled then
            
            end
        end
    end
    
    
    Sleep(0)
    local pos = entity:GetPosition()
    local zoneAttribs = gRegion:FindAll(gZoneAttribsType)
    local zones = {}
    
    local bgSym = Symbol("Backdrop")
    local flyInSym = Symbol("FlyIn")
    
        --Get Zones
    for i = 1, #zoneAttribs do
        if not IsNull(zoneAttribs[i]) then
            if zoneAttribs[i]:GetTag() ~= bgSym and zoneAttribs[i]:GetZoneId() ~= flyInSym then
                table.insert(zones, zoneAttribs[i]:GetZone())
            end
        end
    end
    
    if DebugMsgs == true then
        print("ChangeFog Started")
    end
    
    if not IsNull(zones) then
        if DebugMsgs == true then
            print("Found some zones")
        end
        local localPlayers = gRegion:GetLocalPlayerAvatars()
        if not IsNull(localPlayers) then
            if DebugMsgs == true then
                print("Found a local player")
            end
            for i = 1, #zones do
                local temp =  zones[i]:GetZone()
                if DebugMsgs == true then
                    print("changing now")
                end
                --local t = 0
                --while t < TimeLength do
                    --local lerpVal = Lerp(0,1,t/TimeLength)
                    temp:SetDistanceFogDensity(DistanceFogDensity)
                    temp:SetHeightFogDensity(HeightFogDensity)
                    temp:SetFogColor(FogColor)
                    t = t + DeltaTime()
                    --Sleep(0)
                end
            end
            
        else
             for i = 1, #zones do
                local temp =  zones[i]:GetZone()
                if DebugMsgs == true then
                    print("changing now")
                end
                -- while t < TimeLength do
                    -- local lerpVal = Lerp(0,1,t/TimeLength)
                    temp:SetDistanceFogDensity(DistanceFogDensity)
                    temp:SetHeightFogDensity(HeightFogDensity)
                    temp:SetFogColor(FogColor)
                -- end
            end               
        end
    end
end
    ]]
