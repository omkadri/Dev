timeLength = 2.0
originalAtten = 1.0
peakRatio = 0.75

local WORLDPOINT = Symbol("worldPoint")
local UNLIT_ATTEN = Lotus_Game.UNLIT_ATTEN

function BuildUpWorldPosMat(deco)
    --Sleep(0)
    local lotusAvatar = deco
    while true do
        local parent = lotusAvatar:GetAttachParent()
        if IsNull(parent) or parent == lotusAvatar then
            break
        end
        lotusAvatar = parent
    end

    local t = 0
    local val = 0
    local peak = (peakRatio) * timeLength
    local pPos = Vector()
    while t < timeLength do
        pPos = deco:GetPosition()
        if t < peak then
            val = t/(peak)
        else
            val = 1 - (t-peak)/(timeLength-peak)
        end
        val = originalAtten * val
        deco:SetMaterialParam(WORLDPOINT, pPos.x, pPos.y, pPos.z)
        deco:SetMaterialParam(UNLIT_ATTEN, val * 2)
        
        t = t + DeltaTime()
        Sleep(0)
    end
end
