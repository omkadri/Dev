-- local EASING = require "Lotus.Scripts.Libs.EasingLib"

--materialParam = Lotus_Game.EMISSIVE_MAP_ATTEN
startValue = 0
endValue = 1.5

-- Coolant defense
coolantGlowMat = Resource()
coolantGlowMatSlot = 2
coreMeshes = {Instance()}
coreMatSlots = {1}
pipeAvatarType = Type()
corePipeMeshIntact = Resource()
corePipeMeshDestroyed = Resource()
corePipeDestroyedMatSwaps = {Resource()}
corePipeDestroyedMatSwapIds = {2}

-- Core mat swap updates
coreMaterialFuel = Resource()
coreMaterialCoolant = Resource()
coreMaterialOff = Resource()

-- ChildDissolve variables
attachmentType = Type()
frostedMeshes = {Instance()}

-- Ice Pop
eventSpawners = {Instance()}
eventDecos = {Instance()}
eventTimePercent = {33,50,75,82,100}

deathSpawner = Resource()

-- Lights
coreLightsTag = Symbol("SabotageCoreLight")
coreCoolantLightColor = Color(122,177,255,207) --122,207,204 for Corpus
--coreFuelLightColor = Color()

-- Anims
coreMesh = Instance()
startAnim = Resource()
loopingAnim = Resource()


local NV_MODULAR_OBJ_TIMER = Symbol("ModularObjectiveTime")
local NV_CORE_RESULT = Symbol("SabotageCoreResult") -- 1 = Explosive (plug in fuel cell), 2 = Cool (plug in coolant), 3 = Silent (plug fuel into coolant slot), 4 = Silent, console stage completed

local function round(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end

function IceDefenseMaterials()
    local gameRules = gGameRules
    local defendPercent = gameRules:GetNetPersistentVar(NV_MODULAR_OBJ_TIMER)
    local coolantLights = gRegion:FindTagged(Symbol("SabotageCoreCoolantLight"))
    
    if gRegion:IsMaster() then
        print("Pipe material update started: Host")
    else
        print("Pipe material update started: Client")
    end
    
    -- Turn on coolant pipe lights
    for i, light in ipairs(coolantLights) do
        light:FirePort("TurnOn")
    end
    
    -- Set up avatar and core materials
    local activeAvatars = gRegion:FindAll(pipeAvatarType)
    for i, avatar in ipairs(activeAvatars) do
        avatar:SetOverrideMaterial(coolantGlowMatSlot, coolantGlowMat)
        avatar:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, startValue)
    end

    local itemA
    local itemB
    if not IsNull(frostedMeshes) and #frostedMeshes > 0 then
        itemA = frostedMeshes[1]:GetAllAttachments(attachmentType)
        itemB = frostedMeshes[2]:GetAllAttachments(attachmentType)
    end
    
    while defendPercent < 100 do -- Loop and update materials while defense in progress
    
        defendPercent = gameRules:GetNetPersistentVar(NV_MODULAR_OBJ_TIMER)
    
        -- Update avatars
        local v = Lerp(startValue, endValue, defendPercent/100)
        
        for i = #activeAvatars, 1, -1 do
            if IsNull(activeAvatars[i]) or activeAvatars[i]:GetHealth() <= 0 then
                table.remove(activeAvatars, i)
            else
                activeAvatars[i]:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, v)
                -- Update glass here if health is low or use the avatar script?
            end
        end
        
        -- Frost
        if not IsNull(itemA) and not IsNull(itemB) then
            local val = 0
            val = Lerp(1, 0, defendPercent/100)
            itemA[1]:SetDissolve(val)
            itemB[1]:SetDissolve(val)
        end
        
        -- Icicles
        if not IsNull(eventTimePercent) then            
            for i = 1, #eventTimePercent do
                if defendPercent == eventTimePercent[i] then
                    if not IsNull(eventSpawners[i]) then
                        eventSpawners[i]:FirePort("Enable") 
                    end
                    if not IsNull(eventDecos[i]) then
                        eventDecos[i]:FirePort("Show") 
                    end
                    break
                end
            end
        end
        
        Sleep(0.05)
    end

end

function UpdateReactorMaterials()
    Sleep(1) -- Needs to be here to wait for net var update
    local gameRules = gGameRules
    local coreStatus = gameRules:GetNetPersistentVar(NV_CORE_RESULT)
    local material = coreMaterialOff
    local coreLights = gRegion:FindTagged(coreLightsTag)

    if coreStatus == 1 then
        material = coreMaterialFuel
        for i, light in ipairs(coreLights) do
            light:FirePort("TurnOn")
        end
    elseif coreStatus == 2 then
        material = coreMaterialCoolant
        if coreLightsTag ~= Symbol("SabotageCoreLight") then
            for i, light in ipairs(coreLights) do
                light:SetColor(coreCoolantLightColor)
                light:FirePort("TurnOn")
            end
        end
    else
        for i, light in ipairs(coreLights) do
            light:FirePort("TurnOff")
        end
    end
    
    for i = 1, #coreMeshes do
        coreMeshes[i]:SetOverrideMaterial(coreMatSlots[i], material)
    end
end

function PipeDefenseAvatarDamaged(avatar)
    if not gRegion:IsMaster() then
        return
    end

    local maxHealth = avatar:GetMaxHealth()
    local health = avatar:GetHealth()
    local pct = health / maxHealth
    if pct <= 0.5 and pct > 0.4 then
        local mesh = avatar:GetMesh()
        if mesh == corePipeMeshIntact then
            --avatar:SetMesh(corePipeMeshDamaged, false, true)
            -- To Do: Material swap and effect instead?
        end
    end
end

function PipeDefenseAvatarDied(avatar)
    local objMarker = gRegion:FindNearest(gBaseMarkerInfoType, avatar:GetPosition(), 5)
    if not IsNull(objMarker) then
        objMarker:Destroy() -- Destroy the pipe's objective marker
    end
    avatar:SetMesh(corePipeMeshDestroyed, false, true)
    local pos = avatar:GetPosition()
    pos.y = pos.y + 4
    gRegion:CreateEntity(deathSpawner, pos, ZERO_ROTATION)
    for i, material in ipairs(corePipeDestroyedMatSwaps) do
        if not IsNull(material) and not IsNull(corePipeDestroyedMatSwapIds[i]) then
            avatar:SetOverrideMaterial(corePipeDestroyedMatSwapIds[i], material)
        end
    end
    print("Sabotage: Pipe avatar " .. tostring(avatar) .. " died")
end

function ReactorPlayAnims()
    coreMesh:PlayAnimation(startAnim, true, false)
    coreMesh:PlayAnimation(loopingAnim, false, true)
end