mainProjType = Type()
mainProjTypeHair = Type()
wispProjType = Type()
material = Resource()
hiddenMat = Resource()
ghostBaseMat = Resource()
newHairDeco = Type()
animationNames = {Symbol()}

fadeTime = 1
fadeIn = false

swordEffect = Type()

local sEmBlueTintColor = Symbol("EmBlueTintColor")
local sEmBlueAtten = Symbol("EmBlueAtten")
local sTintColor0 = Symbol("TintColor0")
local sTintColor1 = Symbol("TintColor1")
local sTintColor2 = Symbol("TintColor2")
local sTintColor3 = Symbol("TintColor3")
local sEmissiveTintColorHi = Symbol("EmissiveTintColorHi")

local HairDeco = WeakResource("/Lotus/Characters/Tenno/Operator/Hair/HairMasterDeco")
local skelClothType = WeakResource("/EE/Types/Effects/SkeletalClothEx")

function LotusIsComing(cinematic)
    local t = 0
    local brightColor = Vector(1, 0.68, 0.3)
    local newColor = Vector()
    if IsNull(material) then
        return
    end
    local baseColor = Vector(material:GetParam(sEmBlueTintColor, 1), material:GetParam(sEmBlueTintColor, 2), material:GetParam(sEmBlueTintColor, 3))
    while t < 1 do
        local timer = Clamp(t + Noise(Time() * 4) * 0.2, 0, 1)
        newColor = LerpVector(baseColor, brightColor, timer)
        material:SetParam(sEmBlueTintColor, newColor.x, newColor.y, newColor.z, 1)
        
        local val = 15 + timer * 30  --Really have to crank this one...
        material:SetParam(sEmBlueAtten, val, 0, 0, 0)
        t = t + DeltaTime() * 0.33
        Sleep(0)
    end
    
    local currentTime = cinematic:GetAnimDelta()
    while currentTime < 0.54 do
        Sleep(0)
        currentTime = cinematic:GetAnimDelta()
    end
    
    material:SetParam(sEmBlueAtten, 15, 0, 0, 0)
    material:SetParam(sEmBlueTintColor, baseColor.x, baseColor.y, baseColor.z, 1)
end

local function AllAttachments(avatar)
    local attachments = avatar:GetAllAttachments(skelClothType)
    if IsNull(attachments) then
        attachments = {}
    end
    local decoItems = avatar:GetAllAttachments(gDecorationType)
    for i=1, #decoItems do
        if not decoItems[i]:IsA(gLotusEffectDecorationType) then
            table.insert(attachments, decoItems[i])
        end
    end
    return attachments
end

function AttachedEffects(spawner)
    Sleep(0)
    local avatar = spawner:GetAttachParent()
    
    --avatar:SetDissolve(0.9)
    
    --avatar:SetOverrideMaterialForAllSections(ghostBaseMat, true)

    if not avatar:HasAttachment(mainProjType) then
        avatar:SetOverrideMaterial(0, hiddenMat, false) --Eyeballs
        avatar:SetOverrideMaterial(1, hiddenMat, false) --Eyelashes
        avatar:Attach(mainProjType, EMPTY_SYMBOL)
    end
        
    local decos = AllAttachments(avatar)
    for i, deco in ipairs(decos) do
        if not deco:HasAttachment(wispProjType) then
            deco:Attach(wispProjType, EMPTY_SYMBOL)
        end
        if not deco:HasAttachment(mainProjType) then
            deco:Attach(mainProjType, EMPTY_SYMBOL)
            --decos[i]:SetOverrideMaterialForAllSections(ghostBaseMat, false)
        end
        deco:RemoveMaterialParam(sTintColor0)
        deco:RemoveMaterialParam(sTintColor1)
        deco:RemoveMaterialParam(sTintColor2)
        deco:RemoveMaterialParam(sTintColor3)
        deco:RemoveMaterialParam(sEmissiveTintColorHi)
    end
    
    local hairDeco = avatar:GetAttachment(HairDeco) --Hair doesn't inherit projectors
    if not IsNull(hairDeco) then
        if not avatar:HasAttachment(newHairDeco) then
            local hairMesh = hairDeco:GetMesh()
            --Rebuild the hair without lit transparency as it causes issues here
            local newHair = avatar:Attach(newHairDeco, Symbol("GAME_C1_HEAD1"))
            if not IsNull(newHair) then
                newHair:SetMesh(hairMesh, false, false)
                newHair:Attach(mainProjTypeHair, EMPTY_SYMBOL)
                newHair:SetOverrideMaterialForAllSections(ghostBaseMat, false)
            end
            --Check for hair bands, these can remain
            local childrenOfHair = hairDeco:GetAllAttachments(gDecorationType)
                for i, deco in ipairs(childrenOfHair) do
                    deco:SetOverrideMaterialForAllSections(ghostBaseMat, false)
                    deco:SetUseParentVisibility(false)
                end
            hairDeco:SetVisibility(false, false)
        end
        --hairDecos[i]:Attach(wispProjType, EMPTY_SYMBOL)
    end
    
    Sleep(0.1)
    for i, deco in ipairs(decos) do
        deco:SetOverrideMaterialForAllSections(ghostBaseMat, false)
    end
    
    avatar:SetOverrideMaterial(2, ghostBaseMat, false)
    avatar:SetOverrideMaterial(3, ghostBaseMat, false)
    avatar:RemoveMaterialParam(sTintColor0)
    avatar:RemoveMaterialParam(sTintColor1)
    avatar:RemoveMaterialParam(sTintColor2)
    avatar:RemoveMaterialParam(sTintColor3)
    avatar:RemoveMaterialParamEx(sEmissiveTintColorHi, 0)
    avatar:RemoveMaterialParamEx(sEmissiveTintColorHi, 1)
    avatar:RemoveMaterialParamEx(sEmissiveTintColorHi, 2)
    avatar:RemoveMaterialParamEx(sEmissiveTintColorHi, 3)
end

function SwordGrabbed(spawner)
    Sleep(0.5)
    local effect = gRegion:FindFirstTagged(Symbol("SwordBaseEffect"))
    if not IsNull(effect) then
        effect:Destroy()
    end
end

function OperatorSwordGrab(spawner)
    local sword = gRegion:FindFirstTagged(Symbol("ChimeraSword"))
    if not IsNull(sword) then
        sword:Attach(swordEffect, EMPTY_SYMBOL)
    end
end

function FadeWhite()
    local postBias = gRegion:GetLevelInfo():GetPostProcessBias()
    if IsNull(postBias) then
        return
    end

    if not fadeTime or fadeTime <= 0 then
        fadeTime = 1
    end

    local t = 0
    while t < 1 do
        local a = SmoothStep(Clamp(t, 0, 1))

        if fadeIn then
            postBias.fade = -1 + a
        else
            postBias.fade = -a
        end

        Sleep(0)
        t = t + DeltaTime() / fadeTime
    end

    if fadeIn then
        postBias.fade = 0
    else
        postBias.fade = -1
    end
end

function DissolveForPortal()
    local dissolveEntities = {}

    local emptyTable = {}
    
    for _,name in ipairs(animationNames) do
        local entity = (gRegion:FindAnimationNamed(name) or emptyTable)[1]
        table.insert(dissolveEntities, entity)
        local attachments = entity:GetAllAttachments(gDecorationType)
        for _,attachment in ipairs(attachments) do
            table.insert(dissolveEntities, attachment)
        end
    end

    local t = 0
    while t < 1 do
        Sleep(0)
        t = t + DeltaTime() / fadeTime
        local a = SmoothStep(Clamp(t, 0, 1))
        
        for _,e in ipairs(dissolveEntities) do
            if not IsNull(e) then
                e:SetDissolve(a)
            end
        end
    end
end
