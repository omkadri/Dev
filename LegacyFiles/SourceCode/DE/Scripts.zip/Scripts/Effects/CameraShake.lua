local EASING = require "Lotus.Scripts.Libs.EasingLib"

Delay = 0
shakeAmp = 1
shakePeriod = 1
Radius = 15
shakeMultiplier = 8
shakeTime = 4
timeMod = 2

function StartCameraShake(trigger)
    local t = 0
    local levelInfo = gRegion:GetLevelInfo()
    local player = gRegion:GetLocalPlayerAvatar()
    
    if IsNull(player) then
        return
    end

    --local players = gRegion:GetHumanPlayers()
    
    Sleep(Delay)
    
    --for i=0, #players do
        if Length(player:GetSimPosition()-trigger:GetSimPosition()) > Radius then
            return
        end
    --end
    
    while t < shakeTime  do
        levelInfo.postProcess.viewShake.mShakeAmbient = Abs(Sin(t*timeMod)) * shakeMultiplier
        t = t + DeltaTime()
        Sleep(0)
    end
    
    levelInfo.postProcess.viewShake.mShakeAmbient = 0
end

function CameraShakeBounce(trigger)
    local t = 0
    local levelInfo = gRegion:GetLevelInfo()
    local player = gRegion:GetLocalPlayerAvatar()
    
    if IsNull(player) then
        return
    end
    
    Sleep(Delay)
    
    if Length(player:GetSimPosition()-trigger:GetSimPosition()) > Radius then
        return
    end
    
    while t < shakeTime  do
        levelInfo.postProcess.viewShake.mShakeAmbient = EASING.inElastic(t, shakeMultiplier, -shakeMultiplier, shakeTime, shakeAmp, shakePeriod)
        --levelInfo.postProcess.viewShake.mShakeAmbient =  EASING.inBounce(t, shakeMultiplier, -shakeMultiplier, shakeTime)
        t = t + DeltaTime()
        Sleep(0)
    end
    
    levelInfo.postProcess.viewShake.mShakeAmbient = 0
end
