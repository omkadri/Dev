colorButNoFlickerDecos = {Instance()}
effectsDecos = {Instance()} --These will check for, and color, attached projectors/particles
lightsToChange = {Instance()}
dustParticles = Instance()
applyColorToMe = false
applyToChildren = false
applyToTheseChildren = {WeakResource()}
sleepTime = 1

MaxDistance = 6
MinAniSpd = 0.2
MaxAniSpd = 2
StreamChild = WeakResource()
SpinTransTimeLength = 1

local COLOR_UTIL = require "Lotus.Scripts.Effects.EffectsColorUtilities"
local effectTag = Symbol("EffectsDeco")
local buildingTag = Symbol("BuildingEffect")

local TintColor = Symbol("TintColor")
local TintColor0 = Symbol("TintColor0")
local TintColor1 = Symbol("TintColor1")
local TintColor2 = Symbol("TintColor2")
local TintColor3 = Symbol("TintColor3")

local mEmissiveTintColor = Symbol("EmissiveTintColor")
local mEmissiveTintColorHi = Symbol("EmissiveTintColorHi")
local mEmissiveTintColorLo = Symbol("EmissiveTintColorLo")

local mMorphParam = Symbol("MorphAmount")
local EASING = require "Lotus.Scripts.Libs.EasingLib"

local function GetEnergyColor()
    local energyColor = Color(212, 227, 255, 255)

    if gRegion:IsMaster() then
        local playerProfile = gPlayerProfileMgr:GetPlayerProfile(0)
        if not IsNull(playerProfile) then
            local gameData = playerProfile:GetGameSpecificData()
            if not IsNull(gameData) then
                local customization = gameData:GetPlayerShip(true).mShipInterior
                if not IsNull(customization) then
                    energyColor = customization.mColors.mEnergyColor
                end
            end
        end
    else
        local squadMembers = gMatchingService:GetSquadMembers()
        for i = 1, #squadMembers do
            local squadMember = squadMembers[i]
            if squadMember.isHost then
                local loadout = cjson.decode(squadMember.loadout)
                if not IsNull(loadout.ShipInterior) then
                    local theColors = loadout.ShipInterior.Colors

                    -- Raw JSON color values are ints (can be negative), so need to initialize this way
                    if theColors.en ~= nil then
                        local colorPalette = Lotus_Game.CustomizationColorPalette()

                        colorPalette:SetColorInt(Lotus_Game.EnergyColor, theColors.en)
                        colorPalette:SetInitialized(Lotus_Game.EnergyColor, true)

                        energyColor = colorPalette:GetColor(Lotus_Game.EnergyColor)
                    end
                end
            end
        end
    end

    return energyColor
end

local function PlayerColor()
    local energyColor = Color(212, 227, 255, 255)
    local color0 = Color(177, 177, 181, 128)
    local color1 = Color(176, 198, 234, 128)
    local color2 = Color(158, 158, 158, 128)
    local color3 = Color(118, 118, 118, 128)

    if gGameRules:IsA(gLotusAttractModeGameRulesType) then
        local customization = gGameRules:GetShipInterior()
        if not IsNull(customization.mSkinFlavourItem) or _T.ColoringLisetInt == true then
            if customization.mColors:Initialized(Lotus_Game.TintColor0) then
                color0 = customization.mColors.mTintColor0
            end
            if customization.mColors:Initialized(Lotus_Game.TintColor1) then
                color1 = customization.mColors.mTintColor1
            end
            if customization.mColors:Initialized(Lotus_Game.TintColor2) then
                color2 = customization.mColors.mTintColor2
            end
            if customization.mColors:Initialized(Lotus_Game.TintColor3) then
                color3 = customization.mColors.mTintColor3
            end
            if customization.mColors:Initialized(Lotus_Game.EnergyColor) then
                energyColor = customization.mColors.mEnergyColor
            end
        end
    end
    
    energyColor.alpha = 255
    return COLOR_UTIL.SRGBToLinear255(energyColor), energyColor, COLOR_UTIL.SRGBToLinear255(color0), COLOR_UTIL.SRGBToLinear255(color1), COLOR_UTIL.SRGBToLinear255(color2), COLOR_UTIL.SRGBToLinear255(color3)
end

local function ColorTints(deco, color0, color1, color2, color3)
    deco:SetMaterialParam(TintColor0, color0.red / 255, color0.green / 255, color0.blue / 255, 0.5)
    deco:SetMaterialParam(TintColor1, color1.red / 255, color1.green / 255, color1.blue / 255, 0.5)
    deco:SetMaterialParam(TintColor2, color2.red / 255, color2.green / 255, color2.blue / 255, 0.5)
    deco:SetMaterialParam(TintColor3, color3.red / 255, color3.green / 255, color3.blue / 255, 0.5)
end

local function CustomLisetEnergyColor()
    local energyColor, srgbEnergyColor, color0, color1, color2, color3 = PlayerColor()

    for i, temp in ipairs(colorButNoFlickerDecos) do
        temp:SetMaterialParam(Lotus_Game.TINT_COLOR, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
        temp:SetMaterialParam(mEmissiveTintColor, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
        temp:SetMaterialParam(mEmissiveTintColorHi, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
        temp:SetMaterialParam(mEmissiveTintColorLo, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
        ColorTints(temp, color0, color1, color2, color3)
    end
    
    for i, temp in ipairs(effectsDecos) do
        temp:SetMaterialParam(Lotus_Game.TINT_COLOR, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)

        COLOR_UTIL.ApplyHighLowOnParticleSysChildren(temp, energyColor)
        Effects.SetColorMinMaxChildParticleSystems(temp, gEffectType, energyColor, energyColor)

        local projectors = temp:GetAllAttachments(gDynamicProjectorType)
        for j=1, #projectors do
            local proj = projectors[j]
            proj:SetMaterialParam(Lotus_Game.TINT_COLOR, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
            proj:SetMaterialParam(Symbol("offsetColor"), energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
        end
        local flares = temp:GetAllAttachments(gLensFlareType)
        for j=1, #flares do
            flares[j]:SetTint(energyColor)
        end
        local rays = temp:GetAllAttachments(gDecorationType)
        for j=1, #rays do
            local ray = rays[j]
            if (ray:GetTag() == effectTag) or (ray:GetTag() == buildingTag) then
                ray:SetMaterialParam(mEmissiveTintColor, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
                ray:SetMaterialParam(Lotus_Game.TINT_COLOR, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
            end
        end
    end
    
    local jukeSeq = gRegion:FindFirstTagged(Symbol("JUKEBOX_SEQUENCER"))
    if not IsNull(jukeSeq) then
        jukeSeq:SetMaterialParam(Lotus_Game.TINT_COLOR, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
    end
    
    local miniOctavia = gRegion:FindFirstTagged(Symbol("MiniOctavia"))
    if not IsNull(miniOctavia) then
        miniOctavia:SetMaterialParam(Lotus_Game.TINT_COLOR0, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1, true)
        miniOctavia:SetMaterialParam(mEmissiveTintColorHi, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1, true)
    end
    
    local colorH, colorS, colorV = COLOR_UTIL.RGBToHSV(srgbEnergyColor)
    for i, temp in ipairs(lightsToChange) do
            local lightColor = temp:GetColor()
            local lightH, lightS, lightV = COLOR_UTIL.RGBToHSV(lightColor)
            local newLightColor = COLOR_UTIL.HSVToRGB(colorH, colorS * 0.05, lightV) --Keep brightness consistent, don't oversaturate
            temp:SetColor(newLightColor)
    end
    
    local dustColor = Color()
    dustColor = COLOR_UTIL.HSVToRGB(colorH, colorS * 0.3, colorV * 0.6) --This dust needs to remain subtle
    dustColor.alpha = 80
    if not IsNull(dustParticles) then
        dustParticles:SetColorMinMax(dustColor, dustColor)
    end
end

function FlickerDecorations()
    Sleep(1)
    while not gPlayerProfileMgr:IsLoggedIn() do
        Sleep(0)
    end
    Sleep(1) --Give other stuff time to process

    if IsNull(_T.ApplyPlayerLisetColors) then
        _T.ApplyPlayerLisetColors = true
    end
    while true do
        if not IsNull(_T.ApplyPlayerLisetColors) then
            if _T.ApplyPlayerLisetColors then
                CustomLisetEnergyColor()
                _T.ApplyPlayerLisetColors = false
            end
        end
        Sleep(0)
    end
end

function EntityColorButNoFlicker(entity)
    local energyColor, srgbEnergyColor, color0, color1, color2, color3 = PlayerColor()
    
    entity:SetMaterialParam(Lotus_Game.TINT_COLOR, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
    entity:SetMaterialParam(mEmissiveTintColor, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
    entity:SetMaterialParam(mEmissiveTintColorHi, 1, 1, 1, 1)
    entity:SetMaterialParam(mEmissiveTintColorLo, 1, 1, 1, 1)
    ColorTints(entity, color0, color1, color2, color3)
end

local function _ColorParticleSys(pSys, energyColor)
    pSys:SetColorMinMax(energyColor, energyColor)
    COLOR_UTIL.ApplyHighLow(pSys, energyColor)
end

local function _ColorDeco(deco, energyColor)
    deco:SetMaterialParam(TintColor, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
    COLOR_UTIL.ApplyHighLow(deco, energyColor)
    
    deco:SetMaterialParam(Symbol(mEmissiveTintColorHi), energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
    deco:SetMaterialParam(Symbol(mEmissiveTintColorLo), energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
end

function ColorParticleSys(pSys)
    Sleep(sleepTime)
    while not gPlayerProfileMgr:IsLoggedIn() do
        Sleep(0)
    end
    local energyColor = GetEnergyColor()
    _ColorParticleSys(pSys, energyColor)
end

function ApplyShipEnergyColor(entity)
    Sleep(sleepTime)
    while not gPlayerProfileMgr:IsLoggedIn() do
        Sleep(0)
    end
    local energyColor = GetEnergyColor()
    if entity:IsA(gLightType) then
        entity:SetColor(energyColor)
    else
        _ColorDeco(entity, energyColor)
    end
    if applyToChildren then

        COLOR_UTIL.ApplyHighLowOnParticleSysChildren(entity, energyColor)
        Effects.SetColorMinMaxChildParticleSystems(entity, gEffectType, energyColor, energyColor)

        local allChildren = entity:GetAllAttachments(gEntityType)
        for i=1, #allChildren do
            local child = allChildren[i]
            if not IsNull(child) then
                if child:IsA(gLightType) then
                    child:SetColor(energyColor)
                elseif child:IsA(gParticleSysType) then
                    --Already done
                else
                    _ColorDeco(child, energyColor)
                end
            end
        end
    end
end

function ApplyShipEnergyColorToSelected(entity)
    Sleep(sleepTime)
    while not gPlayerProfileMgr:IsLoggedIn() do
        Sleep(0)
    end
    local energyColor = GetEnergyColor()
    if applyColorToMe then
        if entity:IsA(gLightType) then
            entity:SetColor(energyColor)
        else
            _ColorDeco(entity, energyColor)
        end
    end

    COLOR_UTIL.ApplyHighLowOnParticleSysChildren(entity, energyColor)
    for i=1, #applyToTheseChildren do
        Effects.SetColorMinMaxChildParticleSystems(entity, applyToTheseChildren[i], energyColor, energyColor)
    end
    local allChildren = entity:GetAllAttachments(gEntityType)
    for i=1, #allChildren do
        local child = allChildren[i]
        for i=1, #applyToTheseChildren do
            if not IsNull(child) and child:IsA(applyToTheseChildren[i]) then
                 
                if child:IsA(gLightType) then
                    child:SetColor(energyColor)
                elseif child:IsA(gParticleSysType) then
                    --Already done
                else
                    _ColorDeco(child, energyColor)
                end
            end
        end
    end
end

function InfestedReactionDeco(deco)
    Sleep(0)
    while not gPlayerProfileMgr:IsLoggedIn() do
        Sleep(0)
    end
    Sleep(1)
    Engine.EnableZoneCull(deco)
    local t = 0
    local dist = 10
    local distanceAmbientAnim = 0
    local ambientAnimAmount = 0
    local decoPos = deco:GetPosition()
    local avatar = gRegion:GetLocalPlayerAvatar()
    local decoFacingDir = RotateVector(Vector(0, 0, 1), deco:GetRotation())
    
    local reactiveDistance = 5
    local currentDistAmbientAnim = 0
    local newDistAmbientAnim = 0
    local vec = Vector()

    while not IsNull(deco) and not IsNull(avatar) do
        ambientAnimAmount = math.sin(t) * 0.05 + 0.05
        avatar:GetPositionEx(vec)
        VectorSub(vec, vec, decoPos)
        dist = Length(vec)
        Normalize(vec)
        local atten = math.max(0, Dot(vec, decoFacingDir))
        distanceAmbientAnim = Clamp((reactiveDistance - dist) / reactiveDistance, 0, 1) * atten
        newDistAmbientAnim = Lerp(currentDistAmbientAnim, distanceAmbientAnim, 0.02)
        deco:SetAnimDelta(0, ambientAnimAmount + newDistAmbientAnim * 0.9)
        currentDistAmbientAnim = newDistAmbientAnim
        Sleep(0)
        t = t + DeltaTime() * 2
    end
end

function planterDSpinOnProximity(deco)

    Sleep(sleepTime)
    while not gPlayerProfileMgr:IsLoggedIn() do
        Sleep(0)
    end
    
    if applyColorToMe then
        local energyColor = GetEnergyColor()
        if deco:IsA(gLightType) then
            deco:SetColor(energyColor)
        else
            _ColorDeco(deco, energyColor)
        end
    end
    
    -- Spin on Local Player only
    local avatar = gRegion:GetLocalPlayerAvatar()
    local pos = deco:GetPosition()
    local attachments = deco:GetAttachedChildren()
    local stream
    
    for i=1, #attachments do
        if attachments[i]:IsA(StreamChild) then
            stream = attachments[i]
        end
    end  
       
    local spinning = false
    while not IsNull(deco) and not IsNull(avatar) do
    
        local dist
        if not IsNull(avatar) then
            dist = avatar:DistanceToPoint(pos)
            local t = 0
            local val
            if dist <= MaxDistance then
                while t < SpinTransTimeLength and spinning == false do
                    val = EASING.inOutQuad(t, 0, 1, SpinTransTimeLength)
                    if not IsNull(stream) then
                        stream:SetMaterialParam(mMorphParam, val)
                    end
                    deco:SetAnimRate(0, val * (MaxAniSpd-MinAniSpd) + MinAniSpd)
                    Sleep(0)
                    t = t + DeltaTime()
                end
                spinning = true
            elseif dist > MaxDistance and spinning == true then
                while t < SpinTransTimeLength and spinning == true do
                    val = EASING.inOutQuad(t, 1, -1, SpinTransTimeLength)
                    if not IsNull(stream) then
                        stream:SetMaterialParam(mMorphParam, val)
                    end
                    deco:SetAnimRate(0, val * (MaxAniSpd-MinAniSpd) + MinAniSpd)
                    Sleep(0)
                    t = t + DeltaTime()
                end
                spinning = false
            end
        end
        
        Sleep(1)
    end
end

function FoundryGlow(deco)
    local sNScalesWorldPos = Symbol("nScalesWorldPos")
    local foundryDeco = gRegion:FindFirstTagged(Symbol("FoundryBakingEffectDeco"))
    local pos = Vector()
    while not IsNull(foundryDeco) do
        if deco:IsVisible() then
            pos = deco:GetPosition()
            foundryDeco:SetMaterialParam(sNScalesWorldPos, pos.x, pos.y, pos.z, 1)
        else
            foundryDeco:SetMaterialParam(sNScalesWorldPos, 0, 0, 0, 1)
            Sleep(2)
        end
        Sleep(0)
    end
end