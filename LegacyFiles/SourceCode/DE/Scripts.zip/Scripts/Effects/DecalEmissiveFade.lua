emissiveAtten = 50
fadeDuration = 1
lowClamp = 0
useAttachmentsColorSlot = false

local COLOR_UTIL = require "Lotus.Scripts.Effects.EffectsColorUtilities"

local emissiveMapAtten = Symbol("EmissiveMapAtten")
local emissiveTintColor = Symbol("EmissiveTintColor")
local useEnergyColor = false

function FadeEmissive(decal)

    local energyColor = Color()
    local energyColorA = Color()
    local energyColorB = Color()
    
    local weapon = decal:GetCreator()
    if not IsNull(weapon) and weapon:IsA(gLotusWeaponType) then
        if useAttachmentsColorSlot then 
            local customization = weapon:GetCustomization()
            local colors = customization:GetColors(Lotus_Game.Attachments)
            if colors:Initialized(Lotus_Game.EnergyColor) then
                energyColorA = Color(colors.mEnergyColor)
                useEnergyColor = true
                if colors:Initialized(Lotus_Game.EnergyColor1) then
                    energyColorB = Color(colors.mEnergyColor1)
                else
                    energyColorB = energyColorA
                end
            end
        else
            useEnergyColor = weapon:GetEnergyColor(energyColorA, false)
            useEnergyColor = weapon:GetEnergyColor(energyColorB, true)
        end
    end
    
    local matVal = 0
    local t = 0
    while t < fadeDuration do
        matVal = Clamp(((1 - SmoothStep(t / fadeDuration)) * emissiveAtten), lowClamp, emissiveAtten)
        decal:SetMaterialParam(emissiveMapAtten,matVal)
        
        if useEnergyColor then
        
            energyColor.red = Lerp(energyColorA.red,energyColorB.red,t/fadeDuration)
            energyColor.green = Lerp(energyColorA.green,energyColorB.green,t/fadeDuration)
            energyColor.blue = Lerp(energyColorA.blue,energyColorB.blue,t/fadeDuration)
            
            decal:SetMaterialParam(emissiveTintColor, COLOR_UTIL.SRGBToLinear(energyColor.red), COLOR_UTIL.SRGBToLinear(energyColor.green), COLOR_UTIL.SRGBToLinear(energyColor.blue))
        end
        
        t = t + DeltaTime()
        Sleep(0)
    end
    
    decal:SetMaterialParam(emissiveMapAtten,lowClamp)
end

function SetEmissiveAtten(decal)
    decal:SetMaterialParam(emissiveMapAtten, emissiveAtten)
end