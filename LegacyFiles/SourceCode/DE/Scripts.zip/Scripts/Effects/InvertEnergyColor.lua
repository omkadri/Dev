local COLOR_UTIL = require "Lotus.Scripts.Effects.EffectsColorUtilities"

function InvertEnergyColor(entity)
    
    local parentSpawner = entity:GetRootOwner()
    local parent = parentSpawner:GetCreator()
    
    local energyColor = Color(255,255,255,1)
    
    if not IsNull(parent) and parent:IsA(gLotusWeaponType) then
        local playerCustomization = parent:GetCustomization()
        local colors = playerCustomization:GetColors(Lotus_Game.PrimaryColors)
    
        if colors:Initialized(Lotus_Game.EnergyColor) then
            energyColor = colors.mEnergyColor
        end
    end
        
    energyColor.red = 255 - energyColor.red
    energyColor.green = 255 - energyColor.green
    energyColor.blue = 255 - energyColor.blue
    
    entity:SetMaterialParam(Symbol("TintColor"), COLOR_UTIL.SRGBToLinear(energyColor.red), COLOR_UTIL.SRGBToLinear(energyColor.green), COLOR_UTIL.SRGBToLinear(energyColor.blue),1)
    COLOR_UTIL.ApplyHighLow(entity, energyColor)
    
end