TimeLength = 0.5
RandomYRotation = true
-- Scaling Linear & Acceleration
ScaleEase = true
ScaleTimeLength = 1
StartScale = Vector(1,1,1)
EndScale = Vector()

-- Fade
Fade = true
FadeTimeLength = 0.5
StartFadeValue = 1
EndFadeValueEnd = 0
FadeParam = Symbol("UnlitAtten")

ColorTinting = true
ColorTimeLength = 0.5
ColorStartValue = Color(255,255,255,255)
ColorEndValue = Color(255,0,0,255)

-- Easing Functions
-- quadratic easing out - decelerating to zero velocity
local function easeOutQuad(t, b, c, d)
    t=t/d
    return -c * t*(t-2) + b
end

-- exponential easing out - decelerating to zero velocity
local function easeOutExpo(t, b, c, d)
    if (t==d) then
        return b+c
    else
        return c * (-math.pow(2, -10 * t/d) + 1) + b
    end
end


function Combiner(deco)
    local t = 0
    local scVal = Vector(StartScale.x, StartScale.y, StartScale.z)
    local fadeVal
    local r,g,b,a = ColorStartValue.red/255, ColorStartValue.green/255, ColorStartValue.blue/255, ColorStartValue.alpha/255
    Sleep(0)
    if RandomYRotation == true then
        local xAngle = math.random (-5, 5)
        local yAngle = math.random (-180 , 180)
        local zAngle = math.random (-5, 5)
        local decoRot = Rotation()
        decoRot.bank = xAngle
        decoRot.heading = yAngle
        decoRot.pitch = zAngle
        deco:SetRotation(decoRot)
    end
    while t < TimeLength do
        if t < ScaleTimeLength and ScaleEase == true then
            scVal = easeOutExpo(t, StartScale, EndScale - StartScale, ScaleTimeLength)
            deco:SetMaterialParam(Lotus_Game.V_SCALES, scVal.x, scVal.y, scVal.z)  --:???
        end
        if t < FadeTimeLength and Fade == true then
            fadeVal = easeOutExpo(t, StartFadeValue, EndFadeValueEnd-StartFadeValue, FadeTimeLength)
            deco:SetMaterialParam(FadeParam, fadeVal)
        else if t > FadeTimeLength then
            fadeVal = EndFadeValueEnd
            deco:SetMaterialParam(FadeParam, fadeVal)
            end
        end
        if t < ColorTimeLength and ColorTinting == true then 
                r = easeOutExpo(t, ColorStartValue.red/255, ColorEndValue.red/255-ColorStartValue.red/255, ColorTimeLength)
                g = easeOutExpo(t, ColorStartValue.green/255, ColorEndValue.green/255-ColorStartValue.green/255, ColorTimeLength)
                b = easeOutExpo(t, ColorStartValue.blue/255, ColorEndValue.blue/255-ColorStartValue.blue/255, ColorTimeLength)
            deco:SetMaterialParam(Lotus_Game.TINT_COLOR, r,g,b,a)
        end
        t = t + DeltaTime() 
        Sleep(0)
    end
end
