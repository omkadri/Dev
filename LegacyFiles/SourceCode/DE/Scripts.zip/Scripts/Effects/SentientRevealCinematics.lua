typeToKill = WeakResource()
typeToAttach = Type()
attachToThis = Instance()
attachToArray = {Instance()}
isAttachedToThis = Instance()
isAttachedToThisArray = {Instance()}
attachPos = Vector()
attachRot = Rotation()
delay = 0.0
attachmentType = Type()
isEnable = true

sentientsAreMadAtYouColor = Color()
attachToHunhow = Type()

sparkDecoType = Type()
flowParticleType = Type()
gooParticleType = Type()
flareType = Type()
shieldType = Type()

postProcessMaterial = Resource()

attachBone = Symbol()

glitchSpeed = 2

local StalkerTag = Symbol("Stalker")
local StalkerSwordAnimName = Symbol("SentientSword")
local IllusionAvatar = WeakResource("/Lotus/Powersuits/Harlequin/IllusionMirrorAvatar")
local EFFECTS_UTIL = require "Lotus.Scripts.Effects.EffectsUtilities"
local EASING = require "Lotus.Scripts.Libs.EasingLib"

local SYM_EMISSIVE_TINT_COLOR_LO = Symbol("EmissiveTintColorLo")
local SYM_EMISSIVE_TINT_COLOR_HI = Symbol("EmissiveTintColorHi")
local SYM_UNLIT_ATTEN = Symbol("UnlitAtten")
local SYM_EMISSIVE_MAP_ATTEN = Symbol("EmissiveMapAtten")

local GLITCH_WEIGHT = 1.0

function KillAttached()
    if not IsNull(typeToKill) then
        local temp = isAttachedToThis:GetAttachment(typeToKill)
        if not IsNull(temp) then
            temp:Destroy()
        end
    end
end

function KillAttachedToGameCamera()
    Sleep(delay)
    local cam = gRegion:GetGameCamera()
    if not IsNull(typeToKill) and not IsNull(cam) then
        local temp = cam:GetAttachment(typeToKill)
        if not IsNull(temp) then
            temp:Destroy()
        end
    end
end

function KillThisAttachedToParent(deco)
    local parent = deco:GetAttachParent()
    if not IsNull(parent) and not IsNull(typeToKill) then
        local children = parent:GetAttachment(typeToKill)
        if not IsNull(children) then
            children:Destroy()
        end
    end
end

function KillAttachedArray()
    if not IsNull(isAttachedToThisArray) and not IsNull(typeToKill) then
        for count=1, #isAttachedToThisArray do
            local temp = isAttachedToThisArray[count]:GetAttachment(typeToKill)
            if not IsNull(temp) then
                temp:Destroy()
            end
        end
    end
end

function Attach()
    Sleep(delay)
    if not IsNull(attachToThis) and not IsNull(typeToAttach) then
        attachToThis:Attach(typeToAttach, EMPTY_SYMBOL, attachPos, attachRot)
    end
end

function AttachArray()
    if not IsNull(attachToArray) and not IsNull(typeToAttach) then
        for count=1, #attachToArray do
            attachToArray[count]:Attach(typeToAttach, EMPTY_SYMBOL, attachPos, attachRot)
        end
    end
end

function AttachProjector(spawner)
    Sleep(0)
    local parent = spawner:GetAttachParent()
    if not IsNull(parent) and not IsNull(typeToAttach) then
        parent:AttachIncludingChildren(typeToAttach, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, true)
    end
end

function KillParent(deco)
    local parent = deco:GetAttachParent()
    if not IsNull(parent) then
        parent:Destroy() --Dirty :(
    end
end

function AttachToMe(deco)
    if not IsNull(typeToAttach) then
        deco:Attach(typeToAttach, EMPTY_SYMBOL)
    end
end

function AttachToAvatarFromBehavior(behavior)
    local avatar = behavior:GetAvatar()
    if not IsNull(avatar) then
        if not IsNull(typeToAttach) then
            avatar:Attach(typeToAttach, EMPTY_SYMBOL)
        end
    end
end

function DestroyIfSelfExists(entity)
    local parent = entity:GetAttachParent()
    if not IsNull(parent) then
        local items = parent:GetAllAttachments(entity)
        if #items > 1 then
            entity:Destroy()
        end
    end
end

function KillParticleCenterTypeIfIllusionAvatar(entity)
    local object = entity:GetCreator()
    if IsNull(object) then
        return
    end
    local root = object:GetAttachRoot()
    if IsNull(root) then
        return
    end
    if root:IsA(IllusionAvatar) then
        entity:Destroy()
    end
end

function EnableDisableAttachment()
    local items = isAttachedToThis:GetAllAttachments(attachmentType)
    if not IsNull(items) then
        for i, temp in ipairs(items) do
            if isEnable then
                temp:Enable()
            else
                temp:Disable()
            end
        end
    end
end

function EnableDisableAttachmentOnParent(entity)
    local parent = entity:GetAttachParent()
    if IsNull(parent) then
        return
    end
    local items = parent:GetAllAttachments(attachmentType)
    if not IsNull(items) then
        for i, temp in ipairs(items) do
            if isEnable then
                temp:Enable()
            else
                temp:Disable()
            end
        end
    end
end

function SwapSentientColor(spawner)
    local t = 0
    local fxTag = Symbol("SentientAttachEffect")
    local finalRange = 20
    local startPos = spawner:GetSimPosition()
    
    local hunhow = gRegion:FindFirstTagged(Symbol("Hunhow"))
    if not IsNull(hunhow) then
        hunhow:Attach(attachToHunhow, EMPTY_SYMBOL)
        hunhow:SetMaterialParam(Lotus_Game.EMISSIVE_MAP_ATTEN, 4)
        hunhow:SetMaterialParam(SYM_EMISSIVE_TINT_COLOR_LO, sentientsAreMadAtYouColor.red / 255, sentientsAreMadAtYouColor.green / 255, sentientsAreMadAtYouColor.blue / 255, 1)
        hunhow:SetMaterialParam(SYM_EMISSIVE_TINT_COLOR_HI, sentientsAreMadAtYouColor.red / 255, sentientsAreMadAtYouColor.green / 255, sentientsAreMadAtYouColor.blue / 255, 1)
    end
    local lightningFx = gRegion:FindFirstTagged(Symbol("LightningEffectType"))
    if not IsNull(lightningFx) then
        local minColor = sentientsAreMadAtYouColor
        minColor.alpha = 255
        lightningFx:SetColorMinMax(minColor, sentientsAreMadAtYouColor)
    end
    while true do
        local allFx = gRegion:FindTaggedInRadius(fxTag, startPos, 0, finalRange * t)
        for i=1, #allFx do
            local temp = allFx[i]
            if temp:IsA(gParticleSysType) then
                temp:SetColorMinMax(sentientsAreMadAtYouColor, sentientsAreMadAtYouColor)
            elseif temp:IsA(gLensFlareType) then
                temp:SetTint(sentientsAreMadAtYouColor)
            elseif temp:IsA(gLightType) then
                temp:SetColor(sentientsAreMadAtYouColor)
                temp:SetBrightness(0.5)
            end
        end
        t = math.min(t + DeltaTime() * 0.5, 1) --Just keep running in case any are made after the burst
        Sleep(0)
    end
end

function DragonRevealLights()
    local allLights = gRegion:FindAll(gLightType)
    local brights = {}
    for i=1, #allLights do
        local thisBrightness = allLights[i]:GetBrightness()
        table.insert(brights, thisBrightness)
    end
    local smokeEffect = gRegion:FindFirstTagged(Symbol("SmokeStuff"))
    local wind = gRegion:FindFirstTagged(Symbol("WindEffect"))
    local smokeColor = Color(112, 106, 99, 20)
    local t = 0
    local pPoints = {1, 0.6, 0.1, 0.1, 0.5, 1}
    local smokeRed = {112, 120, 145, 112}
    local smokeGreen = {106, 102, 88, 106}
    local smokeBlue = {99, 88, 41, 99}
    local windForces = {0, 60, 50, 20, 0}
    while t < 1 do
        local val = EFFECTS_UTIL.Piecewise(t, pPoints)
        for i, temp in ipairs(allLights) do
            temp:SetBrightness(brights[i] * val)
        end
        if not IsNull(smokeEffect) then
            local newRed = EFFECTS_UTIL.Piecewise(t, smokeRed)
            local newGreen = EFFECTS_UTIL.Piecewise(t, smokeGreen)
            local newBlue = EFFECTS_UTIL.Piecewise(t, smokeBlue)
            local newColor = Color(newRed, newGreen, newBlue, smokeColor.alpha)
            smokeEffect:SetColorMinMax(newColor, newColor)
        end
        if not IsNull(wind) then
            local newForce = EFFECTS_UTIL.Piecewise(t, windForces)
            local r = Range(newForce * 0.6, newForce)
            wind:SetForce(r)
        end
        Sleep(0)
        t = t + DeltaTime() * 0.5
    end  
    if not IsNull(wind) then
        wind:Destroy()
    end
end

function HunhowApproachCamera(cinematic)

    local postProcess = cinematic:GetRegionMgr():GetLevelInfo().postProcess

    local t = 0
    while t < 1.0 do
        postProcess.fade = Lerp(0, 0.2, t)
        local st = t--(t * t)
        cinematic:SetShakeParams(st * 1, 0.1, 0.2, Lerp(0.5, 1.0, t))
       t = t + DeltaTime() * 0.15
       Sleep(0) 
    end

end

function BringSparksToSword(spawner)
    local parent = spawner:GetAttachParent()
    if IsNull(parent) then
        return
    end
    local spark = parent:GetAttachment(sparkDecoType)
    local sword = gRegion:FindFirstTagged(Symbol("StalkerSword"))
    if IsNull(sword) then
        local Swords = gRegion:FindAnimationNamed(StalkerSwordAnimName)
        if not IsNull(Swords) then
            sword = Swords[1]
        end
    end
    if IsNull(spark) or IsNull(sword) then
        return
    end
    spark:Unattach()
    local startPosition = spark:GetSimPosition()
    local flare = spark:GetAttachment(gLensFlareType)
    local speed = Random(0.4, 0.8)
    speed = 0.3 --Keeping consistent, to not annoy sound guys
    local yArc = Random(-1.5, 1.5)
    --(time, start, change, duration, amplitude, period)
    --outQuad(t, b, c, d)
    local t = 0
    local newPos = Vector()
    local killedFlow = false
    local killedGoo = false
    while t < 1 and not IsNull(sword) and not IsNull(spark) do
        local val = EASING.outElastic(t, 0, 1, 1, 0.5, 0.8)
        newPos = LerpVector(startPosition, sword:GetSimPosition(), val)
        newPos.y = newPos.y + (1 - EASING.outQuad(t, 0, 1, 1)) * yArc * math.sin(t * 3.14159) - t * 0.5
        spark:SetPosition(newPos)
        if t > 0.8 and not killedFlow then
            local pSys = spark:GetAttachment(flowParticleType)
            if not IsNull(pSys) then
                pSys:Disable()
            end
            killedFlow = true
        end
        if t > 0.5 and not killedGoo then
            local pSys = spark:GetAttachment(gooParticleType)
            if not IsNull(pSys) then
                pSys:Disable()
            end
            killedGoo = true
        end
        if not IsNull(flare) then
            flare:SetOpacity(1 - EASING.inQuad(t, 0, 1, 1))
        end
        t = t + DeltaTime() * speed
        Sleep(0)
    end
    if not IsNull(flare) then
        flare:Destroy()
    end
    --gRegion:CreateEntity(attachmentType, spark:GetSimPosition(), ZERO_ROTATION)
    Sleep(1) --To not pop out fx
    if not IsNull(spark) then
        spark:Destroy()
    end
end

function StalkerWind(wind)
    local t = 1
    local val
    while t > 0 and not IsNull(wind) do
        val = 150 * math.pow(t, 3)
        wind:SetForce(Range(val, val))
        t = t - DeltaTime() * 4
        Sleep(0)
    end
    while t < 1 and not IsNull(wind) do
        val = -24 * (t * t)
        wind:SetForce(Range(val, val))
        t = t - DeltaTime() * 0.3
        Sleep(0)
    end
    if not IsNull(wind) then
        wind:Destroy()
    end
end

function KillShield(cinematic, sword)
    if IsNull(sword) then
        return
    end
    local shieldDeco = gRegion:FindNearest(shieldType, sword:GetSimPosition(), 10)
    if not IsNull(shieldDeco) then
        shieldDeco:PlayTriggeredFade()
    end
end

function SwordToLife(cinematic, sword)
    if IsNull(sword) then
        return
    end
    local t = 0
    local flare = sword:Attach(flareType, EMPTY_SYMBOL, Vector(0, 0.21, 0))

    while t < 1 and not IsNull(sword) do
        sword:SetMaterialParam(SYM_UNLIT_ATTEN, 0.5 * math.sin(t * 3.14159)) --Wip
        sword:SetMaterialParam(SYM_EMISSIVE_MAP_ATTEN, t * 4)
        if not IsNull(flare) then
            flare:SetOpacity(t)
        end
        t = t + DeltaTime() * 0.18
        Sleep(0)
    end
    sword:SetMaterialParam(SYM_UNLIT_ATTEN, 0)
end

function ResetGlitch(cinematic)
    if not IsNull(postProcessMaterial) then
        postProcessMaterial:SetParam(Symbol("GlitchWeight"), GLITCH_WEIGHT)
    end
end

function GlitchCooldown(cinematic)
    local t = 1
    while not IsNull(postProcessMaterial) and t > 0 do
        postProcessMaterial:SetParam(Symbol("GlitchWeight"), t * GLITCH_WEIGHT)
        t = t - DeltaTime() * glitchSpeed
        Sleep(0)
    end
    if not IsNull(postProcessMaterial) then
        postProcessMaterial:SetParam(Symbol("GlitchWeight"), 0)
    end
end

function SentientSwordBeamToStalker(beam)
    local stalker
    local Stalkers = gRegion:FindAnimationNamed(StalkerTag)
    if not IsNull(Stalkers) then
        stalker = Stalkers[1]
    end
    if not IsNull(stalker) then
        beam:SetEndPointEntity(stalker, attachBone)
        stalker:Attach(typeToAttach, attachBone)
    end
end

function ApostasyLotusLongHair(cin)
    local deco = gRegion:FindFirstTagged(Symbol("LotusLongHair"))
    if not IsNull(deco) then
        deco:SetDissolve(0)
    end
end
