-- Scale
DoScale = true
ScTimeLength = 1
ScBegin = Vector(1,1,1)
ScEnd = Vector(1,0.5,0.5)
-- Fade
DoFade = true
FadeDelay = 4
FadeTimeLength = 0.4
FadeStartValue = 5
FadeEndValue = 0
--

function ScaleAndFade(deco)
    if DoScale == true then
        deco:ScriptRunChildScript(Symbol("vtxScaling"), false)
    end
    if DoFade == true then
        deco:ScriptRunChildScript(Symbol("easeOutFade"), false)
    end
end
    
-- exponential easing out - decelerating to zero velocity
local function easeOutExpo(t, b, c, d)
    if (t==d) then
        return b+c
    else
        return c * (-math.pow(2, -10 * t/d) + 1) + b
    end
end

function vtxScaling(deco)
    Sleep(0)
    local t = 0
    local val = Vector(ScBegin.x,ScBegin.y,ScBegin.z)
    while t < ScTimeLength do
        val = easeOutExpo(t, ScBegin, ScEnd - ScBegin, ScTimeLength)
        deco:SetMaterialParam(Lotus_Game.V_SCALES, val.x, val.y, val.z)
        t = t + DeltaTime()
        Sleep(0)
    end
end

function easeOutFade(deco)
    Sleep(0)
    deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, FadeStartValue)
    Sleep(FadeDelay)
    local t = 0
    local val
    while t < FadeTimeLength do
        val = easeOutExpo(t, FadeStartValue, FadeEndValue - FadeStartValue, FadeTimeLength)
        deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, val)
        t = t + DeltaTime() 
        Sleep(0)
    end
end
