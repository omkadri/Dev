tankHeight = 3.3
puddleRaiseHeight = 2
lerpDuration = 3
fluidDeco = Instance()
fogDecoType = Type("/Lotus/Fx/Levels/GasCity/Remastered/LabTestTubeFluidFogDeco")
puddleDecoType = Type("/Lotus/Fx/Levels/GasCity/Remastered/LabTestTubeFluidPuddleLargeDeco")
fluidFxType = Type("/Lotus/Fx/Levels/GasCity/Remastered/LabTestTubeMediumBurst")
glassDeco = Instance()
effectsToDisable = {Instance()}
delay = 0

local startPosFx = Vector()
local startPosDeco = Vector()
local startPosPuddleDeco = Vector()

function DrainTheTank(trigger) 
    Sleep(delay)
    --// GET CHILDREN
    
    local fluidFx = fluidDeco:GetAttachment(fluidFxType)
    
    local fogDeco = fluidDeco:GetAttachment(fogDecoType)

    local puddleDeco = fluidDeco:GetAttachment(puddleDecoType)

    
    --// ENABLE AND DETTACH FLUID PARTICLE FX
    
    if not IsNull(fluidFx) then
        fluidFx:Unattach()
        fluidFx:Enable()
    end
    
    if not IsNull(glassDeco) then
        glassDeco:Destroy()
    end
    
    --// DETTACH PUDDLE DECO
    
    if not IsNull(puddleDeco) then
        puddleDeco:Unattach()
    end
    
    if not IsNull(effectsToDisable) then
        for i = 1, #effectsToDisable do
            if not IsNull(effectsToDisable[i]) then
                 effectsToDisable[i]:Destroy()
            end
        end
    end
    
    --// SET MATERIAL PANS DOWN
    fluidDeco:SetMaterialParam(Symbol("Pan"),0,-0.2,0)
    
    if not IsNull(fluidFx) then
        fogDeco:SetMaterialParam(Symbol("Pan"),0,-0.2,0)
    end
    
    
    --// LERP FLUID DECO LEVEL
    
    if not IsNull(fluidDeco) then
        startPosDeco = fluidDeco:GetPosition()
    end
    
    local offsetPosDeco = Vector(0, (tankHeight * -1), 0)
    
    if not IsNull(fluidFx) then
        startPosFx = fluidFx:GetPosition()
    end
    
    local offsetPosFx = Vector(0, (tankHeight * -0.5), 0)
    
    if not IsNull(puddleDeco) then
        startPosPuddleDeco = puddleDeco:GetPosition()
    end
    
    local offsetPosPuddleDeco = Vector(0, puddleRaiseHeight, 0)
    
    if not IsNull(puddleDeco) and not puddleDeco:IsVisible() then
        puddleDeco:SetVisibility(true)
    end
    
    local t = 0
    while t < lerpDuration do
    
        local newPosDeco = startPosDeco + (offsetPosDeco * SmoothStep(t / lerpDuration)) --Lerp(startPosDeco, endPosDeco, SmoothStep(t))   
        local newPosFx = startPosFx + (offsetPosFx * SmoothStep(t / lerpDuration))
        local newPosPuddleDeco = startPosPuddleDeco + (offsetPosPuddleDeco * SmoothStep(t / lerpDuration))
        
        if not IsNull(fluidDeco) then
            fluidDeco:SetPosition(newPosDeco)
        end
        
        if not IsNull(fluidFx) then
            fluidFx:SetPosition(newPosFx)
        end
        
        if not IsNull(puddleDeco) then
            puddleDeco:SetPosition(newPosPuddleDeco)
        end
        
        t = t + DeltaTime()
        Sleep(0)
        
    end
    
    fluidDeco:SetVisibility(false)
    
end
