useRoot = false
materialFade = false
shipAvatar = WeakResource("/Lotus/Types/Player/TennoShipAvatar")
dissolveChildren = false
fadeChildren = false
local fadeSpeed = 4

function SheathWeapon(weaponAttachment)
    if useRoot then --For dual weapons
        weaponAttachment = weaponAttachment:GetAttachRoot()
    end
    if materialFade then
        weaponAttachment:ScriptRunChildScript(Symbol("FadeDown"), false)
    end
end

function UnsheathWeapon(weaponAttachment)
    if useRoot then --For dual weapons
        weaponAttachment = weaponAttachment:GetAttachRoot()
    end
    if materialFade then
        weaponAttachment:ScriptRunChildScript(Symbol("FadeUp"), false)
    end
end

local function _Fade(weapon, a, b)
    if _T[weapon:GetFullName()] == nil then
        _T[weapon:GetFullName()] = 0
    end
    
    _T[weapon:GetFullName()] = _T[weapon:GetFullName()] + 1
    
    local lock = _T[weapon:GetFullName()]

    local allDecos = weapon:GetAllAttachments(gDecorationType)
    if dissolveChildren then
        for i=1, #allDecos do
            if not IsNull(allDecos[i]) then
                allDecos[i]:SetDissolve(1 - b)
            end
        end
    end
    
    local newDissolve = 1 - b
    if b > 0 then
        newDissolve = 1 - b
    end
    
    local t = 0
    while t < 1 do
        if _T[weapon:GetFullName()] ~= lock then
            return
        end
        weapon:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, Lerp(a, b, t))
        if fadeChildren then
            for i=1, #allDecos do
                if not IsNull(allDecos[i]) then
                    allDecos[i]:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, Lerp(a, b, t))
                end
            end
        end
        t = t + DeltaTime() * fadeSpeed * 0.5
        Sleep(0)
    end

    weapon:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, b)
    if fadeChildren then
        for i=1, #allDecos do
            if not IsNull(allDecos[i]) then
                allDecos[i]:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, b)
            end
        end
    end
    _T[weapon:GetFullName()] = nil
end

function FadeDown(weapon)
    local current = weapon:GetMaterialParam(Lotus_Game.UNLIT_ATTEN, 1)
    if current == 0 then
        return
    end
    
    _Fade(weapon, current, 0)
end

function FadeUp(weaponAttachment)
    local avatar = weaponAttachment:GetAttachRoot()
    if not IsNull(avatar) and avatar:IsA(gBaseAvatarType) and not avatar:IsA(shipAvatar) then
        local mainHandWeapon = avatar:InventoryControl():GetWeaponInHand(Engine.MAIN_HAND)
        local weapon = weaponAttachment:GetWeapon()
        if (not avatar:InventoryControl():IsMeleeing() and weapon ~= mainHandWeapon) then --So these fx don't up with casting a power, only if exiting Ready to melee
            return
        end
    end
    local current = weaponAttachment:GetMaterialParam(Lotus_Game.UNLIT_ATTEN, 1)
    if current == 1 then
        return
    end
    
    _Fade(weaponAttachment, current, 1)
end
