coreSpawnPoint = Instance()
lightArray = {Instance()}
startColor = Color()
endColor = Color()

function Start()

    local avatar = coreSpawnPoint:GetActiveAvatar()
    
    --Ensure avatar exists
    while IsNull(avatar) do
        avatar = coreSpawnPoint:GetActiveAvatar()
        Sleep(0)
    end
    
    --While avatar exists
    while IsNull(avatar) == false do
        local health = avatar:GetHealthPercentage()
        local col = startColor:Lerp(endColor, 1 - health)
        local red = col.red / 255
        local green = col.green / 255
        local blue = col.blue / 255
        
        avatar:SetMaterialParam(Lotus_Game.TINT_COLOR, col.red/255, col.green/255, col.blue/255, 1)
        
        for i = 1, #lightArray do
            lightArray[i]:SetColor(col)
        end
        
        Sleep(0)
    end

end