zoneAttr = Instance()
damageTrig = Instance()
debugPlz = false
enabledFogColor = Color(81,19,13,125)
enabledFogDensity = 1
fogOverride = true


function ChangeFog(trigger, avatar)
    Sleep(0)
    local zone = zoneAttr:GetZone()
    local initFogCol
    local initFogDen
    
    if not IsNull(zone) then
        initFogCol = zone:GetFogColor()
        initFogDen = zone:GetDistanceFogDensity()
        if debugPlz then
            print(initFogCol.red .. ", " .. initFogCol.green .. ", " .. initFogCol.blue .. ", " .. initFogCol.alpha)
        end
        local isFogOverridden = false
        
        while trigger:IsTouching(avatar) do
            Sleep(0)
            if not isFogOverridden and damageTrig:IsEnabled() then
                zone:SetOverrideLevelFog(true)
                zone:SetFogColor(enabledFogColor)
                zone:SetDistanceFogDensity(enabledFogDensity)
                isFogOverridden = true
            elseif isFogOverridden and not damageTrig:IsEnabled() then
                zone:SetOverrideLevelFog(false)
                zone:SetFogColor(initFogCol)
                zone:SetDistanceFogDensity(initFogDen)
                isFogOverridden = false
            end
        end
        -- Exited Trigger
        zone:SetOverrideLevelFog(false)
        zone:SetFogColor(initFogCol)
        zone:SetDistanceFogDensity(initFogDen)
    end
end

function ChangeFogSimple(trigger, avatar)
    Sleep(0)
    local zone = zoneAttr:GetZone()
    local initFogCol, initFogDen
    
    if not IsNull(zone) then
        initFogCol = zone:GetFogColor()
        initFogDen = zone:GetDistanceFogDensity()
        
        if debugPlz then
            print(initFogCol.red .. ", " .. initFogCol.green .. ", " .. initFogCol.blue .. ", " .. initFogCol.alpha)
        end
        local isFogOverridden = false
        
        while trigger:IsTouching(avatar) do
            Sleep(0)
            if not isFogOverridden then
                zone:SetOverrideLevelFog(true)
                zone:SetFogColor(enabledFogColor)
                zone:SetDistanceFogDensity(enabledFogDensity)
                isFogOverridden = true               
            elseif isFogOverridden then
                zone:SetOverrideLevelFog(fogOverride)
                zone:SetFogColor(initFogCol)
                zone:SetDistanceFogDensity(initFogDen)
                isFogOverridden = false
            end
        end
        -- Exited Trigger
        zone:SetOverrideLevelFog(false)
        zone:SetFogColor(initFogCol)
        zone:SetDistanceFogDensity(initFogDen)
    end
end
