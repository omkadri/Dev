morphAName = Symbol()
morphBName = Symbol()
morphCName = Symbol()
TimeLength = 1

-- Morphs.morphA

function SetParentMorphA(entity)
    Sleep(0.0)
    local deco = entity:GetAttachParent()
    local t = 0
    local mAmount = 0
    if not IsNull(deco) then
        deco:SetMorphValue(morphAName, 0)
        deco:SetMorphValue(morphBName, 0)
        deco:SetMorphValue(morphCName, 0)
        while t < TimeLength do
            mAmount = math.min(t/TimeLength, 1)
            deco:SetMorphValue(morphAName, mAmount)
            t = t + DeltaTime()
            Sleep(0.0)
        end
        deco:SetMorphValue(morphAName, 1)
    end
    entity:Destroy()
end

function SetParentMorphAToB(entity)
    Sleep(0.0)
    local deco = entity:GetAttachParent()
    local t = 0
    local mAmount = 0
    if not IsNull(deco) then
        while t < TimeLength do
            mAmount = math.min(t/TimeLength, 1)
            deco:SetMorphValue(morphBName, mAmount)
            deco:SetMorphValue(morphAName, 1 - mAmount)
            t = t + DeltaTime()
            Sleep(0.0)
        end
        deco:SetMorphValue(morphAName, 0)
        deco:SetMorphValue(morphBName, 1)
    end
    entity:Destroy()
end

function SetParentMorphBToC(entity)
    Sleep(0.0)
    local deco = entity:GetAttachParent()
    local t = 0
    local mAmount = 0
    if not IsNull(deco) then
        while t < TimeLength do
            mAmount = math.min(t/TimeLength, 1)
            deco:SetMorphValue(morphCName, mAmount)
            deco:SetMorphValue(morphBName, 1 - mAmount)
            t = t + DeltaTime()
            Sleep(0.0)
        end
        deco:SetMorphValue(morphBName, 0)
        deco:SetMorphValue(morphCName, 1)
    end
    entity:Destroy()
end
