pFX = {Type()}
burntBodyMat = Resource()
leadUpFxToKill = {WeakResource()}
speed = 1
useCreator = false

   
local ragdollType = Type("/EE/Types/Physics/Ragdoll")
local effectTag = Symbol("EffectsDeco")

function EnemyDeathByFire(spawner)
    Sleep(0)
    if IsNull(spawner) then
        return
    end
    local avatar = nil
    if useCreator then
        avatar = spawner:GetCreator()
    else
        avatar = spawner:GetAttachRoot()
    end
    local attempts = 8
    local spawnerType = WeakResource("/EE/Types/Effects/Spawner")

    while (IsNull(avatar) or avatar:IsA(spawnerType)) and attempts > 0 do
        if useCreator then
            avatar = spawner:GetCreator()
        else
            avatar = spawner:GetAttachRoot()
        end
        attempts = attempts - 1
        Sleep(0)
    end
    local entity = avatar
    if IsNull(entity) then
        return
    end

    if entity:IsA(ragdollType) then
        avatar = entity:GetAvatarOwner()
    end
    
    local attachBone = Symbol("GAME_C1_HIP1")
    if IsNull(avatar) or not avatar:IsA(gBaseAvatarType) then
        return
    end
    
    attachBone = avatar:DamageControl():GetProxyBoneForPart(Engine.TORSO)
    for i=1, #pFX do
        local effect = entity:Attach(pFX[i], attachBone)
    end
    
    local killed = false
    local haveRagdoll = false
    local ragdoll = nil
    local timeLength = 6
    entity:SetOverrideMaterialForAllSections(burntBodyMat, false)
    local children = entity:GetAllAttachments(gDecorationType)
    for i=1, #children do
        local temp = children[i]
        if temp:GetTag() ~= effectTag then
            temp:SetOverrideMaterialForAllSections(burntBodyMat, false)
        end
    end
    local t = 0
    
    while t < timeLength do
        if not IsNull(avatar) then
            if (avatar:GetHealth() <= 0 and not killed) then
                killed = true
            end
        end
        if killed and not haveRagdoll and not IsNull(avatar) then
            ragdoll = avatar:GetRagdoll()
            if not IsNull(ragdoll) then
                haveRagdoll = true
                entity = ragdoll
                entity:SetOverrideMaterialForAllSections(burntBodyMat, false)
                local children = entity:GetAllAttachments(gDecorationType)
                for i=1, #children do
                    local temp = children[i]
                    if temp:GetTag() ~= effectTag then
                        temp:SetOverrideMaterialForAllSections(burntBodyMat, false)
                    end
                end
                for i=1, #leadUpFxToKill do
                    local temp = entity:GetAttachment(leadUpFxToKill[i])
                    if not IsNull(temp) then
                        temp:Destroy()
                    end
                end
            end
        end
        if not IsNull(entity) then
            entity:SetDissolve(math.pow(t / timeLength, 3))
        end
        t = t + DeltaTime() * speed
        Sleep(0)
    end
    
    if IsNull(avatar) then
        return
    end
    local numRagdolls = avatar:GetNumRagdolls()
    if numRagdolls > 0 then
        for i = 0, numRagdolls - 1 do
            local rag = avatar:GetRagdollByIndex(i)
            rag:Destroy()
        end
    else
        --Need this check in PvP to ensure that we don't destroy player avatars (is this necessary in PvE anyways?)
        local npcAgent = avatar:GetAgent()
        local player = avatar:GetPlayer()
            
        if IsNull(npcAgent) then
            return
        end
            
        if not IsNull(player) then
            return
        end
            
        if avatar:IsA(gTennoAvatarType) then
            return
        end
            
        if not IsNull(avatar) then
            avatar:Destroy()
        end
    end
end
