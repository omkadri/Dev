timeScale = {0.15,0.08,0.15,0.2,0.4,1.0}
deltaSpeed = 0.33
spinDeco = Type()
flameDeco = Type()
plantDecos = { Type() }

local sCinDeltaAtten = Symbol("CinematicAtten")
local sUnlitAtten = Symbol("UnlitAtten")
local sShaderTime = Symbol("ShaderTime")

local sMorphs = { Symbol("Object2"), Symbol("Object3"), Symbol("Object4"), Symbol("Object5"), Symbol("Morphs.Object6") }

local sRefractionTintColor = Symbol("RefractionTintColor")

local function piecewise(x, points)
    local NUM_POINTS = #points
    local SEGMENT_LEN = 1.0 / (NUM_POINTS - 1)
    local SEGMENT_NORMALIZE = 1.0 / SEGMENT_LEN
    local count = 1
    while count < NUM_POINTS do
        if x < SEGMENT_LEN * count then
            return(Lerp(points[count], points[count + 1], (x-SEGMENT_LEN * (count - 1))*SEGMENT_NORMALIZE))
        end
        count = count + 1
    end
    return (points[NUM_POINTS])
end

function SlowTime(cinematic)
    local allCloth = gRegion:FindAll(gSkeletalClothExType)
    local t = 0
    while t < 1 do
        local val = piecewise(t, timeScale)
        for i=1, #allCloth do
            allCloth[i]:AddDeltaAttenuation(sCinDeltaAtten, piecewise(t, timeScale))
        end
        
        local allParticles = gRegion:FindAll(gParticleSysType) --Each frame as new ones are constantly being made
        for i=1, #allParticles do
            allParticles[i]:AddDeltaAttenuation(sCinDeltaAtten, piecewise(t, timeScale))
        end
        
        if not IsNull(_T.CinematicDelta) then
            _T.CinematicDelta = val
        end
    
        Sleep(0)
        t = t + DeltaTime() * deltaSpeed
    end
end

function ShieldAtten(shieldDeco)
    Sleep(1)
    
    if IsNull(_T.CinematicDelta) then
        _T.CinematicDelta = 1
    end
    local trail = gRegion:FindFirstTagged(Symbol("SilvaWeaponTrail"))
    local flames = gRegion:FindTagged(Symbol("PrimeSilvaFlames"))
    local atten = 0
    local shaderTime = 0
    while not IsNull(shieldDeco) and not IsNull(trail) do
        if trail:IsActive() then
            atten = math.min(1, atten + DeltaTime() * 8)
        else
            atten = math.max(0, atten - DeltaTime() * 0.88)
        end
        shieldDeco:SetMaterialParam(sUnlitAtten, atten)
        shieldDeco:SetMaterialParam(sShaderTime, shaderTime)
        for i=1, #flames do
            flames[i]:SetMaterialParam(sUnlitAtten, atten)
            flames[i]:SetMaterialParam(sShaderTime, shaderTime)
        end
        if not IsNull(_T.CinematicDelta) then
            shaderTime = shaderTime + _T.CinematicDelta * DeltaTime()
        else
            shaderTime = shaderTime + DeltaTime()
        end
        Sleep(0)
    end
end

function LauncherAtten(oberonDeco)
    Sleep(0.5)
    
    
    local decos = oberonDeco:GetAllAttachments(gDecorationType)
    for i=1, #decos do
        decos[i]:SetMaterialParam(sUnlitAtten, 1)
    end
    
    local attachments = oberonDeco:GetAllAttachments(gLotusWeaponAttachmentType)
    for i=1, #attachments do
        attachments[i]:SetMaterialParam(sUnlitAtten, 1)
    end
    
    local spinner = oberonDeco:GetAttachment(spinDeco)
    local flames = oberonDeco:GetAttachment(flameDeco)
    local amount = 0
    while true do
        if not IsNull(spinner) then
            spinner:SetAttachLocalSpace(ZERO_VECTOR, Rotation(amount * 180, 0, 0))
        end
        if not IsNull(flames) then
            flames:SetAttachLocalSpace(ZERO_VECTOR, Rotation(amount * 180, 0, 0))
        end
        Sleep(0)
        amount = amount + DeltaTime()
    end
end

function GooBall(deco)
    local t = 0
    while true do
        local val = t % 1
        deco:SetMorphValue(sMorphs[5], val)
        Sleep(0)
        t = t + DeltaTime()
    end
end

function HallowedCast(deco)
    local t = 0
    local timeLength = 1
    local endPos = Vector(24, -5.2, 40)
    local startPos = Vector(18.8, -5.2, 24)
    local newPos = Vector()
    while t < 1 do
        newPos = LerpVector(startPos, endPos, t)
        gRegion:CreateEntity(plantDecos[math.random(1, #plantDecos)], Vector(newPos.x + Random(-2, 2), newPos.y - 0.3, newPos.z + Random(-2, 2)), Rotation(math.random(-180, 180), 0, 0))
        Sleep(0)
        t = t + DeltaTime() / timeLength
    end
end

function MoveDeco(deco)
    local pos = deco:GetSimPosition()
    local t = 0
    while t < 1 do
        local upY = 0.3 * SmoothStep(t)
        deco:SetPosition(Vector(pos.x, pos.y + upY, pos.z))
        Sleep(0)
        t = t + DeltaTime() * 3
    end
    
    while t > 0 do
        local upY = 0.6 * SmoothStep(t)
        deco:SetPosition(Vector(pos.x, pos.y + upY - 0.3, pos.z))
        Sleep(0)
        t = t - DeltaTime() * 0.33
    end
end

function HallowedWater()
    local water = gRegion:FindFirstTagged(Symbol("WaterPlane"))
    local t = 0
    while t < 1 and not IsNull(water) do
        water:SetMaterialParam(sRefractionTintColor, 1 * t, 0.34 * t, 0.069 * t, 1)
        Sleep(0)
        t = t + DeltaTime() * 4
    end
    t = 1
    while t > 0 and not IsNull(water) do
        water:SetMaterialParam(sRefractionTintColor, 1 * t, 0.34 * t, 0.069 * t, 1)
        Sleep(0)
        t = t - DeltaTime() * 0.2
    end
    water:SetMaterialParam(sRefractionTintColor, 0, 0, 0, 1)
end

function WaterSplashPoints(deco)
    Sleep(2)
    local triggerType = Type("/EE/Types/Engine/WaterSimTrigger")
    local pos = deco:GetSimPosition()
    local trigger = gRegion:FindNearest(triggerType, pos, 50)
    local oberonDeco = gRegion:FindFirstTagged(Symbol("OberonDeco"))
    
    local bones = { Symbol("GAME_L1_LEG4"), Symbol("GAME_R1_LEG4") }
    local waterHeight = -5.18
    local index = 1
    local pos = Vector()
    while not IsNull(trigger) and not IsNull(oberonDeco) do
        pos = oberonDeco:GetBonePosition(bones[1 + index % 2], false)
        if pos.y < waterHeight then
            trigger:InsertSplashPoint(pos + Vector(Random(-0.15, 0.15), 0, Random(-0.15, 0.15)))
        end
        Sleep(0.25)
        index = index + 1
    end   
end