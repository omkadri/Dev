sparkResource = WeakResource("/Lotus/Types/Enemies/Sentients/Sparks/SparkDeco")
particleTypes = { Type() }
defaultColor = Color()
resistanceColors = { Color() }
resistanceIcons = { WeakResource() }
iconParticleSys = Type()
iconParticleTrail = Type()
burstEffectType = Type()
reactionAnim = Resource()

local sUnlitAtten = Symbol("UnlitAtten")

local COLOR_UTIL = require "Lotus.Scripts.Effects.EffectsColorUtilities"

--[[
DT_IMPACT,
DT_PUNCTURE,
DT_SLASH,

DT_FIRE,
DT_FREEZE,
DT_ELECTRICITY,
DT_POISON,

DT_EXPLOSION, // HEAT + COLD
DT_RADIATION, // HEAT + ELECTRICAL
DT_GAS, // HEAT + TOXIC
DT_MAGNETIC, // COLD + ELECTRICAL
DT_VIRAL, // COLD + TOXIC
DT_CORROSIVE, // ELECTRICAL + TOXIC
]]--

local canRequestAnim = Symbol("CanRequestAnimation")

local function SetEnergyColor(avatar, newEnergyColor)
    local suit = avatar:InventoryControl():GetActivePowerSuit()
    if IsNull(suit) then
        return
    end
    local playerCustomization = suit:GetCustomization()
    local colors = playerCustomization:GetColors(Lotus_Game.PrimaryColors)
    colors:SetColor(4, newEnergyColor)
    colors:SetInitialized(4, true)
    playerCustomization:SetColors(Lotus_Game.PrimaryColors, colors)
    suit:SetCustomization(playerCustomization) 
end

function OnResistanceChanged(damageController, addedResistances)
    local avatar = damageController:GetAvatar()

    if IsNull(avatar) then
        return
    end

    -- determine which new damage resistances were added
    local damageInts = {}
    local val = 1
    while addedResistances > 0 do
        local r = addedResistances % 2

        if r == 1 then
            table.insert(damageInts, val)
        end

        val = val + 1
        addedResistances = addedResistances / 2
    end

    local newColor = defaultColor
    -- pick one of the new damage resistances as the new color for the sentient
    for i = 1, #damageInts do
        local damageInt = damageInts[i]
        if damageInt > 0 and not IsNull(resistanceColors[damageInt]) then
            newColor = resistanceColors[damageInt]
            break
        end
    end

    if IsNull(newColor) then
        return
    end

    local spark = nil
    local children = avatar:GetAutoSimChildrenArray()
    if not IsNull(children) then
        for i=1,#children do
            if children[i].mType:IsA(sparkResource) then
                spark = children[i].mInstance
                break
            end
        end
    end

    if IsNull(spark) then
        return
    end

    for i=1, #particleTypes do
        local pSys = spark:GetAttachment(particleTypes[i])
        if not IsNull(pSys) then
            pSys:SetColorMinMax(newColor, newColor)
            COLOR_UTIL.ApplyHighLow(pSys, newColor)
        end
    end
    local flare = spark:GetAttachment(gLensFlareType)
    if not IsNull(flare) then
        flare:SetTint(newColor)
    end
    
    gRegion:CreateEntity(burstEffectType, spark:GetSimPosition(), ZERO_ROTATION, avatar)
    
    if
        #damageInts > 0 and 
        not IsNull(reactionAnim) and 
        not avatar:IsPlayingAnimation(reactionAnim) and
        avatar:IsPlayingAction(canRequestAnim)
    then
        avatar:PlayAnimation(reactionAnim, false, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_ONCE, true)
    end
    
    for i = 1, #damageInts do
        local damageInt = damageInts[i]
        if damageInt > 0 then
            local iconEffect = avatar:Attach(iconParticleSys, EMPTY_SYMBOL, Vector(0.0, 1.8, 1.0), ZERO_ROTATION, avatar)
            local trail = nil
            if not IsNull(iconEffect) and not IsNull(resistanceIcons[damageInt]) then
                trail = iconEffect:Attach(iconParticleTrail, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, avatar)
                iconEffect:SetMaterial(Resource(resistanceIcons[damageInt]))
            end
        end
    end
end

function ImmunityIcon(iconEffect)
    local t = 0
    local speed = 28
    local atten = 1

    local trail = iconEffect:GetAttachment(iconParticleTrail)
    
    while t < 1 do
        atten = 1.2 - math.abs(0.5 - t) * 2
        iconEffect:SetAttachLocalSpace(Vector(atten * math.sin(t * speed), 2.5 + (-0.6 + t) * 2.0, atten * math.cos(t * speed)), ZERO_ROTATION)
        iconEffect:SetMaterialParam(sUnlitAtten, math.min(1.0, 2 - 2 * t))
        if not IsNull(trail) then
            trail:SetMaterialParam(sUnlitAtten, math.min(1.0, 2 - 2 * t))
        end
        t = t + DeltaTime() * 0.45
        Sleep(0)
    end

    iconEffect:Destroy()
end
