function InteriorStunCheck(scriptEntity)
    Sleep(0.5)
    local crewShipMgr = gGameRules:GetCrewShipManager()
    if IsNull(crewShipMgr) then
        return
    end
    local ship = crewShipMgr:GetShipForZone(scriptEntity:GetZone())
    local isStunned
    
    local fxEntities = {}
    fxEntities = gRegion:FindTagged(Symbol("EMPStunnedInteriorFX"))
    
    while not IsNull(ship) do
        local unused, damagedTotal, total = ship:GetModCapacity()
        isStunned = (damagedTotal == 0)
        if isStunned then
            for i=1, #fxEntities do
                if not IsNull(fxEntities[i]) then
                    fxEntities[i]:SetVisibility(true)
                end
            end                
        else
            for i=1, #fxEntities do
                if not IsNull(fxEntities[i]) then
                    fxEntities[i]:SetVisibility(false)
                end
            end
        end
        
        Sleep(0.1)
        
    end
    
end