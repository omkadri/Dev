OriginalValue = 0 
NewValue = 1
TimeLength = 1
Param = Symbol()
Delay = 0

function RailingBurnAway(spawner)
    Sleep(Delay)
    local t = 0
    local val
    local deco = spawner:GetAttachParent()
    if not IsNull(deco) then
        while t < TimeLength do
            val = Lerp(OriginalValue, NewValue, t/TimeLength)
            deco:SetMaterialParam(Param, val)
            t = t + DeltaTime() 
            Sleep(0)
        end
        deco:SetMaterialParam(Param, NewValue)
    end
end

function RailingTakeDamage(spawner)
    Sleep(Delay)
    local t = 0
    local val
    local deco = spawner:GetAttachParent()
    if not IsNull(deco) then
        while t < TimeLength do
            --val = Lerp(OriginalValue, NewValue, t/TimeLength)
            val = OriginalValue + (1 - t) * (math.sin(t*8)*0.5)
            deco:SetMaterialParam(Param, val)
            t = t + DeltaTime() 
            Sleep(0)
        end
        deco:SetMaterialParam(Param, OriginalValue)
    end
end
