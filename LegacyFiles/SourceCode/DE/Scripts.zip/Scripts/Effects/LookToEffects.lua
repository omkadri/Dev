locatorDeco = Type()
local bone = Symbol("GAME_C1_HEAD1")

boneA = Symbol("GAME_C1_HEAD1")
boneB = Symbol("GAME_R1_LEG1")
twistRot = Rotation()

function LookAtThisBone(entity)
    Sleep(1)
    local startPos = entity:GetLocalAttachPosition()
    local startRot = entity:GetLocalAttachRotation()
    local avatar = entity:GetAttachRoot()
    if IsNull(avatar) then
        return
    end
    
    local WeaponAttachBone = entity:GetAttachBone()
    local locator = avatar:Attach(locatorDeco, WeaponAttachBone, startPos, startRot)
    
    entity:Unattach()
    
    while not IsNull(entity) do
        local newRot = LookTo(entity:GetSimPosition(), avatar:GetBonePosition(bone))
        
        newRot = LookTo(Vector(), avatar:GetBonePosition(boneB) - avatar:GetBonePosition(boneA))
        --newRot = LookTo(ZERO_VECTOR, avatar:GetBonePosition(Symbol("GAME_R1_LEG1")) - avatar:GetBonePosition(Symbol("GAME_L1_ARM1")))
        
        local newPos = locator:GetSimPosition()
        --Normalize(newPos)
        
        newRot.heading = newRot.heading + twistRot.heading
        newRot.pitch = newRot.pitch + twistRot.pitch
        --newRot.bank = newRot.bank + 90
        newRot.bank = startRot.bank + twistRot.bank
        --newRot.heading = startRot.heading
        --entity:SetRotation(newRot)
        
        entity:SetPosition(newPos)
        entity:SetRotation(newRot)
        Sleep(0)
    end
end

function ShoulderLookAt(entity)
    Sleep(1)
    local avatar = entity:GetAttachRoot()
    if IsNull(avatar) then
        return
    end
    
    local WeaponAttachBone = entity:GetAttachBone()
    local locator = avatar:Attach(locatorDeco, WeaponAttachBone)

    while not IsNull(entity) do
        local decoRot = locator:GetSimRotation()

        local toRot = LookTo(entity:GetSimPosition(), avatar:GetBonePosition(boneB))

        --100% fudged for this one decoration, would need a proper transform
        local newRot = Rotation(Lerp(-toRot.pitch, 0, 0.8), decoRot.heading - toRot.heading, 0)
        print(newRot)
        entity:SetAttachLocalSpace(ZERO_VECTOR, newRot)
        Sleep(0)
    end
end