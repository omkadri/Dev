cloneMuzzleEffect = Type()
cloneGunTag = Symbol("CloneAkbolto")
projectileType = Type()
prismAttach = Type()
laserType = WeakResource()
laserDeco = Type()
energyColor = Color()
energyColorHi = Color()
isHydroid = false

local COLOR_UTIL = require "Lotus.Scripts.Effects.EffectsColorUtilities"

local sEmissiveTintColorHi = Symbol("EmissiveTintColorHi")
local sEmissiveTintColorLo = Symbol("EmissiveTintColorLo")

local function DarkitectEnabled()
    local player = gRegion:GetLocalPlayerAvatar()
    if IsNull(player) then
        return true
    end
    return false
end

function MuzzleFlash(spawner)
    if DarkitectEnabled() then
        return
    end
    local cloneGuns = gRegion:FindTagged(cloneGunTag)
    for i=1, #cloneGuns do
        cloneGuns[i]:Attach(cloneMuzzleEffect, EMPTY_SYMBOL)
    end
end

function FireAtGrineer(spawner)
    if DarkitectEnabled() then
        return
    end
    local cinematic = gRegion:GetPlayingCinematic()
    if IsNull(cinematic) then
        return
    end
    local grineerSym = Symbol("MarineGroupA")
    if cinematic:GetAnimDelta() > 0.56 then
        grineerSym = Symbol("MarineGroupB")
    end
    if isHydroid then
        grineerSym = Symbol("MarineShotA")
        if cinematic:GetAnimDelta() > 0.38 then
            grineerSym = Symbol("MarineShotB")
        end
    end
    local marines = gRegion:FindTagged(grineerSym)
    if #marines < 1 then
        return
    end
    local randomInt = math.random(1, #marines)
    local marine = marines[randomInt]
    if IsNull(marine) then
        return
    end
    local endPos = marine:GetBonePosition(Symbol("GAME_C1_SPINE3"), false)
    if not isHydroid then
        local allProxies = marine:GetAllAttachments(gHitProxyType)
        local proxy = allProxies[math.random(1, #allProxies)]
        if IsNull(proxy) then
            return
        end
        endPos = proxy:GetPosition()
    end
    local spawnPos = spawner:GetPosition()
    gRegion:CreateEntity(projectileType, spawnPos, LookTo(spawnPos, endPos))
    spawner:Destroy()
end

function PrismBall(deco)
    if DarkitectEnabled() then
        return
    end
    local avatar = gRegion:FindFirstTagged(Symbol("MirageDeco"))
    if IsNull(avatar) then
        return
    end
    local cinematic = gRegion:GetPlayingCinematic()
    if IsNull(cinematic) then
        return
    end
    local leftPos = Vector()
    local rightPos = Vector()
    local leftBone = Symbol("GAME_L1_WEAPON1")
    local rightBone = Symbol("GAME_R1_WEAPON1")
    local newPos = Vector()
    local tossDelta = 0.81944
    while cinematic:GetAnimDelta() < tossDelta do
        leftPos = avatar:GetBonePosition(leftBone)
        rightPos = avatar:GetBonePosition(rightBone)
        newPos = LerpVector(leftPos, rightPos, 0.5)
        deco:SetPosition(newPos)
        Sleep(0)
    end
    deco:Attach(prismAttach, EMPTY_SYMBOL)
    local startPos = newPos
    local finalPos = Vector(-0.03, 6.7, -37.5)
    local finalDelta = 0.859722
    while cinematic:GetAnimDelta() < finalDelta do
        local d = cinematic:GetAnimDelta()
        newPos = LerpVector(startPos, finalPos, (d-tossDelta) / (finalDelta - tossDelta))
        deco:SetPosition(newPos)
        Sleep(0)
    end
    deco:Destroy()
end


function CreateLasers(spawner)
    if DarkitectEnabled() then
        return
    end
    local projectile = spawner:GetAttachParent()
    local instigatorAvatar = projectile:GetCreator()

    local attenuatedRadius = 20

    local energyColor = Color(179, 109, 196, 255)

    local lasers = {}
    local laserParents = {}

    local rot = Rotation()
    
    local numLasers = 30
    for i=1, numLasers do --Attach lasers and their shark parents
        rot.bank = math.random(-180, 180)
        rot.heading = math.random(-180, 180)
        rot.pitch = math.random(-180, 180)
        local p = projectile:Attach(laserDeco, EMPTY_SYMBOL, ZERO_VECTOR, rot)
        rot.bank = math.random(-45, 45)
        rot.heading = math.random(-45, 45)
        rot.pitch = math.random(-45, 45)
        p:SetTestRotateSpeed(rot)
        local laser = p:GetAttachment(laserType)
        if not IsNull(laser) then
            lasers[i] = laser
            laserParents[i] = p
        else
            numLasers = numLasers - 1
        end
    end
end

function TintMirage(deco)
    Sleep(1)
    deco:SetMaterialParam(sEmissiveTintColorLo, COLOR_UTIL.SRGBToLinear(energyColor.red), COLOR_UTIL.SRGBToLinear(energyColor.green), COLOR_UTIL.SRGBToLinear(energyColor.blue), 1, true)
    deco:SetMaterialParam(sEmissiveTintColorHi, COLOR_UTIL.SRGBToLinear(energyColorHi.red), COLOR_UTIL.SRGBToLinear(energyColorHi.green), COLOR_UTIL.SRGBToLinear(energyColorHi.blue), 1, true)
    local trails = deco:GetAllAttachments(gWeaponTrailType)
    for i=1, #trails do
        trails[i]:SetTint(energyColor)
    end
end