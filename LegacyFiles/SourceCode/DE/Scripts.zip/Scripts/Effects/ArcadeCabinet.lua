
openedAnimation = Resource()
cephalonInsertFX = Type()
chephalonInserFXBone = Symbol()
chepalonInsertFXOffset = Vector()
activatedFX = Type()
activatedFXBone = Symbol()
activatedFXOffset = Vector()


function Init(arcadeDeco)
    -- get the master avatar
    while IsNull(gRegion) do
        Sleep(0)
    end

    if gRegion:IsMaster() then
        arcadeDeco:Attach(cephalonInsertFX, chephalonInserFXBone, chepalonInsertFXOffset)
        arcadeDeco:Attach(activatedFX, activatedFXBone, activatedFXOffset)
        arcadeDeco:PlayAnimation(openedAnimation, false, false)
    end
end
