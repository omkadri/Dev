-- Post process
zoneAttribsOrokin = WeakResource("/Lotus/Levels/Orokin/OrokinZoneAttribs")
zoneAttribsExterior = WeakResource("/Lotus/Levels/Grineer/GrineerZoneAttribs")
colorCorrectionExterior = Resource()
colorCorrectionExteriorAlt = Resource()
colorCorrectionDerelict = Resource()
levelInfoOrokin = Resource()
levelInfoDerelict = Resource()
levelInfoExterior = Resource()
fogExteriorColor = Color()
fogExteriorDensity = 0.3
fogExteriorHtDensity = 0.2
fogExteriorHtFalloff = 1.5
fogDerelictColor = Color()
fogDerelictDensity = 0.375
fogDerelictHtDensity = 0
fogDerelictHtFalloff = 1
additionalScriptTrigger = Instance()
overrideExteriorFog = true
isForest = false
orokinSidePortal = Instance()
portalMaterialOverride = Resource()

zoneAttribsExteriors = {Resource()}
levelInfoExteriors = {Resource()}
portalMaterialOverrides = {Resource()}

-- Sound shake
shakeSound = Resource()
shakeEffect = Resource()
shakeAmp = 10

local NV_DAY_NIGHT = Symbol("DayNight")

-- Effects ----------------------------------------------------------------------------------------------------------------------------------

local function GetLocalPostProcess()
    local avatar = gRegion:GetLocalPlayerAvatar()
    
    if IsNull(avatar) then
        return
    end
    
    local cameraControl = avatar:CameraControl()
    
    if IsNull(cameraControl) and not cameraControl:IsA(WeakResource("/EE/Types/Engine/NullCameraController")) then
        return
    end
    
    return avatar:CameraControl():ScriptGetCurrentPostProcessInfo()
end

local function SetPostProcess(postProcess)
    local localPostProcess = GetLocalPostProcess()
    
    localPostProcess.bloom = postProcess.bloom
    localPostProcess.horizonRadius = postProcess.horizonRadius
    localPostProcess.horizonFog = postProcess.horizonFog
    localPostProcess.fogColor = postProcess.fogColor
    localPostProcess.distanceFogDensity = postProcess.distanceFogDensity
    localPostProcess.heightFogFalloff = postProcess.heightFogFalloff
    localPostProcess.heightFogDensity = postProcess.heightFogDensity
    localPostProcess.lightMapBoost = postProcess.lightMapBoost
    localPostProcess.lightMapTint = postProcess.lightMapTint
end

function TransitionPostProcess()

    -- Only run for matching levels
    local matchingZoneAttribs = gRegion:FindAll(zoneAttribsExterior)
    if IsNull(matchingZoneAttribs) or #matchingZoneAttribs == 0 then
        return
    end
    
    -- Set up exterior fog
    if overrideExteriorFog then
        local zones = matchingZoneAttribs --gRegion:FindAll(zoneAttribsExterior)
        if not IsNull(zones) then
            for x=1,#zones do
                local zone = zones[x]:GetZone()
                if not IsNull(zone) and not zones[x]:IsBackDrop() and zones[x]:GetZoneId():c_str() ~= "FlyIn" then
                    zone:SetFogColor(fogExteriorColor)
                    zone:SetDistanceFogDensity(fogExteriorDensity)
                    zone:SetHeightFogDensity(fogExteriorHtDensity)
                    zone:SetHeightFogFalloff(fogExteriorHtFalloff)
                end
            end
        else
            return -- No zones found for this exterior zoneattribs type
        end
    end
    
    -- Run extra script associated with this tileset
    if gRegion:IsMaster() then
        if not IsNull(additionalScriptTrigger) then
            additionalScriptTrigger:FirePort("Execute")
        end
    end
    
    -- Get post process settings
    local gameRules = gGameRules
    while IsNull(gameRules) do
        gameRules = gGameRules
        Sleep(0.1)
    end

    local baseLevelInfo = levelInfoOrokin
    local faction = gGameRules:GetMission():GetFactionTag()
    if faction == Symbol("Infestation") then
        baseLevelInfo = levelInfoDerelict
    end
    local orokinPostProcess = baseLevelInfo.postProcess
    local colorCorrection = colorCorrectionExterior
    local postProcess = levelInfoExterior.postProcess
    
    if isForest then
        -- Check if using alt post process
        local gameRules = gGameRules
        local dayNight = gameRules:GetNetPersistentVar(NV_DAY_NIGHT, 9999) --Setup in ProceduralLevel.lua
        while dayNight == 9999 do -- poll until var arrives
            Sleep(0)
            dayNight = gameRules:GetNetPersistentVar(NV_DAY_NIGHT, 9999)
        end
        
        if dayNight == 1 then
            colorCorrection = colorCorrectionExterior -- Day
            postProcess = levelInfoExterior.postProcess
        else
            colorCorrection = colorCorrectionExteriorAlt -- Night
            postProcess = levelInfoExterior.postProcessAlt
        end
    end

    if not IsNull(orokinSidePortal) then
        orokinSidePortal:SetOverrideMaterialForAllSections(portalMaterialOverride, false)
    end
    -- Apply post process settings
    local previousZone
    while true do
        local player = gRegion:GetLocalPlayerAvatar()
        if not IsNull(player) then
            local zone = player:GetZone()
            if not IsNull(zone) and not (player:IsKilled() or player:IsPreDeath()) then
                local currentZone = zone:GetAttribs()
                local cameraControl = player:CameraControl()
                
                if not IsNull(currentZone) and not IsNull(cameraControl) then
                    if not IsNull(previousZone) then
                        if currentZone:IsA(zoneAttribsOrokin) and previousZone:IsA(zoneAttribsExterior) then -- Player moved from exterior to interior
                            cameraControl:RemoveColorCorrection(colorCorrection)
                            SetPostProcess(orokinPostProcess)
                        elseif currentZone:IsA(zoneAttribsExterior) and previousZone:IsA(zoneAttribsOrokin) then -- Player moved from interior or no zone to exterior
                            cameraControl:PushColorCorrection(colorCorrection, 0, -1, 0)
                            SetPostProcess(postProcess)
                        end
                    else
                        if currentZone:IsA(zoneAttribsOrokin) then -- Player moved from exterior to interior
                            cameraControl:RemoveColorCorrection(colorCorrection)
                            SetPostProcess(orokinPostProcess)
                        elseif currentZone:IsA(zoneAttribsExterior) then -- Player moved from interior or no zone to exterior
                            cameraControl:PushColorCorrection(colorCorrection, 0, -1, 0)
                            SetPostProcess(postProcess)
                        end
                    end
                    previousZone = zone:GetAttribs()
                    
                end
            else
                previousZone = nil
            end
        else
            previousZone = nil
        end
        Sleep(0.1)
    end

end

function TransitionPostProcessExteriorToDerelict()
    
    -- Set up derelict fog
    local zones = gRegion:FindAll(zoneAttribsOrokin)
    if not IsNull(zones) then
        for x=1,#zones do
            local zone = zones[x]:GetZone()
            if not IsNull(zone) and not zones[x]:IsBackDrop() and zones[x]:GetZoneId():c_str() ~= "FlyIn" then
                zone:SetFogColor(fogDerelictColor)
                zone:SetDistanceFogDensity(fogDerelictDensity)
                zone:SetHeightFogDensity(fogDerelictHtDensity)
                zone:SetHeightFogFalloff(fogDerelictHtFalloff)
            end
        end
    else
        return -- No zones found for this zoneattribs type
    end
    
    -- Run extra script associated with this tileset
    if gRegion:IsMaster() then
        if not IsNull(additionalScriptTrigger) then
            additionalScriptTrigger:FirePort("Execute")
        end
    end
    
    -- Get post process settings
    local gameRules = gGameRules
    while IsNull(gameRules) do
        gameRules = gGameRules
        Sleep(0.1)
    end

    local derelictLevelInfo = levelInfoDerelict
    local derelictPostProcess = derelictLevelInfo.postProcess
    local derelictColorCorrection = colorCorrectionDerelict
    local exteriorId = 1
    for i = 1, #zoneAttribsExteriors do
        local zoneAttribs = gRegion:FindAll(zoneAttribsExteriors[i])
        if #zoneAttribs > 0 then
            exteriorId = i
            break
        end
    end
    local exteriorPostProcess = levelInfoExteriors[exteriorId].postProcess
    
    --[[if isForest then
        -- Check if using alt post process
        local gameRules = gGameRules
        local dayNight = gameRules:GetNetPersistentVar(NV_DAY_NIGHT, 9999) --Setup in ProceduralLevel.lua
        while dayNight == 9999 do -- poll until var arrives
            Sleep(0)
            dayNight = gameRules:GetNetPersistentVar(NV_DAY_NIGHT, 9999)
        end
        
        if dayNight == 1 then
            colorCorrection = colorCorrectionExterior -- Day
            postProcess = levelInfoExterior.postProcess
        else
            colorCorrection = colorCorrectionExteriorAlt -- Night
            postProcess = levelInfoExterior.postProcessAlt
        end
    end]]

    if not IsNull(orokinSidePortal) then
        orokinSidePortal:SetOverrideMaterialForAllSections(portalMaterialOverrides[exteriorId], false)
    end
    
    -- Apply post process settings
    local previousZone
    while true do
        local player = gRegion:GetLocalPlayerAvatar()
        if not IsNull(player) then
            local zone = player:GetZone()
            if not IsNull(zone) and not (player:IsKilled() or player:IsPreDeath()) then
                local currentZone = zone:GetAttribs()
                local cameraControl = player:CameraControl()
                
                if not IsNull(currentZone) and not IsNull(cameraControl) then
                    if not IsNull(previousZone) then
                        if currentZone:IsA(zoneAttribsOrokin) and previousZone:IsA(zoneAttribsExteriors[exteriorId]) then -- Player moved from exterior to derelict
                            cameraControl:PushColorCorrection(derelictColorCorrection, 0, -1, 0)
                            SetPostProcess(derelictPostProcess)
                        elseif currentZone:IsA(zoneAttribsExteriors[exteriorId]) and previousZone:IsA(zoneAttribsOrokin) then -- Player moved from interior or no zone to exterior
                            cameraControl:RemoveColorCorrection(derelictColorCorrection)
                            SetPostProcess(exteriorPostProcess)
                        end
                    else
                        if currentZone:IsA(zoneAttribsOrokin) then -- Player moved from exterior to derelict
                            cameraControl:PushColorCorrection(derelictColorCorrection, 0, -1, 0)
                            SetPostProcess(derelictPostProcess)
                        elseif currentZone:IsA(zoneAttribsExteriors[exteriorId]) then -- Player moved from derelict or no zone to exterior
                            cameraControl:RemoveColorCorrection(derelictColorCorrection)
                            SetPostProcess(exteriorPostProcess)
                        end
                    end
                    previousZone = zone:GetAttribs()
                    
                end
            else
                previousZone = nil
            end
        else
            previousZone = nil
        end
        Sleep(0.1)
    end

end

function SoundShake()
    local playerAvatars = gRegion:GetHumanPlayerAvatars()
    if IsNull(playerAvatars) then
        return
    end
    local player = playerAvatars[1]
    local postProcess = gRegion:GetLevelInfo().postProcess
    local soundInst

    local pos = player:GetPosition()
    soundInst = gRegion:PlaySound(shakeSound,pos,false)
    gRegion:CreateEntity(shakeEffect, pos, ZERO_ROTATION)    
    while not IsNull(soundInst) do
        local amp = soundInst:GetCurAmplitude()
        postProcess.viewShake.mShakeAmbient = amp  * shakeAmp
        Sleep(0) 
    end
    Sleep(1)
    postProcess.viewShake.mShakeAmbient = 0
end
