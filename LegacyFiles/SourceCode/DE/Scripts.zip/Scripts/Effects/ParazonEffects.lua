attachEffect = Type()
markerAddedEffect = Type()
markerSoundEffect = Resource()

function HackIdle(weaponAttachment)
    local weapon = weaponAttachment:GetWeapon()
    local effect = weaponAttachment:Attach(attachEffect, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, weapon)
    Sleep(1)
    while not IsNull(effect) and weaponAttachment:GetDrawOnTop() do
        
        Sleep(0)
    end
    if not IsNull(effect) then
        effect:Destroy()
    end
end

function PositionMarker(entity)
    -- runs on the attachment
    local target = entity:GetAttachRoot()
    if IsNull(target) or not target:IsA(gBaseAvatarType) then
        return
    end
    
    if target ~= entity:GetAttachParent() then
        entity:AttachTo(target, Symbol())
    end
    
    local entPos = target:GetPosition()
    local dmgControl = target:DamageControl()
    local bone = dmgControl:GetProxyBoneForPart(Engine.HEAD)
    local attachOffset = (math.max(target:EyePosition().y, target:GetBonePosition(bone).y) + 0.3)
    attachOffset = attachOffset - entPos.y
    entity:SetAttachLocalSpace(Vector(0, attachOffset, 0), ZERO_ROTATION)
    entity:Attach(markerAddedEffect, Symbol())
    entity:PlaySound(markerSoundEffect, false)
    local timer = 0
    
    while not IsNull(target) and not IsNull(dmgControl) do
        local timeRemaining = dmgControl:GloryKillTimeRemaining()
        local isPreDeath = dmgControl:IsPreDeath()
        if timeRemaining <= 3.0 or isPreDeath then        
            local pulseT = timeRemaining - 3.0
            if isPreDeath then
                pulseT = timer * 0.5
            end
            local p = 1.0 - math.abs(math.sin(pulseT * 2.0 * math.pi))
            -- pulse
            local minColor = Color(255,56,52,255)
            local maxColor = Color(0,0,0,0)
            local pulseColor = minColor:Lerp(maxColor, p)
            entity:SetColorMinMax(pulseColor, pulseColor)
        end
        timer = timer + DeltaTime()
        Sleep(0)
    end
end
