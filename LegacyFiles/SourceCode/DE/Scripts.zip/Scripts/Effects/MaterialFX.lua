fadeLength = 5.0
originalEmissive = 1.0
targetDeco = Instance()
newColor = Color()
param = Symbol()

function FadeEmissive(deco)
    local t = 0
    local toFade = originalEmissive
    while t < fadeLength do
        toFade = (1 - t/fadeLength)*originalEmissive
        deco:SetMaterialParam(Lotus_Game.EMISSIVE_MAP_ATTEN, toFade)
        t = t + DeltaTime()
        Sleep(0.0)
    end
end

function SwapMaterialColorTargetted()
    if not IsNull(targetDeco) then
        targetDeco:SetMaterialParam(param, newColor.red/255, newColor.green/255, newColor.blue/255, newColor.alpha/255)
    end
end
