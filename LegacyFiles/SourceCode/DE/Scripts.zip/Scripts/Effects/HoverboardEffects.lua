jetTrailType = Type()
jetFlares = Type()
localSpeedDeco = Type()
speedDecoVisThreshold = 2
speedDotsType = Type()
colorDotsMin = Color(187, 187, 187, 128)
colorDotsMax = Color(213, 212, 212, 255)
snowProj = Type()
venusGameRules = WeakResource()

local sSnowAmount = Symbol("SnowAmount")

local velocityMax = 3.0

local function RandomSign()
    if Random(1, 100) > 50 then
        return 1
    else
        return -1
    end
end

local function DestroyEffects(effects)
    for i, temp in ipairs(effects) do
        if not IsNull(temp) then
            temp:Destroy()
        end
    end
end

function InitAvatarEffects(spawner)
    local isLocal = false
    
    while not IsNull(gRegion:GetPlayingCinematic()) do
        Sleep(0)
    end
    
    local avatar = spawner:GetAttachParent()
    
    if IsNull(avatar) or not avatar:IsA(gLotusVehicleAvatarType) then
        return
    end
    
    local pilot = nil
    --For now, loop until we have a rider
    local localAvatar = gRegion:GetLocalPlayerAvatar()
    while IsNull(pilot) do
        Sleep(0)
        pilot = avatar:GetRider()
    end
    isLocal = true

    if IsNull(avatar) then
        return
    end

    if not localAvatar == pilot then
        return
    end
    Sleep(1)
    
    local trails = avatar:GetAllAttachments(jetTrailType)
    local flares = avatar:GetAllAttachments(jetFlares)

    local cam = gRegion:GetGameCamera()
    local speedLines = cam:GetAttachment(speedDotsType)
    local speedDeco = cam:GetAttachment(localSpeedDeco)
    local snow = avatar:GetAttachment(snowProj)
    if IsNull(snow) and gGameRules:IsA(venusGameRules) then
        snow = avatar:Attach(snowProj, EMPTY_SYMBOL)
    end
    local effectsAreAttached = false

    local zeroVector = Vector()
    local oldVelocity = Vector()
    local smoothVX = SmoothFloat(0, 0.4)
    local smoothVY = SmoothFloat(0, 0.4)
    local smoothVZ = SmoothFloat(0, 0.4)
    local sAtten = 0
    
    while not IsNull(avatar) do
        pilot = avatar:GetRider()
        if not IsNull(pilot) then --No on riding, let it sit
            local dt = DeltaTime()
            local velocity = avatar:GetVelocity()
            smoothVX:SetTargetVal(velocity.x)
            smoothVX:Update(dt)
            smoothVY:SetTargetVal(velocity.y)
            smoothVY:Update(dt)
            smoothVZ:SetTargetVal(velocity.z)
            smoothVZ:Update(dt)
            
            velocity.x = smoothVX:GetVal()
            velocity.y = smoothVY:GetVal()
            velocity.z = smoothVZ:GetVal()
            
            local dir = AngleToDirection(avatar:GetSimRotation())
            local accel = velocity - oldVelocity
            local d = Dot(accel, dir)
            local forward = Dot(dir, velocity)
            local v = Length(velocity) * Clamp((d + 0.2) * 5, 0, 1)

            for i, temp in ipairs(trails) do
                local trailVal = math.max(0.0, (v - 10) * 0.1)
                if not IsNull(temp) then
                    temp:SetMaterialParam(Lotus_Game.ALPHA_ATTEN, math.min(1, trailVal))
                end
            end

            for i, temp in ipairs(flares) do
                if not IsNull(temp) then
                    local flareVal = Length(velocity) * 0.06
                    temp:SetOpacity(0.6 + math.min(0.4, flareVal))
                end
            end
            if not IsNull(speedDeco) then
                if v < speedDecoVisThreshold then
                    if speedDeco:IsVisible() then
                        speedDeco:SetVisibility(false, false)
                    end
                else
                    if not speedDeco:IsVisible() then
                        speedDeco:SetVisibility(true, false)
                    end
                    local speedVal = math.max(0.0, (Length(velocity) - speedDecoVisThreshold) * 0.25)
                    speedDeco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, math.min(1.0, speedVal))
                end
            end
            if not IsNull(speedLines) then
                local velocityLength = Length(velocity)
                local linesVal = math.max(0.0, (velocityLength - 1) * 2)
                speedLines:SetSpeed(linesVal * 2, linesVal * 3)
                
                local colorMult = math.min(1.0, velocityLength / velocityMax)
                local colorMin = Color(colorDotsMin.red * colorMult, colorDotsMin.green * colorMult, colorDotsMin.blue * colorMult, colorDotsMin.alpha * colorMult)
                local colorMax = Color(colorDotsMax.red * colorMult, colorDotsMax.green * colorMult, colorDotsMax.blue * colorMult, colorDotsMax.alpha * colorMult)
                
                speedLines:SetColorMinMax(colorMin, colorMax)
                
                if linesVal > 0.1 then
                    local off = Vector(velocity.x, velocity.y, velocity.z)
                    Normalize(off)
                    local newRot = LookTo(zeroVector, velocity * -1)
                    speedLines:SetAttachLocalSpace(off * linesVal * 0.5, newRot)
                end
            end
            oldVelocity = velocity
        end
        
        if IsNull(pilot) then
            if effectsAreAttached then
                if not IsNull(speedLines) then
                    speedLines:Destroy()
                end
                if not IsNull(speedDeco) then
                    speedDeco:Destroy()
                end
                for i, temp in ipairs(flares) do
                    if not IsNull(temp) then
                        temp:SetOpacity(0.6)
                    end
                end
                effectsAreAttached = false
            end
        elseif not effectsAreAttached then
            if not IsNull(pilot) and pilot == localAvatar then
                speedLines = cam:Attach(speedDotsType, EMPTY_SYMBOL)
                speedDeco = cam:Attach(localSpeedDeco, EMPTY_SYMBOL, Vector(0, 0, 0.2), ZERO_ROTATION, avatar)
            end
            effectsAreAttached = true
        end
        if not IsNull(snow) and sAtten < 1 then
            snow:SetMaterialParam(sSnowAmount, sAtten)
        end
        sAtten = sAtten + DeltaTime() * 0.0025
        Sleep(0)
    end
    
    DestroyEffects(trails)
    DestroyEffects(flares)

    if isLocal then
        if not IsNull(speedLines) then
            speedLines:Destroy()
        end
        if not IsNull(speedDeco) then
            speedDeco:Destroy()
        end
    end
end
