projectorA = Type()
attachedEffects = Type()
attachedDeco = Type()
reactorDecoTag = Symbol("Reactor")
markerPoint = Instance()
newTintColor = Color()
reactorLights = {Instance()}
reactorOffMaterial = Resource()

function ReactorEffects()
    Sleep(1.0)
    
    --local pos = markerPoint:GetPosition()
    --local reactor = gRegion:FindFirstTaggedInRadius(reactorDecoTag, pos, 0, 30)
    local reactor = gRegion:FindFirstTagged(reactorDecoTag)
    if IsNull(reactor) then
        return
    end
    
    local timeLeft = 300
    local transition = 0.0
    local dAmount = 1.0
    local tColor = Color()
    
    if gPromotedToHost then
        local attachments = reactor:GetAllAttachments()
        for i = 1, #attachments do
            attachments[i]:Destroy() -- Destroy attachments first if a host migration took place to stop overlap
        end
    end
    
    reactor:Attach(attachedEffects, EMPTY_SYMBOL)
    local proj = reactor:Attach(projectorA, EMPTY_SYMBOL)
    local corruptedDeco = reactor:Attach(attachedDeco, EMPTY_SYMBOL)
    
    while timeLeft > 0 do
        timeLeft = gGameRules:GetMissionTimeLeft(Symbol())
        transition = timeLeft / 300
        dAmount = math.min(1.0, transition + 0.05)
        corruptedDeco:SetDissolve(dAmount)
        
        tColor.red = Lerp(newTintColor.red, 255, transition)
        tColor.green = Lerp(newTintColor.green, 153, transition)
        tColor.blue = Lerp(newTintColor.blue, 33, transition)
        reactor:SetMaterialParam(Lotus_Game.TINT_COLOR, tColor.red / 255, tColor.green / 255, tColor.blue / 255, 1)
        
        for i = 1, #reactorLights do
            reactorLights[i]:SetColor(Color(tColor.red,tColor.green,tColor.blue,255))
        end
        
        Sleep(0.0)
    end
    
    -- Shut down reactor
    local lightScale = 0.35
    reactor:SetOverrideMaterial(4, reactorOffMaterial)
    for i = 1, #reactorLights do
        reactorLights[i]:SetColor(Color(tColor.red*lightScale, tColor.green*lightScale, tColor.blue*lightScale, 255))
    end

    if not IsNull(proj) then
        proj:Destroy()
    end
end