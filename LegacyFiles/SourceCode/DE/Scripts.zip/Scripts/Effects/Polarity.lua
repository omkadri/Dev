module(..., package.seeall)

-- NOTE:
-- Any resources here must be anchored on the YinYang powersuit, or else using them here is liable to spot-load

local helmetTypes = {
    WeakResource("/Lotus/Characters/Tenno/Anima/AnimaHelmetDeco"),
    WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAltHelmetDeco"),
    WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAltHelmet2Deco"),
    WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaCombinedHelmetDeco"),
    WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaCombinedHelmetADeco"),
    WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraCombinedHelmetDeco"),
    WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxPrimeCombinedHelmetDeco"),
	WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/EquinoxDeluxeCombinedHelmetDeco")
}

local allHelmAttachments = {
    {}, -- Helmet
    {}, -- Alt Helmet
    {}, -- Alt Helmet 2
    {}, -- SWInsomnia
    {   -- SWDivisa
        WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/Cloth/SWDivisaNightHelmetPonyTailASkeletalCloth"),
        WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/Cloth/SWDivisaDayHelmetPonyTailASkeletalCloth")
    },
    {}, -- SWMegaera
    {},  -- EquinoxPrimeHelmet
	{	-- EquinoxDeluxeHelmet
		WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeLightHelmetClothASkeletalCloth"),
		WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeLightHelmetClothBSkeletalCloth"),
		WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeNightHelmetClothSkeletalCloth"),
		WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeCombinedHelmetClothASkeletalCloth"),
		WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeCombinedHelmetClothBSkeletalCloth")
	}
}

local skinTypes = {
    WeakResource("/Lotus/Upgrades/Skins/YinYang/YinYangSkin"),
    WeakResource("/Lotus/Upgrades/Skins/Anima/SWInsomniaSkin"),
    WeakResource("/Lotus/Upgrades/Skins/Anima/SWDivisaSkin"),
    WeakResource("/Lotus/Upgrades/Skins/Anima/SWMegaeraSkin"),
    WeakResource("/Lotus/Upgrades/Skins/YinYang/EquinoxPrimeSkin"),
	WeakResource("/Lotus/Upgrades/Skins/YinYang/EquinoxDeluxeSkin")
}

local allAttachments = {
    -- YinYang 
    WeakResource("/Lotus/Characters/Tenno/Anima/AnimaDressDeco"),
    WeakResource("/Lotus/Characters/Tenno/Anima/AnimaSleeveClothLDeco"),
    WeakResource("/Lotus/Characters/Tenno/Anima/AnimaSleeveClothRDeco"),
    
    WeakResource("/Lotus/Characters/Tenno/Anima/AnimusLegRingsDeco"),
    
    WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimusHalfDressDeco"),
    WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimusSleeveClothRDeco"),
    
    -- EquinoxPrime
    WeakResource("/Lotus/Characters/Tenno/Anima/Cloth/EquinoxPrimeNightDressDeco"),
    WeakResource("/Lotus/Characters/Tenno/Anima/Cloth/EquinoxPrimeNightSleeveClothLDeco"),
    WeakResource("/Lotus/Characters/Tenno/Anima/Cloth/EquinoxPrimeNightSleeveClothRDeco"),
    
    WeakResource("/Lotus/Characters/Tenno/Anima/Cloth/EquinoxPrimeCombinedDressDeco"),
	
	-- Equinox Deluxe
	WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeCombinedArmClothLDeco"),
	WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeCombinedArmClothRDeco"),
	WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeCombinedBackDeco"),
	WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeCombinedSkirtDeco"),
	
	WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeDayArmClothLDeco"),
	WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeDayArmClothRDeco"),
	WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeDayBackDeco"),
	WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeDaySkirtDeco"),
	
	WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeNightArmClothLDeco"),
	WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeNightArmClothRDeco"),
	WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeNightBackDeco")
}

local emptyTint = WeakResource("/Lotus/Characters/Tenno/EmptyUsePrimaryTint")
local emptyTintName = Symbol("EmptyUsePrimaryTint")

-------------------------------------------------------------------

local yinInfo = {
    helmMeshes = {
        WeakResource("/Lotus/Characters/Tenno/Anima/AnimaHelmet_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/AnimaHelmetAlt_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimusAltHelmet2Dark_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaNightHelmet_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaNightHelmet_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraNightHelmet_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxPrimeNightHelmet_skel.fbx"),
		WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/EquinoxDeluxeNightHelmet_skel.fbx")
    },

    helmAttachments = {
        {}, -- Helmet
        {}, -- Alt Helmet
        {}, -- Alt Helmet 2
        {}, -- SWInsomnia
        {   -- SWDivisa
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/Cloth/SWDivisaNightHelmetPonyTailASkeletalCloth")
        },
        {}, -- SWMegaera
        {}, -- EquinoxPrimeHelmet
		{	-- EquinoxDeluxeHelmet
			WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeNightHelmetClothSkeletalCloth")
		}
    },

    mesh = {
        WeakResource("/Lotus/Characters/Tenno/Anima/Anima_skel.fbx"), -- YinYangSkin
        WeakResource("/Lotus/Characters/Tenno/Anima/Anima_skel.fbx"), -- SWInsomniaSkin
        WeakResource("/Lotus/Characters/Tenno/Anima/Anima_skel.fbx"), -- SWDivisaSkin
        WeakResource("/Lotus/Characters/Tenno/Anima/Anima_skel.fbx"), -- SWMegaeraSkin
        WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxPrimeNightBody_skel.fbx"), -- EquinoxPrimeSkin
		WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/EquinoxDeluxeNightBody_skel.fbx") -- EquinoxDeluxeSkin
    },

    meshUgly = WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxPrimeNightBody_skel.fbx"),

    materialOverrides = {
        {}, -- YinYangSkin
        {   -- SWInsomniaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaNightBody")
        },
        {   -- SWDivisaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaNightBodyMat")
        },
        {   -- SWMegaeraSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraNightBodyMat")
        },
        {}, -- EquinoxPrimeSkin
		{}	-- EquinoxDeluxeSkin
    },

    materialOverridesUgly = {
        {}, -- YinYangSkin
        {   -- SWInsomniaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaNightBody"),
            emptyTint
        },
        {   -- SWDivisaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaNightBodyMat"),
            emptyTint
        },
        {   -- SWMegaeraSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraNightBodyMat"),
            emptyTint
        },
        {}, -- EquinoxPrimeSkin
		{}	-- EquinoxDeluxeSkin
    },

    attachments = {
        {   -- YinYangSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaDressDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaSleeveClothLDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaSleeveClothRDeco")
        },
        {   -- SWInsomniaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaDressDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaSleeveClothLDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaSleeveClothRDeco")
        },
        {   -- SWDivisaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaDressDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaSleeveClothLDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaSleeveClothRDeco")
        },
        {   -- SWMegaeraSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaDressDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaSleeveClothLDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaSleeveClothRDeco")
        },
        {   -- EquinoxPrimeSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/Cloth/EquinoxPrimeNightDressDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/Cloth/EquinoxPrimeCombinedDressDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/Cloth/EquinoxPrimeNightSleeveClothLDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/Cloth/EquinoxPrimeNightSleeveClothRDeco")
        },
		{	-- EquinoxDeluxeSkin
			WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeNightArmClothLDeco"),
			WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeNightArmClothRDeco"),
			WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeNightBackDeco")
		}
    },

    attachmentsUgly = {
        WeakResource("/Lotus/Characters/Tenno/Anima/Cloth/EquinoxPrimeNightDressDeco"),
        WeakResource("/Lotus/Characters/Tenno/Anima/Cloth/EquinoxPrimeCombinedDressDeco"),
        WeakResource("/Lotus/Characters/Tenno/Anima/Cloth/EquinoxPrimeNightSleeveClothLDeco"),
        WeakResource("/Lotus/Characters/Tenno/Anima/Cloth/EquinoxPrimeNightSleeveClothRDeco")
    },

    attachmentMaterialOverrides = {
        {}, -- YinYangSkin
        {   -- SWInsomniaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaNightCloth"),
            WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaNightCloth"),
            WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaNightCloth"),
            WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaNightCloth"),
            WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaNightCloth")
        },
        {   -- SWDivisaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaNightClothMat"),
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaNightClothMat"),
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaNightClothMat"),
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaNightClothMat"),
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaNightClothMat")
        },
        {   -- SWMegaeraSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraNightColthMat"),
            WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraNightColthMat"),
            WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraNightColthMat"),
            WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraNightColthMat"),
            WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraNightColthMat")
        },
        {}, -- EquinoxPrimeSkin
		{} 	-- EquinoxDeluxeSkin
    },

    attachmentMaterialOverridesUgly = {},

    customizationInfo = {
        WeakResource("/Lotus/Powersuits/YinYang/YinCustomizationInfo"), -- YinYangSkin
        WeakResource("/Lotus/Powersuits/YinYang/YinCustomizationInfo"), -- SWInsomniaSkin
        WeakResource("/Lotus/Powersuits/YinYang/YinCustomizationInfo"), -- SWDivisaSkin
        WeakResource("/Lotus/Powersuits/YinYang/YinCustomizationInfo"), -- SWMegaeraSkin
        WeakResource("/Lotus/Powersuits/YinYang/EquinoxPrimeNightCustomizationInfo"), -- EquinoxPrimeSkin
		WeakResource("/Lotus/Powersuits/YinYang/EquinoxDeluxeNightCustomizationInfo") -- EquinoxDeluxeSkin
    },

    customizationInfoUgly = WeakResource("/Lotus/Powersuits/YinYang/EquinoxPrimeNightCustomizationInfo"),

    simCollisionOverride = {
        nil, -- YinYangSkin
        nil, -- SWInsomniaSkin
        nil, -- SWDivisaSkin
        nil, -- SWMegaeraSkin
        nil, -- EquinoxPrimeSkin
		nil	 -- EquinoxDeluxeSkin
    },

    abilityIcons = {
        WeakResource("/Lotus/Interface/Icons/Abilities/YinYangSwitch.png"),
        WeakResource("/Lotus/Interface/Icons/Abilities/YinYangTargetCalm.png"),
        WeakResource("/Lotus/Interface/Icons/Abilities/YinYangAuraEnemyDamage.png"),
        WeakResource("/Lotus/Interface/Icons/Abilities/YinYangBlastHeal.png")
    }
}

-------------------------------------------------------------------

local yangInfo = {
    helmMeshes = {
        WeakResource("/Lotus/Characters/Tenno/Anima/AnimusHelmet_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/AnimusHelmetAlt_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimusAltHelmet2Light_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaDayHelmet_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaDayHelmet_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraDayHelmet_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxPrimeDayHelmet_skel.fbx"),
		WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/EquinoxDeluxeLightHelmet_skel.fbx")
    },

    helmAttachments = {
        {}, -- Helmet
        {}, -- Alt Helmet
        {}, -- Alt Helmet 2
        {}, -- SWInsomnia
        {   -- SWDivisa
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/Cloth/SWDivisaDayHelmetPonyTailASkeletalCloth")
        },
        {}, -- SWMegaera
        {}, -- EquinoxPrimeHelmet
		{	-- EquinoxDeluxeHelmet
			WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeLightHelmetClothASkeletalCloth"),
			WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeLightHelmetClothBSkeletalCloth")
		}
    },

    mesh = {
        WeakResource("/Lotus/Characters/Tenno/Anima/Animus_skel.fbx"), -- YinYangSkin
        WeakResource("/Lotus/Characters/Tenno/Anima/Animus_skel.fbx"), -- SWInsomniaSkin
        WeakResource("/Lotus/Characters/Tenno/Anima/Animus_skel.fbx"), -- SWDivisaSkin
        WeakResource("/Lotus/Characters/Tenno/Anima/Animus_skel.fbx"), -- SWMegaeraSkin
        WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxPrimeDayBody_skel.fbx"), -- EquinoxPrimeSkin
		WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/EquinoxDeluxeLightBody_skel.fbx")
    },

    meshUgly = WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxPrimeDayBody_skel.fbx"),

    materialOverrides = {
        {}, -- YinYangSkin
        {   -- SWInsomniaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaDayBody")
        },
        {   -- SWDivisaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaDayBodyMat")
        },
        {   -- SWMegaeraSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraDayBodyMat")
        },
        {}, -- EquinoxPrimeSkin
		{}	-- EquinoxDeluxeSkin
    },

    materialOverridesUgly = {
        {}, -- YinYangSkin
        {   -- SWInsomniaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaDayBody"),
            emptyTint
        },
        {   -- SWDivisaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaDayBodyMat"),
            emptyTint
        },
        {   -- SWMegaeraSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraDayBodyMat"),
            emptyTint
        },
        {}, -- EquinoxPrimeSkin
		{}	-- EquinoxDeluxeSkin
    },

    attachments = {
        {   -- YinYangSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimusLegRingsDeco")
        },
        {   -- SWInsomniaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimusLegRingsDeco")
        },
        {   -- SWDivisaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimusLegRingsDeco")
        },
        {   -- SWMegaeraSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimusLegRingsDeco")
        },
        {},	-- EquinoxPrimeSkin
		{	-- EquinoxDeluxeSkin
			WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeDayArmClothLDeco"),
			WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeDayArmClothRDeco"),
			WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeDayBackDeco"),
			WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeDaySkirtDeco")
		}
    },

    attachmentsUgly = {},

    attachmentMaterialOverrides = {
        {}, -- YinYangSkin
        {   -- SWInsomniaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaDayBody")
        },
        {   -- SWDivisaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaDayBodyMat")
        },
        {   -- SWMegaeraSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraDayBodyMat")
        },
        {}, -- EquinoxPrimeSkin
		{}	-- EquinoxDeluxeSkin
    },

    attachmentMaterialOverridesUgly = {},

    customizationInfo = {
        WeakResource("/Lotus/Powersuits/YinYang/YangCustomizationInfo"), -- YinYangSkin
        WeakResource("/Lotus/Powersuits/YinYang/YangCustomizationInfo"), -- SWInsomniaSkin
        WeakResource("/Lotus/Powersuits/YinYang/YangCustomizationInfo"), -- SWDivisaSkin
        WeakResource("/Lotus/Powersuits/YinYang/YangCustomizationInfo"), -- SWMegaeraSkin
        WeakResource("/Lotus/Powersuits/YinYang/EquinoxPrimeDayCustomizationInfo"), -- EquinoxPrimeSkin
		WeakResource("/Lotus/Powersuits/YinYang/EquinoxDeluxeDayCustomizationInfo")	-- EquinoxDeluxeSkin
    },

    customizationInfoUgly = WeakResource("/Lotus/Powersuits/YinYang/EquinoxPrimeDayCustomizationInfo"),

    simCollisionOverride = {
        nil, -- YinYangSkin
        nil, -- SWInsomniaSkin
        nil, -- SWDivisaSkin
        nil, -- SWMegaeraSkin
        WeakResource("/Lotus/Powersuits/YinYang/EquinoxPrimeDaySimCollision"), -- EquinoxPrimeSkin
		nil	 -- EquinoxDeluxeSkin
    },

    simCollisionOverrideUgly = WeakResource("/Lotus/Powersuits/YinYang/EquinoxPrimeDaySimCollision"),

    abilityIcons = {
        WeakResource("/Lotus/Interface/Icons/Abilities/YinYangSwitch.png"),
        WeakResource("/Lotus/Interface/Icons/Abilities/YinYangTargetFury.png"),
        WeakResource("/Lotus/Interface/Icons/Abilities/YinYangAuraPowerStrength.png"),
        WeakResource("/Lotus/Interface/Icons/Abilities/YinYangBlastHarm.png")
    }
}

-------------------------------------------------------------------

local yinYangInfo = {
    helmMeshes = {
        WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimusHelmet_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimusHelmetAlt_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimusAltHelmet2Combined_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaCombinedHelmet_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaCombinedHelmet_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraCombinedHelmet_skel.fbx"),
        WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxPrimeCombinedHelmet_skel.fbx"),
		WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/EquinoxDeluxeCombinedHelmet_skel.fbx")
    },

    helmAttachments = {
        {}, -- Helmet
        {}, -- Alt Helmet
        {}, -- Alt Helmet 2
        {}, -- SWInsomnia
        {   -- SWDivisa
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/Cloth/SWDivisaNightHelmetPonyTailASkeletalCloth"),
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/Cloth/SWDivisaDayHelmetPonyTailASkeletalCloth")
        },
        {}, -- SWMegaera
        {}, -- EquinoxPrimeHelmet
		{	-- EquinoxDeluxeHelmet
			WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeCombinedHelmetClothASkeletalCloth"),
			WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeCombinedHelmetClothBSkeletalCloth")
		}
    },

    mesh = {
        WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimus_skel.fbx"), -- YinYangSkin
        WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimus_skel.fbx"), -- SWInsomniaSkin
        WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimus_skel.fbx"), -- SWDivisaSkin
        WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimus_skel.fbx"), -- SWMegaeraSkin
        WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxPrimeCombinedBody_skel.fbx"), -- EquinoxPrimeSkin
		WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/EquinoxDeluxeCombinedBody_skel.fbx") -- EquinoxDeluxeSkin
    },

    meshUgly = WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxPrimeCombinedBody_skel.fbx"),

    materialOverrides = {
        {}, -- YinYangSkin
        {   -- SWInsomniaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaCombinedTorso"),
            WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaCombinedLegs")
        },
        {   -- SWDivisaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaNightDayBodyMat"),
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaDayNightBodyMat")
        },
        {   -- SWMegaeraSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraNightDayBodyMat"),
            WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraDayNightBodyMat")
        },
        {}, -- EquinoxPrimeSkin
		{}	-- EquinoxDeluxeSkin
    },

    materialOverridesUgly = {
        {}, -- YinYangSkin
        {   -- SWInsomniaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaCombinedLegs"),
            emptyTint,
            WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaCombinedTorso"),
            emptyTint
        },
        {   -- SWDivisaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaDayNightBodyMat"),
            emptyTint,
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaNightDayBodyMat"),
            emptyTint
        },
        {   -- SWMegaeraSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraDayNightBodyMat"),
            emptyTint,
            WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraNightDayBodyMat"),
            emptyTint
        },
        {}, -- EquinoxPrimeSkin
		{}	-- EquinoxDeluxeSkin
    },

    attachments = {
        {   -- YinYangSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaSleeveClothLDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimusHalfDressDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimusSleeveClothRDeco")
        },
        {   -- SWInsomniaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaSleeveClothLDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimusHalfDressDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimusSleeveClothRDeco")
        },
        {   -- SWDivisaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaSleeveClothLDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimusHalfDressDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimusSleeveClothRDeco")
        },
        {   -- SWMegaeraSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaSleeveClothLDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimusHalfDressDeco"),
            WeakResource("/Lotus/Characters/Tenno/Anima/AnimaAnimusSleeveClothRDeco")
        },
        {   -- EquinoxPrimeSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/Cloth/EquinoxPrimeCombinedDressDeco")
        },
		{	-- EquinoxDeluxeSkin
			WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeCombinedArmClothLDeco"),
			WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeCombinedArmClothRDeco"),
			WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeCombinedBackDeco"),
			WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/Cloth/EquinoxDeluxeCombinedSkirtDeco")
		}
    },

    attachmentsUgly = {
        WeakResource("/Lotus/Characters/Tenno/Anima/Cloth/EquinoxPrimeCombinedDressDeco")
    },

    attachmentMaterialOverrides = {
        {}, -- YinYangSkin
        {   -- SWInsomniaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWInsomnia/SWInsomniaCombinedCloth")
        },
        {   -- SWDivisaSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWDivisa/SWDivisaCombinedClothMat")
        },
        {   -- SWMegaeraSkin
            WeakResource("/Lotus/Characters/Tenno/Anima/SWMegaera/SWMegaeraCombinedClothMat")
        },
        {}, -- EquinoxPrimeSkin
		{}	-- EquinoxDeluxeSkin
    },

    attachmentMaterialOverridesUgly = {},

    customizationInfo = {},

    simCollisionOverride = {
        nil, -- YinYangSkin
        nil, -- SWInsomniaSkin
        nil, -- SWDivisaSkin
        nil, -- SWMegaeraSkin
        WeakResource("/Lotus/Powersuits/YinYang/EquinoxPrimeDaySimCollision"), -- EquinoxPrimeSkin
		nil	 -- EquinoxDeluxeSkin
    },

    simCollisionOverrideUgly = WeakResource("/Lotus/Powersuits/YinYang/EquinoxPrimeDaySimCollision")
}

--=================================================================


local YIN_POLARITY = 0
local YANG_POLARITY = 1
local YIN_TO_YANG = 2
local YANG_TO_YIN = 3

local function IsIn(o, arr)
    for i, a in ipairs(arr) do
        if o == a then
            return true
        end
    end
    return false
end

local function CreateAttachments(attachEntity, allAttachmentList, wantedAttachmentList, attachBone, attachmentMatOverrides, colors, deco)
    for i, attachType in ipairs(allAttachmentList) do
        local attachment = attachEntity:GetAttachment(attachType)
        local isIn = IsIn(attachType, wantedAttachmentList)
        if isIn then
            if IsNull(attachment) then
                attachment = attachEntity:Attach(Type(attachType), attachBone)
            end
            
            if not IsNull(attachment) then
                local clothChildren = attachment:GetAllAttachments(gSkeletalClothExType)
                if #attachmentMatOverrides == 0 then
                    attachment:RemoveAllOverrideMaterials(false)
                    
                    for k, cloth in ipairs(clothChildren) do
                        cloth:RemoveAllOverrideMaterials(false)
                    end
                else
                    for j, override in ipairs(attachmentMatOverrides) do
                        local matRes = Resource(override)
                        attachment:SetOverrideMaterial(j - 1, matRes, false)
                        
                        for k, cloth in ipairs(clothChildren) do
                            cloth:SetOverrideMaterial(j - 1, matRes, false)
                        end
                    end
                end
                
                if not IsNull(deco) then
                    attachment:UseMaterialParams(deco)
                    for k, cloth in ipairs(clothChildren) do
                        cloth:UseMaterialParams(deco)
                    end
                else
                    Lotus_Game.WeaponCustomization_ApplyColors(attachment, colors, true)
                end
            end
        else
            if not IsNull(attachment) then
                local currentRegion = attachment:GetRegionMgr()
                currentRegion:DestroyObject(attachment)
            end
        end
    end
end

-- Update mesh/attachments
local function UpdateSuit(suit, info, entityOverride)
    local avatar = suit:GetAvatarOwner()
    if IsNull(avatar) then
        return
    end
        
    local customization = suit:GetCustomization()
        
    local skinIdx = nil
    local skinIdxNoUpg = nil
    local skin = customization:GetSkin(Lotus_Game.BodySkin)
        
    for i, skinType in ipairs(skinTypes) do
        -- The skin we have an upgrade for takes priority, it may differ than what's in our customization slot (e.g. previewing skins in arsenal)
        if suit:HasUpgradeWRes(skinType) then
            skinIdx = i
            break
        end
            
        if skinType == skin then
            skinIdxNoUpg = i
        end
    end
        
    if skinIdx == nil then
        if skinIdxNoUpg == nil then
            return
        end
            
        skinIdx = skinIdxNoUpg
    end
        
    local allowUgly = customization.mAllowUglyMode and Resource(skinTypes[skinIdx]):AllowUglyMode()
    local matOverrides = nil
    if allowUgly then
        if IsNull(entityOverride) then
            suit:OverrideMesh(Resource(info.meshUgly))
            suit:OverrideCustomizationInfo(Type(info.customizationInfoUgly))
        else
            entityOverride:SetMesh(Resource(info.meshUgly), true, false)
        end
        matOverrides = info.materialOverridesUgly[skinIdx]
    else
        if IsNull(entityOverride) then
            suit:OverrideMesh(Resource(info.mesh[skinIdx]))
            suit:OverrideCustomizationInfo(Type(info.customizationInfo[skinIdx]))
        else
            entityOverride:SetMesh(Resource(info.mesh[skinIdx]), true, false)
        end
        matOverrides = info.materialOverrides[skinIdx]
    end
        
    local suitEntity = entityOverride
    if IsNull(suitEntity) then
        suitEntity = suit:GetCustomizationEntity()
    end
        
    suitEntity:SetOverrideMaterialForAllSections(nil, false)
    suitEntity:ClearMaterialParamsArray()
        
    for i, override in ipairs(matOverrides) do
        if override == emptyTint then
            suitEntity:SetMaterialParamEx(emptyTintName, i - 1, 0, 0, 0, 0, false)
            suitEntity:SetOverrideMaterial(i - 1, nil, false)
        else
            suitEntity:SetOverrideMaterial(i - 1, Resource(override), false)
        end
    end
        
    local colors = customization:GetColors(Lotus_Game.PrimaryColors)
    for i = 0, Lotus_Game.MAX_CustomizationColor - 1 do
        if not colors:Initialized(i) then
            if i == Lotus_Game.EmissiveColor1 then
                if colors:Initialized(Lotus_Game.EmissiveColor0) then
                    colors:SetColor(i, colors.mEmissiveColor0)
                else
                    colors:SetColor(i, customization:GetDefaultColor(Lotus_Game.EmissiveColor0, suitEntity))
                end
            else
                colors:SetColor(i, customization:GetDefaultColor(i, suitEntity))
            end
            colors:SetInitialized(i, true)
        end
    end
        
    Lotus_Game.WeaponCustomization_ApplyColors(suitEntity, colors, false, false)
        
    for i, helmetType in ipairs(helmetTypes) do
        local helmet = avatar:GetAttachment(helmetType)
        if not IsNull(helmet) then
            if not IsNull(entityOverride) then
                helmet = entityOverride:Attach(Type(helmetType), EMPTY_SYMBOL)
            end
            
            helmet:SetMesh(Resource(info.helmMeshes[i]), false, false)
            Lotus_Game.WeaponCustomization_ApplyColors(helmet, colors, true)
            CreateAttachments(helmet, allHelmAttachments[i], info.helmAttachments[i], Symbol("GAME_C1_HEAD1"), nil, colors, nil)
            
            break
        end
    end
        
    local attachEntity = suitEntity
    if IsNull(entityOverride) and suit:IsOverrideSuitEnabled() then
        local altSuit = avatar:InventoryControl():GetAlternatePowerSuit()
        if not IsNull(altSuit) then
            attachEntity = altSuit:GetCustomizationEntity()
        end
    end
        
    if allowUgly then
        CreateAttachments(attachEntity, allAttachments, info.attachmentsUgly, EMPTY_SYMBOL, info.attachmentMaterialOverridesUgly, colors, nil)
            
        if IsNull(entityOverride) then
            if info.simCollisionOverrideUgly == nil then
                avatar:SetSimCollision(suit:GetSimCollision())
            else
                avatar:SetSimCollision(Resource(info.simCollisionOverrideUgly))
            end
        end
    else
        CreateAttachments(attachEntity, allAttachments, info.attachments[skinIdx], EMPTY_SYMBOL, info.attachmentMaterialOverrides[skinIdx], colors, nil)
            
        if IsNull(entityOverride) then
            if info.simCollisionOverride[skinIdx] == nil then
                avatar:SetSimCollision(suit:GetSimCollision())
            else
                avatar:SetSimCollision(Resource(info.simCollisionOverride[skinIdx]))
            end
        end
    end
        
    if IsNull(entityOverride) and avatar:ReplicaLocallyControlled() and info.abilityIcons ~= nil then
        local skipIconOverride = false
        -- Don't override icon textures if in Archwing mode.
        if suit:IsOverrideSuitEnabled() then
            local altSuit = avatar:InventoryControl():GetAlternatePowerSuit()
            if not IsNull(altSuit) then
                skipIconOverride = altSuit:IsA(gFlightJetPackItemType)
            end
        end
        if not skipIconOverride then
            local abilities = suit:GetAbilities()
            for i, ability in ipairs(abilities) do
                ability:SetIconTexture(info.abilityIcons[i])
            end
        end
    end
end

local function UpdateAttachments(suit)
    local polarity = suit:GetSuitState()
    if polarity == YIN_POLARITY then
        UpdateSuit(suit, yinInfo)
    elseif polarity == YANG_POLARITY then
        UpdateSuit(suit, yangInfo)
    else    -- YIN_TO_YANG or YANG_TO_YIN
        UpdateSuit(suit, yinYangInfo)
    end
end

local function PrivateSetPolarity(suit, polarity)
    if polarity == suit:GetSuitState() then
        return
    end
    
    suit:SetSuitState(polarity)
    UpdateAttachments(suit)
end

function SwitchPolarity(suit)
    -- Immediately changes from YIN <-> YANG
    local polarity = suit:GetSuitState()
    if polarity == YIN_POLARITY or polarity == YIN_TO_YANG then
        PrivateSetPolarity(suit, YANG_POLARITY)
    else
        PrivateSetPolarity(suit, YIN_POLARITY)
    end
end

function PartialSwitchPolarity(suit)
    -- Changes YIN -> YIN_TO_YANG -> YANG -> YANG_TO_YIN -> YIN
    local polarity = suit:GetSuitState()
    if polarity == YIN_POLARITY then
        PrivateSetPolarity(suit, YIN_TO_YANG)
    elseif polarity == YIN_TO_YANG then
        PrivateSetPolarity(suit, YANG_POLARITY)
    elseif polarity == YANG_POLARITY then
        PrivateSetPolarity(suit, YANG_TO_YIN)
    else
        PrivateSetPolarity(suit, YIN_POLARITY)
    end
end

function UndoPartialSwitch(suit)
    -- Changes YIN_TO_YANG -> YIN and YANG_TO_YIN -> YANG
    local polarity = suit:GetSuitState()
    if polarity == YIN_TO_YANG then
        PrivateSetPolarity(suit, YIN_POLARITY)
    elseif polarity == YANG_TO_YIN then
        PrivateSetPolarity(suit, YANG_POLARITY)
    end
end

function ForceYin(suit)
    if suit:GetSuitState() ~= YIN_POLARITY then
        PrivateSetPolarity(suit, YIN_POLARITY)
    end
end

function ForceYang(suit)
    if suit:GetSuitState() ~= YANG_POLARITY then
        PrivateSetPolarity(suit, YANG_POLARITY)
    end
end

function RedoPolarity(suit)
    UpdateAttachments(suit)
end

function IsYin(suit)
    return suit:GetSuitState() == YIN_POLARITY
end

function IsYang(suit)
    return suit:GetSuitState() == YANG_POLARITY
end

local function GetColorPolarity(color)
    if color:Luminance() > 0.5 then -- probably do something better than this
        return YANG_POLARITY
    end
    return YIN_POLARITY
end

function YinColorPolarity(color)
    return GetColorPolarity(color) == YIN_POLARITY
end

function Initialize(suit)
    -- Randomizing Equinox's appearance can cause some things to get rebuilt
    -- Which for a moment can result in a null avatar owner on the suit, leading to a crash
    while IsNull(suit:GetAvatarOwner()) do
        Sleep(0)
    end

    if not IsNull(suit:GetAvatarOwner()) and suit:GetAvatarOwner():ReplicaLocallyControlled() then
        -- We need to sleep so we get our abilities set up, but everyone else doesn't
        Sleep(0)
    end
    
    if gRegion:IsMaster() then
        local polarity = YIN_POLARITY
        local customization = suit:GetCustomization()
        local colors = customization:GetColors(Lotus_Game.PrimaryColors)
        if colors:Initialized(Lotus_Game.EmissiveColor0) then
            polarity = GetColorPolarity(suit:GetEnergyElementColor())
        end

        if gGameRules:InDojo() or gGameRules:IsA(gLotusAttractModeGameRulesType) or gGameRules:IsA(gLotusHubGameRulesType) then
            -- Stick to mixed polarity in ship/relays/etc
            -- Use different mixed polarities here so in dojo we can properly switch back to your default
            if suit:GetSuitState() <= YANG_TO_YIN then
                -- Something (e.g. arsenal) already set us, don't override it
                return
            end
            
            if polarity == YIN_POLARITY then
                PrivateSetPolarity(suit, YIN_TO_YANG)
            else
                PrivateSetPolarity(suit, YANG_TO_YIN)
            end
            
            return
        end
        
        PrivateSetPolarity(suit, polarity)
        return
    end
    
    UpdateAttachments(suit)
end

function CleanUp(suit)
    local avatar = suit:GetAvatarOwner()
    if not IsNull(avatar) then
        for i, attachType in ipairs(allAttachments) do
            local attachment = avatar:GetAttachment(attachType)
            if not IsNull(attachment) then
                local currentRegion = attachment:GetRegionMgr()
                currentRegion:DestroyObject(attachment)
            end
        end
        
        avatar:RemoveAllOverrideMaterials()
    end
end

function SetupHelmet(helmet)
    local avatar = helmet:GetAttachRoot()
    if not IsNull(avatar) and avatar:IsA(gBaseAvatarType) then
        if avatar:ReplicaLocallyControlled() then
            -- Match the sleep in Initialize()
            Sleep(0)
        end
        
        local suit = avatar:InventoryControl():GetActivePowerSuit()
        if not IsNull(suit) then
            local polarity = suit:GetSuitState()
            for i, helmType in ipairs(helmetTypes) do
                if helmet:GetType() == helmType then
                    if polarity == YIN_POLARITY then
                        helmet:SetMesh(Resource(yinInfo.helmMeshes[i]), false, false)
                    elseif polarity == YANG_POLARITY then
                        helmet:SetMesh(Resource(yangInfo.helmMeshes[i]), false, false)
                    else
                        helmet:SetMesh(Resource(yinYangInfo.helmMeshes[i]), false, false)
                    end
                    
                    break
                end
            end
        end
    end
end

function SetupDecoOpposite(suit, deco)
    local polarity = suit:GetSuitState()
    if polarity == YIN_POLARITY then
        UpdateSuit(suit, yangInfo, deco) -- Suit is yin, deco is yang
    elseif polarity == YANG_POLARITY then
        UpdateSuit(suit, yinInfo, deco) -- Suit is yang, deco is yin
    else    -- YIN_TO_YANG or YANG_TO_YIN
        UpdateSuit(suit, yinYangInfo, deco) -- Suit is mixed, deco is also mixed
    end
end

function DioramaView(deco, polarity)
    
    -- Update mesh/attachments
    local UpdateSuitDiorama = function(deco, suitMesh, materialOverrides, customizationInfo, helmMeshes, attachmentList, helmAttachmentList, attachmentMaterialOverrides)
        local playerDeco = deco:GetRegionMgr():FindFirstTagged(Symbol("Player"))
        if IsNull(playerDeco) then
            return
        end
        local skinIdx = 1
        local helmetIndex = 1
        local material = playerDeco:GetMaterialInSlot(0)
        if not IsNull(material) then
            if material:IsA(WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/EquinoxDeluxeLightBody")) or material:IsA(WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxDeluxe/EquinoxDeluxeDarkBody")) then
                skinIdx = 6
                helmetIndex = 8
            elseif material:IsA(WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxPrimeDay")) or material:IsA(WeakResource("/Lotus/Characters/Tenno/Anima/EquinoxPrimeNight")) then
                skinIdx = 5
                helmetIndex = 7
            else
                for i=1, #yinYangInfo.materialOverrides do
                    if not IsNull(yinYangInfo.materialOverrides[i][1]) then
                        if material == yinYangInfo.materialOverrides[i][1] then
                            skinIdx = i
                        end
                    end
                end
            end
        end
        
        local mesh = Resource(suitMesh[skinIdx])
        if not IsNull(mesh) then
            deco:SetMesh(mesh, false, false)
        end
        deco:UseMaterialParams(playerDeco)
        
        local matOverrides = materialOverrides[skinIdx]
        for i, override in ipairs(matOverrides) do
            deco:SetOverrideMaterial(i - 1, Resource(override), false)
        end
        
        local helmet = nil
        for i, helmetType in ipairs(helmetTypes) do
            helmet = deco:GetAttachment(helmetType)
            if not IsNull(helmet) then
                helmetIndex = i
                break
            end
        end
        if IsNull(helmet) then
            local helmetRes = Resource(helmetTypes[1])
            helmet = deco:Attach(helmetRes, EMPTY_SYMBOL)
        end
        if not IsNull(helmet) then
            helmet:SetMesh(Resource(helmMeshes[helmetIndex]), false, false)
            helmet:UseMaterialParams(playerDeco)
            CreateAttachments(helmet, allHelmAttachments[helmetIndex], helmAttachmentList[helmetIndex], Symbol("GAME_C1_HEAD1"), nil, nil, playerDeco)
        end

        CreateAttachments(deco, allAttachments, attachmentList[skinIdx], EMPTY_SYMBOL, attachmentMaterialOverrides[skinIdx], nil, playerDeco)
    end
    
    if polarity == YIN_POLARITY then
        UpdateSuitDiorama(deco, yinInfo.mesh, yinInfo.materialOverrides, yinInfo.customizationInfo, yinInfo.helmMeshes, yinInfo.attachments, yinInfo.helmAttachments, yinInfo.attachmentMaterialOverrides)
    elseif polarity == YANG_POLARITY then
        UpdateSuitDiorama(deco, yangInfo.mesh, yangInfo.materialOverrides, yangInfo.customizationInfo, yangInfo.helmMeshes, yangInfo.attachments, yangInfo.helmAttachments, yangInfo.attachmentMaterialOverrides)
    else    -- YIN_TO_YANG or YANG_TO_YIN
        UpdateSuitDiorama(deco, yinYangInfo.mesh, yinYangInfo.materialOverrides, nil, yinYangInfo.helmMeshes, yinYangInfo.attachments, yinYangInfo.helmAttachments, yinYangInfo.attachmentMaterialOverrides)
    end
end