-- GolemPanelTumor
Delay = 0
TimeLength = 1
AutoStartScale = false
StartScale = 1
EndScale = 0

-- t = time
-- b = begin
-- c = change == ending - beginning
-- d = duration

local function inOutBack(t, b, c, d, s)
  if not s then s = 1.70158 end
  s = s * 1.525
  t = t / d * 2
  if t < 1 then
    return c / 2 * (t * t * ((s + 1) * t - s)) + b
  else
    t = t - 2
    return c / 2 * (t * t * ((s + 1) * t + s) + 2) + b
  end
end

function shrinkTumor(deco)
    Sleep(Delay)
    local t = 0
    
    if AutoStartScale then
        StartScale = deco:GetMeshScale()
    end
       
    while t < TimeLength do
        -- inOutBack bounces a bit beyond start and end values, so clamp it to valid value
        local val = math.max(0.01, inOutBack(t, StartScale, EndScale - StartScale, TimeLength, 1.1))
        deco:SetMeshScale(val)
        t = t + DeltaTime()
        Sleep(0)
    end
end