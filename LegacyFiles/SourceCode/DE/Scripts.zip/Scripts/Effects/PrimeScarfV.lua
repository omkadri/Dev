ringType = Type()
hubRingType = Type()
energyJetType = Type()
smokeJetType = Type()

local baseOffset = Vector(-0.30, 0.32, 0)
local jetOffsets = {Vector(-0.2, 0.28, 0.22), Vector(-0.2, 0.28, 0.-0.22)}
local jetRots = {Rotation(30, 0, 0), Rotation(150, 0, 0)}
local ringScales = {0.22, 0.28}
local sNormalFade = Symbol("nScalesFade")
local sUnlitAtten = Symbol("UnlitAtten")

function PrimeScarfEffects(scarf)
    if IsNull(gGameRules) then
        return
    end
    local avatar = scarf:GetAttachRoot()
    if IsNull(scarf) or IsNull(avatar) then
        return
    end

    if not avatar:IsA(gBaseAvatarType) then
        return
    end
    
    local suit = avatar:InventoryControl():GetActivePowerSuit()
    
    local avatarScale = avatar:GetMeshScale()
    
    if gGameRules:IsA(gLotusHubGameRulesType) then
        scarf:Attach(hubRingType, EMPTY_SYMBOL, baseOffset, ZERO_ROTATION, scarf)
        return
    end
    
    local effectDeco = scarf:Attach(ringType, EMPTY_SYMBOL, baseOffset, ZERO_ROTATION, scarf)
    
    local energyJets = {}
    local smokeJets = {}
    for i=1, 2 do
        local smoke = scarf:Attach(smokeJetType, EMPTY_SYMBOL, jetOffsets[i], jetRots[i])
        if not IsNull(smoke) then
            table.insert(smokeJets, smoke)
        end
        local energy = scarf:Attach(energyJetType, EMPTY_SYMBOL, jetOffsets[i], jetRots[i])
        if not IsNull(energy) then
            table.insert(energyJets, energy)
        end
    end
    
    local wasChanneling = false
    local val = 0
    local rot = Rotation()
    local rotateSpeed = 1
    
    while true do
        local meleeWeapon = avatar:InventoryControl():GetMeleeWeapon()
        local comboTier = 0
        if not IsNull(meleeWeapon) then
            comboTier = meleeWeapon:GetActiveImpactBehavior():GetCurrentComboTier()
        end
        local channeling = (comboTier > 0)
        
        if channeling and not wasChanneling then
            for i=1, #energyJets do
                energyJets[i]:Enable()
            end
            for i=1, #smokeJets do
                smokeJets[i]:Enable()
            end
        end
        
        if channeling then
            val = math.min(1, val + DeltaTime() * 2)
        else
            val = math.max(0, val - DeltaTime() * 3)
        end
        
        if not channeling and wasChanneling then
            local jets = scarf:GetAllAttachments(energyJetType)
            for i=1, #energyJets do
                energyJets[i]:Disable()
            end
            for i=1, #smokeJets do
                smokeJets[i]:Disable()
            end
        end

        wasChanneling = channeling

        if not IsNull(effectDeco) then
            rotateSpeed = 2 + val * 8
            rot.bank = rot.bank - DeltaTime() * 60 * rotateSpeed
            if rot.bank < -180 then
                rot.bank = rot.bank + 360
            end
            rot.heading = rot.heading - DeltaTime() * 45 * rotateSpeed
            if rot.heading < -180 then
                rot.heading = rot.heading + 360
            end
            rot.pitch = rot.pitch - DeltaTime() * 35 * rotateSpeed
            if rot.pitch < -180 then
                rot.pitch = rot.pitch + 360
            end
            effectDeco:SetAttachLocalSpace(Vector(baseOffset.x - val * 0.01, baseOffset.y + val * 0.04, 0), rot)
            effectDeco:SetMeshScale(Lerp(ringScales[1] * avatarScale, ringScales[2] * avatarScale, (val * val)))
            effectDeco:SetMaterialParam(sNormalFade, val)
            effectDeco:SetMaterialParam(sUnlitAtten, 0.05 + 2 * val)
        end

        Sleep(0)
    end
end
