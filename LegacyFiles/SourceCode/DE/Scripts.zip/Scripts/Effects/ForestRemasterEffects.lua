pollenParticleSys = Resource()

function roachGang(ParticleSys)
    Sleep(0)
    while true do
        ParticleSys:SetSpewCount(4,8, true)
    end
end

function triggerPlantPollen(self)
    Sleep(0)
    local pos = self:GetPosition()
    gRegion:CreateNano(pollenParticleSys, pos, ZERO_ROTATION)
end