local worldTransmissionMaterial = Resource("/Lotus/Fx/Enemies/Corpus/Champions/CorpusArenaInWorldTransmission")
local scoreboardMaterial = Resource("/Lotus/Fx/Enemies/Corpus/Champions/CorpusHolographcScoreboardBG")
local supportMaterials = {
    Resource("/Lotus/Fx/Enemies/Corpus/Champions/CorpusHolographcTransmissionBorder"),
    Resource("/Lotus/Fx/Enemies/Corpus/Champions/CorpusHolographcTransmissionRays")
}

local sRippleScale = Symbol("RippleScale")
local sUnlitAtten = Symbol("UnlitAtten")
local RippleStart = Vector(0.5, 0.5, 0.04)
local fadeWithTintColor = true

local scoreBgMaxAlpha = 1.0

local transmissionScreenWRes = WeakResource("/Lotus/Fx/Enemies/Corpus/Champions/CorpusArenaTransmissionScreenDeco")
local inWorldMovie = Resource("/Lotus/Interface/InWorldText.swf")

local NV_PLAYER_SCORE = Symbol("Team1Score")
local NV_ENEMY_SCORE = Symbol("Team2Score")


function ResetMaterials()
    if not IsNull(worldTransmissionMaterial) and not IsNull(scoreboardMaterial) then
        local sbR = scoreboardMaterial:GetParam(Lotus_Game.TINT_COLOR, 1)
        local sbG = scoreboardMaterial:GetParam(Lotus_Game.TINT_COLOR, 2)
        local sbB = scoreboardMaterial:GetParam(Lotus_Game.TINT_COLOR, 3)
        if fadeWithTintColor then
            worldTransmissionMaterial:SetParam(Lotus_Game.TINT_COLOR, 1, 1, 1, 0)
            scoreboardMaterial:SetParam(Lotus_Game.TINT_COLOR, sbR, sbG, sbB, scoreBgMaxAlpha)
        else
            worldTransmissionMaterial:SetParam(sUnlitAtten, 0)
            scoreboardMaterial:SetParam(sUnlitAtten, 0)
        end
        for i=1, #supportMaterials do
            if not IsNull(supportMaterials[i]) then
                supportMaterials[i]:SetParam(sUnlitAtten, 0)
            end
        end
    end
    
    local corpusArenaScreenMovies = {}
    local screens = gRegion:FindAll(transmissionScreenWRes)
    for i,screen in ipairs(screens) do
        local movie = gFlashMgr:GotoMovie(inWorldMovie)
        corpusArenaScreenMovies[i] = movie
        movie:AttachToEntity(screen, Vector(0, 0.3,-1), Rotation(180, -45, 0), Vector(1, 1, 1))
        movie:SetVariable("Panel.Bg", "_visible", false)
        movie:SetCullDistance(45)
    end
    
    _T.InWorldTextDisableAlphaInterp = true
    _T.CorpusArenaScreenScoreFade = 255
    local gameRules = gGameRules
    
    while not IsNull(gameRules) do
        local playerScore = gameRules:GetNetPersistentVar(NV_PLAYER_SCORE, 0)
        local enemyScore = gameRules:GetNetPersistentVar(NV_ENEMY_SCORE, 0)
        for i,movie in ipairs(corpusArenaScreenMovies) do
            if not IsNull(movie) then
                movie:Execute("SetMessage", tostring(playerScore) .. " - " .. tostring(enemyScore))
                movie:SetVariable("Panel", "_alpha", _T.CorpusArenaScreenScoreFade)
            end
        end
        Sleep(0.1)
    end
end

function TransmissionStarted()
    local sbR = scoreboardMaterial:GetParam(Lotus_Game.TINT_COLOR, 1)
    local sbG = scoreboardMaterial:GetParam(Lotus_Game.TINT_COLOR, 2)
    local sbB = scoreboardMaterial:GetParam(Lotus_Game.TINT_COLOR, 3)
    if not IsNull(worldTransmissionMaterial) then
        local w = 0.0
        while w < 1.0 do
            w = Clamp(w + (DeltaTime() * 3), 0.0, 1.0)
            local fade = SmoothStep(w)
            _T.CorpusArenaScreenScoreFade = (1-fade)*255
            if fadeWithTintColor then
                worldTransmissionMaterial:SetParam(Lotus_Game.TINT_COLOR, 1, 1, 1, fade)
                scoreboardMaterial:SetParam(Lotus_Game.TINT_COLOR, sbR, sbG, sbB, (1-fade) * scoreBgMaxAlpha)
            else
                worldTransmissionMaterial:SetParam(sUnlitAtten, fade)
                scoreboardMaterial:SetParam(sUnlitAtten, 1-fade)
            end
            worldTransmissionMaterial:SetParam(sRippleScale, RippleStart.z + RippleStart.x * (1 - fade), RippleStart.z + RippleStart.y * (1 - fade))
            for i=1, #supportMaterials do
                if not IsNull(supportMaterials[i]) then
                    supportMaterials[i]:SetParam(sUnlitAtten, fade)
                end
            end
            Sleep(0)
        end
    end
end

function TransmissionEnded()
    local sbR = scoreboardMaterial:GetParam(Lotus_Game.TINT_COLOR, 1)
    local sbG = scoreboardMaterial:GetParam(Lotus_Game.TINT_COLOR, 2)
    local sbB = scoreboardMaterial:GetParam(Lotus_Game.TINT_COLOR, 3)
    if not IsNull(worldTransmissionMaterial) then
        local w = 1.0
        while w > 0.0 do
            w = Clamp(w - (DeltaTime() * 3), 0.0, 1.0)
            local fade = SmoothStep(w)
            _T.CorpusArenaScreenScoreFade = (1-fade)*255
            if fadeWithTintColor then
                worldTransmissionMaterial:SetParam(Lotus_Game.TINT_COLOR, 1, 1, 1, fade)
                scoreboardMaterial:SetParam(Lotus_Game.TINT_COLOR, sbR, sbG, sbB, (1-fade) * scoreBgMaxAlpha)
            else
                worldTransmissionMaterial:SetParam(sUnlitAtten, fade)
                scoreboardMaterial:SetParam(sUnlitAtten, 1-fade)
            end
            worldTransmissionMaterial:SetParam(sRippleScale, RippleStart.z + RippleStart.x * (1 - fade), RippleStart.z + RippleStart.y * (1 - fade))
            for i=1, #supportMaterials do
                if not IsNull(supportMaterials[i]) then
                    supportMaterials[i]:SetParam(sUnlitAtten, fade)
                end
            end
            Sleep(0)
        end
    end
end
