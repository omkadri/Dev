-- vtxScaling Variables
DoScaling = true
DoScalingLerp = false
ScalingTimeLength = 1
ScalingStart = Vector(1,1,1)
ScalingEnd = Vector(2,3,2)
ScalingDelay = 0
ScaleStart = 0.2
ScaleEnd = 1
-- UnlitAtten Fade
DoUnlitFading = true
UAParam = Symbol("UnlitAtten")
UADelay = 0
UATimeLength = 1
UAStart = 1
UAEnd = 0
destroyAtEnd = false
DoScalesFade = false

local mVScalesFade = Symbol("vScalesFade")
local EASING = require "Lotus.Scripts.Libs.EasingLib"

-- Combine Functions
function Combined(deco)
    if DoScaling == true then
        deco:ScriptRunChildScript(Symbol("vtxScaling"), false)
    end
    if DoUnlitFading == true then
        deco:ScriptRunChildScript(Symbol("UnlitAttenFade"), false)
    end
end

-- Combine Functions
function CombinedExpoFade(deco)
    if DoScaling == true then
        deco:ScriptRunChildScript(Symbol("vtxScaling"), false)
    end
    if DoUnlitFading == true then
        deco:ScriptRunChildScript(Symbol("UnlitAttenFadeExpo"), false)
    end
end

-- Scale mesh
function vtxScaling(deco)
    Sleep(ScalingDelay)
    local t = 0
    local val = Vector()
    val.x = ScalingStart.x
    val.y = ScalingStart.y
    val.z = ScalingStart.z
    local SChange = ScalingEnd - ScalingStart
    while t < ScalingTimeLength do
        if DoScalingLerp == false then
            val = EASING.outExpo(t, ScalingStart, SChange, ScalingTimeLength)
        else
            val.x = Lerp(ScalingStart.x, ScalingEnd.x, t)
            val.y = Lerp(ScalingStart.y, ScalingEnd.y, t)
            val.z = Lerp(ScalingStart.z, ScalingEnd.z, t)
        end        
        deco:SetMaterialParam(Lotus_Game.V_SCALES, val.x, val.y, val.z)
        t = t + DeltaTime()
        Sleep(0)
    end
end

-- Fade UnlitAtten
function UnlitAttenFade(deco)
    Sleep(UADelay)
    local t = 0
    local val
    while t < UATimeLength do
        val = Lerp(UAStart, UAEnd, t/UATimeLength)
        deco:SetMaterialParam(UAParam, val)
        t = t + DeltaTime()
        Sleep(0)
    end
end

-- Fade UnlitAtten
function UnlitAttenFadeExpo(deco)
    Sleep(UADelay)
    local t = 0
    local val
    while t < UATimeLength do
        val = EASING.outExpo(t, UAStart, UAEnd - UAStart, UATimeLength)
        deco:SetMaterialParam(UAParam, val)
        t = t + DeltaTime()
        Sleep(0)
    end
    if destroyAtEnd then
        deco:Destroy()
    end
end

function EaseOutScale(deco)
    if ScalingDelay > 0 then
        Sleep(ScalingDelay)
    end
    
    local t = 0
    local val
    while t < ScalingTimeLength do
        val = EASING.outExpo(t, ScaleStart, ScaleEnd - ScaleStart, ScalingTimeLength)
        if DoScalesFade then
            deco:SetMaterialParam(mVScalesFade, val)
        else
            deco:SetMeshScale(val, true)
        end
        t = t + DeltaTime()
        Sleep(0)
    end
    
    if destroyAtEnd then
        deco:Destroy()
    end
end
