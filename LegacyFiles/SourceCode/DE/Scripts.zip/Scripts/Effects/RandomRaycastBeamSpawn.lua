childBeamType = Type()
beamEndEffect = Type()
BeamEndPoint = Vector()
BeamEndObject = Instance()
checkParticleQuality = true
useEnergyLevels = false
twoEnergyType = Type()

local raycastIgnoreTypes = {
    WeakResource("/EE/Types/Game/Avatar"),
    WeakResource("/EE/Types/Engine/HitProxy"),
    WeakResource("/EE/Types/Physics/Ragdoll"),
    WeakResource("/EE/Types/Game/PickUp")
}

local function MinimumDistRand(min, max)
    local minDistance = 0
    if _T.RandomBeamSpawnDistOverride then
        minDistance = _T.RandomBeamSpawnDistOverride
    end
    
    local val = Random(min, max)
    if val < 0 then
        return val - minDistance
    else
        return val + minDistance
    end
end

local function GetNearbyPoint(pos)
    local toPos = Vector(pos.x + MinimumDistRand(-6,6), pos.y - math.random(-6,6), pos.z + MinimumDistRand(-6,6))
    local rayCastHit = Vector()
    local count = 0
    while count < 3 do --Max raycasts before this one fails
        if gRegion:RaycastIgnoreTypes(pos, toPos, raycastIgnoreTypes, nil, rayCastHit) then
            count = 5
        else
            count = count + 1
            toPos = Vector(pos.x + MinimumDistRand(-5,5), pos.y + math.random(-5,5), pos.z + MinimumDistRand(-5,5))
        end
    end
    return rayCastHit
end

function OnDecoEffects(deco)

    Sleep(0.2)

    if IsNull(gClient) or IsNull(deco) then
        return
    end

    Engine.EnableZoneCull(deco)

    if checkParticleQuality then
        local graphicsSys = gClient:GetGraphicsSys()
        local customDisplaySettings = graphicsSys:GetCustomDisplaySettings()
        local pQ = customDisplaySettings.particleSysQuality
        if IsNull(pQ) then
            pQ = 1
        end
        if pQ == 0 then
            return
        end
    end
    
    local delay = 0.5
    local beam = nil
    local beamTwo = nil
    local wave = Vector()
    local currentBeam = nil
    local pickup = nil
    local twoEnergyFX = nil
    local reachedFullEnergy = false
    
    if useEnergyLevels then
        while (not reachedFullEnergy) do
            if IsNull(pickup) then
                pickup = deco:GetAttachParent()
            end

            if not IsNull(pickup) then
                local count = pickup:GetPickUpCount()
                if count == 2 and IsNull(twoEnergyFX) then -- at 2 energy we will attach another effect
                    twoEnergyFX = deco:Attach(twoEnergyType, EMPTY_SYMBOL)
                elseif count >= 3 then -- only at full energy we will show the rays
                    reachedFullEnergy = true
                end
            end
            Sleep(0)
        end
    end

    while not IsNull(deco) do
        delay = Random(0.2, 0.3)
        local vec = Vector()
            
        --Create beam
        if IsNull(beam) then
            beam = deco:Attach(childBeamType, EMPTY_SYMBOL, vec)
            currentBeam = beam
        end
        
        if IsNull(beamTwo) then
            beamTwo = deco:Attach(childBeamType, EMPTY_SYMBOL, vec)
        end
        
        local newEndPoint = GetNearbyPoint(deco:GetSimPosition())
        if not IsNull(currentBeam) then
            if newEndPoint == ZERO_VECTOR then
                currentBeam:SetVisibility(false, false)
            else
                currentBeam:SetVisibility(true, false)
                currentBeam:SetEndPoint(newEndPoint)
                gRegion:CreateNano(beamEndEffect, newEndPoint, ZERO_ROTATION)
                if currentBeam == beam then
                    currentBeam = beamTwo
                else
                    currentBeam = beam
                end

                if _T.RandomBeamSpawnCallback then
                    _T.RandomBeamSpawnCallback(newEndPoint)
                end
            end
            
            wave = Vector(math.random() * .8 - 0.4, math.random() * .8 - 0.4, math.random() * .8 - 0.4)
            currentBeam:SetWaveAmplitude(wave)
        end
        Sleep(delay)
    end
end

function EnvironmentBeamEffect(beam)
    local newEndPoint = GetNearbyPoint(beam:GetSimPosition())
    if newEndPoint == ZERO_VECTOR then
        beam:Destroy()
    else
        beam:SetEndPoint(newEndPoint)
        gRegion:CreateNano(beamEndEffect, newEndPoint, ZERO_ROTATION)
        if _T.RandomBeamSpawnCallback then
            _T.RandomBeamSpawnCallback(newEndPoint)
        end
    end
end

function SetBeamEndPoint(beam)
    beam:SetEndPoint(BeamEndPoint)
end

function SetBeamEndPointRelative(beam)
    local beamStart = beam:GetPosition()
    local endHere = beamStart + BeamEndPoint
    beam:SetEndPoint(endHere)
end

function SetBeamEndToObject(beam)
    local EndPointObject = BeamEndObject:GetPosition()
    beam:SetEndPoint(EndPointObject)
end
