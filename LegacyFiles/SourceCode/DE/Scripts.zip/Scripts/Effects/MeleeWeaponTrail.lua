DoCustomColor = true

TimeLength = 0.3
Delay = 0
Param = Symbol("BlueClipThreshold")
OriginalValue = 1
NewValue = 0
ParamTwo = Symbol("UnlitAtten")
OriginalValueTwo = 2
NewValueTwo = 0
twoPointOh = false
animSpeed = 1.0

function MeleeWeaponTrail(deco)
    local swingSpeed = 1.0
    if DoCustomColor == true then
        local lotusAvatar = deco:GetCreator()
        if IsNull(lotusAvatar) then
            lotusAvatar = deco:GetAttachParent()
        end
        if not IsNull(lotusAvatar) then
            while true do
                local parent = lotusAvatar:GetAttachParent()
                if IsNull(parent) or parent == lotusAvatar then
                    break
                end
                lotusAvatar = parent
            end
        end
        if not IsNull(lotusAvatar) then
            local meleeweapon = lotusAvatar:InventoryControl():GetMeleeWeapon()
            if not IsNull(meleeweapon) then
                local playerCustomization = meleeweapon:GetCustomization()
                swingSpeed = meleeweapon:GetFireRate()
                local colors = playerCustomization:GetColors(Lotus_Game.PrimaryColors)
                if colors:Initialized(Lotus_Game.EnergyColor) then
                    local energyColor = colors.mEnergyColor
                    deco:SetMaterialParam(Lotus_Game.TINT_COLOR, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
                end
            else
                deco:SetMaterialParam(Lotus_Game.TINT_COLOR, 255, 0, 255, 1)
            end
        end
    end
    deco:SetMaterialParam(Param, OriginalValue)
    deco:SetMaterialParam(ParamTwo, OriginalValueTwo)

    Sleep(Delay)
    local t = 0
    local val
    local valTwo
    swingSpeed = swingSpeed * animSpeed
    if twoPointOh then -- toggle for now to not break other fx
        local detached = false
        while t < (TimeLength * 3) do
            val = 1 - t/TimeLength;
            deco:SetMaterialParam(Param, val)
            --valTwo = math.min(1, 3 - t / TimeLength)
            --deco:SetMaterialParam(ParamTwo, valTwo)
            t = t + DeltaTime() * swingSpeed
            if not detached and (t > TimeLength) then
                deco:Unattach()
                detached = true
            end
            Sleep(0)
        end
    else
        while t < TimeLength do
            val = Lerp(OriginalValue, NewValue, t/TimeLength)
            valTwo = Lerp(OriginalValueTwo, NewValueTwo, t/TimeLength)
            deco:SetMaterialParam(Param, val)
            deco:SetMaterialParam(ParamTwo, valTwo)
            t = t + DeltaTime() * swingSpeed
            Sleep(0)
        end
    end
    deco:Destroy()
end