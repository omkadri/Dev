lifeSpan = 10
unlitAtten = 1

function FlareFadeIn(flare)
    
    local t = 0
    while t<= lifeSpan do
        --flare:SetMaterialParam(Symbol("UnlitAtten"),t*unlitAtten)
        flare:SetOpacity(t)
        t = t + DeltaTime()
    end
end