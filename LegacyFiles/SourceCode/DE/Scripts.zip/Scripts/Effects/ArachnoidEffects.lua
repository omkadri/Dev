chargeUpTime = 1.5
panStart = 0.0
panEnd = 0.8

local sUV_OFFSET = Symbol("uvOffsets")

function ChargeUpFade(deco)
    local t = 0
    while t < 1 do
        deco:SetMaterialParam(sUV_OFFSET, 0, 0, Lerp(panStart, panEnd, t), 0)
        t = t + DeltaTime() / chargeUpTime
        Sleep(0)
    end
end