Delay = 0
DoScale = true
ScaleParam = String("vScales")
ScaleTimeLength = 4
ScaleStartEndVal = Vector(0.5,0.5,0.5)
ScalePeak = 1
ScalePeakVal = Vector(1,1,1)
ScalePeakEnd = 2
destroyAtEnd =  true
DebugPlease = false
DoUnlitAtten = true
UAStartEndVal = 0
UATimeLength = 1
UAPeak = 1
UAPeakVal = 1
UAPeakEnd = 2
UAParam = String("UnlitAtten")
Timelength = 2
ScaleStart = 0.5
ScaleEnd = 1

local EASING = require "Lotus.Scripts.Libs.EasingLib"

-- sinusoidal easing out - decelerating to zero velocity
local function easeOutSine(t, b, c, d)
    return c * math.sin(t/d * (math.pi/2)) + b;
end

-- sinusoidal easing in - accelerating from zero velocity
local function easeInSine(t, b, c, d)
    return -c * math.cos(t/d * (math.pi/2)) + c + b;
end

function Combined(deco)
    Sleep(Delay)
    if DoScale == true then
        deco:ScriptRunChildScript(Symbol("ScaleFlatPeak"), false)
    end
    if DoUnlitAtten == true then
        deco:ScriptRunChildScript(Symbol("FadeFlatPeak"), false)
    end
end

function ScaleFlatPeak(deco)
    local t = 0
    local fading = 0
    local val = Vector(1,1,1)
    local StateDuration = 0
    local state

    while t < ScaleTimeLength do
        if t < ScalePeak then
            StateDuration = ScalePeak
            fading = t
            state = 1
            val.x = easeOutSine(fading, ScaleStartEndVal.x, ScalePeakVal.x - ScaleStartEndVal.x, StateDuration)
            val.y = easeOutSine(fading, ScaleStartEndVal.y, ScalePeakVal.y - ScaleStartEndVal.y, StateDuration)
            val.z = easeOutSine(fading, ScaleStartEndVal.z, ScalePeakVal.z - ScaleStartEndVal.z, StateDuration)
            else if t < ScalePeakEnd then
                StateDuration = (ScaleTimeLength - ScalePeak) - (ScaleTimeLength - ScalePeakEnd)
                fading = 0
                val.x = ScalePeakVal.x
                val.y = ScalePeakVal.y
                val.z = ScalePeakVal.z
                state = 2
            else
                StateDuration = ScaleTimeLength - ScalePeakEnd
                fading = t - ScalePeakEnd
                state = 3
                val.x = easeInSine(fading, ScalePeakVal.x, ScaleStartEndVal.x - ScalePeakVal.x, StateDuration)
                val.y = easeInSine(fading, ScalePeakVal.y, ScaleStartEndVal.y - ScalePeakVal.y, StateDuration)
                val.z = easeInSine(fading, ScalePeakVal.z, ScaleStartEndVal.z - ScalePeakVal.z, StateDuration)
            end
        end
        if DebugPlease == true then
            print("STATE", state)
            print("t:", t)
            print("StateDuration:", StateDuration)
            print("fading:", fading)
        end
        deco:SetMaterialParam(Lotus_Game.V_SCALES, val.x, val.y, val.z)
        t = t + DeltaTime() 
        Sleep(0)
    end        
end

function FadeFlatPeak(deco)
    local t = 0
    local fading = 0
    local val = 0
    while t < UATimeLength do
        if t < UAPeak then
            fading = t/UAPeak
        else if t > UATimeLength and t < UAPeakEnd then
                fading = 0
            else
                fading = 1 - (t-UAPeakEnd)/(UATimeLength-UAPeakEnd)
            end
        end
        if fading < 0 then
                fading = 0
            else if fading > 1 then
                fading = 1
            end
        end
        val = Lerp(UAStartEndVal, UAPeakVal, fading)
        if DebugPlease == true then
            print("value: ", val, "\n fading: ", fading)
        end
        deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, val)
        t = t + DeltaTime() 
        Sleep(0)
    end
    
    if destroyAtEnd and not IsNull(deco) then
        deco:Destroy()
    end
end

function EaseMeshScaleFade(deco)
    local t = 0
    local val = 0
    while t < Timelength do
        val = EASING.outExpo(t, ScaleStart, ScaleEnd - ScaleStart, Timelength)
        deco:SetMeshScale(val, true)
        t = t + DeltaTime()
        Sleep(0)
    end
end
