DebugLog = false
TintDelay = 0
TintTag = Symbol("CleanWater")
TintTimelength = 1
TintStart = Color(255, 0, 0, 255)
TintEnd = Color(255, 255, 0, 255)
fluidDecos = {Instance()}
indexLights = {Instance()}
ColorParam = Symbol("BaseColor")

local COLOR_UTIL = require "Lotus.Scripts.Effects.EffectsColorUtilities"


function CleanRefreshingWater()
    Sleep(TintDelay)
    local rArray = gRegion:FindTagged(TintTag)
    if IsNull(rArray) then
        return
    end
        
    local t = 0
    local tmpColor = Color()
    if DebugLog == true then
        print(#rArray)
    end

    while t < TintTimelength do
        tmpColor.red = Lerp(TintStart.red, TintEnd.red, t/TintTimelength)
        tmpColor.green = Lerp(TintStart.green, TintEnd.green, t/TintTimelength)
        tmpColor.blue = Lerp(TintStart.blue, TintEnd.blue, t/TintTimelength)
--~         tmpColor.alpha = Lerp(TintStart.alpha, TintEnd.alpha, t/TintTimelength)
        
        if DebugLog == true then
            print(ColorParam, tmpColor.red, tmpColor.green, tmpColor.blue, tmpColor.alpha)
        end
        
--~         tmpColor.red = tmpColor.red/255
--~         tmpColor.green = tmpColor.green/255
--~         tmpColor.blue = tmpColor.blue/255
--~         tmpColor.alpha = tmpColor.alpha/255
        
        for i = 1, #rArray do
            local temp = rArray[i]
            temp:SetMaterialParam(ColorParam, tmpColor.red/255, tmpColor.green/255, tmpColor.blue/255, 1)
            --temp:SetMaterialParam(ColorParam, tmpColor.red, tmpColor.green, tmpColor.blue, tmpColor.alpha)
        end
        
        t = t + DeltaTime()
        Sleep(0)
    end
end

function FluidTransition()
    Sleep(TintDelay)
    local rArray = fluidDecos

    local t = 0
    local tmpColor = Vector()
    local tAlpha = 1
        
    while t < TintTimelength do
        tmpColor.x = Lerp(TintStart.red, TintEnd.red, t/TintTimelength)
        tmpColor.y = Lerp(TintStart.green, TintEnd.green, t/TintTimelength)
        tmpColor.z = Lerp(TintStart.blue, TintEnd.blue, t/TintTimelength)
        tAlpha = Lerp(TintStart.alpha, TintEnd.alpha, t/TintTimelength)
    
        for i = 1, #indexLights do
            local temp = indexLights[i]
            temp:SetmpColor(Color(tmpColor.x, tmpColor.y, tmpColor.z, 1))
        end
        
        tmpColor.x = COLOR_UTIL.SRGBToLinear(tmpColor.x)
        tmpColor.y = COLOR_UTIL.SRGBToLinear(tmpColor.y)
        tmpColor.z = COLOR_UTIL.SRGBToLinear(tmpColor.z)

        for i = 1, #rArray do
            local temp = rArray[i]
            temp:SetMaterialParam(Lotus_Game.TINT_COLOR, tmpColor.x, tmpColor.y, tmpColor.z, tAlpha/255)
        end
    
        t = t + DeltaTime()
        Sleep(0)
    end
end
