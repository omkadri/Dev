lightType = Symbol()
lightRadiusSearch = 30
lightDelay = 1
lightBrightness = 1
lightTimeLength = 1

function ToggleLights(entity) 
 
    local lightArray = gRegion:FindTaggedInRadius(lightType, entity:GetPosition(), 0, lightRadiusSearch)

    if not IsNull(lightArray) then 
        for i=1, #lightArray do 
            local temp = lightArray[i] 
--            temp:ToggleLights(
            temp:SetBrightness(lightBrightness)
            Sleep(lightDelay)
            local t = 0
            local val = lightBrightness
            while t < lightTimeLength do
                val = Lerp(lightBrightness, 0, t/lightTimeLength)
                temp:SetBrightness(val)
                t = t + DeltaTime()
                Sleep(0)
            end
        end 
    end 
end