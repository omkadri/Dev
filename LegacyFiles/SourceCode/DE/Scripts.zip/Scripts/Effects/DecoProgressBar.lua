barGranularity = 2
materialParam = Symbol("BlueClipThreshold")
triggeredFadeTag = Symbol("TurnMeOn")
lightsTag = Symbol("LightsOn")
ventTag = Symbol("ventSteam")
tubeTag = Symbol("tubeSteam")
local ventVis = false
local tubeVis = false
local tintParam = Symbol("TintColor")
startColor = Color()
endColor = Color()
local hasStarted = false

function UpdateMaterialParamFromOwnerTimer(owner)
    local timerName = Symbol(owner:GetFullName())
    
    local topVentSteam = gRegion:FindFirstTaggedInRadius(ventTag, owner:GetPosition(), 0, 7)
    local tubeVentSteam = gRegion:FindFirstTaggedInRadius(tubeTag, owner:GetPosition(), 0, 5)
    local initMachines = gRegion:FindTaggedInRadius(triggeredFadeTag, owner:GetPosition(), 0, 8)
    local initLight = gRegion:FindFirstTaggedInRadius(lightsTag, owner:GetPosition(), 0, 8)

    owner:SetMaterialParam(materialParam, 1)

    while not IsNull(owner) and not IsNull(gGameRules) do
        if gGameRules:HasMissionTimer(timerName) then
            local time = gGameRules:GetMissionTimeLeft(timerName)
            local maxTime = gGameRules:GetNetPersistentVar(timerName)
            local value = math.floor(1 + ((time / maxTime) * barGranularity)) / barGranularity
            owner:SetMaterialParam(materialParam, value-.05)
            
            if value == 1 then -- empty, enable top vent
                if not hasStarted then
                    hasStarted = true
                    for i = 1, #initMachines do
                        initMachines[i]:PlayTriggeredFade()
                    end
                    if not IsNull(initLight) then
                        initLight:FirePort("TurnOn")
                    end
                end
                owner:SetMaterialParam(tintParam, startColor.red/255, startColor.green/255, startColor.blue/255, startColor.alpha/255)
                if not IsNull(tubeVentSteam) and tubeVis == true then
                    tubeVentSteam:Disable()
                    tubeVis = false
                end
                if not IsNull(topVentSteam) and ventVis == false then
                    topVentSteam:Enable()
                    ventVis = true
                end
            end
            if value == 0 then -- ready
                owner:SetMaterialParam(tintParam, endColor.red/255, endColor.green/255, endColor.blue/255, endColor.alpha/255)
                if not IsNull(tubeVentSteam) and tubeVis == false then
                    tubeVentSteam:Enable()
                    tubeVis = true
                end
                if not IsNull(topVentSteam) and ventVis == true then
                    topVentSteam:Disable()
                    ventVis = false
                end
            end
        end
        Sleep(0)
    end
end