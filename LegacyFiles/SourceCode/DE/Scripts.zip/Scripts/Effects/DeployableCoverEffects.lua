effectDecoType = Type()
attachedDecoType = Type()

function AnimDeco(spawner)
    local avatar = spawner:GetAttachRoot()
    if IsNull(avatar) then
        return
    end

    local aDeco = avatar:GetAttachment(attachedDecoType)
    if IsNull(aDeco) then
        return
    end
    local effectDeco = avatar:Attach(effectDecoType, aDeco:GetAttachBone(), aDeco:GetLocalAttachPosition(), aDeco:GetLocalAttachRotation())
    
    avatar:SuspendScriptUntilAnimEvent("TransferCoverAttachment", 0.2)
    if not IsNull(effectDeco) and not IsNull(avatar)then
        effectDeco:AttachTo(avatar, Symbol("GAME_L1_WEAPON1"))
        effectDeco:SetAttachLocalSpace(ZERO_VECTOR, ZERO_ROTATION)
    end
end