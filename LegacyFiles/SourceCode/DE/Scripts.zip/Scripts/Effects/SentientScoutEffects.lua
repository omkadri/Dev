maxValue = 3.0
hitValue = 0.5
fadeSpeed = 1
newColor = Color()
headDecoType = Type()

local sUnlitAtten = Symbol("UnlitAtten")

function OnDamaged(avatar)
    if not gRegion:IsMaster() then
        return
    end

    if IsNull(avatar) or _T.sentientScoutGlow == nil then
        return
    end
    
    if IsNull(_T.sentientScoutGlow[avatar:GetInstance()]) then
        _T.sentientScoutGlow[avatar:GetInstance()] = 0
    end
    
    _T.sentientScoutGlow[avatar:GetInstance()] = math.min(maxValue, _T.sentientScoutGlow[avatar:GetInstance()] + hitValue)
end

function SentientDamageGlow(avatar)
    Sleep(1)
    if IsNull(avatar) then
        return
    end
    
    avatar:AddDamageCallback("OnDamaged") 
    
    local instanceID = avatar:GetInstance()
    
    if _T.sentientScoutGlow == nil then
        _T.sentientScoutGlow = {}
    end
    
    if _T.sentientScoutGlow[instanceID] == nil then
        _T.sentientScoutGlow[instanceID] = 0.05
    end
    
    local allDecos = avatar:GetAllAttachments(gDecorationType)
    
    while not IsNull(avatar) do
        local t = math.max(0, _T.sentientScoutGlow[instanceID])
        
        if t > 0 then
            avatar:SetMaterialParam(sUnlitAtten, 1.0 + t)
            avatar:SetDissolve(0.5 * t / maxValue)
            for i=1, #allDecos do
                if not IsNull(allDecos[i]) then
                    allDecos[i]:SetMaterialParam(sUnlitAtten, 1.0 + t)
                end
            end
            Sleep(0)
            _T.sentientScoutGlow[instanceID] = _T.sentientScoutGlow[instanceID] - DeltaTime() * fadeSpeed
        else
            Sleep(0)
        end
    end
end

function OnScanned(spawner)
    Sleep(0)
    local avatar = spawner:GetAttachRoot()
    if IsNull(avatar) then
        return
    end
    avatar:SetMaterialParam(Lotus_Game.TINT_COLOR, newColor.red / 255, newColor.green / 255, newColor.blue / 255, 1)
    local deco = avatar:GetAttachment(headDecoType)
    if not IsNull(deco) then
        deco:SetMaterialParam(Lotus_Game.TINT_COLOR, newColor.red / 255, newColor.green / 255, newColor.blue / 255, 1)
    end
    local pSys = avatar:GetAllAttachments(gParticleSysType)
    for i=1, #pSys do
        pSys[i]:SetColorMinMax(newColor, newColor)
    end
    local flares = avatar:GetAllAttachments(gLensFlareType)
    for i=1, #flares do
        flares[i]:SetTint(newColor)
    end
end