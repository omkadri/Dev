startFx = Type()
effectDecoType = Type()


function Tackle(behavior)
    local avatar = behavior:GetAvatar()
    if IsNull(avatar) then
        return
    end
    avatar:Attach(startFx, EMPTY_SYMBOL)
    avatar:SuspendScriptUntilAnimEvent("ChargeStart", 1.5)
    local t = 0
    while t < 1 and not IsNull(behavior) do
        gRegion:CreateEntity(effectDecoType, avatar:GetPosition(), avatar:GetSimRotation())
        Sleep(0.05)
        t = t + DeltaTime() * 4
    end
end

function DecoFade(deco)
    Sleep(0)
    local t = 0
    while t < 1 do
        deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, t)
        Sleep(0)
        t = t + DeltaTime() * 4
    end
    local speed = Random(.6, 1.2)
    while t > 0 do
        deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, t)
        Sleep(0)
        t = t - DeltaTime() * speed
    end
    deco:Destroy()
end