baseEmissiveAtten = 3.0
sentientDeco = Type()
burstEffect = Type()

local attachBone = Symbol("GAME_C1_HIP1") 
local CLOAKVECTOR = Symbol("CloakVector")
local EMISSIVEMAPATTEN = Symbol("EmissiveMapAtten")
local sValkyr = Symbol("ValkyrDeco")

local function DissolvePosLoop(boneName, parent) --Update material with bone's position
    local vec = parent:GetBonePosition(boneName)
    parent:SetMaterialParam(CLOAKVECTOR, vec.x, vec.y, vec.z, 0)
end

function DissolveThem(spawner)
    Sleep(0)
    local entity = spawner:GetAttachParent()
    if IsNull(entity) then
        return
    end
    
    local t = 0
    while t < 1 and not IsNull(entity) do
        entity:SetDissolve(t)
        DissolvePosLoop(attachBone, entity)  --Only works on Pus, pbr material doesn't have this cloak
        t = t + DeltaTime() * 0.25
        Sleep(0)
    end
end

function AncientFade(spawner)
    Sleep(0)
    local entity = spawner:GetAttachParent()
    if IsNull(entity) then
        return
    end

    local t = 1
    while t > 0 and not IsNull(entity) do
        entity:SetMaterialParam(EMISSIVEMAPATTEN, t * 5)
        t = t - DeltaTime() * 0.55
        Sleep(0)
    end
end

function ResetDissolve(infestedJerk)
    --sometimes their dissolve gets buggered up
    if IsNull(infestedJerk) then
        return
    end
    infestedJerk:SetMaterialParam(EMISSIVEMAPATTEN, baseEmissiveAtten)
    infestedJerk:SetDissolve(0)
end

function SpawnSentientsInBeam(beamDeco)
    Sleep(0)
    local pos = beamDeco:GetPosition()
    local rot = beamDeco:GetSimRotation()
    local dir = AngleToDirection(rot)
    local t = 0
    local startScale = 0.5
    local finalScale = 1.4
    local numSpawned = 0
    local numToSpawn = 85
    local lengthOfBeam = 20
    local offsetVec = Vector()
    local newSpawnPos = Vector()
    while numSpawned < numToSpawn do
        offsetVec.x = 0
        offsetVec.y = 0
        offsetVec.z = numSpawned * lengthOfBeam / numToSpawn
        offsetVec = RotateVector(offsetVec, rot)
        VectorAdd(newSpawnPos, pos, offsetVec)
        
        local newScale = Lerp(startScale, finalScale, numSpawned / numToSpawn)
        newSpawnPos.y = newSpawnPos.y - 0.8 * newScale
        
        local deco = gRegion:CreateEntity(sentientDeco, pos + dir - Vector(0, 0.4, 0), rot)
        if not IsNull(deco) then
            --deco:SetMeshScale(newScale)
        end
        numSpawned = numSpawned + 1
        t = t + DeltaTime()
        Sleep(0.4)
    end
end

function SentientMotion(deco)
    local pos = deco:GetPosition()
    local rot = deco:GetSimRotation()
    local dir = AngleToDirection(rot)
    local t = 0
    local startScale = 0.5
    local finalScale = 1.4
    local lengthOfBeam = 30
    local endPos = pos + Vector(dir.x * lengthOfBeam, dir.y * lengthOfBeam, dir.z * lengthOfBeam)
    endPos.y = endPos.y - 0.8 * (finalScale - startScale)
    local currentPos = Vector()
    local didBurst = false
    local groundPlane = -1.88
    local valDeco = gRegion:FindFirstTagged(sValkyr)
    while t < 1 and not IsNull(deco) do
        currentPos = LerpVector(pos, endPos, t)
        deco:SetPosition(currentPos)
        deco:SetMeshScale(Lerp(startScale, finalScale, t))
        if not didBurst and not IsNull(valDeco) then
            local valPos = valDeco:GetPosition()
            if valPos.z < currentPos.z and not didBurst then
                currentPos.y = groundPlane --Force to the ground
                currentPos.z = valPos.z
                currentPos.x = valPos.x
                --currentPos.z = currentPos.z + 1.5 --Move it further down the line
                gRegion:CreateEntity(burstEffect, currentPos, Rotation(0, -90, 0))
                didBurst = true
            end
        end
        Sleep(0)
        t = t + DeltaTime()*1.5
    end
end