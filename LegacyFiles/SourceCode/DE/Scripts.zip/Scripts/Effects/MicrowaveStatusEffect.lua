burstEffect = Type()

local worldParam = Symbol("impactPoint")
local CLOAKHDR = Symbol("CloakHDR")
local CLOAKVECTOR = Symbol("CloakVector")
local LowColorParam = Symbol("LowColor")
local HighColorParam = Symbol("HighColor")
    
local EFFECTS_UTIL = require "Lotus.Scripts.Effects.EffectsUtilities"

local effectTag = Symbol("EffectsDeco")

local function AllAttachments(avatar)
    local attachments = avatar:GetAllAttachments(gDecorationType)
    local finalItems = {}
    for i, temp in ipairs(attachments) do
        local material = temp:GetMaterialInSlot(0)
        if not IsNull(material) then
            local atten = material:GetParam(Lotus_Game.UNLIT_ATTEN, 0)
            if (atten > 100) and not (temp:GetTag() == effectTag) then -- If these are true, it's an effect, so don't attach
                table.insert(finalItems, temp)
            end
        end
    end
    table.insert(finalItems, avatar)
    return finalItems
end

local function DissolvePosLoop(boneName, parent) --Update material with bone's position
    local vec = parent:GetBonePosition(boneName)
    parent:SetMaterialParam(CLOAKVECTOR, vec.x, vec.y, vec.z, 2.5)
end

function MicrowaveTheEnemy(spawner)
    Sleep(0)
    local bone = spawner:GetAttachBone()
    local avatar = spawner:GetAttachRoot()
    
    local weapon = spawner:GetCreator()
    local creatorAvatar = nil
    local energyColor = Color(26, 241, 201, 255)
    if not IsNull(weapon) and weapon:IsA(gLotusWeaponType) then
        local playerCustomization = weapon:GetCustomization()
        local colors = playerCustomization:GetColors(Lotus_Game.PrimaryColors)
        if colors:Initialized(Lotus_Game.EnergyColor) then
            energyColor = Color(colors.mEnergyColor)
        end
        creatorAvatar = weapon:GetOwner()
    end

    local fade = {0, 0.28, 0.15, 0}
    local hitRagdoll = false
    local killed = false
    local ragdoll = nil
    local timeLength = 3
    local entity = avatar
    avatar:SetMaterialParam(CLOAKHDR, energyColor.red / 25, energyColor.green / 25, energyColor.blue / 25, 1)
    local t = 0
    local pos = Vector()
    while t < timeLength do
        local val = EFFECTS_UTIL.Piecewise(t / timeLength, fade)

        if not IsNull(avatar) and not IsNull(entity) then
            pos = entity:GetBonePosition(bone)
            DissolvePosLoop(bone, avatar)
            avatar:SetDissolve(val)
            if (avatar:GetHealth() <= 0 and not killed) then
                gRegion:CreateEntity(burstEffect, pos, ZERO_ROTATION, creatorAvatar)
                fade = {0, 0.38, 0.7, 1}
                killed = true
                timeLength = t + 5 --Corpse can stick around a bit
            end
            if (killed and not hitRagdoll and avatar:IsA(gAvatarType)) then --Get the ragdoll
                ragdoll = avatar:GetRagdoll()
                if not IsNull(ragdoll) then
                    hitRagdoll = true
                    entity = ragdoll
                    ragdoll:SetMaterialParam(CLOAKHDR, energyColor.red / 25, energyColor.green / 25, energyColor.blue / 25, 1)
                end
            end
        end
        if not IsNull(ragdoll) then
            ragdoll:SetDissolve(val)
        end
        t = t + DeltaTime()
        Sleep(0)
    end
    if not IsNull(ragdoll) then
        ragdoll:Destroy()
    end
    avatar:SetDissolve(0)
    avatar:SetMaterialParam(CLOAKVECTOR, 0, 0, 0, 0)
    avatar:SetMaterialParam(CLOAKHDR, 0, 0, 0, 1)
    spawner:Destroy()
end

function ProjUpdateWorldPos(projectorArray)
    if IsNull(projectorArray) then
        return
    end
    while not IsNull(projectorArray) do
        local pos = projectorArray[1]:GetSimPosition()
        for i, proj in ipairs(projectorArray) do
            proj:SetMaterialParam(worldParam, pos.x, pos.y, pos.z)
        end
        Sleep(0)
    end
end