Delay = 0
TimeLength = 0.5
yRotStart = 90
yRotEnd = 0
xRot = 0
zRot = 0
SpawnerA = Instance()
SpawnerB = Instance()
AChance = 66

local EASING = require "Lotus.Scripts.Libs.EasingLib"

function MatchRotationToInstance(deco)
    if Delay > 0 then Sleep(Delay) end
    if not IsNull(deco) then
        local t = 0
        local val = 0
        while t < TimeLength do
            -- val = EASING.inSine(t, yRotStart, yRotEnd - yRotStart, TimeLength)
            val = EASING.inOutExpo(t, yRotStart, yRotEnd - yRotStart, TimeLength)
            local rot = Rotation(xRot,val,zRot)
            deco:SetAttachLocalSpace(deco:GetLocalAttachPosition(),rot)
            t = t + DeltaTime()
            Sleep(0)
        end
    end
end

function BurstRandomSpawner()
    local num = math.random(0, 100)
--~     print("Got a", num)
    if num < AChance and not IsNull(SpawnerA) then
        SpawnerA:FirePort("Burst")
    elseif not IsNull(SpawnerB) then
        SpawnerB:FirePort("Burst")
    end
end