minSpeed = 0.1
maxSpeed = 1
minShake = 0.1
maxShake = 1
fadeInTime = 1
fadeOutTime = 1
doIvBag = false
ivStart = 0.05
ivTime = 1
colorCorrection = Resource("/Lotus/Materials/PostFX/RedB_v.png")


katanaWeaponWRes = WeakResource()

local sBlueClip = Symbol("BlueClipThreshold")

function UmbraTransmissionCameraShake()
    local sndInst = _T.UmbraShakeSound
    if IsNull(sndInst) then
        sndInst = _T.TransmissionSoundInstance
    end
    if IsNull(sndInst) then
        return
    end
    
    local cam = gRegion:FindFirstTagged(Symbol("MemoryCamera"))
    local deco = gRegion:FindFirstTagged(Symbol("MedicalDevice"))
    
    local t = 0
    local shakeSpeed = minSpeed
    local shakeAmount = minShake
    local bagTime = 0
    
    while not IsNull(sndInst) do
        t = Clamp(t + DeltaTime() / fadeInTime, 0, 1)
        bagTime = Clamp(bagTime + DeltaTime() / ivTime, 0, 1)
        
        shakeSpeed = Clamp(sndInst:GetCurAmplitude(), 0, 1)
        shakeAmount = Lerp(minShake, maxShake, t)
        
        if not IsNull(cam) then
            cam:SetShakeParams(Lerp(minSpeed, maxSpeed, shakeSpeed), shakeAmount)
        end
        
        if doIvBag and not IsNull(deco) then
            deco:SetMaterialParam(sBlueClip, ivStart + 0.2 * bagTime)
        end
        Sleep(0)
    end
    
    t = 0
    while t < 1 do
        t = Clamp(t + DeltaTime() / fadeOutTime, 0, 1)
        bagTime = Clamp(bagTime + DeltaTime() / ivTime, 0, 1)
        
        if not IsNull(cam) then
            cam:SetShakeParams(minSpeed, Lerp(shakeAmount, minShake, t))
        end
        if doIvBag and not IsNull(deco) then
            deco:SetMaterialParam(sBlueClip, ivStart + 0.2 * bagTime)
        end
        
        Sleep(0)
    end
    
    cam:SetShakeParams(minSpeed, minShake)
end

function CinematicIVDrain(cinematic)
    local deco = cinematic:GetRegionMgr():FindFirstTagged(Symbol("MedicalDevice"))
    local t = 0
    _T.InfWallAdd = 0
    local avatar = gRegion:GetLocalPlayerAvatar()
    if not IsNull(avatar) then
        avatar:CameraControl():PushColorCorrection(colorCorrection, 0.1, 0.2, 3)
    end
    while t < 1 and not IsNull(deco) do
        t = t + DeltaTime() / ivTime
        deco:SetMaterialParam(sBlueClip, 0.75 + 0.25 * t)
        _T.InfWallAdd = t * 0.3
        Sleep(0)
    end
end

function LungeAtIsaah(cinematic)
    local t = 0
    local region = cinematic:GetRegionMgr()
    local postVolume = region:FindFirstTagged(Symbol("MemoryPostProcess"))
    local postProcess = nil
    if not IsNull(postVolume) then
        postProcess = postVolume:GetPostProcessInfo()
    end
    while t < 1 do
        t = t + DeltaTime() * 3
        _T.InfWallAdd = 0.45 + t * 0.15
        if not IsNull(postProcess) then
            postProcess.fade = t
        end
        Sleep(0)
    end
    
    while not IsNull(gRegion:GetPlayingCinematic()) do
        Sleep(0)
    end
    --postProcess.fade = 0
end

function BedSheetUpdate(deco)
    Sleep(0)
    local breathSeq = gRegion:FindFirstTagged(Symbol("BreathSequencer"))
    local t = 0
    local breath = SmoothFloat(0, 0.15)
    local offsetVec = Vector(0, 0.4, -0.35)
    local pos = deco:GetSimPosition() + RotateVector(offsetVec, deco:GetSimRotation())
    deco:SetMaterialParam(Symbol("WorldPos"), pos.x, pos.y, pos.z)
    --Todo, make more good
    while not IsNull(deco) do
        local val = math.sin(t) * 0.5 + 0.5
        if IsNull(breathSeq) then
            breathSeq = gRegion:FindFirstTagged(Symbol("BreathSequencer"))
        else
            local breathingSoundInst = breathSeq:GetSoundInstance()
            if not IsNull(breathingSoundInst) then
                val = breathingSoundInst:GetCurAmplitude()
            end
        end
        breath:SetTargetVal(val)
        breath:Update(DeltaTime())
        local sVal = breath:GetVal()
        deco:SetMaterialParam(Symbol("MeltAtten"), Lerp(0, -0.1, sVal))
        t = t + DeltaTime()
        Sleep(0)
    end
end

function OrdisEyes(deco)
    local eyeL = Symbol("GAME_L1_EYE1")
    local eyeR = Symbol("GAME_R1_EYE1")

    while not IsNull(deco) do
        local lt = Frac(Time() * 0.2)
        local rt = Frac((3.3 + Time()) * 0.2)

        lt = Noise2D(3, 0.5, lt, 0.5)
        rt = Noise2D(3, 0.5, rt, 0.0)

        deco:SetBoneDirectorLocalMultiply(eyeL, Rotation(0, lt * 180,0))
        deco:SetBoneDirectorLocalMultiply(eyeR, Rotation(0, rt * 180,0))

        Sleep(0)
    end
end

function CustomizeKatana(deco)
    Sleep(1)
    local avatar = deco:GetRegionMgr():GetLocalPlayerAvatar()
    if IsNull(avatar) then
        return
    end
    local meleeWeapon = avatar:InventoryControl():GetMeleeWeapon()
    if not IsNull(meleeWeapon) and meleeWeapon:IsA(katanaWeaponWRes) then
        local customization = meleeWeapon:GetCustomization()
        customization:ClearSkins()
        customization:ApplyCustomization(deco)
    end
end