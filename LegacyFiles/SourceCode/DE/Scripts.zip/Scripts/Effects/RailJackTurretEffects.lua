local PLAYER_SKILL_LIB = require "Lotus.Scripts.Libs.PlayerSkillsLib"

transitionEffect = Type()
colorCorrection = Resource()
transitionSoundStart = Resource()
transitionSoundEnd = Resource()
decoForPosition = Instance()
postFxMat = Resource()

-- // PILOT TURRET DEPLOYMENT VARIABLES // --
deployAnim = weakResource()
idleAnim = weakResource()
dismountAnim = weakResource()
deactivatedAnim = weakResource()

local sVignetteAtten = Symbol("VignetteAtten")

-----------------------------------
-- // PILOT TURRET STATE CONTROLS // --

function DeployPilotGuns(avatar, emplacement, virtualGunsInstance)
    if IsNull(virtualGunsInstance) or IsNull(emplacement) then
        return
    end
    virtualGunsInstance:SetVisibility(true, true)
    virtualGunsInstance:PlayAnimation(deployAnim,true,false)
    virtualGunsInstance:PlayAnimation(idleAnim,false,true)
    while emplacement:IsHooked() do
        Sleep(0)
    end
    virtualGunsInstance:PlayAnimation(dismountAnim,true,false)
    virtualGunsInstance:PlayAnimation(deactivatedAnim,false,true)
    virtualGunsInstance:SetVisibility(false, true)
end

------------------------------------

function TurretHarness(avatar, emplacement, virtualGunsInstance)
    if IsNull(avatar) or not avatar:ReplicaLocallyControlled() or IsNull(decoForPosition) or IsNull(virtualGunsInstance) or IsNull(emplacement) then
        --Script is only run locally
        return
    end

    local avatarHasSkills = avatar:IsIntrinsicSkillAbilityAdded(PLAYER_SKILL_LIB.sSkillRJARGimbal)
    if not avatarHasSkills then
        return
    end
    
    local flares = gRegion:FindAll(gLensFlareType, avatar:GetPosition(), 0, 200)
    local lights = gRegion:FindTagged(Symbol("VolumetricLight"))
    local zones = gRegion:FindAll(gZoneAttribsType, avatar:GetPosition(), 0, 100)
    local startPos = avatar:GetPosition()
    
    --Post fx
    local postProcess = gRegion:GetLevelInfo().postProcess
    postProcess.radialBlurStrength = 0.15
    local cameraControl = avatar:CameraControl()
    --cameraControl:PushColorCorrection(colorCorrection, 0.0, -1.0, 0.0)

    avatar:SetUseZoneDissolve(false)
    emplacement:SetUseZoneDissolve(false)
    virtualGunsInstance:SetUseZoneDissolve(false)
    virtualGunsInstance:SetUseParentVisibility(false)
    local children = virtualGunsInstance:GetAllAttachments(gEntityType)
    for i=1, #children do
        children[i]:SetUseZoneDissolve(false)
    end
    avatar:Attach(transitionEffect, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, avatar)
    if not IsNull(transitionSoundStart) then
    	avatar:PlaySoundForEntityOnly(transitionSoundStart,false)
    end
    local timeLength = 1.5
    local t = 0
    local appliedIdle = false
    while t < timeLength do
        local val = t / timeLength
        for i, temp in ipairs(zones) do
            if not IsNull(temp) then
                temp:SetZoneDissolve(val)
            end
        end
        --cameraControl:SetColorCorrectionOpacity(colorCorrection, val)
        if not IsNull(postFxMat) then
            --postFxMat:SetParam(sVignetteAtten, 0.25 + 0.5 * val, 0, 0, 0)
        end
        Sleep(0)
        t = t + DeltaTime()
    end
    local backdropZone = decoForPosition:GetZone() --Needs to be a zone that's always visible, or we need to udpate connectivitymgr
    if IsNull(backdropZone) or not backdropZone:HasBackdrop() then
        return
    end
    
    local camera = gRegion:GetGameCamera()
    for i, temp in ipairs(flares) do
        if not IsNull(temp) then
            temp:SetOpacity(0)
        end
    end
    for i, temp in ipairs(lights) do
        if not IsNull(temp) then
            temp:TurnOff()
        end
    end
    for i, temp in ipairs(zones) do
        if not IsNull(temp) then
            temp:SetZoneDissolve(1)
        end
    end

    local quadV0 = Vector()
    local quadV1 = Vector()
    local quadV2 = Vector()
    local sizeX = 28 --Large enough to handle 120 fov
    local sizeY = 22
    local camOffset0 = Vector(-sizeX, sizeY, 0)
    local camOffset1 = Vector(sizeX, sizeY, 0)
    local camOffset2 = Vector(sizeX, -sizeY, 0)
    local camOffsetCenter = Vector(0, 0, 15)
    local camRot = Rotation()
    local camPos = Vector()
    local forwardDir = decoForPosition:GetPosition() - startPos
    Normalize(forwardDir)
    local camDir = Vector()
    local leftVec = CrossProduct(forwardDir, Vector(0, 1, 0))
    local player = gRegion:GetLocalPlayer()
    local isObserving = false
    while emplacement:IsHooked() do
        if not IsNull(player:GetObservedPlayer()) then
            if not isObserving then
                --Make the level visible again so we see the other player
                for i, temp in ipairs(zones) do
                    if not IsNull(temp) then
                        temp:SetZoneDissolve(0)
                    end
                end
                backdropZone:SetExtraBackDropPlane(ZERO_VECTOR, ZERO_VECTOR, ZERO_VECTOR, ZERO_VECTOR)
            end
            isObserving = true
        else
            if isObserving then
                for i, temp in ipairs(zones) do
                    if not IsNull(temp) then
                        temp:SetZoneDissolve(1)
                    end
                end
            end
            isObserving = false
            --Make a quad in camera space as covering everything with a static quad is proving difficult
            if not IsNull(camera) and not IsNull(backdropZone) then
                camRot = camera:GetRotation()
                camPos = camera:GetPosition()
                camDir = AngleToDirection(camRot)
                local d = Dot(camDir, forwardDir)
                if d > 0 then
                    d = d * 2 --May need to shift offsets here
                end
                camOffsetCenter.z = 16 + 0 * d --Push out further when looking forward so weapons don't get clipped
                local sideD = Dot(camDir, leftVec)
    --            camRot.heading = camRot.heading - sideD * 45 --Rotate towards the RJ as that's where we really need to cover things up
                quadV0 = RotateVector(camOffset0, camRot)
                quadV1 = RotateVector(camOffset1, camRot)
                quadV2 = RotateVector(camOffset2, camRot)
                backdropZone:SetExtraBackDropPlane(camPos + RotateVector(camOffsetCenter, camRot), quadV0, quadV1, quadV2)
            end
        end
        Sleep(0)
    end

    if not IsNull(avatar) then
        avatar:Attach(transitionEffect, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, avatar)
        if not IsNull(transitionSoundEnd) then
    		avatar:PlaySoundForEntityOnly(transitionSoundEnd,false)
    	end
    end
    for i, temp in ipairs(flares) do
        if not IsNull(temp) then
            temp:SetOpacity(1)
        end
    end
    for i, temp in ipairs(lights) do
        if not IsNull(temp) then
            temp:TurnOn()
        end
    end
    t = 1
    while t > 0 do
        for i, temp in ipairs(zones) do
            if not IsNull(temp) then
                temp:SetZoneDissolve(t)
            end
        end
        --cameraControl:SetColorCorrectionOpacity(colorCorrection, t)
        if not IsNull(postFxMat) then
            --postFxMat:SetParam(sVignetteAtten, 0.25 + 0.5 * t, 0, 0, 0)
        end
        Sleep(0)
        t = t - DeltaTime() * 0.6
    end
    --Post fx removal
    postProcess = gRegion:GetLevelInfo().postProcess
    postProcess.radialBlurStrength = 0
    --cameraControl:RemoveColorCorrection(colorCorrection)
    if not IsNull(postFxMat) then
        --postFxMat:SetParam(sVignetteAtten, 0.25, 0, 0, 0)
    end
        
    if not IsNull(backdropZone) then
        backdropZone:SetExtraBackDropPlane(ZERO_VECTOR, ZERO_VECTOR, ZERO_VECTOR, ZERO_VECTOR)
    end
    for i, temp in ipairs(zones) do
        if not IsNull(temp) then
            temp:SetZoneDissolve(0)
        end
    end

    avatar:SetUseZoneDissolve(true)
    emplacement:SetUseZoneDissolve(true)
    virtualGunsInstance:SetUseZoneDissolve(true)
    for i, temp in ipairs(children) do
        if not IsNull(temp) then
            temp:SetUseZoneDissolve(true)
        end
    end
end

function ResetTurretEffects(avatar, emplacement, virtualGunsInstance)
    local postProcess = gRegion:GetLevelInfo().postProcess
    postProcess.radialBlurStrength = 0
    local backdropZone = decoForPosition:GetZone() --Needs to be a zone that's always visible, or we need to udpate connectivitymgr
    if not IsNull(backdropZone) then
        backdropZone:SetExtraBackDropPlane(ZERO_VECTOR, ZERO_VECTOR, ZERO_VECTOR, ZERO_VECTOR)
    end
    local zones = gRegion:FindAll(gZoneAttribsType, avatar:GetPosition(), 0, 100)
    for i, temp in ipairs(zones) do
        if not IsNull(temp) then
            temp:SetZoneDissolve(0)
        end
    end

    avatar:SetUseZoneDissolve(true)
    emplacement:SetUseZoneDissolve(true)
    virtualGunsInstance:SetUseZoneDissolve(true)
    local children = virtualGunsInstance:GetAllAttachments(gEntityType)
    for i, temp in ipairs(children) do
        if not IsNull(temp) then
            temp:SetUseZoneDissolve(true)
        end
    end
end