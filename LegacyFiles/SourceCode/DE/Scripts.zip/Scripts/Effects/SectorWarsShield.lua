baseValue = 0.5
hitValue = 5
fadeSpeed = 12
ShieldHitEffect = Type()
beamPos = Vector()
beamEndSearchRadius = 30
endPointTag = Symbol("BeamEndPointTag")
hiddenMaterial = Resource()
useEntityForEndPoint = false

local invulnHealth = 1000000

function FadeBurst(deco)
    local t = 1
    while t > 0 do
        deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, hitValue * t + baseValue)
        t = t - DeltaTime() * fadeSpeed
        Sleep(0)
    end
    deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, baseValue)
end

function OnDamaged(deco, scriptDamageData)
    deco:SetHealth(invulnHealth)
    local graphicsSys = gClient:GetGraphicsSys()
    local customDisplaySettings = graphicsSys:GetCustomDisplaySettings()
    local pQ = customDisplaySettings.particleSysQuality
    if pQ == 0 then
        return
    end
    deco:ScriptRunChildScript(Symbol("FadeBurst"), false)
    local ssd = scriptDamageData
    if not IsNull(ssd) then
        local pos = ssd:GetHitPoint()
        if not IsNull(pos) then
            gRegion:CreateEntity(ShieldHitEffect, pos, ZERO_ROTATION)
        end
    end
end

function ShieldInitiate(deco)
    Sleep(0)
    local graphicsSys = gClient:GetGraphicsSys()
    local customDisplaySettings = graphicsSys:GetCustomDisplaySettings()
    local pQ = customDisplaySettings.particleSysQuality
    if pQ == 0 and not IsNull(hiddenMaterial) then
        deco:SetOverrideMaterial(0, hiddenMaterial, false)
    end
    
    deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, baseValue)
    while not IsNull(deco) do
        Sleep(1)
    end
end

function BeamInitialize(beam)
    Sleep(2)
    local object = gRegion:FindFirstTaggedInRadius(endPointTag, beam:GetSimPosition(), 0, beamEndSearchRadius) 
    if not IsNull(object) then
        if useEntityForEndPoint then
            beam:SetEndPointEntity(object, EMPTY_SYMBOL)
        else
            beam:SetEndPoint(object:GetSimPosition())
        end
    else
        beam:SetEndPoint(beamPos)
    end
end
