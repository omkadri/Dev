-- ramp a material value up or down

TimeLength = 1
Peak = 0.5
PeakValue = 1
ValleyValue = 0
Param = Symbol()
TargetDeco = {Instance()}
Delay = 0
destroyAtEnd = false
showAtStart = false
hideAtEnd = false
doOutInSine = true

local EASING = require "Lotus.Scripts.Libs.EasingLib"

function MaterialFadeTargetted()
    Sleep(Delay)
    if showAtStart and not IsNull(TargetDeco) then
        for j = 1, #TargetDeco do
            local temp = TargetDeco[j]
            temp:SetVisibility(true)
        end
    end
    local t = 0
    local val
    while t < TimeLength do
        --val = Lerp(OriginalValue, NewValue, t/TimeLength)
        if doOutInSine then
            val = EASING.outInSine(t, ValleyValue, PeakValue - ValleyValue, TimeLength)
        else
            val = Lerp(ValleyValue, PeakValue, t/TimeLength)
        end
        if not IsNull(TargetDeco) then
            for j = 1, #TargetDeco do
                local temp = TargetDeco[j]
                temp:SetMaterialParam(Param, val)
            end
        end
        t = t + DeltaTime() 
        Sleep(0)
    end
    if destroyAtEnd and not IsNull(TargetDeco) then
        for j = 1, #TargetDeco do
            local temp = TargetDeco[j]
            temp:Destroy()
        end
    end
end

function MaterialFadePeakTargetted()
    Sleep(Delay)
    if showAtStart and not IsNull(TargetDeco) then
        for j = 1, #TargetDeco do
            local temp = TargetDeco[j]
            temp:SetVisibility(true)
        end
    end
    local t = 0
    local fading
    local val
    while t < TimeLength do
        if t < Peak then
            fading = t/Peak
        else
            fading = 1 - (t-Peak)/(TimeLength-Peak)
        end
        if fading < 0 then
            fading = 0
        end
        val = Lerp(ValleyValue, PeakValue, fading)
        if not IsNull(TargetDeco) then
            for j = 1, #TargetDeco do
                local temp = TargetDeco[j]
                temp:SetMaterialParam(Param, val)
            end
        end
        t = t + DeltaTime() 
        Sleep(0)
    end
    if destroyAtEnd and not IsNull(TargetDeco) then
        for j = 1, #TargetDeco do
            local temp = TargetDeco[j]
            temp:Destroy()
        end
    end
     if hideAtEnd and not IsNull(TargetDeco) then
        for j = 1, #TargetDeco do
            local temp = TargetDeco[j]
            temp:SetVisibility(false)
        end
    end   
end
