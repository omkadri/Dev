Param = Symbol("TintColor")
minScale = 1.0
getParentFirst = false
isLightningParticle = false
destroyBeam = false
beamDelay = 0.75
swapMinMax = false
sleepFirst = false
applyToParentColor = false
applyToChildren = false
invertColor = false
isWeaponProjectile = false
isAttachedToWeapon = false
projectileParents = 0
isHitEffect = false
isPrimaryWeapon = false
isMeleeWeapon = false
passCreatorThrough = false
isSentinelWeapon = false
isSecondaryWeapon = false
lensFlareAtten = 1
applyLowHigh = true
useAltEnergyColor = false
useOperatorEyes = false
destroyIfIllusionAvatar = false
HueClamp = false
newSaturate = 0.5
newBrightness = 1
disableParticles = false
beamSetWave = false
beamWaveAmp = 0.0
isArchwing = false
newEnergyColor = Color()
applyToWeaponsToo = false
isBaroDangle = false
getRootObjectColor = false

local GlobalAlphaAtten = 0.75
local replicantAvatar = WeakResource("/Lotus/Types/Enemies/TennoReplicants/TennoReplicantAvatar")
local stalkerAvatar = WeakResource("/Lotus/Types/Enemies/Stalker/StalkerAvatar")
local lichAvatarM = WeakResource("/Lotus/Types/Enemies/KuvaLich/KuvaLichAAvatar")
local lichAvatarF = WeakResource("/Lotus/Types/Enemies/KuvaLich/KuvaLichFemaleAAvatar")
local jetPackType = WeakResource("/Lotus/Types/Game/FlightJetPackItems/PlayerFlightJetPackItem")

local COLOR_UTIL = require "Lotus.Scripts.Effects.EffectsColorUtilities"
local weaponSlots = {Engine.SLOT_1, Engine.SLOT_2, Engine.SLOT_6}

local function GetEnergyColor(deco, needParent)
    local lotusAvatar
    local parent
    if needParent then
        parent = deco:GetAttachRoot()
        local rootAvatar = deco:GetAttachParent()
        while not IsNull(rootAvatar) do
            --check for avatars, in case the root is an emplacement
            if rootAvatar:IsA(gLotusAvatarType) then
                parent = rootAvatar
                break
            end
            rootAvatar = rootAvatar:GetAttachParent()
        end
    else
        parent = deco:GetCreator()
    end
    if IsNull(parent) then
        return
    end
    if parent:IsA(gLotusWeaponType) then
        parent:ApplyEnergyColor(deco)
        return nil
    elseif parent:IsA(gLotusAvatarType) then
        lotusAvatar = parent
    else
        local parentTwo = parent:GetCreator()
        if not IsNull(parentTwo) then
            if parentTwo:IsA(gEntityType) then
                lotusAvatar = parentTwo:GetAttachRoot()        
            elseif (parentTwo:IsA(gPowerSuitType) or parentTwo:IsA(jetPackType))  then
                lotusAvatar = parentTwo:GetAvatarOwner()
            end
        elseif parent:IsA(gProjectileType) then
            lotusAvatar = parent:GetInstigator()
        else
            lotusAvatar = parent:GetAttachRoot()
        end
    end
    if IsNull(lotusAvatar) then
        return nil
    end
    if lotusAvatar:IsA(replicantAvatar) then
        local rColor = Color(5, 145, 175, 255)
        return rColor
    end
    if lotusAvatar:IsA(stalkerAvatar) then
        local rColor = Color(255, 0, 0, 255)
        return rColor
    end
    if not lotusAvatar:IsA(gTennoAvatarType) and not lotusAvatar:IsA(gLotusSentinelAvatarType) then
        if lotusAvatar:IsA(lichAvatarM) or lotusAvatar:IsA(lichAvatarF) then
        else
            return nil
        end
    end
    if not IsNull(lotusAvatar) or parent == lotusAvatar then
        local attempts = 8
        local powersuit = nil
        while attempts > 0 and IsNull(powersuit) and not IsNull(lotusAvatar) do
            if isArchwing then
                powersuit = lotusAvatar:InventoryControl():GetAlternatePowerSuit()
            else
                powersuit = lotusAvatar:InventoryControl():GetActivePowerSuit()
            end
            attempts = attempts - 1
            Sleep(0)
        end
        if isPrimaryWeapon and not IsNull(lotusAvatar) then
            powersuit = lotusAvatar:InventoryControl():GetWeaponInSlot(Engine.SLOT_2)
        end
        if isMeleeWeapon and not IsNull(lotusAvatar) then
            powersuit = lotusAvatar:InventoryControl():GetMeleeWeapon()
        end
        if isSecondaryWeapon and not IsNull(lotusAvatar) then
            powersuit = lotusAvatar:InventoryControl():GetWeaponInSlot(Engine.SLOT_1)
        end
        if not IsNull(powersuit) then
            local playerCustomization = powersuit:GetCustomization()
            attempts = 8
            while attempts > 0 and not playerCustomization:Initialized() and not IsNull(powersuit) do
                playerCustomization = powersuit:GetCustomization()
                attempts = attempts - 1
                Sleep(0)
                if IsNull(powersuit) then
                    return nil
                end
            end

            local energyColor = nil
            local colors = nil
            if useAltEnergyColor then
                if Param == Symbol("TintColor") then
                    powersuit:ApplyEnergyColor(deco, true)
                    return nil
                end
                colors = playerCustomization:GetColors(Lotus_Game.Attachments)
            elseif useOperatorEyes then
                colors = playerCustomization:GetColors(Lotus_Game.Eyes)
            else
                energyColor = Color()
                if Param == Symbol("TintColor") then
                    powersuit:ApplyEnergyColor(deco)
                    return nil
                end
                powersuit:GetEnergyColor(energyColor, false)
                return energyColor
            end

            if colors:Initialized(Lotus_Game.EnergyColor) then
                energyColor = Color(colors.mEnergyColor)
            end
            return energyColor
        end
    end
end

local function GetEnergyColorProjectile(deco)
    local parent
    local pDeco = deco
    if isHitEffect then
        parent = deco
    else
        if projectileParents == 0 then
            parent = deco:GetAttachRoot()
        else
            for i=1, projectileParents do
                parent = pDeco:GetAttachParent()
                pDeco = parent
            end
        end
    end

    Sleep(0)
    if IsNull(parent) then
        return
    end
    local weapon
    if isAttachedToWeapon then
        --Work around since some weapon fx are attached directly to the avatar, not the weapon (ie, Beams)
        if not parent:IsA(gTennoAvatarType) and not parent:IsA(gLotusMirrorAvatarType) then
            return nil
        end
        if isMeleeWeapon then
            weapon = parent:InventoryControl():GetMeleeWeapon()
        elseif isSecondaryWeapon then
            weapon = parent:InventoryControl():GetWeaponInSlot(Engine.SLOT_1)
        else
            weapon = parent:InventoryControl():GetWeaponInHand(Engine.MAIN_HAND)
        end
    else
        if isHitEffect then
            weapon = parent:GetCreator()
        elseif parent:IsA(gProjectileType) then
            weapon = parent:GetInstigatorItem()
        end
    end
    if IsNull(weapon) or not weapon:IsA(gLotusWeaponType) then
        return nil
    end
    if not IsNull(weapon) then
        local playerCustomization
        if isSentinelWeapon then
            local sent = weapon:GetAvatarOwner()
            local suit = sent:InventoryControl():GetActivePowerSuit()
            playerCustomization = suit:GetCustomization()
        else
            local avatar = weapon:GetOwner()
            if not IsNull(avatar) and avatar:IsA(gLotusMirrorAvatarType) then
                local pQ = COLOR_UTIL.ParticleQuality()
                if destroyIfIllusionAvatar then
                    if pQ ~= 2 then --Only render these for High
                        deco:Destroy()
                    end
                    return
                elseif pQ < 1 then -- If not medium or high then don't apply colours
                    return
                end
            end
            playerCustomization = weapon:GetCustomization()
        end
        local attempts = 8
        while attempts > 0 and not playerCustomization:Initialized() and not IsNull(weapon) do
            playerCustomization = weapon:GetCustomization()
            attempts = attempts - 1
            Sleep(0)
        end
            
        local energyColor = nil
        local colors
        if useAltEnergyColor then
            colors = playerCustomization:GetColors(Lotus_Game.Attachments)
        elseif useOperatorEyes then
            colors = playerCustomization:GetColors(Lotus_Game.Eyes)
        else
            colors = playerCustomization:GetColors(Lotus_Game.PrimaryColors)
        end
        if colors:Initialized(Lotus_Game.EnergyColor) then
            energyColor = Color(colors.mEnergyColor)
        end
        return energyColor
    end
end

function ApplyEnergyColor(deco)
    local energyColor = Color()
    if sleepFirst then
        Sleep(0.0)
    end
    if isWeaponProjectile then
        energyColor = GetEnergyColorProjectile(deco)
    else
        energyColor = GetEnergyColor(deco, getParentFirst)
    end
    if not IsNull(energyColor) then
        if applyToParentColor then
            local temp = deco:GetAttachParent()
            if not IsNull(temp) then
                deco = temp
            end
        end
        if invertColor then
            energyColor.red = 255 - energyColor.red
            energyColor.green = 255 - energyColor.green
            energyColor.blue = 255 - energyColor.blue
        end
        deco:SetMaterialParam(Param, COLOR_UTIL.SRGBToLinear(energyColor.red), COLOR_UTIL.SRGBToLinear(energyColor.green), COLOR_UTIL.SRGBToLinear(energyColor.blue), 1, applyToChildren)
        if applyLowHigh then
            COLOR_UTIL.ApplyHighLow(deco, energyColor)
        end
    end
    if isBaroDangle then
        --Only used for the baro dangle as a temp fix while clothEx offsets are looked at
        local parent = deco:GetAttachParent()
        if not IsNull(parent) then
            local scale = parent:GetMeshScale()
            local offset = deco:GetLocalAttachPosition()
            deco:SetAttachLocalSpace(Vector(offset.x * 1, offset.y * scale, offset.z * 1), deco:GetLocalAttachRotation())
        end
    end
end

function SetMaterialParam(entity)
    if not IsNull(entity) then
        if sleepFirst then
            Sleep(0.0)
        end
        
        entity:SetMaterialParam(Param, COLOR_UTIL.SRGBToLinear(newEnergyColor.red), COLOR_UTIL.SRGBToLinear(newEnergyColor.green), COLOR_UTIL.SRGBToLinear(newEnergyColor.blue), 1)
        if applyToChildren then
            local child = entity:GetAllAttachments(gDecorationType)
            if not IsNull(child) then
                for i=1, #child do
                    local tC = child[i]
                    tC:SetMaterialParam(Param, COLOR_UTIL.SRGBToLinear(newEnergyColor.red), COLOR_UTIL.SRGBToLinear(newEnergyColor.green), COLOR_UTIL.SRGBToLinear(newEnergyColor.blue), 1)
                end
            end
        end
    end
end

local function GetEnergyColorDeco(deco)
    local avatar
    local parent
    local weapon

    local pDeco = deco
    repeat
        parent = pDeco:GetAttachParent()
        pDeco = parent
    until IsNull(parent) or parent:IsA(gBaseAvatarType) or parent:IsA(gProjectileType)
    if not IsNull(parent) then
        if parent:IsA(gBaseAvatarType) then
            avatar = parent
            if isMeleeWeapon then
                weapon = avatar:InventoryControl():GetMeleeWeapon()
            elseif isSecondaryWeapon then
                weapon = avatar:InventoryControl():GetWeaponInSlot(Engine.SLOT_1)
            else
                weapon = avatar:InventoryControl():GetWeaponInSlot(Engine.SLOT_2)
            end
        elseif parent:IsA(gProjectileType) then
            Sleep(0)
            avatar = parent:GetInstigator()
            weapon = parent:GetInstigatorItem()
        end
    end

    if IsNull(weapon) or IsNull(avatar) then
        return nil
    end

    local customization
    if isSentinelWeapon then
        local sent = weapon:GetAvatarOwner()
        local suit = sent:InventoryControl():GetActivePowerSuit()
        customization = suit:GetCustomization()
    else
        if avatar:IsA(gLotusMirrorAvatarType) then
            local pQ = COLOR_UTIL.ParticleQuality()
            if destroyIfIllusionAvatar then
                if pQ ~= 2 then --Only render these for High
                    deco:Destroy()
                end
                return
            elseif pQ < 1 then -- If not medium or high then don't apply colours
                return
            end
        end
        customization = weapon:GetCustomization()
    end
    local attempts = 8
    while attempts > 0 and not customization:Initialized() and not IsNull(weapon) do
        customization = weapon:GetCustomization()
        attempts = attempts - 1
        Sleep(0)
    end
        
    local energyColor = nil
    local colorSlot = Lotus_Game.PrimaryColors
    
    if deco:IsA(gLotusWeaponDecorationType) then
        colorSlot = deco:GetCustomizationColorSlot()
    end
    local colors = customization:GetColors(colorSlot)
    if colors:Initialized(Lotus_Game.EnergyColor) then
        energyColor = Color(colors.mEnergyColor)
    end
    return energyColor
end

function ApplyEnergyColorDeco(deco)
    Sleep(0)
    local energyColor = GetEnergyColorDeco(deco)
    if IsNull(energyColor) then
        return
    end
    
    if applyToParentColor then
        local temp = deco:GetAttachParent()
        if not IsNull(temp) then
            deco = temp
        end
    end
    if invertColor then
        energyColor.red = 255 - energyColor.red
        energyColor.green = 255 - energyColor.green
        energyColor.blue = 255 - energyColor.blue
    end
    deco:SetMaterialParam(Param, COLOR_UTIL.SRGBToLinear(energyColor.red), COLOR_UTIL.SRGBToLinear(energyColor.green), COLOR_UTIL.SRGBToLinear(energyColor.blue), 1)
    if applyLowHigh then
        COLOR_UTIL.ApplyHighLow(deco, energyColor)
    end
    if applyToChildren then
        local child = deco:GetAllAttachments(gDecorationType)
        if not IsNull(child) then
            for i=1, #child do
                local tC = child[i]
                tC:SetMaterialParam(Param, COLOR_UTIL.SRGBToLinear(energyColor.red), COLOR_UTIL.SRGBToLinear(energyColor.green), COLOR_UTIL.SRGBToLinear(energyColor.blue), 1)
                COLOR_UTIL.ApplyHighLow(tC, energyColor)
            end
        end
    end
end

function ApplyEnergyColorParticles(deco, getP)
    if sleepFirst then
        Sleep(0.0)
    end
    local energyColor = Color()
    local object = deco
    if passCreatorThrough then
        local creator = deco:GetCreator()
        if not IsNull(creator) then
            object = creator
        end
    end
    if isWeaponProjectile then
        energyColor = GetEnergyColorProjectile(object)
    else
        energyColor = GetEnergyColor(object, getParentFirst)
    end
    local minColor = Color()
    if not IsNull(energyColor) then
        if invertColor then
            energyColor.red = 255 - energyColor.red
            energyColor.green = 255 - energyColor.green
            energyColor.blue = 255 - energyColor.blue
        end
        energyColor.alpha = 255 * GlobalAlphaAtten
        if applyLowHigh then
            COLOR_UTIL.ApplyHighLow(deco, energyColor)
        end
        minColor.red = energyColor.red
        minColor.green = energyColor.green
        minColor.blue = energyColor.blue
        minColor.alpha = energyColor.alpha * minScale
        if isLightningParticle then
            minColor.alpha = 0
            energyColor.alpha = energyColor.alpha / GlobalAlphaAtten
        end
        if swapMinMax then
            deco:SetColorMinMax(energyColor, minColor)
        else
            deco:SetColorMinMax(minColor, energyColor)
        end
    end
    if disableParticles then
        Sleep(0)
        deco:Disable()
    end
end

function ApplyEnergyColorLensflare(flare)
    Sleep(0.0)
    local energyColor = Color()
    local object = flare
    if passCreatorThrough then
        local creator = flare:GetCreator()
        if not IsNull(creator) then
            object = creator
        end
    end
    if getRootObjectColor then
        local parent = flare:GetAttachRoot()
        if not IsNull(parent) then
            object = parent
        end
    end
    if isWeaponProjectile then
        energyColor = GetEnergyColorProjectile(object)
    else
        energyColor = GetEnergyColor(object, getParentFirst)
    end
    if not IsNull(energyColor) then
        energyColor.red = energyColor.red * lensFlareAtten
        energyColor.green = energyColor.green * lensFlareAtten
        energyColor.blue = energyColor.blue * lensFlareAtten
        if HueClamp then
            local alpha = energyColor.alpha
            local H, S, V = COLOR_UTIL.RGBToHSV(energyColor)
            S = newSaturate
            V = newBrightness
            energyColor = COLOR_UTIL.HSVToRGB(H, S, V)
            energyColor.alpha = alpha
        end
        flare:SetTint(energyColor)
    end
end

function ApplyEnergyColorLight(light)
    Sleep(0.0)
    local energyColor = Color()
    local object = light
    if passCreatorThrough then
        local creator = light:GetCreator()
        if not IsNull(creator) then
            object = creator
        end
    end
    if destroyIfIllusionAvatar and isAttachedToWeapon then
        local root = light:GetAttachRoot()
        if not IsNull(root) then
            if root:IsA(gLotusMirrorAvatarType) then
                light:Destroy()
            end
        end
    end
    if isWeaponProjectile then
        energyColor = GetEnergyColorProjectile(object)
    else
        energyColor = GetEnergyColor(object, getParentFirst)
    end
    if not IsNull(energyColor) then
        if HueClamp then
            local alpha = energyColor.alpha
            local H, S, V = COLOR_UTIL.RGBToHSV(energyColor)
            S = newSaturate
            V = newBrightness
            energyColor = COLOR_UTIL.HSVToRGB(H, S, V)
            energyColor.alpha = alpha
        end
        light:SetColor(energyColor)
    end
end

function ApplyEnergyColorBeam(beam)
    Sleep(0.0)
    local energyColor = Color()
    if isWeaponProjectile then
        energyColor = GetEnergyColorProjectile(beam)
    else
        energyColor = GetEnergyColor(beam, getParentFirst)
    end
    if not IsNull(energyColor) then
        if applyLowHigh then
            COLOR_UTIL.ApplyHighLow(beam, energyColor)
        end
        beam:SetTint(energyColor)
    end
    if beamSetWave then
        local waves = Vector(Random(-beamWaveAmp, beamWaveAmp), Random(-beamWaveAmp, beamWaveAmp), Random(-beamWaveAmp, beamWaveAmp))
        beam:SetWaveAmplitude(waves)
    end
    if destroyBeam then
        Sleep(beamDelay)
        if not IsNull(beam) then
            beam:Destroy()
        end
    end
end

function ApplyEnergyColorSuit(suit)
    Sleep(0)
    if not suit:IsA(gPowerSuitType) then
        return
    end
    local energyColor = Color()
    local playerCustomization = suit:GetCustomization()
    local colors = playerCustomization:GetColors(Lotus_Game.PrimaryColors)
    if colors:Initialized(Lotus_Game.EnergyColor) then
        energyColor = Color(colors.mEnergyColor)
    end
    if not IsNull(energyColor) then
        --deco:SetMaterialParam(Param, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
        if applyLowHigh then
            local avatar = suit:GetAvatarOwner()
            if not IsNull(avatar) then
                COLOR_UTIL.ApplyHighLow(avatar, energyColor)
            end
        end
    end
end

function ApplyEnergyColorWeaponTrail(trail)
    Sleep(0.0)
    while not IsNull(gRegion:GetPlayingCinematic()) do
        Sleep(0)
    end
    local attempts = 20 --These are created during mission loading, very lenient with attempts here
    while not trail:GetAttachRoot():IsA(gBaseAvatarType) and attempts > 0 do
        attempts = attempts - 1
        Sleep(0)
    end
    local energyColor = Color()
    local object = trail
    if passCreatorThrough then
        local creator = trail:GetCreator()
        if not IsNull(creator) then
            object = creator
        end
    end
    if isWeaponProjectile then
        energyColor = GetEnergyColorProjectile(object)
    else
        energyColor = GetEnergyColor(object, getParentFirst)
    end
    if not IsNull(energyColor) then
        trail:SetTint(energyColor)
        if applyLowHigh then
            COLOR_UTIL.ApplyHighLow(trail, energyColor)
        end
    end
    
    if not IsNull(gGameRules) then
        if gGameRules:IsA(gLotusHubGameRulesType) then
            trail:Destroy() -- Kill it for perf, don't need these in hubs
        end
    end
end

function FlowRotationTest(entity)
    
    entity:SetRotation(Rotation())
    while true do

        local r = entity:GetRotation()
        r.pitch = r.pitch + DeltaTime() * 50
        if r.pitch > 180 then
            r.pitch = r.pitch - 180.0
        end
        entity:SetRotation(r)

        Sleep(0)

    end
end

function SetEnergyColor(entity)
    local suit
    local avatar
    if entity:IsA(gPowerSuitType) then
        --Script is on the powersuit
        suit = entity
        if not IsNull(suit) then
            avatar = suit:GetAvatarOwner()
        end
    else
        avatar = entity
        if getParentFirst then
            avatar = entity:GetAttachParent()
        end
        if IsNull(avatar) or not avatar:IsA(gBaseAvatarType) then
            return
        end
        local attempts = 15
        while IsNull(suit) and attempts > 0 do
            suit = avatar:InventoryControl():GetActivePowerSuit()
            attempts = attempts - 1
            Sleep(0)
        end
    end
    
    --Weapons
    if applyToWeaponsToo then
        local inventoryControl = avatar:InventoryControl()
        for i=1, #weaponSlots do
            local weapon = inventoryControl:GetWeaponInSlot(weaponSlots[i])
            if not IsNull(weapon) then
                local weaponCustomization = weapon:GetCustomization()
                local weaponColors = weaponCustomization:GetColors(Lotus_Game.PrimaryColors)
                weaponColors:SetColor(Lotus_Game.EnergyColor, newEnergyColor)
                weaponColors:SetInitialized(Lotus_Game.EnergyColor, true)
                weaponCustomization:SetColors(Lotus_Game.PrimaryColors, weaponColors)
                weapon:SetCustomization(weaponCustomization)
            end
        end
    end
    
    --Powersuit
    if IsNull(suit) then
        return
    end
    local playerCustomization = suit:GetCustomization()
    local colors = playerCustomization:GetColors(Lotus_Game.PrimaryColors)
    colors:SetColor(Lotus_Game.EnergyColor, newEnergyColor)
    colors:SetInitialized(Lotus_Game.EnergyColor, true)
    playerCustomization:SetColors(Lotus_Game.PrimaryColors, colors)
    suit:SetCustomization(playerCustomization)
end