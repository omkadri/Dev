material = Resource()
burntBodyMat = Resource()

local sHarrowFrameMarker = Symbol("HarrowFrameMarker")
local sExtrudePoint = Symbol("ExtrudePoint")
local sExtrudeVector = Symbol("ExtrudeVector")
local sGlowPosition = Symbol("GlowPosition")
local effectTag = Symbol("EffectsDeco")

function PossessionProjector(proj)
    local attachRoot = proj:GetAttachRoot()
    
    local localTarget = false
    local targetPos = gRegion:FindFirstTagged(sHarrowFrameMarker)
    if IsNull(targetPos) or targetPos:DistanceToEntity(attachRoot) < 1 then
        targetPos = Vector(0, 2, -4)
    else
        targetPos = targetPos:GetPosition()
    end
    
    local extrude
    local t = 0
    while true do
        if localTarget then
            extrude = targetPos + Vector(Noise(t*2), Noise(t) * 0.5, Noise(t*3) * 0.2)
        else
            extrude = targetPos - attachRoot:GetSimPosition()
        end
        material:SetParam(sExtrudePoint, extrude.x, extrude.y, extrude.z, 0)
        material:SetParam(sExtrudeVector, extrude.x, extrude.y, extrude.z, 0)
        
        Sleep(0)
        t = t + DeltaTime()
    end
end

function SmokeBallEffect(deco)
    local pos = deco:GetSimPosition()
    deco:SetMaterialParam(sGlowPosition, pos.x, pos.y, pos.z)
end

function HarrowCrumble(spawner)
    local entity = spawner:GetAttachRoot()
    if IsNull(entity) then
        return
    end

    if IsNull(entity) then
        return
    end

    local timeLength = 12
    entity:SetOverrideMaterialForAllSections(burntBodyMat, false)
    local children = entity:GetAllAttachments(gEntityType)
    for i=1, #children do
        local temp = children[i]
        if temp:GetTag() ~= effectTag then
            temp:SetOverrideMaterialForAllSections(burntBodyMat, false)
        end
    end
    local t = 0
    
    while t < timeLength do
        if not IsNull(entity) then
            entity:SetDissolve(math.pow(t / timeLength, 3))
        end
        t = t + DeltaTime()
        Sleep(0)
    end
end
