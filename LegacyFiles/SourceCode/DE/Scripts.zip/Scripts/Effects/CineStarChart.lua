local planets = {}

local maxSize = 143000
local maxDist = 5900
local planetNames = { "Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto", "Ceres", "Eris" }
local planetOrder = { 1, 2, 3, 4, 5.2, 6.8, 7.8, 8.7, 9, 4.4, 10 }
local planetSizes = { 4880, 12100, 12800, 6790, 93000, 70000, 31800, 49500, 3000, 3000, 4000 }
local planetDistances = { 57.9, 108, 150, 228, 778, 1430, 2870, 4500, 5900, 350, 6000 }
local planetOrbits = { 0.2, 0.3, 0.4, 0.6, 0.7, 0.8, 1.0, 0.5, 0.3, 1.0, 0.4, 0.2 }
local planetOrbitSpeed = {0.241, -0.615, 1.00, -1.88, 11.9, -29.5, 84.0, -165, 248, 4.6, 3}
local planetDay = { }
local planetDaySpeed = {58.7*24, 243*24, 24, 24.6, 9.84, 10.2, 17.9, 19.1, 6.39 * 24, 9, 60}

sun = Instance()


local function UpdatePlanets()

    local dt = DeltaTime()--* 100
    
    local SUN_OFFSET = 0.05
    
    local SIZE_EXP = 0.35
    local PLANET_SCALE = 1.0
    
    local DIST_EXP = 0.3
    local PLANET_DIST_SCALE = 2.75
    
    local PLANET_ORBIT_SCALE = 0.005
    local PLANET_DAY_SPEED = 0.05
    
    for i = 1,#planetNames do
    
        if planetDay[i] == nil then
            planetOrbits[i] = Frac(i * 0.3) --math.random()
            planetDay[i] = math.random()
        end
        
        planetOrbits[i] = planetOrbits[i] + dt * (1.0 / planetOrbitSpeed[i]) * PLANET_ORBIT_SCALE
        if planetOrbits[i] > 1.0 then
            planetOrbits[i] = planetOrbits[i] - 1.0
        elseif planetOrbits[i] < 0.0 then
            planetOrbits[i] = planetOrbits[i] + 1.0
        end
        
        planetDay[i] = planetDay[i] + dt * (24 / planetDaySpeed[i]) * PLANET_DAY_SPEED
        if planetDay[i] > 1.0 then
            planetDay[i] = planetDay[i] - 1.0
        elseif planetDay[i] < 0.0 then
            planetDay[i] = planetDay[i] + 1.0
        end
        
        local entity = planets[i]
        
        local s = (planetSizes[i] / maxSize) 
        s = math.pow(s, SIZE_EXP)
        s = s * PLANET_SCALE
        entity:SetMeshScale(s)
        
        local d = math.pow(planetOrder[i] / #planets, 0.7)
        --d = planetDistances[i] / maxDist
        --d = math.pow(d, DIST_EXP)
        -- linear bs
        d = Lerp(0.05, 1, planetOrder[i] / #planets)
        
        
        d = d * PLANET_DIST_SCALE
        --d = d + SUN_OFFSET
        
        
        local orbitRot = Rotation(planetOrbits[i] * 360, 0, 0)
        local localPos = Vector(0, 0, d)
        localPos = RotateVector(localPos, orbitRot)
        local localRot = Rotation(planetDay[i] * 360.0, 0, 0)
        
        entity:SetAttachLocalSpace(localPos, localRot)

    end
end

function SolarSytem()

    planets = sun:GetAllAttachments(Type("/Lotus/Objects/Space/PlanetDeco"))
    sun:SetMeshScale(1.0)
    while true do 
        UpdatePlanets() 
        Sleep(0.0)
    end
end