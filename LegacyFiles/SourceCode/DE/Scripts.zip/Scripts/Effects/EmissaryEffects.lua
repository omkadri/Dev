

function DecoUpdate(deco)
    local lantern = gRegion:FindNearestTagged(Symbol("EmissaryLantern"), deco:GetSimPosition())
    if IsNull(lantern) then
        return
    end
    local startPos = deco:GetPosition()
    local endPos = lantern:GetCenter() --Find the lantern
    local offset = Vector(Random(-4, 4), Random(2, 4), Random(-4, 4))
    local newPos = Vector()
    local t = 0
    local speed = Random(0.25, 0.3)
    while t < 1 do
        newPos = LerpVector(startPos, endPos, t * t) + offset * SmoothStep(1 - 2 * math.abs(0.5 - t))
        deco:SetPosition(newPos)
        t = t + DeltaTime() * speed
        Sleep(0)
    end
    deco:Destroy()
end