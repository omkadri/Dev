closedRetract = Resource()
openSpin = Resource()
openExtended = Resource()

local function _IsIdle(posture)
    return posture == Engine.WALK
end

local function _IsRun(posture)
    return posture == Engine.JOG or posture == Engine.RUN
end

function OnInit(suitAttachment, avatar) 
    
    if IsNull(avatar) or not avatar:IsA(gBaseAvatarType) then 
        return -- When using navigation were attached to some deco.
    end
    
    local posture = avatar:GetPosture()
    local oldPosture = posture
    local isFiring = avatar:IsFiring()
    local isRunning = _IsRun(posture)
    local wasRunning = isRunning
    
    local minRate = 0.0001
    local maxRate = 2.0
    local t = 0.0
    local currentRate = 0.0

    suitAttachment:PlayAnimation(openSpin, false, true, 1, Symbol(), currentRate, true)
    
    while true do
        posture = avatar:GetPosture()
        isFiring = avatar:IsFiring()
        -- Player changed from walk to run
        if (posture ~= oldPosture and (posture == Engine.WALK or posture == Engine.JOG or posture == Engine.RUN)) then 
            isRunning =  posture == Engine.JOG or posture == Engine.RUN
            if isRunning ~= wasRunning then
                if not isRunning then 
                    suitAttachment:PlayAnimation(openExtended, false, false, 0, Symbol(), 1.0)
                else
                    suitAttachment:PlayAnimation(closedRetract, false, false, 0, Symbol(), 1.0)
                end
                wasRunning = isRunning
            end
            oldPosture = posture
        end
        
        if isFiring then 
            t = math.min(t + DeltaTime(), 1.0 )
        else 
            t = math.max(t - DeltaTime(), 0.0)
        end
        
        currentRate = minRate + (math.sqrt(t) * maxRate)
        suitAttachment:SetAnimRate(1, currentRate)
        
        Sleep(0)
    end
    
end