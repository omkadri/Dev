typeToKill = WeakResource()
typesToKill = {Type()}

typeToAttach = Type()
attachToThis = Instance()
attachToArray = {Instance()}
isAttachedToThis = Instance()
isAttachedToThisArray = {Instance()}
attachPos = Vector()
attachRot = Rotation()
delay = 0.0
attachmentType = Type()
isEnable = true
bone = Symbol()
newMesh = Resource()
masterOnly = true
stopSpewing = false
destrySelfIfNotLocal = false

beamAttachBones = {Symbol()}
beamEndBones = {Symbol()}

local IllusionAvatar = WeakResource("/Lotus/Powersuits/Harlequin/IllusionMirrorAvatar")
local worldParam = Symbol("impactPoint")

function KillAttached()
    if not IsNull(typeToKill) then
        local temp = isAttachedToThis:GetAttachment(typeToKill)
        if not IsNull(temp) then
            temp:Destroy()
        end
    end
end

function KillAttachedOnSelf(self)
    if not IsNull(typeToKill) then
        local temp = self:GetAttachment(typeToKill)
        if not IsNull(temp) then
            temp:Destroy()
        end
    end
end

function KillAttachedToGameCamera()
    Sleep(delay)
    local cam = gRegion:GetGameCamera()
    if not IsNull(typeToKill) and not IsNull(cam) then
        local temp = cam:GetAttachment(typeToKill)
        if not IsNull(temp) then
            temp:Destroy()
        end
    end
end

function KillThisAttachedToParent(deco)
    local parent = deco:GetAttachParent()
    if not IsNull(parent) and not IsNull(typeToKill) then
        local children = parent:GetAttachment(typeToKill)
        if not IsNull(children) then
            if stopSpewing then
                children:SetSpewCount(0,0,false)
            else
                children:Destroy()
            end
        end
    end
end


function KillArrayAttachedToParent(deco)
    local parent = deco:GetAttachParent()
    if not IsNull(parent) and not IsNull(typesToKill) then
        for i=1, #typesToKill do
            local children = parent:GetAttachment(typesToKill[i])
            if not IsNull(children) then
                if stopSpewing then
                    children:SetSpewCount(0,0,false)
                else
                    children:Destroy()
                end
            end
        end
    end
end

function KillArrayAttachedToSelf(deco)
    if not IsNull(deco) and not IsNull(typesToKill) then
        for i=1, #typesToKill do
            local children = deco:GetAttachment(typesToKill[i])
            if not IsNull(children) then
                if stopSpewing then
                    children:SetSpewCount(0,0,false)
                else
                    children:Destroy()
                end
            end
        end
    end
end

function KillThisAttachedToParentOnBone(deco)
    if IsNull(bone) or bone == EMPTY_SYMBOL then
        return
    end
    
    local parent = deco:GetAttachParent()
    if not IsNull(parent) and not IsNull(typeToKill) then
        local children = parent:GetAllAttachments(typeToKill)
        if not IsNull(children) then
            for i = 1, #children do
                if not IsNull(children[i]) and children[i]:GetAttachBone() == bone then
                    children[i]:Destroy()
                end
            end
        end
    end
end

function KillAttachedArray()
    if not IsNull(isAttachedToThisArray) and not IsNull(typeToKill) then
        for count=1, #isAttachedToThisArray do
            local temp = isAttachedToThisArray[count]:GetAttachment(typeToKill)
            if not IsNull(temp) then
                temp:Destroy()
            end
        end
    end
end

function Attach()
    Sleep(delay)
    if not IsNull(attachToThis) and not IsNull(typeToAttach) then
        attachToThis:Attach(typeToAttach, bone, attachPos, attachRot)
    end
end

function AttachArray()
    if not IsNull(attachToArray) and not IsNull(typeToAttach) then
        for count=1, #attachToArray do
            attachToArray[count]:Attach(typeToAttach, EMPTY_SYMBOL, attachPos, attachRot)
        end
    end
end

function AttachProjector(spawner)
    Sleep(0)
    local parent = spawner:GetAttachParent()
    if not IsNull(parent) and not IsNull(typeToAttach) then
        parent:AttachIncludingChildren(typeToAttach, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, true)
    end
end

function KillParent(deco)
    local parent = deco:GetAttachParent()
    if not IsNull(parent) then
        parent:Destroy() --Dirty :(
    end
end

function AttachToMe(deco)
    if masterOnly and not gRegion:IsMaster() then
        return
    end
    if not IsNull(typeToAttach) then
        deco:Attach(typeToAttach, bone)
    end
end

function AttachToTouchingAvatar(trigger, avatar)
    if not IsNull(avatar) then
        if isEnable then
            if not avatar:HasAttachment(typeToAttach) then
                avatar:Attach(typeToAttach, bone)
            end
        else
            local children = avatar:GetAttachment(typeToAttach)
            if not IsNull(children) then
                children:Destroy()
            end
        end
    end
end

function AttachToAvatarFromBehavior(behavior)
    local avatar = behavior:GetAvatar()
    if not IsNull(avatar) then
        if not IsNull(typeToAttach) then
            avatar:Attach(typeToAttach, EMPTY_SYMBOL)
        end
    end
end

function KillParticleCenterTypeIfIllusionAvatar(entity)
    local object = entity:GetCreator()
    if IsNull(object) then
        return
    end
    local root = object:GetAttachRoot()
    if IsNull(root) then
        return
    end
    if root:IsA(IllusionAvatar) then
        if entity:IsA(gLightType) then
            entity:TurnOff()
        else
            entity:Destroy()
        end
    end
end

function EnableDisableAttachment()
    local items = isAttachedToThis:GetAllAttachments(attachmentType)
    if not IsNull(items) then
        for i, temp in ipairs(items) do
            if isEnable then
                temp:Enable()
            else
                temp:Disable()
            end
        end
    end
end

function EnableDisableAttachmentOnParent(entity)
    local parent = entity:GetAttachParent()
    if IsNull(parent) then
        return
    end
    local items = parent:GetAllAttachments(attachmentType)
    if not IsNull(items) then
        for i, temp in ipairs(items) do
            if isEnable then
                temp:Enable()
            else
                temp:Disable()
            end
        end
    end
end

function SwapParentMesh(entity)
    local parent = entity:GetAttachParent()
    if not IsNull(parent) then
        parent:SetMesh(newMesh, false, false)
    end
end

function ProjUpdateWorldPos(proj)
    while not IsNull(proj) do
        local pos = proj:GetSimPosition()
        proj:SetMaterialParam(worldParam, pos.x, pos.y, pos.z)
        Sleep(0)
    end
end

function SleepToDisable(entity)
    Sleep(delay)
    if not IsNull(entity) then
        entity:Disable()
    end
end

function ApplyToParentIfLocal(entity)
    Sleep(delay)
    if not IsNull(entity) then
        local avatar = entity:GetAttachParent()
        if not IsNull(avatar) and avatar:IsA(gLotusAvatarType) then
            if avatar:ReplicaLocallyControlled() then
                avatar:Attach(typeToAttach, bone)
            elseif destrySelfIfNotLocal then
                entity:Destroy()
            end
        end
    end
end

function AttachBeamsToThis(entity)
    Sleep(delay)
    if not IsNull(entity) and not IsNull(beamAttachBones) and not IsNull(beamEndBones) and (#beamAttachBones == #beamEndBones) then
        for i=1, #beamAttachBones do
            local beam = entity:Attach(typeToAttach, beamAttachBones[i])
            if not IsNull(beam) then
                beam:SetEndPointEntity(entity, beamEndBones[i])
            end
        end
    end
end

function BeamEndPoint(beam)
    Sleep(delay)
    if not IsNull(beam) then
        beam:SetEndPoint(attachPos)
    end
end
