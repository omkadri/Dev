startBlur = 2.0
newBlur = 0.0

function ReduceMotionBlur()

    local postProcess = gRegion:GetLevelInfo().postProcess
    
    local t = 0.0
    while t <= 1 do
        t = t + RealDeltaTime() * 3
        postProcess.motionBlurStrength = Lerp(startBlur, newBlur, t)
        Sleep(0)
    end
end