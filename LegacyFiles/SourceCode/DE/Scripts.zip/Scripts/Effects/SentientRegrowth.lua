-- Global Params --

local COLOR_UTIL = require "Lotus.Scripts.Effects.EffectsColorUtilities"
local sUnlitAtten = Symbol("UnlitAtten")

-- Regrowth Beam Params --

-- Regrowth Sculpture Params --

decoToDissolve = Instance()
specifyDecoToDissolve = false
unhideDeco = false --if decoration starts hidden, to avoid Volume collision from existing before its actually there
fxToCreate = Resource()
delayBeforeFxCreate = 1
initialDelay = 0
reverseDissolve = false
loop = false
loopDelay = 1
regrowthPercent = 0
regrowthTime = 15
cleanupTime = 3
dissolveSpeedA = 6
dissolveSpeedB = 2
dissolveSpeedC = 1
anim = Resource()
useAnimLength = false
animLength = 1
useProximity = true
detectionRange = 20
useOnlyFirstMat = false
decoEnergyMat = Resource()
decoRegrowthMat = Resource()
energyDecoType = Type()
regrowthDecoType = Type()
useProj = true
projectorType = Type()
projectorAtten = 4
--projExtrudePoint = Vector(0,0.1,0)
keepProj = false
destroySound = Resource()
replacementMesh = Resource()

-- Reactive Regrowth --
physicsTypeCollision = Resource()
physicsTypeNoCollision = Resource()
justKillTheDamnWall = false
local regenRate = 0.2
local regenDelay = 0.001
local animInterpTime = 2
local healthThresholdPercent = 0.25
local secondWallTime = 0.6
local doorOpenTime = 6
local energyWallType = WeakResource("/Lotus/Fx/Levels/SentientDevourer/RegrowthReactiveWallEnergyDeco")
local tunnelEnergyType = WeakResource("/Evolution/Lotus/Fx/Levels/SentientDevourer/RegrowthReactiveWallNanoRegrowthDeco")


function RegrowthBeam(beam)

    local targetPos = beam:GetPosition()
    local beamParent = beam:GetAttachParent()
    
    local parentTag
    local sourceTag
    local tagA = Symbol("regrowthTargetA")
    local tagB = Symbol("regrowthTargetB")
    local tagC = Symbol("regrowthTargetC")
    
    if not IsNull(beamParent) then
        parentTag = beamParent:GetTag()
    end
    
    if parentTag == tagC then
        sourceTag = Symbol("regrowthSourceC")
    elseif parentTag == tagB then
        sourceTag = Symbol("regrowthSourceB")
    else --if parentTag == tagA then
        sourceTag = Symbol("regrowthSourceA")
    end
    
    local regrowthSource = gRegion:FindNearestTagged(sourceTag,targetPos)
    
    if not IsNull(regrowthSource) then
        beam:SetEndPointEntity(regrowthSource, EMPTY_SYMBOL)
    end
end


local function DoCoolParticleBurstAfterDelay(deco)
    --print("!!!!!!!!!!!!!!!!Particle burst initiated")
	Sleep(delayBeforeFxCreate)
    if not IsNull(deco) then
        local location = deco:GetPosition()
        local fxToBurst = gRegion:CreateEntity(fxToCreate, location)
        Sleep(0.1)
        if not IsNull(fxToBurst) then
            fxToBurst:FirePort("Enable")
            fxToBurst:FirePort("Burst")
        end
	end
end


local function DoDissolve(deco)
    Sleep(0.1)
    local pQ = COLOR_UTIL.ParticleQuality()
    local hiddenMat = Resource("/Lotus/Fx/Common/HiddenNoPhysics")
    
    -- Attributes that don't show up without this?
    local temp = {regrowthPercent, dissolveSpeedA, dissolveSpeedB, dissolveSpeedC}
    
    local decoEnergy = deco:Attach(energyDecoType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, deco)
    local decoRegrowth = deco:Attach(regrowthDecoType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, deco)
    
    if not IsNull(decoEnergy) and not IsNull(decoRegrowth) then
    
        local mesh = deco:GetMesh() -- Set the child deco meshes
        
        if not IsNull(mesh) then
            decoRegrowth:SetMesh(mesh,false,false)
            decoEnergy:SetMesh(mesh,false,false)
        end
        
        if not IsNull(anim) then
            decoEnergy:PlayAnimation(anim,false,false)
            decoRegrowth:PlayAnimation(anim,false,false)
            deco:PlayAnimation(anim,false,false)
        end
        
        if pQ < 3 then -- Set materials on child decos - added cull for extra matIDs to optimise for ropy skel
            decoRegrowth:SetOverrideMaterialForAllSections(hiddenMat)
            decoEnergy:SetOverrideMaterialForAllSections(hiddenMat)
            decoRegrowth:SetOverrideMaterial(0,decoRegrowthMat)
            decoEnergy:SetOverrideMaterial(0,decoEnergyMat)
        else
            decoRegrowth:SetOverrideMaterialForAllSections(decoRegrowthMat)
            decoEnergy:SetOverrideMaterialForAllSections(decoEnergyMat)            
        end    
        
        local projector -- Attach a projector
        
        if useProj then
            --local interiorMat = deco:GetMaterialInSlot(1)
            --deco:SetOverrideMaterial(1,hiddenMat)
            projector = deco:Attach(projectorType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, deco)
            --deco:SetOverrideMaterial(1,interiorMat)
            
            --if not IsNull(projector) then
            --    projector:SetMaterialParam(Symbol("ExtrudePoint"),projExtrudePoint.x,projExtrudePoint.y,projExtrudePoint.z)
            --end
        end
        
        local t = regrowthTime*regrowthPercent
        local smoothT = 0
        local dissolveEnergy = 1
        local dissolveRegrowth = 1
        local dissolveClean = 1
        local atten = 0
        
        decoEnergy:SetDissolve(dissolveEnergy)
        decoRegrowth:SetDissolve(dissolveRegrowth)
        deco:SetDissolve(dissolveClean)
        
        while t < regrowthTime do -- Main dissolve loop, set dissolves and attens for each component based on desired speeds
            smoothT = SmoothStep(t/regrowthTime)
            
            dissolveEnergy = 1 - Clamp(smoothT*dissolveSpeedA,0,1)
            decoEnergy:SetDissolve(dissolveEnergy)
            dissolveRegrowth = 1 - Clamp(smoothT*dissolveSpeedB,0,1)
            decoRegrowth:SetDissolve(dissolveRegrowth)
            dissolveClean = 1 - Clamp(smoothT*dissolveSpeedC,0,1)
            deco:SetDissolve(dissolveClean)
            
            if keepProj then
                atten = smoothT * projectorAtten
            else
                atten = (smoothT * (1 - smoothT)) * projectorAtten
            end
            
            if not IsNull(projector) then
                projector:SetMaterialParam(sUnlitAtten, atten)
            end
            
            t = t + DeltaTime()
            Sleep(0)
        end
        
        t = 0       -- Dissolve pass is done, now to clean up the child decos, fade the underlying layers away to prep for deletion
        while t < cleanupTime do
            smoothT = SmoothStep(t/cleanupTime)
            decoEnergy:SetDissolve(smoothT)
            decoRegrowth:SetDissolve(smoothT)
            t = t + DeltaTime()
            Sleep(0)
        end
        deco:SetDissolve(0)
        decoEnergy:Destroy()
        decoRegrowth:Destroy()
        if not keepProj then
            projector:Destroy()
        end
        
        if not IsNull(replacementMesh) then
            deco:SetMesh(replacementMesh, true, false)
        end
    end
end

function SimpleDissolveIn(deco)
    if unhideDeco == true then --UnHide the deco, so its VolumeCollision registers
        deco:SetVisibility(true, true)
    end
	DoCoolParticleBurstAfterDelay()
    DoDissolve(deco)
end

function RegrowthSculpture(deco)

    Sleep(0) -- Allow initialisation
    
    local pQ = COLOR_UTIL.ParticleQuality()
    
    -- Attributes that don't show up without this?
    local temp = {regrowthPercent, dissolveSpeedA, dissolveSpeedB, dissolveSpeedC}
    
    -- If no anim specified, assume it's not used
    local useAnim = false
    
    if IsNull(anim) then
        useAnim = false
    else    
        useAnim = true
    end
    
    -- If editor mode, make everything visible
    if unhideDeco == true then
        deco:SetVisibility(true, true)
    Sleep(0.1)
    end
    if IsNull(gRegion:GetPlayerAvatar(0)) then
        deco:SetDissolve(0)
    else
        deco:SetDissolve(1-(regrowthTime*regrowthPercent))
    end
    
    
    -- Player proximity check
    local nearestAvatar
    
    while IsNull(nearestAvatar) and useProximity do
        nearestAvatar = gRegion:FindNearestPlayerAvatar(deco:GetPosition(),detectionRange)
        Sleep(0.2)
    end
    
    
    -- Attach the two child decos
    local decoEnergy = deco:Attach(energyDecoType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, deco)
    local decoRegrowth = deco:Attach(regrowthDecoType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, deco)
    
    if not IsNull(decoEnergy) and not IsNull(decoRegrowth) then
        
        -- Set the child deco meshes
        local mesh = deco:GetMesh()
        
        if not IsNull(mesh) then
            decoRegrowth:SetMesh(mesh,false,false)
            decoEnergy:SetMesh(mesh,false,false)
        end
        
        -- Set materials on child decos - added cull for extra matIDs to optimise for ropy skel
        if useOnlyFirstMat or (pQ < 3) then
        
            local hiddenMat = Resource("/Lotus/Fx/Common/HiddenNoPhysics")
            
            decoRegrowth:SetOverrideMaterialForAllSections(hiddenMat)
            decoEnergy:SetOverrideMaterialForAllSections(hiddenMat)
            
            decoRegrowth:SetOverrideMaterial(0,decoRegrowthMat)
            decoEnergy:SetOverrideMaterial(0,decoEnergyMat)
            
        else
        
            decoRegrowth:SetOverrideMaterialForAllSections(decoRegrowthMat)
            decoEnergy:SetOverrideMaterialForAllSections(decoEnergyMat)
            
        end    
    
        -- Attach a projector
        local projector
        
        if useProj then
            projector = deco:Attach(projectorType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, deco)
            --projector:SetMaterialParam(Symbol("ExtrudePoint"),projExtrudePoint.x,projExtrudePoint.y,projExtrudePoint.z)
        end
        
        
        -- Initialise the dissolve and atten values
        local t = regrowthTime*regrowthPercent
        local smoothT = 0
        
        local dissolveEnergy = 1
        local dissolveRegrowth = 1
        local dissolveClean = 1
        
        local atten = 0
        
        decoEnergy:SetDissolve(dissolveEnergy)
        decoRegrowth:SetDissolve(dissolveRegrowth)
        deco:SetDissolve(dissolveClean)
        
        -- Wait if we want to delay the start
        Sleep(initialDelay)
        
        -- Initialise gate for looping
        local shouldDissolve = true
        
        -- Start the dissolve loop
        while shouldDissolve do
        
            if useAnim then
                
                -- If we're using the anim, check if we want to drive the dissolve by the anim time, or the anim time by the dissolve
                local animRate = 1
            
                if useAnimLength then
                    regrowthTime = animLength
                else
                    animRate = 1/regrowthTime
                end
                
                deco:PlayAnimation(anim,false,false, 0, Symbol(), animRate)
                decoRegrowth:PlayAnimation(anim,false,false, 0, Symbol(), animRate)
                decoEnergy:PlayAnimation(anim,false,false, 0, Symbol(), animRate)
            end
        
            -- Main dissolve loop, set dissolves and attens for each component based on desired speeds
            while t < regrowthTime do
                smoothT = SmoothStep(t/regrowthTime)
                
                if reverseDissolve then
                    dissolveEnergy = Clamp(smoothT*dissolveSpeedA,0,1)
                    decoEnergy:SetDissolve(dissolveEnergy)
                    
                    dissolveRegrowth = Clamp(smoothT*dissolveSpeedB,0,1)
                    decoRegrowth:SetDissolve(dissolveRegrowth)
                    
                    dissolveClean = Clamp(smoothT*dissolveSpeedC,0,1)
                    deco:SetDissolve(dissolveClean)
                else
                    dissolveEnergy = 1 - Clamp(smoothT*dissolveSpeedA,0,1)
                    decoEnergy:SetDissolve(dissolveEnergy)
                    
                    dissolveRegrowth = 1 - Clamp(smoothT*dissolveSpeedB,0,1)
                    decoRegrowth:SetDissolve(dissolveRegrowth)
                    
                    dissolveClean = 1 - Clamp(smoothT*dissolveSpeedC,0,1)
                    deco:SetDissolve(dissolveClean)
                end
                
                atten = (smoothT * (1 - smoothT)) * projectorAtten
                
                if not IsNull(projector) then
                    projector:SetMaterialParam(sUnlitAtten, atten)
                end
                
                t = t + DeltaTime()
                
                Sleep(0)
            end
            
            -- Dissolve pass is done, now to clean up the child decos, fade the underlying layers away to prep for deletion
            
            t = 0
            
            if not reverseDissolve then
                while t < cleanupTime do
                    smoothT = SmoothStep(t/cleanupTime)
                    
                    decoEnergy:SetDissolve(smoothT)
                    decoRegrowth:SetDissolve(smoothT)
                    
                    t = t + DeltaTime()
                    Sleep(0)
                end
            end
        
            -- Pause at the end of the loop if we want to delay each loop
            Sleep(loopDelay)
            
            -- Flip the bool if we want to get out
            if loop then
                shouldDissolve = true
            else
                shouldDissolve = false
            end
        
        end
        
        -- We're done! Destroy everything.
        decoEnergy:Destroy()
        decoRegrowth:Destroy()
        
        if not IsNull(projector) then
            projector:Destroy()
        end
        
    end

end

function ReactiveRegrowth(deco, damageData)
    if IsNull(deco) then
        return
    end
    
    -- Note: I unchecked the RegrowthReactiveWallDeco type's 'can die' and 'remove on destroy' so that health never goes below 1 when damaged,
    -- and the object can't be removed by damaging it - this should fix the SetHealth crash along with the other commented changes.

    local energyWall = deco:GetAttachment(energyWallType)    
    local tunnelEnergy = deco:GetAttachment(tunnelEnergyType)    
    local initHealth = deco:GetHealth()
    local health = initHealth
    local oldHealth
    local newHealth
    local healthThreshold = initHealth * healthThresholdPercent
    local animTime = 0
    local animTimeTarget
    local lastDamageTimer = 0
    local regen = regenRate * initHealth
    local tunnelEnergyAtten = 0
    local t = 0
    secondWallTime = math.max(secondWallTime, 0.1)
    
    while not IsNull(deco) do
        
        oldHealth = health
        health = deco:GetHealth()
        animTimeTarget = 1 - (health / initHealth)
        
        if not IsNull(tunnelEnergy) then
            tunnelEnergy:SetMaterialParam(Symbol("UnlitAtten"), animTimeTarget*2)
        end
        
        if animTime < animTimeTarget then
            local differenceScalar = animTimeTarget - animTime
            t = 0
            while t < (animInterpTime * differenceScalar) do
                -- Update anim target incase we take further damage while in the loop
                health = deco:GetHealth()
                animTimeTarget = 1 - (health / initHealth)
                
                animTime = Lerp(animTime,animTimeTarget,t/animInterpTime)
                deco:SetAnimDelta(0,animTime)
                deco:SetDissolve(animTime)
                t = t + DeltaTime()
                Sleep(0)
            end
        elseif animTime > animTimeTarget then
            animTime = animTimeTarget
            deco:SetAnimDelta(0,animTime)
            deco:SetDissolve(animTime)
        end
        
        
        if health <= healthThreshold and not IsNull(energyWall) then
        	
        	energyWall:PlaySound(destroySound, false, 0, false)
            
            local dissolve
            
            -- Dissolve energy wall
            t = 0
            while t < secondWallTime do
                dissolve = t/secondWallTime
                energyWall:SetDissolve(dissolve)
                t = t + DeltaTime()
                Sleep(0)
            end
            
            --[[if justKillTheDamnWall then
                deco:Destroy()
                return
            end]]
            
            if not IsNull(deco) and deco:GetHealth() > 1 then
                -- Get rid of collision
                deco:SetPhysicsBehaviorAndRegister(physicsTypeNoCollision)
                deco:SetVisibility(false)
                
                -- Wait X seconds
                Sleep(doorOpenTime)
                
                -- Reenable collision
                deco:SetPhysicsBehaviorAndRegister(physicsTypeCollision)
                deco:SetVisibility(true)
                deco:SetHealth(healthThreshold + 1,false)
                
                -- Regrow energy wall
                t = 0
                while t < secondWallTime do
                    dissolve = 1 - (t/secondWallTime)
                    energyWall:SetDissolve(dissolve)
                    t = t + DeltaTime()
                    Sleep(0)
                end
            
                health = deco:GetHealth()
            else
                deco:Destroy()
                return
            end
            
        end
        
        if oldHealth > health then
            lastDamageTimer = 0
        else
            lastDamageTimer = lastDamageTimer + DeltaTime()
        end
        
        if lastDamageTimer > regenDelay then
            newHealth = health + (DeltaTime() * regen)
            newHealth = math.min(newHealth, initHealth) -- Cap health at its original max value
            newHealth = math.max(newHealth, 1) -- Cap so it never gets set below 1
            deco:SetHealth(newHealth,false)
        end
        
        Sleep(0)        
    end
    
end