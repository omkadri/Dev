-- Random lookat event

local NV_RAND_WORLD_EVENT_CHANCE = Symbol("RandWorldEventChance")

eventCost = 25

--quake = false
Chance = 33
mover = Instance()
lookAtTrigger = Instance()
PortForwarder = Instance()
DestroyWhenSeen = false
DoDebug = false

function rollForEvent()

    local gameRules = gGameRules
    local worldEventChance = gameRules:GetNetPersistentVar(NV_RAND_WORLD_EVENT_CHANCE)
    local chanceMod = ( worldEventChance + eventCost * 0.25 )
    --Broadcast(worldEventChance)
    
    if eventCost <= worldEventChance  then
        local randFloat = Random(0, 100)
        
        if randFloat <= worldEventChance then
            --Broadcast("Event Fired reduce event chance.")
            gameRules:SetNetPersistentVar(NV_RAND_WORLD_EVENT_CHANCE, 0)
            if not IsNull(mover) then
                mover:StartForwardMovement()
            end
            if not IsNull(lookAtTrigger) then
                lookAtTrigger:Destroy()
            end            
        else
            --Broadcast("Event Not fired, increase event Chance.")
            gameRules:SetNetPersistentVar(NV_RAND_WORLD_EVENT_CHANCE, chanceMod)
        end
    
    else
        --Broadcast("Event Not fired, increase event Chance.")
        gameRules:SetNetPersistentVar(NV_RAND_WORLD_EVENT_CHANCE, chanceMod)
    
    end
    
end

function rollForEventPortForwarder()

    local gameRules = gGameRules
    local worldEventChance = gameRules:GetNetPersistentVar(NV_RAND_WORLD_EVENT_CHANCE)
    local chanceMod = ( worldEventChance + eventCost * 0.25 )
    --Broadcast(worldEventChance)
    
    if eventCost <= worldEventChance  then
        local randFloat = Random(0, 100)
        
        if randFloat <= worldEventChance then
            --Broadcast("Event Fired reduce event chance.")
            gameRules:SetNetPersistentVar(NV_RAND_WORLD_EVENT_CHANCE, 0)
            if not IsNull(PortForwarder) then
                PortForwarder:FirePort("TriggerPort")
            end
            if not IsNull(lookAtTrigger) then
                lookAtTrigger:Destroy()
            end            
        else
            --Broadcast("Event Not fired, increase event Chance.")
            gameRules:SetNetPersistentVar(NV_RAND_WORLD_EVENT_CHANCE, chanceMod)
        end
    
    else
        --Broadcast("Event Not fired, increase event Chance.")
        gameRules:SetNetPersistentVar(NV_RAND_WORLD_EVENT_CHANCE, chanceMod)
    
    end
    
end

function RandomChanceMoverTrigger()
    local randFloat = Random(0,100)
    if DoDebug then
        print("RandomChance was "..randFloat..". This msg brought to you by RandomWorldEvent.lua")
    end
    if randFloat <= Chance then
        if not IsNull(mover) then
            mover:StartForwardMovement()
        end
        if not IsNull(lookAtTrigger) then
            lookAtTrigger:Destroy()
        end 
    end
    if DestroyWhenSeen and not IsNull(lookAtTrigger) then
        lookAtTrigger:Destroy()
    end
end

function RandomChancePortForwarderTrigger()
    local randFloat = Random(0,100)
    if DoDebug then
        print("RandomChance was "..randFloat..". This msg brought to you by RandomWorldEvent.lua")
    end
    if randFloat <= Chance then
        if not IsNull(PortForwarder) then
            PortForwarder:FirePort("TriggerPort")
        end
        if not IsNull(lookAtTrigger) then
            lookAtTrigger:Destroy()
        end 
    end
    if DestroyWhenSeen and not IsNull(lookAtTrigger) then
        lookAtTrigger:Destroy()
    end
end