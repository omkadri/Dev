-- ramp a Light value up or down

OriginalValue = 1 
NewValue = 2 
TimeLength = 1
Peak = 0.5
PeakValue = 1
ValleyValue = 0
TargetLight = {Instance()}
Delay = 0
colour = Color()
startColor = Color()
endColor = Color()
TurnOn = false

function BrightnessFade(light)
    Sleep(Delay)
    if TurnOn then
        light:TurnOn()
    end
    local t = 0
    local val
    while t < TimeLength do
        val = Lerp(OriginalValue, NewValue, t/TimeLength)
        light:SetBrightness(val)
        t = t + DeltaTime() 
        Sleep(0)
    end
end

function BrightnessFadePeak(light)
    Sleep(Delay)
    local t = 0
    local fading
    local val
    while t < TimeLength do
        if t < Peak then
            fading = t/Peak
        else
            fading = 1 - (t-Peak)/(TimeLength-Peak)
        end
        if fading < 0 then
            fading = 0
        end
        val = Lerp(ValleyValue, PeakValue, fading)
        light:SetBrightness(val)
        t = t + DeltaTime() 
        Sleep(0)
    end
end

function BrightnessFadeTargetted()
    Sleep(Delay)
    local t = 0
    local val
    while t < TimeLength do
        val = Lerp(OriginalValue, NewValue, t/TimeLength)
        if not IsNull(TargetLight) then
            for j = 1, #TargetLight do
                local temp = TargetLight[j]
                temp:SetBrightness(val)
            end
        end
        t = t + DeltaTime() 
        Sleep(0)
    end
end

function BrightnessFadePeakTargetted()
    Sleep(Delay)
    local t = 0
    local fading
    local val
    while t < TimeLength do
        if t < Peak then
            fading = t/Peak
        else
            fading = 1 - (t-Peak)/(TimeLength-Peak)
        end
        if fading < 0 then
            fading = 0
        end
        val = Lerp(ValleyValue, PeakValue, fading)
        if not IsNull(TargetLight) then
            for j = 1, #TargetLight do
                local temp = TargetLight[j]
                temp:SetBrightness(val)
            end
        end
        t = t + DeltaTime() 
        Sleep(0)
    end
end

function SetBrightnessTargetted()
    Sleep(Delay)
    for j = 1, #TargetLight do
        local temp = TargetLight[j]
        temp:SetBrightness(NewValue)
    end
end

function ChangeColour()
    for i, light in ipairs(TargetLight) do
        light:SetColor(colour)
    end
end

-- Scale mesh
function ChangeColorFade()
    Sleep(Delay)
    local t = 0
    local val = startColor
    while t < TimeLength do
        val.red = Lerp(startColor.red, endColor.red, t/TimeLength)
        val.green = Lerp(startColor.green, endColor.green, t/TimeLength)
        val.blue = Lerp(startColor.blue, endColor.blue, t/TimeLength)
        for j = 1, #TargetLight do
            local temp = TargetLight[j]
            temp:SetColor(val)
        end
        t = t + DeltaTime() 
        Sleep(0)
    end
end
