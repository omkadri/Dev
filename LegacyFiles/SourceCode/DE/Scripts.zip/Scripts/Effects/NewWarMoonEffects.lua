eyeMat = Resource()
helmetType = Type()
newHelmetMesh = Resource()
hoodSkin = Resource("/Lotus/Upgrades/Skins/Operator/Hoods/HoodA")
eyesMat = Resource("/Lotus/Fx/Levels/TheWarWithin/Cinematics/VoidEyesMat")

local OPERATOR = require "Lotus.Powersuits.Operator.OperatorLib"
local boneName = Symbol("GAME_C1_BODYLO2")

function DespawnBlade(spawner)
    local deco = spawner:GetAttachParent()
    local t = 0
    while t < 1 and not IsNull(deco) do
        deco:SetDissolve(t) --Do more
        Sleep(0)
        t = t + DeltaTime() * 2.4
    end
    if not IsNull(deco) then
        deco:SetDissolve(1)
    end
end

function ClearOperatorEyes(cinematic, operator)
    if not IsNull(operator) then
        operator:SetOverrideMaterial(0, eyeMat, false)
    end
end

function SwapHelmet(spawner)
    local dax = spawner:GetAttachParent()
    if IsNull(dax) then
        return
    end
    local helmet = dax:GetAttachment(helmetType)
    if not IsNull(helmet) then
        helmet:SetMesh(newHelmetMesh, false, false)
    end
end

function BeamUpdate(beam)
    local erra = gRegion:FindFirstTagged(Symbol("Erra"))
    local r = Vector(0, FRand() * 0.4, FRand() * 0.3 - 0.15)
    while not IsNull(beam) and not IsNull(erra) do
        beam:SetEndPoint(erra:GetBonePosition(boneName, false))
        Sleep(0)
    end
end

function SetUpPlayerOperator(cinematic)
    while IsNull(gRegion:GetLocalPlayer()) do
        Sleep(0)
    end
    
    local currentRegion = cinematic:GetRegionMgr()
    local operatorType = WeakResource("/Lotus/Types/Friendly/Tenno/OperatorHubNonReplicatedAvatar")
    
    local operatorTypeStrong = Type(operatorType)
    local localOperator = currentRegion:CreateEntity(operatorTypeStrong, cinematic:GetPosition(), ZERO_ROTATION)
    
    if not IsNull(localOperator) and not IsNull(gPlayerProfileMgr:GetPlayerProfile(0)) then
        local operatorCustomization  = gPlayerProfileMgr:GetPlayerProfile(0):GetGameSpecificData():GetLoadOut().mOperatorCustomization
        local operatorSuit = operatorCustomization:GetOperatorSuit()
        
        --We want the player's operator's head, but not the suit
        if not IsNull(operatorSuit) then
            local suitType = Type(operatorSuit)
            local powersuit = currentRegion:CreateObject(suitType, localOperator)
            local customization = operatorCustomization.mCustomization
            local activeBodySkin = customization:GetSkin(Lotus_Game.TOSS_BODY_SUIT)
            customization:SetSkin(nil, Lotus_Game.TOSS_BODY_SUIT)
            customization:SetSkin(nil, Lotus_Game.TOSS_ARMS)
            customization:SetSkin(nil, Lotus_Game.TOSS_LEGS)
            customization:SetSkin(nil, Lotus_Game.TOSS_SKIRT)
            customization:SetSkin(Resource("/Lotus/Upgrades/Skins/Operator/Hoods/HoodA"), Lotus_Game.TOSS_HOOD)
            local suitColors = customization:GetColors(Lotus_Game.Attachments)
            suitColors:SetInitialized(Lotus_Game.TintColor0, false)
            suitColors:SetInitialized(Lotus_Game.TintColor1, false)
            suitColors:SetInitialized(Lotus_Game.TintColor2, false)
            suitColors:SetInitialized(Lotus_Game.TintColor3, false)
            customization:SetColors(Lotus_Game.Attachments, suitColors)
            powersuit:SetCustomization(operatorCustomization.mCustomization)
            localOperator:InventoryControl():GiveItem(powersuit, true)
        end
    end
    
    localOperator:SetAnimName(Symbol("OperatorC"))
    OPERATOR.RemoveOperatorHood(localOperator)
    Sleep(0.1)
    localOperator:SetOverrideMaterial(0, eyesMat, false)
end