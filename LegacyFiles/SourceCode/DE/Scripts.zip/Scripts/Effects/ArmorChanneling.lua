effects = {Type()}
offsets = {Vector()}
rotations = {Rotation()}
destroyAttachedIfParentIsDeco = false --If cloned onto peacemaker ghosts, etc
endAfterAvatarCheck = false
beamType = Type()
beamOffset = Vector()
endPointEffect = Type()
aimingFadeBaseLevel = 0
onChannelingBurstEffect = Type()
allowedTimeBetweenBursts = 0.33
useDissolve = false
hideRightArmorAttachment = false

local COLOR_UTIL = require "Lotus.Scripts.Effects.EffectsColorUtilities"
local worldParam = Symbol("EmitterWorldPos")
local sUnlitAtten = Symbol("UnlitAtten")
local sRightShoulderBone = Symbol("GAME_R1_ARM1")
local pEffectTag = Symbol("ChannelingEffect")

local raycastIgnoreTypes = {
    WeakResource("/EE/Types/Game/Avatar"),
    WeakResource("/EE/Types/Engine/HitProxy"),
    WeakResource("/EE/Types/Physics/Ragdoll"),
    WeakResource("/EE/Types/Game/PickUp")
}

local function GetNearbyPoint(pos)
    local toPos = Vector(pos.x + math.random(-6,6), pos.y - math.random(-6,6), pos.z + math.random(-6,6))
    local rayCastHit = Vector()
    local count = 0
    while count < 2 do --Max raycasts before this one fails
        if gRegion:RaycastIgnoreTypes(pos, toPos, raycastIgnoreTypes, nil, rayCastHit) then
            count = 5
        else
            count = count + 1
            toPos = Vector(pos.x + math.random(-3,3), pos.y + math.random(-3,3), pos.z + math.random(-3,3))
        end
    end

    return rayCastHit
end

local function ChannelingParticles(root, isEnable)
    local effects = root:GetAllAttachments(gParticleSysType)
    for i, temp in ipairs(effects) do
        if temp:GetTag() == pEffectTag then
            if isEnable then
                temp:Enable()
            else
                temp:Disable()
            end
        end
    end
end

function Init(suitAttachment, avatar)
    Sleep(0.2)
    if IsNull(gGameRules) then
        return
    end
    if IsNull(suitAttachment) or IsNull(avatar) or gGameRules:IsA(gLotusHubGameRulesType) then
        return
    end

    if not avatar:IsA(gBaseAvatarType) then
        if avatar:IsA(gDecorationType) and destroyAttachedIfParentIsDeco then
            local allAttached = suitAttachment:GetAllAttachments(gEffectType)
            for i=1, #allAttached do
                allAttached[i]:Destroy()
            end
        end
        return
    end
    
    ChannelingParticles(suitAttachment, false)
    
    if endAfterAvatarCheck then
        return
    end
    
    local wasChanneling = false
    local doBurst = not IsNull(onChannelingBurstEffect)
    local burstTimer = allowedTimeBetweenBursts
    local pos = offsets
    local rot = rotations
    
    for i=1, #effects do
        if IsNull(pos[i]) then
            pos[i] = Vector()
        end
        if IsNull(rot[i]) then
            rot[i] = Rotation()
        end
    end
    
    while true do
        local meleeWeapon = avatar:InventoryControl():GetMeleeWeapon()
        local comboTier = 0
        if not IsNull(meleeWeapon) then
            comboTier = meleeWeapon:GetActiveImpactBehavior():GetCurrentComboTier()
        end
        local channeling = (comboTier > 0)

        if channeling and not wasChanneling then
            for i=1, #effects do
                if not IsNull(offsets[i]) or IsNull(rotations[i]) then
                    suitAttachment:Attach(effects[i], EMPTY_SYMBOL, pos[i], rot[i])
                end
            end
            if doBurst and burstTimer < 0 then
                gRegion:CreateEntity(onChannelingBurstEffect, suitAttachment:GetSimPosition(), ZERO_ROTATION, avatar)
                burstTimer = allowedTimeBetweenBursts
            end
            ChannelingParticles(suitAttachment, true)
        end
        
        if not channeling and wasChanneling then
            for i=1, #effects do
                local temp = suitAttachment:GetAttachment(effects[i])
                if not IsNull(temp) then
                    temp:Destroy()
                end
            end
            ChannelingParticles(suitAttachment, false)
        end

        wasChanneling = channeling

        if doBurst then
            if channeling then
                if burstTimer < 0 then
                    gRegion:CreateEntity(onChannelingBurstEffect, suitAttachment:GetSimPosition(), ZERO_ROTATION, avatar)
                    burstTimer = allowedTimeBetweenBursts
                end
            end
            burstTimer = burstTimer - DeltaTime()
        end
        Sleep(0)
    end
end

function ParticleUpdateWorldPos(pSys)
    local avatar = pSys:GetAttachRoot()
    local energyColor = Color(80, 155, 225, 255)
    local suit = avatar:InventoryControl():GetActivePowerSuit()
    local playerCustomization = suit:GetCustomization()
    local colors = playerCustomization:GetColors(Lotus_Game.Attachments)
    if colors:Initialized(Lotus_Game.EnergyColor) then
        energyColor = Color(colors.mEnergyColor)
        pSys:SetColorMinMax(energyColor, energyColor)
        COLOR_UTIL.ApplyHighLow(pSys, energyColor)
    end
    while not IsNull(pSys) do
        local pos = pSys:GetSimPosition()
        pSys:SetMaterialParam(worldParam, pos.x, pos.y, pos.z)
        Sleep(0)
    end
end


local function BeamEffects(beam, avatar, armor)
    beam:Enable()
    Sleep(0)
    local beamScale = 0.5
    beam:SetMaterialParam(Symbol("OffsetTime"), Random(0,1))
    local wave = Vector(Random(-1,1), Random(-1,1), Random(-1,1)) * beamScale
    beam:SetWaveAmplitude(wave)
    local atten = Random(1.5, 3.5)
    
    local rampUpTime = Random(0.1, 0.15)
    local t = 0
    while t < rampUpTime do
        local val = atten * t / rampUpTime
        beam:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, 1 + val * 5)
        armor:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, 1 + val * 4)
        Sleep(0)
        t = t + DeltaTime()
    end
    beam:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, 2)
    wave = Vector(Random(-1,1), Random(-1,1), Random(-1,1)) * beamScale
    beam:SetWaveAmplitude(wave)
    Sleep(Random(0.2, 0.3))
    wave = Vector(Random(-1,1), Random(-1,1), Random(-1,1)) * beamScale
    beam:SetWaveAmplitude(wave)

    rampUpTime = Random(0.15, 0.25)
    t = 0
    while t < rampUpTime do
        local val = atten * (rampUpTime - t) / rampUpTime
        beam:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, 1 + val)
        armor:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, 1 + val)
        Sleep(0)
        t = t + DeltaTime()
    end
    beam:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, 0)
    armor:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, 1)
    beam:Disable()
end

function EdoPrimeInit(suitAttachment, avatar)
    if IsNull(suitAttachment) or IsNull(avatar) or gGameRules:IsA(gLotusHubGameRulesType) then
        return
    end

    if not avatar:IsA(gBaseAvatarType) then
        if avatar:IsA(gDecorationType) and destroyAttachedIfParentIsDeco then
            local allAttached = suitAttachment:GetAllAttachments(gEntityType)
            for i=1, #allAttached do
                allAttached[i]:Destroy()
            end
        end
        return
    end
    
    if endAfterAvatarCheck then
        return
    end
    
    local wasChanneling = false
    local pQ = COLOR_UTIL.ParticleQuality()
    
    local beam = suitAttachment:Attach(beamType, EMPTY_SYMBOL, beamOffset)
    
    if not IsNull(beam) then
        beam:Disable()
    end

    while true do
        local meleeWeapon = avatar:InventoryControl():GetMeleeWeapon()
        local comboTier = 0
        if not IsNull(meleeWeapon) then
            comboTier = meleeWeapon:GetActiveImpactBehavior():GetCurrentComboTier()
        end
        local channeling = (comboTier > 1)

        if channeling then
            Sleep(Random(0, 0.7))
            --Pause, doesn't need to be instant.  Check to see if we're still channeling
            channeling = not IsNull(meleeWeapon) and (meleeWeapon:GetActiveImpactBehavior():GetCurrentComboTier() > 1)
            if channeling then
                local newEndPoint = GetNearbyPoint(suitAttachment:GetSimPosition())
                if newEndPoint ~= ZERO_VECTOR then
                    if not IsNull(beam) then
                        beam:SetEndPoint(newEndPoint)
                        if pQ > 0 then
                            gRegion:CreateEntity(endPointEffect, newEndPoint, ZERO_ROTATION)
                        end
                        BeamEffects(beam, avatar, suitAttachment)
                        Sleep(Random(0.8, 2.0) / (1 + pQ)) --Sleep before creating another one
                    end
                end
            end
        end

        wasChanneling = channeling
        Sleep(0)
    end
end

function HideEffectWhenAiming(deco)
    Sleep(0)
    local avatar = deco:GetAttachRoot()
    if IsNull(avatar) or not avatar:IsA(gLotusAvatarType) or not avatar:ReplicaLocallyControlled() then
        return
    end
    local isAiming = false
    local atten = 1
    local armorAttachment = nil
    local badge = nil
    if hideRightArmorAttachment then
        local suit = avatar:InventoryControl():GetActivePowerSuit()
        if not IsNull(suit) then
            armorAttachment = suit:GetCustomizationAttachment(Lotus_Game.ArmRight)
            badge = suit:GetCustomizationAttachment(Lotus_Game.CustomEmblem)
        end
    end
    while true do
        isAiming = avatar:HasPostureModifier(Engine.PM_AIM) and not avatar:HasPostureModifier(Engine.PM_IN_AIR)
        if isAiming or (not isAiming and atten < 1) then
            if isAiming then
                atten = math.max(aimingFadeBaseLevel, atten - DeltaTime() * 4)
            else
                atten = math.min(1, atten + DeltaTime() * 4)
            end
            if useDissolve then
                deco:SetDissolve(1 - atten)
            else
                deco:SetMaterialParam(sUnlitAtten, atten)
            end
            if hideRightArmorAttachment then
                if not IsNull(armorAttachment) then
                    armorAttachment:SetDissolve(1 - atten)
                end
                if not IsNull(badge) then
                    badge:SetDissolve(1 - atten)
                end
            end
        end
        Sleep(0)
    end
end

function PrimeArmourFourProjectileEffect(deco)
    Sleep(0)
    local avatar = deco:GetCreator()

    local energyColor = Color(197, 205, 206, 160)
    if not IsNull(avatar) then
        local projEffects = deco:GetAllAttachments(gParticleSysType)
        local suit = avatar:InventoryControl():GetActivePowerSuit()
        local playerCustomization = suit:GetCustomization()
        local colors = playerCustomization:GetColors(Lotus_Game.Attachments)
        if colors:Initialized(Lotus_Game.EnergyColor) then
            energyColor = Color(colors.mEnergyColor)
            for i=1, #projEffects do
                projEffects[i]:SetColorMinMax(energyColor, energyColor)
                COLOR_UTIL.ApplyHighLow(projEffects[i], energyColor)
            end
        end
    end
    
    local initialPos = deco:GetPosition()
    local finalPos = initialPos + Vector(Random(-4, 4), Random(-4, 4), Random(-4, 4))
    local t = 0
    local newPos = initialPos
    while t < 1 do
        newPos = LerpVector(newPos, finalPos, 0.1)
        deco:SetPosition(newPos)
        Sleep(0)
        t = t + DeltaTime()
    end
    
    local t = 0
    initialPos = newPos
    local speed = Random(1.5, 2.5)
    while t < 1 and not IsNull(avatar) do
        finalPos = avatar:GetBonePosition(sRightShoulderBone)
        newPos = LerpVector(initialPos, finalPos, SmoothStep(t))
        deco:SetPosition(newPos)
        Sleep(0)
        t = t + DeltaTime() * speed
    end
    
    local splash = gRegion:CreateEntity(endPointEffect, newPos, ZERO_ROTATION)
    if not IsNull(splash) then
        splash:SetColorMinMax(energyColor, energyColor)
    end
    deco:Destroy()
end