local animationLength = 40

local mVoxelizeSymbol = Symbol("Voxelize")

function Voxel(deco)
    Engine.EnableZoneCull(deco)

    local voxelAmt = 0
    local attachments = deco:GetAllAttachments(gDecorationType)

    while not IsNull(deco) do
        if _T.LotusGlitching then
            voxelAmt = math.min(1.0, voxelAmt + DeltaTime() * 10)
        else
            voxelAmt = math.max(0.0, voxelAmt - DeltaTime() * 10)
        end
        
        _T.LotusVoxelAmt = voxelAmt
        
        deco:SetMaterialParam(mVoxelizeSymbol, 50, 50, 50, voxelAmt)
        for i=1,#attachments do
            attachments[i]:SetMaterialParam(mVoxelizeSymbol, 50, 50, 50, voxelAmt)
        end
        Sleep(0)
    end
    
end

function LotusUpdate(deco)
    Engine.EnableZoneCull(deco)
    Sleep(0)
    
    deco:ScriptRunChildScript(Symbol("Voxel"), false)

    deco:SetAmbientAnimationRate(1)
    local t = 0
    local ambientAnimAmount = 0
    local waveAdjust = 0
    local noise = 0
    local noiseTimer = Random(1, 3)
    while not IsNull(deco) do
        waveAdjust = math.cos(t * 0.2 + math.sin(t * 0.44)) * 0.07 * math.abs(math.sin(t * 0.77)) --Constant fluctuation of speed
        if noiseTimer < 0 then
            _T.LotusGlitching = true
            --Glitch is happening, step through animation, do other things here
            noise = Random(.05, 1) / animationLength
            deco:SetAnimDelta(0, (noise + ambientAnimAmount / animationLength) % 1)
            Sleep(Random(0, 0.2))
            noise = noise + Random(.05, 1) / animationLength
            deco:SetAnimDelta(0, (noise + ambientAnimAmount / animationLength) % 1)
            Sleep(Random(0, 0.2))
            noise = noise + Random(.05, 1) / animationLength
            deco:SetAnimDelta(0, (noise + ambientAnimAmount / animationLength) % 1)
            Sleep(Random(0, 0.2))
            noise = noise + Random(.05, 1) / animationLength
            deco:SetAnimDelta(0, (noise + ambientAnimAmount / animationLength) % 1)
            Sleep(Random(0, 0.2))
            ambientAnimAmount = ambientAnimAmount + noise
            noise = 0
            _T.LotusGlitching = false
            noiseTimer = Random(3, 6)
            Sleep(0)
        end
        Sleep(0)
        t = t + DeltaTime()
        noiseTimer = noiseTimer - DeltaTime()
    end
end