trailType = Type()
jetTrailType = Type()
jetDecos = {Type()}
jetFlares = Type()
localSpeedDeco = Type()
speedDecoVisThreshold = 12
speedDotsType = Type()
colorDotsMin = Color(187, 187, 187, 128)
colorDotsMax = Color(213, 212, 212, 255)

flakEffect = Type()
bgProjectile = Type()
vacuumCleanerType = Type()
randomDeathBeamType = Type()
randomDeathBeamWarningSound = Resource()
dustCaster = Type()

bubblesType = Type()
waterParticlesType = Type()
avatarWaterSpray = Type()
causticsDeco = Type()
--local isSwimming = false

isSkiff = false

local velocityMax = 3.0
local artilleryTag = Symbol("FomShipExteriorHull")
local fairyArchWing = WeakResource("/Lotus/Characters/Tenno/Faerie/FaerieArchwing_skelDeco")

local function RandomSign()
    if Random(1, 100) > 50 then
        return 1
    else
        return -1
    end
end

local function GetJets(avatar, items)
    local jTable = {}
    for i=1, #items do
        local temp = avatar:GetAttachment(items[i])
        if not IsNull(temp) then
            table.insert(jTable, temp)
        end
    end
    return jTable
end

local function DestroyEffects(effects)
    for i, temp in ipairs(effects) do
        if not IsNull(temp) then
            temp:Destroy()
        end
    end
end

function InitAvatarEffects(jetPack)
    local avatar = nil
    local isLocal = false
    if isSkiff then
        local vehicle = jetPack:GetAttachParent()
        local pilot = nil
        --For now, loop until we have a rider
        local localAvatar = gRegion:GetLocalPlayerAvatar()
        while IsNull(pilot) and not localAvatar == pilot do
            Sleep(0)
            pilot = vehicle:GetRider()
        end
        isLocal = true
        avatar = vehicle
    else
        avatar = jetPack:GetAvatarOwner()
    end
    
    if IsNull(avatar) then
        return
    end
    
    Sleep(0)
    --Titania specific branch, destroy right away so it doesn't show in the arsenal
    local fairyDeco = avatar:GetAttachment(fairyArchWing)
    if not IsNull(fairyDeco) then
        fairyDeco:Destroy()
    end
    
    Sleep(1)
    
    if IsNull(avatar) then
        return
    end

    --Titania, check again, in case clients lag
    fairyDeco = avatar:GetAttachment(fairyArchWing)
    if not IsNull(fairyDeco) then
        fairyDeco:Destroy()
    end
    
    while not IsNull(gRegion:GetPlayingCinematic()) do
        Sleep(0)
    end
    
    if IsNull(avatar) or not avatar:IsA(gLotusAvatarType) then
        return
    end
    
    --DestroyEffects(avatar:GetAllAttachments(trailType))
    local meleeTrails = avatar:GetAllAttachments(trailType)
    local trails = avatar:GetAllAttachments(jetTrailType)
    local jets = GetJets(avatar, jetDecos)
    local flares = avatar:GetAllAttachments(jetFlares)
    local bubbles = avatar:GetAllAttachments(bubblesType)
    local waterSplash = avatar:GetAllAttachments(waterParticlesType)
    local avatarWaterSplash = avatar:GetAttachment(avatarWaterSpray)
    
    local cam = gRegion:GetGameCamera()
    --local effects
    local speedLines = nil
    local speedDeco = nil
    local zone = avatar:GetZone()
    local isTerrain = not IsNull(zone) and zone:IsA(gTerrainZoneType)
    
    if gRegion:GetLocalPlayerAvatar() == avatar or isLocal then
        if not avatar:IsInWater() then
            if not IsNull(zone) then
                if not zone:IsA(gTerrainZoneType) then
                    speedLines = cam:Attach(speedDotsType, EMPTY_SYMBOL)
                end
            end
            speedDeco = avatar:Attach(localSpeedDeco, EMPTY_SYMBOL, Vector(0, 1.5, 1))
        else
            avatar:Attach(causticsDeco, EMPTY_SYMBOL, Vector(0, 1.5, 1))
        end
        local flightMode = avatar:InventoryControl():GetFlightSuitMode()
        if flightMode ~= Engine.JET_SKYMODE then
            avatar:Attach(vacuumCleanerType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, avatar)
        end
    end
    
    if isTerrain then
        for i, temp in ipairs(trails) do
            if not IsNull(temp) then
                temp:SetLength(0.1)
            end
        end
        avatar:Attach(dustCaster, EMPTY_SYMBOL, Vector(0, -1, 0), Rotation(0, 90, 0), jetPack)
    end
    
    local zeroVector = Vector()
    local oldVelocity = Vector()
    local smoothVX = SmoothFloat(0, 0.4)
    local smoothVY = SmoothFloat(0, 0.4)
    local smoothVZ = SmoothFloat(0, 0.4)
    
    while true do
        local dt = DeltaTime()
        local velocity = avatar:GetVelocity()
        smoothVX:SetTargetVal(velocity.x)
        smoothVX:Update(dt)
        smoothVY:SetTargetVal(velocity.y)
        smoothVY:Update(dt)
        smoothVZ:SetTargetVal(velocity.z)
        smoothVZ:Update(dt)
        
        velocity.x = smoothVX:GetVal()
        velocity.y = smoothVY:GetVal()
        velocity.z = smoothVZ:GetVal()
        
        local dir = AngleToDirection(avatar:GetSimRotation())
        local accel = velocity - oldVelocity
        local d = Dot(accel, dir)
        local forward = Dot(dir, velocity)
        local v = Length(velocity) * Clamp((d + 0.2) * 5, 0, 1)
        for i, temp in ipairs(meleeTrails) do
            local trailVal = math.max(0.0, (10 - Length(velocity)) * 0.1)
            if not IsNull(temp) then
                temp:SetMaterialParam(Lotus_Game.ALPHA_ATTEN, trailVal)
            end
        end
        for i, temp in ipairs(trails) do
            local trailVal = math.max(0.0, (v - 10) * 0.1)
            if not IsNull(temp) then
                temp:SetMaterialParam(Lotus_Game.ALPHA_ATTEN, math.min(1, trailVal))
            end
        end
        for i, temp in ipairs(jets) do
            local jetVal = math.max(0.0, (v - 12)) * 0.25
            if not IsNull(temp) then
                temp:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, math.min(5, jetVal))
            end
        end
        for i, temp in ipairs(flares) do
            if not IsNull(temp) then
                local flareVal = Length(velocity) * 0.06
                temp:SetOpacity(math.min(1.2, flareVal))
            end
        end
        for i, temp in ipairs(bubbles) do
            if not IsNull(temp) then
                local bubbleVal = math.max(20, 256 * Length(velocity) * 0.2)
                temp:SetSpewCount(bubbleVal, bubbleVal, false)
            end
        end
        for i, temp in ipairs(waterSplash) do
            if not IsNull(temp) then
                local splashVal = math.max(2, 16 * Length(velocity) * 0.2)
                temp:SetSpewCount(splashVal, splashVal, false)
            end
        end
        if not IsNull(avatarWaterSplash) then
            local splashVal = math.max(2, 18 * Length(velocity) * 0.2)
            avatarWaterSplash:SetSpewCount(splashVal, splashVal, false)
        end
        if not IsNull(speedDeco) then
            if v < speedDecoVisThreshold then
                if speedDeco:IsVisible() then
                    speedDeco:SetVisibility(false, false)
                end
            else
                if not speedDeco:IsVisible() then
                    speedDeco:SetVisibility(true, false)
                end
                local speedVal = math.max(0.0, (Length(velocity) - speedDecoVisThreshold) * 0.25)
                speedDeco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, math.min(1.0, speedVal))
            end
        end
        if not IsNull(speedLines) then
            local velocityLength = Length(velocity)
            local linesVal = math.max(0.0, (velocityLength - 1) * 2)
            speedLines:SetSpeed(linesVal * 2, linesVal * 3)
            
            local colorMult = math.min(1.0, velocityLength / velocityMax)
            local colorMin = Color(colorDotsMin.red * colorMult, colorDotsMin.green * colorMult, colorDotsMin.blue * colorMult, colorDotsMin.alpha * colorMult)
            local colorMax = Color(colorDotsMax.red * colorMult, colorDotsMax.green * colorMult, colorDotsMax.blue * colorMult, colorDotsMax.alpha * colorMult)
            
            speedLines:SetColorMinMax(colorMin, colorMax)
            
            if linesVal > 0.1 then
                local off = Vector(velocity.x, velocity.y, velocity.z)
                Normalize(off)
                local newRot = LookTo(zeroVector, velocity * -1)
                speedLines:SetAttachLocalSpace(off * linesVal * 0.5, newRot)
            end
        end

        if isSkiff then
            if IsNull(avatar:GetRider()) then
                break
            end
        end
        oldVelocity = velocity
        Sleep(0)
    end
    
    if isSkiff then
        DestroyEffects(trails)
        DestroyEffects(jets)
        DestroyEffects(flares)

        
        if isLocal then
            if not IsNull(speedLines) then
                speedLines:Destroy()
            end
            if not IsNull(speedDeco) then
                speedDeco:Destroy()
            end
        end
    end
end

function DestroyAvatarEffects(jetPack)
    local avatar = jetPack:GetAvatarOwner()
    if IsNull(avatar) then
        return
    end
    
    DestroyEffects(avatar:GetAllAttachments(jetTrailType))
    DestroyEffects(GetJets(avatar, jetDecos))
    DestroyEffects(avatar:GetAllAttachments(jetFlares))
    DestroyEffects(avatar:GetAllAttachments(bubblesType))
    DestroyEffects(avatar:GetAllAttachments(waterParticlesType))
    DestroyEffects(avatar:GetAllAttachments(avatarWaterSpray))
    DestroyEffects(avatar:GetAllAttachments(causticsDeco))
    DestroyEffects(avatar:GetAllAttachments(dustCaster))
    
    if gRegion:GetLocalPlayerAvatar() == avatar then
        DestroyEffects(gRegion:GetGameCamera():GetAllAttachments(speedDotsType))
        DestroyEffects(avatar:GetAllAttachments(localSpeedDeco))
        DestroyEffects(avatar:GetAllAttachments(vacuumCleanerType))
    end
end

function BackgroundBattleEffects(helper)
    Sleep(3)
    local avatar = helper:GetAttachRoot()
    if gRegion:GetLocalPlayerAvatar() ~= avatar then
        avatar = gRegion:GetLocalPlayerAvatars()[1]
        if IsNull(avatar) then
            return
        end
    end
    
    local flakTimer = 0
    local flakDelay = 1
    local bgProjTimer = 0
    local bgProjDelay = 12
    local ArtilleryDeco
    if not IsNull(bgProjectile) then
        local tA = gRegion:FindTagged(artilleryTag)
        if not IsNull(tA) then
            ArtilleryDeco = tA[1]
        end
    end
    
    while true do
        if not IsNull(flakEffect) then
            if flakTimer > flakDelay then
                flakTimer = 0
                flakDelay = Random(0.5, 1)
                local flakPos = avatar:GetSimPosition()
                local viewDir = AngleToDirection(avatar:GetCameraView())
                flakPos = flakPos + Vector(viewDir.x * Random(10, 80), viewDir.y * Random(10, 80), viewDir.z * Random(10, 80))
                gRegion:CreateEntity(flakEffect, flakPos, ZERO_ROTATION)
            end
            flakTimer = flakTimer + DeltaTime()
        end
        
        if not IsNull(bgProjectile) then
            if bgProjTimer > bgProjDelay then
                bgProjTimer = 0
                bgProjDelay = Random(0.15, 0.4)
                local bgProjPos
                local projRot
                if not IsNull(ArtilleryDeco) then
                    local r = Vector()
                    Randomize(r)
                    local sourcePos = ArtilleryDeco:GetSimPosition() + Vector(0,-200,0) + r * 50
                    local targetPos = avatar:GetSimPosition() + Vector(0,0.1,0)

                    local diff = targetPos - sourcePos
                    local len = Length(diff)
                    Normalize(diff)
                    bgProjPos = targetPos - diff * math.min(200, len)
                    r = Vector()
                    Randomize(r)
                    projRot = LookTo(sourcePos, targetPos + r * 30)
                else
                    bgProjPos = avatar:GetSimPosition()
                    bgProjPos = Vector(bgProjPos.x + RandomSign() * Random(10, 40), bgProjPos.y + RandomSign() * Random(10, 40), bgProjPos.z + RandomSign() * Random(10, 40))
                    projRot = Rotation(Random(-180, 180), Random(-180, 180), Random(-180, 180))
                end
                --gRegion:CreateEntity(bgProjectile, bgProjPos, projRot)
            end
            bgProjTimer = bgProjTimer + DeltaTime()
        end
        Sleep(0.05)
    end
end

function RandomDeathBeam()
    Sleep(10)
    while not _T.gFomorianShieldsDown do
        if not IsNull(randomDeathBeamType) then
            local avatars = gRegion:GetHumanPlayerAvatars()
            if avatars and #avatars then
                local avatar = avatars[RandomInt(1, #avatars)]
                if not IsNull(avatar) and avatar:InventoryControl():GetAliveTime() >= 10 then
                    local flakPos = avatar:GetSimPosition()
                    local viewDir = AngleToDirection(avatar:GetCameraView())
                    flakPos = flakPos + Vector(viewDir.x * Random(10, 80), viewDir.y * Random(10, 80), viewDir.z * Random(10, 80))

                    if not IsNull(randomDeathBeamWarningSound) then
                        gRegion:PlaySound(randomDeathBeamWarningSound, Vector(), false)
                    end

                    local entity = gRegion:CreateEntity(randomDeathBeamType, flakPos, ZERO_ROTATION)
                    _T.fomorianSuperWeaponTarget = entity
                end
                Sleep(Random(10, 25))
            end
        end
    end
end
