spewCountLo = 2
spewCountHigh = 60
spewLengthMax = 2

local sPanUV0 = Symbol('PanUV0')
local sPanUV1 = Symbol('PanUV1')


function setUvScales(deco)
    local scale = deco:GetMeshScale()
    local pan = {deco:GetMaterialParam(sPanUV0, 1),deco:GetMaterialParam(sPanUV0, 2),deco:GetMaterialParam(sPanUV1, 1),deco:GetMaterialParam(sPanUV1, 2)}
    Sleep(0)
    --deco:SetMaterialParam(
end

function roachGang(ParticleSys)
    Sleep(0)
    while true do
        local spewCountMax = math.random(16,64)
        local spewCountMin = math.random(1,2)
        local spewLength = math.random(0.3,4)
        local spewWait = math.random(5,8)
        
        ParticleSys:SetSpewCount(spewCountMax, spewCountMax, true)
        Sleep(spewLength)
        local t = spewCountMax
        while t > spewCountMin do
            ParticleSys:SetSpewCount(t,t, false)
            t = t - 1
            Sleep(0)
        end
        ParticleSys:SetSpewCount(spewCountMin,spewCountMin, false)
        Sleep(spewWait)
        ParticleSys:SetSpewCount(0,0, false)
        -- Sleep to avoid spawned particles popping out of exsistance
        Sleep(3)
    end
end