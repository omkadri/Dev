trailParam = Symbol("SecondParams")

--Will "shrink" the weapon trail when polearm closes.

function ClosePolearm(deco)
    deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, 0)
    local trails = deco:GetAllAttachments(gWeaponTrailType)
    if not IsNull(trails) then
        for i=1, #trails do
            local temp = trails[i]
            temp:SetMaterialParam(trailParam, 0, 0, 1, 0)
        end
    end
end

function OpenPolearm(deco)
    deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, 1)
    local trails = deco:GetAllAttachments(gWeaponTrailType)
    if not IsNull(trails) then
        for i=1, #trails do
            local temp = trails[i]
            temp:SetMaterialParam(trailParam, 0, 0, 1, 1)
        end
    end
end
