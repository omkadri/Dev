

local sRainTag = Symbol("CameraWeatherDeco")
local sTimeToAdd = Symbol("TimeToAdd")
local sRainTwoAtten = Symbol("RainTwoAtten")
local sRainAtten = Symbol("RainAtten")

function SlowRain()
    local rainDeco = gRegion:FindFirstTagged(sRainTag)
    local t = 0
    local val = 0
    
    --Decreasing val by delta means rain will not scroll
    --Quake lasts about 135 frames
    
    local upwardsAmount = 0.95 --1.0 means it'll stop completely, > 1 means upward movement (kinda looks funny)
    
    --Take 2 seconds to slow to a halt
    while not IsNull(rainDeco) and t < 1 do
        val = val - DeltaTime() * Lerp(0.0, upwardsAmount, SmoothStep(t))
        rainDeco:SetMaterialParam(sTimeToAdd, val)
        rainDeco:SetMaterialParam(sRainTwoAtten, t)
        --rainDeco:SetMaterialParam(sRainAtten, 2 + t)
        Sleep(0)
        t = t + DeltaTime() * 0.5
    end
    
    --Pause at this speed for 2.3 seconds
    t = 0
    while not IsNull(rainDeco) and t < 2.3 do
        val = val - DeltaTime() * upwardsAmount
        rainDeco:SetMaterialParam(sTimeToAdd, val)
        Sleep(0)
        t = t + DeltaTime()
    end
    
    --Quickly return to normal when she raises her hands
    t = 1
    while not IsNull(rainDeco) and t > 0 do
        val = val - DeltaTime() * Lerp(upwardsAmount, 0.0, SmoothStep(t))
        rainDeco:SetMaterialParam(sTimeToAdd, val)
        rainDeco:SetMaterialParam(sRainTwoAtten, t)
        --rainDeco:SetMaterialParam(sRainAtten, 2 + t)
        Sleep(0)
        t = t - DeltaTime() * 3
    end
    rainDeco:SetMaterialParam(sRainTwoAtten, 0)
end