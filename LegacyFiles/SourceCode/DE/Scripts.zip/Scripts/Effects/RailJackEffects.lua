speedDotsType = Type()
asteroidTypes = { Type() }
asteroidFieldType = Type()
asteroidFieldMetalType = Type()
-- RailjackAsteroidDeath
deathDeco = Type()
meshScaleMultiplier = 1
deathAnims = {Resource()}
deathFx = Type()
deathDecos = { Type() }
deathGpuBits = { Type() }
hazardWarningSound = Resource()

dissolveDuration = 5
Delay = 0
deathSpawner = Resource()
trailType = Resource()
labelType = Resource("/Lotus/Types/Game/MarkerInfos/SpaceEnemyMarkerInfo")

DoCameraBlurZoom = false
DoHazardWarning = true  
DebugPlz = false

local COLOR_UTIL = require "Lotus.Scripts.Effects.EffectsColorUtilities"
local sAsteroidRandom = Symbol("AsteroidRandom")

local NUM_ASTEROIDS = 5
local MIN_NUM_ASTEROIDS = 4
local MAX_NUM_ASTEROIDS = 10
local sVelocity = Symbol("Velocity")

local shakeRange = Range(0, 0.2)
local anglarshakeRange = Range(0, 0.2)
local radialBlurRange = Range(0, 0.4)
local smoothRadialBlur = SmoothFloat(0, 1.0)
local forwardCamDistanceRange = Range(0.0, 0.1)
local reverseCamDistanceRange = Range(0.0, 0.1)

local linesSpewRange = Range(400, 800)
local linesAspectRange = Range(1.2, 1.4)
local linesUARange = Range(0.75, 1)

local lastPilot
local radialBlurSymbol = Symbol("CrewShipPilotBlur")
local HazardWarning = false
local SurroundedByMetal = false

local raycastIgnoreTypes = {
    WeakResource("/EE/Types/Game/Avatar"),
    WeakResource("/EE/Types/Engine/HitProxy"),
    WeakResource("/EE/Types/Physics/Ragdoll"),
    WeakResource("/EE/Types/Game/PickUp")
}

local asteroids = {}

local function GetNearbyPoint(dir, ship)
    local rayCastHit = Vector()
    if not IsNull(ship) then
        local surfaceType = ship:RaycastForHazards(dir, rayCastHit, raycastIgnoreTypes)
        if rayCastHit ~= ZERO_VECTOR then
            if surfaceType == GraphicsRes.ST_METAL then
                SurroundedByMetal = true
            else
                SurroundedByMetal = false
            end
            HazardWarning = true
            return rayCastHit
        end
    end
    
    HazardWarning = false
    return rayCastHit
end

local function PlayHazards(avatar, ship, hazardPos)
    local isInGreenRoom = IsNull(ship) or (not IsNull(ship:GetGreenRoom()) and (avatar:GetZone() == ship:GetGreenRoom():GetZone()))
    if isInGreenRoom then
        return
    end
    local pilot = ship:GetPilot()
    if (pilot and pilot:IsHumanPlayer() and pilot:IsLocallyAuthoritative()) then
        local pos = avatar:GetSimPosition()
        local toRailjack = hazardPos - pos
        Normalize(toRailjack)
        local rot = avatar:GetRotation()
        rot = InverseRotation(rot)
        toRailjack = RotateVector(toRailjack, rot)
        local eyePos = pilot:EyePosition()
        local finalSndPos = eyePos + toRailjack * 5
        gRegion:PlaySound(hazardWarningSound, finalSndPos, false)
        
    end

end
local function UpdatePilotEffects(ship, dt, currentVelocityPercent, bowSpeed, isRunning)

    local pilot = ship:GetPilot()

    if (pilot and pilot:IsHumanPlayer() and pilot:IsLocallyAuthoritative()) then
        lastPilot = pilot
        local pilotCameraController = pilot:CameraControl()
        local frwdVelocityPercentSq = currentVelocityPercent * currentVelocityPercent
        local speedForCameraShakes = math.min(1, bowSpeed / 50)
        local shake = anglarshakeRange:MapToRange(speedForCameraShakes * speedForCameraShakes)
        if isRunning then
            shake = 0.3
        end
        if shake < .03 then
            shake = 0
        end
        pilotCameraController:ShakeView(pilot:EyePosition(), 10, shake, 1)

        local radialBlur = 0
        if isRunning and frwdVelocityPercentSq > 0.8 then
            radialBlur = 0.3
        end

        smoothRadialBlur:SetTargetVal(radialBlur)
        smoothRadialBlur:Update(dt)
        radialBlur = smoothRadialBlur:GetVal()

        pilotCameraController:RadialBlurView(radialBlur, radialBlur, radialBlur, 0.1, radialBlurSymbol)

    elseif not IsNull(lastPilot) then
        local pilotCameraController = lastPilot:CameraControl()
        pilotCameraController:RemoveRadialBlurView(radialBlurSymbol)
        lastPilot = nil
    end
end

local function AsteroidManagement(NUM_ASTEROIDS, pos)
  
    if NUM_ASTEROIDS < #asteroids then
        --need to start removing some.
        local newcount = #asteroids - NUM_ASTEROIDS
        local num_removed = 0
        for i, temp in ipairs(asteroids) do
            if not IsNull(temp) then
                --table remove asteroid
                table.remove(asteroids, i)
                temp:PlayTriggeredFade()
                num_removed = num_removed + 1
                if num_removed > newcount then
                    return 
                end
            end
        end
    elseif NUM_ASTEROIDS > #asteroids then -- need to top up the number
        local newcount = NUM_ASTEROIDS - #asteroids 
        
        if #asteroidTypes > 0 then
            for i=1, newcount do
                local newType = asteroidFieldType
                if SurroundedByMetal then
                    newType = asteroidFieldMetalType
                end
                local aDeco = gRegion:CreateEntity(newType, pos, ZERO_ROTATION)
                if not IsNull(aDeco) then
                    aDeco:SetMaterialParam(sAsteroidRandom, FRand() * 25.5423)
                    table.insert(asteroids, aDeco)
                end
            end
        end
    end

end

function RailJackAvatarEffects(avatar)
    Sleep(2)

    if IsNull(avatar) or not avatar:IsA(gCrewShipAvatarType) then
        return
    end

    --Alternative, expose zone physics and check for gravity
    local zone = avatar:GetZone()
    local ship = avatar:InventoryControl():GetActivePowerSuit()

    while IsNull(ship) do
        ship = avatar:InventoryControl():GetActivePowerSuit()
        Sleep(0.1)
    end

    local hangarId = Symbol("DojoHangar")
    local hangerId = Symbol("DojoHanger")
    while IsNull(zone) or 
            --(IsNull(ship:GetGreenRoom()) or 
            --zone == ship:GetGreenRoom():GetZone()) or 
            gGameRules:InDojo() or 
            zone:GetAttribs():GetBackDropId() == hangerId or 
            gGameRules:IsA(gLotusAttractModeGameRulesType) do
        Sleep(0.5)
        zone = avatar:GetZone()
    end

    while not IsNull(gRegion:GetPlayingCinematic()) do
        Sleep(0)
    end
    
    local invControl = nil
    
    local oldPos = avatar:GetSimPosition()

    local speedLines = gRegion:CreateEntity(speedDotsType, oldPos, ZERO_ROTATION, avatar)

    AsteroidManagement(NUM_ASTEROIDS, oldPos)

    local decoOffset = Vector()
    local decoPos = Vector()
    local cross = Vector()
    local timer = 0
    local checkTime = 1
    local traceTimer = 0
    local traceCheckTime = .2
    local hazardwarningTime = 0
    local hazardwarningCheckTime = 1
    local rot = Rotation()
    local hyperDriveDissolve = 0
    local npcHidden = false
    local motionControl = avatar:MotionControl()
    local velocity = Vector()
    local dir = Vector()
    local pos = Vector()
    local newPos = Vector()
    local velocityN = Vector()
    local newEndPoint = Vector()
    local avatarRot = Rotation()
    local linesOffset = Vector()
    local effectOldPos = Vector()
    local effectVelocity = Vector()
    local effectSpeed = 0
    while true do
        local dt = DeltaTime()

        -- Calculate velocity manually since avatar:GetVelocity() isn't set
        newPos = avatar:GetSimPosition()
        avatarRot = avatar:GetSimRotation()
        dir = AngleToDirection(avatarRot)
        
        velocity = motionControl:GetVelocity()
        --VectorSub(velocity, newPos, oldPos)
        --velocity = velocity / dt
        rot = avatar:GetRotation()
        velocity = RotateVector(velocity, InverseRotation(rot))
        
        local velocityLength = Length(velocity)
        velocityN = velocity / math.max(0.001, velocityLength)

        local currentVelocityPercent = 0
        local isRunning = avatar:GetPosture() == Engine.RUN
        if not IsNull(speedLines) then
            linesOffset = newPos + dir * 20 --60m in front of the ship
            VectorSub(effectVelocity, linesOffset, effectOldPos)
            effectVelocity = effectVelocity / math.max(0.001, dt)
            effectSpeed = Length(effectVelocity)
            effectOldPos = linesOffset
            local linesVal = effectSpeed * 3
            
            local maxVelocity = 12
            currentVelocityPercent = Clamp(math.abs(effectSpeed / maxVelocity), 0, 1)

            linesOffset = linesOffset + effectVelocity * 2
            speedLines:Teleport(linesOffset, LookTo(effectVelocity, ZERO_VECTOR))
            local spewCount = linesSpewRange:MapToRange(math.min(1, 0.5 + math.pow(currentVelocityPercent, 0.25)))
            speedLines:SetSpewCount(spewCount, spewCount, false)

            local aspectAmt = linesAspectRange:MapToRange(currentVelocityPercent)
            local UA = linesUARange:MapToRange(currentVelocityPercent)
            if isRunning then
                aspectAmt = aspectAmt + 0.6
                UA = UA + 1
                linesVal = linesVal * 1.25
            end
            speedLines:SetSpeed(linesVal * 1, linesVal * 2)
            speedLines:SetAspect(aspectAmt,aspectAmt,false)
            speedLines:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, UA)
        end

        if DoCameraBlurZoom and not IsNull(ship) then
            UpdatePilotEffects(ship, dt, currentVelocityPercent, effectSpeed, isRunning)
        end
       
        timer = timer + DeltaTime()
        traceTimer = traceTimer + DeltaTime()
        hazardwarningTime = hazardwarningTime + DeltaTime()
        if traceTimer > traceCheckTime then
            newEndPoint = GetNearbyPoint(velocityN, ship)
            local warningDistance = 150
            if newEndPoint ~= ZERO_VECTOR then
                warningDistance = Distance(newPos, newEndPoint)
                --hit  something increase NUM_ASTEROIDS
                if NUM_ASTEROIDS < MAX_NUM_ASTEROIDS then
                    NUM_ASTEROIDS = NUM_ASTEROIDS + 1
                end
                AsteroidManagement(NUM_ASTEROIDS, newPos)
            elseif timer > checkTime then
                    --no hits start decreasing asteroids to min
                if NUM_ASTEROIDS > MIN_NUM_ASTEROIDS then
                    NUM_ASTEROIDS = NUM_ASTEROIDS - 1
                end
                AsteroidManagement(NUM_ASTEROIDS, newPos)
                timer= 0
            end
            traceTimer = 0
            hazardwarningCheckTime = warningDistance / 150
            if hazardwarningTime > hazardwarningCheckTime then
                if DoHazardWarning and HazardWarning then
                    PlayHazards(avatar, ship, newEndPoint)
                    hazardwarningTime = 0
                end
            end
                
        end
        
        local hds = avatar:GetHyperDriveState()
        local currentInHyperDrive = avatar:GetHyperDriveState() == Lotus_Game.CrewShipAvatar_HDS_ACTIVE
        if (hds ==  Lotus_Game.CrewShipAvatar_HDS_ACTIVE) or (hds ==  Lotus_Game.CrewShipAvatar_HDS_POWERING_DOWN) then
            hyperDriveDissolve = math.min(hyperDriveDissolve + DeltaTime(), 1)
            if not npcHidden then
                local npc = gRegion:FindTagged(Symbol("HangarHide"))
                for i=1, #npc do
                    npc[i]:SetVisibility(false, true)
                end
                npcHidden = true
            end
        else
            hyperDriveDissolve = math.max(0, hyperDriveDissolve - DeltaTime() * 0.3)
        end
        if IsNull(invControl) then
            local playerAvatar = gRegion:GetLocalPlayerAvatar()
            if not IsNull(playerAvatar) then
                invControl = playerAvatar:InventoryControl()
            end
        elseif not invControl:IsOnBoardShip(ship) then
            hyperDriveDissolve = 1
        end
        for i, temp in ipairs(asteroids) do
            if not IsNull(temp) then
                temp:SetDissolve(hyperDriveDissolve)
                temp:SetPosition(newPos)
            end
        end
        oldPos = newPos
        Sleep(0)
    end
end


function AircraftFlarePulse(flare)
    local t = 0.0
    local twoPi = math.pi * 2.0
    while not IsNull(flare) do
        t = t + DeltaTime() * 0.5
        local opac = math.abs(math.sin(Frac(t) * twoPi) * math.sin(Frac(t * .5) * twoPi))
        flare:SetOpacity(0.2 + opac * 0.8)
        Sleep(0)
    end
end

function RailjackAsteroidDeath(spawner)
    local parent = spawner:GetAttachRoot()
    local maxEdge = 14
    if not IsNull(parent) then
        local bounds = parent:GetBoundsMax() - parent:GetBoundsMin()
        local parentMaxEdge = math.max(bounds.x, math.max(bounds.y, bounds.z))
        local deco = gRegion:CreateEntity(deathDeco, parent:GetCenter(), parent:GetSimRotation())
        if not IsNull(deco) then
            local val = parentMaxEdge / maxEdge -- Match size of parent
            deco:SetMeshScale(val * meshScaleMultiplier)
--~             local animScale = math.min((1.5 - val * 0.3), 1) --Slower animation for large asteroids
--~             animScale = math.max(0.5, animScale)
            local animScale = math.min(1/val * 2, 2)
            local x = RandomInt(1, #deathAnims)
            deco:PlayAnimation(deathAnims[x], false, false, Engine.PRT_ONCE, Symbol(), animScale)
            deco:Attach(deathFx, EMPTY_SYMBOL) -- Attach fx here, they use mesh scale
            
            -- Hack: select appropriate gpu particles based on maxEdge
            local gpuSet = "Not set"
            if parentMaxEdge < 20 then
                if not IsNull(deathGpuBits[1]) then
                    gpuSet = "Sm"
                    deco:Attach(deathGpuBits[1], EMPTY_SYMBOL)
                end
            elseif parentMaxEdge < 60 then
                if not IsNull(deathGpuBits[2]) then
                    gpuSet = "Med"
                    deco:Attach(deathGpuBits[2], EMPTY_SYMBOL)
                end
            elseif parentMaxEdge < 100 then
                if not IsNull(deathGpuBits[3]) then
                    gpuSet = "L"
                    deco:Attach(deathGpuBits[3], EMPTY_SYMBOL)
                end
            else
                if not IsNull(deathGpuBits[4]) then
                    gpuSet = "XL"
                    deco:Attach(deathGpuBits[4], EMPTY_SYMBOL)
                end
            end
            if DebugPlz then print(parent:GetName(), ": ", parentMaxEdge) end
            if DebugPlz then print("AnimScale: ", animScale, "\n", gpuSet, "\n\n") end
            Sleep((4.0 / animScale -2))
        end
    end
end

function OnDeath(avatar)
    local spawner = gRegion:CreateEntity(deathFx, avatar:GetSimPosition(), avatar:GetSimRotation(), avatar)
    avatar:SetVisibility(false, true)
    local vel = avatar:GetVelocity()
    spawner:SetMaterialParam(sVelocity, vel.x, vel.y, vel.z, 0)
end

function DeathEffects(spawner)
    Sleep(0)
    local avatar = spawner:GetCreator()
    local vel = Vector()
    if not IsNull(avatar) and avatar:IsA(gLotusAvatarType) then
        vel = avatar:GetVelocity()
    else
        --Dirty, but fallback in case we have the ragdoll at this point
        vel.x = spawner:GetMaterialParam(sVelocity, 1)
        vel.y = spawner:GetMaterialParam(sVelocity, 2)
        vel.z = spawner:GetMaterialParam(sVelocity, 3)
    end
    local t = 0
    local decos = {}
    local rot = spawner:GetRotation()
    local pos = spawner:GetPosition()
    local rRotAmount = 80
    for i=1, #deathDecos do
        local deco = gRegion:CreateEntity(deathDecos[i], pos, rot)
        if not IsNull(deco) then
            deco:SetTestRotateSpeed(Rotation(math.random(-rRotAmount, rRotAmount), math.random(-rRotAmount, rRotAmount), math.random(-rRotAmount, rRotAmount)))
            table.insert(decos, deco)
        end
    end
    while t < 1 do
        local dt = DeltaTime()
        VectorAdd(pos, pos, vel * dt)
        for i=1, #decos do
            if not IsNull(decos[i]) then
                decos[i]:SetPosition(pos)
            end
        end
        Sleep(0)
        t = t + dt * 0.2
    end
    spawner:Destroy()
end

function DissolveParentOnPreDeath(spawner)
    Sleep(0)
    local avatar = spawner:GetAttachParent()
    while not IsNull(avatar) do
        local t = 0
        local val = 0
        local deathExplosion = nil
--~         Effects.DisableChildParticleSystems(avatar, gParticleSysType)
        local trails = avatar:GetAllAttachments(trailType)
        for i=1, #trails do
            trails[i]:SetSpewCount(0,0,false)
        end
        local label = avatar:GetAttachment(labelType)
        if not IsNull(label) then
            label:Destroy()
        end        
        if Delay > 0 then Sleep(Delay) end
        if not IsNull(deathSpawner) and not IsNull(avatar) then 
            deathExplosion = avatar:Attach(deathSpawner, EMPTY_SYMBOL)
        end
        while t <= dissolveDuration and not IsNull(avatar) do
            val = Lerp(0,1, t/dissolveDuration)
            avatar:SetDissolve(val)
            t = t + DeltaTime()
            Sleep(0)
        end
    end
end

function ImmediateSetVisibility(e)
    e:SetVisibility(false)
end

function DockingShake(spawner)
    local postProcess = gRegion:GetLevelInfo().postProcess
    local t = 0
    local shakeAtten = 3
    while t < 1 do
        postProcess.viewShake.mShakeAmbient = shakeAtten * t * t
        Sleep(0)
        t = t + DeltaTime() * 0.1
    end
    Sleep(2)
    while t > 0 do
        postProcess.viewShake.mShakeAmbient = shakeAtten * t
        Sleep(0)
        t = t - DeltaTime() * 0.25
    end
    postProcess.viewShake.mShakeAmbient = 0
end

function LaunchBlurCheat(cinematic, deco)
    if IsNull(deco) then
        return
    end
    local engines = deco:GetAttachment(WeakResource("/Lotus/Objects/Tenno/Ships/RailJack/Engines/RailJackEngineDefault"))
    --Day before TC and this thing is still blurry
    if not IsNull(engines) then
        local sJustUpdate = Symbol("JustUpdate")
        engines:SetMaterialParam(sJustUpdate, 1, 0, 0, 0, true)
        Sleep(1)
        if not IsNull(engines) then
            engines:RemoveMaterialParam(sJustUpdate)
        end
    end
end