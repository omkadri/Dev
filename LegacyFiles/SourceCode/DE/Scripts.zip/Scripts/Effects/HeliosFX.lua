-- material fx etc for Helios

OriginalValue = 1 
NewValue = 2 
TimeLength = 1
Peak = 0.5
PeakValue = 1
ValleyValue = 0
Param = Symbol()
ParamV = Symbol()
Delay = 0
SkyBoxTag = Symbol()
BeamTag = Symbol()

LockAnimNorth = Resource()
LockAnimSouth = Resource()
LockAnimEast = Resource()
LockAnimWest = Resource()

local BURNVECTOR = Symbol("BurnVector")

function PhaseThreeFireFade(deco)
    Sleep(Delay)
    local SkyArray = gRegion:FindTagged(SkyBoxTag)
    local t = 0
    local fading
    local val
    local sunRot = Rotation()

    while t < TimeLength do
        if t < Peak then
            fading = t/Peak
        else
            fading = 1 - (t-Peak)/(TimeLength-Peak)
        end
        if fading < 0 then
            fading = 0
        end
        if not IsNull(SkyArray) and not IsNull(SkyArray[1]) then
            local temp = SkyArray[1]
            sunRot = temp:GetRotation()
            local sunVec = AngleToDirection(sunRot)
            deco:SetMaterialParam(ParamV, sunVec.x, 0, sunVec.z)
        end
        val = Lerp(ValleyValue, PeakValue, fading)
        deco:SetMaterialParam(Param, val)
        t = t + DeltaTime() 
        Sleep(0)
    end
end

function PhaseThreeFireVentsFade(deco)
    Sleep(Delay)
    local SkyArray = gRegion:FindTagged(SkyBoxTag)
    local t = 0
    local fading
    local val
    local sunRot = Rotation()
    local adjRot = Rotation()
    local adjPos = Vector(0,0,-2.72)
    local parentFade = 1.0
    local parentOne = deco:GetAttachParent()
    while t < TimeLength do
        if not IsNull(parentOne) then
            parentFade = parentOne:GetDelta()
        end
        if t < Peak then
            fading = t/Peak
        else
            fading = 1 - (t-Peak)/(TimeLength-Peak)
        end
        if fading < 0 then
            fading = 0
        end
        if not IsNull(SkyArray) and not IsNull(SkyArray[1]) then
            local temp = SkyArray[1]
            sunRot = temp:GetRotation()
            local tempHead = sunRot.heading
            if tempHead > 60 then
                adjRot.heading = 120
                sunRot.heading = sunRot.heading-120
                local sunVec = AngleToDirection(sunRot)
                deco:SetAttachLocalSpace(adjPos, adjRot)
                deco:SetMaterialParam(ParamV, sunVec.x, 0, sunVec.z)
            else if tempHead < -60 then
                adjRot.heading = -120
                sunRot.heading = sunRot.heading+120
                local sunVec = AngleToDirection(sunRot)
                deco:SetAttachLocalSpace(adjPos, adjRot)
                deco:SetMaterialParam(ParamV, sunVec.x, 0, sunVec.z)
            else
                adjRot.heading = 0
                local sunVec = AngleToDirection(sunRot)
                deco:SetAttachLocalSpace(adjPos, adjRot)
                deco:SetMaterialParam(ParamV, sunVec.x, 0, sunVec.z)
            end
            end
            
        end
        val = Lerp(ValleyValue, PeakValue, fading*parentFade)
        deco:SetMaterialParam(Param, val)
        t = t + DeltaTime() 
        Sleep(0)
    end
end

function Phase3VentLockDeath(lockDeco)
    local SkyArray = gRegion:FindTagged(SkyBoxTag)
    if not IsNull(SkyArray) and not IsNull(SkyArray[1]) then
        local temp = SkyArray[1]
        local sunRot = temp:GetRotation()
        local tempHead =  45 - sunRot.heading
        if tempHead > 0 then
            if tempHead > 90 then
                lockDeco:PlayAnimation(LockAnimEast, false, false)
            else
                lockDeco:PlayAnimation(LockAnimSouth, false, false)
            end
        else
            if tempHead < -90 then
                lockDeco:PlayAnimation(LockAnimNorth, false, false)
            else
                lockDeco:PlayAnimation(LockAnimWest, false, false)
            end
        end
    else
        lockDeco:PlayAnimation(LockAnimNorth, false, false)
    end
end

function Phase3WindRotation(windDeco)
    Sleep(1.0)
    local SkyArray = gRegion:FindTagged(SkyBoxTag)
    local windRot = Rotation()
    if not IsNull(SkyArray) then
        while true do
            local temp = SkyArray[1]
            if not IsNull(temp) then
                local sunRot = temp:GetRotation()
                windRot.heading = 90 + sunRot.heading
                windDeco:SetRotation(windRot)
            end
            Sleep(0.0)
        end
    end
end

function ProjectorBurnAwayFade(deco)
    local playerPos = deco:GetAttachParent():GetPosition()
    --Check for phase 2, need a more elegant solution here
    local isPhaseTwo = false
    if (playerPos.x < -40) and (playerPos.z < 300) then
        isPhaseTwo = true
    end
    local SkyArray
    if isPhaseTwo == true then
        SkyArray = gRegion:FindTagged(BeamTag)
    else
        SkyArray = gRegion:FindTagged(SkyBoxTag)
    end
    local sunVec = Vector()
    
    if not IsNull(SkyArray) then
        while true do
            local temp = SkyArray[1]
            if not IsNull(temp) then
                if isPhaseTwo == true then
                    playerPos = deco:GetAttachParent():GetPosition()
                    local sunPos = temp:GetPosition()
                    sunVec = playerPos - sunPos
                    deco:SetMaterialParam(BURNVECTOR, sunVec.x, sunVec.y, sunVec.z)
                else
                    local sunRot = temp:GetRotation()
                    sunRot.heading = sunRot.heading + 90
                    sunVec = AngleToDirection(sunRot)
                    deco:SetMaterialParam(BURNVECTOR, sunVec.x, 0, sunVec.z)
                end
            end
            Sleep(0.0)
        end
    end
end