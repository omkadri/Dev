Delay = 0
TimeLength = 2
Peak = 1
ParamValleyValue = 1
ParamPeakValue = 2
ScaleValleyValue = 1
ScalePeakValue = 2
Param = Symbol("UnlitAtten")
DoScaling = true
DoParam = true
TargetDeco = {Instance()}

local function easeOutBack(t,d,b,c)
    local s=1.70158
    t=t/d-1
    return c*(t*t*((s+1)*t+s)+1)+b
end


local function bias(biasAmount, value)
    return value / (( 1/biasAmount-2)*(1-value)+1)
end

-- quadratic easing out - decelerating to zero velocity
local function easeOutQuad(t, b, c, d)
    t=t/d
    return -c * t*(t-2) + b
end

-- exponential easing out - decelerating to zero velocity
local function easeOutExpo(t, b, c, d)
    if (t==d) then
        return b+c
    else
        return c * (-math.pow(2, -10 * t/d) + 1) + b
    end
end

-- sinusoidal easing in/out - accelerating until halfway, then decelerating
local function easeInOutSine(t, b, c, d)
    return -c/2 * (math.cos(math.pi*t/d) - 1) + b;
end

function MaterialFadePeakMeshScale(deco)
    Sleep(Delay)
    local t = 0
    local fading
    local val
    local scaleVal
    local starting = true
    while t < TimeLength do
        if not IsNull(TargetDeco) then
            for j = 1, #TargetDeco do
                local temp = TargetDeco[j]
                if t < Peak then
                    fading = t/Peak
                else
                    starting = false
                    fading = 1 - (t-Peak)/(TimeLength-Peak)
                end
                if fading < 0 then
                    fading = 0
                end
                if DoParam then
                    val = Lerp(ParamValleyValue, ParamPeakValue, fading)
                    temp:SetMaterialParam(Param, val)
                end
                if DoScaling == true then
                    if starting == true then
                        scaleVal = easeOutQuad(fading, ScaleValleyValue, ScalePeakValue-ScaleValleyValue, Peak)
                    else
                        scaleVal = easeInOutSine(t-Peak, ScalePeakValue, ScaleValleyValue-ScalePeakValue, TimeLength-Peak)
                    end
                    -- print(t-Peak)
                end
                temp:SetMeshScale(scaleVal)
            end
        end
        t = t + DeltaTime() 
        Sleep(0)
    end
end
