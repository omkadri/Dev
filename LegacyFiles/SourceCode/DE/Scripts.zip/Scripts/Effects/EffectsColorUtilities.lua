module(..., package.seeall)

local function _ApplyHighLow(deco, energyColor)
    if IsNull(energyColor) then
        return
    end
    local tempColor = Lotus_Game.LotusWeapon_GetLowColor(energyColor)
    deco:SetMaterialParam(Lotus_Game.LOW_COLOR, tempColor.red / 255, tempColor.green / 255, tempColor.blue / 255, 1)
    tempColor = Lotus_Game.LotusWeapon_GetHighColor(energyColor)
    deco:SetMaterialParam(Lotus_Game.HIGH_COLOR, tempColor.red / 255, tempColor.green / 255, tempColor.blue / 255, 1)
end

function ApplyHighLow(deco, energyColor)
    _ApplyHighLow(deco, energyColor)
end

local function _ApplyHighLowOnParticleSysChildren(entity, energyColor)
    if IsNull(energyColor) or IsNull(energyColor) then
        return
    end
    local tempColor = Lotus_Game.LotusWeapon_GetLowColor(energyColor)
    Effects.ScriptSetMaterialParamChildParticleSystems(entity, Lotus_Game.LOW_COLOR, tempColor.red / 255, tempColor.green / 255, tempColor.blue / 255, 1)
    tempColor = Lotus_Game.LotusWeapon_GetHighColor(energyColor)
    Effects.ScriptSetMaterialParamChildParticleSystems(entity, Lotus_Game.HIGH_COLOR, tempColor.red / 255, tempColor.green / 255, tempColor.blue / 255, 1)
end

function ApplyHighLowOnParticleSysChildren(entity, energyColor)
    _ApplyHighLowOnParticleSysChildren(entity, energyColor)
end

function ApplyEnergyTints(deco, energyColor, hiColor, loColor)
    if IsNull(energyColor) or IsNull(hiColor) or IsNull(loColor) then
        return
    end
    deco:SetMaterialParam(Lotus_Game.TINT_COLOR, energyColor.red / 255, energyColor.green / 255, energyColor.blue / 255, 1)
    deco:SetMaterialParam(Lotus_Game.LOW_COLOR, loColor.red / 255, loColor.green / 255, loColor.blue / 255, 1)
    deco:SetMaterialParam(Lotus_Game.HIGH_COLOR, hiColor.red / 255, hiColor.green / 255, hiColor.blue / 255, 1)
end

local function _SRGBToLinear(srgb) -- takes 0:1
    if (srgb <= 0.03928) then
        return srgb / 12.92
    else
        return math.pow((srgb + 0.055) / 1.055, 2.4)
    end
end

function ApplyEnergyTintsSRGB(deco, energyColor, hiColor, loColor)
    if IsNull(energyColor) or IsNull(hiColor) or IsNull(loColor) then
        return
    end
    deco:SetMaterialParam(Lotus_Game.TINT_COLOR, _SRGBToLinear(energyColor.red / 255), _SRGBToLinear(energyColor.green / 255), _SRGBToLinear(energyColor.blue / 255), 1)
    deco:SetMaterialParam(Lotus_Game.LOW_COLOR, loColor.red / 255, loColor.green / 255, loColor.blue / 255, 1)
    deco:SetMaterialParam(Lotus_Game.HIGH_COLOR, hiColor.red / 255, hiColor.green / 255, hiColor.blue / 255, 1)
end

local function _ApplyColor(deco, avatar, param, colorSlot, attribute, scale)
    if not scale then
        scale = 1.0
    end
    local matParam = Lotus_Game.TINT_COLOR
    if not IsNull(param) then
        matParam = param
    end
    local suit = avatar:InventoryControl():GetActivePowerSuit()
    if not IsNull(suit) then
        local playerCustomization = suit:GetCustomization()
        local colors = playerCustomization:GetColors(colorSlot)
        if colors:Initialized(attribute) then
            local color = Color(colors:GetColor(attribute))
            if deco:IsA(gParticleSysType) then
                deco:SetColorMinMax(color, color)
            else
                deco:SetMaterialParam(matParam, _SRGBToLinear(color.red / 255) * scale, _SRGBToLinear(color.green / 255) * scale, _SRGBToLinear(color.blue / 255) * scale, 1)
            end
            _ApplyHighLow(deco, color)
        else
            deco:RemoveMaterialParam(matParam)
        end
    end
end

function ApplyEnergyColor(deco, avatar, param, scale)
    _ApplyColor(deco, avatar, param, Lotus_Game.PrimaryColors, Lotus_Game.EnergyColor, scale)
end

function ApplyColor(deco, avatar, param, colorSlot, attribute)
    _ApplyColor(deco, avatar, param, colorSlot, attribute)
end

function ApplyColorFromSuitOrWeapon(deco, entity)
    if not IsNull(entity) then
        entity:ApplyEnergyColor(deco)
    end
end

function ApplyEnergyTint(entity, avatar)
    local color = Color(4, 100, 220, 255)
    local suit = avatar:InventoryControl():GetActivePowerSuit()
    if not IsNull(suit) then
        local playerCustomization = suit:GetCustomization()
        local colors = playerCustomization:GetColors(Lotus_Game.PrimaryColors)
        if colors:Initialized(Lotus_Game.EnergyColor) then
            color = Color(colors:GetColor(Lotus_Game.EnergyColor))
        end
    end
    entity:SetTint(color)
end

function EnergyHighColor(inColor)
    return Lotus_Game.LotusWeapon_GetHighColor(inColor)
end

function EnergyLowColor(inColor)
    return Lotus_Game.LotusWeapon_GetLowColor(inColor)
end

function LinearToSRGB(inColor)
    local outColor = Color()
    local s1 = math.sqrt(inColor.red / 255)
    local s2 = math.sqrt(s1)
    local s3 = math.sqrt(s2)
    outColor.red = Clamp(0.585 * s1 + 0.783 * s2 - 0.368 * s3, 0.0, 1.0) * 255;
    s1 = math.sqrt(inColor.green / 255)
    s2 = math.sqrt(s1)
    s3 = math.sqrt(s2)
    outColor.green = Clamp(0.585 * s1 + 0.783 * s2 - 0.368 * s3, 0.0, 1.0) * 255;
    s1 = math.sqrt(inColor.blue / 255)
    s2 = math.sqrt(s1)
    s3 = math.sqrt(s2)
    outColor.blue = Clamp(0.585 * s1 + 0.783 * s2 - 0.368 * s3, 0.0, 1.0) * 255;
    outColor.alpha = inColor.alpha
    return outColor
end

function SRGBToLinear(srgb) --Takes in 0-255 returns 0-1
    return _SRGBToLinear(srgb / 255)
end

function SRGBToLinear255(inColor) --Takes in 0-255 returns 0-255 color
    local outColor = Color()
    outColor.red =  _SRGBToLinear(inColor.red / 255) * 255
    outColor.green =  _SRGBToLinear(inColor.green / 255) * 255
    outColor.blue =  _SRGBToLinear(inColor.blue / 255) * 255
    outColor.alpha = inColor.alpha
    return outColor
end

function RGBToHSV(rgbColor)
    --Convert to HSV
    local red = rgbColor.red / 255
    local green = rgbColor.green / 255
    local blue = rgbColor.blue / 255
    local minVal = math.min(red, green, blue)
    local maxVal = math.max(red, green, blue)
    local deltaVal = maxVal - minVal
    local deltaR = 0
    local deltaG = 0
    local deltaB = 0
    local H = 0.0
    local S = 0.0
    if (maxVal > 0) then
        S = deltaVal / maxVal
    end
    local V = maxVal
    if (deltaVal > 0) then
        deltaR = (((maxVal - red) / 6) + (deltaVal / 2)) / deltaVal
        deltaG = (((maxVal - green) / 6) + (deltaVal / 2)) / deltaVal
        deltaB = (((maxVal - blue) / 6) + (deltaVal / 2)) / deltaVal
    end
    if (red == maxVal) then
        H = deltaB - deltaG
    elseif (green == maxVal) then
        H = (1/3) + deltaR - deltaB
    elseif (blue == maxVal) then
        H = (2/3) + deltaG - deltaR
    end
    if (H < 0) then
        H = H + 1
    end
    if (H > 1) then
        H = H - 1
    end
    return H, S, V
end

function HSVToRGB(H, S, V)
    --Convert to RGB
    local red
    local green
    local blue
    H = H * 6
    if (H == 6) then
        H = 0
    end
    local I = math.floor(H)
    local valOne = V * (1 - S)
    local valTwo = V * (1 - S * (H-I))
    local valThree = V * (1 - S * (1 - (H-I)))
    if (I == 0) then
        red = V
        green = valThree
        blue = valOne
    elseif (I == 1) then
        red = valTwo
        green = V
        blue = valOne
    elseif (I == 2) then
        red = valOne
        green = V
        blue = valThree
    elseif (I == 3) then
        red = valOne
        green = valTwo
        blue = V
    elseif (I == 4) then
        red = valThree
        green = valOne
        blue = V
    else
        red = V
        green = valOne
        blue = valTwo
    end
    local C = Color()
    C.red = math.abs(red * 255)
    C.green = math.abs(green * 255)
    C.blue = math.abs(blue * 255)
    C.alpha = 255
    return(C)
end

function ParticleQuality()

    if not gClient then
        return GraphicsRes.PQ_LOW
    end

    local graphicsSys = gClient:GetGraphicsSys()
    local customDisplaySettings = graphicsSys:GetCustomDisplaySettings()
    local pQ = customDisplaySettings.particleSysQuality
    return pQ
end