voidEntities = { Instance() }
earthEntities = { Instance() }

local triggerTag = Symbol("MoonBaseSkyboxFade")
local sUnlitAtten = Symbol("UnlitAtten")

function FadeSkyboxToEarth()
    local t = 0
    for i, entity in ipairs(earthEntities) do
        if not IsNull(entity) then
            entity:SetVisibility(true, false)
        end
    end
    while t < 1 do
        for i, entity in ipairs(voidEntities) do
            if not IsNull(entity) then
                --entity:SetDissolve(t)
                entity:SetMaterialParam(sUnlitAtten, 1 - t)
            end
        end
        
        for i, entity in ipairs(earthEntities) do
            if not IsNull(entity) then
                --entity:SetDissolve(1 - t)
                entity:SetMaterialParam(sUnlitAtten, t)
            end
        end
        
        t = t + DeltaTime() * 0.2
        Sleep(0)
    end
    
    for i, entity in ipairs(voidEntities) do
        if not IsNull(entity) then
            entity:SetVisibility(false, false)
        end
    end
    for i, entity in ipairs(earthEntities) do
        if not IsNull(entity) then
            --entity:SetDissolve(0)
            entity:SetMaterialParam(sUnlitAtten, 1)
        end
    end
end

function TriggerSkyboxFade()
    local trigger = gRegion:FindFirstTagged(triggerTag)
    if not IsNull(trigger) then
        trigger:FirePort("Execute")
    end
end