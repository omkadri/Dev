baseValue = 0.05

decoType = Type()

local invulnHealth = 100000

function ShieldDamageEffects(shield)
    Sleep(0)
    local glowAmount = 0
    while true do
        local newHealth = shield:GetHealth()
        if newHealth < invulnHealth then
            glowAmount = glowAmount + 0.5
        end
        if newHealth > 0 then
            shield:SetHealth(invulnHealth)
        end
        shield:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, glowAmount + baseValue)
        glowAmount = math.max(0, math.min(glowAmount, 3) - DeltaTime())
        Sleep(0)
    end
end

function ControlMoaRotationEffect(spawner)
    Sleep(0)
    local base = 0.5
    local riot = spawner:GetAttachRoot()
    if IsNull(riot) then
        return
    end
    local allSpawns = riot:GetAllAttachments(spawner:GetType())
    if #allSpawns > 1 then
        return
    end
    local deco = riot:GetAttachment(decoType)
    if IsNull(deco) then
        return
    end
    local t = 0
    while t < 1 do
        if not IsNull(deco) then
            deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, base + t)
        end
        Sleep(0)
        t = t + DeltaTime() * 8
    end
    while t > 0 do
        if not IsNull(deco) then
            deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, base + t)
        end
        Sleep(0)
        t = t - DeltaTime() * 2
    end
end