zoneAttr = Instance()
newMeshScale = 0.2
attachEffect = Type()
hairMask = Resource()

function DecoScale(deco)
    while not IsNull(deco) do
        deco:SetMeshScale(newMeshScale, true)
        Sleep(0)
    end
end

function NeptuneSkybox()
    local zPos = Vector(720, -960, -600)
    local t = 0
    --Move the skybox to make things feel faster
    while not IsNull(zoneAttr) and not IsNull(gRegion:GetPlayingCinematic()) do
        zPos.z = zPos.z - DeltaTime() * 2
        zoneAttr:SetPosition(zPos)
        Sleep(0)
    end
end

function VisionFadeIn(spawner)
    local deco = spawner:GetAttachParent()
    if IsNull(deco) then
        return
    end
    local t = 1
    while t > 0 and not IsNull(deco) do
        deco:SetDissolve(t)
        Sleep(0)
        t = t - DeltaTime() * 1.25
    end
    deco:SetDissolve(0)
end

function VisionFadeOut(spawner)
    local deco = spawner:GetAttachParent()
    if IsNull(deco) then
        return
    end
    local aEffect = deco:GetAttachment(attachEffect)
    if not IsNull(aEffect) then
        aEffect:Destroy()
    end
    local t = 0
    while t < 1 and not IsNull(deco) do
        deco:SetDissolve(t)
        Sleep(0)
        t = t + DeltaTime() * 1.8
    end
end

function VisionWindUpdate(wind)
    local offset = Vector(-2.5, 0.4, -1)
    --I'm doing nothing yet.
end

function SentientScareInit()
    local fogVolumes = gRegion:FindTagged(Symbol("SentientFog"))
    for i=1, #fogVolumes do
        fogVolumes[i]:SetAttenuation(0)
    end
    
    local lights = gRegion:FindTagged(Symbol("SentientLight"))
    for i=1, #lights do
        lights[i]:TurnOff()
    end
    local flares = gRegion:FindTagged(Symbol("SentientFlare"))
    for i=1, #flares do
        flares[i]:Disable()
    end
    
    local sky = gRegion:FindFirstTagged(Symbol("MainSky"))
    if not IsNull(sky) then
        sky:SetTimeOfDay(1)
    end
end

function SentientScareFadeIn()
    local fogVolumes = gRegion:FindTagged(Symbol("SentientFog"))
    local lights = gRegion:FindTagged(Symbol("SentientLight"))
    for i=1, #lights do
        lights[i]:TurnOn()
    end
    local flares = gRegion:FindTagged(Symbol("SentientFlare"))
    for i=1, #flares do
        flares[i]:Enable()
    end
    
    local spawners = gRegion:FindTagged(Symbol("SentientSpawner"))
    for i=1, #spawners do
        spawners[i]:Enable()
    end
    
    local sky = gRegion:FindFirstTagged(Symbol("MainSky"))
    
    local t = 0
    while t < 1 do
        for i=1, #fogVolumes do
            fogVolumes[i]:SetAttenuation(t)
        end
        if not IsNull(sky) then --We can move time to adjust rendering
            --sky:SetTimeOfDay(1 + t * 2) 
        end
        Sleep(0)
        t = t + DeltaTime() * 0.1
    end
end

function HairMask(cin, operator)
    local hairType = WeakResource("/Lotus/Characters/Tenno/Operator/Heads/AdultMaleOperatorA/Cloth/AdultMaleHairASkeletalCloth")
    local hair = operator:GetAttachment(hairType)
    if not IsNull(hair) then
        hair:SetTextureOverride(0, "SphericalMap", hairMask)
    end
end

function VoidTransitionPost(cinematic)
    local postProcess = gRegion:GetLevelInfo().postProcess
    local bloom = 1
    while not IsNull(postProcess) do
        postProcess.bloom = bloom
        bloom = bloom + DeltaTime() * 0.5
        Sleep(0)
    end
end

function LotusBackgroundGlow(spawner)
    local levelInfo = spawner:GetRegionMgr():GetLevelInfo()
    local t = 0
    --levelInfo.postProcess.fade = t
    while t < 1 do
        t = t + DeltaTime() * .16
        levelInfo.postProcess.fade = (0 - t * t)
        Sleep(0)
    end
    levelInfo.postProcess.fade = -1
end