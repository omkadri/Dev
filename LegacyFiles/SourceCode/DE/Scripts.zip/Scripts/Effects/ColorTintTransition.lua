target = Instance()
tintDelay = 0
tintStart = Color()
tintEnd = Color()
tintTimelength = 5
colorParam = Symbol()

function ColorTint(Deco)
    Sleep(tintDelay)
    local t = 0
    local tint = Color()
    while t < tintTimelength do
        tint.red = Lerp(tintStart.red, tintEnd.red, t/tintTimelength)
        tint.green = Lerp(tintStart.green, tintEnd.green, t/tintTimelength)
        tint.blue = Lerp(tintStart.blue, tintEnd.blue, t/tintTimelength)
        tint.alpha = Lerp(tintStart.alpha, tintEnd.alpha, t/tintTimelength)
        Deco:SetMaterialParam(Lotus_Game.TINT_COLOR, tint.red/255, tint.green/255, tint.blue/255, tint.alpha/255)
        t = t + DeltaTime()
        Sleep(0)
    end
end

function ParamTint(Deco)
    Sleep(tintDelay)
    local t = 0
    local tint = Color()
    while t < tintTimelength do
        tint.red = Lerp(tintStart.red, tintEnd.red, t/tintTimelength)
        tint.green = Lerp(tintStart.green, tintEnd.green, t/tintTimelength)
        tint.blue = Lerp(tintStart.blue, tintEnd.blue, t/tintTimelength)
        tint.alpha = Lerp(tintStart.alpha, tintEnd.alpha, t/tintTimelength)
        Deco:SetMaterialParam(colorParam, tint.red/255, tint.green/255, tint.blue/255, tint.alpha/255)
        t = t + DeltaTime()
        Sleep(0)
    end
end

function ParamTintTargeted()
    Sleep(tintDelay)
    local Deco = target
    local t = 0
    local tint = Color()
    while t < tintTimelength do
        tint.red = Lerp(tintStart.red, tintEnd.red, t/tintTimelength)
        tint.green = Lerp(tintStart.green, tintEnd.green, t/tintTimelength)
        tint.blue = Lerp(tintStart.blue, tintEnd.blue, t/tintTimelength)
        tint.alpha = Lerp(tintStart.alpha, tintEnd.alpha, t/tintTimelength)
        if not IsNull(Deco) then
            Deco:SetMaterialParam(colorParam, tint.red/255, tint.green/255, tint.blue/255, tint.alpha/255)
        end
        t = t + DeltaTime()
        Sleep(0)
    end
end