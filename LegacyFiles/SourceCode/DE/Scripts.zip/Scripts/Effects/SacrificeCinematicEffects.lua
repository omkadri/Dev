decoTag = Symbol("MimicDecoA")
decoRoundness = 0.3
projType = Type()

colorCorrection = Resource()

helmetType = WeakResource()
regrowthProjType = WeakResource()

sentientBeamType = Type()
sentientBeamEndPoint = Type()


hiddenMat = Resource()

treeStumpMesh = Resource()

sentientsThatFire = { Instance() }
firingEffect = Type()

lotusShieldType = Type()

newPostFxMat = Resource()

local sTintColor = Symbol("TintColor")
local sTintColor0 = Symbol("TintColor0")
local sTintColor1 = Symbol("TintColor1")
local sTintColor2 = Symbol("TintColor2")
local sTintColor3 = Symbol("TintColor3")
local sEmissiveTintColor = Symbol("EmissiveTintColor")
local sEmissiveTintColorHi = Symbol("EmissiveTintColorHi")
local sFitAtten = Symbol("FitAtten")
local sShapeCenter = Symbol("ShapeCenter")
local sShapeDimensions = Symbol("ShapeDimensions")
local sUnlitAtten = Symbol("UnlitAtten")
local sCloakVector = Symbol("CloakVector")

local function GetParam(deco, paramSym, backupColor)
    local material = deco:GetMaterialInSlot(0)
    local paramColor = Vector()
    if not IsNull(material) then
        paramColor.x = material:GetParam(paramSym, 1)
        paramColor.y = material:GetParam(paramSym, 2)
        paramColor.z = material:GetParam(paramSym, 3)
    end
    if paramColor.x > 5 then --Material param did not exist
        paramColor = backupColor
    end
    return paramColor
end

local function GetEmissive(deco)
    --Emissives could be using one of several parameters
    local material = deco:GetMaterialInSlot(0)
    local paramColor = Vector(.3, .3, .3)
    if not IsNull(material) then
        paramColor.x = material:GetParam(sEmissiveTintColorHi, 1)
        paramColor.y = material:GetParam(sEmissiveTintColorHi, 2)
        paramColor.z = material:GetParam(sEmissiveTintColorHi, 3)
        if paramColor.x > 10 then --Material param did not exist
            paramColor.x = material:GetParam(sEmissiveTintColor, 1)
            paramColor.y = material:GetParam(sEmissiveTintColor, 2)
            paramColor.z = material:GetParam(sEmissiveTintColor, 3)
        end
        if paramColor.x > 10 then --Material param did not exist
            paramColor.x = material:GetParam(sTintColor, 1)
            paramColor.y = material:GetParam(sTintColor, 2)
            paramColor.z = material:GetParam(sTintColor, 3)
        end
        if paramColor.x > 5 then --Material param did not exist
            paramColor = Vector(.3, .3, .3)
        end
    end
    return paramColor
end

local function ApplyColor(colorA, colorB, t, deco, colorSym)
    deco:SetMaterialParam(colorSym, Lerp(colorA.x, colorB.x, t), Lerp(colorA.y, colorB.y, t), Lerp(colorA.z, colorB.z, t), 1, true)
end

function CinematicMimicReveal(spawner)
    local sentientAvatar = spawner:GetAttachParent()

    if IsNull(sentientAvatar) then
        return
    end

    local currentRegion = sentientAvatar:GetRegionMgr()
    local deco = currentRegion:FindFirstTagged(decoTag)
    if not IsNull(deco) then
        --deco:PlayTriggeredFade()
    else
        return
    end
    local revealDuration = 1.5
    
    --Set up shader effect
    local proj = sentientAvatar:Attach(projType, EMPTY_SYMBOL)
    local targetCenter = deco:GetCenter()
    sentientAvatar:SetMaterialParam(sShapeCenter, targetCenter.x, targetCenter.y, targetCenter.z, 0, true)

    local bounds = (deco:GetBoundsMax() - targetCenter)-- * deco:GetMeshScale()
    local round = decoRoundness

    sentientAvatar:SetMaterialParam(sShapeDimensions, bounds.x, bounds.y, bounds.z, round, true)
    
    local backupColor = Vector(0.3, 0.3, 0.3)
    local sentientT0 = GetParam(sentientAvatar, sTintColor0, backupColor) --These could be hard coded
    local sentientT1 = GetParam(sentientAvatar, sTintColor1, backupColor)
    local sentientT2 = GetParam(sentientAvatar, sTintColor2, backupColor)
    local sentientT3 = GetParam(sentientAvatar, sTintColor3, backupColor)
    
    local targetT0 = GetParam(deco, sTintColor0, sentientT0)
    local targetT1 = GetParam(deco, sTintColor1, sentientT1)
    local targetT2 = GetParam(deco, sTintColor2, sentientT2)
    local targetT3 = GetParam(deco, sTintColor3, sentientT3)

    local sentientEnergyColor = GetParam(sentientAvatar, sEmissiveTintColorHi, backupColor)
    local targetEnergyColor = GetEmissive(deco)
    --end shader set up
    
    local timeElapsed = 0
    while timeElapsed < revealDuration do
        Sleep(0)
        timeElapsed = timeElapsed + DeltaTime()
        local val = math.min(timeElapsed / revealDuration, 1.0)
        
        if not IsNull(sentientAvatar) then
            --Shader fx
            local shaderVal = 1 - val
            local fitAtten = 1 - (val * val)
            sentientAvatar:SetMaterialParam(sFitAtten, fitAtten, 0, 0, 0, true)
            if not IsNull(proj) then
                local atten = 1 - 2 * (math.abs(0.5 - shaderVal))
                proj:SetMaterialParam(sUnlitAtten, 5 * atten)
                ApplyColor(sentientEnergyColor, targetEnergyColor, shaderVal, proj, sTintColor)
            end

            ApplyColor(sentientT0, targetT0, shaderVal, sentientAvatar, sTintColor0)
            ApplyColor(sentientT1, targetT1, shaderVal, sentientAvatar, sTintColor1)
            ApplyColor(sentientT2, targetT2, shaderVal, sentientAvatar, sTintColor2)
            ApplyColor(sentientT3, targetT3, shaderVal, sentientAvatar, sTintColor3)
            --end shader fx
            sentientAvatar:SetDissolve(math.max(0, 1.0 - 2 * val))
        end
        
        if not IsNull(deco) then
            deco:SetDissolve(math.min(1, 2 * val))
        end
        
    end

    if not IsNull(proj) then
        proj:Destroy()
    end
    
    if not IsNull(deco) then
        deco:Destroy()
    end
end

function SentientBeamFiring(spawner)
    local beam = spawner:Attach(sentientBeamType, EMPTY_SYMBOL)
    local t = 0
    local sword = spawner:GetRegionMgr():FindFirstTagged(Symbol("EnergySword"))    
    local offset = Vector(0, Random(0.2, 0.5), 0)
    local endPos = Vector()
    local endPoint = nil
    if not IsNull(sword) and not IsNull(beam) then
        endPoint = sword:Attach(sentientBeamEndPoint, EMPTY_SYMBOL, offset)
    end
    while t < 1 and not IsNull(beam) and not IsNull(sword) and not IsNull(endPoint) do
        endPos = endPoint:GetSimPosition()
        beam:SetEndPoint(endPos)
        t = t + DeltaTime() * 0.5
        Sleep(0)
    end
    if not IsNull(endPoint) then
        endPoint:Destroy()
    end
    if not IsNull(beam) then
        beam:Destroy()
    end
end

function LotusBeamFiring(spawner)
    local region = spawner:GetRegionMgr()
    local beam = spawner:Attach(sentientBeamType, EMPTY_SYMBOL)
    local t = 0
    local deco = region:FindFirstTagged(Symbol("UmbraCinematicDeco"))    
    local offset = Vector()
    local endPos = Vector()
    local endPoint = nil
    if not IsNull(deco) and not IsNull(beam) then
        endPoint = deco:Attach(sentientBeamEndPoint, Symbol("GAME_C1_SPINE2"), offset)
    end
    while t < 1 and not IsNull(beam) and not IsNull(deco) and not IsNull(endPoint) do
        endPos = endPoint:GetSimPosition()
        beam:SetEndPoint(endPos)
        t = t + DeltaTime() * 0.8
        Sleep(0)
    end
    if not IsNull(endPoint) then
        endPoint:Destroy()
    end
    if not IsNull(beam) then
        beam:Destroy()
    end
end

function AllSentientsFire(cinematic)
    local waypoint = gRegion:FindFirstTagged(Symbol("SentientFiresAtThis"))
    if IsNull(waypoint) or #sentientsThatFire < 1 then
        return
    end
    local bone = Symbol("GAME_R1_ARM2")
    local offset = Vector(1, 0.03, 0)
    local endPos = waypoint:GetPosition()
    local endPoint = gRegion:CreateEntity(sentientBeamEndPoint, endPos, ZERO_ROTATION)
    for i=1, #sentientsThatFire do
        if not IsNull(sentientsThatFire[i]) then
            local beam = sentientsThatFire[i]:Attach(sentientBeamType, bone, offset)
            sentientsThatFire[i]:Attach(firingEffect, bone, offset)
            if not IsNull(beam) then
                beam:SetEndPoint(endPos + Vector(Random(-0.5, 0.5), 0, Random(-0.5, 0.5)))
            end
        end
        if i == 3 then --Last 3 use other arm
            bone = Symbol("GAME_L1_ARM2")
            offset = Vector(-1, 0.03, 0)
        end
        Sleep(0)
    end
    Sleep(1)
    if not IsNull(endPoint) then
        endPoint:Destroy()
    end
end

function UmbraBlocked(spawner)
    local region = spawner:GetRegionMgr()
    if IsNull(region) then
        return
    end
    local levelInfo = region:GetLevelInfo()
    if IsNull(levelInfo) then
        return
    end
    local postProcess = levelInfo.postProcess
    if IsNull(postProcess) then
        return
    end
    local deSatColor = Color(94, 12, 12, 255)
    local startSat = postProcess.saturation
    postProcess.desaturateColor = deSatColor
    postProcess.saturation = 0.0

    local t = 0
    while t < 1 do
        postProcess.saturation = Lerp(0.0, startSat, t)
        postProcess.desaturateColor = deSatColor:Lerp(Color(255,255,255,255), t)
        t = t + DeltaTime() * 0.5
        Sleep(0)
    end
    postProcess.saturation = startSat
    postProcess.desaturateColor = Color(255, 255, 255, 255)
end

function IntroFadeIn(cinematic)
    local postVolume = cinematic:GetRegionMgr():FindFirstTagged(Symbol("ShrinePostVolume"))
    if not IsNull(postVolume) then
        postVolume:Disable()
    end
    local postProcess = cinematic:GetRegionMgr():GetLevelInfo().postProcess
    if IsNull(postProcess) then
        return
    end
    local t = 1
    while t > 0 do
        postProcess.fade = t
        t = t - DeltaTime() * 0.25
        Sleep(0)
    end
    postProcess.fade = 0
end

function ToShredsYouSay(cinematic)
    local region = cinematic:GetRegionMgr()
    if IsNull(region) then
        return
    end
    local levelInfo = region:GetLevelInfo()
    if IsNull(levelInfo) then
        return
    end
    local postProcess = levelInfo.postProcess
    if IsNull(postProcess) then
        return
    end
    local t = 0
    while t < 1 do
        postProcess.fade = -(t * t)
        t = t + DeltaTime() / 0.6
        Sleep(0)
    end
    postProcess.fade = -1
    t = 1
    Sleep(2)
    while t > 0 do
        postProcess.fade = -t
        t = t - DeltaTime() / 0.5
        Sleep(0)
    end
    postProcess.fade = 0
end

function MemoryAnger()
    local avatar = gRegion:GetLocalPlayerAvatar()
    if IsNull(avatar) then
        return
    end
    local cameraControl = avatar:CameraControl()
    if IsNull(cameraControl) then
        return
    end
    cameraControl:PushColorCorrection(colorCorrection, 0.1, 0.6, 5)
    cameraControl:RadialBlurView(1.5, 1.1, 1.1, 2.5)
    
    local t = 0
    while t < 1 do
        t = t + DeltaTime() * 0.4
        _T.InfWallAdd = 0.3 + t * 0.15
        Sleep(0)
    end
    --Do other stuff here?
end

function HideBaseHelmet(spawner)
    local damagedHelmet = gRegion:FindFirstTagged(Symbol("UmbraDamagedHelm"))
    if not IsNull(damagedHelmet) then
        damagedHelmet:SetDissolve(0)
    end
    local umbraDeco = spawner:GetAttachParent()
    if IsNull(umbraDeco) then
        return
    end
    local helmet = umbraDeco:GetAttachment(helmetType)
    if not IsNull(helmet) then
        helmet:SetDissolve(1)
        helmet:SetVisibility(false, false)
    end
end

function HelmetRegrowth(spawner)
    Sleep(0)
    local umbraDeco = spawner:GetAttachParent()
    if IsNull(umbraDeco) then
        return
    end
    local helmet = umbraDeco:GetAttachment(helmetType)
    local damagedHelmet = gRegion:FindFirstTagged(Symbol("UmbraDamagedHelm"))
    local proj = nil
    if not IsNull(damagedHelmet) then
        proj = damagedHelmet:GetAttachment(regrowthProjType) --Need this for world position
    end
    if not IsNull(helmet) then
        helmet:SetVisibility(true, false)
    end
    local t = 0
    local pos = Vector()
    while t < 1 and not IsNull(helmet) and not IsNull(damagedHelmet) and not IsNull(proj) do
        pos = proj:GetSimPosition()
        helmet:SetMaterialParam(sCloakVector, pos.x, pos.y, pos.z, 0.1)
        damagedHelmet:SetMaterialParam(sCloakVector, pos.x, pos.y, pos.z, 0.2)
        helmet:SetDissolve(1 - t)
        damagedHelmet:SetDissolve(math.max(0, t * 1.25 - 0.25))
        Sleep(0)
        t = t + DeltaTime() * 0.4 --Speed
    end
    if not IsNull(helmet) and not IsNull(damagedHelmet) then
        helmet:SetDissolve(0)
        damagedHelmet:SetDissolve(1)
    end
end

function LotusSpawnIn(spawner)
    local deco = spawner:GetAttachRoot()
    if IsNull(deco) then
        return
    end
    
    local t = 1
    local pos = Vector()
    deco:SetOverrideMaterial(0, hiddenMat, false)
    deco:SetOverrideMaterial(1, hiddenMat, false)
    deco:SetOverrideMaterial(11, hiddenMat, false)
    deco:SetMaterialParam(Symbol("CloakHDR"), 1.3, 1.3, 3, 1)
    while t > 0 do
        pos = deco:GetSimPosition()
        deco:SetDissolve(t * 0.2)
        deco:SetMaterialParam(Symbol("CloakVector"), pos.x, pos.y + 0.7, pos.z, 2)
        Sleep(0)
        t = t - DeltaTime() * 0.1
    end
end

function LotusLand(spawner)
    local tree = gRegion:FindFirstTagged(Symbol("TreeDeco"))
    if not IsNull(tree) then
        tree:SetMesh(treeStumpMesh, false, true)
    end
    local fire = gRegion:FindFirstTagged(Symbol("TreeFireFx"))
    if not IsNull(fire) then
        fire:Destroy()
    end
    local light = gRegion:FindFirstTagged(Symbol("TreeFireLight"))
    if not IsNull(light) then
        light:TurnOff()
    end
end

function LotusTakeOff(spawner)
    local deco = spawner:GetAttachParent()
    if not IsNull(deco) then
        local effect = deco:GetAttachment(lotusShieldType)
        if not IsNull(effect) then
            effect:Destroy()
        end
    end
    local postVolume = gRegion:FindFirstTagged(Symbol("ShrinePostVolume"))
    if IsNull(postVolume) then
        return
    end
    local postProcess = postVolume:GetPostProcessInfo()
    local viewShake = postProcess.viewShake
    local t = 0
    viewShake.mShakeSpeed = 2.5
    while t < 1 do
        viewShake.mShakeAmbient = (1 - t) * 12
        Sleep(0)
        t = t + DeltaTime() / 2
    end
    viewShake.mShakeAmbient = 0
end

function ScapePost(cinematic)
    local region = cinematic:GetRegionMgr()
    local postVolume = region:FindFirstTagged(Symbol("VitruvianPostVol"))
    if IsNull(postVolume) then
        return
    end
    local postProcess = postVolume:GetPostProcessInfo()
    local t = 0
    while t < 1 do
        postProcess.fade = -(t * t)
        Sleep(0)
        t = t + DeltaTime() * 0.5
    end
    t = 1
    postProcess.fade = -1
    postProcess:SetPostFxMaterial(newPostFxMat)
    local everythingToHide = region:FindTagged(Symbol("DecoToHide"))
    for i=1, #everythingToHide do
        everythingToHide[i]:SetVisibility(false, true)
    end
    local everythingToShow = region:FindTagged(Symbol("DecoToShow"))
    for i=1, #everythingToShow do
        everythingToShow[i]:SetVisibility(true, false)
    end
    local lightsToToggle = region:FindTagged(Symbol("LightToDisable"))
    for i=1, #lightsToToggle do
        lightsToToggle[i]:TurnOff()
    end
    Sleep(0.2)
    while t > 0 do
        postProcess.fade = -(t * t)
        Sleep(0)
        t = t - DeltaTime() * 0.8
    end
    postProcess.fade = 0
end