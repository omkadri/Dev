duration = 10
radius = 10
brightness = 20000

function LightRamp(light)
    local t = 0
    while t < duration do
        local smoothLerp = SmoothStep(t / duration)
        light:SetRadius(radius * smoothLerp)
        light:SetLumens(brightness * smoothLerp)
        t = t + DeltaTime()
        Sleep(0)
    end
end