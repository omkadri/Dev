weatherAmount = 0
timelength = 10
light = Instance()

local sHydroidRainDeco = Symbol("HydroidRainDeco")
local sRainAtten = Symbol("RainAtten")

function FinalCinSky()
    local sky = gRegion:FindAll(gDynamicSkyType)[1]
    if IsNull(sky) then
        return
    end

    local startTime = 18
    local endTime = 26
    local timeToChange = 8

    local timeRate = sky:GetTimeOfDayRate()
    sky:SetTimeOfDay(startTime)
    local newTimeRate = (endTime - startTime) / timeToChange
    sky:SetTimeOfDayRate(newTimeRate)

    Sleep(timeToChange)

    sky:SetTimeOfDay(endTime)
    sky:SetTimeOfDayRate(timeRate)
end

function UpdateWeather()
    local sky = gRegion:FindAll(gDynamicSkyType)[1]
    if not IsNull(sky) then
        sky:SetWeatherOverride(weatherAmount)
    end
    local deco = gRegion:FindFirstTagged(sHydroidRainDeco)
    local prevRain = 0
    if not IsNull(deco) then
        prevRain = deco:GetMaterialParam(sRainAtten, 1)
    end
    local t = 0
    while t < 1 and not IsNull(deco) do
        local val = Lerp(prevRain, weatherAmount, t)
        deco:SetMaterialParam(sRainAtten, val)
        Sleep(0)
        t = t + DeltaTime() / timelength
    end
end

function DimLight()
    if IsNull(light) then
        return
    end
    local brightness = light:GetBrightness()
    local t = 1
    while not IsNull(light) and t > 0 do
        Sleep(0)
        t = math.max(0, t - DeltaTime() / timelength)
        light:SetBrightness(brightness * t)
    end
end