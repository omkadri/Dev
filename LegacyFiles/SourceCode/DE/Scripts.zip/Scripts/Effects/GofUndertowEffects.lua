local shakeLib = require "Lotus.Scripts.Libs.ShakeLib"

effectToSpawn = Type()
effectToSpawnA = Type()
attachBone = Symbol("GAME_C1_HIP1")
SpewMax = 512
SpewMaxA = 32
local SpewBias = 0.15
DebugPlz = false

local function playerZinTrigger(trigger, instigatorAvatar, trigZDim)
    local worldZ = trigger:GetForwardVector()
    local a = trigger:GetPosition() - Vector(trigZDim/2 * worldZ.x,trigZDim/2 * worldZ.y,trigZDim/2 * worldZ.z) -- min
    local b = trigger:GetPosition() + Vector(trigZDim/2 * worldZ.x,trigZDim/2 * worldZ.y,trigZDim/2 * worldZ.z) -- max
    local avaPos = instigatorAvatar:GetPosition()
    local result = (Dot(avaPos,worldZ) - Dot(a, worldZ))/(Dot(b,worldZ) - Dot(a, worldZ))
    return(result)
end

local function bias(b,x)
    local output = x/((1/b-2)*(1-x)+1)
    if output < 0.01 then
        output = 0.01
    elseif output > 1 then
        output = 1
    end
    return output
end

function SetUndertowerEffects(trigger, instigatorAvatar)
    local hasEntered = false
    local avatar = instigatorAvatar
    local undertowEffect
    local undertowEffectA
    local trigDim = trigger:GetDimensions()
    local triggerZLen = trigDim.z
    local triggerDimMin = trigger:GetBoundsMin()
    local triggerDimMax = trigger:GetBoundsMax()
    local avaPos = avatar:GetPosition()
    local lastPostProcess = gRegion:GetLevelInfo().postProcess
    local postProcess = lastPostProcess
    if IsNull(avatar) or not avatar:IsA(gLotusAvatarType) or not avatar:ReplicaLocallyControlled() then return end
    
    while trigger:IsTouching(avatar) and not IsNull(avatar) do
        
        if not hasEntered then
            hasEntered = true
            undertowEffect = gRegion:CreateEntity(effectToSpawn, avatar:GetPosition(), trigger:GetRotation())
            undertowEffectA = gRegion:CreateEntity(effectToSpawnA, avatar:GetPosition(), trigger:GetRotation())
            local result = playerZinTrigger(trigger, avatar, triggerZLen)
            undertowEffect:SetSpewCount(SpewMax * bias(SpewBias,result), SpewMax * bias(SpewBias,result), false)
            undertowEffectA:SetSpewCount(SpewMax * bias(SpewMaxA,result), SpewMax * bias(SpewMaxA,result), false)
            avatar:AttachEntity(undertowEffect, attachBone, ZERO_VECTOR, trigger:GetRotation())
        end
       
        local t = 0
        while t < 1 do
            if not trigger:IsTouching(avatar) then
                hasEntered = false
                undertowEffect:SetSpewCount(0,0,false)
                undertowEffectA:SetSpewCount(0,0,false)
                postProcess.fade = lastPostProcess.fade
                postProcess.viewShake.mShakeSpeed =  lastPostProcess.viewShake.mShakeSpeed
                postProcess.viewShake.mShakeAmbient =  lastPostProcess.viewShake.mShakeAmbient
                postProcess.viewShake.mShakeSpeed =  lastPostProcess.viewShake.mShakeSpeed
                postProcess.radialBlurStrength = lastPostProcess.radialBlurStrength
                postProcess.radialBlurScale = lastPostProcess.radialBlurScale
                return
            else
                local result = playerZinTrigger(trigger, avatar, triggerZLen)
                if DebugPlz then print(result) end
                undertowEffect:SetSpewCount(SpewMax * bias(SpewBias,result), SpewMax * bias(SpewBias,result), false)
                undertowEffectA:SetSpewCount(SpewMaxA * bias(SpewBias,result), SpewMax * bias(SpewMaxA,result), false)
                local fadeAmount = bias(0.1, result)
                if fadeAmount < 0 then fadeAmount = 0 end
                postProcess.fade = fadeAmount
                postProcess.radialBlurScale = 1
                postProcess.radialBlurStrength = (bias(0.5,result)*2-0.5) * 5
                postProcess.viewShake.mShakeSpeed = bias(0.6,result) * 8
                postProcess.viewShake.mShakeAmbient = postProcess.viewShake.mShakeSpeed
            end
            t = t + DeltaTime()
            Sleep(0)
            
        end
    Sleep(0)
    end
    
end