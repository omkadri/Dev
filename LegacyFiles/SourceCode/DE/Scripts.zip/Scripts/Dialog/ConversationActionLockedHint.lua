lockedHintMovie = Resource()
locTag = Symbol()
offset = Vector()
rotation = Rotation()

local mText
local mLockedMovie


function LockedHint(action)
    Sleep(0)

    mText = Localize(locTag:c_str(), nil)
    lockedHintMovie = lockedHintMovie
    offset = offset
    rotation = rotation

    ObjectPortHandler(action, "OnEnable")
    ObjectPortHandler(action, "OnDisable")

    if not action:IsEnabled() then
        action:ScriptRunChildScript(Symbol("OnDisable"), true)
    end
end

function OnEnable(action)
    if not IsNull(mLockedMovie) then
        mLockedMovie:Close()
    end
end

function OnDisable(action)
    if not IsNull(mLockedMovie) then
        mLockedMovie:Close()
    end

    local root = action:GetAttachRoot()
    if not IsNull(root) and not root:IsVisible() then
        return
    end

    mLockedMovie = gFlashMgr:GotoMovie(lockedHintMovie)
    if not IsNull(mLockedMovie) then
        mLockedMovie:Execute("SetMessage", mText)
        mLockedMovie:Execute("SetOutOfService", "true")
        mLockedMovie:Execute("SetLiteMode", "true")
        
        mLockedMovie:AttachToEntity(action, offset, rotation, Vector(1, 1, 1))
    end
end
