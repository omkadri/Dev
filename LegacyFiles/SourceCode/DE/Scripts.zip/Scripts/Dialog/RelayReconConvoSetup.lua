challenges = { Resource() }
contributeSound = Resource()

local mStrutsIndex = 4
local mEssenceIndex = 2

local UTIL = require "EE.Interface.Utilities"

local function ContributeToChallenge(pScriptAction, pConversation, pChallenge, pSisterChallenge)
    if IsNull(gChallengeMgr) or IsNull(pChallenge) or IsNull(gGameData) then
        return
    end

    local currProgress = gChallengeMgr:GetChallengeProgress(pChallenge:GetName())
    local reqCount = pChallenge:GetRequiredCount()
    if currProgress >= reqCount then
        UTIL.ShowMessage("/Lotus/Language/RelayReconstruction/ContribAlreadyCompleted")
    else
        local personalCount = 0
        local inventory = gGameData:GetInventory()
        local miscItems = inventory:GetMiscItems()
        local itemType = pChallenge:GetItemType()
        for i = 1, #miscItems do
            if miscItems[i].mItemType == itemType then
                personalCount = miscItems[i].mItemCount

                break
            end
        end

        local needed = reqCount - currProgress
        if personalCount < needed then
            UTIL.ShowMessage(Localize("/Lotus/Language/RelayReconstruction/ContribInsufficient", { COUNT = UTIL.FormatNumber(needed - personalCount) }))
        else
            gChallengeMgr:NotifyTagMultiple(gRegion:GetLocalPlayer(), pChallenge:GetGameTag(), needed, nil, itemType)
            --gGameData:SaveCountedItemForChallengeUpload(itemType, -needed) -- This function has been removed, check P4 history if we need to bring it back!
            pConversation:ResetCallbackResult()
            gGameData:UploadChallengeProgress("OnCallbackRecieved")

            local callbackResult = nil
            _T.BackgroundMovie:Execute("ShowBlockingMessage", "2")
            while(callbackResult == nil) do
                Sleep(0)
                callbackResult = pConversation:GetCallbackResult()
            end
            _T.BackgroundMovie:Execute("ShowBlockingMessage", "0")

            if callbackResult then
                -- If sister challenge is also complete, play a different transmission.
                local transTag = "Donate"
                if gChallengeMgr:GetChallengeProgress(pSisterChallenge:GetName()) >= pSisterChallenge:GetRequiredCount() then
                    transTag = "DonateComplete"
                end
                local transmission = pConversation.mTransmissionSet:GetTransmission(Symbol(transTag))
                if not IsNull(transmission) then
                    pConversation:PlayDialog(transmission, nil, false, true)
                end
                transmission = pConversation.mTransmissionSet:GetTransmission(Symbol("RukDonateComplete"))
                if not IsNull(transmission) then
                    pConversation:PlayDialog(transmission, nil, false, false)
                end
                if not IsNull(contributeSound) then
                    UTIL.PlaySound(contributeSound)
                end

                -- Update JunctionTasks screen so it show proper challenge info.
                local junctionTasks = gFlashMgr:FindMovie(WeakResource("/Lotus/Interface/JunctionTasks.swf"))
                if not IsNull(junctionTasks) then
                    junctionTasks:Execute("OnWorldStateChanged", "")
                end
            else
                UTIL.ShowMessage("/Lotus/Language/RelayReconstruction/ContribFailed")
            end
        end
    end

    pConversation.mReset = true
end

function InitializeDialogOptions(pScriptAction)
    if _T.TaggedDialog == nil then
        _T.TaggedDialog = {}
    end

    _T.TaggedDialog["RelayRecon_ContribStruts"] =
    {
        mName = "/Lotus/Language/RelayReconstruction/ContribStruts_Tag",
        mCallback = 
            function(pConversation)
                ContributeToChallenge(pScriptAction, pConversation, challenges[mStrutsIndex], challenges[mEssenceIndex])
            end
    }

    _T.TaggedDialog["RelayRecon_ContribEssence"] =
    {
        mName = "/Lotus/Language/RelayReconstruction/ContribEssence_Tag",
        mCallback = 
            function(pConversation)
                ContributeToChallenge(pScriptAction, pConversation, challenges[mEssenceIndex], challenges[mStrutsIndex])
            end
    }

    _T.TaggedDialog["RelayRecon_LearnMore"] =
    {
        mName = "/Lotus/Language/RelayReconstruction/LearnMore_Tag",
        mCallback = 
            function(pConversation)

            end
    }

    _T.OnRRConversationStarted =
        function(pConversation)
            local allChallengesComplete = true
            for i = 1, #challenges do
                local currProgress = gChallengeMgr:GetChallengeProgress(challenges[i]:GetName())
                local reqCount = challenges[i]:GetRequiredCount()
                if currProgress < reqCount then
                    allChallengesComplete = false

                    break
                end
            end

            local transTag = "Intro"
            if allChallengesComplete then
                transTag = "AllTasksComplete"
            end
            local transmission = pConversation.mTransmissionSet:GetTransmission(Symbol(transTag))
            if not IsNull(transmission) then
                pConversation:PlayDialog(transmission, nil, false, true)
            end
        end
end
