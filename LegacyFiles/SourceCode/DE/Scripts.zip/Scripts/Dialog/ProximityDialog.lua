transmissionSet = Resource()
transmissionTag = Symbol()
chance = 1.0
cooldown = 60 -- -1 = only once
doRaycast = false

local sRaycastTargetBone = Symbol("GAME_C1_SPINE1")

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"


function ProximityDialog(trigger, instigator)
    local gameRules = gGameRules
    if IsNull(gameRules) or IsNull(instigator) then
        return
    end

    local id
    local ignoreEntities
    local parent = trigger:GetAttachParent()
    if IsNull(parent) then
        id = trigger:GetFullName()
        ignoreEntities = not doRaycast or {}
    else
        id = parent:GetFullName()
        ignoreEntities = not doRaycast or parent:GetAllAttachments(gEntityType)
    end

    local currentTime = gameRules:GetCurrentGameTime()
    
    local proximityDialog = _T.ProximityDialog or {}
    _T.ProximityDialog = proximityDialog
    if not proximityDialog[id] or proximityDialog[id].resetTime < currentTime then
        if Random(0, 1) < chance then
            if doRaycast then
                local from = trigger:GetPosition()
                local to = instigator:GetBonePosition(sRaycastTargetBone)
                local hitEntity = gRegion:RaycastEntityIgnoreMany(from, to, ignoreEntities)
                if hitEntity ~= instigator then
                    return
                end
            end

            proximityDialog[id] = proximityDialog[id] or {}
            local resetTime = FLT_MAX
            if cooldown >= 0 then
                resetTime = currentTime + cooldown
            end
            proximityDialog[id].resetTime = resetTime

            LOTUS_UTIL.CreateHudlessTransmission(transmissionSet:GetTransmission(transmissionTag))
        end
    end
end
