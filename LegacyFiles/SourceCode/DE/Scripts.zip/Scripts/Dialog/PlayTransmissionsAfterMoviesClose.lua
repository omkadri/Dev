onlyOnShip = true
waitOnMovies = {WeakResource()}
transmissionsToPlay = {Resource()}

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"


function PlayTransmissionsAfterMoviesClose()
    if onlyOnShip and LOTUS_UTIL.GetUIMode() ~= LOTUS_UTIL.UI_MODE_IN_SPACE_SHIP then
        return
    end
    
    local shouldKeepWaiting = function()
        for i=1,#waitOnMovies do
            if gFlashMgr:HasMovie(waitOnMovies[i]) then
                return true
            end
        end
        
        return false
    end

    while shouldKeepWaiting() do
        Sleep(0.5)
    end
    
    for i=1,#transmissionsToPlay do
        if not IsNull(transmissionsToPlay[i]) then
            LOTUS_UTIL.CreateHudlessTransmission(transmissionsToPlay[i])
        end
    end
end