syndicate = Resource()
favorsTag = Symbol()
dialogTag = String()
loopingSound = Resource()
openSound = Resource()
closeSound = Resource()

local UTIL = require "EE.Interface.Utilities"

local syndicateMovie = Resource("/Lotus/Interface/ThemedSyndicates.swf")

function TagSyndicateDialog()
    if _T.TaggedDialog == nil then
        _T.TaggedDialog = {}
    end
    if _T.TaggedDialog[dialogTag] and _T.TaggedDialog[dialogTag].mDisabled then
        return
    end
    _T.TaggedDialog[dialogTag] = {
        mName = Localize("/Lotus/Language/Syndicates/Favors_Title", {SYNDICATE = Localize(syndicate:GetUIName():c_str(), nil)}),
        mCallback = function()
            _T.ShowSyndicate = syndicate
            gFlashMgr:PushMovie(syndicateMovie)
        end
    }
end

function ShowSyndicate()
    _T.ShowSyndicate = syndicate

    local loopingSoundInst = nil
    if not IsNull(loopingSound) then
        loopingSoundInst = UTIL.PlaySound(loopingSound)
    end
    if not IsNull(openSound) then
        UTIL.PlaySound(openSound)
    end

    if favorsTag:IsValid() then
        _T.SyndicateFavorsTag = favorsTag
    end

    local syndMovie = gFlashMgr:PushMovie(syndicateMovie)
    if not IsNull(syndMovie) then
        _T.OnCloseSyndicateMovie =
            function()
                if not IsNull(loopingSoundInst) then
                    loopingSoundInst:Stop(true)
                end
                if not IsNull(closeSound) then
                    UTIL.PlaySound(closeSound)
                end
            end
        syndMovie:Execute("SetOnCloseFunction", "OnCloseSyndicateMovie")
    end
end