speakerName = String()
dialogTags = {String()}
onInitFunction = String()
onEndFunction = String()
allowExit = true
cameraSpot = Instance()
hubNpc = Instance()
inputFilter = Resource()
transmissionSet = Resource()
speakerSyndicate = Resource()
introduceSyndicate = Resource()
eventStageTag = Symbol()
eventStageRequirement = 0
eventTransmissionTag = Symbol()
musicLoop = Resource()
openSound = Resource()
closeSound = Resource()

local genericMenuMovie = Resource("/Lotus/Interface/GenericMenu.swf")
local alignmentMovieRes = Resource("/Lotus/Interface/AlignmentDisplay.swf")
local survivalRewardsMovie = Resource("/Lotus/Interface/SurvivalReward.swf")

local defaultTriggeredAnimTag = Symbol("ConversationSpeech")

local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local STORY = require "Lotus.Scripts.Libs.StoryLib"

local mPendingSetActiveQuest

local mGotQuest = false
local mGotQuestFailed = false
local mGotQuestSetActivePrompt = false
local mMakeQuestActive = false
local mActiveQuestSet = false
local mActiveQuestSetFailed = false

local mGotTriggeredItem = false
local mGiveTriggeredItemsFailed = false

local mQuestStageCompleted = false
local mCompleteQuestStageFailed = false

local mCallbackResult = nil

local mYesOrNoResult = nil

local mMusicLoop = nil

local mLoader = nil

local mConversation

-- Generic callback function used for conversation.
function OnCallbackRecieved(result, body)
    mCallbackResult = result
end

function OnItemsTriggered(result, body)
    if result then
        mGotTriggeredItem = true
    else
        mGiveTriggeredItemsFailed = true
        print("Failed to give triggered quest items:")
        print(body)
    end
end

local function  _GiveQuestItems(pConversation, pKeyChain, pStage, pStoreItemToDisplay)
    local stage = pStage + 1
    if stage < 1 or stage > pKeyChain:GetNumChainStages() then
        return
    end
    local playerProfile = gPlayerProfileMgr:GetPlayerProfile(0)
    if IsNull(playerProfile) then
        return
    end
    local gameData = playerProfile:GetGameSpecificData()
    if IsNull(gameData) then
        return
    end
    
    mGotTriggeredItem = false
    mGiveTriggeredItemsFailed = false
    
    if not gameData:HasTriggeredItemsForQuestKey(pKeyChain, stage) then
        local failRetryDelay = 5
        local t = 0
        local blockingMessageActive = false
        gameData:GiveTriggeredItemsForQuestKeyChain(pKeyChain, stage, "OnItemsTriggered")
        while not mGotTriggeredItem do
            t = t + DeltaTime()
            if not blockingMessageActive and t > 2 then
                blockingMessageActive = true
                _T.BackgroundMovie:Execute("ShowBlockingMessage", "1")
            end
            if mGiveTriggeredItemsFailed and t > failRetryDelay then
                mGiveTriggeredItemsFailed = false
                t = 0
                print "Retrying GiveQuestItems."
                gameData:GiveTriggeredItemsForQuestKeyChain(pKeyChain, stage, "OnItemsTriggered")
                failRetryDelay = math.min(failRetryDelay * 2, 60)
            end
            Sleep(0)
        end
        mGotTriggeredItem = false
        if blockingMessageActive then
            _T.BackgroundMovie:Execute("ShowBlockingMessage", "0")
        end
        if not IsNull(survivalRewardsMovie) and not IsNull(pStoreItemToDisplay) then
            local movie = gFlashMgr:PushMovie(survivalRewardsMovie)
            if not IsNull(movie) then
                _T.DisplayReward(pStoreItemToDisplay, 1)
            end
        end
    end
end

function OnActiveQuestSet(result, body)
    if result then
        mActiveQuestSet = true
        _T.BackgroundMovie:Execute("CheckQuests", "")
    else
        mActiveQuestSetFailed = true
        UTIL.ShowMessage("/Lotus/Language/Menu/SetActiveQuestFailed")
    end
end

function OnConfirmSetActiveQuest(result)
    mGotQuestSetActivePrompt = false
    
    local playerProfile = gPlayerProfileMgr:GetPlayerProfile(0)
    if IsNull(playerProfile) then
        return
    end
    local gameData = playerProfile:GetGameSpecificData()
    if IsNull(gameData) then
        return
    end
    if tonumber(result) == Engine.CI_SELECT and mPendingSetActiveQuest ~= nil then
        gameData:SetActiveQuest(mPendingSetActiveQuest, "OnActiveQuestSet")
    end

    mPendingSetActiveQuest = nil
end

function OnGiveQuest(result, body)
    if not result then
        mGotQuestFailed = true
    else
        -- TODO: Update quest marker.
        mGotQuest = true
        if mMakeQuestActive then
            local playerProfile = gPlayerProfileMgr:GetPlayerProfile(0)
            if IsNull(playerProfile) then
                return
            end
            local gameData = playerProfile:GetGameSpecificData()
            if IsNull(gameData) then
                return
            end
            gameData:SetActiveQuest(mPendingSetActiveQuest, "OnActiveQuestSet")
            mGotQuestSetActivePrompt = false
        else
            mGotQuestSetActivePrompt = true
            UTIL.ShowYesOrNoMessage(Localize("/Lotus/Language/Menu/WorldStatePanel_SetActiveQuestConfirm", { QUEST = Localize(mPendingSetActiveQuest:GetLocalizeTag():c_str(), nil) }), "OnConfirmSetActiveQuest")
        end
    end
end

local function _SetActiveQuest(pConversation, pKeyChain)
    local hasQuest = false
    for i=1,5 do
        local quests = gGameData:GetInventory():GetQuestKeys()
        for _,quest in ipairs(quests) do
            if not IsNull(quest) and quest.mItemType == pKeyChain then
                hasQuest = true
                break
            end
        end

        if hasQuest then
            break
        end

        if i < 5 then
            Sleep(2)
        end
    end

    if not hasQuest then
        UTIL.ShowMessage("/Lotus/Language/Menu/SetActiveQuestFailed")
    end

    mActiveQuestSet = false
    mActiveQuestSetFailed = false

    local failRetryDelay = 5
    local t = 0
    local blockingMessageActive = false
    gGameData:SetActiveQuest(pKeyChain, "OnActiveQuestSet")
    while not mActiveQuestSet do
        t = t + DeltaTime()
        if not blockingMessageActive and t > 2 then
            blockingMessageActive = true
            _T.BackgroundMovie:Execute("ShowBlockingMessage", "1")
        end
        if mActiveQuestSetFailed and t > failRetryDelay then
            mGotQuestFailed = false
            t = 0
            print("Retrying SetActiveQuest.")
            gGameData:SetActiveQuest(pKeyChain, "OnActiveQuestSet")
            failRetryDelay = math.min(failRetryDelay * 2, 60)
        end
        Sleep(0)
    end
    if blockingMessageActive then
        _T.BackgroundMovie:Execute("ShowBlockingMessage", "0")
    end
end

local function _AcceptQuest(pConversation, pKeyChain, pAutoActivate)
    if IsNull(pKeyChain) then
        return
    end

    local playerProfile = gPlayerProfileMgr:GetPlayerProfile(0)
    if IsNull(playerProfile) then
        return
    end
    local gameData = playerProfile:GetGameSpecificData()
    if IsNull(gameData) then
        return
    end

    mLoader = UISys.ScriptResLoader_Create({pKeyChain:GetFullName()}, true)
    while not IsNull(mLoader) and not mLoader:IsDone() do
        Sleep(0)
    end
    
    mPendingSetActiveQuest = Resource(pKeyChain)

    local questKeyReward = Lotus_Game.Reward()
    questKeyReward.mRewardType = Lotus_Game.RT_CONSUMABLE
    questKeyReward.mProductCategory = Engine.Item_QuestKeys
    questKeyReward.mItemType = pKeyChain

    mGotQuest = false
    mGotQuestFailed = false
    mMakeQuestActive = pAutoActivate
    
    local failRetryDelay = 5
    local t = 0
    local blockingMessageActive = false
    gameData:GiveQuestKeyReward(questKeyReward, "OnGiveQuest")
    while not mGotQuest do
        t = t + DeltaTime()
        if not blockingMessageActive and t > 2 then
            blockingMessageActive = true
            _T.BackgroundMovie:Execute("ShowBlockingMessage", "1")
        end
        if mGotQuestFailed and t > failRetryDelay then
            mGotQuestFailed = false
            t = 0
            print "Retrying AcceptQuest."
            gameData:GiveQuestKeyReward(questKeyReward, "OnGiveQuest")
            failRetryDelay = math.min(failRetryDelay * 2, 60)
        end
        Sleep(0)
    end
    if blockingMessageActive then
        _T.BackgroundMovie:Execute("ShowBlockingMessage", "0")
    end
    
    while mGotQuestSetActivePrompt do
        Sleep(0)
    end
end

function OnQuestStageCompleted(result, body)
    if result then
        mQuestStageCompleted = true
    else
        mCompleteQuestStageFailed = true
        print("Failed to give complete quest stage:")
        print(body)
    end
end

local function _AdvanceQuest(pConversation, pKeyChain, pStage)
    if pStage < 0 or pStage > pKeyChain:GetNumChainStages() + 1 then
        return
    end

    while IsNull(gGameData) do
        Sleep(0)
    end
    local inventory = gGameData:GetInventory()
    while IsNull(inventory) do
        Sleep(0)
        inventory = gGameData:GetInventory()
    end
    
    if not pKeyChain:IsA(inventory:GetActiveQuest()) then
        print "Error: Tried to advance inactive quest!"
        return
    end
    
    mQuestStageCompleted = false
    mCompleteQuestStageFailed = false
    
    local failRetryDelay = 5
    local t = 0
    local blockingMessageActive = false
    gGameData:CompleteQuestStage(pStage, "OnQuestStageCompleted")
    while not mQuestStageCompleted do
        Sleep(0)
        t = t + DeltaTime()

        if not blockingMessageActive and t > 1 then
            blockingMessageActive = true
            _T.BackgroundMovie:Execute("ShowBlockingMessage", "1")
        end
        if mCompleteQuestStageFailed and t > failRetryDelay then
            mCompleteQuestStageFailed = false
            t = 0
            print "Retrying AdvanceQuest."
            gGameData:CompleteQuestStage(pStage, "OnQuestStageCompleted")
            failRetryDelay = math.min(failRetryDelay * 2, 60)
        end
    end

    if blockingMessageActive then
        _T.BackgroundMovie:Execute("ShowBlockingMessage", "0")
    end
    
    STORY.InvalidateQuestCompletionCache(pKeyChain)
    LOTUS_UTIL.UpdateQuests(true)
end

local function _ShowOptions(pConversation, pOptions, pCallback, pAllowExit, pWaitingCallback, pFocusCallback, pUnfocusCallback, pSounds)
    local movie = gFlashMgr:FindMovie(genericMenuMovie)
    if IsNull(movie) and #pOptions > 0 then

        if pSounds and not IsNull(pSounds.open) then
            _T.DialogOpenSound = pSounds.open:GetFullName()
        end

        _T.DialogueMode = true -- this is so the movie can adapt during initialize
        movie = gFlashMgr:GotoMovie(genericMenuMovie)
        _T.DialogueMode = false
        _T.DialogOpenSound = nil

        if not IsNull(movie) then
            if pAllowExit == nil then
                pAllowExit = true
            end
            movie:Execute("SetAllowExit", tostring(pAllowExit))
            movie:Execute("SetTitleCaseText", "false")

            local title = pConversation.mDefaultTitle
            if title ~= nil then
                movie:Execute("SetTitle", title)
            end

            local optionSelection = nil

            _T.MenuSelectionDone =
                function(pElements)
                    if pElements[1] ~= nil then
                        optionSelection = pElements[1]
                    else
                        optionSelection = false
                    end
                end
            movie:Execute("SetCallBack", "MenuSelectionDone")

            _T.GetMenuEntries = 
                function()
                    return(pOptions)
                end
            movie:Execute("SetElementsFunction", "GetMenuEntries")

            if pFocusCallback ~= nil then
                _T.MenuOnFocusedCallback =
                    function(pElement)
                        pFocusCallback(pElement)
                    end
                movie:Execute("SetOnFocusedCallback", "MenuOnFocusedCallback")
            end
            if pUnfocusCallback ~= nil then
                _T.MenuOnUnfocusedCallback =
                    function(pElement)
                        pUnfocusCallback(pElement)
                    end
                movie:Execute("SetOnUnfocusedCallback", "MenuOnUnfocusedCallback")
            end

            if pSounds and not IsNull(pSounds.focus) then
                movie:Execute("SetOnFocusedSound", pSounds.focus:GetFullName())
            end
            if pSounds and not IsNull(pSounds.select) then
                movie:Execute("SetOnSelectedSound", pSounds.select:GetFullName())
            end

            movie:Execute("SetTargetBackgroundAlpha", "0")
            movie:Execute("SetAlignment", "Bottom")

            while optionSelection == nil do
                if pWaitingCallback then
                    pWaitingCallback(pConversation)
                end
                Sleep(0)
            end

            if optionSelection ~= false and optionSelection.mCallback ~= nil then
                print("Conversation option selected: " .. optionSelection.mName)
                optionSelection.mCallback(pConversation)
                
                if optionSelection == false then
                    return
                end
            end

            if not IsNull(pCallback) then
                pCallback(pConversation, optionSelection)
            end
        end
    else
        if not IsNull(pCallback) then
            pCallback(pConversation, false)
        end
    end
end

function OnAlignmentUpdate()
end

local function _AlignmentChoice(pConversation, pChoiceId, pSunChoice, pNeutralChoice, pMoonChoice, pSounds)
    local activeQuest, missionIndex, difficulty = LOTUS_UTIL.GetActiveQuest(gGameData)
    local alignment = nil

    if difficulty ~= nil and difficulty > 0 then
        alignment = gGameData:GetAlignmentReplay()
    else
        alignment = gGameData:GetAlignment()
    end 

    local alignmentMovie = gFlashMgr:FindMovie(alignmentMovieRes)
    if IsNull(alignmentMovie) then
        _T.SuppressUIOpenSound = true
        alignmentMovie = gFlashMgr:GotoMovie(alignmentMovieRes)
        _T.SuppressUIOpenSound = nil
    end
    alignmentMovie:Execute("SetDebug", "false")
    alignmentMovie:Execute("SetAlignment", alignment.mWisdom .. ", " .. alignment.mAlignment)
    alignmentMovie:SetViewportAnchorPoint(Engine.VAP_BOTTOM_LEFT)

    local optionSelected = nil
    local options = {}

    local registerAlignmentChoice = function(choice, alignmentType)
        if not IsNull(alignmentMovie) then
            alignmentMovie:Execute("Close", "")
        end

        local newAlignment = nil
        if difficulty ~= nil and difficulty > 0 then
            newAlignment = gGameData:GetAlignmentReplay()
        else
            newAlignment = gGameData:GetAlignment()
        end 

        local alignmentTypeStr = "_Invalid"
        local displayAlignment = Lotus_Game.TaoAlignment()
        displayAlignment.mWisdom = newAlignment.mWisdom
        if alignmentType == Lotus_Game.AT_POSITIVE then
            displayAlignment.mAlignment = 1
            alignmentTypeStr = "_Sun"
        elseif alignmentType == Lotus_Game.AT_NEUTRAL then
            displayAlignment.mAlignment = 0
            alignmentTypeStr = "_Neutral"
        else
            displayAlignment.mAlignment = -1
            alignmentTypeStr = "_Moon"
        end
        newAlignment:AddWisdom(1, alignmentType)
        
        if not IsNull(alignmentMovie) then
            alignmentMovie:Execute("SetAlignment", displayAlignment.mWisdom .. ", " .. displayAlignment.mAlignment)
        end

        gGameData:UpdateAlignment(newAlignment, pChoiceId .. alignmentTypeStr, "OnAlignmentUpdate")
    end
    
    options[1] = {
        mName = pSunChoice,
        mAlignmentType = Lotus_Game.AT_POSITIVE,
        mCallback = function()
            optionSelected = Lotus_Game.AT_POSITIVE
            registerAlignmentChoice(pSunChoice, Lotus_Game.AT_POSITIVE)
        end
    }
    options[2] = {
        mName = pNeutralChoice,
        mAlignmentType = Lotus_Game.AT_NEUTRAL,
        mCallback = function()
            optionSelected = Lotus_Game.AT_NEUTRAL
            registerAlignmentChoice(pNeutralChoice, Lotus_Game.AT_NEUTRAL)
        end
    }
    options[3] = {
        mName = pMoonChoice,
        mAlignmentType = Lotus_Game.AT_NEGATIVE,
        mCallback = function()
            optionSelected = Lotus_Game.AT_NEGATIVE
            registerAlignmentChoice(pMoonChoice, Lotus_Game.AT_NEGATIVE)
        end
    }
    
    local currentCin = gRegion:GetPlayingCinematic()
    local waitingCallback = nil

    if not IsNull(currentCin) then
        local playerAvatar = gRegion:GetLocalPlayerAvatar()
        playerAvatar:SetCanTerminateCinematicAnimation(false)
        
        local cinematicFrozen = false
        local basePlayRate = 1
    
        if not IsNull(currentCin) then
            basePlayRate = currentCin:GetPlayRate()
        end

        waitingCallback = function() -- Waiting callback
            if not IsNull(currentCin) and not cinematicFrozen then
                local timeBeforeFreeze = currentCin:GetCurrentDeltaTime(true) - 1
                local timeBeforeSlowdown = 15
                local playRateMultiplier = Clamp(timeBeforeFreeze/timeBeforeSlowdown, 0, 1)
                if playRateMultiplier < 0.05 then
                    playRateMultiplier = 0
                    cinematicFrozen = true
                end
                local newPlayRate = basePlayRate * playRateMultiplier
                currentCin:SetPlayRate(newPlayRate)
            end
        end
    end
    
    local focusedElement
    _ShowOptions(
        pConversation,
        options,
        nil,
        false,
        waitingCallback,
        function(pElement) -- Focused callback
            if not IsNull(alignmentMovie) then
                local previewAlignment = Lotus_Game.TaoAlignment()
                previewAlignment.mWisdom = alignment.mWisdom
                if pElement.mAlignmentType == Lotus_Game.AT_POSITIVE then
                    previewAlignment.mAlignment = 1
                elseif pElement.mAlignmentType == Lotus_Game.AT_NEUTRAL then
                    previewAlignment.mAlignment = 0
                else
                    previewAlignment.mAlignment = -1
                end
                alignmentMovie:Execute("SetAlignment", previewAlignment.mWisdom .. ", " .. previewAlignment.mAlignment)
            end
            focusedElement = pElement
        end,
        function(pElement) -- Unfocused callback
            if not IsNull(alignmentMovie) and pElement == focusedElement then
                local currAlignment = nil
                local activeQuest, missionIndex, difficulty = LOTUS_UTIL.GetActiveQuest(gGameData)

                if difficulty ~= nil and difficulty > 0 then
                    currAlignment = gGameData:GetAlignmentReplay()
                else
                    currAlignment = gGameData:GetAlignment()
                end  

                if optionSelected then
                    if pElement.mAlignmentType == Lotus_Game.AT_POSITIVE then
                        currAlignment.mAlignment = 1
                    elseif pElement.mAlignmentType == Lotus_Game.AT_NEUTRAL then
                        currAlignment.mAlignment = 0
                    else
                        currAlignment.mAlignment = -1
                    end
                end
                alignmentMovie:Execute("SetAlignment", currAlignment.mWisdom .. ", " .. currAlignment.mAlignment)
            end
        end,
        pSounds
    )

    return optionSelected
end

function OnYesOrNoResult(result)
    mYesOrNoResult = result
end

local function _ShowYesOrNoMessage(pConversation, pText)
    mYesOrNoResult = nil
    UTIL.ShowYesOrNoMessage(pText, "OnYesOrNoResult")

    while mYesOrNoResult == nil do
        Sleep(0)
    end

    return mYesOrNoResult
end

local function _PlayDialog(pConversation, pTransmisson, pCallback, pWaitToFinish, pForce, pTriggeredAnimTag)
    _T.HideTransmissionComms = true
    if IsNull(pTransmisson) then
        print("Error: No transmission")
        return
    end
    
    if pForce then
        _T.QueuedTransmissions = {}
        LOTUS_UTIL.InterruptTransmission(_T.curTransmission)
    end

    if not IsNull(pConversation.mHubNpc) then
        local animTag = pTriggeredAnimTag or defaultTriggeredAnimTag
        if animTag:IsValid() then
            pConversation.mHubNpc:PlayTriggeredAnim(animTag)
        end
    end
    LOTUS_UTIL.CreateHudlessTransmission(pTransmisson)

    if pWaitToFinish == nil or pWaitToFinish then
        pConversation.mWaitingForDialog = true
        while LOTUS_UTIL.IsTransmissionPlaying() do
            Sleep(0)
        end
        pConversation.mWaitingForDialog = false
    end
    
    if not IsNull(pCallback) then
        pCallback(pConversation)
    end
    _T.HideTransmissionComms = nil
end

local function _PushCameraSpot(pConversation, pCameraSpot, pTransitionTime)
    if IsNull(pCameraSpot) then
        return
    end

    local cameraControl = pConversation.mPlayerAvatar:CameraControl()
    local oldTransitionTime
    local transitionTime = pTransitionTime or 0.0

    if IsNull(cameraControl:GetCameraSpot()) and transitionTime > 0.0 then
        transitionTime = transitionTime * 0.5
    else
        oldTransitionTime = cameraControl:GetTransitionToCameraSpotTime()
        cameraControl:SetTransitionToCameraSpotTime(transitionTime)
    end

    cameraControl:SetCameraSpot(pCameraSpot, transitionTime)
    table.insert(pConversation.mCameraSpotStack, pCameraSpot)

    if not IsNull(oldTransitionTime) then
        cameraControl:SetTransitionToCameraSpotTime(oldTransitionTime)
    end
end

local function _PopCameraSpot(pConversation, pTransitionTime)
    local cameraSpotStack = pConversation.mCameraSpotStack
    if IsNull(cameraSpotStack[1]) then
        return
    end

    local cameraControl = pConversation.mPlayerAvatar:CameraControl()
    local oldTransitionTime = cameraControl:GetTransitionToCameraSpotTime()
    local transitionTime = pTransitionTime or 0.0

    cameraControl:SetTransitionToCameraSpotTime(transitionTime)

    if next(cameraSpotStack) then
        table.remove(cameraSpotStack, #cameraSpotStack)
        cameraControl:SetCameraSpot(cameraSpotStack[#cameraSpotStack], transitionTime)
    end

    cameraControl:SetTransitionToCameraSpotTime(oldTransitionTime)
end

local function _ResetCallbackResult(pConversation)
    mCallbackResult = nil
end

local function _GetCallbackResult(pConversation)
    return mCallbackResult
end

local function _Conversation(scriptAction, instigatorAvatar)
    _T.HideTransmissionComms = true
    
    if IsNull(instigatorAvatar) then
        print("Conversation.lua -- Tried to start conversation with null instigatorAvatar")
        return
    end
    
    if instigatorAvatar:IsOperatorTransferenceInProgress() then
        local player = instigatorAvatar:GetPlayer()
        while not IsNull(instigatorAvatar) and instigatorAvatar:IsOperatorTransferenceInProgress() do
            Sleep(0)
        end
        
        if IsNull(player) then
            print("Conversation.lua -- Tried to start conversation during transference and player went null")
            return
        end
        
        instigatorAvatar = player:GetAvatar()
        while IsNull(instigatorAvatar) do
            Sleep(0)
            if IsNull(player) then
                print("Conversation.lua -- Tried to start conversation during transference and player went null")
                return
            end
            instigatorAvatar = player:GetAvatar()
        end
    end
    
    if _T.TaggedDialog == nil then
        _T.TaggedDialog = {}
    end
    
    local conversation = {
        ShowOptions = _ShowOptions,
        AlignmentChoice = _AlignmentChoice,
        ShowYesOrNoMessage = _ShowYesOrNoMessage,
        PlayDialog = _PlayDialog,
        PushCameraSpot = _PushCameraSpot,
        PopCameraSpot = _PopCameraSpot,
        GiveQuestItems = _GiveQuestItems,
        SetActiveQuest = _SetActiveQuest,
        AcceptQuest = _AcceptQuest,
        AdvanceQuest = _AdvanceQuest,
        ResetCallbackResult = _ResetCallbackResult,
        GetCallbackResult = _GetCallbackResult,
        mSpeakerName = speakerName,
        mDefaultTitle = Localize(speakerName, nil),
        mScriptAction = scriptAction,
        mPlayerAvatar = instigatorAvatar,
        mCameraSpotStack = {},
        mOldCameraSpot = instigatorAvatar:CameraControl():GetCameraSpot(),
        mReset = false,
        mTransmissionSet = transmissionSet,
        mSpeakerSyndicate = speakerSyndicate,
        mEventStageTag = eventStageTag,
        mEventStageRequirement = eventStageRequirement,
        mEventTransmissionTag = eventTransmissionTag,
        mWaitingForDialog = false,
        mAllowLineSkip = false,
        mHubNpc = hubNpc
    }

    mConversation = conversation

    if not IsNull(musicLoop) and mMusicLoop == nil then
        mMusicLoop = UTIL.PlaySound(musicLoop)
    end
    if not IsNull(openSound) then
        UTIL.PlaySound(openSound)
    end
    
    if _T.HubNpcs and conversation.mSpeakerName then
        local npcData = _T.HubNpcs[conversation.mSpeakerName]
        if npcData then
            conversation.mTransmissionSet = npcData.conversationTransmissionOverrides or conversation.mTransmissionSet
        end
    end
    
    conversation.Reset = function()
        local options = {}
        for i,tag in ipairs(dialogTags) do
            local option = _T.TaggedDialog[tag]
            if option ~= nil and not option.mDisabled and (option.mCondition == nil or option.mCondition(conversation)) then
                table.insert(options, {mName = option.mName, mCallback = option.mCallback, mAlwaysShow = option.mAlwaysShow})
            end
        end
        
        if #options > 0 then
            if #options == 1 and not options[1].mAlwaysShow then
                local option = options[1]
                if option.mCallback then
                    option.mCallback(conversation)
                end
            else
                conversation:ShowOptions(options, nil, allowExit)
            end
        end
    end

    if IsNull(hubNpc) and not IsNull(scriptAction) then
        hubNpc = scriptAction:GetAttachParent()
    end

    instigatorAvatar:SetHudHidden(true)
    instigatorAvatar:SetAnimationIVSelect(1)
    if not IsNull(cameraSpot) then
        conversation:PushCameraSpot(cameraSpot, 0.4)
    end
    if not IsNull(inputFilter) then
        instigatorAvatar:PushInputFilter(inputFilter)
    end
    
    instigatorAvatar:GetPlayer():PushScriptedInputHandler(Symbol("ConversationDialogSkip"), gFlashMgr:GetInputCodeValue("MENU_CLICK"), "InputHandler_SkipDialog")
    instigatorAvatar:GetPlayer():PushScriptedInputHandler(Symbol("ConversationDialogSkipController"), gFlashMgr:GetInputCodeValue("MENU_SELECT"), "InputHandler_SkipDialog")

    local disabledNpcSpeech = false
    if not IsNull(hubNpc) then
        instigatorAvatar:ScriptRunChildScript(Symbol("SetTorso"), false)
        if hubNpc:IsA(gLotusHubNpcEntityType) and hubNpc:IsSpeechEnabled() then
            hubNpc:DisableSpeech()
            disabledNpcSpeech = true
        end
    end
    
    if not IsNull(introduceSyndicate) then
        gGameData:SetNodeIntroCompleted(introduceSyndicate:GetAffiliationTag())
    end
    
    local cameraControl = instigatorAvatar:CameraControl()

    if not IsNull(cameraControl) then
        cameraControl:SetCullNearbyAvatars(6)
    end

    _T.CurrentConversation = conversation
    _T.DisableHeadTracking = true

    if _T[onInitFunction] ~= nil then
        _T[onInitFunction](conversation)
    end

    repeat
        conversation.mReset = false
        conversation:Reset()
    until not conversation.mReset

    if not IsNull(mMusicLoop) then
        mMusicLoop:Stop(true)
    end
    if not IsNull(closeSound) then
        UTIL.PlaySound(closeSound)
    end

    if not IsNull(cameraControl) then
        cameraControl:SetCullNearbyAvatars(-1)
    end

    _T.DisableHeadTracking = nil
    _T.CurrentConversation = nil
    mConversation = nil
    
    if disabledNpcSpeech and not IsNull(hubNpc) then
        hubNpc:EnableSpeech()
    end
    
    instigatorAvatar:GetPlayer():PopScriptedInputHandler(Symbol("ConversationDialogSkip"), gFlashMgr:GetInputCodeValue("MENU_CLICK"))
    instigatorAvatar:GetPlayer():PopScriptedInputHandler(Symbol("ConversationDialogSkipController"), gFlashMgr:GetInputCodeValue("MENU_SELECT"))
    
    if not IsNull(inputFilter) then
        instigatorAvatar:PopInputFilter(inputFilter)
    end
    
    conversation:PopCameraSpot(0.4)
    
    instigatorAvatar:SetHudHidden(false)
    instigatorAvatar:SetAnimationIVSelect(0)

    _T.HideTransmissionComms = nil
    
    if _T[onEndFunction] ~= nil then
        _T[onEndFunction](conversation)
    end

    return conversation
end

function ConversationAction(scriptAction, instigatorAvatar)
    if instigatorAvatar:ReplicaLocallyControlled() then
        local conversation = _Conversation(scriptAction, instigatorAvatar)
        if conversation.mDisableAction and not IsNull(scriptAction) then
            scriptAction:Disable()
        end
    end
end

function ConversationTrigger(trigger, instigatorAvatar)
    while _T.CurrentConversation do -- probably need a better way to queue conversations
        Sleep(0)
    end
    if instigatorAvatar:ReplicaLocallyControlled() then
        _Conversation(nil, instigatorAvatar)
    end
end

function InputHandler_SkipDialog(data)
    if mConversation and ((mConversation.mAllowLineSkip or gFlashMgr:GetConfigBool("Engine.DeveloperMode")) and (data == 0 and mConversation.mWaitingForDialog and not IsNull(_T.curTransmission))) then
        LOTUS_UTIL.InterruptTransmission(_T.curTransmission)
    end
end

function SetTorso(instigatorAvatar)
    Sleep(0)
    Sleep(0)
    if not IsNull(instigatorAvatar) and mConversation and not IsNull(mConversation.mHubNpc) then
        instigatorAvatar:MotionControl():SetTorsoFromView(LookTo(instigatorAvatar:GetSimPosition(), mConversation.mHubNpc:GetSimPosition()))
    end
end
