tags = {String()}


function ConversationCondition()
    if not _T.TaggedDialog then
        return false
    end

    for i=1,#tags do
        local tag = tags[i]
        if tags[i] ~= "" then
            local entry = _T.TaggedDialog[tag]
            if entry and not entry.mDisabled and ((entry.mCondition == nil) or entry.mCondition()) then
                return true
            end
        end
    end

    return false
end
