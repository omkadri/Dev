sounds = { Resource() }

function OnEnter(trigger)
    local ent = trigger:GetAttachParent()
    ent:PlaySound(sounds[RandomInt(1, #sounds)], false)
end
