colourCorrection = Resource()
occlusionFilter = Resource()
mixerArray = {Resource()}
counter = Instance()
fadeTime = 1.5
maxDamage = 50
minHealth = 10

local function LerpOcclusion(avatar, startVal, endVal)
    
    if IsNull(occlusionFilter) or IsNull(mixerArray) then
        return
    end

    if fadeTime > 0.0 then
        local t = 0 
        while t < 1 do
            local amount = Lerp(startVal, endVal, t) 
            for i = 1, #mixerArray do
                mixerArray[i]:UpdateDynamicFilter(occlusionFilter, amount)
            end
            t = t + RealDeltaTime() / fadeTime
            Sleep(0)
        end
    end
    
    if endVal == 0 then
        for i = 1, #mixerArray do
            mixerArray[i]:ClearSoundFilter()
        end
    else
        for i = 1, #mixerArray do
            mixerArray[i]:UpdateDynamicFilter(occlusionFilter, endVal)
        end
    end
end

function Damage(trigger)
    local avatar = gRegion:GetLocalPlayerAvatar()
    local t = 0
    local disabledShieldRegen = false
    
    while trigger:IsEnabled() do
        while IsNull(avatar) do
            Sleep(0)
            avatar = gRegion:GetLocalPlayerAvatar()
        end
        
        Sleep(0)
    
        if not IsNull(avatar) and not avatar:IsKilled() and counter:GetCurrentValue() > 0 then
            if not disabledShieldRegen then
                avatar:InventoryControl():AddUpgrade(Game.AVATAR_SHIELD_RECHARGE_RATE, Game.SET, 0)
                disabledShieldRegen = true
            end
        
            t = t + DeltaTime()
            if t > 1 then
                local dmg = maxDamage * counter:GetCurrentValue() / counter:GetThreshold()
                if avatar:GetHealth() - dmg < minHealth then
                    dmg = dmg + (avatar:GetHealth() - dmg - minHealth)
                end
                if dmg > 0 then
                    avatar:DamageEx(dmg, Engine.DT_CINEMATIC, Engine.TORSO, 500, trigger, trigger)
                end
                t = 0
            end
        else
            if disabledShieldRegen then
                if not IsNull(avatar) then
                    avatar:InventoryControl():RemoveUpgrade(Game.AVATAR_SHIELD_RECHARGE_RATE, Game.SET, 0)
                end
                disabledShieldRegen = false
            end
        
            t = 0
        end
    end
end

function OcclusionScaler(trigger)
    local avatar = gRegion:GetLocalPlayerAvatar()
    local value = 0
    local maxValue = counter:GetThreshold()
    
    while trigger:IsEnabled() do
        while IsNull(avatar) do
            Sleep(0)
            avatar = gRegion:GetLocalPlayerAvatar()
        end
        
        if value ~= counter:GetCurrentValue() then
            local cameraControl = avatar:CameraControl()
            if counter:GetCurrentValue() == 1 and not IsNull(cameraControl) then
                cameraControl:PushColorCorrection(colourCorrection,3,-1,0)
            elseif counter:GetCurrentValue() == 0 then
                cameraControl:RemoveColorCorrection(colourCorrection)
            end
        
            LerpOcclusion(avatar, value / maxValue, counter:GetCurrentValue() / maxValue)
            value = counter:GetCurrentValue()
        end 
        
        Sleep(0)
    end
    
    fadeTime = 0
    LerpOcclusion(avatar, counter:GetCurrentValue() / maxValue, 0)
    avatar = gRegion:GetLocalPlayerAvatar()
    if not IsNull(avatar) then
        local cameraControl = avatar:CameraControl()
        cameraControl:RemoveColorCorrection(colourCorrection)
    end
end
