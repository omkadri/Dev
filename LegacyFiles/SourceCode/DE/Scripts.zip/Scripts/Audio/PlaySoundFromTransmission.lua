sound = Resource()
enableSequencersWithTags = {Symbol()}
waitForEnd = false
delay = 0


function PlaySoundFromTransmission()
    local transmission = _T.curTransmission

    if IsNull(transmission) then
        return
    end

    if waitForEnd then
        while _T.curTransmission == transmission do
            Sleep(0)
        end
    end

    if delay > 0 then
        Sleep(delay)
    end

    if not IsNull(sound) then
        gRegion:PlaySound(sound, ZERO_VECTOR, false)
    end

    for _,tag in ipairs(enableSequencersWithTags) do
        if tag:IsValid() then
            local sequencers = gRegion:FindTagged(tag)
            for _,sequencer in ipairs(sequencers) do
                if sequencer:IsA(gSequencerType) then
                    sequencer:Enable()
                end
            end
        end
    end
end
