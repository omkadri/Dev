startDelay = 0
transmission = Resource()

transmissionSet = Resource()
tag = Symbol()
interruptAll = false
randomChance = 1.0

local warWithinKeyChainWRes = WeakResource("/Lotus/Types/Keys/WarWithinQuest/WarWithinQuestKeyChain")

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local STORY = require "Lotus.Scripts.Libs.StoryLib"

function GiveTransmission()
    if randomChance >= 0.0 and randomChance < 1.0 and SRandom(0.0, 1.0) < randomChance then
        return
    end
    if startDelay >= 0 then
        Sleep(startDelay)
    end
    if interruptAll and not IsNull(_T.curTransmission) then
        LOTUS_UTIL.InterruptTransmission(_T.curTransmission)
        _T.QueuedTransmissions = {}
    end
    local playerAv = gRegion:GetLocalPlayerAvatar()
    if not IsNull(playerAv) and not IsNull(transmission) then
        playerAv:GiveTransmissionAsync(transmission)
    end
end

function GiveTransmissionFromSet()
    if randomChance >= 0.0 and randomChance < 1.0 and SRandom(0.0, 1.0) < randomChance then
        return
    end
    DIALOG.PlayGlobalTransmission(transmissionSet, tag)
end

function GiveOperatorTransmission()

    --only play operator transmissions if TWW has been completed
    local warWithinComplete = STORY.CheckQuestCompletion(warWithinKeyChainWRes)
    if not warWithinComplete then
        return
    end

    if randomChance >= 0.0 and randomChance < 1.0 and SRandom(0.0, 1.0) < randomChance then
        return
    end
    DIALOG.PlayLocalOperatorTransmission(tag)
end
