sound = Resource()

function OnEnter(trigger)
    local ent = trigger:GetInstigator()
    ent:PlaySound(sound,false)
end