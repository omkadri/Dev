sounds = { Resource() }
replicate = false
useAttachParent = false
useInstigator = false

function PlaySound(entity)
    local ent = entity
    
    if useAttachParent then
        ent = entity:GetAttachParent()
    elseif useInstigator then
        ent = entity:GetInstigator()
    end

    if not IsNull(ent) then
        ent:PlaySound(sounds[RandomInt(1, #sounds)], false, Engine.SP_VERY_LOW, replicate)
    end
end
