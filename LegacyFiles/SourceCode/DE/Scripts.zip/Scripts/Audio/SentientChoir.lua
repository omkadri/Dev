--turn off sentient Choir
function DisableSentientChoir()

gRegion:GetNpcMgr():SetChoirBarksAllowed(false)

end

-- turn on sentient choir
function EnableSentientChoir()

gRegion:GetNpcMgr():SetChoirBarksAllowed(true)

end