startDelay = 0
transmissionTag = Symbol()
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"

function GiveTransmission()

    Sleep(startDelay)

    DIALOG.PlayGlobalOperatorTransmission(transmissionTag)
end