tag = Symbol()

function EnableFirstTagged()
    if tag:IsValid() then
        local instance = gRegion:FindFirstTagged(tag)
        if not IsNull(instance) then
            instance:Enable()
        end
    end
end
