makeDeco = Type()
actionTime = 5

function RandomCovers()
    Sleep(5)
    local spots = gRegion:FindTagged(Symbol("DynamicCoverSpot"))
    
    if #spots == 0 then
        return
    end
    
    local coversList = {}
    
    for i = 1, #spots do
        coversList[i] = 0
    end

    while true do
        local i = RandomInt(1, #spots)
        
        if coversList[i] == 0 then
            coversList[i] = gRegion:CreateEntity(makeDeco, spots[i]:GetSimPosition(), spots[i]:GetSimRotation())
        elseif coversList[i] ~= nil then
            coversList[i]:Destroy()
            coversList[i] = 0
        end
        
        Sleep(actionTime)
    end

end
