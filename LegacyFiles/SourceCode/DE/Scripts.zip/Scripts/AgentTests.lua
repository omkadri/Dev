local amalgamChargeUpFX = Type("/Lotus/Fx/Gameplay/SentientEndlessMode/AmalgamChargeUp")
local sAmalgamBoss = Symbol("AmalgamBossAvatar")

local amalgamBossAvatarTypes = {
    Type("/Lotus/Types/Enemies/Corpus/Amalgams/Avatars/AmalgamCarrusPilotBossAvatar"),
    Type("/Lotus/Types/Enemies/Corpus/Amalgams/Avatars/AmalgamCorpusSniperBossAvatar"),
    Type("/Lotus/Types/Enemies/Corpus/Amalgams/Avatars/AmalgamMoaBossAvatar"),
    Type("/Lotus/Types/Enemies/Corpus/Amalgams/Avatars/AmalgamMoaSatyrBossAvatar")
}


function AmalgamDestroyScript(avatar)

    Broadcast("AmalgamDestroyScript started!")
    local t = 0
    local useTime = 3
    
    --amalgamBossExplosionLoopAnims
    local fx = nil
    
    for i = 1, #amalgamBossAvatarTypes do

        if not IsNull(avatar) and avatar:IsA(amalgamBossAvatarTypes[i]) then
            fx =avatar:Attach(amalgamChargeUpFX, EMPTY_SYMBOL)
            --fx = avatar:Attach(amalgamChargeUpFX, EMPTY_SYMBOL)
            --avatar:PlayAnimation(amalgamBossExplosionStartAnims[i], true, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_ONCE, true)
            --avatar:PlayAnimation(amalgamBossExplosionLoopAnims[i], false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_LOOP, true)
            break
        end
    end
    
    while true do
    
        if IsNull(avatar) or avatar:IsKilled() then
            fx:Destroy()
            return
        end
        
        if t >= useTime then
            break
        end
    
        t = t + DeltaTime()
        Sleep(0)
    end
    
    local artifact = gRegion:FindNearestTagged(Symbol("SentientAmalgamArtifactAvatar"), avatar:GetPosition())
    
    if not IsNull(artifact) then
        artifact:Destroy()
    end
    
    if not IsNull(avatar) then
        avatar:Destroy()
    end
    
end

function OnActivated(trigger)

    local avatar = gRegion:FindNearestTagged(sAmalgamBoss, trigger:GetPosition())
    
    avatar:ScriptRunChildScript(Symbol("AmalgamDestroyScript"), false)

end

function OnTouched(trigger)


end


function ContextActionTest(agent)
    
    local avatar = agent:GetAvatar()
    
    local contextAction = gRegion:FindNearestTagged(Symbol("ArtifactNpcCaptureHitSwitch"), avatar:GetPosition())
    agent:UseContextAction(contextAction, false)
    
    
    ObjectPortHandler(contextAction, "OnActivated")
    
    --avatar:ScriptRunChildScript(Symbol("AmalgamDestroyScript"), false)
    
    while true do
        Sleep(0)
    end

end