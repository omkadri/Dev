facePlayer = false          --Do we want to face the player in the direction of the trigger?
spawnerType = Type()

local transferenceAbilityType = WeakResource('/Lotus/Powersuits/PowersuitAbilities/OperatorTransferenceAbility')
local UTIL = require "EE.Interface.Utilities"

local function SetTransferenceEnabled(instigator, enabled)
    local powersuit = instigator:InventoryControl():GetActivePowerSuit()
    if not IsNull(powersuit) then
        local transferenceAbility = powersuit:GetAbilityByType(transferenceAbilityType)
        if not IsNull(transferenceAbility) then
            transferenceAbility:SetAbilityActivationBlocked(enabled)
        end
    end
end

local function _Kneel(trigger, instigator)
    if instigator:IsPreparedToTrade() then
        UTIL.ShowMessage("/Lotus/Language/Dojo/KneelingNotAllowedWhileTrading")
        trigger:Enable()
        return
    end

    trigger:Disable()
    local spawner = trigger:GetAttachment(spawnerType)
    
    if instigator:IsPlayingAction(Symbol("Kneel")) then
        SetTransferenceEnabled(instigator, false)

        instigator:SetAnimAction(Symbol("NULL"))
        _T.Kneeling = false
        _T.KneelingTrigger = nil
        Sleep(2)
        trigger:SetExclusiveAvatar(nil)

        instigator:InputControl():EnableCrouch(true)
        instigator:InputControl():EnableJump(true)
        if not IsNull(spawner) then
            spawner:Enable()
        end
    else
        SetTransferenceEnabled(instigator, true)

        trigger:SetExclusiveAvatar(instigator)
        if not IsNull(spawner) then
            spawner:Disable()
        end
        if instigator:ReplicaLocallyControlled() then
            local trigPos = trigger:GetPosition()
            local tpPos = Vector(trigPos.x, instigator:GetPosition().y, trigPos.z)
            instigator:InputControl():StopCrouching()
            instigator:SetPosture(Engine.WALK)
            instigator:MotionControl():SetPushVelocity(ZERO_VECTOR)
            if facePlayer then
                instigator:Teleport(tpPos, trigger:GetRotation())
                instigator:SetCameraView(trigger:GetRotation())
            else
                instigator:Teleport(tpPos)
            end
        end

        instigator:InputControl():EnableCrouch(false) -- This prevents player from being able to slide during the kneel
        instigator:InputControl():EnableJump(false)
        instigator:SetAnimAction(Symbol("Kneel"))
        _T.KneelingTrigger = trigger
        _T.Kneeling = true
        Sleep(2)
    end
    
    trigger:FirePort("ToggleText")
    trigger:Enable()

end

function Kneel(trigger, instigator)
    _Kneel(trigger, instigator)
end

function CancelKneel(instigator)
    if not IsNull(_T.Kneeling) and _T.Kneeling and not IsNull(_T.KneelingTrigger) then
        _Kneel(_T.KneelingTrigger, instigator)
    end
end