runningStartDistance = 15
useNullifierBubble = false
shieldDecoType = Type()
amalgamAttachOffset = Vector(0, 1, 0)

local function GetTableName(avatar)
    if not IsNull(avatar) then
        return("AmalgamSatyr_" .. avatar:GetInstance())
    end
    return nil;
end


local IV_TEST = 129

local function IsPosValid(instigatorAvatar, targetPos)
    --make sure the location is on the nav mesh so that the npc isn't jumping out of the map
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    if IsNull(aiDir) then
        return false
    end
    local nearestNavMeshPoint = aiDir:GetClosestWorldPointOnNavMeshScript(targetPos)
    if Distance(nearestNavMeshPoint, targetPos) > 0.2 then
        return false
    end

    return true
end

--[[
	stand mode
	0: waiting for mode update
	1: on big legs
	2: on little legs
	3: on 4 leg mode (running to lunge)
	4: nuke ability is done. has to be big leg mode
	5: tackle ability is done. has to be little leg mode
]]
local function SetStandMode(avatar, standMode)
	if not gRegion:IsMaster() then
		return
	end

    local tableName = GetTableName(avatar)
	if IsNull(_T[tableName]) then
	    _T[tableName] = {}
		_T[tableName].standingType = 0
	end

	_T[tableName].standingTime = gGameRules:GetCurrentGameTime()
	local agent = avatar:GetAgent()
	if standMode == 1 and _T[tableName].standingType ~= 1 then
		if _T[tableName].standingType ~= 0 then
			local pos = avatar:GetSimPosition()
			local rot = avatar:GetSimRotation()
			local rightVector = RotateVector(Vector(1,0,0), rot)
			if IsPosValid(avatar, pos - rightVector*2) then
				avatar:SetAnimAction(Symbol("ToBigLegModeLeft"))		-- let's cartwheel to the left
			elseif IsPosValid(avatar, pos + rightVector*2) then
				avatar:SetAnimAction(Symbol("ToBigLegModeRight"))		-- let's cartwheel to the right
			else
				return													-- no room to cartwheel
			end
		else
			avatar:SetAnimAction(Symbol("BigLegMode"))					-- no cartwheel needed
		end
		if not IsNull(agent) then
			agent:ClearAgentBlackboardEntry(Symbol("StandModeLittle"))
			agent:ClearAgentBlackboardEntry(Symbol("StandModeFourLeg"))
			agent:SetAgentBlackboardValue(Symbol("StandModeBig"), 1)
		end

		_T[tableName].standingType = 1  -- on Big Legs
		avatar:ScriptSetCurrentReactionSet(0)
	elseif standMode == 2 and _T[tableName].standingType ~= 2 then
		if _T[tableName].standingType ~= 0 and _T[tableName].standingType ~= 3 and _T[tableName].standingType ~= 5 then
			local pos = avatar:GetSimPosition()
			local rot = avatar:GetSimRotation()
			local rightVector = RotateVector(Vector(1,0,0), rot)
			if IsPosValid(avatar, pos - rightVector*2) then
				avatar:SetAnimAction(Symbol("ToLittleLegModeLeft"))		-- let's cartwheel to the left
			elseif IsPosValid(avatar, pos + rightVector*2) then
				avatar:SetAnimAction(Symbol("ToLittleLegModeRight"))	-- let's cartwheel to the right
			else
				return													-- no room to cartwheel
			end
		else
			avatar:SetAnimAction(Symbol("LittleLegMode"))				-- no cartwheel needed
		end
		if not IsNull(agent) then
			agent:ClearAgentBlackboardEntry(Symbol("StandModeBig"))
			agent:ClearAgentBlackboardEntry(Symbol("StandModeFourLeg"))
			agent:SetAgentBlackboardValue(Symbol("StandModeLittle"), 1)
		end

		_T[tableName].standingType = 2  -- change to Little Leg
		avatar:ScriptSetCurrentReactionSet(1)
	elseif standMode == 3 and _T[tableName].standingType ~= 3 then
		if not IsNull(agent) then
			agent:ClearAgentBlackboardEntry(Symbol("StandModeBig"))
			agent:ClearAgentBlackboardEntry(Symbol("StandModeLittle"))
			agent:SetAgentBlackboardValue(Symbol("StandModeFourLeg"), 1)
		end
		avatar:SetAnimAction(Symbol("FourLegMode"))						-- four leg mode

		_T[tableName].standingType = 3  -- let's run
	end
end

local lastLungeTime = 0
function SatyrUpdate(avatar)
	if not gRegion:IsMaster() then
		return
	end

    local tableName = GetTableName(avatar)
	local timer = 0.0
    local nullifierBubbleTimer = 0
    local nullifierPulseDelay = 5

    Sleep(0)
	SetStandMode(avatar, 1)

	local minVelocitySqr = 4 -- 2m/s
    local lastPos = avatar:GetSimPosition()
	local tooSlowTime = 0
    local tooSlowDuration = 1.0
	while not IsNull(avatar) and not avatar:IsPreDeath() and not avatar:IsKilled() do
		timer = timer + DeltaTime()

		if not IsNull(avatar:GetAgent()) and not avatar:IsFiring() and avatar:IsOnNav() then
			local target = avatar:GetAgent():GetTarget()
			if _T[tableName].standingType == 1 then		-- big leg mode now
				if timer > 4 and target.avatar and target.distanceToTarget < 4 then
					SetStandMode(avatar, 2)
					timer = 0
				end

				if timer > 4 and target.avatar and target.distanceToTarget > runningStartDistance then -- target is too far. let's run to target
					SetStandMode(avatar, 3)
					lastLungeTime = gGameRules:GetCurrentGameTime()
					timer = 0
				end
			elseif _T[tableName].standingType == 2 then -- little leg mode now
				if timer > 4 and target.avatar and target.distanceToTarget >= 4 then
					SetStandMode(avatar, 1)
					timer = 0
				end
			elseif _T[tableName].standingType == 3 then -- four leg running
				local curPos = avatar:GetSimPosition()
				-- get up if stuck on something
				if DistanceSqr(lastPos, curPos) / (DeltaTime() * DeltaTime()) < minVelocitySqr then
					tooSlowTime = tooSlowTime + DeltaTime()
					if tooSlowTime >= tooSlowDuration then
						SetStandMode(avatar, 2)
						tooSlowTime = 0
						timer = 0
					end
				else
					tooSlowTime = 0
				end
				lastPos = curPos
			elseif _T[tableName].standingType == 4 then -- 4: nuke ability is done. has to be big leg mode.
				SetStandMode(avatar, 1)
				timer = 0
			elseif _T[tableName].standingType == 5 then -- 5: tackle ability is done. has to be little leg mode.
				SetStandMode(avatar, 2)
				timer = 0
			end
		end
        
        if useNullifierBubble then
            if nullifierBubbleTimer >= nullifierPulseDelay then
                avatar:Attach(shieldDecoType, Symbol("GAME_C1_ROOT"), amalgamAttachOffset)
                nullifierBubbleTimer = 0
            end
            nullifierBubbleTimer = nullifierBubbleTimer + DeltaTime()
        end



		Sleep(0)
	end
end
