endMissionDialog = Instance()
endMissionMovie = Resource()
kneelAnim = Resource()
successTrans = Resource()
failMissionTrans = Resource()
spawnEffect = Resource()
enemyProjectorFX = Resource()
rushersAvatarType = WeakResource()

local CROOM = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local mEnergyPickupType = Type("/Lotus/Types/PickUps/EnergyIncreasePvPHundred")
local mBackupAiSpec = Resource("/Lotus/Types/Game/MasteryRankSpecs/OperatorTrackingTest")

local sTimer = Symbol("TimeLimit")

local mNpcMgr = gRegion:GetNpcMgr()
local mAiDir = mNpcMgr:GetAiDirector()
local mGameRules = gGameRules

local mPlayerAv = nil
local mPlayer = nil
local mTimerMgr = nil
local mRetryTimerId = nil
local mSpawns = nil

local mBackupMinLevel = 14
local mBackupMaxLevel = 14
local mEnergyRespawnTime = 20
local mRespawnTime = 10

--Target
local mTarget = nil
local mRegenTime = 3
local mRegenRate = 1000
local mMinScale = 0.5
local mMaxScale
local mMinAtten = 0
local mMaxAtten = 0.2
local mCurHealth
local mLastHealth
local mMaxHealth

local function Retry()
    mRetryTimerId = nil
    mGameRules:RespawnPlayer(mPlayer, false)
    mPlayerAv = mPlayer:GetAvatar()
    mAiDir:OrderNpcsStormTarget(mPlayerAv)
end

local function SpawnEnergy(waypoint)
    local pickup = gRegion:CreateEntity(mEnergyPickupType, waypoint:GetPosition(), ZERO_ROTATION)
    if not IsNull(pickup) then
        ObjectPortHandler(pickup, "OnPickedUp")
    else
        mTimerMgr:AddTimer(mEnergyRespawnTime, SpawnEnergy, false, waypoint)
    end
end

function OnPickedUp(pickup)
    local waypoint = gRegion:FindNearestTagged(Symbol("EnergySpawn"), pickup:GetPosition())
    mTimerMgr:AddTimer(mEnergyRespawnTime, SpawnEnergy, false, waypoint)
end

function OnDestroyed()
    mPlayerAv:DamageControl():AddDamageModifier(Symbol("Invuln"), Engine.DT_ANY, Engine.ANY_PART, 0)
    local npcs = gRegion:FindAll(gLotusNpcAvatarType)
    for i, npc in ipairs(npcs) do
        if npc:GetOriginalFaction() == Symbol("Infestation") then
            npc:Destroy()
        end
    end
end

local function SpawnBroodMother(spawn)
    if IsNull(spawn) then
        spawn = mSpawns[RandomInt(1, #mSpawns)]
    end
    local agent = mAiDir:CreateRandomAgent(spawn, Symbol("Team"))
    CROOM.SetupEnemy(agent:GetAvatar(), spawnEffect, enemyProjectorFX)
    ObjectPortHandler(agent:GetAvatar(), "OnKilled")
end

function OnKilled(avatar)
    mTimerMgr:AddTimer(mRespawnTime, SpawnBroodMother, false)
end

function RunChallenge()
    local TimerLib = require "Lotus.Interface.Libs.TimerMgr"
    mTimerMgr = TimerLib.CreateTimerMgr()
    
    mGameRules:SetSaveMatchStatsDisabled(true)
    mGameRules:SetShowReviveScreenOnDeath(false)
    mGameRules:SetMissionTimer(sTimer, Symbol(), 180, false, true)
    
    mPlayer = gRegion:GetLocalPlayer()
    mPlayerAv = mPlayer:GetAvatar()
    while IsNull(mPlayerAv) do
        Sleep(0)
        mPlayerAv = mPlayer:GetAvatar()
    end
    mPlayer:AddTimerOfInterest(sTimer)
    
    local SetupFunc = function(agent)
        CROOM.SetupEnemy(agent:GetAvatar(), nil, nil)
    end
    
    CROOM.SetMaxAttempts(3)
    
    local missionInfo = mGameRules:GetMission()
    mAiDir:Enable(true)
    mAiDir:SetObjective(mPlayerAv)
    mAiDir:SetLevelAlert(true) 
    mAiDir:SetEnableAutoSpawns(false)
    mAiDir:OrderNpcsStormTarget(mPlayerAv)
    mAiDir:SetMaxEnhancedAgents(0)

    local aiList = mGameRules:GetMissionAI()
    if IsNull(aiList) then
        aiList = mBackupAiSpec:GetEnemies()
        mAiDir:SetEnemyLevelMinMax(mBackupMinLevel, mBackupMaxLevel)
    else
        mAiDir:SetEnemyLevelMinMax(missionInfo.minEnemyLevel, missionInfo.maxEnemyLevel)
    end
    
    for i, enemy in ipairs(aiList) do
        mAiDir:AddMissionAIType(enemy.agent, enemy.probability, enemy.maxSimultaneous, enemy.tier)
    end

    local completed = false
    local failed = false
    local target = gRegion:FindFirstTagged(Symbol("Target"))
    mSpawns = gRegion:FindTagged(Symbol("Spawn"))
    for i, spawn in ipairs(mSpawns) do
        mTimerMgr:AddTimer(1, SpawnBroodMother, false, spawn)
    end

    ObjectPortHandler(target, "OnDestroyed")
    
    local energySpawns = gRegion:FindTagged(Symbol("EnergySpawn"))
    for i, spawn in ipairs(energySpawns) do
        mTimerMgr:AddTimer(mEnergyRespawnTime, SpawnEnergy, false, spawn)
    end
    
    while not completed and not failed do
        if IsNull(mPlayerAv) or mPlayerAv:IsKilled() and IsNull(mRetryTimerId) then
            _T.HideImpactMessage()
            failed = not CROOM.PlayerRetry()
            if not failed then
                mRetryTimerId = mTimerMgr:AddTimer(2, Retry, false)
            else
                break
            end
        end
        
        local rushers = gRegion:FindAll(rushersAvatarType)
        for i, rusher in ipairs(rushers) do
            if IsNull(rusher:GetAttachment(enemyProjectorFX)) then
                CROOM.SetupEnemy(rusher, nil, enemyProjectorFX)
            end
        end
        
        if IsNull(target) then
            completed = true
        elseif mGameRules:GetMissionTimeLeft(sTimer) <= 0 then
            failed = true
        end
        
        mTimerMgr:Update(DeltaTime())    
        Sleep(0)
    end
    
    if completed then
        LOTUS_UTIL.OnChallengePassed(mPlayerAv, kneelAnim, successTrans, endMissionMovie, endMissionDialog)
    else
        CROOM.ChallengeFailed()
        mPlayerAv:GiveItem(failMissionTrans, true)
    end
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end

local function UpdateTarget()
    local progress = mCurHealth / mMaxHealth
    mTarget:SetMeshScale(Lerp(mMinScale, mMaxScale, progress), true)
    mTarget:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, Lerp(mMaxAtten, mMinAtten, progress))
end

function Target(deco)
    mTarget = deco
    mMaxHealth = mTarget:GetHealth()
    mCurHealth = mMaxHealth
    mLastHealth = mMaxHealth
    mMaxScale = mTarget:GetMeshScale()
    
    mTarget:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, 0)
    
    local regenDelay = mRegenTime
    local regenOverflow = 0
    
    while not IsNull(deco) do
        mCurHealth = deco:GetHealth()
        if mCurHealth < mLastHealth then
            UpdateTarget()
            mLastHealth = mCurHealth
            regenDelay = mRegenTime
            -- play damage sound loop
            local damageSeq = gRegion:FindFirstTagged(Symbol("OperatorOrbDamage"))
            if not IsNull(damageSeq) and IsNull(damageSeq:GetSoundInstance()) then
                damageSeq:Enable()
            end
        else
            if regenDelay > 0 then
                regenDelay = regenDelay - DeltaTime()
                -- stop damage sound loop
                local damageSeq = gRegion:FindFirstTagged(Symbol("OperatorOrbDamage"))
                if not IsNull(damageSeq) and not IsNull(damageSeq:GetSoundInstance()) then
                damageSeq:Disable()
                end
            elseif regenDelay <= 0 and mCurHealth < mMaxHealth then
                regenOverflow = regenOverflow + mRegenRate * DeltaTime()
                local flooredRegen = math.floor(regenOverflow)
                
                if flooredRegen > 0 then
                    deco:SetHealth(mCurHealth + flooredRegen, false)
                    regenOverflow = regenOverflow - flooredRegen
                    mCurHealth = mCurHealth + flooredRegen
                    mLastHealth = mCurHealth
                    UpdateTarget()
                end
                -- play regen sound loop
                local regenSeq = gRegion:FindFirstTagged(Symbol("OperatorOrbRegenerate"))
                if not IsNull(regenSeq) and IsNull(regenSeq:GetSoundInstance()) then
                regenSeq:Enable()
                end
            else
                -- stop regen sound loop
                local regenSeq = gRegion:FindFirstTagged(Symbol("OperatorOrbRegenerate"))
                if not IsNull(regenSeq) and not IsNull(regenSeq:GetSoundInstance()) then
                regenSeq:Disable()
                end
            end
        end
        
        Sleep(0)
    end
end
