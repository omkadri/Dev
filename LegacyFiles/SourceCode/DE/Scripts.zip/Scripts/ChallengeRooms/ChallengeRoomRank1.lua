resetTrigger = Instance()
endChallengeCounter = Instance()
endChallengeValue = 1
allowedResets = 3
resetAnim = Resource()
endMissionMovie = Resource()
endMissionDialog = Instance()
kneelAnim = Resource()
endMissionTrans = Type()
endMissionFailedTrans = Type()
spawnpoints = {Instance()}

hide = false
restrictToSlot = Engine.SLOT_1
weaponAttachmentType = WeakResource()
dissolveTime = 3
targetHitEffect = Type()

local cRoom = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"
local postFade = require "Lotus.Scripts.PostProcess.BasePostProcessFade"
local challengeRunning = true

local retriesLeftMsg = "/Lotus/Language/Menu/MasteryRetriesLeft"

function OnDamaged(entity)
    local dupeFx = gRegion:FindAll(targetHitEffect, entity:GetPosition(), 0, 1)  -- Only create one
    if IsNull(dupeFx) then
        gRegion:CreateEntity(targetHitEffect, entity:GetPosition(), entity:GetRotation())
    end
end

local function Setup()
    _T.gCurrentRsPoint = 1
    _T.gCurrentResetCount = 0
    _T.gNumRsPoints = #spawnpoints
    local player = gRegion:GetLocalPlayer()
    player:SetPlayerSpawn(spawnpoints[_T.gCurrentRsPoint])
    
    if not IsNull(targetHitEffect) then
        local targets = gRegion:FindTagged(Symbol("Target"))
        for i = 1, #targets do
            ObjectPortHandler(targets[i],"OnDamaged")
        end
    end
end

local function ResetLevel()
    
    local platforms = gRegion:FindTagged(Symbol("Platform"))
    for i = 1, #platforms do
        platforms[i]:SetVisibility(false,true)
        platforms[i]:FirePort("Beginning")
    end
    
    --[[local triggers = gRegion:FindTagged(Symbol("Trigger"))
    for i = 1, #triggers do
        triggers[i]:Enable()
    end]]
    
    local targetTriggers = gRegion:FindTagged(Symbol("TargetTrigger"))
    for i = 1, #targetTriggers do
        targetTriggers[i]:Enable()
    end
    
    local beams = gRegion:FindTagged(Symbol("Beam"))
    for i = 1, #beams do
        beams[i]:FirePort("Disable")
    end
    
    local targets = gRegion:FindTagged(Symbol("Target"))
    for i = 1, #targets do
        targets[i]:SetVisibility(false,true)
        --targets[i]:SetHealth(targets[i]:GetDefaultHealth())
    end
    
end

--if you fell off the platform, teleport to the current restart waypoint
local function ResetCheck()
    
    local entitiesTouching = resetTrigger:GetEntitiesTouching()
    local gameRules = gGameRules
    local playerAv = gRegion:GetLocalPlayerAvatar()
    
    for i = 1,#entitiesTouching do
        if entitiesTouching[i] == playerAv then
            local player = playerAv:GetPlayer()
            postFade.Fade(0,-1,0.5)
            ResetLevel()
            gameRules:RespawnPlayer(player, false)
            player:GetAvatar():SetCameraView(player:GetPlayerSpawn():GetRotation())
            player:GetAvatar():MotionControl():SetTorsoFromView(player:GetPlayerSpawn():GetRotation())
            player:GetAvatar():PlayAnimation(resetAnim, false, Engine.ATMM_ANIMATION_DRIVEN)
            _T.gCurrentResetCount = _T.gCurrentResetCount + 1
            if _T.gCurrentResetCount <= allowedResets then
                _T.ShowImpactMessage(retriesLeftMsg, 5, false, nil, false, { RETRIES = allowedResets - _T.gCurrentResetCount })
            end
            postFade.Fade(-1,0,2)
            break
        end
    end
    
end

function RunChallenge()
    Setup()
    
    while challengeRunning do
    
        ResetCheck()
        
        if endChallengeCounter:GetCurrentValue() == endChallengeValue or _T.gCurrentResetCount > allowedResets then
            challengeRunning = false
        end
        
        Sleep(0)
    
    end
    
    local playerAv = gRegion:GetLocalPlayerAvatar()
    
    if _T.gCurrentResetCount > allowedResets then
        Sleep(0.25)
        playerAv:PlayNonReplicatedAnimation(kneelAnim, true, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_FREEZE, true)
        playerAv:GiveItem(endMissionFailedTrans, true)
        Sleep(3)
        cRoom.ChallengeFailed()
    else
        local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
        LOTUS_UTIL.OnChallengePassed(playerAv, kneelAnim, endMissionTrans, endMissionMovie, endMissionDialog)
    end

end

function SetNextRestartWaypoint()
    if _T.gCurrentRsPoint < _T.gNumRsPoints then
        _T.gCurrentRsPoint = _T.gCurrentRsPoint + 1
    end
    
    local player = gRegion:GetLocalPlayer()
    player:SetPlayerSpawn(spawnpoints[_T.gCurrentRsPoint])
    
    _T.gCurrentResetCount = 0
end

function SetRestrictToSlot()
    
    local avatar = gRegion:GetLocalPlayerAvatar()
    local inv = avatar:InventoryControl()
    local equippedWeap = inv:GetWeaponInSlot(restrictToSlot)

    inv:GetActivePowerSuit():SetAbilityIdentifiersBlocked(true)
    
    while IsNull(equippedWeap) or (restrictToSlot == Engine.SLOT_6 and equippedWeap:GetActualHand() ~= Engine.EXTRA2) do
        Sleep(0)
        if IsNull(equippedWeap) then
            equippedWeap = inv:GetWeaponInHand(Engine.MAIN_HAND)
        end
    end
    
    if restrictToSlot == Engine.SLOT_1 then
        avatar:InventoryControl():SetWeaponDisabled(Engine.SLOT_2)
        avatar:InventoryControl():SetWeaponDisabled(Engine.SLOT_6)
    elseif restrictToSlot == Engine.SLOT_2 then
        avatar:InventoryControl():SetWeaponDisabled(Engine.SLOT_1)
        avatar:InventoryControl():SetWeaponDisabled(Engine.SLOT_6)
    elseif restrictToSlot == Engine.SLOT_6 then
        avatar:InventoryControl():SetWeaponDisabled(Engine.SLOT_1)
        avatar:InventoryControl():SetWeaponDisabled(Engine.SLOT_2)
    end
    
    avatar:InventoryControl():Equip(restrictToSlot, Engine.MAIN_HAND, Engine.InventoryControllerBase_ES_PLAY_EQUIP_ANIM)
end

function HideAllWeapons()
    local players = gRegion:GetHumanPlayers()
    local avatar = players[1]:GetAvatar()
    local attachments = avatar:GetAllAttachments(weaponAttachmentType)
    local t = 0
    
    while t < dissolveTime do
        for i = 1,#attachments do
            attachments[i]:SetDissolve(Lerp(0,1,t/dissolveTime))
        end
        Sleep(0)
        t =  t + DeltaTime()
    end
    
    for i = 1,#attachments do
        attachments[i]:SetAlwaysHide(hide)
    end
end

function InfiniteAmmo(trigger)    
    Sleep(0)
    local players = gRegion:GetHumanPlayers()
    local avatar = players[1]:GetAvatar()
    local inv = avatar:InventoryControl()
    local weapon = inv:GetWeaponInHand(Engine.MAIN_HAND)
    local ammoExType = weapon:GetAmmoExType()
    
    while not IsNull(trigger) do        
        while IsNull(weapon) do
            weapon = gRegion:GetHumanPlayers()[1]:GetAvatar():InventoryControl():GetWeaponInHand(Engine.MAIN_HAND)
            Sleep(0)
            print("getting weapon")
        end
        
        while IsNull(inv) do
            inv = gRegion:GetHumanPlayers()[1]:GetAvatar():InventoryControl()
            Sleep(0)
        end
        
        if inv:GetMaxAmmoEx(ammoExType) >= inv:GetAmmoExCount(ammoExType) then
            inv:GiveAmmoEx(ammoExType, inv:GetMaxAmmoEx(ammoExType) - inv:GetAmmoExCount(ammoExType))
        end
        Sleep(0)
    end
        
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end
