backupAiSpec = Resource()
dialogTrigger = Instance()
endMissionMovie = WeakResource()
kneelAnim = Resource()
kneelIdleAnim = Resource()
standAnim = Resource()
spawnEffect = Resource()
projector = Resource()
invulnProjector = Resource()
endMissionTrans = Resource()

local UTIL = require "EE.Interface.Utilities"
local CROOM = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"
local POST = require "Lotus.Scripts.PostProcess.BasePostProcessFade"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local TABLE = require "Lotus.Scripts.Libs.TableLib"

local sInvuln = Symbol("Invuln")
local sRandomTeam = Symbol("RandomTeam")
local sFaction = Symbol("Challenge")

local mModifierLocs = {}

local ON_KILL_TIMER_INCREASE = 15
local LEVEL_BONUS = 0
local COMBO_TIMER_REDUCTION = 0
local ROUND_IMPACT_MESSAGE_DURATION = 6

local mAiDir = nil
local mPlayer = nil
local mPlayerAv = nil

local mTimerMgr = nil

local mAgentTypes = {}
local mBossAgentTypes = {}
local mSpawnPoints = {}
local mCurrentAgentType = 1
local mCurrentSpawnPt = 1
local mCombo = 0
local mComboTimer = 0
local mRound = 1
local mShowComboTimer = 4
local mMinLevel = 0
local mMaxLevel = 0
local mFailed = false
local mRespawnPos
local mRespawnRot

local mTestSucceeded = false

local mTimerTracker = nil
local mLabelTracker = nil

local function NextRound()
    mRound = mRound + 1
    if mRound > 1 then
        _T.ShowImpactMessage("120% ENEMY ARMOR", ROUND_IMPACT_MESSAGE_DURATION, false, nil, nil)
        
    end
    
    if mRound > 2 then
        _T.ShowImpactMessage("ENEMY LEVELS +10", ROUND_IMPACT_MESSAGE_DURATION, false, nil, nil)
        LEVEL_BONUS = 10
    end
    
    if mRound > 3 then
        _T.ShowImpactMessage("150% ENEMY HEALTH", ROUND_IMPACT_MESSAGE_DURATION, false, nil, nil)
    end
    
    if mRound > 4 then
        _T.ShowImpactMessage("ENEMY LEVELS +20", ROUND_IMPACT_MESSAGE_DURATION, false, nil, nil)
        LEVEL_BONUS = 20
    end
    
    if mRound > 5 then
        _T.ShowImpactMessage("COMBO TIMER REDUCED 3 SECONDS", ROUND_IMPACT_MESSAGE_DURATION, false, nil, nil)
        COMBO_TIMER_REDUCTION = 3
    end    
    
    if mRound > 6 then
        _T.ShowImpactMessage("ENEMY LEVELS +30", ROUND_IMPACT_MESSAGE_DURATION, false, nil, nil)
        LEVEL_BONUS = 30
    end
    
    if mRound > 7 then
        _T.ShowImpactMessage("ENEMY LEVELS +20", ROUND_IMPACT_MESSAGE_DURATION, false, nil, nil)
        
    end
    
    if mRound > 8 then
        _T.ShowImpactMessage("ENEMY LEVELS +40", ROUND_IMPACT_MESSAGE_DURATION, false, nil, nil)
        LEVEL_BONUS = 40
    end
    
    if mRound > 9 then
        _T.ShowImpactMessage("ENEMY LEVELS +20", ROUND_IMPACT_MESSAGE_DURATION, false, nil, nil)
    end
end

local function ApplyModifier(avatar)
    local inv = avatar:InventoryControl()
    if mRound > 1 then
        inv:AddUpgrade(Game.AVATAR_ARMOUR, Game.MULTIPLY, 1.2)
    end
    
    if mRound > 2 then
    end
    
    if mRound > 3 then
        inv:AddUpgrade(Game.AVATAR_HEALTH_MAX, Game.MULTIPLY, 1.5)
    end
    
    if mRound > 4 then
    end
    
    if mRound > 5 then
    end
    
    if mRound > 6 then
    end
    
    if mRound > 7 then
    end
    
    if mRound > 8 then
        
    end
    
    if mRound > 9 then
    end
end

local function CreateAgent()
    local agentType
    if mCurrentAgentType == 10 then
        agentType = mBossAgentTypes[mRound]
        mCurrentAgentType = 0
    else
        agentType = mAgentTypes[mCurrentAgentType]
    end
    
    local spawn = mSpawnPoints[mCurrentSpawnPt]
    local agent = mAiDir:CreateAgent(agentType, spawn, EMPTY_SYMBOL, mMinLevel + LEVEL_BONUS)
    
    if not IsNull(agent) then
        mCurrentAgentType = mCurrentAgentType + 1
        mCurrentSpawnPt = UTIL.Ternary(mCurrentSpawnPt + 1 > #mSpawnPoints, 1, mCurrentSpawnPt + 1)
        local avatar = agent:GetAvatar()
        CROOM.SetupEnemy(avatar, spawnEffect, invulnProjector)
        ObjectPortHandler(avatar, "OnKilled")
        avatar:SetFaction(sFaction)
        ApplyModifier(avatar)
    end
end

local function ClearEnemies()
    local enemies = gRegion:FindAll(gLotusNpcAvatarType)
    for i=1,#enemies do
        enemies[i]:Destroy()
    end
end

local function Retry()
    ClearEnemies()

    mPlayer = gRegion:GetLocalPlayer()
    gGameRules:RespawnPlayer(mPlayer, false)
    mPlayerAv = mPlayer:GetAvatar()
    ObjectPortHandler(mPlayerAv, "OnKilled")
    mPlayerAv:Teleport(mRespawnPos, mRespawnRot)

    mCurrentAgentType = 1
    mCurrentSpawnPt = 1
    mCombo = 0
    mComboTimer = ON_KILL_TIMER_INCREASE
    mRound = 1
    mShowComboTimer = 4
    mFailed = false

    -- _T.RemoveHudTracker("ComboTimerTracker")
    -- _T.RemoveHudTracker("ComboLabelTracker")

    Sleep(0)

    mTimerTracker = _T.AddHudTracker("ComboTimerTracker", LOTUS_UTIL.HT_TIMER)
    mTimerTracker.SetLabel("COMBO TIMER")
    mTimerTracker.SetValue(mComboTimer)

    mLabelTracker = _T.AddHudTracker("ComboLabelTracker", LOTUS_UTIL.HT_LABEL)
    mLabelTracker.SetLabel("COMBO: " .. mCombo .. "X")
    
    CreateAgent()
    CreateAgent()
    CreateAgent()
end

local function Init()
    local playerSpawn = gRegion:FindAll(gPlayerSpawnType)[1]
    assert(not IsNull(playerSpawn))
    mRespawnPos, mRespawnRot = playerSpawn:GetPosition(), playerSpawn:GetRotation()

    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    
    mTimerMgr = TIMER.CreateTimerMgr()
    
    gGameRules:SetSaveMatchStatsDisabled(true)
    gGameRules:SetShowReviveScreenOnDeath(false)
    
    local missionInfo = gGameRules:GetMission()
    mMinLevel = missionInfo.minEnemyLevel
    mMaxLevel = missionInfo.maxEnemyLevel
    
    mAiDir:Enable(true)
    mAiDir:SetEnableAutoSpawns(false)
    
    local aiList = gGameRules:GetMissionAI()
    if IsNull(aiList) then
        aiList = backupAiSpec:GetEnemies()
    end
    for i, enemy in ipairs(aiList) do
        mAiDir:AddMissionAIType(enemy.agent, enemy.probability, enemy.maxSimultaneous, enemy.tier)
        if enemy.tier == 0 then
            table.insert(mAgentTypes, Type(enemy.agent))
        else
            table.insert(mBossAgentTypes, Type(enemy.agent))
        end
    end
    
    mSpawnPoints = gRegion:FindAll(gNpcSpawnPointType)

    CROOM.SetMaxAttempts(3)
    
    Retry()

    mAiDir:SetLevelAlert(true)
    mAiDir:SetObjective(mPlayerAv)
    if mAiDir:GetMinEnemyLevel() == 1 then
        mAiDir:SetEnemyLevelMinMax(45,55)
    end
    mAiDir:SetCustomSpawnSelectionFilter(10, 100, 0, 5, false, false, false)
    mAiDir:SetUseCustomSpawnSelectionFilter(true)
    mAiDir:OrderNpcsStormTarget(mPlayer:GetAvatar(), 10)
end

function ComboChallenge()
    Sleep(1)
    Init()
    
    while true do
        Sleep(0)
        
        if IsNull(mPlayerAv) then
            mPlayerAv = mPlayer:GetAvatar()
            mAiDir:OrderNpcsStormTarget(mPlayerAv, 10)
            ObjectPortHandler(mPlayerAv, "OnKilled")
        end
        
        if mCombo >= 100 then
            mTestSucceeded = true
            break
        end
        
        mTimerMgr:Update(DeltaTime())
        
        mComboTimer = math.max(mComboTimer - DeltaTime(), 0)
        mTimerTracker.SetValue(mComboTimer)

        if mComboTimer <= 0 then
            mFailed = true
        end

        if mComboTimer <= mShowComboTimer then
            _T.ShowImpactMessage(math.floor(mComboTimer) .. " SECONDS LEFT", 1, false, nil, nil)
            mShowComboTimer = mShowComboTimer - 1
        end

        mLabelTracker.SetLabel("COMBO: " .. mCombo .. "X")

        if mFailed then
            if CROOM.PlayerRetry() then
                Retry()
            else
                mTestSucceeded = false
                break
            end
        end
    end

    if mTestSucceeded then
        ClearEnemies()
        local playerAv = gRegion:GetLocalPlayerAvatar()
        LOTUS_UTIL.OnChallengePassed(playerAv, kneelAnim, endMissionTrans, endMissionMovie, dialogTrigger)
    else
        CROOM.ChallengeFailed()
    end
end

function OnKilled(avatar)
    if avatar == mPlayerAv then 
        mFailed = true
    elseif not mFailed then
        mCombo = mCombo + 1
        
        if math.mod(mCombo, 10) == 0 then
            NextRound()
        else
            _T.ShowImpactMessage(mCombo .. "X", 3, false, nil, nil)
        end

        if mCombo == 100 then
            return
        end
        
        mComboTimer = ON_KILL_TIMER_INCREASE - COMBO_TIMER_REDUCTION
        mTimerTracker.SetValue(mComboTimer)
        CreateAgent()
    end
end
