backupAiSpec = Resource()
dialogTrigger = Instance()
endMissionMovie = WeakResource()
championDeathBank = Resource()
kneelAnim = Resource()
kneelIdleAnim = Resource()
standAnim = Resource()
spawnEffect = Resource()
projector = Resource()
endMissionTrans = Resource()

local gameRules = gGameRules
local aiDir = gRegion:GetNpcMgr():GetAiDirector()

local energyPickupType = Type("/Lotus/Types/PickUps/EnergyIncreasePvPSmall")

local UTIL = require "EE.Interface.Utilities"
local CROOM = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"
local POST = require "Lotus.Scripts.PostProcess.BasePostProcessFade"

local killMessageTag = "/Lotus/Language/Game/PVEDeathMatchKillMessage"
local fastMovementLoc = "/Lotus/Language/Game/PveDeathMatchFasterMovement"
local vampireModifierLoc = "/Lotus/Language/Game/PveDeathMatchVampire"
local levelUpLoc = "/Lotus/Language/Game/PveDeathMatchLevelUp"
local roundStartingTag = "/Lotus/Language/Menu/PvpRoundStarting"
local roundStartTag = "/Lotus/Language/Menu/PvpBeginRound"
local roundCompleteLoc = "/Lotus/Language/Menu/Mission_RoundComplete"
local killsLoc = "/Lotus/Language/Menu/KillsScoreBoard"

local mPlayerScore = 0
local mKillMessageDuration = 5
local mMinSpawnDistance = 15
local mNearTeamDistance = 25
local mEnergyRespawnTime = 35
local mRespawnTime = 5
local mMissionFailed = false
local mMissionComplete = false
local mKillGoals = {12, 18, 24}
local mMaxAgents = {4, 6, 8}
local mCurrentRound = 1
local enemyLevel = 1
local mPlayerRespawnDelay = 2

local mRoundStarted = false
local mPlayer = nil
local mEnemies = {}
local mSpawns = {}
local mAgentTypes = {}

local mVampireDD = Engine.DamageData()

local mTimerMgr = nil

local mModifiers = 
{
    { name = "FAST_MOVEMENT", aura = Resource("/Lotus/Upgrades/Mods/DirectorMods/FastMovementSpeedLevelAura"), loc = fastMovementLoc },
    { name = "VAMPIRE", aura = nil, loc = vampireModifierLoc },
    { name = "LEVEL_UP", aura = nil, loc = levelUpLoc },
}

local function IsNear(entity, nearList, nearDistance)
    for i, near in ipairs(nearList) do
        if not IsNull(near) then
            local avatar = near:GetAvatar()
            if not IsNull(avatar) and not avatar:IsKilled() and avatar:DistanceToEntity(entity) < nearDistance then
                return true
            end
        end
    end
    
    return false
end

local function CanSee(entity, seeList)
    for i, see in ipairs(seeList) do
        if not IsNull(see) then
            local avatar = see:GetAvatar()
            if not IsNull(avatar) and not avatar:IsKilled() and avatar:CanSeeEntity(entity, -1, false, false) >= 0.1 then
                return true
            end
        end 
    end
    
    return false
end

local function IsValidSpawn(spawn, enemies, teammates)    
    if IsNear(spawn, enemies, mMinSpawnDistance) then   --near enemies
        return false
    end
    
    if CanSee(spawn, enemies) then                      --visible to enemies
        return false
    end
    
    if IsNear(spawn, teammates, 1) then                 --on top of friendlies
        return false
    end
    
    return true
end

local function SelectSpawn(isPlayer)
    
    local teammates = UTIL.Ternary(isPlayer, {mPlayer}, mEnemies)
    local enemies = UTIL.Ternary(isPlayer, mEnemies, {mPlayer})
    
    --select spawns that enemies can't see and aren't near
    local potentialSpawns = {}
    for i, spawn in ipairs(mSpawns) do
        if IsValidSpawn(spawn, enemies, teammates) then
            table.insert(potentialSpawns, spawn)
        end
    end    

    local spawnToUse = nil
    if IsNull(spawnToUse) then
        for i, spawn in ipairs(potentialSpawns) do
            if IsNear(spawn, teammates, mNearTeamDistance) then
                spawnToUse = spawn
                break
            end
        end
    end
    
    if IsNull(spawnToUse) then
        --last resort spawn selection
        if #potentialSpawns > 0 then
            spawnToUse = potentialSpawns[RandomInt(1, #potentialSpawns)]
        else
            spawnToUse = mSpawns[RandomInt(1, #mSpawns)]
        end
    end
    
    return spawnToUse
end

local SpawnAgent = function(agentType, spawnPointOverride)
    local spawn = UTIL.Ternary(IsNull(spawnPointOverride), SelectSpawn(false), spawnPointOverride)
    local agent = aiDir:CreateAgentAtPosition(agentType, spawn:GetPosition(), spawn:GetRotation())
    
    if not IsNull(agent) then
        CROOM.SetupEnemy(agent:GetAvatar(), spawnEffect, projector)
        local foundSlot = false
        for i, enemy in ipairs(mEnemies) do
            if IsNull(enemy) then
                mEnemies[i] = agent
                foundSlot = true
                break
            end
        end
        
        if not foundSlot then
            table.insert(mEnemies, agent)
        end
    end
end

local SpawnPlayer = function(player)
    if not mRoundStarted then
        return
    end

    local spawn = SelectSpawn(true)
    player:SetPlayerSpawn(spawn)
    gGameRules:RespawnPlayer(player, false)
    if _G.IsTrainingMissionPractise then
        Sleep(0)
        player:GetAvatar():InventoryControl():ToggleTrackKills(false)
    end
end

local SpawnEnergy

function OnPickedUp(pickup)
    local waypoint = gRegion:FindNearestTagged(Symbol("EnergySpawn"), pickup:GetPosition())
    mTimerMgr:AddTimer(mEnergyRespawnTime, SpawnEnergy, false, waypoint)
end

SpawnEnergy = function(waypoint)
    local pickup = gRegion:CreateEntity(energyPickupType, waypoint:GetPosition(), ZERO_ROTATION)
    if not IsNull(pickup) then
        ObjectPortHandler(pickup, "OnPickedUp")
    else
        mTimerMgr:AddTimer(mEnergyRespawnTime, SpawnEnergy, false, waypoint)
    end
end

local VampireDamage = function()
    local avatar = gRegion:GetLocalPlayerAvatar()
    if not avatar:IsKilled() and avatar:GetHealth() > 2 then
        avatar:DamageDD(mVampireDD)
    end
end

local function ColorizeText(text, color)
    if IsNull(text) then
        return nil
    end

    return "<font color=\"#" .. string.format("%X", color) .. "\">" .. text .. "</font>"
end

local function ShowKillMessage(sourceName, victimName, assistName, victimIsPlayer)    
    sourceName = ColorizeText(sourceName, UTIL.Ternary(victimIsPlayer, _G.UIColor_PvpTeamTwo, _G.UIColor_PvpTeamOne))
    victimName = ColorizeText(victimName, UTIL.Ternary(victimIsPlayer, _G.UIColor_PvpTeamOne, _G.UIColor_PvpTeamTwo))

    local eventMsg = ColorizeText(" " .. Localize(killMessageTag, {}) .. " ", _G.UIColor_White)
    local msg = "<p>" .. sourceName .. eventMsg .. victimName .. "</p>"
    local object = {}
    object.Life = mKillMessageDuration
    _T.AddLogMessage(msg, object)
end

local function GetValidDeathSource(dd)
    local victim = dd:GetVictim()
    if victim:IsIgnoredByAiDirector() or victim:IsA(gLotusSentinelAvatarType) or (victim:GetFaction() == Symbol("TENNO") and IsNull(victim:GetPlayer())) then
        return nil
    end
    
    local source = dd:GetSource()
    if IsNull(source) then
        return nil
    end
    
    if not source:IsA(gBaseAvatarType) then
        print(source:GetFullName() .. " killed " .. victim:GetUIName() .. " but was ignored, because non-avatar")
        return nil
    end

    if source:IsA(gLotusNpcAvatarType) then
        local creator = source:GetCreatorAvatar()
        if not IsNull(creator) then
            return creator
        end
        
        local spawnedByAv = source:GetSpawnedByAvatar()
        if not IsNull(spawnedByAv) then
            return spawnedByAv
        end
    end
        
    return source
end

local function IsModifierActive(name)
    for i, modifier in ipairs(mModifiers) do
        if i > mCurrentRound then
            break
        elseif modifier.name == name then
            return true
        end
    end
    return false
end

function OnDeath(dd)
    local source = GetValidDeathSource(dd)
    local victim = dd:GetVictim()
        
    if IsNull(victim:GetPlayer()) and not IsNull(source) then
        mPlayerScore = mPlayerScore + 1
        mTimerMgr:AddTimer(mRespawnTime, SpawnAgent, false, victim:GetAgentType())
        UTIL.PlaySound(championDeathBank)
        if IsModifierActive("LEVEL_UP") then
            aiDir:SetEnemyLevelMinMax(enemyLevel + mPlayerScore, enemyLevel + mPlayerScore)
        end
        
        if IsModifierActive("VAMPIRE") and not source:IsKilled() then
            source:SetHealth(source:GetMaxHealth())
        end
    elseif not IsNull(victim:GetPlayer()) then
        local retrying = CROOM:PlayerRetry() 
        if retrying then
            mTimerMgr:AddTimer(mPlayerRespawnDelay, SpawnPlayer, false, victim:GetPlayer())
        else
            mMissionFailed = true
        end
    end
    
    if not IsNull(source) then
        ShowKillMessage(source:GetUIName(), victim:GetUIName(), nil, IsNull(source:GetPlayer()))
    end
end

local function EnableNextModifier()
    if not IsNull(mModifiers[mCurrentRound].aura) then
        gGameRules:AddActiveLevelAuraUpgrade(mModifiers[mCurrentRound].aura)
    elseif mModifiers[mCurrentRound].name == "VAMPIRE" then
        mTimerMgr:AddTimer(5, VampireDamage, true)
    end
end

function ArenaChallenge()
    Sleep(1)

    local TimerLib = require "Lotus.Interface.Libs.TimerMgr"
    mTimerMgr = TimerLib.CreateTimerMgr()

    mVampireDD.baseAmount = 100
    mVampireDD.canBeFatal = false
    mVampireDD:SetDamagePct(Engine.DT_HEALTH_DRAIN, 1.0)
    
    championDeathBank = championDeathBank
    
    CROOM.SetMaxAttempts(3)
    local missionInfo = gameRules:GetMission()
    
    aiDir:Enable(true)
    aiDir:SetEnableAutoSpawns(false)
    aiDir:SetLevelAlert(true)
    aiDir:InitInfluenceMap(Symbol("Grineer"), 1, 0.1, true, false, 0, 0.25)
    aiDir:InitInfluenceMap(Symbol("EnemyActivity"), 0.1, 0.5, false, false, 0, 0.25)
    aiDir:SetEnemyLevelMinMax(missionInfo.minEnemyLevel, missionInfo.maxEnemyLevel)
    enemyLevel = missionInfo.minEnemyLevel

    local aiList = gameRules:GetMissionAI()
    if IsNull(aiList) or #aiList == 0 then
        aiList = backupAiSpec:GetEnemies()   --only used when loading via File -> Load Level
        aiDir:SetEnemyLevelMinMax(40, 40)
        enemyLevel = 40
    end
    
    for i, enemy in ipairs(aiList) do
        aiDir:AddMissionAIType(enemy.agent, enemy.probability, enemy.maxSimultaneous, enemy.tier)
        mAgentTypes[i] = Type(enemy.agent)
    end
    
    local energySpawns = gRegion:FindTagged(Symbol("EnergySpawn"))
    for i, spawn in ipairs(energySpawns) do
        mTimerMgr:AddTimer(mEnergyRespawnTime, SpawnEnergy, false, spawn)
    end
    
    gameRules:AddOnDeathCallback("OnDeath")
    gameRules:SetShowReviveScreenOnDeath(false)
    gameRules:SetConsumablesDisabled(true)
    gameRules:SetSentinelSpawningAllowed(false)
    
    mPlayer = gRegion:GetLocalPlayer()
    
    mSpawns = gRegion:FindAll(gPlayerSpawnType)
    if #mSpawns > 0 then
        aiDir:SetObjective(mSpawns[1])
    end

    local initialEnemySpawns = {}
    local initialPlayerSpawn = nil
    for i, spawn in ipairs(mSpawns) do
        if spawn:GetTeam() == Symbol("Team2") then
            table.insert(initialEnemySpawns, spawn)
        elseif spawn:GetTeam() == Symbol("Team1") then
            initialPlayerSpawn = spawn
        end
    end
    
    local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
    local progressBar = nil
    
    while not IsNull(gameRules) do
        if mMissionFailed or mMissionComplete then
            break
        end
        
        if not mRoundStarted then
            if mCurrentRound > 1 then
                POST.Fade(-1,-1,0)
                mPlayer:SetPlayerSpawn(initialPlayerSpawn)
                mPlayer:GetAvatar():InventoryControl():GetActivePowerSuit():DeactivateAbilitiesSendRMI()
                gameRules:RespawnPlayer(mPlayer, false)
                Sleep(0)
                mPlayer:GetAvatar():PlayNonReplicatedAnimation(kneelIdleAnim, false, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_LOOP, false)
                if _G.IsTrainingMissionPractise then
                    mPlayer:GetAvatar():InventoryControl():ToggleTrackKills(false)
                end
                POST.Fade(-1,0,2)
            end
            
            gameRules:DisplayMessage(gRegion:GetLocalPlayer(), roundStartingTag, mModifiers[mCurrentRound].loc, 0, 5, true)
            Sleep(4)
            mPlayer:GetAvatar():PlayNonReplicatedAnimation(standAnim, false, Engine.ATMM_ANIMATION_DRIVEN,Engine.PRT_ONCE, false)
            Sleep(1)
            
            for i, agentType in ipairs(mAgentTypes) do
                if i <= mMaxAgents[mCurrentRound] then
                    SpawnAgent(agentType, initialEnemySpawns[math.min(i, #initialEnemySpawns)])
                    Sleep(0)
                end
            end
            
            EnableNextModifier()
            mRoundStarted = true
            gameRules:DisplayMessage(gRegion:GetLocalPlayer(), roundStartTag, mModifiers[mCurrentRound].loc, 0, 5, true)
        end
        
        --sucks but no callback for avatars being created - since this is SP only and low enemy counts I don't think the impact will be noticeable
        local npcs = gRegion:FindAll(gLotusNpcAvatarType)
        for i, npc in ipairs(npcs) do
            if npc:GetFaction() ~= Symbol("TENNO") and not npc:HasAttachment(projector) then
                CROOM.SetupEnemy(npc, spawnEffect, projector)
            end
        end
        
        if IsNull(progressBar) then
            progressBar = _T.AddHudTracker("ArenaChallengeProgressBar", LOTUS_UTIL.HT_PROGRESS_BAR, 0.2, false, false)
            progressBar.SetFlareColor(_G.UIColor_DarkBlue)
        end
        progressBar.SetLabel(killsLoc, 1)
        progressBar.SetGoalLabel(mPlayerScore .. " / " .. mKillGoals[mCurrentRound])
        progressBar.SetValue(mPlayerScore / mKillGoals[mCurrentRound])
        mTimerMgr:Update(DeltaTime())
        
        if mPlayerScore >= mKillGoals[mCurrentRound] then
            for i, npc in ipairs(npcs) do
                npc:Destroy()
            end

            mTimerMgr:ClearTimers()
            
            if mCurrentRound < #mKillGoals then
                mCurrentRound = mCurrentRound + 1
                mPlayerScore = 0
                _T.ShowImpactMessage(roundCompleteLoc, 3, nil, nil, false)
                mRoundStarted = false
                Sleep(3)
            else
                mMissionComplete = true
            end
        end
        
        Sleep(0)
    end
    
    if mMissionComplete then
        local playerAv = gRegion:GetLocalPlayerAvatar()
        LOTUS_UTIL.OnChallengePassed(playerAv, kneelAnim, endMissionTrans, endMissionMovie, dialogTrigger)
    else
        CROOM.ChallengeFailed()
    end
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end
