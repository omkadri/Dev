resetAnim = Resource()
allowedResets = 3
endMissionMovie = Resource()
endMissionDialog = Instance()
kneelAnim = Resource()
transmission = Type()
failTrans = Type()
enemyProjectorFX = Type()
spawnEffect = Resource()
allSpawnControls = {Instance()}       --all spawn controls - used for cleanup
spawn = Instance()
meleeTargetWaypoints = {Instance()}
meleeTargetType = Type()
rescueObjectiveMarker = Instance()
escapeTrigger = Instance()


local CROOM = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"
local POST = require "Lotus.Scripts.PostProcess.BasePostProcessFade"

local playerAv = gRegion:GetLocalPlayerAvatar()
local aiDir = gRegion:GetNpcMgr():GetAiDirector()
local gameRules = gGameRules
local tries = 0
local stealthCompleted = false
local targetsDestroyed = 0
local meleeTargets = {}
local detected = false
local challengeComplete = false

local targetsDestroyedLoc = "/Lotus/Language/Game/TargetsDestroyed"
local attemptsLeftLoc = "/Lotus/Language/Game/AttemptsLeft"
local detectedLoc = "/Lotus/Language/Game/Detected"

local function CreateMeleeTargets()
    for i, meleeTarget in ipairs(meleeTargets) do
        if not IsNull(meleeTarget) then
            meleeTarget:Destroy()
        end
    end
    meleeTargets = {}
    for i, meleeTargetWaypoint in ipairs(meleeTargetWaypoints) do
        local pos = meleeTargetWaypoint:GetPosition()
        pos.y = pos.y + 1
        local meleeTarget = gRegion:CreateEntity(meleeTargetType, pos, ZERO_ROTATION)
        table.insert(meleeTargets, meleeTarget)
        ObjectPortHandler(meleeTarget, "OnDestroyed")
    end
end

function RunChallenge()

    while IsNull(playerAv) do
        Sleep(0)
        playerAv = gRegion:GetLocalPlayerAvatar()
    end
    playerAv:DamageControl():AddDamageModifier(Symbol("RescueChallengeInvulnDM"), Engine.DT_ANY, Engine.ANY_PART, 0)
    playerAv:DamageControl():AddShieldHealthDamageModifier(Symbol("RescueChallengeInvulnDM"), Engine.DT_ANY, Engine.ANY_PART, Engine.DHT_NONE, 0)
    
    gameRules:SetSaveMatchStatsDisabled(true)
    aiDir:SetObjective(playerAv)
    spawn = spawn
    rescueObjectiveMarker = rescueObjectiveMarker
    
    for i, spawnControl in ipairs(allSpawnControls) do
        ObjectPortHandler(spawnControl, "OnAgentCombat")
    end
    ObjectPortHandler(escapeTrigger, "OnTouched")
    CreateMeleeTargets()
    
    local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
    local progressBar = nil
    
    while tries < allowedResets and not challengeComplete do
        Sleep(0)
        if IsNull(progressBar) then
            progressBar = _T.AddHudTracker("RescueChallengeProgressBar", LOTUS_UTIL.HT_PROGRESS_BAR, 0.2, false, false)
            progressBar.SetFlareColor(_G.UIColor_DarkBlue)
            progressBar.SetGoalLabel(progressBar.Localize(targetsDestroyedLoc), 1)
        end
        progressBar.SetLabel(targetsDestroyed .. " / " .. #meleeTargets)
        progressBar.SetValue(targetsDestroyed / #meleeTargets)
    end
    
    if IsNull(playerAv) then
        playerAv = gRegion:GetPlayerAvatar(0)
    end
    
    if challengeComplete then
        LOTUS_UTIL.OnChallengePassed(playerAv, kneelAnim, transmission, endMissionMovie, endMissionDialog)
    else
        playerAv:PlayNonReplicatedAnimation(kneelAnim, true, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_FREEZE, true)
        playerAv:GiveItem(failTrans, true)
        Sleep(3)
        CROOM.ChallengeFailed()
    end
end

function OnTouched(trigger)
    challengeComplete = true
end

function OnAgentCombat(entity)
    if IsNull(_T.ShowImpactMessage) or stealthCompleted then
        return
    end
    
    if IsNull(playerAv) then
        playerAv = gRegion:GetPlayerAvatar(0)
    end
    
    detected = true
    tries = tries + 1
    _T.ShowImpactMessage(Localize(detectedLoc, nil), 5, true, nil, false)
    while playerAv:IsDoingFinisher() do
        Sleep(0)
    end
    
    playerAv:PlayNonReplicatedAnimation(kneelAnim, true, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_FREEZE, true)
    POST.Fade(0,-1,2)
    playerAv:Teleport(spawn:GetPosition())
    Sleep(1)
    for i, spawnControl in ipairs(allSpawnControls) do
        spawnControl:FirePort("Remove Agents")
        spawnControl:FirePort("Reset")
    end
    
    local avatars = gRegion:FindAll(gLotusNpcAvatarType)
    for i, avatar in ipairs(avatars) do
        if avatar:IsKilled() then
            while IsNull(avatar:GetRagdoll()) do
                Sleep(0)
            end
        end
    end
    
    local ragdolls = gRegion:FindAll(gRagdollType)
    for i, ragdoll in ipairs(ragdolls) do
        ragdoll:Destroy()
    end
    
    targetsDestroyed = 0
    CreateMeleeTargets()
    
    playerAv:PlayAnimation(resetAnim, false, Engine.ATMM_ANIMATION_DRIVEN)
    POST.Fade(-1,0,1)
    detected = false
    
    _T.ShowImpactMessage(Localize(attemptsLeftLoc, nil) .. ": " .. allowedResets - tries, 5, true, nil, false)
end

function OnDestroyed(entity)
    if detected then
        return
    end

    targetsDestroyed = targetsDestroyed + 1
    if targetsDestroyed >= #meleeTargets then
        stealthCompleted = true
        rescueObjectiveMarker:Enable()
    end
end

function KillSentinel()
    local player = gRegion:GetLocalPlayerAvatar()
    
    if IsNull(player) then
        print("Player doesn't exist, was the script called too early?")
        return
    end
    
    local sentinel = player:InventoryControl():GetSentinel()
    
    if not IsNull(sentinel) then
        sentinel:Destroy()
    end
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end

function OnKilled(agent)
    local av = agent:GetAvatar()
    agent:ReturnToAiControl()
    CROOM.SetupEnemy(av, spawnEffect, enemyProjectorFX)
end
