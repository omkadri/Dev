endMissionMovie = Resource()
endMissionDialog = Instance()
kneelAnim = Resource()
endMissionTrans = Type()
failMissionTrans = Type()
bonusEntity = Type()
enemyProjectorFX = Type()
spawnEffect = Resource()
backupAiSpec = Resource()

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local CROOM = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"
local TABLE = require "Lotus.Scripts.Libs.TableLib"


local BONUS_SPAWN_TIME = 10
local MAX_SIMUL_TARGETS = 3
local BONUS_TIME = 20
local KILL_GOAL = 50
local MAX_SIMUL_FLYING_AI = 5
local GROUND_SQUAD_SIZE = 5
local AI_SPAWN_TIME = 2
local STARTING_TIME_LEFT = 30
local MAX_TIME_LEFT = 30
local GROUND_TIER = 0
local FLYING_TIER = 1
local FACTION = Symbol("Grineer")

local mAiDir = gRegion:GetNpcMgr():GetAiDirector()
local mGameRules = gGameRules
local mKilltotal = 0
local mPlayerAv = gRegion:GetLocalPlayerAvatar()
local mPlayer = mPlayerAv:GetPlayer()
local mIsRetrying = false

local mAvailableBonusSpawns = {}
local mUsedBonusSpawns = {}
local mBonusTargets = {}
local mFlyingSpawns = {}
local mFlyingAgents = {}
local mSquads = {}
local mArchwingPickups = {}
local mProgressBar = nil

local mTimerMgr = nil

local function SpawnFlyingAgent()
    if #mFlyingAgents + 1 < MAX_SIMUL_FLYING_AI then
        local spawn = nil
        while IsNull(spawn) do
            spawn = mFlyingSpawns[RandomInt(1, #mFlyingSpawns)]
            if mPlayerAv:Distance2DToEntity(spawn) < 10 then
                spawn = nil
            end
        end
        
        local agentType = mAiDir:GetRandomEnemyAgentType(FACTION, 0, true, true, FLYING_TIER, true)
        local agent = mAiDir:CreateAgentNearEntity(agentType, spawn, 10, Symbol("RandomTeam"))
        if IsNull(agent) then
            print("Failed to create random agent")
        else
            agent:StormTarget(mPlayerAv)
            --print(agentType:GetFullName() .. " spawned at " .. spawn:GetFullName() .. " with tag " .. spawn:GetTag():c_str())
            CROOM.SetupEnemy(agent:GetAvatar(), spawnEffect, enemyProjectorFX)
            ObjectPortHandler(agent:GetAvatar(), "OnKilled")
            table.insert(mFlyingAgents, agent)
        end
    end
end

local function SpawnGroundAgent(squad)
    local agentType = mAiDir:GetRandomEnemyAgentType(FACTION, 0, true, true, GROUND_TIER, true)
    local agent = mAiDir:CreateAgentNearEntity(agentType, squad.Target, 25, Symbol("RandomTeam"))
    if IsNull(agent) then
        print("Failed to create ground agent")
    else
        --print(agentType:GetFullName() .. " spawned at " .. spawn:GetFullName() .. " with tag " .. spawn:GetTag():c_str())
        CROOM.SetupEnemy(agent:GetAvatar(), spawnEffect, enemyProjectorFX)
        ObjectPortHandler(agent:GetAvatar(), "OnKilled")
        table.insert(squad.Agents, agent)
        squad.NumToSpawn = squad.NumToSpawn - 1
    end
end

local function Retry()
    mIsRetrying = false
    mGameRules:RespawnPlayer(mPlayer, false)
    mPlayerAv = mPlayer:GetAvatar()
end

local function Bonus()
    local index
    local spawn = nil

    while true do        
        index = RandomInt(1, #mAvailableBonusSpawns)
        spawn = mAvailableBonusSpawns[index]
        if mPlayerAv:Distance2DToEntity(spawn) > 10 then
            table.insert(mUsedBonusSpawns, spawn)
            table.remove(mAvailableBonusSpawns, index)
            break
        end
    end
    
    local bonus = gRegion:CreateEntity(bonusEntity, spawn:GetPosition(), spawn:GetRotation())
    ObjectPortHandler(bonus, "OnDestroyed")
    table.insert(mBonusTargets, bonus)
    
    local squad = {}
    squad.Agents = {}
    squad.NumToSpawn = GROUND_SQUAD_SIZE
    squad.Target = bonus
    
    table.insert(mSquads, squad)
end

function RunChallenge()
    
    local TimerLib = require "Lotus.Interface.Libs.TimerMgr"
    mTimerMgr = TimerLib.CreateTimerMgr()
    
    mGameRules:SetSaveMatchStatsDisabled(true)
    mGameRules:SetShowReviveScreenOnDeath(false)
    
    CROOM.SetMaxAttempts(3)
    
    MAX_TIME_LEFT = MAX_TIME_LEFT
    
    mAiDir:Enable(true)
    mAiDir:SetLevelAlert(true)
    mAiDir:SetObjective(mPlayerAv)
    mAiDir:SetEnemyLevelMinMax(25,30)
    mAiDir:SetCustomSpawnSelectionFilter(10, 100, 0, 5, false, false, false)
    mAiDir:SetUseCustomSpawnSelectionFilter(true)
    mAiDir:SetEnableAutoSpawns(false)
    local aiList = mGameRules:GetMissionAI()
    if IsNull(aiList) then
        aiList = backupAiSpec:GetEnemies()
    end
    
    for i, enemy in ipairs(aiList) do
        mAiDir:AddMissionAIType(enemy.agent, enemy.probability, enemy.maxSimultaneous, enemy.tier)
    end
    
    Sleep(0)    --wait a frame for ai director to init before we try to spawn enemies (hits a debug crash otherwise)
    
    mAvailableBonusSpawns = gRegion:FindTagged(Symbol("BonusSpawn"))
    mFlyingSpawns = gRegion:FindTagged(Symbol("FlyingSpawn"))
    
    mPlayer:AddTimerOfInterest(Symbol("TimeAttack"))
    mGameRules:SetMissionTimer(Symbol("TimeAttack"), Symbol(Localize("/Lotus/Language/Game/KillEnemiesWithinTimeLimit", { COUNT = KILL_GOAL })), STARTING_TIME_LEFT, true, true)
    
    mTimerMgr:AddTimer(AI_SPAWN_TIME, SpawnFlyingAgent, true, true)  --spawn flying
    for i = 1, MAX_SIMUL_TARGETS do
        mTimerMgr:AddTimer(BONUS_SPAWN_TIME, Bonus, false)
    end
 
    mProgressBar = _T.AddHudTracker("TACProgressBar", LOTUS_UTIL.HT_PROGRESS_BAR, 0.2, false, false)
    mProgressBar.SetFlareColor(_G.UIColor_DarkBlue)
    mProgressBar.SetLabel("/Lotus/Language/Game/EnemyCount", 1)
    mProgressBar.SetGoalLabel(mKilltotal .. " / " .. KILL_GOAL)
    mProgressBar.SetValue(mKilltotal / KILL_GOAL)
    
    mArchwingPickups = gRegion:FindTagged(Symbol("ArchwingPickup"))
    
    while not IsNull(mGameRules) do
        
        mTimerMgr:Update(DeltaTime())
        
        --Challenge end conditions--
        if mKilltotal >= KILL_GOAL or mGameRules:GetMissionTimeLeft(Symbol("TimeAttack")) <= 0 then
            break
        elseif IsNull(mPlayerAv) or mPlayerAv:IsKilled() and not mIsRetrying then
            mIsRetrying = CROOM:PlayerRetry() 
            
            if mIsRetrying then
                mTimerMgr:AddTimer(2, Retry, false)
            else
                break
            end
        end
        
        for i, squad in ipairs(mSquads) do
            if squad.NumToSpawn > 0 then
                SpawnGroundAgent(squad)
            end
            
            if IsNull(squad.Target) then
                for k = #squad.Agents, 1, -1 do
                    local agent = squad.Agents[k]
                    if not IsNull(agent) then
                        local avatar = agent:GetAvatar()
                        if not gRegion:CanPlayersSeeEntity(avatar) and mPlayerAv:Distance2DToEntity(avatar) > 50 then
                            gRegion:CreateEntity(spawnEffect, avatar:GetPosition(), ZERO_ROTATION)
                            avatar:Destroy()
                            table.remove(squad.Agents, k)
                        end
                    end
                end
            end
        end
        
        Sleep(0)
    end
    
    local remainingAvatars = gRegion:FindAll(gLotusNpcAvatarType)
    for i, avatar in ipairs(remainingAvatars) do
        if not avatar:IsA(gLotusSentinelAvatarType) then
            avatar:Destroy()
        end
    end
    
    for i, pickup in ipairs(mArchwingPickups) do
        pickup:Destroy()
    end
    
    mPlayer:RemoveTimerOfInterest(Symbol("TimeAttack"))
    
    for i, bonus in ipairs(mBonusTargets) do
        bonus:Destroy()
    end
    
    
    if mKilltotal >= KILL_GOAL then
        LOTUS_UTIL.OnChallengePassed(mPlayerAv, kneelAnim, endMissionTrans, endMissionMovie, endMissionDialog)
    else
        CROOM.ChallengeFailed()
        mPlayerAv:GiveItem(failMissionTrans, true)
    end
end

function OnKilled(avatar)
    mKilltotal = mKilltotal + 1
    mProgressBar.SetGoalLabel(mKilltotal .. " / " .. KILL_GOAL)
    mProgressBar.SetValue(mKilltotal / KILL_GOAL)
    
    local killsLeft = KILL_GOAL - mKilltotal
    if math.mod(killsLeft, 5) == 0 then
        _T.ShowImpactMessage(killsLeft .. " " .. Localize("/Lotus/Language/Game/EnemiesRemaining", {}), 2, true, nil, false)
    elseif killsLeft == 1 then
        _T.ShowImpactMessage(killsLeft .. " " .. Localize("/Lotus/Language/Game/SingleEnemyRemaining", {}), 2, true, nil, false)
    end
    
    for i = #mSquads, 1, -1 do
        local squad = mSquads[i]
        TABLE.RemoveIfNil(squad.Agents)
        if #squad.Agents == 0 then
            table.remove(mSquads, i)
        end
    end
end

function OnDestroyed(destroyedBonus)
    local newTime = mGameRules:GetMissionTimeLeft(Symbol("TimeAttack")) + BONUS_TIME
    if newTime > MAX_TIME_LEFT then
        newTime = MAX_TIME_LEFT
    end
    mGameRules:SetMissionTimerValue(Symbol("TimeAttack"), newTime)
    mTimerMgr:AddTimer(BONUS_SPAWN_TIME, Bonus, false)
    TABLE.RemoveByElement(mBonusTargets, destroyedBonus)
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end

function OnPickedUp(player, item, pos, pickup)
    local attachments = pickup:GetAllAttachments(gDecorationType)
    for i, ent in ipairs(attachments) do
        ent:SetVisibility(false, true)
    end
    
    Sleep(3)
    for i, ent in ipairs(attachments) do
        ent:SetVisibility(true, true)
    end
end

