canisterAttachmentType = Type()
canisterDestroyedFx = Type()
radiusDecoType = Type()
canisterItemType = Type()
canisters = {Instance()}
backupAiSpec = Resource()
dialogTrigger = Instance()
endMissionMovie = WeakResource()
kneelAnim = Resource()
kneelIdleAnim = Resource()
standAnim = Resource()
spawnEffect = Resource()
projector = Resource()
invulnProjector = Resource()
endMissionTrans = Resource()
local pickupIcon = Resource("/Lotus/Interface/Icons/CanisterIconFull.png")

local UTIL = require "EE.Interface.Utilities"
local CROOM = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"
local POST = require "Lotus.Scripts.PostProcess.BasePostProcessFade"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local TABLE = require "Lotus.Scripts.Libs.TableLib"

local sInvuln = Symbol("Invuln")
local sRandomTeam = Symbol("RandomTeam")
local sFaction = Symbol("Challenge")

local killsLoc = "/Lotus/Language/Game/EnemyCount"
local progressLoc = "/Lotus/Language/Menu/ProgressXOfY"
local spawningCanisterLoc = "/Lotus/Language/Game/MasterySpawningCanister"
local canisterDestabilizingLoc = "/Lotus/Language/Game/MasteryDespawningCanister"
local cleanupLoc = "/Lotus/Language/EidolonPlains/ExterminateTimer"

local mAiDir = nil
local mPlayer = nil
local mPlayerAv = nil

local mTimerMgr = nil

local CANISTER_RADIUS = 15
local MAX_SPAWN = 25
local SPAWN_TIME = 2
local MIN_SQUAD_SIZE = 3
local MAX_SQUAD_SIZE = 7
local KILL_GOAL = 60
local CANISTER_SPAWN_DELAY = 10
local CANISTER_DESPAWN_DELAY = 20           --how long to wait before the canister self destructs
local CANISTER_DESTROYED_SPAWN_DELAY = 5    --how long to wait for spawning a canister if the last one was destroyed (aka unused by the player)
local CLEANUP_TIME = 15

local mEximusToSpawn = 0
local mNumAgentsToSpawn = 0
local mAgents = {}
local mSpawnPoints = {}
local mKillCount = 0
local mKillTracker = nil
local mTimerTracker = nil
local mPickupTracker = nil

local mMissionComplete = false
local mCanister = nil
local mPickedUp = false
local mLastTimer = nil
local mNumCanisters = 0
local mNumUsedCanisters = 0
local mSpawned = false
local mTestComplete = false

local function OnAgentSpawned(gameRules, agent)
    table.insert(mAgents, agent)
    local avatar = agent:GetAvatar()
    avatar:DamageControl():AddShieldHealthDamageModifier(sInvuln, Engine.DT_ANY, Engine.ANY_PART, Engine.DHT_NONE, 0)
    avatar:SetFaction(sFaction)
    agent:SetAlert()
end

local function SpawnDelay()
    if mAiDir:GetLiveAICount() < MAX_SPAWN then
        mEximusToSpawn = 1
        mNumAgentsToSpawn = RandomInt(MIN_SQUAD_SIZE, MAX_SQUAD_SIZE)
    end    
end

local function StartTimer(label, duration, callback)
    if mTimerMgr:HasTimer(mLastTimer) then
        mTimerMgr:RemoveTimer(mLastTimer)
    end
    mLastTimer = mTimerMgr:AddTimer(duration, callback, false)
    mTimerTracker.SetLabel(label)
    mTimerTracker.StartTimer(duration, false)
end


local function UpdateTrackers()
    mKillCount = math.min(KILL_GOAL, mKillCount)
    mKillTracker.SetLabel(killsLoc)
    mKillTracker.SetGoalLabel(mKillTracker.Localize(progressLoc, {CURRENT = mKillCount, TOTAL = KILL_GOAL}))
    mKillTracker.SetValue(mKillCount/KILL_GOAL)
    
    while IsNull(mPickupTracker.List["mElements"]) do
        Sleep(0)
    end
    for i = 1, mNumCanisters do
        local element = mPickupTracker.List.mElements[i]
        if i <= mNumUsedCanisters then
            element.Color = _G.UIColor_Red
        elseif i == mNumUsedCanisters + 1 and mSpawned then
            element.Color = _G.UIColor_White
        else
            break
        end
    end
    mPickupTracker.List:Redraw(nil, true)
end

local function EndTest()
    mTestComplete = true
end

local CanisterSpawn
local CanisterDestroy
CanisterSpawn = function()
    if #canisters == 0 then
        mMissionComplete = true
        return
    end
    mPickedUp = false
    Broadcast("Canister spawned")
    mCanister = canisters[1]
    table.remove(canisters, 1)
    mCanister:FirePort("Show")
    local marker = mCanister:GetAttachment(gBaseMarkerInfoType)
    marker:Enable()
    mSpawned = true
    UpdateTrackers()
    StartTimer(canisterDestabilizingLoc, CANISTER_DESPAWN_DELAY, CanisterDestroy)
end

CanisterDestroy = function()
    local avatar = mPlayer:GetAvatar()
    if not IsNull(mCanister) then
        gRegion:CreateEntity(canisterDestroyedFx, mCanister:GetPosition(), ZERO_ROTATION)
        mCanister:Destroy()
    elseif avatar:HasItem(canisterItemType) then
        local attachment = avatar:GetAttachment(canisterAttachmentType)
        gRegion:CreateEntity(canisterDestroyedFx, attachment:GetPosition(), ZERO_ROTATION)
        avatar:RemoveItem(canisterItemType)
        if not IsNull(_T.HideImpactMessage) then
            _T.HideImpactMessage()
        end
    end
    mNumUsedCanisters = mNumUsedCanisters + 1
    mSpawned = false
    UpdateTrackers()
    
    if mNumUsedCanisters < mNumCanisters then
        StartTimer(spawningCanisterLoc, CANISTER_DESTROYED_SPAWN_DELAY, CanisterSpawn)
    else
        StartTimer(cleanupLoc, CANISTER_DESTROYED_SPAWN_DELAY, EndTest)
    end
end

local function UpdateSpawning()
    local agent = nil
    local spawn = mSpawnPoints[RandomInt(1, #mSpawnPoints)]
    if mEximusToSpawn > 0 then
        mEximusToSpawn = mEximusToSpawn - 1
        agent = mAiDir:CreateRandomAgent(spawn, sRandomTeam, 0, nil, Engine.EXIMUS)
    elseif mNumAgentsToSpawn > 0 then
        mNumAgentsToSpawn = mNumAgentsToSpawn - 1
        agent = mAiDir:CreateRandomAgent(spawn, sRandomTeam, 0, nil, Engine.STANDARD)
    end
    
    if not IsNull(agent) then
        local avatar = agent:GetAvatar()
        CROOM.SetupEnemy(avatar, spawnEffect, invulnProjector)
        ObjectPortHandler(avatar, "OnKilled")
        table.insert(mAgents, agent)
    end
end

local function Init()
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    mPlayer = gRegion:GetLocalPlayer()
    mPlayerAv = mPlayer:GetAvatar()
    ObjectPortHandler(mPlayerAv, "OnKilled")
    
    mTimerMgr = TIMER.CreateTimerMgr()
    
    gGameRules:SetSaveMatchStatsDisabled(true)
    gGameRules:SetShowReviveScreenOnDeath(false)
    
    mAiDir:Enable(true)
    mAiDir:SetLevelAlert(true)
    mAiDir:SetObjective(mPlayerAv)
    if mAiDir:GetMinEnemyLevel() == 1 then
        mAiDir:SetEnemyLevelMinMax(45,55)
    end
    mAiDir:SetCustomSpawnSelectionFilter(10, 100, 0, 5, false, false, false)
    mAiDir:SetUseCustomSpawnSelectionFilter(true)
    mAiDir:SetEnableAutoSpawns(false)
    mAiDir:OrderNpcsStormTarget(mPlayer:GetAvatar(), 10)
    local aiList = gGameRules:GetMissionAI()
    if IsNull(aiList) then
        aiList = backupAiSpec:GetEnemies()
    end
    
    for i, enemy in ipairs(aiList) do
        mAiDir:AddMissionAIType(enemy.agent, enemy.probability, enemy.maxSimultaneous, enemy.tier)
    end
    
    mNumCanisters = #canisters
    mSpawnPoints = gRegion:FindAll(gNpcSpawnPointType)
    
    _T.OnAgentSpawnedCallback = OnAgentSpawned
    _T.CanisterDestroyed = function(projectile)
        local avatars = gRegion:FindRadiusEntities(projectile:GetPosition(), CANISTER_RADIUS, gLotusNpcAvatarType)
        if IsNull(avatars) then
            avatars = {}
        end
        
        local ragdolls = gRegion:FindRadiusEntities(projectile:GetPosition(), CANISTER_RADIUS, gHitProxyPhysicsType)
        for _, ragdoll in ipairs(ragdolls) do
            local avatar = ragdoll:GetAvatarOwner()
            if not IsNull(avatar) and not avatar:IsKilled() then
                table.insert(avatars, avatar)
            end
        end
        
        for _, avatar in ipairs(avatars) do
            avatar:DamageControl():RemoveShieldHealthDamageModifier(sInvuln)
            local attachments = avatar:GetAllAttachments(gDynamicProjectorType)
            for _, attachment in ipairs(attachments) do
                if attachment:IsA(invulnProjector) then
                    attachment:Destroy()
                end
            end
            avatar:PlayAbilityReactionAnim(Symbol("EXCALIBUR_BLIND"), false, Engine.ATMM_ANIMATION_HORIZ_PHYSICS_VERT, Engine.PRT_ONCE, true, RandomInt(0, 2))
            avatar:Attach(projector, EMPTY_SYMBOL)
        end
        local radiusDeco = gRegion:CreateEntity(radiusDecoType, projectile:GetPosition(), ZERO_ROTATION)
        radiusDeco:SetMeshScale(CANISTER_RADIUS)
        radiusDeco:PlayTriggeredFade()
    end
    _T.OnCanisterPickedUp = function()
        local hudMovie = gGameRules:GetHudMovieInstance()
        local avatar = mPlayer:GetAvatar()
        
        local inputFilter = nil
        if not IsNull(avatar) then
            inputFilter = avatar:GetInputFilter()
        end

        _T.ShowImpactMessage("/Lotus/Language/Items/AltFireToThrow", -1, nil, nil, nil, { ITEM = TitleCase(hudMovie:GetLocalized("/Lotus/Language/SolarisVenus/CondensedThemiaName", true)) }, nil, nil, nil, nil, inputFilter)
    end
    _T.OnDroppedGameplayObject = function(pickup)
        if not IsNull(_T.HideImpactMessage) then
            _T.HideImpactMessage()
        end
    end
    _T.OnCanisterThrown = function(projectile)
        if mTimerMgr:HasTimer(mLastTimer) then
            mTimerMgr:RemoveTimer(mLastTimer)
        end
        
        mNumUsedCanisters = mNumUsedCanisters + 1
        
        if mNumUsedCanisters < mNumCanisters then
            StartTimer(spawningCanisterLoc, CANISTER_SPAWN_DELAY, CanisterSpawn)
        else
            StartTimer(cleanupLoc, CLEANUP_TIME, EndTest)
        end
        
        mSpawned = false
        UpdateTrackers()
        if not IsNull(_T.HideImpactMessage) then
            _T.HideImpactMessage()
        end
        mPlayer:GetAvatar():InventoryControl():EquipBestWeapon(false)
    end
    _T.OnCanisterCreated = function(pickup)
        mCanister = pickup
    end
    
    mPickupTracker = _T.AddHudTracker("Pickups", LOTUS_UTIL.HT_ICON_BAR, nil, nil, false)
    for i=1, #canisters do
        mPickupTracker.AddIcon(pickupIcon, {Width = 32, Height = 32, Color = _G.UIColor_MediumGrey})
    end
    mPickupTracker.SetCustomDrawFunction(
        function(pMovie, pList, pElement)
            pMovie:SetVariable(pElement.mClipName, "_color", pElement.Color)
        end)
    mPickupTracker.List:Redraw()
    
    mKillTracker = _T.AddHudTracker("Kills", LOTUS_UTIL.HT_PROGRESS_BAR)
    mTimerTracker = _T.AddHudTracker("Timer", LOTUS_UTIL.HT_TIMER)
    UpdateTrackers()
    
    --mPlayer:GetAvatar():PlayNonReplicatedAnimation(standAnim, false, Engine.ATMM_ANIMATION_DRIVEN,Engine.PRT_ONCE, false)
    mTimerMgr:AddTimer(SPAWN_TIME, SpawnDelay, true)
    StartTimer(spawningCanisterLoc, 5, CanisterSpawn)
end

function CanisterChallenge()
    Sleep(1)
    Init()
    
    while not mTestComplete do
        Sleep(0)
        
        if IsNull(mPlayerAv) then
            mPlayerAv = mPlayer:GetAvatar()
            mAiDir:OrderNpcsStormTarget(mPlayer:GetAvatar(), 10)
            ObjectPortHandler(mPlayerAv, "OnKilled")
        end
        
        mTimerMgr:Update(DeltaTime())
        UpdateSpawning()
    end
    
    for _, agent in ipairs(mAgents) do
        if not IsNull(agent) then
            agent:GetAvatar():Destroy()
        end
    end
    
    if mMissionComplete then
        local playerAv = gRegion:GetLocalPlayerAvatar()
        LOTUS_UTIL.OnChallengePassed(playerAv, kneelAnim, endMissionTrans, endMissionMovie, dialogTrigger)
    else
        CROOM.ChallengeFailed()
    end
end

function OnCanisterPickedUp()
    _T.OnCanisterPickedUp()
end

function OnCanisterDestroyed(projectile)
    _T.CanisterDestroyed(projectile)
end

function OnKilled(avatar)
    if avatar == mPlayerAv then
        mTimerMgr:AddTimer(2, function() gGameRules:RespawnPlayer(mPlayer, false) end)
    else
        mKillCount = mKillCount + 1
        if mKillCount >= KILL_GOAL then
            mTestComplete = true
            mMissionComplete = true
        end
        UpdateTrackers()
        TABLE.RemoveIfNil(mAgents)
    end
end

function OnCanisterThrown(projectile)
    _T.OnCanisterThrown(projectile)
end

function OnCanisterCreated(pickup)
    if not IsNull(_T.OnCanisterCreated) then
        _T.OnCanisterCreated(pickup)
    end
end