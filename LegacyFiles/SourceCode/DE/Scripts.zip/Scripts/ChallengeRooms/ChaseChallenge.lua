endMissionDialog = Instance()

local CROOM = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local SPAWN = require "Lotus.Scripts.Libs.SpawnLib"

local chaseBeaconType = WeakResource("/Lotus/Types/Gameplay/MasteryChallenge/ChaseBeacon")
local backupAiSpec = Resource("/Lotus/Types/Game/EnemySpecs/RaidBombingRunGrineerSquadOne")
local enemyProjectorFX = Type("/Lotus/Fx/Projectors/ChamberEnemyGlow")
local spawnEffect = Resource("/Lotus/Fx/Explosions/DefaultExplosionDistortion")
local failMissionTrans = Resource("/Lotus/Sounds/Lotus/Dojo/LotusDojoGenericFailureTransmission")
local successTrans = Type("/Lotus/Sounds/Lotus/Dojo/LotusDojoGenericSuccessTransmission")
local endMissionMovie = Resource("/Lotus/Interface/EndOfMatch.swf")
local kneelAnim = Resource("/Lotus/Animations/Tenno/Emotes/Generic/StandToKneel_anim.fbx")

local captureProgressLoc = "/Lotus/Language/Dojo/ChaseChallengeProgress"
local timerLoc = "/Lotus/Language/Game/CapturePointsWithinTimeLimit"

local timerSym = Symbol("TimeLimit")

local npcMgr = gRegion:GetNpcMgr()
local aiDir = npcMgr:GetAiDirector()
local gameRules = gGameRules

local mPlayerAv = nil
local mPlayer = nil

local mBeaconData = {}
local mDrainRate = 12
local mCaptureRate = 6
local mTimeLimit = 300
local mCaptureRotSpeed = Rotation()
local mCaptureColor = Color(0, 255, 0)
local mCaptureCount = 0
local mBackupMinLevel = 40
local mBackupMaxLevel = 50

local completeSound = Resource("/Lotus/Sounds/Ambience/Tenno/Gameplay/ChaseChallengeNodeComplete")

--AI balance
local maxAi = 15
local maxSourceAi = 15
local maxAiSpawn = 5
local minDist = 10
local spawnDelay = 5

local mTimerMgr = nil
local mRetryTimerId = nil

local Retry = function()
    mRetryTimerId = nil
    gameRules:RespawnPlayer(mPlayer, false)
    mPlayerAv = mPlayer:GetAvatar()
    aiDir:OrderNpcsStormTarget(mPlayerAv)
end

function OnTouched(trigger)
    local index = trigger:GetAttachParent():GetFullName()
    local touchLoopSequencer = gRegion:FindTagged(Symbol("TouchLoop"))
    mBeaconData[index].Touching = true
    _T.ShowImpactMessage(Localize(captureProgressLoc, { PROGRESS = string.format("%.0f", mBeaconData[index].Progress) }), -1, true, nil, false)

    if mBeaconData[index].Progress < 100 then
        for i = 1, #touchLoopSequencer do
            if not IsNull(touchLoopSequencer[i]) then
                touchLoopSequencer[i]:Enable()
            end
        end
    end

end

function OnUntouched(trigger)
    local touchLoopSequencer = gRegion:FindTagged(Symbol("TouchLoop"))
    mBeaconData[trigger:GetAttachParent():GetFullName()].Touching = false
    _T.HideImpactMessage()

     for i = 1, #touchLoopSequencer do
        if not IsNull(touchLoopSequencer[i]) then
            touchLoopSequencer[i]:Disable()
        end
    end
end

function RunChallenge()
    local TimerLib = require "Lotus.Interface.Libs.TimerMgr"
    mTimerMgr = TimerLib.CreateTimerMgr()

    local beacons = gRegion:FindAll(chaseBeaconType)
    for i, beacon in ipairs(beacons) do
        local trigger = beacon:GetAttachment(gTriggerType)
        ObjectPortHandler(trigger, "OnTouched")
        ObjectPortHandler(trigger, "OnUntouched")
        
        local data = {}
        data.Progress = 0
        data.Touching = false
        data.Mover = beacon
        data.Marker = beacon:GetAttachment(gBaseMarkerInfoType)
        data.Beacon = beacon:GetAttachment(WeakResource("/Lotus/Types/Gameplay/MasteryChallenge/ChaseBeaconDeco"))
        data.RotationSpeed = data.Beacon:GetTestRotateSpeed()
        
        mBeaconData[beacon:GetFullName()] = data
    end
    
    gameRules:SetSaveMatchStatsDisabled(true)
    gameRules:SetShowReviveScreenOnDeath(false)
    gameRules:SetMissionTimer(timerSym, Symbol(timerLoc), mTimeLimit, false, true)
    
    mPlayer = gRegion:GetLocalPlayer()
    mPlayerAv = mPlayer:GetAvatar()
    mPlayer:AddTimerOfInterest(timerSym)
    
    local SetupFunc = function(agent)
        CROOM.SetupEnemy(agent:GetAvatar(), spawnEffect, enemyProjectorFX)
    end
    
    CROOM.SetMaxAttempts(3)
    
    local spawnSources = gRegion:FindAll(WeakResource("/Lotus/Types/Game/Waypoints/SpawnSource"))
    SPAWN.Initialize(spawnSources)    
    SPAWN.SetSource(spawnSources[1])
    SPAWN.SetMaxAi(maxAi)
    SPAWN.SetMaxSourceAi(maxSourceAi)
    SPAWN.SetMaxAiSpawn(maxAiSpawn)
    SPAWN.SetSpawnDelay(spawnDelay)
    SPAWN.SetMinSpawnDistance(minDist)
    SPAWN.SetFaction(Symbol("Grineer"))
    SPAWN.EnableSpawning(true)
    SPAWN.RunOnAgent(SetupFunc)
    
    local missionInfo = gameRules:GetMission()
    aiDir:Enable(true)
    aiDir:SetObjective(spawnSources[1])
    aiDir:SetLevelAlert(true)
    aiDir:SetEnableAutoSpawns(false)
    aiDir:OrderNpcsStormTarget(mPlayerAv)
    
    local aiList = gameRules:GetMissionAI()
    if IsNull(aiList) then
        aiList = backupAiSpec:GetEnemies()
        aiDir:SetEnemyLevelMinMax(mBackupMinLevel, mBackupMaxLevel)
    else
        aiDir:SetEnemyLevelMinMax(missionInfo.minEnemyLevel, missionInfo.maxEnemyLevel)
    end
    
    for i, enemy in ipairs(aiList) do
        aiDir:AddMissionAIType(enemy.agent, enemy.probability, enemy.maxSimultaneous, enemy.tier)
    end
    
    local completed = false
    local failed = false
    
    while not completed and not failed do
        if IsNull(mPlayerAv) or mPlayerAv:IsKilled() and IsNull(mRetryTimerId) then
            _T.HideImpactMessage()
            failed = not CROOM.PlayerRetry()
            if not failed then
                mRetryTimerId = mTimerMgr:AddTimer(2, Retry, false)
            else
                break
            end
        end
    
        for i, data in pairs(mBeaconData) do
            if data.Touching then
                if not IsNull(mRetryTimerId) then
                    data.Touching = false
                elseif data.Progress < 100 then
                    data.Progress = math.min(data.Progress + DeltaTime() * mCaptureRate, 100)
                    data.Beacon:SetTestRotateSpeed(LerpRotation(data.RotationSpeed, mCaptureRotSpeed, data.Progress / 100))
                    local newColor = Color(74, 74, 74):Lerp(mCaptureColor, data.Progress / 100)
                    data.Beacon:SetMaterialParam(Lotus_Game.EMISSIVE_TINT_COLOR, newColor.red / 255, newColor.green / 255, newColor.blue / 255)
                    
                    if data.Progress >= 100 then
                        mCaptureCount = mCaptureCount + 1
                        data.Mover:StopMovement()
                        data.Marker:Disable()
                        _T.HideImpactMessage()

                        local touchLoopSequencer = gRegion:FindTagged(Symbol("TouchLoop"))
                        data.Mover:PlaySound(completeSound,false)
                        for i = 1, #touchLoopSequencer do
                            if not IsNull(touchLoopSequencer[i]) then
                                touchLoopSequencer[i]:Disable()
                            end
                        end
                    end
                    
                    _T.ShowImpactMessage(Localize(captureProgressLoc, { PROGRESS = string.format("%.0f", data.Progress) }), -1, true, nil, false)
                end
            end
            
            if not data.Touching and data.Progress < 100 then
                data.Progress = math.max(data.Progress - DeltaTime() * mDrainRate, 0)
            end
        end
        
        if mCaptureCount >= #beacons then
            completed = true
        elseif gameRules:GetMissionTimeLeft(timerSym) <= 0 then
            failed = true
        end

        SPAWN.Update()
        mTimerMgr:Update(DeltaTime())
    
        Sleep(0)
    end
    
    SPAWN.KillAllAgents()
    
    if completed then
        LOTUS_UTIL.OnChallengePassed(mPlayerAv, kneelAnim, successTrans, endMissionMovie, endMissionDialog)
    else
        CROOM.ChallengeFailed()
        mPlayerAv:GiveItem(failMissionTrans, true)
    end
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end
