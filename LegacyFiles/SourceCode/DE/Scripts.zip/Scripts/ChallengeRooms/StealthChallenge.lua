checkpointScripts = {Instance()}
resetPoints = {Instance()}
resetAnim = Resource()
allowedResets = 3
endMissionMovie = Resource()
endMissionDialog = Instance()
kneelAnim = Resource()
transmission = Type()
failTrans = Type()
delay = 0
enemyProjectorFX = Type()
spawnEffect = Resource()
mainSpawnControls = {Instance()}    --spawn controls that trigger the encounter
allSpawnControls = {Instance()}       --all spawn controls - used for cleanup

barrier = Instance()
cameraSpot = Instance()
idleAnim = Resource("/Lotus/Animations/Tenno/Movement/Unarmed/Idle_anim.fbx")

local CROOM = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"
local postFade = require "Lotus.Scripts.PostProcess.BasePostProcessFade"
local playerAv = gRegion:GetPlayerAvatar(0)
local aiDir = gRegion:GetNpcMgr():GetAiDirector()
local gameRules = gGameRules
local tries = 0

function RunChallenge()
    _T.gSpotted = false
    _T.gRsIndex = 1
    Sleep(0.1)
    _T.gChallengeComplete = false
    gameRules:SetSaveMatchStatsDisabled(true)
    aiDir:SetLevelAlert(false)
    aiDir:SetObjective(playerAv)
    aiDir:SetEnemyLevelMinMax(7, 8)
    playerAv:CameraControl():SetTransitionToCameraSpotTime(0)
    
    for i, spawnControl in ipairs(allSpawnControls) do
        ObjectPortHandler(spawnControl,"OnAgentCombat")
    end
    
    for i, checkpoint in ipairs(checkpointScripts) do
        ObjectPortHandler(checkpoint,"OnExecuted")
    end
    
    while tries < allowedResets and not _T.gChallengeComplete do
        Sleep(0)
    end
    
    if IsNull(playerAv) then
        playerAv = gRegion:GetPlayerAvatar(0)
    end
    
    if _T.gChallengeComplete then
        local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
        LOTUS_UTIL.OnChallengePassed(playerAv, kneelAnim, transmission, endMissionMovie, endMissionDialog)
    else
        playerAv:PlayNonReplicatedAnimation(kneelAnim, true, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_FREEZE, true)
        playerAv:GiveItem(failTrans, true)
        Sleep(3)
        CROOM.ChallengeFailed()
    end
end

function OnAgentCombat(entity)
    if IsNull(_T.ShowImpactMessage) then
        return
    end
    
    _T.gSpotted = true
    tries = tries + 1
    _T.ShowImpactMessage(Localize("/Lotus/Language/Game/Detected", nil), 5, true, nil, false)
    
    while playerAv:IsDoingFinisher() do
        Sleep(0)
    end
    
    playerAv:PlayNonReplicatedAnimation(kneelAnim, true, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_FREEZE, true)
    postFade.Fade(0,-1,2)
    playerAv:Teleport(resetPoints[_T.gRsIndex]:GetPosition())
    Sleep(1)
    
    --cleanup
    for i, spawnControl in ipairs(allSpawnControls) do
        spawnControl:FirePort("Remove Agents")
    end
    
    local avatars = gRegion:FindAll(gLotusNpcAvatarType)
    for i, avatar in ipairs(avatars) do
        if avatar:IsKilled() then
            while IsNull(avatar:GetRagdoll()) do
                Sleep(0)
            end
        end
    end
    
    local ragdolls = gRegion:FindAll(gRagdollType)
    for i, ragdoll in ipairs(ragdolls) do
        ragdoll:Destroy()
    end
    
    mainSpawnControls[_T.gRsIndex]:FirePort("Reset")
    playerAv:PlayAnimation(resetAnim, false, Engine.ATMM_ANIMATION_DRIVEN)
    postFade.Fade(-1,0,1)
    _T.gSpotted = false
    
    _T.ShowImpactMessage(Localize("/Lotus/Language/Game/AttemptsLeft", nil) .. ": " .. allowedResets - tries, 5, true, nil, false)
end

function OnKilled(agent)
    local av = agent:GetAvatar()
    agent:ReturnToAiControl()
    CROOM.SetupEnemy(av, spawnEffect, enemyProjectorFX)
end

function KillSentinel()
    local player = gRegion:GetLocalPlayerAvatar()
    
    if IsNull(player) then
        print("Player doesn't exist, was the script called too early?")
        return
    end
    
    local sentinel = player:InventoryControl():GetSentinel()
    
    if not IsNull(sentinel) then
        sentinel:Destroy()
    end
end

function Checkpoint()
    
    if _T.gSpotted then
       return
    end
    
    _T.gRsIndex = _T.gRsIndex + 1
    Sleep(2)
    cameraSpot:FirePort("Activate")
    Sleep(1)
    barrier:SetVisibility(false, true)
    barrier:SetPhysicsBehaviorAndRegister(nil)
    
end

function ChallengeComplete()
    if _T.gSpotted then
       return
    end
    
    _T.gChallengeComplete = true
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end

function CameraSpot(spot)
    local player = nil
    while IsNull(player) do
        Sleep(0)
        player = gRegion:GetLocalPlayerAvatar()
    end
    player = player:GetPlayer()
    local camCtrl = player:CameraControl()
    local minimap = player:GetMiniMap()
    
    while camCtrl:GetCameraSpot() ~= spot do
        Sleep(0)
    end
    
    if not IsNull(idleAnim) then
        minimap:Hide()
        player:GetAvatar():PlayAnimation(idleAnim, false, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_LOOP, true)
        Sleep(delay)
        player:GetAvatar():PlayAnimation(nil, false)
        minimap:Restore()
    end
end

