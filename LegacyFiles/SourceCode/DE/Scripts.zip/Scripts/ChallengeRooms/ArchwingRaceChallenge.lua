successTrans = Type()
endMissionMovie = Resource()
endMissionDialog = Instance()
goalTrigger = Instance()
ringFlythroughFx = Resource()
delay = 1
energyAmount = 0

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local playerAv = gRegion:GetPlayerAvatar(0)
local gameRules = gGameRules
local sTimer = Symbol("RaceTimer")


local ringTriggerType = WeakResource("/Lotus/Types/Gameplay/MasteryRank/RingTrigger")
local secondsMessage = "/Lotus/Language/Dojo/RaceIncreaseSeconds"

local initialTime = 10
local timeIncrease = 2

local goalTriggerHit = false

function OnTouched(trigger)
    if trigger:IsA(ringTriggerType) then
        gameRules:SetMissionTimerValue(sTimer, gameRules:GetMissionTimeLeft(sTimer) + timeIncrease)
        trigger:Disable()
        _T.ShowImpactMessage(secondsMessage, 1, true, nil, false, { SECONDS = timeIncrease })
        local parent = trigger:GetAttachParent()
        local effects = parent:GetAllAttachments(gDecorationType)
        for i, effect in ipairs(effects) do
            effect:Destroy()
        end
        gRegion:CreateEntity(ringFlythroughFx, parent:GetPosition(), ZERO_ROTATION)
    else
        goalTriggerHit = true
    end
end

function RunChallenge()

    _T.ShowImpactMessage("/Lotus/Language/Objectives/ArchwingRaceGo", 2, true, nil, false)
    
    ringFlythroughFx = ringFlythroughFx
    gameRules:SetSaveMatchStatsDisabled(true)
    gameRules:SetMissionTimer(sTimer, Symbol(), initialTime, true, true, false)
    playerAv:GetPlayer():AddTimerOfInterest(sTimer)    
    
    local triggers = gRegion:FindAll(ringTriggerType)
    for i, trigger in ipairs(triggers) do
        ObjectPortHandler(trigger, "OnTouched")
    end
    ObjectPortHandler(goalTrigger, "OnTouched")
    
    while gameRules:GetMissionTimeLeft(sTimer) > 0 and not goalTriggerHit do
        Sleep(0)
    end
    
    if not goalTriggerHit then
        gameRules:EndGame(Engine.GameRules_GS_FAILURE)
        return
    end
    
    if IsNull(playerAv) then
        playerAv = gRegion:GetPlayerAvatar(0)
    end
    
    gameRules:SetShouldStopMissionTimer(sTimer, true)
    LOTUS_UTIL.OnChallengePassed(playerAv, nil, successTrans, endMissionMovie, endMissionDialog)
end

function SetEnergy()
    Sleep(delay)
    local suit = playerAv:InventoryControl():GetActivePowerSuit()
    suit:SetEnergy(energyAmount)
end

function KillSentinel()
    local player = gRegion:GetLocalPlayerAvatar()
    
    if IsNull(player) then
        print("Player doesn't exist, was the script called too early?")
        return
    end
    
    local sentinel = player:InventoryControl():GetSentinel()
    
    if not IsNull(sentinel) then
        sentinel:Destroy()
    end
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end
