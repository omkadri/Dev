module(..., package.seeall)

local rankPromotedStr = "/Lotus/Language/ActivityFeed/ActivityFeedRankPromoted"

local rank1Loc = Localize("/Lotus/Language/Ranks/Rank1", nil)
local rank2Loc = Localize("/Lotus/Language/Ranks/Rank2", nil)
local rank3Loc = Localize("/Lotus/Language/Ranks/Rank3", nil)
local rank4Loc = Localize("/Lotus/Language/Ranks/Rank4", nil)
local rank5Loc = Localize("/Lotus/Language/Ranks/Rank5", nil)
local rank6Loc = Localize("/Lotus/Language/Ranks/Rank6", nil)
local rank7Loc = Localize("/Lotus/Language/Ranks/Rank7", nil)
local rank8Loc = Localize("/Lotus/Language/Ranks/Rank8", nil)
local rank9Loc = Localize("/Lotus/Language/Ranks/Rank9", nil)
local rank10Loc = Localize("/Lotus/Language/Ranks/Rank10", nil)
local rank11Loc = Localize("/Lotus/Language/Ranks/Rank11", nil)
local rank12Loc = Localize("/Lotus/Language/Ranks/Rank12", nil)
local rank13Loc = Localize("/Lotus/Language/Ranks/Rank13", nil)

local iconDirs = { "1_Initiate",
                    "2_SilverInitiate",
                    "3_GoldInitiate",
                    "4_Novice",
                    "5_SilverNovice",
                    "6_GoldNovice",
                    "7_Disciple",
                    "8_SilverDisciple",
                    "9_GoldDisciple",
                    "10_Seeker",
                    "11_SilverSeeker",
                    "12_GoldSeeker",
                    "13_Hunter",
                    "14_SilverHunter",
                    "15_GoldHunter",
                    "16_Eagle",
                    "17_SilverEagle",
                    "18_GoldEagle",
                    "19_Tiger",
                    "20_SilverTiger",
                    "21_GoldTiger",
                    "22_Dragon",
                    "23_SilverDragon",
                    "24_GoldDragon",
                    "25_Sage",
                    "26_SilverSage",
                    "27_GoldSage",
                    "28_Master",
                    "29_SilverMaster",
                    "30_GoldMaster" }      

local attemptsLeft       

return
{

SetMaxAttempts = function(totalAttempts)
    attemptsLeft = totalAttempts
end,

ChallengeFailed = function()
    local gameRules = gGameRules
    gameRules:EndGame(Engine.GameRules_GS_FAILURE,0)
end,

ChallengePassed = function(endMissionMovie, endMissionDialog, isPractise)
    local player = gRegion:GetLocalPlayer()
    if not IsNull(player) and not isPractise then
        gChallengeMgr:NotifyValue(player, Symbol("PLAYER_RANK_CHALLENGE_COMPLETE"), _G.TrainingMissionRank)
    end

    endMissionDialog:FirePort("Open")
    Sleep(3)
    if not isPractise then
        if _T.ShowNotification ~= nil and (_G.TrainingMissionRank % 2) == 0 then
        _T.ShowNotification(Localize("/Lotus/Language/Menu/Loadout_NewSlotUnlocked", {}), "LoadoutSlot")
        end

        if not IsNull(_G.TrainingMissionRank) and _G.TrainingMissionRank > 0 then --Challenge num set to -1 in all challenges by default until data driven correctly
            local playerProfile = gPlayerProfileMgr:GetPlayerProfile(0)
            local rankLocs = {rank1Loc, rank2Loc, rank3Loc, rank4Loc, rank5Loc, rank6Loc, rank7Loc, rank8Loc, rank9Loc, rank10Loc, rank11Loc, rank12Loc, rank13Loc}
        
            for i = 1, #rankLocs do
                if _G.TrainingMissionRank == i then
                    local rArgs = {}
                    rArgs["PLAYER_NAME"] = gPlayerProfileMgr:GetPlayerProfile(0):GetPlayerName()
                    local rankPromotedLoc = Localize(rankPromotedStr, rArgs)
                    playerProfile:PostActivityMessage(rankPromotedLoc .. " " .. rankLocs[i], iconDirs[i])
                end
            end    
        end
    else
        local endMissionInstance = gFlashMgr:FindMovie(endMissionMovie)
        if not IsNull(endMissionInstance) then
            endMissionInstance:Execute("AutoClose", "")
        end
    end
end,

SetupEnemy = function(avatar, spawnEffect, enemyProjectorFX)    
    if IsNull(avatar) then
        return
    end
    
    gRegion:CreateEntity(spawnEffect,avatar:GetPosition(), avatar:GetRotation())
    avatar:Attach(enemyProjectorFX, EMPTY_SYMBOL)
    local attachments = avatar:GetAllAttachments(gEntityType)
    for i, attachment in ipairs(attachments) do
        attachment:Attach(enemyProjectorFX, EMPTY_SYMBOL)
    end
    
    avatar:SetDropTable(nil)
end,

PlayerRetry = function()
    if attemptsLeft - 1 > 0 then
        attemptsLeft = attemptsLeft - 1
        if attemptsLeft ~= 1 then
            _T.ShowImpactMessage(attemptsLeft .. " " .. Localize("/Lotus/Language/Game/AttemptsLeft", {}), 2, true, nil, false)     --Localize
        else
            _T.ShowImpactMessage(attemptsLeft .. " " .. Localize("/Lotus/Language/Game/AttemptLeft", {}), 2, true, nil, false)     --Localize
        end
        return true
    else
        return false
    end
end,

AddAiTypes = function(backupAiSpec)
    local gameRules = gGameRules
    local aiList = gameRules:GetMissionAI()
    if IsNull(aiList) then
        aiList = backupAiSpec:GetEnemies()
    end
    
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    
    for i, enemy in ipairs(aiList) do
        aiDir:AddMissionAIType(enemy.agent, enemy.probability, enemy.maxSimultaneous, enemy.tier)
    end
end
}