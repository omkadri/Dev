resetPoints = {Instance()}
resetTrigger = Instance()
resetAnim = Resource()
allowedResets = 3
endChallengeCounter = Instance()
endChallengeValue = 1
endMissionMovie = Resource()
endMissionDialog = Instance()
kneelAnim = Resource()
transmission = Type()
hitProxyType = Type()

beamType = Resource()
firstTarget = Instance()
selectedMaterialSlot = 0
selectedMaterial = Resource()
adjacentMinDistance = 1
adjacentMaxDistance = 5
minIterations = 3
maxIterations = 5
beamDelay = 0.25
requiredTargetHits = {5,10}
maxVisibleBeams = 2     -- 0 for show all
timeLimits = {15,30}             --overall time limit (seconds)
targetTimeLimits = {3,2}     --time to hit target once marked (seconds) 
missedSound = Resource()
hitSound = Resource()
waves = 2

local cRoom = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"
local postFade = require "Lotus.Scripts.PostProcess.BasePostProcessFade"
local challengeRunning = true
local playerAv = gRegion:GetPlayerAvatar(0)
local targetHit = false
local currentTarget

local function Setup()
    _T.gCurrentRsPoint = 1
    _T.gCurrentResetCount = 0
    _T.gNumRsPoints = #resetPoints
    _T.gStage = 1
end

local function ResetLevel()
    
    local platforms = gRegion:FindTagged(Symbol("Platform"))
    for i = 1, #platforms do
        platforms[i]:SetVisibility(false,true)
        platforms[i]:FirePort("Beginning")
    end
    
    local triggers = gRegion:FindTagged(Symbol("Trigger"))
    for i = 1, #triggers do
        triggers[i]:Enable()
    end
    
    if _T.gStage > 1 then
        local targetTriggers = gRegion:FindTagged(Symbol("TargetTrigger"))
        for i = 1, #targetTriggers do
            targetTriggers[i]:Enable()
        end
        
        local beams = gRegion:FindTagged(Symbol("Beam"))
        for i = 1, #beams do
            beams[i]:FirePort("Disable")
        end
        
        local targets = gRegion:FindTagged(Symbol("Target"))
        for i = 1, #targets do
            targets[i]:SetVisibility(false,true)
            --targets[i]:SetHealth(targets[i]:GetDefaultHealth())
        end
    end
    
end

--if you fell off the platform, teleport to the current restart waypoint
local function ResetCheck()
    
    local entitiesTouching = resetTrigger:GetEntitiesTouching()
    
    for i = 1,#entitiesTouching do
        if entitiesTouching[i] == playerAv then
            postFade.Fade(0,-1,0.5)
            ResetLevel()
            playerAv:Teleport(resetPoints[_T.gCurrentRsPoint]:GetPosition(),resetPoints[_T.gCurrentRsPoint]:GetRotation())
            playerAv:PlayAnimation(resetAnim, false, Engine.ATMM_ANIMATION_DRIVEN)
            postFade.Fade(-1,0,2)
            _T.gCurrentResetCount = _T.gCurrentResetCount + 1
            if _T.gCurrentResetCount <= allowedResets then
                print("Resets left: " .. allowedResets - _T.gCurrentResetCount)
            end
            break
        end
    end
    
end

function RunChallenge()
    Setup()
    
    while challengeRunning do
    
        ResetCheck()
        
        if endChallengeCounter:GetCurrentValue() == endChallengeValue or _T.gCurrentResetCount > allowedResets then
            challengeRunning = false
        end
        
        Sleep(0)
    
    end
    
    if _T.gCurrentResetCount > allowedResets then
        
        print("Challenge Failed")
    end

end

function SetNextRestartWaypoint()
    if _T.gCurrentRsPoint < _T.gNumRsPoints then
        _T.gCurrentRsPoint = _T.gCurrentRsPoint + 1
    end
    
    _T.gCurrentResetCount = 0
end

function SetNextStage()
    _T.gStage = _T.gStage + 1
end

function OnDamaged(this)
    targetHit = true
    this:GetAttachParent():SetOverrideMaterial(selectedMaterialSlot,nil)
    this:Destroy()
end

local function PickNode(possiblePaths, currentPath)
    local found = false
    local nextNode
            
    while not found do
        found = true
        if #possiblePaths <= 0 then
            nextNode = nil
            break
        end
        local index = math.random(1,#possiblePaths)
        nextNode = possiblePaths[index]
        for j = 1,#currentPath do
            if currentPath[j] == nextNode then
                found = false
                table.remove(possiblePaths,index)
                break
            end
        end
        
        Sleep(0)
    end
    
    return nextNode
end

local function GetPossiblePaths(currentPath)
    local possiblePaths = gRegion:FindTaggedInRadius(Symbol("GroupTarget"),currentPath[#currentPath]:GetPosition(),adjacentMinDistance,adjacentMaxDistance)
    if #possiblePaths == 0 then
        print("ChallengeRoomRank1.lua::RandomTargets - couldn't find nearby targets")
        return nil
    end
    return possiblePaths
end

function RandomTargets()
    
    local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
    
    local gameRules = gGameRules
    local timer = _T.AddHudTracker("TargetChallengeTimer", LOTUS_UTIL.HT_TIMER, 0.25, false, false)
    
    for wave = 1,waves do
        gameRules:SetSaveMatchStatsDisabled(true)
        
        local args = {}
        local roundStart = Localize("/Lotus/Language/Game/Trial_RoundStart", args)
        timer.ShowMessage(roundStart .. " " .. wave, 5)
        timer.StartTimer(timeLimits[wave], false, false, true)
        local targetsHit = 0
        local beams = {}
        currentTarget = firstTarget
        local t = 0
        local targetTime = 0
        targetHit = false
        
        --quickly face player to the first target
        local lookRot = LookTo(playerAv:GetPosition(), firstTarget:GetPosition())
        local currentRot = playerAv:GetCameraView()
        
        while t < 0.2 do
            local newRot = LerpRotation(currentRot,lookRot,t/0.2)
            playerAv:SetCameraView(newRot)
            Sleep(0)
            t = t + DeltaTime()
        end
        
        t = 0

        while targetsHit < requiredTargetHits[wave] and t < timeLimits[wave] do
            
            currentTarget:SetOverrideMaterial(selectedMaterialSlot,selectedMaterial)
            local hitProxy = currentTarget:Attach(hitProxyType, EMPTY_SYMBOL)
            ObjectPortHandler(hitProxy, "OnDamaged")
            while not targetHit and targetTime < targetTimeLimits[wave] do
                Sleep(0)
                t = t + DeltaTime()
                targetTime = targetTime + DeltaTime()
                if t > timeLimits[wave] then
                    for i = 1,#beams do
                        beams[i]:Destroy()
                    end
                    cRoom.ChallengeFailed()
                    return
                end
            end
            if targetTime < targetTimeLimits[wave] then
                targetsHit = targetsHit + 1
                currentTarget:PlaySound(hitSound,false)
            else
                print("Target Missed, Finding a new Target")
                currentTarget:PlaySound(missedSound,false)
                currentTarget:SetOverrideMaterial(selectedMaterialSlot,nil)
                hitProxy:Destroy()
            end
            targetTime = 0
            
            for i = 1,#beams do
                beams[i]:Destroy()
            end
            beams = {}
            
            if targetsHit >= requiredTargetHits[wave] then
                break
            end
           
            local currentPath = {currentTarget}
            local iterations = math.random(minIterations,maxIterations)
            for i = 1,iterations do
            
                local possiblePaths = GetPossiblePaths(currentPath)
                local nextNode = PickNode(possiblePaths, currentPath)
                
                if IsNull(nextNode) then
                    break
                end
                
                local prevNode = currentPath[#currentPath]
                table.insert(currentPath,nextNode)
                
                --draw beam between next and prev
                local beam = gRegion:CreateEntity(beamType, prevNode:GetPosition(), ZERO_ROTATION)
                table.insert(beams,beam)
                
                beam:SetEndPoint(nextNode:GetPosition())
                beam:FirePort("Enable")
                if maxVisibleBeams > 0 and #beams > maxVisibleBeams then
                    beams[1]:Destroy()
                    table.remove(beams,1)
                end
                
                if i < iterations then
                    Sleep(beamDelay)
                    t = t + beamDelay
                end
                
            end
            
            if t > timeLimits[wave] then
                cRoom.ChallengeFailed()
            end
            
            currentTarget = currentPath[#currentPath]
            targetHit = false
            Sleep(0)
        end
        
        currentTarget = nil
        timer.SetPaused(true)
        Sleep(0)
        local waveDelay = 10
        if wave == waves then
            waveDelay = 5
        end
        
        local args = {}
        local roundEndRound = Localize("/Lotus/Language/Game/Trial_RoundEndRound", args)
        local roundEndComplete = Localize("/Lotus/Language/Game/Trial_RoundEndComplete", args)
        
        timer.SetPaused(false)
        timer.ShowMessage(roundEndRound .. " " .. wave .. " " .. roundEndComplete, 5)
        timer.StartTimer(waveDelay, false)
        Sleep(waveDelay)
    end
    
    LOTUS_UTIL.OnChallengePassed(playerAv, kneelAnim, transmission, endMissionMovie, endMissionDialog)
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end
