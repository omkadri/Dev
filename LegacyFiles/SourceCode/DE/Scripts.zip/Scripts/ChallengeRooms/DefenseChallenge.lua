endMissionMovie = Resource()
endMissionDialog = Instance()
kneelAnim = Resource()
endMissionTrans = Type()
failMissionTrans = Type()
waveGoal = { 5, 10, 15 }
maxSpawned = 6
spawnDelay = 3
waveDelay = 5
enemyProjectorFX = Type()
spawnEffect = Resource()
backupAiSpec = Resource()
defenseSpawn = Instance()
waveCompleteForwarders = {Instance()}

local CROOM = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local waveCompleted = "/Lotus/Language/Game/WaveComplete"
local wavesCompleted = "/Lotus/Language/Challenges/Challenge_Completed"
local waveIncoming = "/Lotus/Language/Game/WaveXIncoming"

local aiDir = gRegion:GetNpcMgr():GetAiDirector()
local gameRules = gGameRules
local killTotal = 0
local wave = 1
local playerAv = gRegion:GetLocalPlayerAvatar()
local player = playerAv:GetPlayer()
local retrying = false

local mTimerMgr = nil
local mSpawnTimerId = nil

local Retry = function()
    retrying = false
    gameRules:RespawnPlayer(player, false)
    playerAv = player:GetAvatar()
end

local SpawnDelay = function()
    local liveCount = aiDir:GetLiveAICount()
    if liveCount < maxSpawned and killTotal + liveCount < waveGoal[wave] then
        local agent = aiDir:CreateRandomAgent(nil, Symbol("Enemy"))
        if IsNull(agent) then
            print("Failed to create random agent")
        else
            CROOM.SetupEnemy(agent:GetAvatar(), spawnEffect, enemyProjectorFX)
            ObjectPortHandler(agent:GetAvatar(), "OnKilled")
        end
    end 
end

local WaveDelay = function()
    mSpawnTimerId = mTimerMgr:AddTimer(spawnDelay, SpawnDelay, true)
    _T.ShowImpactMessage(Localize(waveIncoming, {WAVENUM = wave}), 5, true, nil, false)
    aiDir:SetCurrentTier(wave - 1, false)
end

function RunChallenge()
    
    local TimerLib = require "Lotus.Interface.Libs.TimerMgr"
    mTimerMgr = TimerLib.CreateTimerMgr()

    gameRules:SetSaveMatchStatsDisabled(true)
    gameRules:SetShowReviveScreenOnDeath(false)
    
    CROOM.SetMaxAttempts(3)

    aiDir:Enable(true)
    aiDir:SetEnableAutoSpawns(false)
    aiDir:SetLevelAlert(true)
    aiDir:SetObjective(playerAv)
    aiDir:SetEnemyLevelMinMax(25,30)
    aiDir:SetCustomSpawnSelectionFilter(10, 100, 0, 5, false, false, false)
    aiDir:SetUseCustomSpawnSelectionFilter(true)
    local aiList = gameRules:GetMissionAI()
    if IsNull(aiList) then
        aiList = backupAiSpec:GetEnemies()
    end
    
    for i, enemy in ipairs(aiList) do
        aiDir:AddMissionAIType(enemy.agent, enemy.probability, enemy.maxSimultaneous, enemy.tier)
    end
    
    Sleep(0)    --wait a frame for ai director to init before we try to spawn enemies (hits a debug crash otherwise)
    
    local defenseAvatar = defenseSpawn:GetActiveAvatar()
    while IsNull(defenseAvatar) do
        Sleep(0)
        defenseAvatar = defenseSpawn:GetActiveAvatar()
    end
    
    gameRules:SetDefenseModeTarget(defenseAvatar)
    local tracker = _T.AddHudTracker("DefenseTarget", LOTUS_UTIL.HT_HEALTH_TRACKER, 0.15, false, false)
    tracker.SetTarget(defenseAvatar)
    tracker.SetHealthWarningThreshold(20, false)
    
    CROOM.SetupEnemy(defenseAvatar, spawnEffect, enemyProjectorFX)
    aiDir:OrderNpcsStormTarget(defenseAvatar)
    local totalWaves = #waveGoal
    local lastWave = 0
    
    local progressBar = nil
    
    while not IsNull(gameRules) do
        
        mTimerMgr:Update(DeltaTime())
        if lastWave ~= wave then
            if wave <= totalWaves then
                mTimerMgr:AddTimer(waveDelay, WaveDelay, false)
                mTimerMgr:RemoveTimer(mSpawnTimerId)
            end
            if lastWave > 0 then
                _T.ShowImpactMessage((Localize(waveCompleted, {WAVENUM = lastWave})), 5, true, nil, false)
                if not IsNull(waveCompleteForwarders[lastWave]) then
                    waveCompleteForwarders[lastWave]:FirePort("TriggerPort")
                end
            end
            if IsNull(progressBar) then
                progressBar = _T.AddHudTracker("DefenseChallengeProgressBar", LOTUS_UTIL.HT_PROGRESS_BAR, 0.5, false, false)
                progressBar.SetFlareColor(_G.UIColor_DarkBlue)
                progressBar.SetLabel(wavesCompleted, 1)
            end
            progressBar.SetGoalLabel(wave - 1 .. " / " .. totalWaves)
            progressBar.SetValue((wave - 1) / totalWaves)
            lastWave = wave
            killTotal = 0
        end
    
        if wave > totalWaves or IsNull(defenseAvatar) or defenseAvatar:IsKilled() then
            break
        elseif killTotal >= waveGoal[wave] then
            wave = wave + 1
        elseif IsNull(playerAv) or playerAv:IsKilled() and not retrying then
            retrying = CROOM:PlayerRetry() 
            
            if retrying then
                mTimerMgr:AddTimer(2, Retry, false)
            else
                break
            end
        end
        
        Sleep(0)
    end
    
    local remainingAvatars = gRegion:FindAll(gLotusNpcAvatarType)
    for i, avatar in ipairs(remainingAvatars) do
        if not avatar:IsA(gLotusSentinelAvatarType) and avatar ~= defenseAvatar then
            avatar:Destroy()
        end
    end
    
    if wave >= totalWaves and not IsNull(defenseAvatar) and not defenseAvatar:IsKilled() then
        local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
        LOTUS_UTIL.OnChallengePassed(playerAv, kneelAnim, endMissionTrans, endMissionMovie, endMissionDialog)
    else
        CROOM.ChallengeFailed()
        playerAv:GiveItem(failMissionTrans, true)
    end
end

function OnKilled(avatar)
    killTotal = killTotal + 1
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end
