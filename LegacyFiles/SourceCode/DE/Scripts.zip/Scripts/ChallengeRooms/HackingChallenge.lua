timeLimit = 60
actionList = {Instance()}

endTransmission = Resource()
endMissionMovie = Resource()
endMissionDialog = Instance()

lockedMaterial = Resource()
unlockedMaterial = Resource()

kneelAnim = Resource()

local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local panicLight = WeakResource("/Lotus/Types/Actions/PanicLight")

local hackConsolesLoc = "/Lotus/Language/Game/ConsoleHackTimeLimit"

local timer = nil

--[[
      A[1]
        |
       /\
  C[3]  B[2]
]]


local function EndChallenge()
    local playerAvatar = gRegion:GetPlayerAvatar(0)
    
    _T.RemoveHudTracker(timer)
    LOTUS_UTIL.OnChallengePassed(playerAvatar, kneelAnim, endTransmission, endMissionMovie, endMissionDialog, 5)
end

local function SetEnableConsoleFx(action, enable)
    local panicLights = action:GetAllAttachments(panicLight)
    local consoleDecos = action:GetAllAttachments(gDecorationType)
    if enable then
        panicLights[1]:TurnOn()
        consoleDecos[1]:SetOverrideMaterial(1, lockedMaterial)
    else
        panicLights[1]:TurnOff()
        consoleDecos[1]:SetOverrideMaterial(1, unlockedMaterial)
    end
end

function StartChallenge()

    local gameRules = gGameRules
    
    gameRules:SetSaveMatchStatsDisabled(true)
    --gameRules:SetPanicButtonMarkersEnabled(true)
    timer = _T.AddHudTracker("HackingChallengeTimer", LOTUS_UTIL.HT_TIMER, 0.25, false, false)
    timer.ShowMessage(hackConsolesLoc, 5)
    timer.StartTimer(timeLimit, false, true, true)
    _T.hackingTutorialOverride = 2
    
    for i, action in ipairs(actionList) do
        action:Enable()
        SetEnableConsoleFx(action, true)
        while action:IsEnabled() do
            Sleep(0)
        end
        SetEnableConsoleFx(action, false)
        _T.hackingTutorialOverride = UTIL.Ternary(_T.hackingTutorialOverride > 3, 2, _T.hackingTutorialOverride + 1)
        
    end
    
    EndChallenge()

end

function PanicButtonOverride(avatar, result, button)

    if IsNull(avatar) then
        return
    end
    
    if result == 1 then
        button:Disable()
    end

end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end
