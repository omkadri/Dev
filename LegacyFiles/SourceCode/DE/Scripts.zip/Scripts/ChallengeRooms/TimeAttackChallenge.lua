endMissionMovie = Resource()
endMissionDialog = Instance()
kneelAnim = Resource()
endMissionTrans = Type()
failMissionTrans = Type()
killGoal = 50
maxSpawned = 7
spawnDelay = 2
startTime = 20
maxTime = 30
bonusTime = 10
bonusSpawnTime = 10
bonusEntity = Type()
enemyProjectorFX = Type()
spawnEffect = Resource()
waypoints = {Instance()}
backupAiSpec = Resource()

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local CROOM = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"

local aiDir = gRegion:GetNpcMgr():GetAiDirector()
local gameRules = gGameRules
local killTotal = 0
local playerAv = gRegion:GetLocalPlayerAvatar()
local player = playerAv:GetPlayer()
local retrying = false
local bonus
local usedWaypoints = {}

local mTimerMgr = nil

local SpawnDelay = function()
    if aiDir:GetLiveAICount() < maxSpawned then
        local agent = aiDir:CreateRandomAgent(nil, Symbol("Enemy"))
        if IsNull(agent) then
            print("Failed to create random agent")
        else
            CROOM.SetupEnemy(agent:GetAvatar(), spawnEffect, enemyProjectorFX)
            ObjectPortHandler(agent:GetAvatar(), "OnKilled")
        end
    end
end

local Retry = function()
    retrying = false
    gameRules:RespawnPlayer(player, false)
    playerAv = player:GetAvatar()
end

local Bonus = function()
    if IsNull(bonus) then
        local index
        local waypoint = nil
        local failed = {}
        local distToPlayer = 0
            
        while distToPlayer < 3 do
            if #waypoints == 0 then
                waypoints = usedWaypoints
                usedWaypoints = {}
            end
            
            index = RandomInt(1, #waypoints)
            waypoint = waypoints[index]
            table.insert(usedWaypoints, waypoint)
            table.remove(waypoints, index)
                
            distToPlayer = waypoint:DistanceToEntity(playerAv)
        end
            
        for i, point in ipairs(failed) do
            table.insert(waypoints, point)
        end
            
        bonus = gRegion:CreateEntity(bonusEntity, waypoint:GetPosition(), waypoint:GetRotation())
        ObjectPortHandler(bonus, "OnDestroyed")
    end
end

function RunChallenge()
    
    local TimerLib = require "Lotus.Interface.Libs.TimerMgr"
    mTimerMgr = TimerLib.CreateTimerMgr()
    
    gameRules:SetSaveMatchStatsDisabled(true)
    gameRules:SetShowReviveScreenOnDeath(false)
    
    CROOM.SetMaxAttempts(3)
    
    local prevKills = killGoal
    bonusTime = bonusTime   --hack to expose bonusTime in editor (needs to be referenced in main function)
    maxTime = maxTime
    
    aiDir:Enable(true)
    aiDir:SetLevelAlert(true)
    aiDir:SetObjective(playerAv)
    aiDir:SetEnemyLevelMinMax(25,30)
    aiDir:SetCustomSpawnSelectionFilter(10, 100, 0, 5, false, false, false)
    aiDir:SetUseCustomSpawnSelectionFilter(true)
    aiDir:SetEnableAutoSpawns(false)
    local aiList = gameRules:GetMissionAI()
    if IsNull(aiList) then
        aiList = backupAiSpec:GetEnemies()
    end
    
    for i, enemy in ipairs(aiList) do
        aiDir:AddMissionAIType(enemy.agent, enemy.probability, enemy.maxSimultaneous, enemy.tier)
    end
    
    Sleep(0)    --wait a frame for ai director to init before we try to spawn enemies (hits a debug crash otherwise)
    
    playerAv:GetPlayer():AddTimerOfInterest(Symbol("TimeAttack"))
    gameRules:SetMissionTimer(Symbol("TimeAttack"), Symbol(Localize("/Lotus/Language/Game/KillEnemiesWithinTimeLimit", { COUNT = killGoal })), startTime, true, true)
    
    mTimerMgr:AddTimer(spawnDelay, SpawnDelay, true)
    mTimerMgr:AddTimer(bonusSpawnTime, Bonus, false)
    
    local progressBar = nil
    while not IsNull(gameRules) do
        
        mTimerMgr:Update(DeltaTime())
        
        if killTotal <= killGoal then
            if IsNull(progressBar) then
                progressBar = _T.AddHudTracker("TACProgressBar", LOTUS_UTIL.HT_PROGRESS_BAR, 0.2, false, false)
                progressBar.SetFlareColor(_G.UIColor_DarkBlue)
                progressBar.SetLabel("/Lotus/Language/Game/EnemyCount", 1)
            end
            progressBar.SetGoalLabel(killTotal .. " / " .. killGoal)
            progressBar.SetValue(killTotal / killGoal)
        end
        
        --Challenge end conditions--
        if killTotal >= killGoal or gameRules:GetMissionTimeLeft(Symbol("TimeAttack")) <= 0 then
            break
        elseif IsNull(playerAv) or playerAv:IsKilled() and not retrying then
            retrying = CROOM:PlayerRetry() 
            
            if retrying then
                mTimerMgr:AddTimer(2, Retry, false)
            else
                break
            end
        end
        
        local killsLeft = killGoal - killTotal
        if math.mod(killsLeft, 5) == 0 and prevKills ~= killsLeft then
            _T.ShowImpactMessage(killsLeft .. " " .. Localize("/Lotus/Language/Game/EnemiesRemaining", {}), 2, true, nil, false)
        elseif killsLeft == 1 and prevKills ~= killsLeft then
            _T.ShowImpactMessage(killsLeft .. " " .. Localize("/Lotus/Language/Game/SingleEnemyRemaining", {}), 2, true, nil, false)
        end
        prevKills = killsLeft
        
        Sleep(0)
    end
    
    local remainingAvatars = gRegion:FindAll(gLotusNpcAvatarType)
    for i, avatar in ipairs(remainingAvatars) do
        if not avatar:IsA(gLotusSentinelAvatarType) then
            avatar:Destroy()
        end
    end
    
    playerAv:GetPlayer():RemoveTimerOfInterest(Symbol("TimeAttack"))
    if not IsNull(bonus) then
        bonus:Destroy()
    end
    
    if killTotal >= killGoal then
        LOTUS_UTIL.OnChallengePassed(playerAv, kneelAnim, endMissionTrans, endMissionMovie, endMissionDialog)
    else
        CROOM.ChallengeFailed()
        playerAv:GiveItem(failMissionTrans, true)
    end
end

function OnKilled(avatar)
    killTotal = killTotal + 1
end

function OnDestroyed()
    local newTime = gameRules:GetMissionTimeLeft(Symbol("TimeAttack")) + bonusTime
    if newTime > maxTime then
        newTime = maxTime
    end
    gameRules:SetMissionTimerValue(Symbol("TimeAttack"), newTime)
    mTimerMgr:AddTimer(bonusSpawnTime, Bonus, false)
    --play sound?
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end
