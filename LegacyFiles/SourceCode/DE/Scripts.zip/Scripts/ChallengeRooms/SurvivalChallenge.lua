resetPoints = {Instance()}
resetTrigger = Instance()
resetAnim = Resource()
allowedResets = 3
endMissionMovie = Resource()
endMissionDialog = Instance()
kneelAnim = Resource()
transmission = Type()

timeLimit = 60
waveTimes = {20,40}
maxSpawned = {3,5,7}
spawnDelay = {1,1,1}
meleeTypes = {Type()}
rangedTypes = {Type()}
miscTypes = {Type()}
spawnPoints = {Instance()}
enemyProjectorFX = Type()
spawnEffect = Resource()
spawnPointReuseCount = 3

local CROOM = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"
local postFade = require "Lotus.Scripts.PostProcess.BasePostProcessFade"
local playerAv = gRegion:GetPlayerAvatar(0)
local npcMgr = gRegion:GetNpcMgr()
local aiDir = gRegion:GetNpcMgr():GetAiDirector()
local team = Symbol("RandomTeam")
local gameRules = gGameRules
local usedPoints = {}

local function Setup()
    _T.gCurrentRsPoint = 1
    _T.gCurrentResetCount = 0
    _T.gNumRsPoints = #resetPoints
    _T.gStage = 1
end

local function ResetLevel()
    
    local platforms = gRegion:FindTagged(Symbol("Platform"))
    for i = 1, #platforms do
        platforms[i]:SetVisibility(false,true)
        platforms[i]:FirePort("Beginning")
    end
    
    local triggers = gRegion:FindTagged(Symbol("Trigger"))
    for i = 1, #triggers do
        triggers[i]:Enable()
    end
    
    if _T.gStage > 1 then
        local targetTriggers = gRegion:FindTagged(Symbol("TargetTrigger"))
        for i = 1, #targetTriggers do
            targetTriggers[i]:Enable()
        end
        
        local beams = gRegion:FindTagged(Symbol("Beam"))
        for i = 1, #beams do
            beams[i]:FirePort("Disable")
        end
        
        local targets = gRegion:FindTagged(Symbol("Target"))
        for i = 1, #targets do
            targets[i]:SetVisibility(false,true)
            --targets[i]:SetHealth(targets[i]:GetDefaultHealth())
        end
    end
    
end

--if you fell off the platform, teleport to the current restart waypoint
local function ResetCheck()
    
    local entitiesTouching = resetTrigger:GetEntitiesTouching()
    
    if IsNull(playerAv) then
        playerAv = gRegion:GetPlayerAvatar(0)
    end
    
    for i = 1,#entitiesTouching do
        if entitiesTouching[i] == playerAv then
            postFade.Fade(0,-1,0.5)
            ResetLevel()
            playerAv:Teleport(resetPoints[_T.gCurrentRsPoint]:GetPosition(),resetPoints[_T.gCurrentRsPoint]:GetRotation())
            playerAv:PlayAnimation(resetAnim, false, Engine.ATMM_ANIMATION_DRIVEN)
            postFade.Fade(-1,0,2)
            _T.gCurrentResetCount = _T.gCurrentResetCount + 1
            if _T.gCurrentResetCount <= allowedResets then
                print("Resets left: " .. allowedResets - _T.gCurrentResetCount)
            end
            break
        end
    end
    
end

local function SetupEnemyVisuals(entity)
    if IsNull(entity) then
        return
    end
    gRegion:CreateEntity(spawnEffect,entity:GetPosition(),entity:GetRotation())
    entity:Attach(enemyProjectorFX, EMPTY_SYMBOL)
    local attachments = entity:GetAllAttachments(gEntityType)
    for i=1,#attachments do
        attachments[i]:Attach(enemyProjectorFX, EMPTY_SYMBOL)
    end
end

local function ChooseTypeAndSpawn(index)
    local typeToSpawn
    local typeIndex = RandomInt(1,3)
    local spawnIndex = RandomInt(1,#spawnPoints)
    if typeIndex == 1 then
        typeToSpawn = meleeTypes[index]
    elseif typeIndex == 2 then
        typeToSpawn = rangedTypes[index]
    else
        typeToSpawn = miscTypes[index]
    end
    
    local agent = aiDir:CreateAgent(typeToSpawn, spawnPoints[spawnIndex], team)
    local avatar = agent:GetAvatar()
    
    table.insert(usedPoints,spawnPoints[spawnIndex])
    table.remove(spawnPoints,spawnIndex)
    
    if #usedPoints > spawnPointReuseCount then
        table.insert(spawnPoints,usedPoints[1])
        table.remove(usedPoints,1)
    end
    
    CROOM.SetupEnemy(agent:GetAvatar(), spawnEffect, enemyProjectorFX)
    
    return avatar
end

local function GetNumSpawnedEnemies(spawnedAvatars)
    local count = 0
    if #spawnedAvatars == 0 then
        return 0
    end
    for i = #spawnedAvatars, 1, -1 do
        if not IsNull(spawnedAvatars[i]) and not spawnedAvatars[i]:IsKilled() then
            count = count + 1
        else
            table.remove(spawnedAvatars,i)
        end
    end
    return count
end

function RunChallenge()
    Sleep(3)
    
    Setup()
    local aiDir = npcMgr:GetAiDirector()
    
    gameRules:SetSaveMatchStatsDisabled(true)
    aiDir:SetLevelAlert(true)
    aiDir:SetObjective(playerAv)
    aiDir:SetEnemyLevelMinMax(12, 16)
    
    local sentinel = playerAv:InventoryControl():GetSentinel()
    if not IsNull(sentinel) then
        sentinel:InventoryControl():GetActivePowerSuit():SetAbilitiesEnabled(false)
    end
    
    local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
    local timer = _T.AddHudTracker("SurvivalChallengeTimer", LOTUS_UTIL.HT_TIMER, 0.25, false, false)
    timer.ShowMessage("/Lotus/Language/Game/SurvivalChallenge", 5)
    timer.StartTimer(timeLimit, false, true)
    
    local t = 0
    local spawnedAvatars = {}
    local wave = 1
    local spawnTimer = spawnDelay[wave]
    local wasAlive = true
    while t < timeLimit do
    
        if t > waveTimes[wave] then
            wave = wave + 1
            print("next Wave")
        end
        
        local numSpawned = GetNumSpawnedEnemies(spawnedAvatars) 
        if spawnTimer >= spawnDelay[wave] and numSpawned < maxSpawned[wave] then
            table.insert(spawnedAvatars,ChooseTypeAndSpawn(wave))
            spawnTimer = 0
        end
        
        Sleep(0)
        if IsNull(playerAv) then
            playerAv = gRegion:GetPlayerAvatar(0)
        end
        
        if not IsNull(playerAv) and not playerAv:IsKilled() then
            if numSpawned < maxSpawned[wave] then
                spawnTimer = spawnTimer + DeltaTime()
            end
        
            t = t + DeltaTime()
            
            if not wasAlive then
                wasAlive = true
                timer.SetPaused(false)
            end
        elseif wasAlive then
            wasAlive = false
            timer.SetPaused(true)
        end
    end
    
    for i = 1,#spawnedAvatars do
        if not IsNull(spawnedAvatars[i]) and not spawnedAvatars[i]:IsKilled() then
            local fx = gRegion:CreateEntity(spawnEffect, spawnedAvatars[i]:GetPosition(), ZERO_ROTATION)
            spawnedAvatars[i]:Destroy()
        end
    end
    
    LOTUS_UTIL.OnChallengePassed(playerAv, kneelAnim, transmission, endMissionMovie, endMissionDialog)
end

function SetNextRestartWaypoint()
    if _T.gCurrentRsPoint < _T.gNumRsPoints then
        _T.gCurrentRsPoint = _T.gCurrentRsPoint + 1
    end
    
    _T.gCurrentResetCount = 0
end

function SetNextStage()
    _T.gStage = _T.gStage + 1
end

function StartWave()
    
    
    
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end
