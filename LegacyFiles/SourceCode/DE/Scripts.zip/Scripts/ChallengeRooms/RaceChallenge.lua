endMissionMovie = Resource()
endMissionDialog = Instance()
kneelAnim = Resource()
transmission = Type()

timeLimit = 60

trigger = Instance()
targets = {Instance()}
targetType = WeakResource("/Lotus/Objects/Tenno/Dojo/TargetDeco")
moverType = WeakResource("/EE/Types/Engine/Mover")

local playerAv = gRegion:GetPlayerAvatar(0)
local gameRules = gGameRules
local timerSym = Symbol("Timer")
local timeIncrease = 5

local secondsMessage = "/Lotus/Language/Dojo/RaceIncreaseSeconds"
local introMessage = "/Lotus/Language/Dojo/RaceIntroMessage"

function SetTargetsVisible()
    for i, target in ipairs(targets) do
        target:SetVisibility(true, true)
        if target:IsA(moverType) then
            target:FirePort("Start")
        end
    end
end

function OnDestroyed(entity)
    local newTime = gameRules:GetMissionTimeLeft(timerSym) + timeIncrease
    gameRules:SetMissionTimer(timerSym, Symbol("Time Added"), newTime, true, true)
    _T.ShowImpactMessage(secondsMessage, 1, true, nil, false, { SECONDS = timeIncrease })
end

function GoalReached(instigator)
    while instigator:HasPostureModifier(Engine.PM_IN_AIR) do
        Sleep(0)
    end
    if trigger:IsTouching(instigator) then
        _T.gGoalReached = true
    end
end

function RunChallenge()
    _T.gGoalReached = false
    Sleep(0.1)
    _T.gTimeIncrease = 0
    gameRules:SetSaveMatchStatsDisabled(true)
    
    local allTargets = gRegion:FindAll(targetType)
    
    for i, target in ipairs(allTargets) do
        ObjectPortHandler(target, "OnDestroyed")
    end
    
    local sentinel = playerAv:InventoryControl():GetSentinel()
    if not IsNull(sentinel) then
        sentinel:InventoryControl():GetActivePowerSuit():SetAbilitiesEnabled(false)
    end
    
    playerAv:GetPlayer():AddTimerOfInterest(timerSym)
    
    gameRules:SetMissionTimer(timerSym, Symbol(introMessage), timeLimit, true, true)
    
    while gameRules:GetMissionTimeLeft(timerSym) > 0 and not _T.gGoalReached do
        
        Sleep(0)
        
    end
    
    if _T.gGoalReached then
        gameRules:SetMissionTimer(timerSym, Symbol(introMessage), 0, false, true)
        local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
        LOTUS_UTIL.OnChallengePassed(playerAv, kneelAnim, transmission, endMissionMovie, endMissionDialog)
    end
end

function SetNextRestartWaypoint()
    if _T.gCurrentRsPoint < _T.gNumRsPoints then
        _T.gCurrentRsPoint = _T.gCurrentRsPoint + 1
    end
    
    _T.gCurrentResetCount = 0
end

function SetNextStage()
    _T.gStage = _T.gStage + 1
end

function OnDeath(mpRules, victimAvatar, instigatorAvatar, victimPlayer, instigatorPlayer) 
    if not IsNull(victimAvatar) and victimAvatar:IsA(gLotusNpcAvatarType) then
        _T.gTimeIncrease = _T.gTimeIncrease + timeIncrease
    end
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end
