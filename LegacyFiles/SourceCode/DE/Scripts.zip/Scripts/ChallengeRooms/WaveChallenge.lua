endMissionMovie = Resource()
endMissionDialog = Instance()
kneelAnim = Resource()
transmission = Type()
endMissionTrans = Type()
objectiveText = String("/Lotus/Language/Game/KillAllWithPrimary")

timeLimits = {60,60,60}
killGoals = {10,15,20}
maxSpawned = {3,5,7}
spawnDelay = {1,1,1}
enemyProjectorFX = Type()
spawnEffect = Resource()
spawnPointReuseCount = 3
noPowers = false

--These are used in case we are loading level directly instead of normal level flow
backupAiSpec = Resource()
backupMinEnemyLevel = 1
backupMaxEnemyLevel = 1

local CROOM = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"
local player = gRegion:GetLocalPlayer()
local aiDir = gRegion:GetNpcMgr():GetAiDirector()
local sWaveDur = Symbol("WaveDuration")
local totalWaves = 0
local gameRules = gGameRules
local killTotal = 0
local usedPoints = {}
local spawnPoints = {}
local challengeFailed = false

local function Initialize()
    
    spawnPoints = gRegion:FindAll(gNpcSpawnPointType)
    
    gameRules:SetSaveMatchStatsDisabled(true)
    gameRules:SetShowReviveScreenOnDeath(false)
    aiDir:SetLevelAlert(true)
    aiDir:SetObjective(player:GetAvatar())
    aiDir:Enable(true)
    
    local mission = gameRules:GetMission()
    if IsNull(gameRules:GetMissionAI()) then
        aiDir:SetEnemyLevelMinMax(backupMinEnemyLevel, backupMaxEnemyLevel)
    else
        aiDir:SetEnemyLevelMinMax(mission.minEnemyLevel, mission.maxEnemyLevel)
    end
    CROOM.AddAiTypes(backupAiSpec)
    CROOM.SetMaxAttempts(3)
        
    local sentinel = player:GetAvatar():InventoryControl():GetSentinel()
    if not IsNull(sentinel) then
        sentinel:InventoryControl():GetActivePowerSuit():SetAbilitiesEnabled(false)
    end
    
    ObjectPortHandler(player:GetAvatar(), "OnKilled")
    player:AddTimerOfInterest(sWaveDur)
end

local function ChooseSpawnPoint()
    local spawnIndex = RandomInt(1,#spawnPoints)
    local spawnPoint = spawnPoints[spawnIndex]
    table.insert(usedPoints,spawnPoint)
    table.remove(spawnPoints,spawnIndex)
    
    if #usedPoints > spawnPointReuseCount then
        table.insert(spawnPoints,usedPoints[1])
        table.remove(usedPoints,1)
    end
    
    return spawnPoint
end

function OnKilled(avatar)
    if avatar:IsA(gLotusNpcAvatarType) then
        killTotal = killTotal + 1
    else
        --player
        local canRetry = CROOM.PlayerRetry()
        if canRetry then
            gameRules:RespawnPlayer(player, false)
            while player:GetAvatar() == avatar do
                Sleep(0)
            end
            ObjectPortHandler(player:GetAvatar(), "OnKilled")
            if noPowers then
                player:GetAvatar():InventoryControl():GetActivePowerSuit():SetAbilityIdentifiersBlocked(true)
            end
        else
            challengeFailed = true
        end
    end
end

function RunChallenge()
    Sleep(3)
    
    Initialize()
    
    totalWaves = #timeLimits
    
    local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
    local progressBar = nil
    
    for i = 1, totalWaves do
    
        gameRules:SetMissionTimer(sWaveDur, Symbol(Localize("/Lotus/Language/Game/WaveXIncoming", {WAVENUM = i})),timeLimits[i],true,true)
        aiDir:SetCurrentTier(i - 1)
        
        local t = 0
        local spawnTimer = spawnDelay[i]
        while t < timeLimits[i] and not challengeFailed do
            --Update UI
            local goalText = "/Lotus/Language/Game/EnemiesRemaining"
            local remaining = killGoals[i] - killTotal
            if remaining == 1 then
                goalText = "/Lotus/Language/Game/SingleEnemyRemaining"
            end
            if IsNull(progressBar) then
                progressBar = _T.AddHudTracker("WaveChallengeProgressBar", LOTUS_UTIL.HT_PROGRESS_BAR, 0.2, false, false)
                progressBar.SetFlareColor(_G.UIColor_DarkBlue)
                progressBar.SetLabel(objectiveText, 1)
            end
            progressBar.SetGoalLabel(remaining .. " " .. progressBar.Localize(goalText))
            progressBar.SetValue(killTotal / killGoals[i])
            
            --Spawn guys if needed
            if spawnTimer >= spawnDelay[i] and aiDir:GetActiveAICount() < maxSpawned[i] then
                local agent = aiDir:CreateRandomAgent(ChooseSpawnPoint(), Symbol("Enemy"))
                if IsNull(agent) then
                    print("Failed to create random agent")
                else
                    local avatar = agent:GetAvatar()
                    CROOM.SetupEnemy(avatar, spawnEffect, enemyProjectorFX)
                    ObjectPortHandler(avatar, "OnKilled")
                    avatar:SetFaction(Symbol("Enemy"))
                    spawnTimer = 0
                end
            end
            
            if aiDir:GetActiveAICount() < maxSpawned[i] then
                spawnTimer = spawnTimer + DeltaTime()
            end
            
            if killTotal >= killGoals[i] then
                break
            end
            
            t = t + DeltaTime()
            Sleep(0)
        end
        
        if challengeFailed then
            break
        end
        
        local avatars = gRegion:FindAll(gLotusNpcAvatarType)
        for i, avatar in ipairs(avatars) do
            if not avatar:IsAvatarFriendly(player:GetAvatar()) and not avatar:IsKilled() then
                avatar:Destroy()
            end
        end
        
        if t < timeLimits[i] and killTotal >= killGoals[i] then
            killTotal = 0
            local waveDelay = 5
            if i == totalWaves then
                waveDelay = 3
            end
            
            Sleep(0)
            _T.ShowImpactMessage(Localize("/Lotus/Language/Game/WaveComplete", {WAVENUM = i}), waveDelay, true, nil, true)
            if i ~= totalWaves then
                gameRules:SetMissionTimer(sWaveDur, Symbol(), waveDelay, false, false)
                Sleep(1)
                player:GetAvatar():GiveTransmissionAsync(transmission)
                Sleep(waveDelay-1)
            else
                player:RemoveTimerOfInterest(sWaveDur)
                Sleep(waveDelay)
            end
        else
            challengeFailed = true
            break
        end

        Sleep(0)
    end
    
    if _T.MasteryAscensionMode then
        -- TODO let mastery acscencsion know you need to do next one or failed
        if challengeFailed then
            return
        end

        _T.MA_OnChallengeCompleted()
    else
        if challengeFailed then
            CROOM.ChallengeFailed()
            return
        end

        LOTUS_UTIL.OnChallengePassed(player:GetAvatar(), kneelAnim, endMissionTrans, endMissionMovie, endMissionDialog)
    end
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end
