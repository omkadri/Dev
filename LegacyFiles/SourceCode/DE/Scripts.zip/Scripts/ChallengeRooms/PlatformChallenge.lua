resetAnim = Resource()
allowedResets = 3
endMissionMovie = Resource()
endMissionDialog = Instance()
kneelAnim = Resource()
transmission = Type()
enemyProjectorFX = Type()
spawnEffect = Resource()
fallTrigger = Instance()
spawnControl = Instance()
startingPlatforms = {Instance()}
startingTrigger = Instance()
platforms = {Instance()}
initialDelay = 2
timerDuration = 90
playerSpawn = Instance()

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local CROOM = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"
local postFade = require "Lotus.Scripts.PostProcess.BasePostProcessFade"
local player = nil
local playerAv = nil
local gameRules = gGameRules
local tries = 0

local timerStarted = false
local killTotal = 0
local killGoal = 0
local shouldReset = false
local resetting = false

local function UpdateUI()
    if IsNull(_T.PlatformChallengeProgressBar) then
        _T.PlatformChallengeProgressBar = _T.AddHudTracker("PlatformChallengeProgressBar", LOTUS_UTIL.HT_PROGRESS_BAR, 0.2, false, false)
        _T.PlatformChallengeProgressBar.SetFlareColor(_G.UIColor_DarkBlue)
        _T.PlatformChallengeProgressBar.SetLabel("/Lotus/Language/Game/EnemyCount", 1)
    end
    _T.PlatformChallengeProgressBar.SetGoalLabel(killTotal .. " / " .. killGoal)
    _T.PlatformChallengeProgressBar.SetValue(killTotal / killGoal)
end

local function Reset()
    if killTotal >= killGoal then
        return
    end
    
    resetting = true
    tries = tries + 1
    _T.gPlatformChallengeAllowContactNotify = false
    --Reset
    postFade.Fade(0,-1,0.5)
    
    for i, platform in ipairs(startingPlatforms) do
        if not IsNull(platform) then
            platform:FirePort("Show")
        end
    end
    spawnControl:FirePort("Remove Agents")
    for i, platform in ipairs(platforms) do
        platform:SetVisibility(true, true)
        platform:SetMaterialParam(Lotus_Game.EMISSIVE_MAP_ATTEN, 1)
    end
    
    local spawn = player:GetPlayerSpawn()
    gameRules:RespawnPlayer(player, false)
    Sleep(0)
    killTotal = 0
    UpdateUI()
    
    while IsNull(playerAv) do
        Sleep(0)
        playerAv = player:GetAvatar()
    end
    
    playerAv:SetCameraView(spawn:GetRotation())
    playerAv:MotionControl():SetTorsoFromView(spawn:GetRotation())
    Sleep(0.5)
    startingTrigger:Enable()
    playerAv:PlayAnimation(resetAnim, false, Engine.ATMM_ANIMATION_DRIVEN)
    postFade.Fade(-1,0,2)
    
    _T.gPlatformChallengeAllowContactNotify = true
    _T.ShowImpactMessage(Localize("/Lotus/Language/Game/AttemptsLeft", nil) .. ": " .. allowedResets - tries, 5, true, nil, false)
    shouldReset = false
    resetting = false
end

function OnAgentDestroyed()
    if not resetting then
        killTotal = killTotal + 1
        UpdateUI()
    end
end

function OnKilled()
    shouldReset = true
end

function RunChallenge()

    ObjectPortHandler(spawnControl, "OnAgentDestroyed")

    _T.gPlatformChallengeAllowContactNotify = false
    killGoal = spawnControl:GetTotalToSpawn()

    Sleep(0.1)
    gameRules:SetSaveMatchStatsDisabled(true)
    gameRules:SetShowReviveScreenOnDeath(false)

    ObjectPortHandler(fallTrigger,"OnTouched")
    player = gRegion:GetLocalPlayer()
    playerAv = player:GetAvatar()
    ObjectPortHandler(playerAv, "OnKilled")
    player:SetPlayerSpawn(playerSpawn)
    _T.gPlatformChallengeAllowContactNotify = true
    
    UpdateUI()
    
    while tries < allowedResets do
        if killGoal == killTotal then
            break
        end
        if shouldReset then
            Reset()
        end
        Sleep(0)
    end
    
    if tries < allowedResets then
        for i, platform in ipairs(startingPlatforms) do
            platform:FirePort("Show")
        end
        postFade.Fade(0,-1,0.5)
        gameRules:RespawnPlayer(player, false)
        Sleep(0.5)
        playerAv = player:GetAvatar()
        postFade.Fade(-1,0,1)
        local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
        LOTUS_UTIL.OnChallengePassed(playerAv, kneelAnim, transmission, endMissionMovie, endMissionDialog)
    else
        CROOM.ChallengeFailed()
    end

end

function RunTimedChallenge()
    
    Sleep(initialDelay)
    
    local timer = _T.AddHudTracker("PlatformChallengeTimer", LOTUS_UTIL.HT_TIMER, 0.25, false, false)
    if not timerStarted then
        timer.ShowMessage("/Lotus/Language/Game/LaserChallengeCountdown", 5)
        timer.StartTimer(timerDuration, false, true, true)
        timerStarted = true
    end
    
    while true do
        if timerStarted and not gGameRules:MissionFailed() and not gGameRules:MissionCompleted() then
            if timer.Data.Time <= 0 then
                CROOM.ChallengeFailed()
                break
            end
        end
        Sleep(0)
    end

end

function OnTouched(entity)
    Reset()
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end

function EnemySetup(agent)
    CROOM.SetupEnemy(agent:GetAvatar(), spawnEffect, enemyProjectorFX)
end
