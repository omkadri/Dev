endMissionMovie = Resource()
endMissionDialog = Instance()
kneelAnim = Resource()
transmission = Type()
endMissionTrans = Type()
killGoals = {10,15,20}
maxSpawned = {3,5,7}
spawnDelay = {1,1,1}
spawnControls = {Instance()}
playerStartPoints = {Instance()}
enemyProjectorFX = Type()
spawnEffect = Resource()
spawnPointReuseCount = 3
aiSpec = Resource()

local CROOM = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"
local postFade = require "Lotus.Scripts.PostProcess.BasePostProcessFade"
local playerAv = gRegion:GetPlayerAvatar(0)
local aiDir = gRegion:GetNpcMgr():GetAiDirector()
local team = Symbol("RandomTeam")
local gameRules = gGameRules
local killTotal = 0
local usedPoints = {}
local tries = 0
local allowedResets = 3

local function ChooseTypeAndSpawn(index, spawnedAvatars)
    local spawnPoints = spawnControls[index]:GetSpawnPoints()
    local spawnIndex = RandomInt(1,#spawnPoints)
    
    local agent = aiDir:CreateRandomAgent(spawnPoints[spawnIndex], team)
    
    if IsNull(agent) then
        return nil
    end
    
    local avatar = agent:GetAvatar()
    
    table.insert(usedPoints,spawnPoints[spawnIndex])
    table.remove(spawnPoints,spawnIndex)
    
    if #usedPoints > spawnPointReuseCount then
        table.insert(spawnPoints,usedPoints[1])
        table.remove(usedPoints,1)
    end
    
    CROOM.SetupEnemy(avatar, spawnEffect, enemyProjectorFX)
    
    return avatar
end

local function GetNumSpawnedEnemies(spawnedAvatars, goal)
    local count = 0
    if #spawnedAvatars == 0 then
        return 0
    end
    for i = #spawnedAvatars, 1, -1 do
        if not IsNull(spawnedAvatars[i]) and not spawnedAvatars[i]:IsKilled() then
            count = count + 1
        else
            killTotal = killTotal + 1
            local killsLeft = goal - killTotal
            if killsLeft > 0 and (math.mod(killTotal, 5) == 0 or killsLeft < 4) then
                if killsLeft == 1 then
                    _T.ShowImpactMessage(killsLeft .. " " .. Localize("/Lotus/Language/Game/SingleEnemyRemaining", {}), 2, true, nil, false)
                else
                    _T.ShowImpactMessage(killsLeft .. " " .. Localize("/Lotus/Language/Game/EnemiesRemaining", {}), 2, true, nil, false)
                end
            end
            table.remove(spawnedAvatars,i)
        end
        Sleep(0)
    end
    return count
end

local function Retry()
    tries = tries + 1
    --Reset
    postFade.Fade(0,-1,0.5)
    
    local playerAv = gRegion:GetLocalPlayerAvatar()
    local player = playerAv:GetPlayer()
    gameRules:RespawnPlayer(player, false)
    Sleep(0)
    playerAv = player:GetAvatar()
    Sleep(0.5)
    postFade.Fade(-1,0,2)
    
    _T.gPlatformChallengeAllowContactNotify = true
    _T.ShowImpactMessage(Localize("/Lotus/Language/Game/AttemptsLeft", nil) .. ": " .. allowedResets - tries, 5, true, nil, false)
    
end

function RunChallenge()
    
    local lastStartPoint = playerStartPoints[1]
    
    gameRules:SetSaveMatchStatsDisabled(true)
    gameRules:SetShowReviveScreenOnDeath(false)
    aiDir:Enable(true)
    aiDir:SetObjective(playerAv)
    aiDir:SetLevelAlert(true)
    aiDir:SetEnableAutoSpawns(false)
    aiDir:SetEnemyLevelMinMax(15,20)
    local player = gRegion:GetLocalPlayer()
    player:SetPlayerSpawn(playerStartPoints[1])
    
    local missionAI = gameRules:GetMissionAI()
    if IsNull(missionAI) then       --likely we're loading the level directly
        missionAI = aiSpec:GetEnemies()
    end
    
    for i=1,#missionAI do
        local mai = missionAI[i]
        local prob = mai.probability
        local agent = mai.agent
        local maxSim = mai.maxSimultaneous
        local tier = mai.tier
        local agentType = Type(agent)
        if not IsNull(agentType) then
            --table.insert(aiTypes, agentType)
            --table.insert(aiProbability, prob)
            aiDir:AddMissionAIType(agentType, prob, maxSim, tier)
        else
            print("NULL agent type!")
        end
    end
    
    local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
    local progressBar = nil
    
    for i = 1, #killGoals do
    
        aiDir:SetCurrentTier(i-1, true)
        _T.ShowImpactMessage((Localize("/Lotus/Language/Game/WaveXIncoming", {WAVENUM = i})), 3, true, nil, false)
        Sleep(3)
        
        local t = 0
        local spawnedAvatars = {}
        local spawnTimer = spawnDelay[i]
        while killTotal < killGoals[i] and tries < allowedResets do
            local numSpawned = GetNumSpawnedEnemies(spawnedAvatars, killGoals[i]) 
            if spawnTimer >= spawnDelay[i] and numSpawned < maxSpawned[i] then
                local avatar = ChooseTypeAndSpawn(i, spawnedAvatars)
                if not IsNull(avatar) then
                    table.insert(spawnedAvatars,avatar)
                    spawnTimer = 0
                end
            end
            
            if numSpawned < maxSpawned[i] then
                spawnTimer = spawnTimer + DeltaTime()
            end
            
            if IsNull(progressBar) then
                progressBar = _T.AddHudTracker("GauntletProgressBar", LOTUS_UTIL.HT_PROGRESS_BAR, 0.2, false, false)
                progressBar.SetFlareColor(_G.UIColor_DarkBlue)
                progressBar.SetLabel("/Lotus/Language/Game/EnemyCount", 1)
            end
            progressBar.SetGoalLabel(killTotal .. " / " .. killGoals[i])
            progressBar.SetValue(killTotal / killGoals[i])
            
            if IsNull(player:GetAvatar()) or player:GetAvatar():IsKilled() then
                Sleep(1)
                Retry()
            end
            
            t = t + DeltaTime()
            Sleep(0)
        end
        
        if tries >= allowedResets then
            CROOM.ChallengeFailed()
        end
        
        if killTotal >= killGoals[i] then
            for j, av in ipairs(spawnedAvatars) do
                if not IsNull(av) and not av:IsKilled() then
                    av:Destroy()
                end
            end 
            killTotal = 0
            local waveDelay = 10
            if i == #killGoals then
                waveDelay = 5
            end
            Sleep(0)
            _T.ShowImpactMessage((Localize("/Lotus/Language/Game/WaveComplete", {WAVENUM = i})), 3, true, nil, false)
            if i ~= #killGoals then
                Sleep(1)
                if IsNull(playerAv) then
                    playerAv = gRegion:GetPlayerAvatar(0)
                end
                playerAv:GiveItem(transmission,true)
                Sleep(waveDelay-1)
                
                --TP player to new start point if it is different from the previous
                if lastStartPoint ~= playerStartPoints[i+1] then
                    postFade.Fade(0,-1,1)
                    player:SetPlayerSpawn(playerStartPoints[i+1])
                    gameRules:RespawnPlayer(player, false)
                    _T.RemoveHudTracker(progressBar)
                    progressBar = nil
                    postFade.Fade(-1,0,1)
                    lastStartPoint = playerStartPoints[i+1]
                end
            else
                Sleep(waveDelay)
            end
        end

        Sleep(0)
    end
    
    local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
    LOTUS_UTIL.OnChallengePassed(playerAv, kneelAnim, endMissionTrans, endMissionMovie, endMissionDialog)
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end
