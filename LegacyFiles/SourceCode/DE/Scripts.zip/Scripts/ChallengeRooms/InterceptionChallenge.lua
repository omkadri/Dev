scoreGoal = 1000
scoreRatePerSecond = 1
scoreRateScale = 2      --How to scale score rate for each territory owned
reducedScoreRateScale = 0.5     --how to scale score rate for each territory owned for team with less capture points
minSpawnDistance = 40
maxSpawnDistance = 250
enemyColour = Color(255, 0, 0, 255)
playerColour = Color(0, 255, 0, 255)
neutralColour = Color()
pillarDeco = Type()
extraEffectDeco = Type()
numPlayersCaptureScale = {2, 1.66, 1.33, 1}
hackExcludeTypes = {WeakResource()}
backupAiSpec = Resource()

spawnEffect = Resource()
projector = Resource()

--Transmissions
towersCaptured = Resource()
towersLost = Resource()
towerCaptured = Resource()
towerLost = Resource()

territoryTrigger = Instance()

endMissionMovie = Resource()
endMissionDialog = Instance()
kneelAnim = Resource()
endMissionTrans = Type()

local sDominatingXpBonus = Symbol("/Lotus/Language/Actions/DominatingXP")
local sCaptureXp = Symbol("/Lotus/Language/Actions/TerritoryCaptureXP")
local sNeutralizeXp = Symbol("/Lotus/Language/Actions/TerritoryNeutralizeXP")

local TABLE = require "Lotus.Scripts.Libs.TableLib"
local SQUAD = require "Lotus.Scripts.Libs.SquadLib"
local CROOM = require "Lotus.Scripts.ChallengeRooms.BaseChallengeRoom"

local gameRules = gGameRules
local npcManager = gRegion:GetNpcMgr()
local aiDir = npcManager:GetAiDirector()

local territories
local playerOwned = {}
local enemyOwned = {}
local neutral = {}
local enemyScore = 0
local playerScore = 0
local retrying = false
local player = gRegion:GetLocalPlayer()
local playerAv = gRegion:GetLocalPlayerAvatar()

local captureXp = 300
local allCaptureXp = 500
local neutralizeXp = 300


local mTimerMgr = nil

local ageSortFunc = function(a, b) 
    local aDiff = a:GetStateAge()
    local bDiff = b:GetStateAge()
    if aDiff > bDiff then
        return 1
    elseif aDiff < bDiff then
        return -1
    else
        return 0
    end
end

local function IsExcludeType(excludeList, object)
    for j, exType in ipairs(excludeList) do
        if object:IsA(exType) then
            return true
        end
    end
    
    return false
end

--attempt the objective if someone has reached it - called via squadLib
local squadAttemptObjective = function(territory, agents)

    if territory:IsAiCapturing() or territory:GetState() == Lotus_Game.TS_ENEMY_OWNED then
        return
    end

    local touching = {}
    for k, agent in ipairs(agents) do
        local avatar = agent:GetAvatar()
        if territory:IsTouching(avatar) and not IsExcludeType(hackExcludeTypes, avatar) then
            table.insert(touching, agent)
        end
    end
    
    if #touching > 0 then
        local randomMember = touching[RandomInt(1, #touching)]
        local actions = territory:GetHackPoints()
        local action = actions[RandomInt(1, #actions)]
        
        if not IsNull(action) then
            randomMember:UseContextAction(action, false)
            print("squad hacking")
            return randomMember
        else
            print("Couldn't find an action to use")
        end
    end
    
    return nil
end

--attempt the objective as just a single AI - called via squadLib
local attemptObjective = function(territory, agent)
    if territory:IsAiCapturing() or territory:GetState() == Lotus_Game.TS_ENEMY_OWNED then
        return
    end

    if not IsExcludeType(hackExcludeTypes, agent:GetAvatar()) and agent:GetTimeSinceLastDamaged() > 3  then
        local actions = territory:GetHackPoints()
        local action = actions[RandomInt(1, #actions)]
        
        if not IsNull(action) then
            agent:UseContextAction(action, false)
            print("Solo hacking")
            return true
        end
    end
    
    return false
end

local IsObjectiveComplete = function(objective, agents)
    if objective:GetState() == Lotus_Game.TS_ENEMY_OWNED then
        return true
    else
        return false
    end
end

local function LocalizeTerritoryLabel(territoryLabel)
    if territoryLabel == Lotus_Game.TL_ALPHA then
        return Localize("/Lotus/Language/Game/Territory_Alpha", false)
    elseif territoryLabel == Lotus_Game.TL_BRAVO then
        return Localize("/Lotus/Language/Game/Territory_Bravo", false)
    elseif territoryLabel == Lotus_Game.TL_CHARLIE then
        return Localize("/Lotus/Language/Game/Territory_Charlie", false)
    elseif territoryLabel == Lotus_Game.TL_DELTA then
        return Localize("/Lotus/Language/Game/Territory_Delta", false)
    else
        return "Unnamed"
    end
end

local FindObjective = function(squad, objectives, highPriority)
    
    if #objectives == 0 then
        return nil
    end
    
    TABLE.QuickSort(objectives, ageSortFunc)    --oldest first
    
    local players = gRegion:GetHumanPlayerAvatars()
    local obj = nil
    
    if highPriority then
        for i, objective in ipairs(objectives) do
            if (objective:GetState() == Lotus_Game.TS_PLAYER_OWNED or objective:GetState() == Lotus_Game.TS_NEUTRAL) and objective:GetStateAge() > 30 then
                local count = 0
                for k = #players, 1, -1 do
                    if objective:IsTouching(players[k]) then
                        count = count + 1
                        table.remove(players, k)
                    end
                end
                
                if count <= 1 then
                    obj = objective
                    break
                end
            end
        end
        
        if obj then
            print("High priority objective = " .. LocalizeTerritoryLabel(obj:GetLabel()))
        end
        
        return obj
    end
    
    --Prioritize neutral territories otherwise pick one at random
    for i, objective in ipairs(objectives) do
        if objective:GetState() == Lotus_Game.TS_NEUTRAL then
            print("Normal objective = " .. LocalizeTerritoryLabel(objective:GetLabel()))
            return objective
        end
    end
    
    obj = objectives[RandomInt(1, #objectives)]
    print("Normal objective = " .. LocalizeTerritoryLabel(obj:GetLabel()))
    
    return obj
end

local function InitAiInfo()
    local aiInfo = {}

    aiInfo.maxAi = {{6, 6, 6},                    --max ai to have spawned at once , 1player
                    {15, 20, 25},                   --2 players
                    {20, 25, 30},                   --3 players
                    {30, 30, 30}}                   --4 players
    aiInfo.tier = {0, 1, 2}                         --tier to use for enemy types
    aiInfo.numSquadObj =   {{2, 3, 3},              --max number of simultaneous objectives, 1 player
                            {3, 3, 4},              --2 players
                            {3, 4, 4},              --3 players
                            {4, 4, 4}}              --4 players
    aiInfo.minSquadSize = {2, 3, 4}                 --min number of ai required to create a squad
    aiInfo.maxSquadSize = {3, 4, 5}                 --max number of ai required to create a squad
    aiInfo.arraySize = #aiInfo.maxAi                --will not use values past this index in the array (for debugging and readability)
    aiInfo.index = {0.15, 0.3, 1}
    aiInfo.defaultSpawnDelay = {6, 2, 1, 1}
    aiInfo.spawnDelayIncrement = {2, 1, 0, 0}
    aiInfo.maxSpawnDelay = {10, 5, 1, 1}
    aiInfo.objectiveUpdateTime = {8, 6, 4, 2}
    aiInfo.maxLeaders = {0, 2, 3, 4}
    aiInfo.initialSpawnAmount = {6, 8, 10, 12}
    aiInfo.highPriorityUpdate = {80, 40, 30, 20}
    aiInfo.highPrioritySpawnDelay = {10, 6, 2, 0.5}
    aiInfo.squadObjAttempt = squadAttemptObjective
    aiInfo.objAttempt = attemptObjective
    aiInfo.FindObjective = FindObjective
    aiInfo.IsObjectiveComplete = IsObjectiveComplete
    
    aiDir:SetEnableAutoSpawns(false)
    aiDir:SetCustomSpawnSelectionFilter(minSpawnDistance, maxSpawnDistance, 0, 2, true, false, true)
    aiDir:SetUseCustomSpawnSelectionFilter(true)
    aiDir:SetUseNewSpawnPacing(false)
    aiDir:Enable(true)
    aiDir:SetObjective(gRegion:GetLocalPlayerAvatar())
    
    local usingBackup = false
    local aiList = gameRules:GetMissionAI()
    if IsNull(aiList) or #aiList == 0 then
        aiList = backupAiSpec:GetEnemies()   --only used when loading via File -> Load Level
        usingBackup = true
    end
    for i, enemy in ipairs(aiList) do
        aiDir:AddMissionAIType(enemy.agent, enemy.probability, enemy.maxSimultaneous, enemy.tier)
    end
    
    if usingBackup then
        aiDir:SetEnemyLevelMinMax(15, 20)
    else
        local missionInfo = gameRules:GetMission()
        aiDir:SetEnemyLevelMinMax(missionInfo.minEnemyLevel, missionInfo.maxEnemyLevel)
    end
    
    SQUAD.Initialize(aiInfo)
end

local function GetPotentialTargets()

    local targets = {}
    
    for i, territory in ipairs(territories) do
        
        local potential = true
        if territory:GetState() == Lotus_Game.TS_PLAYER_OWNED or territory:GetState() == Lotus_Game.TS_NEUTRAL then            
            if potential then
                table.insert(targets, territory)
            end
        end
    end
    
    return targets

end

local function TestRange(val, minVal, maxVal)

    if val >= minVal and val <= maxVal then
        return true
    end
    
    return false

end

local function GetScoreScales()

    local diff = #enemyOwned - #playerOwned
    local enemyScale = 0
    local playerScale = 0
    if diff > 0 then
        enemyScale = scoreRateScale * #enemyOwned
        playerScale = reducedScoreRateScale * #playerOwned
    elseif diff == 0 and #enemyOwned ~= 0 then
        enemyScale = 1
        playerScale = 1
    elseif diff < 0 then
        playerScale = scoreRateScale * #playerOwned
        enemyScale = reducedScoreRateScale * #enemyOwned
    end
    
    return enemyScale, playerScale
end

local function TerritoryHUDUpdate()
    local playerScorePercent = playerScore / scoreGoal
    local enemyScorePercent = enemyScore / scoreGoal
    if not IsNull(_T.UpdateTerritoryScores) then
        _T.UpdateTerritoryScores(playerScorePercent, enemyScorePercent)

        for i, territory in ipairs(territories) do
            _T.UpdateTerritoryProgress(territory)
        end
    end
end

local Retry = function()
    retrying = false
    gameRules:RespawnPlayer(player, false)
    playerAv = player:GetAvatar()
end

--main gameplay loop
function Territory()
    
    local TimerLib = require "Lotus.Interface.Libs.TimerMgr"
    mTimerMgr = TimerLib.CreateTimerMgr()

    InitAiInfo()
    
    gameRules:SetShowReviveScreenOnDeath(false)
    
    territories = gRegion:FindAll(gTerritoryTriggerType)
    
    -- do territory setup
    for i, territory in ipairs(territories) do
        ObjectPortHandler(territory, "OnPlayerCaptured")
        ObjectPortHandler(territory, "OnEnemyCaptured")
        ObjectPortHandler(territory, "OnNeutralized")
        ObjectPortHandler(territory, "OnTouched")
        
        if territory:GetState() == Lotus_Game.TS_PLAYER_OWNED then
            table.insert(playerOwned, territory)
        elseif territory:GetState() == Lotus_Game.TS_ENEMY_OWNED then
            table.insert(enemyOwned, territory)
        else
            table.insert(neutral, territory)
        end
        
        local hackPoints = territory:GetHackPoints()
        for j, point in ipairs(hackPoints) do
            point:Enable()
            local attachments = point:GetAllAttachments(gDecorationType)
            for k, attachment in ipairs(attachments) do
                attachment:SetVisibility(true, true)
            end
        end
            
        local attachments = territory:GetAllAttachments(gDecorationType)
        for k, attachment in ipairs(attachments) do
            attachment:SetVisibility(true, true)
        end
            
        local objective = territory:GetObjectiveMarker()
        objective:Enable()
        territory:Enable()
    end

    
    local hud = gameRules:GetHudMovieInstance()
    if hud == nil then
        return
    end

    local minimap = player:GetMiniMap()
    
    minimap:EnableObjectivePathing(false)
    _T.InitializeTerritoryHUDElements()
    _T.ShowTerritoryProgress = true
    
    CROOM.SetMaxAttempts(3)

    while enemyScore < scoreGoal and playerScore < scoreGoal do

        while gameRules:IsPauseMenuShowing() do
            Sleep(0)
        end
    
        Sleep(0)
        mTimerMgr:Update(DeltaTime())
        
        local newAgents = SQUAD.Update(GetPotentialTargets(), playerScore / scoreGoal)
        for i, agent in ipairs(newAgents) do
            CROOM.SetupEnemy(agent:GetAvatar(), spawnEffect, projector)
        end
        
        local players = gRegion:GetHumanPlayers()
        for i, territory in ipairs(territories) do
            territory:SetCaptureScale(numPlayersCaptureScale[#players])
        end

        local enemyScale, playerScale = GetScoreScales()
    
        enemyScore = enemyScore + enemyScale * scoreRatePerSecond * DeltaTime()
        playerScore = playerScore + playerScale * scoreRatePerSecond * DeltaTime()
        
        if IsNull(playerAv) or playerAv:IsKilled() and not retrying then
            retrying = CROOM:PlayerRetry() 
            
            if retrying then
                mTimerMgr:AddTimer(2, Retry, false)
            else
                break
            end
        end
        
        TerritoryHUDUpdate()
    end
    
    for i, territory in ipairs(territories) do
        territory:SetCaptureProgress(0)
        territory:Disable()
    end
    
    local avatars = gRegion:FindAll(gLotusNpcAvatarType)
    for i, avatar in ipairs(avatars) do
        if not avatar:IsA(gLotusSentinelAvatarType) then
            avatar:Destroy()
        end
    end
    
    if playerScore >= scoreGoal then
        playerAv = gRegion:GetLocalPlayerAvatar()
        local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
        LOTUS_UTIL.OnChallengePassed(playerAv, kneelAnim, endMissionTrans, endMissionMovie, endMissionDialog)
    else
        CROOM.ChallengeFailed()
    end
end

function OnPlayerCaptured(territory)
    if TABLE.Search(playerOwned, territory) == 0 then
        table.insert(playerOwned, territory)
    end
    TABLE.RemoveByElement(neutral, territory)
    TABLE.RemoveByElement(enemyOwned, territory)
    
    local playerAvs = gRegion:GetHumanPlayerAvatars()
    for i, av in ipairs(playerAvs) do
        if territory:IsTouching(av) and #playerOwned ~= #territories then
            av:GiveItem(towerCaptured, true)
            av:InventoryControl():GiveXP(captureXp, av, sCaptureXp)
        elseif #playerOwned == #territories then
            av:GiveItem(towersCaptured, true)
            av:InventoryControl():GiveXP(allCaptureXp, av, sDominatingXpBonus)
        end
    end
    
    aiDir:SetLevelAlert(true)
end

function OnEnemyCaptured(territory)
    if TABLE.Search(enemyOwned, territory) == 0 then
        table.insert(enemyOwned, territory)
    end
    TABLE.RemoveByElement(neutral, territory)
    TABLE.RemoveByElement(playerOwned, territory)
    
    local playerAvs = gRegion:GetHumanPlayerAvatars()
    for i, av in ipairs(playerAvs) do
        if #enemyOwned < #territories then
            av:GiveItem(towerLost, true)
        elseif #enemyOwned == #territories then
            av:GiveItem(towersLost, true)
        end
    end
end

function OnNeutralized(territory)
    TABLE.RemoveByElement(playerOwned, territory)
    TABLE.RemoveByElement(enemyOwned, territory)
    if TABLE.Search(neutral, territory) == 0 then
        table.insert(neutral, territory)
    end
    
    local playerAvs = gRegion:GetHumanPlayerAvatars()
    for i, av in ipairs(playerAvs) do
        if territory:IsTouching(av) then
            av:InventoryControl():GiveXP(neutralizeXp, av, sNeutralizeXp)
        end
    end
end

function OnTouched(territory)
    SQUAD.ReachedObjective(territory)
end

function TerritoryDecoration(deco)
    
    local trigger = deco:GetAttachParent()
    local targetColour
    local progress
    local pillar = deco:Attach(pillarDeco, EMPTY_SYMBOL)
    local extraEffect = trigger:GetAttachment(extraEffectDeco)
    
    while not IsNull(trigger) do
        deco:SetVisibility(false, true)
        while not trigger:IsEnabled() do
            Sleep(0)
        end
        
        deco:SetVisibility(true, true)
        local t = 0
        while trigger:IsEnabled() do
            targetColour = neutralColour
            progress = trigger:GetCaptureProgress()
            if progress < 0 then
                targetColour = enemyColour
            elseif progress > 0 then
                targetColour = playerColour
            end
            
            local newColour = Color()
            
            if trigger:IsAiCapturing() then
                if t < 0.5 then
                    newColour.alpha = Lerp(targetColour.alpha, 0, t * 2)
                elseif t >= 0.5 then
                    newColour.alpha = Lerp(0, targetColour.alpha, (t - 0.5) * 2)
                end
                t = t + DeltaTime()
                if t > 1 then
                    t = 0
                end
            else
                newColour.alpha = Lerp(neutralColour.alpha, targetColour.alpha, math.abs(progress))
            end
            newColour.red = Lerp(neutralColour.red, targetColour.red, math.abs(progress))
            newColour.green = Lerp(neutralColour.green, targetColour.green, math.abs(progress))
            newColour.blue = Lerp(neutralColour.blue, targetColour.blue, math.abs(progress))
            local sVal = (math.abs(trigger:GetCaptureProgress()) + 0.25) / 1.25
            deco:SetMeshScale(sVal)
            deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, newColour.alpha / 255)
            deco:SetMaterialParam(Lotus_Game.TINT_COLOR, newColour.red / 255, newColour.green / 255, newColour.blue / 255, newColour.alpha / 255)
            if not IsNull(pillar) then
                pillar:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, newColour.alpha / 255)
                pillar:SetMaterialParam(Lotus_Game.TINT_COLOR, newColour.red / 255, newColour.green / 255, newColour.blue / 255, newColour.alpha / 255)
            end
            if not IsNull(extraEffect) then
                extraEffect:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, newColour.alpha / 255)
                extraEffect:SetMaterialParam(Lotus_Game.TINT_COLOR, newColour.red / 255, newColour.green / 255, newColour.blue / 255, newColour.alpha / 255)
            end
            Sleep(0)
        end
    end
    
end

function TerritoryHackAction(action, instigator)
    if gRegion:IsMaster() then
        if not IsNull(instigator) and not instigator:IsKilled() then
            instigator:GetAgent():StopScriptedMode()
            territoryTrigger:SetCaptureProgress(-1)            
        end
    end    
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end
