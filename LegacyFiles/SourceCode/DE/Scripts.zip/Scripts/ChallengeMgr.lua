tag = Symbol()
value = 0

function NotifyChallengeMgrTag()
    local player = gRegion:GetLocalPlayer()
    if not IsNull(player) then
        gChallengeMgr:NotifyTag(player, tag)
    end
end

function NotifyChallengeMgrValue()
    local player = gRegion:GetLocalPlayer()
    if not IsNull(player) then
        gChallengeMgr:NotifyTag(player, tag, value)
    end
end

--added for triggering achievements on individual players that enter a trigger
function NotifyChallengeMgrOnEntityEnter(avatar)
    if not IsNull(avatar) and avatar:IsA(gBaseAvatarType) then
        local player = avatar:GetPlayer()
        if not IsNull(player) then
            gChallengeMgr:NotifyTag(player, tag)
        end
    end
end