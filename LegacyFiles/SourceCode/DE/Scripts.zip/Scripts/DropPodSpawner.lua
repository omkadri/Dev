dropSpawnPod = Instance()
dropPodPreSpawnAnim = Resource()
dropAttachBone = Symbol()
dropPodSpawnScript = Instance()
dropPodLandEffect = Resource()
dropAttachOffset = Vector()
dropAttachRotation = Rotation()

dropFriendlyEffect = Type()

dropAgentType = Type()
hackActionType = Type()
chance = 0.25

EffectsDebug = false



function dropSpawnerDrop()
    dropSpawnPod:FirePort("Show")
    dropSpawnPod:PlayAnimation(dropPodPreSpawnAnim, true, false, 0) 
    Sleep(.01)
    -- Create Effect
    local effect = gRegion:CreateEntity(dropPodLandEffect, ZERO_VECTOR, ZERO_ROTATION)
    dropSpawnPod:AttachEntity(effect, dropAttachBone, ZERO_VECTOR, ZERO_ROTATION)
    print("Drop Effect Spawned")
    
    -- Hide Pod
    effect:Unattach()
    dropSpawnPod:FirePort("Hide")
    effect:FirePort("Enable")
    dropSpawnPod:Destroy()
end

function onDropSpawned(agent)
    if not IsNull(agent) then        
        dropPodSpawnScript:FirePort("Execute")
        agent:SetAllExits(false)
        local avatar = agent:GetAvatar()
        avatar:SetVisibility(false)
        avatar:AttachTo(dropSpawnPod, dropAttachBone)
        --avatar:SetAttachLocalSpace(ZERO_VECTOR, ZERO_ROTATION)
        avatar:SetAttachLocalSpace(dropAttachOffset, dropAttachRotation)

        Sleep(1)
        
        avatar:Unattach()
        avatar:SetVisibility(true)
        agent:SetAlert()
        agent:ReturnToAiControl()
    end
end

function SpawnForPlayer(instigator, selection, this)

    if selection <= 0 then
        return
    end

    local npcMgr = gRegion:GetNpcMgr()
    local aiDir = npcMgr:GetAiDirector()
    local spawnPoint = gRegion:FindNearest(gNpcSpawnPointType, this:GetPosition(), 1)
    
    local agent = aiDir:CreateAgent(dropAgentType, spawnPoint, instigator:GetFaction())
    
    if IsNull(agent) then
        print("DropSpawner.lua::SpawnForPlayer - Failed to create agent")
        return
    end
    
    local avatar = agent:GetAvatar()
    avatar:SetSpawnedByAvatar(instigator)
    avatar:Attach(dropFriendlyEffect, EMPTY_SYMBOL)
    agent:AddOrder(Symbol("StormTarget"), instigator) -- Follow player
    
    this:Disable()
end

function RandomChanceToEnable(this)
    local randNum = Random(0,1)
    if randNum <= chance then
        local rot = this:GetRotation()
        rot.heading = rot.heading + 180
        local action = this:Attach(hackActionType, EMPTY_SYMBOL, Vector(0,0,1.5), Rotation(180,0,0))
        local t = 1
        local sign = 1
        while action:IsEnabled() do
            this:SetMaterialParam(Lotus_Game.EMISSIVE_MAP_ATTEN, Lerp(0,1,t))
            t = t + sign * DeltaTime()
            if t > 1 then
                t = 1
                sign = sign * -1
            elseif t < 0 then
                t = 0
                sign = sign * -1
            end
            Sleep(0)
        end
        this:SetMaterialParam(Lotus_Game.EMISSIVE_MAP_ATTEN, 1)
    end
end


