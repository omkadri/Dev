startEffect = Type()
completedEffect = Type()
totalHealth = 15000

function AnimatewithDamageTaken(deco)
--Lotus Effect Deco animates when it takes damage
    deco:GetRegionMgr():CreateEntity(startEffect, deco:GetSimPosition(), ZERO_ROTATION)

    local animAtten = SmoothFloat(0.0, 0.2)
    local timerSinceLastUpdate = 2
    local oldDelta = 0
    while not IsNull(deco) do
        local x = deco:GetHealth() / totalHealth
        x = Clamp(0, 1, 1 - x)
        animAtten:SetTargetVal(x)
        animAtten:Update(DeltaTime())
        local newDelta = animAtten:GetVal()
        if math.abs(newDelta - oldDelta) > 0.001 then
            deco:SetAnimDelta(0, 0.99 * newDelta)
            timerSinceLastUpdate = 2
            oldDelta = newDelta
        else
            timerSinceLastUpdate = timerSinceLastUpdate - DeltaTime()
        end
        
        --Loop this script until no more updates are needed.
        --Expose GetAnimDelta so we can discontinue the script if not used
        if newDelta > 0.99 then --or timerSinceLastUpdate < 0 then
            deco:GetRegionMgr():CreateEntity(completedEffect, deco:GetSimPosition(), ZERO_ROTATION)
            return
        end
        Sleep(0)
    end
end