-- This is for the Kela Boss fight script
kelaAvType = WeakResource()
jumpInAnim = Resource()
jumpOutAnim = Resource()
teleportFx = Resource()
shockType = Type()
phaseOneThreshold = 0.70
phaseTwoThreshold = 0.40
--grapplePointType = WeakResource()
outerCatwalkController = Instance() --portforwarder
innerCatwalkController = Instance() --portforwarder
arenaLightsOn = Instance()
arenaLightsOff = Instance()

videoTrig = Instance()
--videoController = Instance() --script trigger
doorHint = Instance()
entryPlateTriggers = { Instance() }
cinematic = Instance()
targetObjectTag = Symbol()
targetObjects = { Instance() }
portToFire = String() --no spaces

--Transmissions
barkIntervalMin = 30
barkIntervalMax = 45
introTransmissions = { Resource() }
phaseOneTransmissions = { Resource() }
phaseTwoTransmissions = { Resource() }
phaseThreeTransmissions = { Resource() }
breakOneTransmissions = { Resource() } --1st is enter room, 2nd is taunts, 3rd is leaving room
breakTwoTransmissions = { Resource() }
kelaNearDeathTransmissions = { Resource() }
kelaDeathTransmissions = { Resource() }


--Test Vars
incrementTestCount = true
enableGrappling = true

--Roller Pit Spawning
agentType = Type()
spawnPoints = { Instance() }
rollerVolume = Instance() --trigger
spawningTrigger = Instance() --trigger
spawnLimits = { 8, 10, 12, 16 }
spawnsPerWave = 4
waveDelay = 4
bossArena = true

-- Replicated Variables
local grapplePointType = WeakResource("/Lotus/Types/Enemies/Grineer/Vip/KelaDeThaym/KelaDeThaymHookSecondaryWaypoint")
local videoScriptFinished = false
--local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local UTIL = require "EE.Interface.Utilities"
local gameRules = gGameRules
local npcManager = gRegion:GetNpcMgr()
local aiDir = gRegion:GetNpcMgr():GetAiDirector()
local NV_KELA_FIGHT_STAGE = Symbol("KelaFightStage")
local DAMAGE_MODIFIER = Symbol("KelaController")

-- ===========================================================================
local function CleanUpKela(instigatorAvatar)
    --Destroy lingering Grapple effects
    -- local effects = instigatorAvatar:GetAllAttachments(gEffectType)
    -- for i=1, #effects do
        --effects[i]:Destroy()
    -- end

    --Stop custom movement
    instigatorAvatar:MotionControl():CancelCustomMovement()
    
    --Cancel any warping animation movement
    instigatorAvatar:CancelActionEndPosRot()

    --Stop any powersuit ability (ie grappling / wallrunning) 
    local suit = instigatorAvatar:InventoryControl():GetActivePowerSuit()
    if not IsNull(suit) then
        suit:DeactivateAbilityAndNotifyClients()
    end

    --Restore normal gravity
    instigatorAvatar:SetDisableGravity(false)    
end

local function UpdateJumpPoints(enable, jumpPoints)
    if enable then
        print("     Enabling all jump points")
        for i = 1, #jumpPoints do
            jumpPoints[i]:FirePort("Enable")
        end
    else
        print("     Disabling all jump points")
        for i = 1, #jumpPoints do
            jumpPoints[i]:FirePort("Disable")
        end
    end
end


local function KelaTeleport(telePos, lookPos, avatar, enterArena, jumpPoints)
    print("             Teleporting Kela") 
    local players = gRegion:GetHumanPlayers()
    local agent = avatar:GetAgent()
    
    local targetAvatar = nil
    for i = 1, #players do
        if not IsNull(players[i]) then
            targetAvatar = players[i]:GetAvatar()
            if not IsNull(targetAvatar) then
                break
            end
        end
    end
    
    if not enterArena and gRegion:IsMaster() then
        avatar:DamageControl():RemoveAllProcs()
        agent:SetTarget(targetAvatar) --put her into scripted mode
        avatar:InventoryControl():EnableWeaponFiring(false)
        UpdateJumpPoints(false, jumpPoints)
    end
    
    local objMarker = gRegion:FindNearestTagged(Symbol("ObjectiveMarker"), avatar:GetPosition())
    if not IsNull(objMarker) then
        objMarker:Disable()
    end

    Sleep(0)
    gRegion:CreateEntity(teleportFx, avatar:GetPosition(), ZERO_ROTATION, avatar)
    avatar:PlayAnimation(jumpOutAnim, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_FREEZE, true, 0.6)
    avatar:SuspendScriptUntilAnimEvent("JumpAirborne", 1.0)
    avatar:SetVisibility(false)

    Sleep(0)
    if gRegion:IsMaster() then
        CleanUpKela(avatar)
        avatar:Teleport(telePos, LookTo(telePos, lookPos))
    end

    avatar:PlayAnimation(jumpInAnim, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_ONCE, true)
    Sleep(0.1)
    avatar:SetVisibility(true)
    avatar:SuspendScriptUntilAnimEvent("JumpLanded", 1.0)
    gRegion:CreateEntity(shockType, avatar:GetPosition(), ZERO_ROTATION, avatar)
    
    if enterArena and gRegion:IsMaster() then
        agent:StopScriptedMode()
        avatar:InventoryControl():EnableWeaponFiring(true)
        UpdateJumpPoints(true, jumpPoints)
    end
    
    if enterArena then
        if not IsNull(objMarker) then
            objMarker:Enable()
        end
    end
    
end

local function CheckKelaPos(avatar, hidePos, lookPos, enterArena, jumpPoints)
    if avatar:DistanceToPoint(hidePos) > 6 then
        print("     Kela didn't make it into the control room. Trying again.")
        if not IsNull(avatar) then
            KelaTeleport(hidePos, lookPos, avatar, enterArena, jumpPoints)
        end
    end
end

local function StepFightStage(stage)
    stage = stage + 1
    print("Advancing Kela fight stage to ", stage)
    gGameRules:SetNetPersistentVar(NV_KELA_FIGHT_STAGE, stage)
    return stage
end

local function UpdateGrapplePoints(enable, grapplePoints)
    if enable then
        for i = 1, #grapplePoints do
            grapplePoints[i]:FirePort("Enable")
        end
    else
        for i = 1, #grapplePoints do
            grapplePoints[i]:FirePort("Disable")
        end
    end
end

function OnEnded(videoTrig)
    videoScriptFinished = true
end

local function IsKelaStanding(kelaAvatar, stage)
    local kelaStanding = false
    if stage < 6 then
        kelaStanding = not kelaAvatar:IsPreDeath()
    elseif kelaAvatar:GetHealth() > 0 then
        kelaStanding = true
    end
    
    return kelaStanding
end

local function SetCombatState(kelaAvatar, dmgThreshold, nextDmgThreshold, kHealthMax, stage)

    kelaAvatar:DamageControl():SetPreDeathHealthPortion(dmgThreshold)
    kelaAvatar:DamageControl():RemoveShieldHealthDamageModifier(DAMAGE_MODIFIER)
    
    if stage == 6 then
        kelaAvatar:DamageControl():SetPreDeathEnabled(false)
    end
    
    --local barkInterval = Random(barkIntervalMin, barkIntervalMax)
    local barkInterval = 35
    local barkTimer = 0
    local barkHealthThreshold = 0.15
    _T.KelaNearDeath = false
    _T.KelaNearDeathPlayed = false
    
    local kelaStanding = IsKelaStanding(kelaAvatar, stage)

    while IsKelaStanding(kelaAvatar, stage) do
        if barkTimer >= barkInterval and not _T.KelaNearDeathPlayed then
            videoTrig:FirePort("Execute")
            barkTimer = 0
            barkInterval = Random(barkIntervalMin, barkIntervalMax)
        end
        
        --throttle the barking when health gets low
        local kelaHealth = kelaAvatar:GetHealth()
        if not _T.KelaNearDeathPlayed and ( kelaHealth / kHealthMax <= barkHealthThreshold ) then
            _T.KelaNearDeath = true
            _T.KelaNearDeathPlayed = true
            videoTrig:FirePort("Execute")
        end
        
        barkTimer = barkTimer + DeltaTime()
        Sleep(0)
    end
    
    if stage < 6 then --make her immune and set her next pre-death threshold. Don't need to do this in final stage
        kelaAvatar:DamageControl():AddShieldHealthDamageModifier(DAMAGE_MODIFIER, Engine.DT_ANY, Engine.ANY_PART, Engine.DHT_NONE, 0.0)
        local newHealth = dmgThreshold * kHealthMax
        kelaAvatar:SetHealth( dmgThreshold * kHealthMax )
    end
    
    stage = StepFightStage(stage)  --stage 0->1
    return stage
end

function BossLogic(entity)
    print("Kela boss logic started")
    while not gRegion:IsMaster() do
        Sleep(1)
    end
    
    _T.PlayTaunts = false
    
    if not _T.InWorldTransmissionQueue then
        _T.InWorldTransmissionQueue = {}
    end
    
    if not IsNull(arenaLightsOn) then
        arenaLightsOn:FirePort("TriggerPort")
    end
    
    ObjectPortHandler(videoTrig, "OnEnded")


    while IsNull(gameRules) do
        Sleep(0)
        gameRules = gGameRules
    end
   
    
    local entityPos = entity:GetPosition()
    local kelaAvatar = gRegion:FindNearest(kelaAvType, entityPos)
    
    print("Kela Boss logic waiting on Kela avatar to spawn before continuing")
    while IsNull(kelaAvatar) do
        kelaAvatar = gRegion:FindNearest(kelaAvType, entityPos)
        Sleep(0)
    end
    
    print("     Kela fight started")
    local kHealthMax = kelaAvatar:GetMaxHealth()
    local jumpPoints = gRegion:FindTagged(Symbol("KelaJump"))
    local stage = gGameRules:GetNetPersistentVar(NV_KELA_FIGHT_STAGE, 0)
    local hidePos = gRegion:FindNearestTagged(Symbol("EntrancePoint"), entityPos):GetPosition()
    local lookPos = gRegion:FindNearestTagged(Symbol("CenterPlatform"), entityPos):GetPosition()
    local attackPos = gRegion:FindNearestTagged(Symbol("CenterPlatform"), entityPos):GetPosition()    
    
    -- fight kela until her health hits the first threshold
    if stage <= 0 then
        print("     Kela fight stage 0")
        stage = SetCombatState(kelaAvatar, phaseOneThreshold, phaseTwoThreshold, kHealthMax, stage)
    end
    
    -- teleport Kela out to control room to activate first arena modifier.
    if stage <= 1 then
        Broadcast("KELA MOVING TO CONTROL ROOM")
        print("     Kela jumps into the control room")
        
        if not IsNull(kelaAvatar) then
            KelaTeleport(hidePos, lookPos, kelaAvatar, false, jumpPoints)
        end
        
        --turn off lights and start stage break stuff
        if not IsNull(arenaLightsOff) then
            arenaLightsOff:FirePort("TriggerPort")
        end
        
        if not IsNull(videoTrig) then
            videoTrig:FirePort("Execute")
        end
        
        videoScriptFinished = false
        while not videoScriptFinished do
            --if kela is not in control room, try to put her there again
            CheckKelaPos(kelaAvatar, hidePos, lookPos, false, jumpPoints)
            Sleep(2)
        end
        
        Sleep(1.5)
        stage = StepFightStage(stage)
    end
    
    --bring Kela back into the arena
    if stage <= 2 then
        Broadcast("KELA RETURNING TO ARENA")
        print("     Kela jumping back into the arena")
        
        if not IsNull(kelaAvatar) then
            KelaTeleport(attackPos, lookPos, kelaAvatar, true, jumpPoints)
        end
        
        if not IsNull(arenaLightsOn) then
            arenaLightsOn:FirePort("TriggerPort")
        end
        
        stage = StepFightStage(stage)
    end
    
    --Fight Kela until she reaches 2nd health threshold
    if stage <=3 then
        print("     Kela fighting in the arena")
        
        entity:ScriptRunChildScript(Symbol("GrappleManager"), false)
        
        stage = SetCombatState(kelaAvatar, phaseTwoThreshold, -1, kHealthMax, stage)
    end
    
    --Move Kela to control room to activate next Arena modifier
    if stage <= 4 then
        Broadcast("KELA MOVING TO CONTROL ROOM")
        print("     Kela jumps back into the control room")

        if not IsNull(kelaAvatar) then
            KelaTeleport(hidePos, lookPos, kelaAvatar, false, jumpPoints)
        end
        
        --turn off lights and start stage break stuff
        if not IsNull(arenaLightsOff) then
            arenaLightsOff:FirePort("TriggerPort")
        end
        
        if not IsNull(videoTrig) then
            videoTrig:FirePort("Execute")
        end
        
        videoScriptFinished = false

        while not videoScriptFinished do
            CheckKelaPos(kelaAvatar, hidePos, lookPos, false, jumpPoints)
            Sleep(2)
        end
        
        Sleep(1.5)
        
        stage = StepFightStage(stage)
    end
    
    --Bring Kela back into the Arena
    if stage <= 5 then
        Broadcast("KELA RETURNING TO ARENA")
        print("     Kela jumping back into the arena")
        
        if not IsNull(kelaAvatar) then
            KelaTeleport(attackPos, lookPos, kelaAvatar, true, jumpPoints)
        end     
        
        if not IsNull(arenaLightsOn) then
            arenaLightsOn:FirePort("TriggerPort")
        end
        
        stage = StepFightStage(stage)
    end
    
    --fight Kela to the death
    if stage <= 6 then
        print("     Kela fighting in the arena")
        
        entity:ScriptRunChildScript(Symbol("GrappleManager"), false)
        stage = SetCombatState(kelaAvatar, -1, -1, kHealthMax, stage)
    end
    
    --turn off lights and play death transmission, and unlock exit door
    if not IsNull(arenaLightsOff) then
        arenaLightsOff:FirePort("TriggerPort")
    end
    
    if not IsNull(videoTrig) then
        videoTrig:FirePort("Execute")
    end
    
    if not IsNull(doorHint) then
        doorHint:FirePort("Unlock")
    end
    
    
    Sleep(15)
    gameRules:SetNetPersistentVar(Symbol("KelaFight"), 0)
    aiDir:SetEnableAutoSpawns(true)
end

--Manage state of the grapple points to get Kela mixing it up between grappling and jumping
function GrappleManager()
    print("             RUNNING GRAPPLE MANAGER")
    local grapplePoints = gRegion:FindAll(grapplePointType, Vector(), 0, FLT_MAX)
    local kelaAvatar = gRegion:FindNearest(kelaAvType, Vector(), FLT_MAX)
    
    local minOnTime = 30
    local maxOnTime = 45
    local minOffTime = 10
    local maxOffTime = 25
    local timer = 0
    local grappleEnabled = false
    
    while not IsNull(kelaAvatar) and not kelaAvatar:IsPreDeath() do

        if timer <= 0 then
            if grappleEnabled then
                print("         DISABLING GRAPPLE POINTS")
                UpdateGrapplePoints(false, grapplePoints)
                timer = Random(minOffTime, maxOffTime)
                grappleEnabled = false
            else
                print("         ENABLING GRAPPLE POINTS")
                UpdateGrapplePoints(true, grapplePoints)
                timer = Random(minOnTime, maxOnTime)
                grappleEnabled = true
            end
        end
        
        timer = timer - DeltaTime()
        
        Sleep(0)
    end
    
    UpdateGrapplePoints(false, grapplePoints)
    print("         DISABLING GRAPPLE POINTS, EXITING GRAPPLE MANAGER")
end

function EntryButtons(entity)
    _T.buttonCount = 0 
    _T.multiplayerChallenge = true
    local players = gRegion:GetHumanPlayerAvatars()
    _T.playerCount = #players
    _T.DebugCount = 0
    
    local oldPlayerCount = _T.playerCount
    local diff = #entryPlateTriggers - _T.playerCount

    if diff > 0 then
        for i = 1, diff do
            entryPlateTriggers[i]:FirePort("Disable")
        end
    end
    
    while _T.buttonCount < _T.playerCount do
        
        --check the # players. Enable/disable pressure plates to match player count if it changed.
        oldPlayerCount = _T.playerCount
        players = gRegion:GetHumanPlayerAvatars()
        
        if  _T.DebugCount == 0 then
            _T.playerCount = #players
        else
            _T.playerCount = _T.DebugCount
        end
        
        if _T.playerCount > oldPlayerCount then --activate new pads
            print("         PLAYER COUNT INCREASED. ACTIVATING NEW PADS")
            diff = _T.playerCount - oldPlayerCount
            for i = 1, #entryPlateTriggers do
                if not entryPlateTriggers[i]:IsEnabled() and diff > 0 then
                    entryPlateTriggers[i]:FirePort("Enable")
                    diff = diff - 1
                end
            end
        elseif _T.playerCount < oldPlayerCount then --deactivate pads
            print("         PLAYER COUNT DECREASED. DEACTIVATING PADS")
            diff = oldPlayerCount - _T.playerCount
            for i = 1, #entryPlateTriggers do
                if entryPlateTriggers[i]:IsEnabled() and diff > 0 then
                    entryPlateTriggers[i]:FirePort("Disable")
                    diff = diff - 1
                end
            end
        end
        Sleep(0)
    end
    
    local testLevel = false
    for i = 1, #entryPlateTriggers do
        entryPlateTriggers[i]:FirePort("Disable")
    end
    if not testLevel then
        gRegion:FindFirstTagged(Symbol("DamageRollers")):FirePort("Enable")
        
        Sleep(1)
        
        cinematic:FirePort("StartPlaying")
        
    end
end

function PlayerTeleport()
    local players = gRegion:GetHumanPlayerAvatars()
    local waypoints = gRegion:FindTagged(Symbol("TeleportDest"))
    --Sleep(0)
    for i = 1, #players do
        players[i]:Teleport(waypoints[i]:GetPosition())
        players[i]:SetView(waypoints[i]:GetRotation())
    end
end

function TestButtons(entity)

    if _T.DebugCount == 0 then
        _T.DebugCount = 1
    end
    
    if incrementTestCount then
        _T.DebugCount = math.min(4, (_T.DebugCount + 1))
        print("             DEBUG PLAYER COUNT == " .. _T.DebugCount)
    else
        _T.DebugCount = math.max(1, (_T.DebugCount - 1))
        print("             DEBUG PLAYER COUNT == " .. _T.DebugCount)
    end
end


function TestGrappling(entity)
    local grapplePoints = gRegion:FindAll(grapplePointType, Vector(), 0, FLT_MAX)
    
    if enableGrappling then
        for i = 1, #grapplePoints do
            grapplePoints[i]:FirePort("Enable")
        end
    else
        for i = 1, #grapplePoints do
            grapplePoints[i]:FirePort("Disable")
        end
    end

end

function AvatarHealthScaling(avatar)
    local players = gRegion:GetHumanPlayerAvatars()
    local health = avatar:GetMaxHealth()
    if #players == 1 then
        return
    elseif #players <= 2 then
        health = health * 2
    elseif #players <= 3 then
        health = health * 3
    else
        health = health * 4
    end
    avatar:SetMaxHealth(health, true)
    avatar:SetHealth(health, true)
end

function RollerSpawning(entity)
    --print("             Start spawning Rollers!!")
    
    local rollerLevel = gameRules:GetMission().maxEnemyLevel
    
    if rollerLevel == 1 then
        rollerLevel = 30
    end
    
    --print("         Roller Level is: " .. rollerLevel)
    
    if bossArena then 
        local kelaAvatar = gRegion:FindNearest(kelaAvType, entity:GetPosition())

        if IsNull(kelaAvatar) then
            return
        end
    
        local kelaAgent = kelaAvatar:GetAgent()
        local kelaRank = 25
        
        if not IsNull(kelaAgent) then
            kelaRank = kelaAgent:GetCurrentLevel()
        end
        
        local stage = gGameRules:GetNetPersistentVar(NV_KELA_FIGHT_STAGE, 0)
        local rollerLevel
        
        if stage <= 2 then 
            rollerLevel = kelaRank * 0.7
        elseif stage <= 4 then
            rollerLevel = kelaRank * 0.9
        elseif stage <= 6 then
            rollerLevel = kelaRank * 1.1
        else
            rollerLevel = kelaRank * 1.3
        end
    end
    
    --local spawns = gRegion:FindTagged(spawnTag)
    local spawns = spawnPoints
    local avatars = spawningTrigger:GetEntitiesTouching()

    while #avatars > 0 do
        local rollers = rollerVolume:GetEntitiesTouching()
        local spawnLimit = UTIL.Ternary(spawnLimits[#avatars] == nil, spawnLimits[#spawnLimits], spawnLimits[#avatars])
        local spawnCount = math.max(math.min(spawnLimit - #rollers, #avatars * spawnsPerWave), 0)
        for i = 1, spawnCount do
            local sPoint = spawns[RandomInt(1, #spawns)]
            local prevPoint
        
            while sPoint == prevPoint do
                sPoint = spawns[RandomInt(1, #spawns)]
                Sleep(0)
            end
            local agent = npcManager:CreateAgentAtPosition(agentType, sPoint:GetPosition(), sPoint:GetRotation(), Symbol("RandomTeam"), rollerLevel, true)
            agent:SetAlert()
        
            prevPoint = sPoint
        end
        Sleep(waveDelay)
        avatars = spawningTrigger:GetEntitiesTouching()
    end
end

function DisableSpawning()
    gameRules:SetNetPersistentVar(Symbol("StopNormalTransmissions"), 1)
    gameRules:HideGameSession(true)
    aiDir:SetEnableAutoSpawns(false)
end

function KelaPitTeleport(entity)
    if not IsNull(entity) then
        local entityPos = entity:GetPosition()
        local kelaAvatar = gRegion:FindNearest(kelaAvType, entityPos)
        local platformEntities = gRegion:FindTagged(Symbol("KelaJump"))
        local target = platformEntities[RandomInt(1, #platformEntities)]
        
        if IsNull(target) then
            target = gRegion:FindFirstTagged(Symbol("CenterPlatform"))
        end
        
        while not target:IsEnabled() do
            target = platformEntities[RandomInt(1, #platformEntities)]
            Sleep(0)
        end

        if not IsNull(kelaAvatar) and not IsNull(target) then
            local targetPos = target:GetPosition()
            KelaTeleport(targetPos, targetPos, kelaAvatar, true)
        end
    end
end

local kelaVoiceBox = Resource("/Lotus/Sounds/Dialog/Rathuum/KelaBarks/KelaDeThaymVoicebox")
local function PlayWorldTrans(transList, randomize, playSequence, playTaunts, portforwarder, startDelay, endDelay)
    print("         playing transmission")
    Sleep(0.1)
    
    local kelaAvatar = gRegion:FindNearest(kelaAvType, Vector(), FLT_MAX)
    if not IsNull(kelaAvatar) then
        kelaAvatar:SetVoiceBox(nil)
    end
    
    if randomize then
        table.insert(_T.InWorldTransmissionQueue, transList[RandomInt(1, #transList)])
    else
        table.insert(_T.InWorldTransmissionQueue, transList[1])
    end

    Sleep(startDelay)
    
    if not IsNull(portforwarder) then
        portforwarder:FirePort("TriggerPort")
    end
    
    if playTaunts then
        
        local delay = 10
        local curInt = RandomInt(2, (#transList - 1)) -- taunts are all in the list except first and last
        local prevInt
        
        while _T.MortarsActive do
            delay = delay - DeltaTime()
            if delay <= 0 then
                curInt = RandomInt(2, (#transList - 1))
                table.insert(_T.InWorldTransmissionQueue, transList[curInt])
                prevInt = curInt
                delay = Random(15, 30)
            end
            Sleep(0)
        end
    end
    
    
    --play the last transmission in the list
    if playSequence and not IsNull(_T.InWorldTransmissionQueue) then
        table.insert(_T.InWorldTransmissionQueue, transList[#transList])
    end
    
    Sleep(endDelay)
    
    if not IsNull(kelaAvatar) then
        kelaAvatar:SetVoiceBox(kelaVoiceBox)
    end
    
    print("     Exiting World Trans")
end

function CinematicTransmission()
    
    if not _T.InWorldTransmissionQueue then
        _T.InWorldTransmissionQueue = {}
    end
    Sleep(0.1)
    
    local stage = gameRules:GetNetPersistentVar(NV_KELA_FIGHT_STAGE)
    local playTaunts = false
    local pForwarder = nil
    local startDelay = 5
    local endDelay = 1
    local randomize = false
    local playSequence = false
    local transmissions = introTransmissions

    if cinematic:IsPlaying() then
        playTaunts = false
        pForwarder = nil
        startDelay = 5
        endDelay = 5
        randomize = false
        playSequence = false
    elseif stage == 0 then --barks while fighting
        transmissions = phaseOneTransmissions
        randomize = true
        playTaunts = false
        playSequence = false
        pForwarder = nil
        startDelay = 0
        endDelay = 5
    elseif stage == 1 then
        transmissions = breakOneTransmissions
        randomize = false
        playTaunts = true
        playSequence = true
        pForwarder = outerCatwalkController
        startDelay = 3
        endDelay = 5
    elseif stage == 3 then --barks while fighting
        transmissions = phaseTwoTransmissions
        randomize = true
        playTaunts = false
        playSequence = false
        pForwarder = nil
        startDelay = 0
        endDelay = 5
    elseif stage == 4 then
        transmissions = breakTwoTransmissions
        randomize = false
        playTaunts = true
        playSequence = true
        pForwarder = innerCatwalkController
        startDelay = 3
        endDelay = 5
    elseif stage == 6 then --barks while fighting
        if _T.KelaNearDeath then
            transmissions = kelaNearDeathTransmissions
            _T.KelaNearDeath = false
            randomize = false
        else
            transmissions = phaseThreeTransmissions
            randomize = true
        end
        playTaunts = false
        playSequence = false
        pForwarder = nil
        startDelay = 0
        endDelay = 5
    elseif stage > 6 then --barks on kela death
        transmissions = kelaDeathTransmissions
        randomize = false
        playTaunts = false
        playSequence = false
        pForwarder = nil
        startDelay = 0
        endDelay = 0
    end
    
    PlayWorldTrans(transmissions, randomize, playSequence, playTaunts, pForwarder, startDelay, endDelay)

end

function FirePorts()

    local taggedDecos = gRegion:FindTagged(targetObjectTag)
    
    if not IsNull(taggedDecos) then
        for i = 1, #taggedDecos do
            taggedDecos[i]:FirePort(portToFire)
        end
    end 

    if not IsNull(targetObjects) then
        for i = 1, #targetObjects do
            targetObjects[i]:FirePort(portToFire)
        end
    end

end

function KelaSpawn(agent)
    local avatar = agent:GetAvatar()
    avatar:SetVisibility(false)
    avatar:PlayAnimation(jumpInAnim, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_ONCE, true)
    Sleep(0.1)
    avatar:SetVisibility(true)
    avatar:SuspendScriptUntilAnimEvent("JumpLanded", 3.0)
    gRegion:CreateEntity(shockType, avatar:GetPosition(), ZERO_ROTATION, avatar)
end
