soundResource = Resource()
playMiniGame = true
paralyzedInfo = Type()
knockToGroundInfo = Type()
droppedInfo = Type()
getUpInfo = Type()
carriedSpawnPoint = Instance()
carrierSpawnPoint = Instance()
carriedSpawnControl = Instance()
carrierSpawnControl = Instance()

function ScriptedAttach(scriptTrigger, avatar)
    local carried
    local carrier
    
    if not IsNull(carriedSpawnPoint) then
        carried = carriedSpawnPoint:GetActiveAvatar()
    elseif not IsNull(carriedSpawnControl) then
        local activeAvatarArray = carriedSpawnControl:GetActiveAvatars()
        if not IsNull(activeAvatarArray) and #activeAvatarArray > 0 then
            carried = activeAvatarArray[1]
        end
    end

    
    if not IsNull(carrierSpawnPoint) then
        carrier = carrierSpawnPoint:GetActiveAvatar()
    elseif not IsNull(carrierSpawnControl) then
        local activeAvatarArray = carrierSpawnControl:GetActiveAvatars()
        if not IsNull(activeAvatarArray) and #activeAvatarArray > 0 then 
            carrier = activeAvatarArray[1]
        end
    end

    if not IsNull(carrier) then
        local agent = carrier:GetAgent()
        if not IsNull(agent) then
            local carryAction = carried:GetCarryAction()
            agent:UseContextAction(carryAction, false)
        end         
    end 
end

function Attach(contextAction, avatar)
    if not IsNull(soundResource) then
        if _T.PickUpPlayed ~= true then
            avatar:PlaySound(soundResource, false)
            _T.PickUpPlayed = true
        end
    end

    --if not IsNull(ObjectiveMarker) then
    --  local ObjectiveWayPoints = gRegion:FindTagged(ObjectiveTag)
    --  if not IsNull(ObjectiveWayPoints) then
    --      gRegion:CreateEntity(ObjectiveMarker, ObjectiveWayPoints[1]:GetPosition(), ObjectiveWayPoints[1]:GetRotation())
    --  end
        
    --end   
    
    print("Attach!")
    if not IsNull(contextAction) then
        local otherAvatar = contextAction:GetAttachParent()
        avatar:CarryAvatar(otherAvatar,Symbol("GAME_C1_ROOT"))
    end
    
end

function PutBuddyOnBed(contextAction, avatar)
    avatar:ScriptPlaceBuddyOnBed(playMiniGame)
end

function GetOffBed(avatar)
    avatar:ScriptGetOffBed()
end

function AttachInitialize(avatar)
    print("Avatar being paralyzed, going to downed firing state!")
    avatar:SetNeedsToBeCarried(true, paralyzedInfo)
end

function AttachInitializeNpcOnSpawn(agent)
    local avatar = agent:GetAvatar()
    avatar:SetNeedsToBeCarried(true, paralyzedInfo)
end

function AttachInitializeToDropped(avatar)
    print("Avatar being paralyzed, going to dropped state!")
    avatar:SetNeedsToBeCarried(true, droppedInfo)
end

function KnockDown(avatar)
    print("AVATAR BEING KNOCKED DOWN")
    if avatar:ReplicaLocallyControlled() then
        avatar:SetNeedsToBeCarried(true, knockToGroundInfo)
    end
end

function Drop(contextAction, avatar)
    print("Dropping Avatar!")
    avatar:DropAvatar()
end

function Recover(player)
    print("Recover From Carrying")
    player:SetNeedsToBeCarried(false, getUpInfo)
end

function DropRedshirtInit(agent)
    local avatar = agent:GetAvatar()
    avatar:SetNeedsToBeCarried(true, droppedInfo)
end
