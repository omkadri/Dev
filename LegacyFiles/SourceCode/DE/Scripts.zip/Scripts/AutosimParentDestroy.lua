parentColorChange = Color()
materialForSlot = {Resource()}
removeOverride = false

function FireDestroyOnParent(self)

    local parent = self:GetAttachParent()
    if IsNull(parent) then
        return
    end
    parent:FirePort("Destroy")

end

function ChangeParentTint(target)


    if IsNull(target) then
        return
    end
    target:SetMaterialParam(Lotus_Game.TINT_COLOR, parentColorChange.red, parentColorChange.blue, parentColorChange.green, 0.5, true)
    
end

function RemoveParentTint(target)

    if IsNull(target) then
        return
    end
    target:RemoveMaterialParam(Lotus_Game.TINT_COLOR)
    
end

function ChangeEmissiveTint(target)


    if IsNull(target) then
        return
    end
    target:RemoveMaterialParam(Lotus_Game.EMISSIVE_TINT_COLOR)
    target:SetMaterialParam(Lotus_Game.EMISSIVE_TINT_COLOR, parentColorChange.red /255, parentColorChange.blue/255, parentColorChange.green/255, parentColorChange.alpha/255, true)
    
end


function SwapMultipleMaterials(target)
    if IsNull(target) then
        return
    end
    if not removeOverride then
        for i, material in ipairs(materialForSlot) do
            target:SetOverrideMaterial(i-1, material, false)
            
        
        end
    else
        target:RemoveAllOverrideMaterials(false)
    end
end