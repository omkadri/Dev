typeToDestroy = WeakResource()
minDistance = 0
maxDistance = 20

function DestroyType(instigator)

    local position = instigator:GetPosition()
    local objects = gRegion:FindAll(typeToDestroy,position,minDistance,maxDistance)
    
    for i = 1, #objects do
        objects[i]:Destroy()
    end
end

function ContextActionDestroyType(contextAction, instigator)

    local position = instigator:GetPosition()
    local objects = gRegion:FindAll(typeToDestroy,position,minDistance,maxDistance)
    
    for i = 1, #objects do
        objects[i]:Destroy()
    end
end

function DestroyAttachedType(instigator)

    local object = instigator:GetAttachment(typeToDestroy)
    
    if not IsNull(object) then
        object:Destroy()
    end
end
