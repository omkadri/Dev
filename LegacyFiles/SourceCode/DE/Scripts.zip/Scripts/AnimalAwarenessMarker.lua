idleIconColor = Color()
investigatingColor = Color()
combatColor = Color()
canHide = true
modifyContextColor = true
sleepProcSymbol = Symbol("SLEEP_PROC")

local mAgent = nil
local mAvatar = nil
local mMarkerEntity = nil

local function Update(deltaTime)
    if IsNull(mAvatar) or IsNull(mAgent) then
        return
    end

    local awareness = mAvatar:GetAwareness()
    local highestImportance = mAgent:GetHighestTargetImportance()

    local shouldHide = canHide and
    (
        (awareness >= 2) or 
        (highestImportance <= 0) or
        (mAgent:IsPaused(sleepProcSymbol) and mAvatar:DamageControl():IsProcActive(Game.PT_SLEEP))
    )

    if not shouldHide then
        if not mMarkerEntity:IsEnabled() then
            mMarkerEntity:Enable()
        end
        --get awareness thresholds to build appropriate fill rate
        
        local targetColor = nil
        local combatImportanceThreshold = mAgent:GetCombatImportanceThreshold()
        local investigateImportanceThreshold = mAgent:GetInvestigateImportanceThreshold()
        local newImportance = 0

        if awareness == 3 then
            targetColor = combatColor
            newImportance = 1
        elseif awareness == 2 then
            targetColor = investigatingColor
        else
            targetColor = idleIconColor
        end

        if modifyContextColor and (targetColor ~= nil) and targetColor ~= mMarkerEntity:GetContextColor() then
            mMarkerEntity:SetContextColor(targetColor)
        end
        
        newImportance = math.min(math.max(highestImportance - investigateImportanceThreshold, 0.0) / math.max(combatImportanceThreshold - investigateImportanceThreshold,0.01), 1.0)
        mMarkerEntity:SetFillValue(newImportance)
    elseif not IsNull(mMarkerEntity) then
        mMarkerEntity:Disable()
    end
end

function AwarenessMarker(markerEntity)
    mMarkerEntity = markerEntity
    mAvatar = markerEntity:GetAttachParent()
    if IsNull(mAvatar) or not mAvatar:IsA(gBaseAvatarType) then
        return
    end
    mAgent = mAvatar:GetAgent()

    while not IsNull(mAvatar) and not mAvatar:IsKilled() do
        --wait for spawning
        if IsNull(mAgent) then
            mAgent = mAvatar:GetAgent()
            if not IsNull(mAgent) then
                break
            end
        end
        Sleep(1.0)
    end

    local sleepTime = DeltaTime()
    while not IsNull(mAvatar) and not IsNull(markerEntity) do
        sleepTime = DeltaTime()
        Update(sleepTime)
        Sleep(sleepTime)
    end
end