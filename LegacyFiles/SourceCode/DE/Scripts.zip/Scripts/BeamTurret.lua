targetType = WeakResource()
beamType = Type()
projectileType = Type()
damagePerSecond = 100
range = 100
attachType = Type()
faction = Symbol()
spawnPoint = Instance()
defenseTurretType = Type()
defensePointAvatarType = Type()
reloadTime = 1.5

local function FindNearest(instigatorAvatar, targetList)

    local dist = 9999
    local result
    
    for i = 1, #targetList do
        local d = instigatorAvatar:DistanceToEntity(targetList[i])
                
        if d < dist and not instigatorAvatar:IsAvatarFriendly(targetList[i]) then
            dist = d
            result = targetList[i]
        end
    end
    
    return result
end

local function GetTarget(instigatorAvatar, targetList)
    
    if IsNull(instigatorAvatar) then
        return
    end
    
    local target
    local instigatorFaction = instigatorAvatar:GetFaction()

    for i = 1, #targetList do
        if not IsNull(targetList[i]) and not targetList[i]:IsFactionFriendly(instigatorFaction) and 
        not targetList[i]:IsA(gLotusSentinelAvatarType) and 
        not targetList[i]:IsA(gAutoTurretAvatarType) then
            target = targetList[i]
        end
    end
    
    return target

end
local function LocalProjectileTurret(instigatorAvatar, connectedDefensePointAvatar)

    Sleep(0)

    local attachment
    local beam
    
    while IsNull(attachment) do
        attachment = instigatorAvatar:GetAttachment(attachType)
        Sleep(0)
    end
    
    if not IsNull(attachment) then
        --beam = attachment:Attach(beamType, Symbol("GAME_C1_WEAPON1"), Vector(0, 0.9, 0))
    end
    --local av = WeakResource("/Lotus/Types/Enemies/Infested/AiWeek/Quadrupeds/QuadrupedAvatar")
    --/Lotus/Fx/Gameplay/PayloadLaserTurretBeam
    
    while not IsNull(instigatorAvatar) and not IsNull(connectedDefensePointAvatar) do
    
        if instigatorAvatar:GetHealth() <= 0 or connectedDefensePointAvatar:IsKilled() then
            instigatorAvatar:Destroy()
            return
        end
        
        local targets = gRegion:FindAll(targetType, instigatorAvatar:GetPosition(), 0, range)
        --local target = FindNearest(instigatorAvatar, targets)
        local target = GetTarget(instigatorAvatar, targets)
        local turretDamage = damagePerSecond * DeltaTime()
        local proj
        if not IsNull(target) then
        
            --Damage---------------------------------
            --target:Damage(turretDamage)
            
            --Projectile--------------------------------
            if IsNull(proj) then
                proj = gRegion:CreateEntity(projectileType, attachment:GetPosition(), ZERO_ROTATION)
            end
            
            if not IsNull(proj) then
                proj:SetAimRate(250)
                proj:SetTarget(target)
            end
            
            --FX---------------------------------------

        end
    
        Sleep(reloadTime)
    end
    
    if not IsNull(instigatorAvatar) then
        instigatorAvatar:Destroy()
    end

end

local function LocalBeamTurret(instigatorAvatar)

end

function BeamTurret(instigatorAvatar)
    LocalBeamTurret(instigatorAvatar)
end

function ProjectileTurret(instigatorAvatar)

end

function AgentBeamTurret(agent)    
    local avatar = agent:GetAvatar()
    
    if faction:IsValid() then
        avatar:SetFaction(faction)
    end
    
    LocalBeamTurret(avatar)
end

function AgentProjectileTurret(agent)
    local avatar = agent:GetAvatar()
    LocalProjectileTurret(avatar)
end

function ScriptTurret(entity)

    Sleep(0)
    
    local turretAvatar = gRegion:FindNearest(defenseTurretType, entity:GetPosition(), 10)
    
    while IsNull(turretAvatar) do
        turretAvatar = gRegion:FindNearest(defenseTurretType, entity:GetPosition(), 10)
        Sleep(0)
    end
    
    local connectedDefensePoint = gRegion:FindNearest(defensePointAvatarType, turretAvatar:GetPosition(), 30)
    
    while IsNull(connectedDefensePoint) do
        connectedDefensePoint = gRegion:FindNearest(defensePointAvatarType, turretAvatar:GetPosition(), 30)
        Sleep(0)
    end
    
    if faction:IsValid() then
        turretAvatar:SetFaction(faction)
    end
    
    LocalProjectileTurret(turretAvatar, connectedDefensePoint)
end