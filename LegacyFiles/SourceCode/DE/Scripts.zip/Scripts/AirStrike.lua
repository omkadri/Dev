 AirStrikeAction = Type()
 BackUpAction = Type()
 TennoLine = Resource()
 enterprise = Type()
 enterpriseFire = Resource()
 
 
 
function AirStrike()
    local from = Vector()
    local to = Vector()
    local player = gRegion:GetPlayerAvatar()
    local hitPoint = Vector()
    
    local enterpriseAirStrike = gRegion:FindAll(enterprise) 
    --gRegion:Raycast(from, endPoint, player, nil, hitPoint)
    
    local eyePos = player:EyePosition()
    local eyeDir = AngleToDirection(player:GetView())
    local endPoint = eyePos + eyeDir * 100.0 
    local rot = player:GetRotation()
    gRegion:Raycast(eyePos, endPoint, player, nil, hitPoint)
    player:PlaySound(TennoLine,true)
    local enterprisePos = enterpriseAirStrike[1]:GetPosition()
            
    enterpriseAirStrike[1]:SetTargetPos(hitPoint)
    Sleep(3)
    player:PlaySound(enterpriseFire, true)
    Sleep(0.5)
    enterpriseAirStrike[1]:FirePort("SuppressionFire")
    
end

function AttachActions()
    Sleep(1)
    local player = gRegion:GetPlayerAvatar()
    player:Attach(AirStrikeAction, EMPTY_SYMBOL)
    player:Attach(BackUpAction, EMPTY_SYMBOL)
end
