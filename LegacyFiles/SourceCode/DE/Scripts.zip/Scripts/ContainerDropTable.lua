dropTable = Resource()
nightmareModeDropTable = Resource()
survivalDropTable = Resource()
evacDropTable = Resource()
basicDropTable = Resource() -- Simple drop table, no ayatan stars or nav coordinates
placement = Vector()
delay = 0.25

function DropTable(instigator)
    Sleep(delay)
    
    -- Create fx
    if gRegion:IsMaster() then
        local aiDir = gRegion:GetNpcMgr():GetAiDirector()
        local faction = aiDir:GetFaction(0)
        local minLevel = aiDir:GetMinEnemyLevel()
        local maxLevel = aiDir:GetMaxEnemyLevel()
        local level = RandomInt(minLevel,maxLevel)
        local gameRules = gGameRules
        local missionType = gameRules:GetMissionType()

        if (_T.gTutorialMission or _T.useBasicCrateDropTable) and not IsNull(basicDropTable) then
            basicDropTable:GenerateDrops(instigator, faction, level, placement)
        elseif gameRules:IsNightmareMode() and not IsNull(nightmareModeDropTable) then
            nightmareModeDropTable:GenerateDrops(instigator, faction, level, placement)
        elseif missionType == Lotus_Game.MT_SURVIVAL and not IsNull(dropTable) and not IsNull(survivalDropTable) then
            if _T.SurvivalMissionState == 3 then
                survivalDropTable:GenerateDrops(instigator, faction, level, placement)
            else
                dropTable:GenerateDrops(instigator, faction, level, placement)
            end
        elseif missionType == Lotus_Game.MT_EVACUATION and not IsNull(dropTable) and not IsNull(evacDropTable) then
            evacDropTable:GenerateDrops(instigator, faction, level, placement)
        elseif not IsNull(dropTable) then
            dropTable:GenerateDrops(instigator, faction, level, placement)
        end
        _T.idleTimoutReset = true
    end
end

function DropTableSingle(instigator)
    Sleep(delay)

    -- Create fx
    if gRegion:IsMaster() then
        local aiDir = gRegion:GetNpcMgr():GetAiDirector()
        local faction = aiDir:GetFaction(0)
        local minLevel = aiDir:GetMinEnemyLevel()
        local maxLevel = aiDir:GetMaxEnemyLevel()
        local level = RandomInt(minLevel,maxLevel)

        dropTable:GenerateDrops(instigator, faction, level, placement)
        
        _T.idleTimoutReset = true
    end
end

function SpaceDropTableSingle(instigator)
    Sleep(delay)

    -- Create fx
    if gRegion:IsMaster() then
        local aiDir = gRegion:GetNpcMgr():GetAiDirector()
        local faction = aiDir:GetFaction(0)
        local minLevel = aiDir:GetMinSpaceEnemyLevel()
        local maxLevel = aiDir:GetMaxSpaceEnemyLevel()
        local level = RandomInt(minLevel,maxLevel)

        dropTable:GenerateDrops(instigator, faction, level, placement)
        
        _T.idleTimoutReset = true
    end
end


function EidolonScaledDropTable(instigator)
    Sleep(delay)

    -- Create fx
    if gRegion:IsMaster() then
        local aiDir = gRegion:GetNpcMgr():GetAiDirector()
        local faction = aiDir:GetFaction(0)
        local level = aiDir:GetScaledEnemyLevel(instigator:GetPosition())

        dropTable:GenerateDrops(instigator, faction, level, placement)
        
        _T.idleTimoutReset = true
    end
end