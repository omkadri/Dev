introTransmission = Resource()
enRouteTransmission = Resource()



local function GiveTransmission(trans)
    if IsNull(trans) then
        return
    end
    local players = gRegion:GetHumanPlayers()
    if not IsNull(players) then
        for x = 1, #players do
            local avatar = players[x]:GetAvatar()
            if not IsNull(avatar) then
                avatar:GiveItem(trans, true)
            end
        end
    end
end

local function IsVIPAlive()
    local gameRules = gGameRules
    local mission = gameRules:GetMission()
    
    local avatars = gRegion:GetAvatars()
    for i=1,#avatars do
        if not IsNull(avatars[i]) and not avatars[i]:IsKilled() then
            local agent = avatars[i]:GetAgent()
            if not IsNull(agent) and agent:IsA(mission.vipAgent) then
                return true
            end
        end
    end
    return false
end

function Run(gameRules)
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()
    gameRules:SetNetPersistentVar(Symbol("StopNormalTransmissions"), 1)
    
    Sleep(15)
    if not gPromotedToHost then
        if not IsNull(introTransmission) then
            GiveTransmission(introTransmission)
        end
    end
    
    local goalDistance = aiDir:GetLeadPlayerDistance()

    while goalDistance > 250 do
        Sleep(0.5)
        goalDistance = aiDir:GetLeadPlayerDistance()
    end

    if not gPromotedToHost then
        print("     playing enroute transmission")
        GiveTransmission(enRouteTransmission)
    end
end
