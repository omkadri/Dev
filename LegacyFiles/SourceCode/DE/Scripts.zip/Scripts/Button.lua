local pickupGlowAttachment = Type("/EE/Types/Pickups/PickupGlow")

buttons = {Instance()}

local buttonLightColorActivated = Color(254,182,112,255)
local buttonLightColorShootable = Color(112,207,254,255)
hasAssociatedLight = false
--buttonLight = Instance()

local mGameRules

local function DestroyAttachments(button, attachmentType)
    local attachments = button:GetAllAttachments(attachmentType)
    for i = #attachments, 1, -1 do
        attachments[i]:Destroy()
    end
end

function OnDamaged(entity)
    if entity:IsA(gHitProxyType) then
        local button = entity:GetAttachParent()
        button:FirePort("Activate")
    elseif entity:IsA(gGameplayObjectType) then
        entity:FirePort("Activate")
    end
end

local function WaitForGameStarted()
    mGameRules = gGameRules
    while IsNull(mGameRules) do
        Sleep(0)
        mGameRules = gGameRules
    end
    
    while not mGameRules:GameStarted() do
        Sleep(0)
    end
end

function ProxyButton(button)
    local proxy = button:GetAttachment(gHitProxyType)
    while IsNull(proxy) do
        Sleep(0)
        proxy = button:GetAttachment(gHitProxyType)
    end
    
    ObjectPortHandler(proxy, "OnDamaged")
    
    while not IsNull(button) do
        Sleep(0)
    end
end

function DamageButton(button)
    WaitForGameStarted()
    
    ObjectPortHandler(button, "OnDamaged")
    
    while button:IsEnabled() do
        Sleep(0)
    end
end

function DamageButtonOrokin(button)
    WaitForGameStarted()
    
    ObjectPortHandler(button, "OnDamaged")
    
    if button:IsEnabled() and not button:IsActivated() then
        button:MakeVulnerable()
        --button:Attach(pickupGlowAttachment, EMPTY_SYMBOL) -- Attachments already exists initiall on the button type
    elseif not button:IsEnabled() or button:IsActivated() then
        button:MakeInvulnerable()
        DestroyAttachments(button, gDynamicProjectorType)
    end        
    
    local buttonLight
    local lastActive = button:IsActivated()
    while button:IsEnabled() do
        -- Find associated light
        if IsNull(buttonLight) and hasAssociatedLight then
            local buttonLights = gRegion:FindTaggedInRadius(Symbol("ButtonLight"), button:GetPosition(), 0, 5)
            if not IsNull(buttonLights) and #buttonLights > 0 then
                buttonLight = buttonLights[1]
            end
        end        
        
        local active = button:IsActivated()
        if active and not lastActive then
            --button:FirePort("MakeInvulnerable")
            button:MakeInvulnerable()
            DestroyAttachments(button, gDynamicProjectorType)
            lastActive = true
            if not IsNull(buttonLight) then
                buttonLight:SetColor(buttonLightColorActivated)
                buttonLight:SetEffect(0)
            end
        elseif not active and lastActive then
            --button:FirePort("MakeVulnerable")
            button:MakeVulnerable()
            button:Attach(pickupGlowAttachment, EMPTY_SYMBOL)
            lastActive = false
            if not IsNull(buttonLight) then
                buttonLight:SetColor(buttonLightColorShootable)
                buttonLight:SetEffect(5)
            end
        end
        Sleep(0)
    end
    
    if not IsNull(buttonLight) then
        buttonLight:FirePort("TurnOff")
    end
    DestroyAttachments(button, gDynamicProjectorType)
    button:MakeInvulnerable()
end

function AttachShootableOverlays()
    for i, button in ipairs(buttons) do
        button:Attach(pickupGlowAttachment, EMPTY_SYMBOL)
    end
end