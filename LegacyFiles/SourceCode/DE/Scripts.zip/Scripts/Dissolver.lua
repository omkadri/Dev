filterType = Type()
hitEffect = Type()
particleEffect = Type()
soundEffect = Resource()

local function Dissolve(entity)
    if not IsNull(entity) and not IsNull(particleEffect) then
        entity:Attach(particleEffect, Symbol("GAME_C1_ROOT"))
    end
    local d = 0.0
    while not IsNull(entity) and d < 1.0 do
        local t = math.pow(d, 4.0)
        entity:SetDissolve(t)            
        Sleep(0)
        d = d + DeltaTime() * 0.25
    end

    if not IsNull(entity) then
        entity:Destroy()
    end
end

function OnDeath(entity, damageData)
    if IsNull(damageData) or IsNull(entity) or damageData:GetDamageType() ~= Engine.DT_DISSOLVE then
        return
    end

    local ragdoll
    if entity:IsA(filterType) then
        ragdoll = entity
    else
        ragdoll = entity:GetRagdoll()
        if IsNull(ragdoll) or not ragdoll:IsA(filterType) then
            return
        end
    end
    
    if not IsNull(entity) and not entity:IsMaster() then
        gRegion:PlaySound(soundEffect, damageData:GetOrigin(), false)
    end
    
    Dissolve(ragdoll)    
end
