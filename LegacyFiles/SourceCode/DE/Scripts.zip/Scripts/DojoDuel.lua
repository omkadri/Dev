duelingBoundaries = {Instance()}
defaultFaction = Symbol("Tenno")
factions = {String()}
matchesToWin = 2
tennoAvatarType = WeakResource()
duelTriggers = {Instance()}
spawnPoints = {Instance()}
teleportOutFx = Resource()
teleportInFx = Resource()
roundStartForwarder = Instance()
roundDuration = 60
numRounds = 3
roundDelay = 10
playerCounter = Instance()

--audio
roundStartSeq = Instance()
roundEndSeq = Instance()
matchEndSeq = Instance()

roundLostTrans = Type()
roundWonTrans = Type()
duelLostTrans = Type()
duelWonTrans = Type()
duelStartTrans = Type()
suddenDeathTrans = Type()

energyRefillType = Type()
energyRefillStations = {Instance()}
refillDelay = 5
refillTimer = 10

entitiesToDestroy = {WeakResource()}
centralDuelMatDeco = Instance()

waypoint = Instance()

dueling = true

local tables = require "Lotus.Scripts.Libs.TableLib"
local teams = {}
local match = {}
local duelStartPoints = {}
local playerAvs
local specPlayerAvs
local dmgSym = Symbol("DojoInvuln")

local function DestroyEndOfRoundEntities()

    for i = 1, #entitiesToDestroy do
        if not IsNull(entitiesToDestroy[i]) then
            local ents = gRegion:FindAll(entitiesToDestroy[i], centralDuelMatDeco:GetPosition(), 0, 20)
            for i = 1, #ents do
                if not IsNull(ents[i]) then
                    ents[i]:SetVisibility(false, true)
                    ents[i]:Destroy()
                end
            end
        end
    end

end

local function InitializeVarNames(zoneName)
    return zoneName .. "CancelDuel",
            zoneName .. "DuelingTeams",
            zoneName .. "DuelingPlayers",
            zoneName .. "MatchData",
            zoneName .. "TeamData",
            zoneName .. "EntitiesToRemove"
end

--Get player avatars
local function GetPlayerAvatars(getSpectating, duelingPlayersVar)
    local players = {}
    local allPlayers = gRegion:GetHumanPlayers()
    local dueling = false
    
    for i = 1, #allPlayers do
        for k = 1, #_T[duelingPlayersVar] do
            if allPlayers[i] == _T[duelingPlayersVar][k] then
                dueling = true
            end
        end
        if dueling and not getSpectating then
            table.insert(players,allPlayers[i]:GetAvatar())
        elseif not dueling and getSpectating then
            table.insert(players,allPlayers[i]:GetAvatar())
        end
        dueling = false
    end

    return players
end

local function RemoveFromTable(tbl, element)
    for i = 1, #tbl do
        if tbl[i] == element then
            table.remove(tbl, i)
            return
        end
    end
end

local function SubtractTable(tbl, sub)
    local dif = {}
    local count
    for i = 1, #tbl do
        count = 0
        for k = 1, #sub do
            if tbl[i] == sub[k] then
                count = count + 1
            end
        end
        if count < #sub then
            table.insert(dif, tbl[i])
        end
    end
    return dif
end

local function TeleportPlayer(playerAv, location)
    gRegion:CreateEntity(teleportOutFx, playerAv:GetPosition(), playerAv:GetRotation())
    
    if playerAv:GetPlayer():IsLocal() then
        playerAv:Teleport(location.pos, location.rot)
    else
        Sleep(0)
    end
    gRegion:CreateEntity(teleportInFx, location.pos, location.rot)
end

local function SetDamageMultiplierOnAvatars(sym, val, avatars)
    for i = 1,#avatars do
        if not IsNull(avatars[i]) and avatars[i]:IsMaster() then
            local sentinel = avatars[i]:InventoryControl():GetSentinel()
            if val < 1 or val > 1 then
                avatars[i]:DamageControl():AddDamageModifier(sym, Engine.DT_ANY, Engine.ANY_PART, val)
                if not IsNull(sentinel) then
                    sentinel:DamageControl():AddDamageModifier(sym, Engine.DT_ANY, Engine.ANY_PART, val)
                end
            else
                avatars[i]:DamageControl():RemoveDamageModifier(sym)
                if not IsNull(sentinel) then
                    sentinel:DamageControl():RemoveDamageModifier(sym)
                end
            end
        end
    end
end

local function RefillAmmoInSlot(slot, inv)
    local ammoType = inv:GetWeaponInSlot(slot):GetAmmoExType()
    inv:GiveAmmoEx(ammoType, inv:GetMaxAmmoEx(ammoType))
end

local function CullDisconnects()
    
    for i = 1, #teams do
        if not IsNull(teams[i].players) then
            for k = 1, #teams[i].players do
                if IsNull(teams[i].players[k]) then
                    table.remove(teams[i].players, k)
                end
            end
        end
        
        if IsNull(teams[i].players) or #teams[i].players == 0 then
            teams[i].forfeit = true
            match.forfeits = match.forfeits + 1
        end
    end
end

local function DecideRoundWinner(zoneName)
    --round timer expired, winner is whoever has highest percentage HP
    local gameRules = gGameRules
    local winners = {}
    
    CullDisconnects()
    
    if gameRules:GetMissionTimeLeft(Symbol(zoneName)) <= 0 then
        for i = 1, #teams do
            teams[i].totalHealthPerc = 0
            if not IsNull(teams[i].players) then
                for k = 1, #teams[i].players do
                    if not teams[i].players[k]:IsPreDeath() then
                        teams[i].totalHealthPerc = teams[i].totalHealthPerc + teams[i].players[k]:GetHealthPercentage()
                    end
                end
            end
            
            if #winners == 0 or teams[i].totalHealthPerc > teams[winners[1]].totalHealthPerc then
                winners = {i}
            elseif teams[i].totalHealthPerc == teams[winners[1]].totalHealthPerc then
                table.insert(winners, i)
            end
        end
    elseif match.forfeits < #teams then
        local teamIncapCount = 0
        for i, team in ipairs(teams) do
            team.incap = true
            for k = 1, #team.players do
                local isDown = team.players[k]:IsPreDeath()
                team.incap = team.incap and isDown
            end
            if team.incap or team.forfeit then
                teamIncapCount = teamIncapCount + 1
            end
        end
        
        if teamIncapCount >= #teams - 1 then
            local allTeamsIncap = true
            for i, team in ipairs(teams) do
                if not team.incap then
                    allTeamsIncap = false
                    if not team.forfeit then
                        winners = {i}
                    end
                end
            end

            if allTeamsIncap then
                -- All teams incapacitated, it's a draw! Consider all teams winners
                for i, team in ipairs(teams) do
                    table.insert(winners, i)
                end
            end
        end
    end
    
    return winners
end

local function SetFactions(dueling)
    for i, team in ipairs(teams) do
        if not IsNull(team.players) then
            for k, player in ipairs(team.players) do
                local fac
                if dueling then
                    fac = Symbol(team.faction)
                else
                    fac = defaultFaction
                end

                if gRegion:IsMaster() then
                    player:SetFaction(fac)
                end
                local sentinel = player:InventoryControl():GetSentinel()
                if not IsNull(sentinel) then
                    if gRegion:IsMaster() then
                        sentinel:SetFaction(fac)
                    end

                    local sentinelAgent = sentinel:GetAgent()
                    if not IsNull(sentinelAgent) then
                        sentinelAgent:ResetPerceptionTargets()
                        sentinelAgent:ClearOverrideTarget()
                    end
                end
                print("Putting " .. player:GetPlayer():GetPlayerName() .. " on faction " .. fac:c_str() .. "  in zone " .. player:GetZone():GetFullName())
            end
        end
    end
end

local function AvatarCares(avatar, zone)
    return not IsNull(avatar) and not IsNull(avatar:GetZone()) and avatar:GetZone() == zone
end

local function DecideMatchWinner(zone)
    
    local highScore = 0
    local highScoreTeams = {}

    for i = 1, #teams do
        if teams[i].score > highScore and not teams[i].forfeit then
            highScore = teams[i].score
            highScoreTeams = {teams[i]}
        elseif teams[i].score == highScore and not teams[i].forfeit then
            table.insert(highScoreTeams, teams[i])
        end
    end
    
    local playerName
    if #highScoreTeams > 1 then
        --draw
        local localAvatar = gRegion:GetLocalPlayerAvatar()
        if AvatarCares(localAvatar, zone) then
            _T.ShowImpactMessage("/Lotus/Language/Menu/PvpMatchDraw", 5, true, nil, false)
        end
        
        match.roundWinners = teams
    else
        playerName = ""
        local msgDisplayed = false
    
        if #highScoreTeams > 0 and not IsNull(highScoreTeams[1].players) then
            if #highScoreTeams[1].players > 1 then
                playerName = highScoreTeams[1].faction
            else
                playerName = highScoreTeams[1].players[1]:GetPlayer():GetPlayerName()
            end
        else
            playerName = Localize("/Lotus/Language/Menu/PvpMatchNobody", {})
        end
        match.roundWinners = highScoreTeams
        match.roundLosers = SubtractTable(teams, highScoreTeams)
        
        for i, team in ipairs(match.roundWinners) do
            for k, player in ipairs(team.players) do
                if player:ReplicaLocallyControlled() then
                    _T.ShowImpactMessage("/Lotus/Language/Menu/PvpMatchVictory", 5, true, nil, false)
                    msgDisplayed = true
                end
            end
        end
        
        for i, team in ipairs(match.roundLosers) do
            for k, player in ipairs(team.players) do
                if player:ReplicaLocallyControlled() then
                    _T.ShowImpactMessage("/Lotus/Language/Menu/PvpMatchDefeat", 5, false, nil, false)
                    msgDisplayed = true
                end
            end
        end
        
        if not msgDisplayed then
            local localAvatar = gRegion:GetLocalPlayerAvatar()
            if AvatarCares(localAvatar, zone) then
                _T.ShowImpactMessage("/Lotus/Language/Menu/PvpMatchPlayerWins", 3, true, nil, false, { PLAYER_NAME = playerName })
            end
        end
    end
end

local function GiveTransmission(team, trans)
    
    if not IsNull(team.players) then
        for i = 1, #team.players do
            if not IsNull(team.players[i]) and team.players[i]:ReplicaLocallyControlled() then
                team.players[i]:GiveItem(trans, true)
            end
        end
    end
end

function AudioChildScript(trigger)
    local stateCompleted = ""
    local audioFinished = false
    local zoneName = trigger:GetZone():GetFullName()
    
    for i = 1, #teams do
        GiveTransmission(teams[i], duelStartTrans)
    end
    
    while match.state ~= "DUEL_SCRIPT_FINISHED" and not audioFinished do
    
        if match.state == "ROUND_STARTING" and stateCompleted ~= match.state then
            roundStartSeq:Enable()
            stateCompleted = match.state
            print("Playing round music in zone " .. zoneName)
        elseif match.state == "ROUND_OVER" and stateCompleted ~= match.state then
            roundEndSeq:Enable()
            roundStartSeq:Disable()
            stateCompleted = match.state
            print("Playing round end music in zone " .. zoneName)
            if match.roundsPlayed < numRounds - 1 then
                if #match.roundWinners == 1 then
                    GiveTransmission(match.roundWinners[1], roundWonTrans)
                else
                    for i = 1, #match.roundWinners do    
                        GiveTransmission(match.roundWinners[1], roundLostTrans)
                    end
                end
                for i = 1, #match.roundLosers do
                    GiveTransmission(match.roundLosers[i], roundLostTrans)
                end
            else
                for i = 1, #teams do
                    GiveTransmission(teams[i], suddenDeathTrans)
                end
            end
        elseif match.state == "DUEL_OVER" and stateCompleted ~= match.state then
            matchEndSeq:Enable()
            roundStartSeq:Disable()
            stateCompleted = match.state
            print("Playing match end music in zone " .. zoneName)
            if #match.roundWinners == 1 then
                GiveTransmission(match.roundWinners[1], duelWonTrans)
            else
                for i = 1, #match.roundWinners do    
                    GiveTransmission(match.roundWinners[1], duelLostTrans)
                end
            end
            for i = 1, #match.roundLosers do
                GiveTransmission(match.roundLosers[i], duelLostTrans)
            end
            audioFinished = true
        end
        
        Sleep(0)
    end
    roundStartSeq:Disable()
    print("Closed audio child script")
end

function EnergyRefillChildScript(trigger)

    local zoneName = trigger:GetZone():GetFullName()
    local cancelDuelVar, duelingTeamsVar, duelingPlayersVar, matchDataVar, teamDataVar, entitiesToRemoveVar = InitializeVarNames(zoneName)
    local refills = {}
    local match = _T[matchDataVar]

    while match.state ~= "DUEL_SCRIPT_FINISHED" do
        
        if match.state == "ROUND_STARTED" then
            Sleep(refillDelay)
            
            if #refills < 1 and match.state == "ROUND_STARTED" then
                for i = 1, #energyRefillStations do
                    if not IsNull(energyRefillStations[i]) then
                        table.insert(refills, { instance = gRegion:CreateEntity(energyRefillType, energyRefillStations[i]:GetPosition() + Vector(0,1.25,0), Rotation()), delta = refillTimer})
                    end
                end
            end
            
            while match.state == "ROUND_STARTED" do
                Sleep(0)
                local dt = DeltaTime()
                for i = 1, #refills do
                    if IsNull(refills[i].instance) then
                        refills[i].delta = refills[i].delta - dt
                        if refills[i].delta <= 0 then
                            refills[i].delta = refillTimer
                            refills[i].instance = gRegion:CreateEntity(energyRefillType, energyRefillStations[i]:GetPosition() + Vector(0,1.25,0), Rotation())
                        end
                    end
                end
            end
            
            for i = 1, #refills do
                if not IsNull(refills[i].instance) then
                    refills[i].instance:Destroy()
                end
            end
            refills = {}
        end
        Sleep(0)

    end
end

local function Initialize(zoneName)
    local cancelDuelVar, duelingTeamsVar, duelingPlayersVar, matchDataVar, teamsDataVar = InitializeVarNames(zoneName)
    
    while IsNull(_T[duelingPlayersVar]) or #_T[duelingPlayersVar] < playerCounter:GetCurrentValue() do
        Sleep(0)
    end
    
    playerAvs = GetPlayerAvatars(false, duelingPlayersVar)
    specPlayerAvs = GetPlayerAvatars(true, duelingPlayersVar)
    
    --setup scores and teams tracking
    for i = 1, #factions do
        local teamData = {}
        teamData.players = {}
        teamData.score = 0
        teamData.incap = false
        teamData.totalHealthPerc = 0
        teamData.faction = factions[i]
        teamData.forfeit = false
        table.insert(teams,teamData)
    end
    
    match.forfeits = 0
    match.state = ""
    match.roundsPlayed = 0
    match.roundWinners = {}
    match.roundLosers = {}
    
    for i = 1, #playerAvs do
        local startPoint = {}
        startPoint.pos = playerAvs[i]:GetPosition()
        startPoint.rot = playerAvs[i]:GetRotation()
        table.insert(duelStartPoints,startPoint)
    end
    
    for k = 1, #factions do
        teams[k].players = _T[duelingTeamsVar][factions[k]]
    end
    
    _T[teamsDataVar] = teams
    _T[matchDataVar] = match
end

--Duel States
--ROUND_STARTING       round about to start, players cannot deal damage yet
--ROUND_STARTED         round has started, players can deal damage
--ROUND_OVER              round has ended with a victor, players cannot deal damage anymore
--DUEL_OVER                  a player has reached the score count
--DUEL_SCRIPT_FINISHED  script has completed
function Duel(trigger)
    local zone = trigger:GetZone()
    local zoneName = zone:GetFullName()
    
    print("Duel script starting in zone " .. zoneName)
    Initialize(zoneName)
    
    local cancelDuelVar, duelingTeamsVar, duelingPlayersVar, matchDataVar, teamsDataVar, entitiesToRemoveVar = InitializeVarNames(zoneName)
    
    local host = gRegion:IsMaster()
    local gameRules = gGameRules
    
    --Setup boundaries
    for i = 1,#duelingBoundaries do
        duelingBoundaries[i]:SetVisibility(true,true)
        print("Boundary " .. duelingBoundaries[i]:GetFullName() .. " enabled in zone " .. zoneName)
    end
    
    for i, trigger in ipairs(duelTriggers) do
        trigger:Enable()
    end
    
    _T[entitiesToRemoveVar] = {}
    
    trigger:ScriptRunChildScript(Symbol("AudioChildScript"), false)
    if host then
        roundStartForwarder:ScriptRunChildScript(Symbol("EnergyRefillChildScript"), false)
    end
    
    if gGameStatsMgr ~= nil and host then
        gGameStatsMgr:AddEvent(Symbol("DUELS"), "", 1)
    end
    
    while match.state ~= "DUEL_OVER" do
        
        --Round setup
        if match.state == "ROUND_OVER" or match.state == "" then
            if match.state ~= "" then
                --reset players
                if not IsNull(_T[entitiesToRemoveVar]) then
                    for i, ent in ipairs(_T[entitiesToRemoveVar]) do
                        if not IsNull(ent) then
                            ent:Destroy()
                        end
                    end
                end
                print("Teleporting Duelers and cleaning up previous round in zone " .. zoneName)
                for i, playerAv in ipairs(playerAvs) do
                    if not IsNull(playerAv) then
                        if not playerAv:IsKilled() then
                            if host then
                                playerAv:SetHealth(playerAv:GetMaxHealth())
                            end
                            playerAv:RemoveAllDeltaAttenuation()
                            --playerAv:SetView(Rotation())
                            playerAv:InventoryControl():GetActivePowerSuit():SetEnergy(50)
                            DestroyEndOfRoundEntities() --Cleanup
                        end
                        print("Teleporting " .. playerAv:GetPlayer():GetPlayerName() .. " in position in zone " .. zoneName)
                        print("duelstartPoint" .. i .. " : " .. tostring(duelStartPoints[i].pos))
                        TeleportPlayer(playerAv, duelStartPoints[i])
                    end
                end
            end

            local localAvatar = gRegion:GetLocalPlayerAvatar()
            if AvatarCares(localAvatar, trigger:GetZone()) then
                _T.ShowImpactMessage("/Lotus/Language/Dojo/DuelRoundBeginning", roundDelay - 6, true, nil, false)
            end
            
            match.state = "ROUND_STARTING"
            Sleep(roundDelay - 4)
            
            --setting energy later as they can use powers and interrupt kneeling animt
            for i, playerAv in ipairs(playerAvs) do
                if not IsNull(playerAv) then
                    playerAv:InventoryControl():GetActivePowerSuit():SetEnergy(50)
                    playerAv:SetForceNotTargetable(false)
                    local sentinel = playerAv:InventoryControl():GetSentinel()
                    if not IsNull(sentinel) then
                        sentinel:SetForceNotTargetable(false)
                    end
                end
            end
            
            local msgTime = 0
            local msgCntr = 0
            while msgTime < 3 and not IsNull(gameRules) do
                if AvatarCares(localAvatar, trigger:GetZone()) and msgCntr == 0 and msgTime > 0 then
                    _T.ShowImpactMessage("3", 1, true, nil, false)
                    msgCntr = msgCntr + 1
                elseif AvatarCares(localAvatar, trigger:GetZone()) and msgCntr == 1 and msgTime > 1 then
                    _T.ShowImpactMessage("2", 1, true, nil, false)
                    msgCntr = msgCntr + 1
                elseif AvatarCares(localAvatar, trigger:GetZone()) and msgCntr == 2 and msgTime > 2 then
                    _T.ShowImpactMessage("1", 1, true, nil, false)
                    msgCntr = msgCntr + 1
                end                
                Sleep(0)
                msgTime = msgTime + DeltaTime()
            end
            if IsNull(gameRules) then   --host migrate
                break
            end
            if AvatarCares(localAvatar, trigger:GetZone()) then
                _T.ShowImpactMessage("/Lotus/Language/Menu/PvpBeginRound", 1, true, nil, false)
            end
            gameRules:SetMissionTimer(Symbol(zoneName), Symbol(), roundDuration, false)
            match.state = "ROUND_STARTED"
            CullDisconnects()
            SetDamageMultiplierOnAvatars(dmgSym,1,playerAvs)
            print("Setting to enemy factions in zone " .. zoneName)
            SetFactions(true)
            if not IsNull(roundStartForwarder) then
                roundStartForwarder:FirePort("Trigger Port")
            end
        end
        
        local skip = false
        local roundWinners = DecideRoundWinner(zoneName)
        if match.forfeits == #teams then
            match.state = "DUEL_OVER"
            if not IsNull(gameRules) then
                gameRules:SetMissionTimer(Symbol(zoneName), Symbol("Round Finished"),-1,false)
            end
            skip = true
        elseif #roundWinners == 0 then
            local humanPlayers = gRegion:GetHumanPlayers()
            for i = 1, #humanPlayers do
                local player = humanPlayers[i]
                local playerAvatar = player:GetAvatar()
                if not IsNull(playerAvatar) then
                    if playerAvatar:GetZone() == zone then
                        player:AddTimerOfInterest(Symbol(zoneName))
                    else
                        player:RemoveTimerOfInterest(Symbol(zoneName))
                    end
                end
            end
            Sleep(0)
            skip = true
        end
        
        if not skip then

            for i = 1, #roundWinners do
                table.insert(match.roundWinners, teams[roundWinners[i]])
            end
            match.roundLosers = SubtractTable(teams, match.roundWinners)
        
            gameRules:SetMissionTimer(Symbol(zoneName), Symbol("Round Finished"),-1,false)
            SetDamageMultiplierOnAvatars(dmgSym,0,playerAvs)
            match.roundsPlayed = match.roundsPlayed + 1

            local winners = roundWinners[1] --convenience var
        
            if #roundWinners == 1 then
                teams[winners].score = teams[winners].score + 1
                --only supporting 1v1 for now, will update at some point
                local player = teams[winners].players[1]
                local loser = match.roundLosers[1].players[1]
                if player:ReplicaLocallyControlled() then
                    _T.ShowImpactMessage("/Lotus/Language/Menu/PvpWonRound", 3, true, nil, false)
                elseif not IsNull(loser) and loser:ReplicaLocallyControlled() then
                    _T.ShowImpactMessage("/Lotus/Language/Menu/PvpLostRound", 3, false, nil, false)
                else
                    local localAvatar = gRegion:GetLocalPlayerAvatar()
                    if AvatarCares(localAvatar, trigger:GetZone()) then
                        _T.ShowImpactMessage("/Lotus/Language/Menu/PvpTheWinnerIs", 3, true, nil, false, { PLAYER_NAME = player:GetPlayer():GetPlayerName() })
                    end
                end
            elseif #roundWinners > 1 then
                local localAvatar = gRegion:GetLocalPlayerAvatar()
                if AvatarCares(localAvatar, trigger:GetZone()) then
                    _T.ShowImpactMessage("/Lotus/Language/Menu/PvpDrawRound", 3, true, nil, false)
                end
            end
        
            if match.roundsPlayed < numRounds and teams[winners].score < matchesToWin and match.forfeits < #teams-1 then
                print("ROUND OVER in zone " .. zoneName)
                match.state = "ROUND_OVER"
            else
                DecideMatchWinner(trigger:GetZone())
                match.state = "DUEL_OVER"
                print("DUEL OVER in zone " .. zoneName)
            end
        
            Sleep(2)
            for i, playerAv in ipairs(playerAvs) do
                if not IsNull(playerAv) and playerAv:IsPreDeath() and playerAv:ReplicaLocallyControlled() then
                    playerAv:InstantRevive()
                end
                if not IsNull(playerAv) and host then
                    playerAv:InventoryControl():ReviveSentinelIfNecessary()
                end
            end
            SetFactions(false)
            Sleep(2)
        end
    end
    
    for i, trigger in ipairs(duelTriggers) do
        trigger:Disable()
    end
    
    for i = 1,#duelingBoundaries do
        duelingBoundaries[i]:SetVisibility(false,true)
        print("Boundary " .. duelingBoundaries[i]:GetFullName() .. " disabled in zone " .. zoneName)
    end

    for i = 1, #playerAvs do
        if not IsNull(playerAvs[i]) and not playerAvs[i]:IsKilled() then
            local inv = playerAvs[i]:InventoryControl()
            local input = playerAvs[i]:InputControl()
            local suit = inv:GetActivePowerSuit()
            if host then
                playerAvs[i]:SetHealth(playerAvs[i]:GetMaxHealth())
                inv:SetWeaponsEnabled(false)
                inv:ReviveSentinelIfNecessary()
            end
            input:EnableMelee(false)
            suit:SetEnergy(0)
            suit:SetAbilitiesEnabled(false)
            playerAvs[i]:RemoveAllDeltaAttenuation()
            --playerAvs[i]:SetView(Rotation())
            DestroyEndOfRoundEntities()
            playerAvs[i]:SetForceNotTargetable(false)           
            Sleep(0)
            local sentinel = inv:GetSentinel()
            if not IsNull(sentinel) and not sentinel:IsKilled() then
                sentinel:SetForceNotTargetable(false)
                if not IsNull(sentinel:InventoryControl()) then
                    sentinel:InventoryControl():GetActivePowerSuit():SetAbilitiesEnabled(false)
                end
            end
            if playerAvs[i]:ReplicaLocallyControlled() then
                RefillAmmoInSlot(Engine.SLOT_1,inv)
                RefillAmmoInSlot(Engine.SLOT_2,inv)
            end
        end
    end
    
    if not IsNull(_T[entitiesToRemoveVar]) then
        for i, ent in ipairs(_T[entitiesToRemoveVar]) do
            if not IsNull(ent) then
                ent:Destroy()
            end
        end
    end
    local humanPlayers = gRegion:GetHumanPlayers()
    for i = 1, #humanPlayers do
        local player = humanPlayers[i]
        if not IsNull(player) then
            player:RemoveTimerOfInterest(Symbol(zoneName))
        end
    end

    _T[cancelDuelVar] = {}
    _T[duelingPlayersVar] = {}
    playerCounter:SetCurrentValue(0)
    match.state = "DUEL_SCRIPT_FINISHED"
    print("Duel script finished in zone" .. zoneName)

    gameRules:SetLocalPlayerInDuel(false)
end

--Handles players in dueling boundaries
function EnterBoundaries(trigger)
    local zoneName = trigger:GetZone():GetFullName()
    local cancelDuelVar, duelingTeamsVar, duelingPlayersVar, matchDataVar, teamDataVar, entitiesToRemoveVar = InitializeVarNames(zoneName)
    local touching = trigger:GetEntitiesTouching()
    local spIndex = 1
    --teleport spectators out of arena
    
    for i, ent in ipairs(touching) do
        if ent:IsA(tennoAvatarType) and tables.Search(_T[duelingPlayersVar], ent:GetPlayer()) == 0 then
            local location = {pos = spawnPoints[spIndex]:GetPosition(), rot = spawnPoints[spIndex]:GetRotation()}
            if spIndex >= #spawnPoints then
                spIndex = 1
            else
                spIndex = spIndex + 1
            end
            
            if not IsNull(ent:GetPlayer()) then
                print("Removing " .. ent:GetPlayer():GetPlayerName() .. " from dueling arena in zone " .. zoneName)
            else
                print("Couldn't remove " .. ent:GetFullName() .. " from dueling arena in zone " .. zoneName)
                return
            end
            TeleportPlayer(ent, location)
        end
    end
    
end

function ExitBoundaries(trigger, instigator)
    local zoneName = instigator:GetZone():GetFullName()
    local cancelDuelVar, duelingTeamsVar, duelingPlayersVar, matchDataVar, teamDataVar, entitiesToRemoveVar = InitializeVarNames(zoneName)

    if tables.Search(_T[duelingPlayersVar], instigator:GetPlayer()) > 0 then
        print("Putting player back in dueling area in zone " .. zoneName)
        TeleportPlayer(instigator, { pos = waypoint:GetPosition(), rot = waypoint:GetRotation() })
    end
end

function TestBoundaries()
    
    local localPlayer = gRegion:GetLocalPlayerAvatar()
    local zoneName = localPlayer:GetZone():GetFullName()
    local cancelDuelVar, duelingTeamsVar, duelingPlayersVar, matchDataVar, teamDataVar, entitiesToRemoveVar = InitializeVarNames(zoneName)
    
    _T[duelingPlayersVar] = {}
    
    if dueling then
        table.insert(_T[duelingPlayersVar],localPlayer:GetPlayer())
    end
end

