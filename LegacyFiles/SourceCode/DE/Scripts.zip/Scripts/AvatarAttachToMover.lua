spawncontrol = Instance()
tramMover = Instance()


function AttachTramAvatar()
 local spawnpoint = spawncontrol:GetSpawnPoints()[1]
 local tramavatar=spawnpoint:GetActiveAvatar()
        if not IsNull(tramMover) then
            tramavatar:AttachToInPlace(tramMover,Symbol())
        end
end

