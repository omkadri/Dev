attachmentTypes = Resource()
decoration = Instance()
boneToAttachTo = Symbol()
offsetPosition = Vector()
offsetRotation = Rotation()

function AddAttachments()

    local attachment = decoration:GetAttachment(attachmentTypes)
    decoration:Attach(attachmentTypes, boneToAttachTo, offsetPosition, offsetRotation)
    
end
