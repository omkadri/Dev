timeToLive = 20
reviveStartAnim = Resource()
reviveLoopAnim = Resource()
reviveFx = Type()
shockwaveType = Type()
healerSpawnFx = Type()
lampType = Type()
--transmissionSet = Resource()

--local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"

local function GetHealTarget(avatar)
    local tag = avatar:GetTag()

    if IsNull(tag) then
        return
    end
    local players = gRegion:GetHumanPlayerAvatars()
    for i = 1, #players do
        if players[i]:GetUIName() == tostring(tag) then
            return players[i]
        end
    end

end

local codexMovie = WeakResource("/Lotus/Interface/Codex.swf")
function DevotedMonitor(avatar)
    -- don't do gameplay stuff in codex
    if gFlashMgr:HasMovie(codexMovie) then 
        return 
    end

    gRegion:CreateEntity(healerSpawnFx, avatar:GetPosition(), ZERO_ROTATION, avatar, avatar)
    gRegion:CreateEntity(shockwaveType, avatar:GetPosition(), ZERO_ROTATION, avatar, avatar)
    if not IsNull(avatar) then
        local dissolve = 1
        while dissolve > 0 and not IsNull(avatar) do
            avatar:SetMaterialParam(Lotus_Game.CLOAK, dissolve)
            avatar:SetDissolve(dissolve)
            dissolve = dissolve - DeltaTime()
            Sleep(0)
        end
    end
    
    local t = 0
    while t < timeToLive and not avatar:IsPreDeath() do
        t = t + DeltaTime()
        Sleep(0)
    end
    
    local downedPlayer = GetHealTarget(avatar)
    if not IsNull(downedPlayer) then
        downedPlayer:DamageControl():SetSoloBleedOutEnabled(false)
    end
    
    gRegion:CreateEntity(shockwaveType, avatar:GetPosition(), ZERO_ROTATION, avatar, avatar)
    
    local dissolve = 0
    while dissolve <= 1 and not IsNull(avatar) do
        avatar:SetMaterialParam(Lotus_Game.CLOAK, dissolve)
        avatar:SetDissolve(dissolve)
        dissolve = dissolve + DeltaTime() + 0.1
        Sleep(0)
    end
    
    Sleep(1)  --temp sleep; give time for transmission
    
    avatar:Destroy()

end

local function GetDirAndTorsoView(instigatorAvatar, target)
    local torsoView
    if not IsNull(target) then
        torsoView = LookTo(instigatorAvatar:GetSimPosition(), target:GetSimPosition())
    else
        torsoView = instigatorAvatar:GetView()
    end
    
    -- Consider heading only for direction
    torsoView.pitch = 0
    torsoView.bank = 0
    return AngleToDirection(torsoView), torsoView
end

function DevotedReviving(agent)
    if IsNull(agent) then
        return
    end
    local avatar = agent:GetAvatar()
    local players = gRegion:GetHumanPlayerAvatars()
    local healingLamp = avatar:GetAttachment(lampType)
    
    local downedPlayers = {}
    
    for i = 1, #players do
        if players[i]:IsPreDeath() then
            table.insert(downedPlayers, players[i])
        end
    end
    
    local downedPlayer
    local nearestPlayerDist = 0
    
    for i = 1, #downedPlayers do
        if nearestPlayerDist == 0 or avatar:DistanceToEntity(downedPlayers[i]) < nearestPlayerDist then
            nearestPlayerDist = avatar:DistanceToEntity(downedPlayers[i])
            downedPlayer = downedPlayers[i]
        end
    end
    
    --local downedPlayer = GetHealTarget(avatar)
    
    if IsNull(downedPlayer) then
        return
    end
    
    local waitTime = 0
    while not IsNull(downedPlayer) and avatar:DistanceToEntity(downedPlayer) > 2 do
        waitTime = waitTime + DeltaTime()
        if waitTime > 5 then --something messed up, just quit trying to revive
            return
        end
        Sleep(0)
    end
    
    local dir
    local torsoView
    local newLamp
    
    if not IsNull(downedPlayer) and downedPlayer:IsPreDeath() then
        dir, torsoView = GetDirAndTorsoView(avatar, downedPlayer)

        avatar:SetDesiredView(torsoView)
        
        --some good ol fashioned hackery to rotate the lamp down during revive 
        if not IsNull(healingLamp) then 
            healingLamp:SetVisibility(false)
            newLamp = avatar:Attach(lampType, Symbol("GAME_L1_WEAPON1"), Vector(0.66, -0.05, -0.05), Rotation(180, 0, -90))
        end

    end
    
    local t = 0
    while t < 3 and not IsNull(downedPlayer) and downedPlayer:IsPreDeath() do
        t = t + DeltaTime()
        Sleep(0)
    end
    
    avatar:PlayAnimation(nil, false, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_ONCE, true)
    
    Sleep(0.5)
    if not IsNull(newLamp) then
        newLamp:Destroy()
    end
    
    if not IsNull(healingLamp) then
        healingLamp:SetVisibility(true)
    end

end