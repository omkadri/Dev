introTransmission = Resource()
transmissions = { Resource() }
combatTransmissions = { Resource() }
minCombatTransDelay = 20
maxCombatTransDelay = 30
minDistToTarget = 75
playCombatTaunts = true
waitForCombatTaunt = false
delayForCombatTaunt = 5
targetNumTransmission = 5 --How many boss taunts to play while en route to boss room


local UTIL = require "EE.Interface.Utilities"

local function GiveTransmission(trans)
    if IsNull(trans) then
        return
    end
    local players = gRegion:GetHumanPlayers()
    if not IsNull(players) then
        for x = 1, #players do
            local avatar = players[x]:GetAvatar()
            if not IsNull(avatar) then
                avatar:GiveItem(trans, true)
            end
        end
    end
end

local function IsVIPAlive()
    local gameRules = gGameRules
    local mission = gameRules:GetMission()
    
    local avatars = gRegion:GetAvatars()
    for i=1,#avatars do
        if not IsNull(avatars[i]) and not avatars[i]:IsKilled() then
            local agent = avatars[i]:GetAgent()
            if not IsNull(agent) and agent:IsA(mission.vipAgent) then
                return true
            end
        end
    end
    return false
end

local function GetShuffled(shuffledTransmissions, t, gameRules)
    if #shuffledTransmissions == 0 then
        for i=1,#t do
            table.insert(shuffledTransmissions, t[i])
        end
        shuffledTransmissions = UTIL.SeededShuffleTable(shuffledTransmissions)
    end
    return shuffledTransmissions
end

function Run(gameRules)
    if gameRules:GetMission().goalTag == Symbol("RelayReconstructionTwo") then
        return
    end

    local shuffledTransmissions = {}
    local shuffledCombatTransmissions = {}
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()
    
    Sleep(15)
    if not gPromotedToHost or IsVIPAlive() then
        if not IsNull(introTransmission) then
            GiveTransmission(introTransmission)
        end
    end
    
    local goalDistance = aiDir:GetLeadPlayerDistance()
    --local targetNumTransmission = 5 -- made this data driven
    local distInterval = goalDistance / targetNumTransmission
    local intervals = {}
    for i=1,targetNumTransmission do
        if goalDistance <= 0.0 then
            intervals[i] = -1.0 -- BAD NAV!
        else
            local t = (i - 1) / (targetNumTransmission - 1)
            intervals[i] = Lerp(minDistToTarget, goalDistance - 100, (t * t))
        end
    end
    
    
    -- noncombat requires advancement
    while true and not IsVIPAlive() do
        Sleep(1.0)
        goalDistance = aiDir:GetLeadPlayerDistance()
        for i=1,targetNumTransmission do
            if goalDistance < intervals[i]  then
                intervals[i] = -1.0
                shuffledTransmissions  = GetShuffled(shuffledTransmissions, transmissions, gameRules)
                GiveTransmission(shuffledTransmissions[1]) 
                table.remove(shuffledTransmissions, 1)
            end
        end
    end
    
    if not playCombatTaunts then
        return
    end
    
    if waitForCombatTaunt then
        Sleep(delayForCombatTaunt)
    end
    
    --local regorFight = false
    --if mission.vipAgent:IsA(WeakResource("/Lotus/Types/Enemies/Grineer/Vip/TylRegor/TylRegorAgent")) then
        --regorFight = true
    --end
    
    -- combat is timed
    while true and IsVIPAlive() do
        shuffledCombatTransmissions  = GetShuffled(shuffledCombatTransmissions, combatTransmissions, gameRules)
        
        if not IsNull(_T.PauseTylTrans) then
            while _T.PauseTylTrans do
                Sleep(10) --long sleep to avoid any back to back transmissions
            end
        end
        
        GiveTransmission(shuffledCombatTransmissions[1]) 
        table.remove(shuffledCombatTransmissions, 1)
        Sleep(math.random(minCombatTransDelay, maxCombatTransDelay))
    end
end
