
avatarModifier = Instance()
TennoAvatar = Instance()
TennoPhaser = Type()
TennoHolster = Type()
TennoDeco = Instance()
EnergizeType = Type()

function ClampView()
    local player = gRegion:GetPlayerAvatar()
    local camCtrl = player:CameraControl()
    local minv = Rotation(-15,0,0)
    local maxv = Rotation(15,0,0)
    camCtrl:SetViewClamp(minv, maxv)
end

function UnClampView()
    local player = gRegion:GetPlayerAvatar()
    local camCtrl = player:CameraControl()
    local minv = Rotation()
    local maxv = Rotation()
    camCtrl:ResetViewClamp()
    --avatarModifier:FirePort("Activate")
    --local phaser = TennoAvatar:GetAttachment(TennoPhaser)
    --local holster = TennoAvatar:GetAttachment(TennoHolster)
    --holster:FirePort("Hide")
    --phaser:FirePort("Show")
end

function HidePhaser()
    --ocal phaser = TennoAvatar:GetAttachment(TennoPhaser)
    --phaser:FirePort("Hide")
end

function BeamOutDeco()
    
    TennoDeco:Attach(EnergizeType, EMPTY_SYMBOL)
    
    local t = 0.0
    while t < 1.1 do
        TennoDeco:SetMaterialParam(Lotus_Game.CLOAK, t)
        t = t + DeltaTime() * 0.34
        Sleep(0)
    end
    
    
    
    TennoDeco:SetMaterialParam(Lotus_Game.CLOAK, 1.1)
end

function fadeToWhite()
    local levelInfo = gRegion:GetLevelInfo()
    levelInfo.postProcess.fade = -1
    
    
end

