shockwaveEntity = Type()
parent = Instance()
verticalOffset = 0

function CreateShockwave()
    if IsNull(parent) then
        return
    end

    gRegion:CreateEntity(shockwaveEntity, parent:GetSimPosition() + Vector(0, verticalOffset, 0), parent:GetRotation(), parent)
end