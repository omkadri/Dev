local aiLib = require "Lotus.Scripts.Libs.AILib"

--mustSucceed = false           -- For critical path actions. Check this to force the action to keep trying until it succeeds. Use carefully.

--Generic
exitOnAlert = false                 --Exit script if agent is alerted
exitOnCombat = false            --Exit script if agent is in combat
exitOnDamage = false            --Exit script if agent takes damage
exitOnEnemySeen = false         --Exit script if agent sees an enemy
moveTypeID = 1                  --  *Basic* Movement type. All NPCs should have a version of these - 1 = SPRINT, 2 = JOG, 3 = WALK

-- Partner_MoveTo
wpDest = Instance()

--Partner_UseContext
contextAction = Instance()

--Partner_ShootTarget
entityTarget = Instance()           --  Thing to fire at
destinationPoint = Instance()   --  Specify a waypoint if you want the AI to move to a new location while shooting. Leave blank to have the AI shoot in situ. 
secShootDuration = 0                -- Time spent shooting. Must be a positive value
secWaitDuration = 0                 --  Time spent idling before returning to standard AI behavior. A duration of -1 acts as an infinite duration. 

--Partner_MeleeTarget
enemySpawnControl = Instance()      --  The spawner that creates the target enemy. Partner will shoot the first (still living) thing this controller spawned. 

--PartnerPickup
pickupAction = Instance()       --  Instance that spawns the weapon pickup

--PartnerFollowPlayer
bStopFollowing = false                  -- Check this to void the NPC's follow behavior. 

--PartnerChooseWeapon
idSlot = 0                  --  Which slot to use
idHand = 0                  --  What hand to use - 0 = MAIN_HAND, 1 = OFF_HAND, 2 = EXTRA1, 3 = EXTRA2
bUseAltFire = false         --  Switch to alt fire mode

--Partner_SetInvulnerable
IsInvincible = true         -- Set to true to make invulnerable, false to clear

--Partner_SwitchAgent
TennoAltAgentType = Type()      --  Agent to use if your partner is TennoAlt
TennoAgentType = Type()     -- Agent to use if your partner is Tenno

--Partner_AdvanceCarefully
shouldAdvanceCounter = Instance()       -- A port state counter to say whether the AI should take cover or advance. Set to 1 to advance
successCounter = Instance()                 --  A port state counter to say whether the AI has completed their task, or should keep trying

--Partner_CoopLedgeMonitor
playerMultiVolume = Instance()          -- A MultiAvatarTrigger set to accept PLAYERS. Should cover the area in which the player stands to indicate they want a boost/reach
npcMultiVolume = Instance()             -- A MultiAvatarTrigger set to accept NPCs. Should cover the area in which the AI will stand and consider helping you up
lowerContextAction = Instance()     -- The boost action
upperContextAction = Instance()     -- The reach action
isActiveCounter = Instance()                --   (Optional) A portStateCounter used to turn the monitor on and off

local DAMAGE_MULT_SYMBOL = Symbol("PartnerInvulnerableDM")

--[[
    LinkFriendlyAIToPlayer
        Referenced inside certain avatar resources to make them start following the player the moment they are spawned. 
--]]
function LinkFriendlyAIToPlayer(avatar)
    Sleep(2)    -- sleep for a couple seconds to be sure the player is spawned
    local localPlayers = gRegion:GetLocalPlayerAvatars()
    if not IsNull(localPlayers) then
        local player = localPlayers[1]
        local agent = avatar:GetAgent()
        if IsNull(agent) == false then  
            agent:SetOwningPlayerAvatar(player)
        end
    end     
end

--[[
    EquipMagBoots
        Might be obsolete, but too heavily referenced to remove just yet. 
--]]
function EquipMagBoots(agent)
    local avatar = agent:GetAvatar()
    avatar:MotionControl():StartMagnetBooting()
    agent:StopScriptedMode()
end

--[[
    MagBootsWarpSupportToPoint
        Debug feature to move the AI partner across Magboot areas. 
--]]
function MagBootsWarpSupportToPoint()
    local gameRules = gGameRules
    local supportingAvatar = gameRules:GetSupportingAvatar()
    local gameRules = gGameRules
    if IsNull(supportingAvatar) or IsNull(gameRules) or (not gameRules:IsNpc(supportingAvatar)) then
        return
    end
    
    local motionControl = supportingAvatar:MotionControl()
    if IsNull(motionControl) then
        return
    end
    
    local magnetMove = motionControl:GetMagnetMovement()
    if IsNull(magnetMove) then
        return
    end
    print("MagBoots:Warping support to point")
    magnetMove:DoMagneticTeleport(wpDest:GetPosition(), wpDest:GetRotation())
end


--[[
    Partner_MoveTo - Tell your AI Partner to interact with a specific trigger
        Should Incorporate MUSTSUCCEED
--]]
function Partner_MoveTo()

    local speed, wasSpeedSuccessful = aiLib:GetMovementSpeedFromID(moveTypeID)
    local partnerAvatar, partnerAgent, wasSuccessful = aiLib:GetAvatarAndAgentPartner()
    if not wasSuccessful or not wasSpeedSuccessful then
        return
    end

    --repeat
        aiLib:Setup(partnerAvatar, partnerAgent, exitOnAlert, exitOnCombat, exitOnDamage, exitOnEnemySeen)      --  Clears out prior commands
        partnerAgent:MoveTo(wpDest, speed, false, true)
        --wasSuccessful = aiLib:MoveTo(partnerAgent, wpDest, speed)                                                             
    --until wasSuccessful or not mustSucceed
    
    aiLib:WaitThenStopScripting(partnerAgent, secWaitDuration)
end

--[[
    Partner_UseContext - Tell your AI Partner to interact with a specific trigger
        Should Incorporate MUSTSUCCEED
--]]
function Partner_UseContext()

    local speed, wasSpeedSuccessful = aiLib:GetMovementSpeedFromID(moveTypeID)
    local partnerAvatar, partnerAgent, wasSuccessful = aiLib:GetAvatarAndAgentPartner()
    if not wasSuccessful or IsNull(contextAction) or not wasSpeedSuccessful then
        return
    end

    --repeat
        aiLib:Setup(partnerAvatar, partnerAgent, exitOnAlert, exitOnCombat, exitOnDamage, exitOnEnemySeen)      --  Clears out prior commands
        partnerAgent:MoveToVector(contextAction:GetPosition(), speed, false, true)
        partnerAgent:UseContextAction(contextAction, true)
        --wasSuccessful = aiLib:UseContext(partnerAgent, contextAction)
    --until wasSuccessful or not mustSucceed
    
    aiLib:WaitThenStopScripting(partnerAgent, secWaitDuration)
end


--[[
    PartnerPickup
        Tell your partner to pick up and equop a weapon
--]]
function PartnerPickup()

    local speed, wasSpeedSuccessful = aiLib:GetMovementSpeedFromID(moveTypeID)
    local partnerAvatar, partnerAgent, wasSuccessful = aiLib:GetAvatarAndAgentPartner()
    if not wasSuccessful or not wasSpeedSuccessful then
        return
    end
    
    local newAction = pickupAction:GetPickUpAction()

    aiLib:Setup(partnerAvatar, partnerAgent, exitOnAlert, exitOnCombat, exitOnDamage, exitOnEnemySeen)      --  Clears out prior commands
    partnerAgent:MoveToVector(newAction:GetPosition(), speed, false, true)
    partnerAgent:UseContextAction(newAction, true)

    --pickupAction
    partnerAgent:StopScriptedMode()
    Sleep(0)
end


--[[
    Partner_ScanTarget
        Tell your partner to switch to the tricorder, and scan a special object. 
                
        Need to be able to handle infinite scan items. 
--]]
function Partner_ScanTarget()
    local partnerAvatar, partnerAgent, wasSuccessful = aiLib:GetAvatarAndAgentPartner()
    if not wasSuccessful  or IsNull(entityTarget) then
        return
    end

    aiLib:Setup(partnerAvatar, partnerAgent, exitOnAlert, exitOnCombat, exitOnDamage, exitOnEnemySeen)

    partnerAgent:DoScanObject(entityTarget, true, Engine.RUN)

    aiLib:WaitThenStopScripting(partnerAgent, secWaitDuration)  
end

--[[
    Partner_ShootTarget - Tell your AI Partner to target and shoot a specific point for a duration
        If you specify a waypoint, the AI will shoot while moving towards that point. 
        The time spent moving comes off the full shoot duration.
--]]
function Partner_ShootTarget()
    local partnerAvatar, partnerAgent, wasSuccessful = aiLib:GetAvatarAndAgentPartner()
    if not wasSuccessful then
        return
    end

    aiLib:Setup(partnerAvatar, partnerAgent, exitOnAlert, exitOnCombat, exitOnDamage, exitOnEnemySeen)

    if not IsNull(entityTarget) then

        partnerAgent:SetTarget(entityTarget)

        local durationRemaining = secShootDuration
        if not IsNull(destinationPoint) then        -- start moving towards the point while shooting
            local startTime = Time()    
            partnerAgent:ShootTargetAndMoveTo(entityTarget, destinationPoint, true, true)
            durationRemaining = Time() - startTime
        end 

        -- Continue shooting target for any remaining duration at the waypoint      
        if not IsNull(entityTarget) and durationRemaining > 0 then 
            partnerAgent:ShootTarget(entityTarget, durationRemaining, true, true)
        end
        
    end

    aiLib:WaitThenStopScripting(partnerAgent, secWaitDuration)
end



--[[
    Partner_MeleeTarget
        Tell your partner to move up and perform a finisher on the target
        Note: The particular version of the partner agent should have Script_Behaviors->Custom_Struggle_Behavior provided with /Lotus/Types/Behaviors/CommanderFinisherBehavior for this to perform correctly
--]]
function PartnerMeleeTarget()
    local partnerAvatar, partnerAgent, wasSuccessful = aiLib:GetAvatarAndAgentPartner()
    if not wasSuccessful or IsNull( enemySpawnControl ) then
        return
    end

    aiLib:Setup(partnerAvatar, partnerAgent, exitOnAlert, exitOnCombat, exitOnDamage, exitOnEnemySeen)

    local spawnAvatar, spawnAgent, wasAlsoSuccessful = aiLib:GetAvatarAndAgentFromSpawner(enemySpawnControl)
    if not wasAlsoSuccessful then
        return
    end

    partnerAgent:DoFinisher( spawnAvatar, true )
    
    aiLib:WaitThenStopScripting(partnerAgent, secWaitDuration)
end


--[[
    Partner_TakeCover - Tell your AI Partner to move to a waypoint and take cover nearby
--]]
function Partner_TakeCover()
    local partnerAvatar, partnerAgent, wasSuccessful = aiLib:GetAvatarAndAgentPartner()
    if not wasSuccessful then
        return
    end

    aiLib:Setup(partnerAvatar, partnerAgent, exitOnAlert, exitOnCombat, exitOnDamage, exitOnEnemySeen)

    --partnerAgent:MoveTo(wpDest, Engine.RUN, false, true) NOT NEEDED. 
    partnerAgent:EnterNearestCover(wpDest, true)
    --Broadcast("Found Cover!") 

    aiLib:WaitThenStopScripting(partnerAgent, secWaitDuration)
end

--[[
    Partner_Wait - Stop AI from performing actions for the specified period
--]]
function Partner_Wait()
    local partnerAvatar, partnerAgent, wasSuccessful = aiLib:GetAvatarAndAgentPartner()
    if not wasSuccessful then
        return
    end

    aiLib:Setup(partnerAvatar, partnerAgent, exitOnAlert, exitOnCombat, exitOnDamage, exitOnEnemySeen)
    
    -- In order to stop the AI, we make him MoveTo his current location, and then explicitly not StopScriptedMode
    partnerAgent:MoveToVector(partnerAvatar:GetPosition(), Engine.RUN, false, true)
    
    aiLib:WaitThenStopScripting(partnerAgent, secWaitDuration)
end


--[[
    Partner_StopScripting - Stop Scripted Behavior immediately and return to standard AI behavior
--]]
function Partner_StopScripting()
    local partnerAvatar, partnerAgent, wasSuccessful = aiLib:GetAvatarAndAgentPartner()
    if not wasSuccessful then
        return
    end

    aiLib:Setup(partnerAvatar, partnerAgent, true, true, true, true)
    
    partnerAgent:StopScriptedMode()
    Sleep(0)
end


--[[
    Partner_FollowPlayer 
        Tell TennoAlt to start and stop following Tenno
--]]
function PartnerFollowPlayer()
    local partnerAvatar, partnerAgent, wasSuccessful = aiLib:GetAvatarAndAgentPartner()
    if not wasSuccessful then
        return
    end
    
    -- Get local player
    local playerAvatar = nil
    local localPlayers = gRegion:GetLocalPlayerAvatars()
    if not IsNull(localPlayers) then
        playerAvatar = localPlayers[1]
    end

    if bStopFollowing == true then  --  If we're STOPPING the follow behavior
        partnerAgent:SetOwningPlayerAvatar(nil)
    else
        partnerAgent:SetOwningPlayerAvatar(playerAvatar)
    end
end

--[[
    Partner_ChooseWeapon
    
    forces your partner to equip a particular weapon and fire mode. 
--]]
function PartnerChooseWeapon()
    local partnerAvatar, partnerAgent, wasSuccessful = aiLib:GetAvatarAndAgentPartner()
    if not wasSuccessful then
        return
    end

    -- Select weapon slot
    local inventory = partnerAvatar:InventoryControl()
    if not IsNull(inventory) then
        inventory:Equip(idSlot, idHand, Engine.InventoryControllerBase_ES_PLAY_EQUIP_ANIM)      
    end
    
    --  Select fire mode
    if bUseAltFire == true then
        partnerAgent:SetWeaponMode(1) 
    else
        partnerAgent:SetWeaponMode(0) 
    end
end

--[[
    Partner_SetInvulnerable
        Turn on invulnerability for AI Partners. Useful for puzzles and obstacles with instakill hazards.
        Be careful not to use this while your partner is in the middle of something, as their current behavior will be flushed. 
--]]
function Partner_SetInvulnerable()
    
    local partnerAvatar, partnerAgent, wasSuccessful = aiLib:GetAvatarAndAgentPartner()
    if not wasSuccessful then
        return
    end

    -- Do I need to store the original value here? 
    --      What if the avatar, by default, has a different damage multiplier?
    if IsInvincible then
        partnerAvatar:DamageControl():AddDamageModifier(DAMAGE_MULT_SYMBOL, Engine.DT_ANY, Engine.ANY_PART, 0)
    else
        partnerAvatar:DamageControl():RemoveDamageModifier(DAMAGE_MULT_SYMBOL)
    end

    partnerAgent:StopScriptedMode()
    Sleep(0)
    
end

--[[
    Partner_SwitchAgent
        Replace the AI agent, modifying their behavior. 
--]]
function Partner_SwitchAgent()

    local partnerAvatar, partnerAgent, wasSuccessful = aiLib:GetAvatarAndAgentPartner()
    if not wasSuccessful then
        return
    end
    
    local gameRules = gGameRules

    if gameRules:IsTennoAlt( partnerAvatar ) then
        partnerAvatar:ChangeAgent(TennoAltAgentType, Symbol("Alpha"), Symbol("Federation"), false)
    else
        partnerAvatar:ChangeAgent(TennoAgentType, Symbol("Alpha"), Symbol("Federation"), false)
    end
    
end


--[[
    Partner_AdvanceCarefully
    
    Causes the AI to alternate between walking towards a point, and taking cover along the way. 
        The AI decides what to do based on the value of a port state counter. 
--]]
function PartnerAdvanceCarefully()
    local partnerAvatar, partnerAgent, wasSuccessful = aiLib:GetAvatarAndAgentPartner()
    if not wasSuccessful then
        return
    end
    
    local lastState = -1
    local hasSucceeded = successCounter:GetCurrentValue()

    while hasSucceeded ~= 1 do  --   While not reached objective

        local newState = shouldAdvanceCounter:GetCurrentValue()

        if newState ~= lastState then 
            partnerAgent:StopScriptedMode()
            lastState = newState
            
            if newState == 1 then   -- If it is safe to advance
                partnerAgent:MoveTo(wpDest, Engine.WALK, false, false)
            else
                if not partnerAgent:EnterNearestCover(partnerAvatar:GetPosition(), false, 5.0) then     -- If we fail to find cover
                    partnerAgent:MoveTo(wpDest, Engine.WALK, false, false)                                  -- don't stop to take cover. Keep Going!
                end
            end
        end
        
        Sleep(0)
        hasSucceeded = successCounter:GetCurrentValue()

    end
    
end


--[[    SINGLE PLAYER ONLY
    Partner_CoopLedgeMonitor
    
    This is for a one way ledge. It'll get the AI up, but not back down again...

    -- Perhaps make the upper volume for both of them, so when the player is in his 
    
    We do an IsEnabled Test on the context actions. This allows us to turn off one or the other of the pair, for more complicated edges 
        (for example, you can prop up your friend, but he can't reach down for you. 
        
    This uses a Statecounter to add extra control over when the monitor should stop trying to control the AI. This is useful when the player is at the bottom of the ledge, 
        but we want the AI to perform other tasks (e.g, he is at the top of the ledge, but there's something else we want him to do instead rather than jumping back down. 
--]]
function PartnerCoopLedgeMonitor()

    local partnerAvatar, partnerAgent, wasSuccessful = aiLib:GetAvatarAndAgentPartner()
    if not wasSuccessful then
        return
    end
    
    if IsNull(lowerContextAction) or IsNull(upperContextAction) or IsNull(playerMultiVolume) then
        print("Partner Coop Ledge Monitor is not setup properly, cancelling execution")
        return
    end

    while true do
        
        --  Wait until activated. Sleep at least once to give the player a chance to go and the AI a little thinking time
        repeat
            Sleep(1.5)
        until IsNull(isActiveCounter) or isActiveCounter:GetCurrentValue() == 1 
    
        local boostInUse = not IsNull(lowerContextAction:GetInstigator())
        local pullInUse = not IsNull(upperContextAction:GetInstigator())

        -- If the ledge is idle
        if not boostInUse and not pullInUse then

            -- If the player might need help            
            if playerMultiVolume:IsAtCapacity() then 

                if npcMultiVolume:IsAtCapacity() then
                    if upperContextAction:IsEnabled() then
                        -- AI is at the top of the ledge. He should reach down for the player
                        aiLib:Setup(partnerAvatar, partnerAgent, false, false, false, false)
                        partnerAgent:UseContextAction(upperContextAction, false)
                    end
                else
                    if lowerContextAction:IsEnabled() then
                        -- AI is not at the top ledge. He should try to boost the player (OR he's at the top, but too far away, in which case he'll hit the upper volume on his way back!)
                        aiLib:Setup(partnerAvatar, partnerAgent, false, false, false, false)
                        partnerAgent:UseContextAction(lowerContextAction, false)
                    end
                end
            end

        else    -- Clean Up Erroneous Edge Uses (edge cases!)
                        
            -- AI partner is waiting to assist, but player is no-where nearby. Stop trying. 
            if not playerMultiVolume:IsAtCapacity() then
                if lowerContextAction:GetInstigator() == partnerAvatar then
                    lowerContextAction:CancelExecution(partnerAvatar)
                    partnerAgent:StopScriptedMode()
                elseif upperContextAction:GetInstigator() == partnerAvatar then
                    upperContextAction:CancelExecution(partnerAvatar)
                    partnerAgent:StopScriptedMode()
                end
            end
            
            -- Player is trying to assist NPC. Make sure he's not caught up in any other scripted behavior
            if( lowerContextAction:GetInstigator() ~= partnerAvatar and upperContextAction:GetInstigator() ~= partnerAvatar ) then
                partnerAgent:StopScriptedMode()
            end
        end
    end
end

