rangeOfEffect = 10
avatarType = Type()
damageBoostUpgrade = Type()
damageBoostMaterial = Resource()
damageBoostProjector = Type()
activateSound = Resource()
activateLocalSound = Resource()
errorSound = Resource()
deactivateSound = Resource()
loopingEffectSound = Resource()

attachmentTypesToAddProjectorTo = { Type() }

local UTIL = require "EE.Interface.Utilities"

local printPrefix = "DamageBoostAbility: "

function Activate(ability, avatar, boost)
    print(printPrefix .. "Activating damage boost ability");
    
    local pos = avatar:GetPosition()
    local allies = gRegion:FindAll(avatarType, pos, 0, rangeOfEffect) 
    if not IsNull(allies) then
        for i=#allies, 1, -1 do
            if not (allies[i]:GetFaction() == Symbol("Federation")) then
                table.remove(allies, i)
            end
        end
    else
        return
    end
    
    print(printPrefix .. "Found " .. #allies .. " allies")
    
    local rules = gGameRules
        
    for k,v in ipairs(allies) do
        if gRegion:IsMaster() then
            v:InventoryControl():AddAvatarUpgrade(damageBoostUpgrade)
        end
        ability:AddToRememberedObjects(v)
        if v:ReplicaLocallyControlled() and rules:IsTenno(v) then
            v:InventoryControl():GetWeaponInSlot(Engine.SLOT_1):GetFireBehavior(0):SetChargedShotActive(true) --hack for DPS
        end
        --ability:SetOverrideMaterialForEntity(v, damageBoostMaterial)
        v:Attach(damageBoostProjector, EMPTY_SYMBOL, v:GetPosition(), v:GetRotation())
        for i,j in ipairs(attachmentTypesToAddProjectorTo) do
            local attachment = v:GetAttachment(j)
            if not IsNull(attachment) then
                attachment:Attach(damageBoostProjector, EMPTY_SYMBOL, attachment:GetPosition(), attachment:GetRotation(), true)
            end
        end
    end
    
    _T["damageSoundLoop"] = avatar:PlaySound(loopingEffectSound, false)
    if avatar:IsLocallyAuthoritative() then
        avatar:PlaySound(activateLocalSound, false, false)
    end
    avatar:PlaySound(activateSound, false, false)
end

function Deactivate(ability, avatar)
    print(printPrefix .. "Deactivating damage boost ability");

    local allies = ability:GetRememberedObjects()
    
    if IsNull(allies) then
        return
    end
    
    --ability:RestoreEntityMaterials()
    
    local rules = gGameRules
    
    for k,v in ipairs(allies) do
        if not IsNull(v) then
            if gRegion:IsMaster() then
                v:InventoryControl():RemoveAvatarUpgrade(damageBoostUpgrade)
            end
            if v:ReplicaLocallyControlled() and rules:IsTenno(v) then
                v:InventoryControl():GetWeaponInSlot(Engine.SLOT_1):GetFireBehavior(0):SetChargedShotActive(false) --hack for DPS
            end
            local proj = v:GetAttachment(damageBoostProjector)
            if not IsNull(proj) then
                proj:Destroy()
            end
            for i,j in ipairs(attachmentTypesToAddProjectorTo) do
                local attachment = v:GetAttachment(j)
                if not IsNull(attachment) then
                    local attProj = attachment:GetAttachment(damageBoostProjector)
                    if not IsNull(attProj) then
                        attProj:Destroy()
                    end
                end
            end
        end
    end
    
    if not IsNull(_T["damageSoundLoop"]) then
        _T["damageSoundLoop"]:Stop(true)
        _T["damageSoundLoop"] = nil
    end
    ability:ClearRememberedObjects()
    
    avatar:PlaySound(deactivateSound, false, false)
end
