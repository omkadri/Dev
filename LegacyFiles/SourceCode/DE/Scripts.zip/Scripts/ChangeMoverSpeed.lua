mover = Instance()
newMoverTime = 10

newTestRotate = Rotation()
testRotateSpeed = 5
isRotating = true


function ChangeAnimationTime()

    if IsNull(mover) then
        return
    end
    
    mover:SetAnimationTime(newMoverTime)
    
end

function ChangeTestRotate()
    if IsNull(mover) then
        return
    end
    
    mover:SetTestRotate(isRotating)
    mover:SetTestRotateSpeed(Rotation(newTestRotate.bank*testRotateSpeed, newTestRotate.heading * testRotateSpeed, newTestRotate.pitch * testRotateSpeed))
end