scriptTrigger = Instance()
missionType = Lotus_Game.MT_MOBILE_DEFENSE
captureScript = Instance()
mobileDefenseScript = Instance()

function CheckMissionType()
    local gameRules = gGameRules
    local m = gameRules:GetMissionType()
    if m == missionType then
        scriptTrigger:RunScripts()
    end
end

function PickMissionType()
    local gameRules = gGameRules
    local m = gameRules:GetMissionType()
    if m == Lotus_Game.MT_CAPTURE then
        captureScript:RunScripts()
    elseif m == Lotus_Game.MT_MOBILE_DEFENSE then
        mobileDefenseScript:RunScripts()
    end
end