doorDeco = Instance()
fakeDoor = Instance()
function CaptureShipDoor()
    local n = 0
    local rot = doorDeco:GetRotation()
    while n < 1 do
        local v = Lerp(rot.pitch, rot.pitch + 120, n)
        doorDeco:SetRotation(Rotation(rot.heading, v, rot.bank))
        n = n + DeltaTime() / 2
        Sleep(0)
    end   
  --  doorHint:FirePort("Lock")
    fakeDoor:FirePort("Show")
    doorDeco:FirePort("Hide")
end

function CaptureShipDoorOpen()
    local n = 0
    local rot = doorDeco:GetRotation()
    fakeDoor:FirePort("Hide")
    doorDeco:FirePort("Show")
    while n < 1 do
        local v = Lerp(rot.pitch, rot.pitch + 120, n)
         doorDeco:SetRotation(Rotation(rot.heading, v, rot.bank))
        n = n + DeltaTime() / 2
        Sleep(0)
    end   
    --doorHint:FirePort("Lock")
end