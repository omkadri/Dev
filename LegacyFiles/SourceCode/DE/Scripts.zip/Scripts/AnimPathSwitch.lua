firstMover = Instance()
secondMover = Instance()
timeToTransition = 8
moverDeco = Instance()
currentState = Instance()
sideDecos = {Instance()}
sideEffects = {Instance()}
nightEscapePort = Instance()
dayReturnPort = Instance()
dayThreshold = 5
nightThreshold = 20
local mLevelInfo



function MoveBetweenAnimPaths(trigger)

    if not IsNull(moverDeco) then
        if currentState:GetCurrentValue() == 0 then --shooting or alerting while duster is already flying doesn't run this twice

            local targetParent = secondMover
            
            currentState:FirePort("Increment")
            moverDeco:Unattach()

 
            local n = 0
            local currentPos = moverDeco:GetPosition()
            local currentRot = moverDeco:GetRotation()
            local multiplier = 0.5
        
            while n < timeToTransition and not IsNull(targetParent) do
                if not IsNull(moverDeco) then
                    local v = n  / timeToTransition
                    local targetPos = targetParent:GetPosition()
                    local pos = LerpVector(currentPos, targetPos, v)
                    local rot = LerpRotation(currentRot, targetParent:GetRotation(), v)

                    moverDeco:SetPosition(pos)
                    moverDeco:SetRotation(rot)
              
                end
                n = n + DeltaTime() * multiplier
                Sleep(0)
            end   
            if not IsNull(moverDeco) then
                moverDeco:AttachToInPlace(targetParent, Symbol())
                if targetParent == secondMover then
                    if not IsNull(sideDecos) then
                        for i, decos in ipairs(sideDecos) do
                            if not IsNull(decos) then
                                decos:SetVisibility(true, true)
                            end
                        end
                    end
                    if not IsNull(sideEffects) then
                        for i, decos in ipairs(sideEffects) do
                            if not IsNull(decos) then
                                decos:FirePort("Enable")
                            end
                        end
                    end
                end
            end

        end
    end
    if IsNull(moverDeco) then
        if not IsNull(firstMover) then
            firstMover:FirePort("Disable")
        end
        if not IsNull(secondMover) then
            secondMover:FirePort("Disable")
        end
    end
    if not IsNull(currentState) then
        currentState:FirePort("Decrement")
    end
end

function MoveBetweenAnimPathsOnAttack(trigger)

    if not IsNull(moverDeco) then
        if currentState:GetCurrentValue() == 0 then --shooting or alerting while duster is already flying doesn't run this twice
            

            local targetParent = firstMover
            local currentParent = moverDeco:GetAttachParent()
            
            if currentParent == secondMover then

                currentState:FirePort("Increment")
                if not IsNull(sideDecos) then
                    for i, decos in ipairs(sideDecos) do
                        decos:SetVisibility(false, true)
                    end
                end
                if not IsNull(sideEffects) then
                    for i, decos in ipairs(sideEffects) do
                        decos:FirePort("Disable")
                    end
                end
            end
 
            
            moverDeco:Unattach()
   
 
            local n = 0
            local currentPos = moverDeco:GetPosition()
            local currentRot = moverDeco:GetRotation()
            local multiplier = 0.5
        
            while n < timeToTransition do
                if not IsNull(moverDeco) and not IsNull(targetParent) then
                    local v = n  / timeToTransition
                    local targetPos = targetParent:GetPosition()
                    local pos = LerpVector(currentPos, targetPos, v)
                    local rot = LerpRotation(currentRot, targetParent:GetRotation() , v)
                    moverDeco:SetPosition(pos)
                    moverDeco:SetRotation(rot)
              
                end
                    n = n + DeltaTime() * multiplier
                 
                    Sleep(0)
            end   
            if not IsNull(moverDeco) then
                moverDeco:AttachToInPlace(targetParent, Symbol())
            end
            
        end
    end
    if IsNull(moverDeco) then
        if not IsNull(firstMover) then
            firstMover:FirePort("Disable")
        end
        if not IsNull(secondMover) then
            secondMover:FirePort("Disable")
        end
    end

end

local function IsNight()

    if IsNull(mLevelInfo) then
        return false
    end
    local timeOfDay = mLevelInfo:GetTimeOfDay()
    return timeOfDay > nightThreshold or timeOfDay < dayThreshold
end

--Checks the time of day and sends the duster into the safety of the sky during night
function Transition()

    local night = true
    mLevelInfo = gRegion:GetLevelInfo()
    night = false
        while true do
            if IsNull(moverDeco) then
                break; 
            end
            if IsNight() ~= night then
                night = not night
                if night then
                    currentState:FirePort("Reset")
                    nightEscapePort:FirePort("Execute")
                else
                    currentState:FirePort("Reset")
                    dayReturnPort:FirePort("Execute")
                end
            end

            Sleep(2)
        end

end

function ExecuteSelf(self)
    Sleep(3) --Allows the assets to load in before starting
    self:FirePort("Execute")
end

--~ local dotProd = Dot(current, target)
--~ Clamp(dotProd, -1.0, 1.0)
--~ local theta = math.acos(dotProd)*time
--~ local relativeVec = target - current*dotProd
--~ return ((current*math.cos(theta)) + (relativeVec*math.sin(theta)))