-- Keeps forcing host migration (disconnecting the other player) and reconnecting.

function OnSessionJoinComplete(success)
    print("OnSessionJoinComplete - success=" .. tostring(success))
end

function OnSessionFound(success)
    print("OnSessionFound - success=" .. tostring(success))
    local searchResults = gMatchingService:GetSearchResults()
    if not success or IsNull(searchResults) or #searchResults == 0 then
        return
    end

    for i = 1, #searchResults do
        local sessionToJoin = searchResults[i]

        local playerProfile = gPlayerProfileMgr:GetPlayerProfile(0)
        local teamId = 0xFF
        local privateInvite = false
        gMatchingService:JoinSquadSession(playerProfile, sessionToJoin, privateInvite, teamId, "OnSessionJoinComplete")
        break
    end
end

function HostMigrationCycle()

    if gRegion:IsMaster() then

        local numAvatars = 0        

        -- Wait until we have a client
        while numAvatars < 2 do

            numAvatars = 0
            local players = gRegion:GetHumanPlayers()
            for p = 1, #players do
                if not IsNull(players[p]:GetAvatar()) then
                    numAvatars = numAvatars + 1
                end
            end

            Sleep(10)
        end

        Sleep(15)
        print("Have 2+ clients")

        local players = gRegion:GetHumanPlayers()
        for p = 1, #players do
            if not players[p]:IsLocal() then
                print("Disconnecting")
                gMatchingService:DisconnectPlayer(players[p], false)
                break
            end
        end

        Sleep(30)

        -- Try to find the other dude and connect to his session
        local playerProfile = gPlayerProfileMgr:GetPlayerProfile(0)
    
        local searchArgs = Engine.SessionSearch()
        searchArgs.originalSessionId = gMatchingService:GetSession():GetSessionId()
        gMatchingService:FindSessions(playerProfile, searchArgs, "OnSessionFound")

    else

        -- We're a client

    end

end
