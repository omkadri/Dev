encounterType = WeakResource()

function ActivateEncounter(hint)
    local npcMgr = gRegion:GetNpcMgr()
    local aiDir = npcMgr:GetAiDirector()

    while not aiDir:IsEnabled() and not aiDir:HasEncounterMgrCompletedMigration() do 
        Sleep(0)
    end
    
    while _T.MissionInitReady == false  do
        Sleep(0)
    end

    if IsNull(hint) or IsNull(encounterType) then
        return
    end

   
    local test = aiDir:ActivateSpecificEncounterAtSpecificHint(hint, encounterType)
    
    if not IsNull(test) then
    
    else
    
    end
end

