
procLevelInfo = Resource()


--Libs----------------
local mTimerMgr = nil
---------------------

--Vars---------------
local sDay = Symbol("Day")
local sNight = Symbol("Night")
_T.sup = nil
---------------------

local function SetEmissiveMapAtten(entity, val)
    if not IsNull(entity) then
        entity:SetMaterialParam(Lotus_Game.EMISSIVE_MAP_ATTEN, val)
    end
end

local function DisableEntites(ents)

    if IsNull(ents) then
        return
    end

    for i = 1, #ents do
    
        if not IsNull(ents[i]) then --Need to nilcheck since particle systems can be autokill, continue keyword in lua disabled
        
            if ents[i]:IsA(gParticleSysType) then
                ents[i]:Disable()
            elseif ents[i]:IsA(gDecorationType) then
                SetEmissiveMapAtten(ents[i], 0)
                --ents[i]:SetVisibility(false, true)
            elseif ents[i]:IsA(gSequencerType) then
                ents[i]:Disable()
            elseif ents[i]:IsA(gLightType) then
                ents[i]:TurnOff()
            elseif ents[i]:IsA(gWaterVolumeTriggerType) then
                ents[i]:Disable()
            end
            
        end
        
    end

end

local function EnableEntities(ents)
    
    if IsNull(ents) then
        return
    end

    for i = 1, #ents do

        if not IsNull(ents[i]) then --Need to nilcheck since particle systems can be autokill, continue keyword in lua disabled
        
            if ents[i]:IsA(gParticleSysType) then
                ents[i]:Enable()
            elseif ents[i]:IsA(gDecorationType) then
                SetEmissiveMapAtten(ents[i], 1)
                --ents[i]:SetVisibility(true, true)
            elseif ents[i]:IsA(gSequencerType) then
                ents[i]:Enable()
            elseif ents[i]:IsA(gLightType) then
                ents[i]:TurnOn()
            elseif ents[i]:IsA(gWaterVolumeTriggerType) then
                ents[i]:Enable()
            end
            
        end
        
    end

end

local function ApplyPostProcess(isDay)

    local levelInfo = gRegion:GetLevelInfo()
    if IsNull(procLevelInfo) or IsNull(levelInfo) then
        return
    end
    
    if isDay == true then
        levelInfo.postProcess = procLevelInfo.postProcess
        --levelInfo.postProcess:SetColorCorrection(dayColorCorrections[SRandomInt(1, #dayColorCorrections)])
    elseif isDay == false then
        levelInfo.postProcess = procLevelInfo.postProcessAlt
        --levelInfo.postProcess:SetColorCorrection(nightColorCorrections[SRandomInt(1, #nightColorCorrections)])
    end

end

local function SetState(state, dayEntities, nightEntities)

    if state == "Day" then
        Broadcast("Day")
        ApplyPostProcess(true)
        EnableEntities(dayEntities)
        DisableEntites(nightEntities)
    elseif state == "Night" then
        Broadcast("Night")
        ApplyPostProcess(false)
        EnableEntities(nightEntities)
        DisableEntites(dayEntities)
    end

end

function Start()

    Broadcast("DayNightTests.lua Started!")
    
    local TimerLib = require "Lotus.Interface.Libs.TimerMgr"
    mTimerMgr = TimerLib.CreateTimerMgr()
    
    local lights = gRegion:FindAll(gLightType)
    local dayEntities = gRegion:FindTagged(sDay)
    local nightEntities = gRegion:FindTagged(sNight)
    
    local sleepTime = 10
    
    while true do
        
        SetState("Day", dayEntities, nightEntities)
        
        Sleep(sleepTime)
        
        SetState("Night", dayEntities, nightEntities)
        
        Sleep(sleepTime)
        
        
        Sleep(0)
    end
    
    Broadcast("DayNightTests.lua Complete!")

end

function ToggleOvercast()

    Broadcast("DayNightTests.lua -- ToggleOvercast Started!")

end