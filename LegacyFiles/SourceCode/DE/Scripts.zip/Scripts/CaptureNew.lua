-- Capture Target
startAnim = Resource()
loopAnim = Resource()
effectEnemy = Type()
effectPlayer = Type()
disallowedVipTypes = {WeakResource()} -- If any of these types are plugged in to mission.vipAgent, don't use as an override
useClosestIntermediateSpawn = false
useClosestOverNav = false

local targetPhysicsVerySlow = Resource("/Lotus/Types/Enemies/CaptureTargets/CaptureTargetWalkVerySlow")
local targetPhysicsSlow = Resource("/Lotus/Types/Enemies/CaptureTargets/CaptureTargetWalkSlow")
local targetPhysicsMed = Resource("/Lotus/Types/Enemies/CaptureTargets/CaptureTargetWalkMedium")
local targetPhysicsFast = Resource("/Lotus/Types/Enemies/CaptureTargets/CaptureTargetWalkFast")
local targetPhysicsVeryFast = Resource("/Lotus/Types/Enemies/CaptureTargets/CaptureTargetWalkVeryFast")
local slowMinLevel = 5
local medMinLevel = 10
local fastMinLevel = 17
local veryFastMinLevel = 25
local captureTargetTier = 5

-- Mission Failed
escapeSequenceDelay = 1
missionFailDelay = 10

-- Escape button
escapeButtonScreen = Instance()
escapeButtonLight = Instance()
escapeButtonScreenOff = Resource()
escapeButtonScreenOn = Resource()
materialSlot = 1

-- Difficulty
local lockdownInterval = 30
local stallDistance = 65 --65
local nearStallDistance = 10
local nearStallTime = 5
local nearIntervalTime = 15
local healthExp = 2.5 --2.06
local healthMult = 0.0045 --0.0065
local healthCap = 100000
local healthMultiplier = {1, 1.75, 2.25, 2.75} -- 1p = 1x, 2p = 1.5x, 3p = 1.75x, 4p = 1.9x
--local captureTargetBaseHealth = 800
local minGuards = 2
local maxGuards = 5
local minLeaders = 1
local maxLeaders = 2
local minNumEnemies = {6, 11, 15, 20}
local maxNumEnemies =  {9, 16, 20, 25}
local baseShieldAmount = 500

-- XP
local captureXpMin = 800
local captureXpMax = 3000

-- Localized text
local targetsRemainingText = "/Lotus/Language/Game/CaptureTargetsRemaining"
local protectiveShieldDronesTag = Symbol("IcePlanetCapture")
local capturedMessage = Symbol("/Lotus/Language/Game/CaptureXpMessage")
local captureTargetText = "/Lotus/Language/Objectives/CaptureTarget"

local captureTargetShootMarker = WeakResource("/Lotus/Types/Enemies/CaptureTargets/CaptureTargetObjectiveMarker")
local captureTargetActionMarker = Type("/Lotus/Types/Enemies/CaptureTargets/CaptureTargetObjectiveNoKillMarker")

-- Types
airlockPanelInnerType = WeakResource("/Lotus/Types/Actions/CaptureEscapeButton") --/Lotus/Types/Actions/CaptureEscapeButton
airlockPanelOuterType = WeakResource("/Lotus/Types/Actions/CaptureEscapeButtonOuter") --/Lotus/Types/Actions/CaptureEscapeButtonOuter
local baseCaptureAvatarType = WeakResource("/Lotus/Types/Enemies/CaptureTargets/CaptureTargetBaseAvatar") --/Lotus/Types/Enemies/CaptureTargets/CaptureTargetBaseAvatar

-- Credit spawning
local healthIntervalPercent = 0.005 -- Used to calculate interval for chance to spawn credits from the target's max health.  Makes using a fixed value less risky for balancing in case the avatar's health is updated.

-- Net persistent vars
local NV_AGENTS_CAPTURED = Symbol("CaptureScore")
local NV_TOTAL_TARGETS = Symbol("TotalTargets")
local NV_AGENTS_ESCAPED = Symbol("AgentsEscaped")
local NV_TARGET_FLEEING = Symbol("CaptureTargetFleeing")
local NV_TARGET_BASE_HEALTH = Symbol("CaptureTargetBaseHealth")
local NV_CAPTURE_STAGE = Symbol("CaptureMissionStage") -- 0 = Target alive, 1 = Target downed, 2 = Target captured, 3 = Target died
local NV_CAPTURE_END_TIMER = Symbol("CaptureEndTimer")
local NV_CAPTURE_DOWNED_TIMER = Symbol("CaptureDownedTimer")
local NV_INDEX_EXTERMINATE_MID  = Symbol("ExterminateMid")
--local NV_TARGET_BASE_SHIELD = Symbol("CaptureTargetBaseShield")

-- Used to track capture targets on clients after they are spawned
local captureTargetsSpawned = false
local currentCaptureTargetCount = 0
local captureTargetTotal = 0

-- VO
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
transmissionSet = Resource()

-- Flee options
stallAtCloseRange = true
local bufferTime = 20 -- Before bleedout timer starts
local bleedoutTime = 60 -- Bleedout timer duration

-- Capture agent shoot target
shootPercentChance = 0.5
shootWaypoint = Instance()
shootDuration = 1
shootAlign = false
shootOutgoingPortForwarder = Instance()

-- Fortress
bunkerDestroyForwarders = {Instance()}

local GAMEMODE = require "Lotus.Scripts.Libs.CommonGamemodeFunctions"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local SQUADLINK = require "Lotus.Scripts.Libs.SquadLink"

local mLastContextAction = nil
----------------------------------------------------------------------------------------------------------------------------------------------------------------

local function ZoneCheckArray(zoneTag, objList)
    local objects = {}
    for i = 1, #objList do
        local zone = objList[i]:GetZone()
        if zone:GetTag() == zoneTag then
            table.insert(objects, objList[i])
        end
    end
    return objects
end

local function GetTargetMarker(zoneTag)
    local objectiveMarkers = gRegion:FindTagged(Symbol("CaptureObjectiveMarker"))
    local objMarker = GAMEMODE.ZoneCheck(zoneTag, objectiveMarkers)
    return objMarker
end

local function RunScriptTriggers(tag, disable, zoneTag)
    local scripts = gRegion:FindTagged(tag)
    if IsNull(scripts) or #scripts == 0 then
        print("Capture: " .. tostring(tag) .. " not found.")
        return
    end
    
    if not IsNull(zoneTag) then
        for i = #scripts, 1, -1 do
            local zone = scripts[i]:GetZone()
            local scriptZoneTag = zone:GetTag()
            if scriptZoneTag ~= zoneTag then
                table.remove(scripts, i)
            end
        end
    end
    
    for i = 1, #scripts do
        if not IsNull(scripts[i]) then
            scripts[i]:FirePort("Execute")
            if disable then
                scripts[i]:FirePort("Disable")
            end
        end
    end        
end

local function Closest(objects,pos,minRange)
    local closestDist = FLT_MAX
    local furthestDist = 0
    local closest
    local furthest
    for i = 1, #objects do
        local dist = objects[i]:DistanceToPoint(pos)
        if dist < closestDist and dist > minRange then
            closest = objects[i]
            closestDist = dist
        end
        if dist > furthestDist then
            furthest = objects[i]
            furthestDist = dist
        end
    end
    
    local result = closest
    if IsNull(result) then
        result = furthest   
    end
    return result
end

local function ClosestToObjectiveOverNav(objects,minRange)
    local closestDist = FLT_MAX
    local furthestDist = 0
    local closest
    local furthest
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()

    for i = 1, #objects do
        local dist = aiDir:GetDistanceToObjective(objects[i])
        if dist < closestDist then
            closest = objects[i]
            closestDist = dist
        end
        if dist > furthestDist then
            furthest = objects[i]
            furthestDist = dist
        end
    end
    
    local result = closest
    if IsNull(result) then
        result = furthest   
    end
    
    --[[if IsNull(result) then -- Couldn't find anything by checking over nav, fall back to distance check
        local objectiveRoomMarker = GetTargetMarker()
        local pos = objectiveRoomMarker:GetPosition()        
        result = Closest(objects,pos,0)
    end]]
    
    return result
end

local function ClosestBeforeObjective(objects, objectiveMarker)
    local closestObjectBeforeObjective
    local closestIndexBeforeObjective = 0
    local markerZone = objectiveMarker:GetZone()
    if not IsNull(markerZone) then
        local objLayerIndex = markerZone:GetLayerIndex()
    
        for i, object in ipairs(objects) do
            local zone = object:GetZone()
            if not IsNull(zone) then
                local layerIndex = zone:GetLayerIndex()
                if layerIndex > closestIndexBeforeObjective and layerIndex < objLayerIndex then
                    closestIndexBeforeObjective = layerIndex
                    closestObjectBeforeObjective = object
                end
            end
        end
    end
    
    if IsNull(closestObjectBeforeObjective) then
        closestObjectBeforeObjective = ClosestToObjectiveOverNav(objects, 0)
    end
    return closestObjectBeforeObjective
end

local function FurthestBeforeObjective(objects, objectiveMarker)
    local furthestObjectBeforeObjective
    local furthestIndexBeforeObjective = FLT_MAX
    local markerZone = objectiveMarker:GetZone()
    if not IsNull(markerZone) then
        local objLayerIndex = markerZone:GetLayerIndex()
    
        for i, object in ipairs(objects) do
            local zone = object:GetZone()
            if not IsNull(zone) then
                local layerIndex = zone:GetLayerIndex()
                if layerIndex < furthestIndexBeforeObjective and layerIndex < objLayerIndex then
                    furthestIndexBeforeObjective = layerIndex
                    furthestObjectBeforeObjective = object
                end
            end
        end
    end
    
    return furthestObjectBeforeObjective
end


local function PlayerDistanceToFleeingTarget(playerAvatar, targetAvatar)
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    local playerDistToObj = aiDir:GetDistanceToObjective(playerAvatar)
    local targetDistToObj = aiDir:GetDistanceToObjective(targetAvatar)
    local distance = playerDistToObj - targetDistToObj
    
    if distance < 0 then
        distance = 0 - distance
    end    
    
    if distance == 0 then
        local playerPos = playerAvatar:GetPosition()
        local targetPos = targetAvatar:GetPosition()    
        distance = Distance(playerPos, targetPos)
    end
    
    return distance
end

local function GetMissionObjText()
    local mission = gGameRules:GetMission()
    local defaultText = { text = captureTargetText, icon = 2 }
    if not IsNull(mission) then
        local goalTag = mission.goalTag
        if IsNull(goalTag) or goalTag == "" then
            return defaultText
        end
        
        local textData = {
            { goalTag = Symbol("SpyQuestMission"), text = "/Lotus/Language/G1Quests/SpyQuestMission1Title", icon = 2 },
        }
        
        for i, data in ipairs(textData) do
            if data.goalTag == goalTag then
                return data
            end
        end
    end
    return defaultText
end

local function UpdateHud()
    local gameRules = gGameRules
    local totalTargets = gameRules:GetNetPersistentVar(NV_TOTAL_TARGETS)
    if totalTargets > 1 then
        local targetsCaptured = gameRules:GetNetPersistentVar(NV_AGENTS_CAPTURED)
        local escaped = gameRules:GetNetPersistentVar(NV_AGENTS_ESCAPED)
        local targetsRemaining = math.max(totalTargets - escaped - targetsCaptured, 0)
        if IsNull(_T.CaptureNewProgressBar) then
            _T.CaptureNewProgressBar = _T.AddHudTracker("CNProgressBar", LOTUS_UTIL.HT_PROGRESS_BAR, 0.2)
            _T.CaptureNewProgressBar.SetFlareColor(_G.UIColor_DarkBlue)
            _T.CaptureNewProgressBar.SetValue(-1)
            _T.CaptureNewProgressBar.SetLabel("")
        end
        _T.CaptureNewProgressBar.SetGoalLabel(_T.CaptureNewProgressBar.Localize(targetsRemainingText) .. " " .. targetsRemaining)
    end
end

local function IsDisallowedAgentType(vipAgent)
    for i, disallowedVipType in ipairs(disallowedVipTypes) do
        if vipAgent == disallowedVipType then
            return true
        end
    end
    return false
end

local function GetDifficultyTier(captureTargetSpec)

    for i, enemy in ipairs(captureTargetSpec) do -- Merge all enemies if 3 tiers not set up
        local tier = enemy.tier
        if tier == captureTargetTier then
            return captureTargetTier
        end
    end

    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    local minLevel = aiDir:GetMinEnemyLevel()
    local tier = math.min(math.floor(minLevel / 10), 2)
    return tier
end

local function AddTargetsToAiSpec()
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()
    
    --Execute the faction conflict script (ship vs ship/corpus vs grineer/etc)    
    local gameRules = gGameRules
    local mission = gameRules:GetMission()
    local captureTargetSpec = mission:GetExtraEnemies()
    local scaledTier = GetDifficultyTier(captureTargetSpec)
        
    if not IsNull(captureTargetSpec) and #captureTargetSpec > 0 then
        for i=1,#captureTargetSpec do
            local mai = captureTargetSpec[i]
            local prob = mai.probability
            local agent = mai.agent
            local maxSim = mai.maxSimultaneous
            local tier = mai.tier
            local agentType = Type(agent)
            if (scaledTier == captureTargetTier or (scaledTier ~= captureTargetTier and tier == scaledTier)) and not IsNull(agentType) then
                aiDir:AddMissionAIType(agentType, prob, maxSim, captureTargetTier)
            end
        end
    else
        print("Capture: No target AISpec found, make sure this mission has a VIP agent set.")
    end      
end

local function FindValidSpawns(spawnControls, zoneTag)
    local results = {}
    for i = 1, #spawnControls do
        local zone = spawnControls[i]:GetZone()
        local tag = zone:GetTag()
        if spawnControls[i]:IsEnabled() and tag == zoneTag then
            table.insert(results, spawnControls[i])
        end
    end
    return results
end

local function IsMultiTargetMission()
    local numTargets = gGameRules:GetNetPersistentVar(NV_TOTAL_TARGETS)
    if numTargets > 1 then
        return true
    else
        return false
    end
end

local function ClosestToPlayerOverNav(objects, objectiveMarker)
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    local playerPosition
    local closestToPlayerOverNav
    local shortestDistance = 0
    local playerSpawns = gRegion:FindTagged(Symbol("PlayerSpawn"))
    local validPlayerSpawns = FindValidSpawns(playerSpawns, Symbol("Spawn")) -- the first player-spawn tile will have the Spawn tag
    if #validPlayerSpawns > 0 then
        playerPosition = validPlayerSpawns[1]:GetPosition() 
    end
    
    if #objects > 0 and not IsNull(playerPosition) then
        for i, object in ipairs(objects) do
            local objectPosition = object:GetPosition()
            local distance = aiDir:GetHighLevelPathDistanceBetweenPositions(objectPosition, playerPosition)
            
            if IsNull(closestToPlayerOverNav) then
                closestToPlayerOverNav = object
                shortestDistance = distance
            end
            if not IsNull(distance) then
                if distance < shortestDistance then
                    closestToPlayerOverNav = object
                    shortestDistance = distance
                end
            end
        end
    end
    
    if IsNull(closestToPlayerOverNav) or shortestDistance == 0 then
        closestToPlayerOverNav = FurthestBeforeObjective(objects, objectiveMarker)
    end
    return closestToPlayerOverNav
end

-- Objective -----------------------------------------------------------------------------------------------------------------------------------------------------

local function SpawnGuardReinforcements(minRange, maxRange, checkVis, checkInfluence, checkLockedDoors, target)
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    local mission = gGameRules:GetMission()
    local numGuards = math.floor(Lerp(minGuards, maxGuards, mission.difficulty))
    local numLeaders = math.floor(Lerp(minLeaders, maxLeaders, mission.difficulty))
    local enemyLevel = aiDir:GetMaxEnemyLevel()
    local numPlayers = gRegion:GetHumanPlayerAvatarCount()
    local enemyCap = math.floor(Lerp(minNumEnemies[numPlayers], maxNumEnemies[numPlayers], mission.difficulty))
    local spawnPt    
    
    if aiDir:GetActiveAICount() > enemyCap - numGuards then
        return
    end
    if enemyLevel <= 5 then
        numLeaders = 0
    end
    
    aiDir:SetEnableAutoSpawns(false)
    aiDir:SetCustomSpawnSelectionFilter(minRange, maxRange, 0, 1, checkVis, checkInfluence, checkLockedDoors) --3, 40, 0, 1, false, false, true
    aiDir:SetCustomSpawnSource(target)
    aiDir:SetUseCustomSpawnSelectionFilter(true)
    
    local guardsSpawned = 0
    for i = 1, numGuards do
        local agent
        if i <= numLeaders then
            agent = aiDir:CreateRandomAgent(spawnPt, Symbol("CaptureGuards"), enemyLevel, nil, Engine.EXIMUS)
        else
            agent = aiDir:CreateRandomAgent(spawnPt, Symbol("CaptureGuards"), enemyLevel, nil, Engine.STANDARD)
        end
        if not IsNull(agent) then
            agent:SetAlert()
            agent:MoveTo(target, true, false, false)
            guardsSpawned = guardsSpawned + 1
        end
    end
    
    if gFlashMgr:GetConfigBool("Engine.DeveloperMode") then
        print("Capture: Spawned " .. guardsSpawned .. " reinforcements.")
    end
    aiDir:SetUseCustomSpawnSelectionFilter(false)
    aiDir:SetEnableAutoSpawns(true)
    
end

local function ScaleHealthAndShield(target, level, numPlayers)

    print("ScaleHealthAndShield")

    local gameRules = gGameRules
    local baseHealth = gameRules:GetNetPersistentVar(NV_TARGET_BASE_HEALTH)
    --local baseShield = gameRules:GetNetPersistentVar(NV_TARGET_BASE_SHIELD)
    local baseShield = baseShieldAmount
    
    if _T.faction == Symbol("Grineer") then
        baseHealth = baseHealth + baseShield
    end

    -- Scale health
    local scaledHealth = baseHealth * (1 + ((level-1) ^ healthExp) * healthMult)
    local scaledHealth = math.ceil(scaledHealth * healthMultiplier[numPlayers])
    if scaledHealth > healthCap then
        scaledHealth = healthCap
    end
    target:SetMaxHealth(scaledHealth)

    if gPromotedToHost then
        target:SetHealth(target:GetHealth()) -- that's just to cap to max health
    else
        target:SetHealth(scaledHealth)
    end
    
    -- Scale shield
    if _T.faction ~= Symbol("Grineer") then
        local scaledShield = baseShield * (1 + ((level-1) ^ healthExp) * healthMult)
        local scaledShield = math.ceil(scaledShield * healthMultiplier[numPlayers])
        if scaledShield > healthCap then
            scaledShield = healthCap
        end

        if baseShield > 0 then
            local damageControl = target:DamageControl()
            damageControl:SetMaxShield(scaledShield)
            damageControl:SetShield(scaledShield)
        end
    end
end

local function ApplyTargetScaling()
    local gameRules = gGameRules
    local mission = gameRules:GetMission()
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()
    local targets = gRegion:FindAll(baseCaptureAvatarType)
    local level = aiDir:GetMaxEnemyLevel() + mission.vipLevelModifier
    local numPlayers = gRegion:GetHumanPlayerAvatarCount()
    
    -- Set scaled walk speed override
    local newTargetPhysics = targetPhysicsVerySlow
    if level >= veryFastMinLevel then
        newTargetPhysics = targetPhysicsVeryFast
    elseif level > fastMinLevel then
        newTargetPhysics = targetPhysicsFast
    elseif level >= medMinLevel then
        newTargetPhysics = targetPhysicsMed
    elseif level >= slowMinLevel then
        newTargetPhysics = targetPhysicsSlow
    end
    
    -- Apply initial scaling
    for i, target in ipairs(targets) do
        if not IsNull(newTargetPhysics) then
            target:SetPhysicsBehaviorAndRegister(newTargetPhysics)
        end
        ScaleHealthAndShield(target, level, numPlayers)
    end
       
    -- Keep scaling until the target is sighted (and the session is locked) in case more players join
    local previousNumPlayers = numPlayers
    local targetFleeing = 0
    while not IsNull(targets) and targetFleeing == 0 do
        targetFleeing = gameRules:GetNetPersistentVar(NV_TARGET_FLEEING)
        numPlayers = gRegion:GetHumanPlayerAvatarCount()
        if numPlayers ~= previousNumPlayers and numPlayers > 0 then
            targets = gRegion:FindAll(baseCaptureAvatarType)
            for i, target in ipairs(targets) do
                ScaleHealthAndShield(target, level, numPlayers)
            end
        end
        previousNumPlayers = numPlayers
        Sleep(2)
    end
end

local function ShipEscapeSequence(failedMission, zoneTag)
    --local aiDir = npcManager:GetAiDirector()
    --aiDir:SetLevelAlert(true)
    GAMEMODE.SetAlarms(true)
    Sleep(escapeSequenceDelay)
    
    local escapePortForwarders = gRegion:FindTagged(Symbol("ShipEscapeEvents"))
    local escapePortForwarder = GAMEMODE.ZoneCheck(zoneTag, escapePortForwarders)
    if not IsNull(escapePortForwarder) then
        escapePortForwarder:FirePort("TriggerPort")
    end

    if failedMission then
        Sleep(missionFailDelay-4)
        if IsMultiTargetMission() then
            DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("MissionFailedMulti"), 0)
        else
            DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("MissionFailed"), 0)
        end        
        Sleep(4)

        SQUADLINK.CompleteLink("MobileDefenseCapture", SQUADLINK.FAILURE)
        gGameRules:EndGame(Engine.GameRules_GS_FAILURE)
    end
end

local function SetActionsEnabled(avatar, enabled)
    if not IsNull(avatar) then
        local gameActionController = avatar:GameActionControl()
        if not IsNull(gameActionController) then
            gameActionController:SetCanExecuteActions(enabled)
        end
    end
end

local function CaptureEndTimer()
    local gameRules = gGameRules
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    local t = gameRules:GetNetPersistentVar(NV_CAPTURE_END_TIMER, 0)
    
    while t < 60 do
        t = t + 1
        gameRules:SetNetPersistentVar(NV_CAPTURE_END_TIMER, t)
        Sleep(1)
    end
    aiDir:SetLevelAlert(false)
    
    while t < 300 do
        t = t + 1
        gameRules:SetNetPersistentVar(NV_CAPTURE_END_TIMER, t)
        if gameRules:GetNetPersistentVar(NV_INDEX_EXTERMINATE_MID, 0) > 0 then
            return
        end
        Sleep(1)
    end
    aiDir:SetEnableAutoSpawns(false)
end

local function _CompleteCapture()
    local mission = gGameRules:GetMission()
    
    -- XP
    local scaledXp = Lerp(captureXpMin, captureXpMax, mission.difficulty)
    GAMEMODE.GiveAllPlayersXP(scaledXp, capturedMessage)
    
    -- Complete mission
    GAMEMODE.MarkExtraction()
    OBJTXT.SetExtractObjText()
    OBJTXT.RemoveObjTimer()
    DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("ObjectiveComplete"), 0)
    gGameRules:SetNetPersistentVar(NV_CAPTURE_STAGE, 2)
    SQUADLINK.CompleteLink("MobileDefenseCapture", SQUADLINK.SUCCESS)
    
    CaptureEndTimer()
end

local function SpawnCaptureTarget(spawncontrol)
    local gameRules = gGameRules
    local mission = gameRules:GetMission()
    local vipSpawnType = Type(mission.vipAgent)
    
    -- Set target level
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()
    local level = math.floor(aiDir:GetMaxEnemyLevel()) + mission.vipLevelModifier
    local enhanceType = Engine.STANDARD
    local canEnhance = false
    if mission.leadersAlwaysAllowed then
        enhanceType = Engine.EXIMUS
        canEnhance = true
    end
    
    -- Spawn target
    local team = Symbol("CaptureTeam")
    local spawnpoint = spawncontrol:GetSpawnPoints()[1]
    local agent
    if not IsNull(vipSpawnType) and not IsDisallowedAgentType(vipSpawnType) then
        agent = aiDir:CreateAgent(vipSpawnType, spawnpoint, team, level, nil, enhanceType)
    else
        local agentType = aiDir:GetRandomEnemyAgentType(Symbol(), level, canEnhance, false, captureTargetTier, true)
        agent = aiDir:CreateAgent(agentType, spawnpoint, team, level, nil, enhanceType)
    end  
    if IsNull(agent) then
        print("Capture: Failed to create capture target agent!")
        return
    end
    local avatar = agent:GetAvatar()
    
    --Need to ensure that avatar is a VIP to protect it from certain powers
    avatar:SetIsVIP()
    
    -- Set base health for scaling
    local baseHealth = avatar:GetInitialMaxHealth()
    local baseShield = avatar:DamageControl():GetMaxShield()
    gameRules:SetNetPersistentVar(NV_TARGET_BASE_HEALTH, baseHealth)
    --gameRules:SetNetPersistentVar(NV_TARGET_BASE_SHIELD, baseShield)
    
    
    
    local faction = mission:GetFactionTag()
    if not IsNull(faction) then
        avatar:SetFaction(faction)
    else
        avatar:SetFaction(Symbol("Grineer")) -- temp
        print("Capture: No faction is set for this mission, default target's faction is Grineer.")
    end

    if gameRules:GetMission().goalId ~= "" then

        if gameRules:GetMission().goalTag == protectiveShieldDronesTag then
            local maxShield = level * 50
            local avatarInv = avatar:InventoryControl()
            avatarInv:AddUpgrade(Game.AVATAR_SHIELD_MAX, Game.ADD, maxShield)
            avatarInv:AddUpgrade(Game.WEAPON_DAMAGE_AMOUNT, Game.MULTIPLY, 2.0)
            avatar:DamageControl():SetShield(maxShield)
        
            avatar:DamageControl():AddShieldAuraUpgrade(Game.AVATAR_SHIELD_MAX, Game.SET, maxShield)
            avatar:DamageControl():AddShieldAuraUpgrade(Game.AVATAR_SHIELD_RECHARGE_RATE, Game.SET, 10000)
            avatar:DamageControl():AddShieldAuraUpgrade(Game.AVATAR_SHIELD_RECHARGE_DELAY, Game.SET, 0)
            avatar:DamageControl():AddShieldAuraUpgrade(Game.AVATAR_DAMAGE_RESISTANCE, Game.SET, 1.0, nil, nil, Engine.DT_POISON)
            avatar:DamageControl():AddShieldAuraUpgrade(Game.GAMEPLAY_FACTION_DAMAGE_RESISTANCE, Game.MULTIPLY, 0.0)
            avatar:DamageControl():AddProcImmunity(Engine.DT_RADIATION, Symbol())
        
            local suit = avatarInv:GetActivePowerSuit()
            if not IsNull(suit) then
                local ability = suit:GetAbilityByIndex(0)
                if not IsNull(ability) then
                    ability:SetCooldownDuration(4)
                end
            end

            avatar:GiveItem(Type("/Lotus/Upgrades/Mods/DirectorMods/EnergyDrainCaptureTargetAura"), false)
            --avatar:GiveItem(Type("/Lotus/Weapons/CaptureTargetWeapons/CaptureTargetCorpusHandCannon"), true)

            -- lazy load drone agent
            gGameRules:BroadcastRequestResourceBatch("/Lotus/Types/Enemies/Corpus/Drones/AIWeek/ShieldDroneAgent")

            for i = 1, 3 do
                local droneAgent = aiDir:CreateAgentNearEntity(Type("/Lotus/Types/Enemies/Corpus/Drones/AIWeek/ShieldDroneAgent"), avatar, 5, team, level, nil, Engine.EXIMUS)
                if not IsNull(droneAgent) then
                    droneAgent:SetIsIgnoredByAiDirector(true)

                    local droneAvatar = droneAgent:GetAvatar()
                    droneAvatar:SetFaction(avatar:GetFaction())
                    droneAvatar:SetIsVIP()
                
                    -- capture target is fast -- drones need to be able to keep up
                    local droneInventory = droneAvatar:InventoryControl()
                    droneInventory:AddUpgrade(Game.AVATAR_MOVEMENT_SPEED, Game.MULTIPLY, 3.5)
                    droneInventory:AddUpgrade(Game.AVATAR_HEALTH_MAX, Game.STACKING_MULTIPLY, 6)
                    droneAvatar:SetHealth(droneAvatar:GetMaxHealth())
                end
            end
        end        

        aiDir:SetMaxEnhancedAgents(9)
        aiDir:SetLevelAlert(true)
        aiDir:ResetIntensity()
        GAMEMODE.SetAlarms(true)
    end
end

local function CompleteTargetSpawn()
    local gameRules = gGameRules
    gameRules:SetNetPersistentVar(NV_TOTAL_TARGETS, captureTargetTotal)
    
    local allTargetsSpawned = true

    -- Check target count
    if not IsNull(baseCaptureAvatarType) then
        local targets = gRegion:FindAll(baseCaptureAvatarType, Vector(), 0, FLT_MAX)
        if #targets ~= captureTargetTotal then
            print("Capture: " .. captureTargetTotal .. " targets expected but " .. #targets .. " spawned!")
            gameRules:SetNetPersistentVar(NV_TOTAL_TARGETS, #targets)
            UpdateHud()
            allTargetsSpawned = false
        end
    end
    
    if allTargetsSpawned then
        print("Capture: " .. captureTargetTotal .. " targets spawned successfully.")
        UpdateHud()
    end
    
    ApplyTargetScaling()
end

local function SpawnVIPOnLoad(s)
    print("SpawnVIPOnLoad: " .. tostring(s))
    
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()

    aiDir:TrackTaggedEntities(Symbol("CaptureSpawn"))

    local objectiveMarker
    if s > 1 then
        objectiveMarker = GetTargetMarker(Symbol("Boss"))
    else
        objectiveMarker = GetTargetMarker(Symbol("Objective"))
    end
        
    aiDir:SetObjective(objectiveMarker)
    
    --local spawnControls = aiDir:FindTaggedReachableByPlayersBeforeObjective(Symbol("CaptureSpawn"))
    local spawnControls = gRegion:FindTagged(Symbol("CaptureSpawn"))
    local captureSpawns = FindValidSpawns(spawnControls, Symbol("Intermediate"))
    
    if #captureSpawns == 0 then
        for i = 1, #spawnControls do
            if spawnControls[i]:IsEnabled() then
                table.insert(captureSpawns, spawnControls[i])
            end
        end
    end
    
    local captureSpawn
    if IsMultiTargetMission() or useClosestIntermediateSpawn then
        captureSpawn = ClosestBeforeObjective(captureSpawns, objectiveMarker)
    elseif useClosestOverNav then
        captureSpawn = ClosestToPlayerOverNav(captureSpawns, objectiveMarker)
    else
        captureSpawn = FurthestBeforeObjective(captureSpawns, objectiveMarker)
    end

    if not IsNull(captureSpawn) then
        SpawnCaptureTarget(captureSpawn)
        captureSpawn:Disable()
            
        -- Break fans and other destroyable objects which block the target's path (only objects between the target's spawn and the escape room)
        local targetDistToObjective = aiDir:GetDistanceToObjective(captureSpawn)
        local distToObjective
        local breakableObjects = gRegion:FindTagged(Symbol("BreakableOnPath"))
        for i = 1, #breakableObjects do
            distToObjective = aiDir:GetDistanceToObjective(breakableObjects[i])
            if distToObjective < targetDistToObjective then
                breakableObjects[i]:FirePort("Destroy")
            end
        end
    else
        print("Capture: Couldn't find any valid capture spawns!")
    end
    
    -- Disable temp objective marker
    local objectiveRoomMarker = GetTargetMarker(Symbol("Objective"))
    if IsNull(objectiveRoomMarker) then
        objectiveRoomMarker = GetTargetMarker(Symbol("Boss")) -- Transition levels only use the boss room for capture
    end
    objectiveRoomMarker:FirePort("Disable")

    currentCaptureTargetCount = currentCaptureTargetCount + 1
    if currentCaptureTargetCount == captureTargetTotal then
        CompleteTargetSpawn()
    end
end

function OnRegisterForBeacon()
end

function OnUnregisterForBeacon()
end

function StartCaptureMission() -- Runs from ObjectiveTrigger
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()
    
    print("Capture: Starting mission")
    
    -- Check to see if script should run
    if gPromotedToHost then
        return
    end

    SQUADLINK.AcceptLink("MobileDefenseCapture")
    
    -- Wait for players
    local numPlayers
    while numPlayers == 0 do
        numPlayers = gRegion:GetHumanPlayerAvatarCount()
        Sleep(0)
    end

    local objectiveRoomMarker = GetTargetMarker(Symbol("Objective"))
    if IsNull(objectiveRoomMarker) then
        objectiveRoomMarker = GetTargetMarker(Symbol("Boss")) -- Transition levels only use the boss room for capture
    end
    aiDir:Enable(true)
    aiDir:SetObjective(objectiveRoomMarker)
    objectiveRoomMarker:FirePort("Enable")
    aiDir:SetAllowLevelAlerts(false)
    
    -- Pick trigger more than min distance away from players, fall back to objective room if no points are available
    local spawnAmount = 0
    local captureObjectiveRoom = GetTargetMarker(Symbol("Objective"))
    local captureBossRoom = GetTargetMarker(Symbol("Boss"))
    --local captureObjectiveRooms = gRegion:FindTagged(Symbol("CaptureAirlockDetectScript"))
    if not IsNull(captureObjectiveRoom) then
        spawnAmount = spawnAmount + 1
    end
    if not IsNull(captureBossRoom) then
        spawnAmount = spawnAmount + 1
    end    
    --[[if #captureObjectiveRooms > 1 then
        spawnAmount = 2
    end]]
    captureTargetTotal = spawnAmount
    
    -- Start VO
    DIALOG.SetupMissionTransmissionSet(transmissionSet)
    if spawnAmount > 1 then
        DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("ObjectiveStartMulti"), 0)
        _T.ObjectiveRestateTag = Symbol("ObjectiveRestateMulti")
    else
        DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("ObjectiveStart"), 0)
    end
    local objData = GetMissionObjText()
    OBJTXT.SetPrimaryObjText(objData.text, objData.icon)
    
    -- Spawn agent
    AddTargetsToAiSpec() -- Merge capture target AI spec with main spec
    for i = 1, spawnAmount do
        if i > 1 then
            SpawnVIPOnLoad(2) -- Spawn near boss room
        else
            if not IsNull(captureObjectiveRoom) then
                SpawnVIPOnLoad(1) -- Spawn near objective room
            elseif not IsNull(captureBossRoom) then
                SpawnVIPOnLoad(2)  -- Spawn near boss room
            end
        end
    end
    
end

function CaptureLockdown()
    --[[print("Capture: Lockdown Started")
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    while aiDir:GetLockDown() do
        Sleep(0)
    end
    print("Capture: Lockdown Ended")
    _T.TimeSinceLastLockdown = 0]]
end

function GrineerFortCaptureSetup() -- Run on LevelStartScript
    -- Set traps active
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    local index = bunkerDestroyForwarders[1]:GetZone():GetLayerIndex()
    local securityLevelSymbol = Symbol("SecurityLevel")
    aiDir:AddZoneMark(securityLevelSymbol, index, 2, -1, 1, 2) --DB fixed for zoneId 1-MaxZones range

    -- Pick 1 random bunker destination
    local destinationBunkerId = RandomInt(1, #bunkerDestroyForwarders)
    table.remove(bunkerDestroyForwarders, destinationBunkerId)
    for i = 1, #bunkerDestroyForwarders do
        bunkerDestroyForwarders[i]:FirePort("TriggerPort")
    end
end

-- Target -------------------------------------------------------------------------------------------------------------------------------------------------------

function Capture(action, avatar) -- Triggered from the capture target's context action, runs on host and all clients when activated
    -- UI
    OBJTXT.PauseObjTimer(true)

    -- Disable action so it can't be used by another player
    action:Disable()
    mLastContextAction = action

    -- The start animation offers a timing window where the player may interact with another object, causing undefined behavior. Disable actions.
    SetActionsEnabled(avatar, false)
    
    --run a child script on the avatar so we don't get stuck in an anim-loop if the CA is deleted
    _T.CapturedAvatar = action:GetAttachParent()
    avatar:ScriptRunChildScript(Symbol("PlayCaptureAnimation"), false)
end

function PlayCaptureAnimation(avatar)
    local gameRules = gGameRules
    local target = _T.CapturedAvatar
    
    -- Capture effects
    local humanPlayer = avatar:GetPlayer()

    avatar:PlayUpperBodyAnimation(nil, false)
    avatar:PlayAnimation(nil, false)

    avatar:PlayNonReplicatedAnimation(startAnim, true, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_ONCE, true)
    avatar:PlayNonReplicatedAnimation(loopAnim, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_LOOP, true) -- blocking, so that we cannot run around while capturing
    
    local targetFx = nil
    if not IsNull(target) then
        targetFx = target:Attach(effectEnemy, EMPTY_SYMBOL)
        local agent = target:GetAgent()
        if not IsNull(agent) then
            agent:PlayPhrase(6) -- Play 'death' bark
        end
    end
    
    local playerFx = avatar:Attach(effectPlayer, EMPTY_SYMBOL)
    local t = 0.0
    while t < 1.1 do
        if not IsNull(avatar) and avatar:GetHealth() > 0 and not avatar:IsPlayingAnimation(loopAnim) then
            avatar:PlayNonReplicatedAnimation(loopAnim, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_LOOP, true) -- blocking, so that we cannot run around while capturing
        else
            -- avatar has died after starting action, restore target to visibility and re-enable the contextaction
            if (IsNull(avatar) or avatar:GetHealth() <= 0 or avatar:DamageControl():IsPreDeath()) and mLastContextAction ~= nil and not IsNull(target) then
                mLastContextAction:Enable()
                target:SetMaterialParam(Lotus_Game.CLOAK, 0)
                target:SetDissolve(0)
                mLastContextAction = nil
                targetFx:Destroy()
                playerFx:Destroy()
                OBJTXT.PauseObjTimer(false)

                SetActionsEnabled(avatar, true)
                return
            end
        end
        
        if not IsNull(target) then
            target:SetMaterialParam(Lotus_Game.CLOAK, t)
            target:SetDissolve(t)
        end
        
        t = t + DeltaTime() * 0.2
        Sleep(0)
    end
    
    if not IsNull(avatar) and avatar:IsPlayingAnimation(loopAnim) then
        avatar:PlayNonReplicatedAnimation(nil, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_ONCE, false)
    end
    
    if IsNull(avatar) and not IsNull(humanPlayer) then
        avatar = humanPlayer:GetAvatar()  -- Avatar may have died and respawned, so grab the new one
    end

    SetActionsEnabled(avatar, true)

    if not IsNull(target) then
        target:Destroy()
    end
    if not IsNull(avatar) then
        avatar:InventoryControl():GiveXP(250, avatar, Symbol("/Lotus/Language/Actions/Captured"))
        if avatar:IsPlayingAnimation(loopAnim) then
            avatar:PlayNonReplicatedAnimation(nil, false)
        end
    end
        
    -- Complete objective if all targets captured
    if gGameRules:IsA(gEndlessExterminationGameRulesType) then
        _T.CaptureComplete = true
    elseif gRegion:IsMaster() then
        local targetsCaptured = gameRules:GetNetPersistentVar(NV_AGENTS_CAPTURED)
        targetsCaptured = targetsCaptured + 1
        gameRules:SetNetPersistentVar(NV_AGENTS_CAPTURED, targetsCaptured) -- Set number of agents captured
        
        local totalTargets = gameRules:GetNetPersistentVar(NV_TOTAL_TARGETS)
        local escapedTargets = gameRules:GetNetPersistentVar(NV_AGENTS_ESCAPED)
        print("Capture: Target Captured. Total: " .. totalTargets .. ", Captured: " .. targetsCaptured .. ", Escaped: " .. escapedTargets)
        local targetsRemaining = math.max(totalTargets - targetsCaptured - escapedTargets, 0)
        UpdateHud()
        
        if targetsCaptured >= (totalTargets - escapedTargets) then
            _CompleteCapture()
        else
            DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("TargetCapturedMulti"), 0)
        end

        --[[local npcManager = gRegion:GetNpcMgr()
        local aiDir = npcManager:GetAiDirector()
        aiDir:SetLevelAlert(true)]]
    end
end

function CaptureFlee(instigator, lookTrigger)
    local gameRules = gGameRules
    local target = lookTrigger:GetAttachParent()
    
    if IsNull(target) then
        return -- Target captured before we had a chance to run this script
    end

    -- Wait until alerted and visible
    local agent = target:GetAgent()
    if gameRules:GetNetPersistentVar(NV_TARGET_FLEEING) == 0 then
        print("Capture: Waiting to flee...")
        while not agent:IsAlerted() and not lookTrigger:IsVisible() do
            if IsNull(agent) or IsNull(target) then
                return -- Target captured before we had a chance to run this script
            end
            Sleep(0)
        end
        print("Capture: Target fleeing")
        DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("TargetSighted"), 0)
    end
    gameRules:SetNetPersistentVar(NV_TARGET_FLEEING, 1)
       
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()
    local currentHealth = target:GetHealth()
    local maxHealth = target:GetMaxHealth()
    local healthInterval = maxHealth * healthIntervalPercent
    local currentDest
    local h = currentHealth
    
    aiDir:SetLevelAlert(true)
    gameRules:HideGameSession(true) -- Hide session when pursuit begins
    
    local escapeRoomTriggers = gRegion:FindTagged(Symbol("EscapeRoomBounds"))
    local escapeButtons = gRegion:FindTagged(Symbol("EscapeButton"))

    -- Find nearest escape button
    local buttonDist = FLT_MAX
    local escapeButton
    for i = 1, #escapeButtons do -- Find closest escape button along nav
        if escapeButtons[i]:IsEnabled() then
            aiDir:SetObjective(escapeButtons[i])
            local targetDistToObjective = aiDir:GetDistanceToObjective(target)
            if targetDistToObjective < buttonDist then
                buttonDist = targetDistToObjective
                escapeButton = escapeButtons[i]
            end
        end
    end
    aiDir:SetObjective(escapeButton)
    
    -- Flee to waypoint
    _T.TimeSinceLastLockdown = 10 -- Subtract 10s from initial lockdown delay
    local t = 10
    local timeElapsed = 0
    local lastNearStallTime = 0
    local stalledNearPlayer = false
    local downedMarkerUpdated = false
    local sleepTime = 0.1
    local downedTime = gGameRules:GetNetPersistentVar(NV_CAPTURE_DOWNED_TIMER)
    
    while not IsNull(target) do
        agent = target:GetAgent()
        if IsNull(agent) then
            return
        end
        
        local devModeEnabled = gFlashMgr:GetConfigBool("Engine.DeveloperMode")
        local avatar = agent:GetAvatar()
        local stallTarget = true
        
        -- Don't stall the target if being damaged
        currentHealth = target:GetHealth()
        local healthDiff = h - currentHealth
        if healthDiff > 0 then
            stallTarget = false
        end
        
        agent:SetAggro(100)
        agent:EnableCoverUse(true)
        agent:SetCombatAwareness()
        
        if t > 1 then

            h = target:GetHealth() -- Store health every second to prevent stalling if target is being damaged
        
            -- Stall target
            local players = gRegion:GetHumanPlayerAvatars()
            local targetAloneInTile = true
            local usePanicButton = false
            
            local targetZone = avatar:GetZone()
            local targetLayerIndex
            if not IsNull(targetZone) then
                targetLayerIndex = targetZone:GetLayerIndex()
            end
            
            for i = 1, #players do
                local distance = PlayerDistanceToFleeingTarget(players[i], avatar)
                local playerZone = players[i]:GetZone()
                
                if not IsNull(playerZone) and not IsNull(targetZone) then
                    
                    -- Stall if far away                      
                    local playerLayerIndex = playerZone:GetLayerIndex()
                    if playerLayerIndex == targetLayerIndex then
                        targetAloneInTile = false
                    end
                    if not targetAloneInTile then
                        if distance < stallDistance then
                            stallTarget = false
                        end
                    else
                        if _T.TimeSinceLastLockdown > lockdownInterval then 
                            usePanicButton = true -- Check if in tile with no players, don't stall and send to nearest panic button
                        end
                        if distance < stallDistance then
                            stallTarget = false
                        end
                    end

                    -- Stall if close
                    if stallTarget == false and stallAtCloseRange then -- Check if close to player
                        if distance <= nearStallDistance then
                            local timeSinceStarted = timeElapsed - lastNearStallTime
                            if timeSinceStarted <= nearStallTime or timeSinceStarted > nearIntervalTime then
                                if not stalledNearPlayer then
                                    lastNearStallTime = timeElapsed
                                    stalledNearPlayer = true
                                end
                                stallTarget = true
                            end
                        else
                            stalledNearPlayer = false
                        end
                    end
                end
            end            
            
            -- Don't stall the targets in the escape room
            for i = 1, #escapeRoomTriggers do
                local entitiesInTrigger = escapeRoomTriggers[i]:GetEntitiesTouching()
                for j = 1, #entitiesInTrigger do
                    if entitiesInTrigger[j] == avatar then
                        stallTarget = false
                    end
                end
            end
            
            -- Flee to escape button, reissue order if stalled
            local lockdown = aiDir:GetLockDown()
            if lockdown then -- Stall and spawn reinforcments
                -- Clear current dest to fight or wait in this tile
                if not IsNull(currentDest) then
                    agent:ClearOrder(Symbol("UseAction"))
                    if devModeEnabled then
                        print("Capture: Target order cleared.")
                    end
                    currentDest = nil
                    
                    -- Spawn reinforcements
                    if targetAloneInTile then
                        SpawnGuardReinforcements(3, 40, false, false, true, target)
                    else
                        SpawnGuardReinforcements(10, 60, true, true, true, target)
                    end
                end
            else -- No lockdown, flee as normal
                if usePanicButton and targetAloneInTile and stallTarget and not stalledNearPlayer then -- Use panic button if out of sight
                    if currentDest == escapeButton or IsNull(currentDest) then
                        local targetPos = target:GetPosition()
                        local panicButtons = gRegion:FindTaggedInRadius(Symbol("PanicButton"), targetPos, 0, 40)
                        local tilePanicButtons = {}
                        local validPanicButtons = {}
                        for i, action in ipairs(panicButtons) do -- Pick a panic button in the same tile as the target
                            local zone = action:GetZone()
                            if not IsNull(zone) then
                                local zoneLayerIndex = zone:GetLayerIndex()
                                if zoneLayerIndex == targetLayerIndex then
                                    table.insert(tilePanicButtons, action)
                                end
                            end
                        end
                        for i, action in ipairs(tilePanicButtons) do -- Don't backtrack to use a panic button
                            local actionDistToObj = aiDir:GetDistanceToObjective(action)
                            local targetDistToObj = aiDir:GetDistanceToObjective(avatar)
                            if actionDistToObj < targetDistToObj then
                                table.insert(validPanicButtons, action)
                            end
                        end
                        local panicButton = Closest(validPanicButtons, targetPos ,0)
                        if not IsNull(panicButton) then
                            agent:SetAlert()
                            agent:AddOrder(Symbol("UseAction"), panicButton) -- Go to escape button
                            currentDest = panicButton
                            if devModeEnabled then
                                print("Capture: Fleeing to panic button.")
                            end
                        end
                    end
                else
                    if stallTarget then
                        if not IsNull(currentDest) then
                            agent:ClearOrder(Symbol("UseAction"))
                            if devModeEnabled then
                                print("Capture: Target order cleared.")
                            end
                            currentDest = nil
                        end
                    else
                        if (currentDest ~= escapeButton or IsNull(currentDest)) and lookTrigger:IsVisible() then
                            aiDir:SetObjective(escapeButton)
                            agent:SetAlert()
                            agent:AddOrder(Symbol("UseAction"), escapeButton) -- Go to escape button
                            currentDest = escapeButton
                            agent:PlayPhrase(29) -- Play 'player spotted' bark
                            if devModeEnabled then
                                print("Capture: New escape button destination assigned.")
                            end
                            Sleep(5)
                        end
                        if target:GetHealth() > 2 and target:GetDissolve() <= 0 then 
                            agent:PlayPhrase(32) -- Play 'retreat' bark (chance to play every 50-60 seconds)
                        end
                    end
                end
            end
            t = 0
        end
        
        -- Target downed
        if target:GetHealth() <= 2 and target:GetDissolve() <= 0 and not IsNull(agent) then
            if gGameRules:GetNetPersistentVar(NV_CAPTURE_DOWNED_TIMER) < bleedoutTime then
                if avatar:HasPostureModifier(Engine.PM_GROUNDFIRE) then
                    agent:PlayPhrase(23, Symbol("GroundFire")) 
                else
                    agent:PlayPhrase(23) -- Play 'need help' bark
                end
            end
            if not downedMarkerUpdated then
                local attachedMarkers = target:GetAllAttachments(captureTargetShootMarker)
                for i, marker in ipairs(attachedMarkers) do
                    marker:Destroy()
                end
                if not gGameRules:IsA(gEndlessExterminationGameRulesType) then
                    target:Attach(captureTargetActionMarker, Symbol("GAME_C1_SPINE3"))
                    local objData = GetMissionObjText()
                    OBJTXT.SetPrimaryObjText(objData.text, 1)
                end
                gameRules:SetNetPersistentVar(NV_CAPTURE_STAGE, 1)
                downedMarkerUpdated = true
            end
        end
        
        t = t + sleepTime
        timeElapsed = timeElapsed + sleepTime
        _T.TimeSinceLastLockdown = _T.TimeSinceLastLockdown + sleepTime
        Sleep(sleepTime)
    end
    
end

function ShootAtWaypoint(instigator)
    if not IsNull(instigator) then
        local agent = instigator:GetAgent()
        if not IsNull(agent) then
            local c = math.random()
            if c <= shootPercentChance then
                agent:ShootTarget(shootWaypoint, shootDuration, shootAlign, true)
                if not IsNull(shootOutgoingPortForwarder) then
                    shootOutgoingPortForwarder:FirePort("TriggerPort")
                end
                if not IsNull(agent) then
                    agent:StopScriptedMode()
                end
            end
        end
    end
end

-- Target Behaviors Scripts -----------------------------------------------------------------------------------------------------------------------------------------

--[[function CaptureUseActionStarted()

end

function CaptureUseActionDamaged()

end]]


-- Capture escape functions ----------------------------------------------------------------------------------------------------------------------------------------

function ToggleEscapeDoor(avatar, result, instigator)

    if IsNull(avatar) then
        return
    end
    
    if not IsNull(avatar:GetAgent()) then
        result = 1
    end
    
    if result == nil then
        result = 1
    end

    if result == 1 then
    
        local players = gRegion:GetHumanPlayerAvatars()
        local isPlayer = false
        for i = 1, #players do
            if avatar == players[i] then
                isPlayer = true
            end
        end
        
        local captureDoorHints = gRegion:FindTagged(Symbol("CaptureDoorHint"))
        local airlockPanelInner = gRegion:FindAll(airlockPanelInnerType)
        local airlockPanelOuter = gRegion:FindAll(airlockPanelOuterType)
        local zone = instigator:GetZone()
        local zoneTag = zone:GetTag()
        
        captureDoorHints = ZoneCheckArray(zoneTag, captureDoorHints)
        airlockPanelInner = ZoneCheckArray(zoneTag, airlockPanelInner)    
        airlockPanelOuter = ZoneCheckArray(zoneTag, airlockPanelOuter)
        
        if isPlayer then
            for i = 1, #captureDoorHints do
                captureDoorHints[i]:FirePort("Unlock")
            end
            for i = 1, #airlockPanelInner do
                airlockPanelInner[i]:Disable()
            end
            for i = 1, #airlockPanelOuter do
                airlockPanelOuter[i]:Disable()
            end
            if not IsNull(escapeButtonLight) then
                escapeButtonLight:TurnOff()
            end
            if not IsNull(escapeButtonScreen) then
                escapeButtonScreen:SetOverrideMaterial(materialSlot, escapeButtonScreenOff)
            end
            instigator:FirePort("Disable")
        else
            for i = 1, #captureDoorHints do
                captureDoorHints[i]:FirePort("Lock")
            end
            for i = 1, #airlockPanelInner do
                airlockPanelInner[i]:SetRestricted(false)
                airlockPanelInner[i]:Enable()
            end
            for i = 1, #airlockPanelOuter do
                airlockPanelOuter[i]:Enable()
            end
            if not IsNull(escapeButtonLight) then
                escapeButtonLight:TurnOn()
            end
            if not IsNull(escapeButtonScreen) then
                escapeButtonScreen:SetOverrideMaterial(materialSlot, escapeButtonScreenOn)
            end
            
            RunScriptTriggers(Symbol("CaptureAirlockDetectScript"), false, zoneTag)
        end

    end
end

function DetectPlayersInAirlock(instigator)
    Sleep(1)
    local playerInRoom = true
    local gameRules = gGameRules
    local captureDoorHints = gRegion:FindTagged(Symbol("CaptureDoorHint"))
    local escapeRoomTriggers = gRegion:FindTagged(Symbol("EscapeRoomBounds"))
    local zone = instigator:GetZone()
    local zoneTag = zone:GetTag()
    
    captureDoorHints = ZoneCheckArray(zoneTag, captureDoorHints)
    escapeRoomTriggers = ZoneCheckArray(zoneTag, escapeRoomTriggers)    
    
    local captureDoorHint = captureDoorHints[1]

    -- Loop to stop players from trolling by entering the room with the target, allowing it to lock and then leaving
    while playerInRoom do
    
        playerInRoom = false
        
        -- Find players and capture targets in room
        local playersInTrigger = {}
        local captureTarget
        for i = 1, #escapeRoomTriggers do
            local entitiesInTrigger = escapeRoomTriggers[i]:GetEntitiesTouching()
            for j = 1, #entitiesInTrigger do
                if not IsNull(entitiesInTrigger[j]) then
                    if entitiesInTrigger[j]:IsA(gTennoAvatarType) then
                        table.insert(playersInTrigger, entitiesInTrigger[j])
                        playerInRoom = true
                    end
                    if entitiesInTrigger[j]:IsA(baseCaptureAvatarType) then
                        captureTarget = entitiesInTrigger[j]
                    end
                end
            end
        end
        
        -- Check if target escaped
        if not playerInRoom then            
            if not IsNull(captureTarget) then
                local doorsLocked = true
                for i = 1, #captureDoorHints do
                    if captureDoorHints[i]:GetDoorStatus() ~= Npc.NpcDoorHint_DS_LOCKED then
                        doorsLocked = false
                        break
                    end
                end
                if doorsLocked then
                    -- Increment escaped count
                    local escaped = gameRules:GetNetPersistentVar(NV_AGENTS_ESCAPED)
                    escaped = escaped + 1
                    gameRules:SetNetPersistentVar(NV_AGENTS_ESCAPED, escaped)
                    
                    -- Remove capture target
                    if not IsNull(captureTarget) then
                        captureTarget:Destroy()
                    end
                    
                    -- Clients need to wait until the targets are spawned
                    local totalTargets = gameRules:GetNetPersistentVar(NV_TOTAL_TARGETS)
                    if not captureTargetsSpawned and totalTargets > 0 then
                        captureTargetsSpawned = true
                    end

                    -- Update hud text once we have spawned the capture targets
                    if captureTargetsSpawned then
                        local targetsCaptured = gameRules:GetNetPersistentVar(NV_AGENTS_CAPTURED)
                        local targetsRemaining = totalTargets - escaped - targetsCaptured
                        UpdateHud()

                        -- Check if objective failed or completed ("event" missions require ALL targets to be captured!)
                        if escaped == totalTargets or gameRules:GetMission().goalId ~= "" then
                            gameRules:HideGameSession(true)
                            ShipEscapeSequence(true, zoneTag)
                        elseif targetsCaptured + escaped == totalTargets then
                            gameRules:HideGameSession(true)
                            ShipEscapeSequence(false, zoneTag)
                            DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("TargetEscapedMulti"), 0)
                            Sleep(2)
                            _CompleteCapture()
                        else
                            ShipEscapeSequence(false, zoneTag)
                            DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("TargetEscapedMulti"), 0)
                        end
                    end
                    
                    return
                end
            else
                return
            end
        elseif not IsNull(captureTarget) then
            -- Secondary destination or aggro
            local secondDest
            local agent = captureTarget:GetAgent()
            local doorState = captureDoorHint:GetDoorStatus()
            if doorState == Npc.NpcDoorHint_DS_LOCKED then
                if not IsNull(agent) then
                    agent:ClearOrder(Symbol("UseAction")) -- Needs fleePt
                end
            else               
                local panicButtons = gRegion:FindTagged(Symbol("PanicButton"))
                if not IsNull(panicButtons) then
                    secondDest = ClosestToObjectiveOverNav(panicButtons, 100)
                end
            end
            if not IsNull(agent) and not IsNull(secondDest) then
                agent:AddOrder(Symbol("UseAction"), secondDest)
            end     
        end
        Sleep(0)
    end
    
end

function TargetPreDeath()
    SQUADLINK.StopAcceptingLinks()
end

function TargetDied() -- Should never happen, but this function acts as a fallback to make the mission fail or completable if a target dies

    local gameRules = gGameRules
    if not gRegion:IsMaster() or gameRules:GetNetPersistentVar(NV_CAPTURE_STAGE) == 3 then
        return
    end

    print("Capture: Error - target died!")

    -- Increment escaped count
    local escaped = gameRules:GetNetPersistentVar(NV_AGENTS_ESCAPED)
    escaped = escaped + 1
    gameRules:SetNetPersistentVar(NV_AGENTS_ESCAPED, escaped)
       
    -- Update hud text
    UpdateHud()

    -- Check if objective failed or completed
    local totalTargets = gameRules:GetNetPersistentVar(NV_TOTAL_TARGETS)
    local targetsCaptured = gameRules:GetNetPersistentVar(NV_AGENTS_CAPTURED)
    if escaped == totalTargets then -- Both targets escaped or died
        gameRules:HideGameSession(true)
        SQUADLINK.CompleteLink("MobileDefenseCapture", SQUADLINK.FAILURE)
        gameRules:EndGame(Engine.GameRules_GS_FAILURE)
    elseif targetsCaptured + escaped == totalTargets then -- No targets left, at least one captured
        gameRules:HideGameSession(true)
        _CompleteCapture()
    end
end

-- Host migration ------------------------------------------------

function InitializeCaptureAfterMigration()

    print("Capture: Host migration occurred")

    local missionType = gGameRules:GetMissionType()
    if missionType ~= Lotus_Game.MT_CAPTURE then
        print("Capture: Cancelled, mission type isn't capture")
        return
    end

    if not gPromotedToHost then
        return
    end
    
    print("Capture: New host initializing after host migration")
    
    local gameRules = gGameRules
    local totalTargets = gameRules:GetNetPersistentVar(NV_TOTAL_TARGETS)
    local capturedTargets = gameRules:GetNetPersistentVar(NV_AGENTS_CAPTURED)
    local escapedTargets = gameRules:GetNetPersistentVar(NV_AGENTS_ESCAPED)    
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()
    if not IsNull(aiDir) then
        aiDir:Enable(true)
    end
    
    -- Set hud text
    UpdateHud()
    local missionStage = gameRules:GetNetPersistentVar(NV_CAPTURE_STAGE, 0) -- 0 = Target alive, 1 = Target downed, 2 = Target captured
    if missionStage < 2 then
        local icon = OBJTXT.ATTACK_ICON
        if missionStage == 1 then
            icon = OBJTXT.GENERIC_ICON
        end
        local objData = GetMissionObjText()
        OBJTXT.SetPrimaryObjText(objData.text, icon)
    end
    
    -- Set up VO
    DIALOG.SetupMissionTransmissionSet(transmissionSet)
    local multipleTargets = IsMultiTargetMission()
    if multipleTargets then
        _T.ObjectiveRestateTag = Symbol("ObjectiveRestateMulti")
    end
    
    -- Fail mission if all targets escaped
    if totalTargets > 0 and escapedTargets == totalTargets then
        print("Capture: Host Migration: All targets escaped, mission failed.")
        if multipleTargets then
            DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("MissionFailedMulti"), 0)
        else
            DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("MissionFailed"), 0)
        end        
        SQUADLINK.CompleteLink("MobileDefenseCapture", SQUADLINK.FAILURE)
        gGameRules:EndGame(Engine.GameRules_GS_FAILURE)
        return
    end

    -- Find mission state
    if totalTargets > 0 then
        if capturedTargets == totalTargets then --or (capturedTargets > 0 and capturedTargets + escapedTargets == totalTargets) then
            print("Capture: Host Migration: All " .. totalTargets .. " targets captured, mission complete.")
            _CompleteCapture()
        elseif capturedTargets + escapedTargets == totalTargets then
            print("Capture: Host Migration: " .. capturedTargets .. " out of " .. totalTargets .. " captured, mission complete.")
            _CompleteCapture()
        else
            local activeTargets = totalTargets - capturedTargets - escapedTargets
            print("Capture: Host Migration: " .. activeTargets .. " targets still active after host migration.")
            RunScriptTriggers(Symbol("CaptureAirlockDetectScript"), false)
        end
    end
    
    -- Safe to call multiple times (starts timer, unlocks door hints when timer expires)
    local doorUnlocks = gRegion:FindTagged(Symbol("doortimer"))
    if not IsNull(doorUnlocks) and #doorUnlocks > 0 then
        doorUnlocks[1]:FirePort("Start")
    end
    
    -- Set up objective markers
    Sleep(3)
    local objectiveRoomMarker = GetTargetMarker(Symbol("Objective"))
    local bossRoomMarker = GetTargetMarker(Symbol("Boss"))
    aiDir:SetObjective(objectiveRoomMarker)
    objectiveRoomMarker:FirePort("Disable")
    
    if not IsNull(bossRoomMarker) then
        aiDir:SetObjective(bossRoomMarker)
        bossRoomMarker:FirePort("Disable")
    end    
    
    ApplyTargetScaling()
end

function CaptureTargetMonitor(trigger)
    local downedTime = gGameRules:GetNetPersistentVar(NV_CAPTURE_DOWNED_TIMER)
    local timerActive = false
    local sleepTime = 0.5
    
    local target = trigger:GetAttachParent()
    if IsNull(target) or not target:IsA(gLotusNpcAvatarType) then
        return
    end
      
    while not IsNull(target) do
        if target:GetHealth() <= 2 then
            downedTime = downedTime + sleepTime
            --OBJTXT.SetDebugText(tostring(math.floor(downedTime)))
            gGameRules:SetNetPersistentVar(NV_CAPTURE_DOWNED_TIMER, math.floor(downedTime))
        end
    
        if downedTime >= bufferTime then
            if not timerActive then -- Start bleedout timer
                local timeLeft = bleedoutTime - (downedTime - bufferTime)
                OBJTXT.SetObjTimer(timeLeft, false, false, false, OBJTXT.TIMELIMIT_STRING)
                timerActive = true
                DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("TargetBleedoutWarning"), 0)
            elseif OBJTXT.GetObjTime() <= 0 then -- Target died in bleedout state
                gGameRules:SetNetPersistentVar(NV_CAPTURE_STAGE, 3)
                
                DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("MissionFailedTargetDied"), 0)
                Sleep(1)
                SQUADLINK.CompleteLink("MobileDefenseCapture", SQUADLINK.FAILURE)
                gGameRules:EndGame(Engine.GameRules_GS_FAILURE)
                break
            end
        end
        Sleep(sleepTime)
    end
    
end
