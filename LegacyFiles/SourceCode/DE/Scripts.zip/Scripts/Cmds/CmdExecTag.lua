local portForwarderType = WeakResource("/EE/Types/Effects/PortForwarder")

function ExecTag(arg)
    if type(arg) ~= "string" then
        return
    end
    
    arg = Symbol(arg)
    
    if not arg:IsValid() or arg == EMPTY_SYMBOL then
        return
    end
    
    local tagged = gRegion:FindTagged(arg)
    for i=1,#tagged do
        local e = tagged[i]
        if not IsNull(e) then
            if e:IsA(gScriptTriggerType) then
                e:FirePort("Execute")
            elseif e:IsA(portForwarderType) then
                e:FirePort("TriggerPort")
            elseif e:IsA(gCinematicType) then
                e:FirePort("StartPlaying")
            end
        end
    end
end