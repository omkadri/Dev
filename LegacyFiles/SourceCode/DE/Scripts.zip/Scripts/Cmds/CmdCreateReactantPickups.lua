function CreateReactantPickups()
    -- spawn 10 reactants for each player for a void fissure mission
    local humanPlayers = gRegion:GetHumanPlayers()
    for i = 1, #humanPlayers do
        for j = 1, 10
        do
            gRegion:CreateEntity(Type("/Lotus/Types/PickUps/VoidTearSealerPickup"), humanPlayers[i]:GetAvatar():GetPosition(), Rotation())
        end
    end
end
