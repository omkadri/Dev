function ShowTaggedEntities(arg)
    local argType = type(arg)
    
    arg = ((argType ~= "string" and argType ~= "number" and argType ~= "bool") or tostring(arg) == "") and Symbol() or Symbol(tostring(arg))
    if arg == _T.CmdShowTaggedEntities then
        _T.CmdShowTaggedEntities = nil
    else
        _T.CmdShowTaggedEntities = nil
        Sleep(0)
        _T.CmdShowTaggedEntities = arg
        if arg == EMPTY_SYMBOL then
            Broadcast "Showing all entities with tags, FYI this kills performance"
        else
            Broadcast("Showing entities with tag \"" .. tostring(arg) .. "\"")
        end
    end

    local tagged
    while _T.CmdShowTaggedEntities ~= nil do
        if _T.CmdShowTaggedEntities == EMPTY_SYMBOL then
            tagged = gRegion:FindAll(gEntityType)
        else
            tagged = gRegion:FindTagged(_T.CmdShowTaggedEntities)
        end
        
        for i=1,#tagged do
            local e = tagged[i]
            if not IsNull(e) and e:GetTag():IsValid() then
                local pos = tagged[i]:GetPosition()
                gRegion:VisAddText(pos, Color(255, 255, 255, 255), e:GetTag():c_str(), 1, 0.2)
                gRegion:VisAddSphere(pos, 0.0125, Color(255, 255, 255, 255), 0.2)
            end
        end
        Sleep(0.2)
    end
end
