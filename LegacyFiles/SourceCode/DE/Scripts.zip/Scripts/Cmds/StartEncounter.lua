function Execute(hint, isMission)
    if isMission then
        _T.StartEncounterHint = hint
    end
end