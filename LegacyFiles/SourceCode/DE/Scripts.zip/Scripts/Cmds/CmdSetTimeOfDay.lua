function SetTimeOfDay(time, rate)
    if type(time) ~= "number" then
        return
    end

    local skies = gRegion:FindAll(gDynamicSkyType)
    for i=1,#skies do
        skies[i]:SetTimeOfDay(time % 24)
    end
end
