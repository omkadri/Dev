success = true

function EndEncounter(withBonus)
    local hints = gRegion:FindAll(gEncounterHintType)
    for i, hint in ipairs(hints) do
        if hint:IsPrimed() and hint:IsActive() then
            local children = hint:GetChildEncounters()
            for k, child in ipairs(children) do
                local template = child:GetCurrentEncounterTemplate()
                if template:IsMissionEncounter() then
                    if success then
                        if withBonus then
                            _T.QualifiedForBountyBonus = true
                        end
                        child:SetEncounterStatus(Npc.ES_SUCCEEDED)
                    else
                        child:SetEncounterStatus(Npc.ES_FAILED)
                    end
                end
            end
        else
            local enc = hint:GetCurrentEncounterTemplate()
            if not IsNull(enc) and enc:IsGlobal() and hint:IsActive() then
                if success then
                    if withBonus then
                        _T.QualifiedForBountyBonus = true
                    end
                    hint:SetEncounterStatus(Npc.ES_SUCCEEDED)
                else
                    hint:SetEncounterStatus(Npc.ES_FAILED)
                end
            end
        end
    end
end