local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

function MasteryTest(rank)
    if rank > 0 then
        LOTUS_UTIL.OpenTrainingMission(rank, true)
    else
        Broadcast("Rank must be positive")
    end
end