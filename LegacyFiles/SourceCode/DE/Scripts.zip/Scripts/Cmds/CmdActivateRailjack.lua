local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

function OnCephCyUnlocked(success, body)
    Broadcast("Cephalon Cy installed!")
end

function OnRailjackUnlocked(success, body)
    Broadcast("Railjack Key installed!")
end

local function _ActivateRailjack()   
    if not gGameData:HasShipFeature(LOTUS_UTIL.SF_RAILJACK_CEPHALON) then
        gFlashMgr:ExecuteToolMenuCommand(Resource("/Lotus/Commands/CmdForcePurchaseItem"), "RailjackCephalonShipFeatureItem")
        Sleep(3)
        gGameData:UnlockShipFeature(LOTUS_UTIL.SF_RAILJACK_CEPHALON, WeakResource(""), 0, "OnCephCyUnlocked")
    else
        Broadcast("Cephalon Cy already installed!")
    end
    
    while not gGameData:HasShipFeature(LOTUS_UTIL.SF_RAILJACK_CEPHALON) do
        Sleep(0)
    end
    
    if not gGameData:HasShipFeature(LOTUS_UTIL.SF_RAILJACK_KEY) then
        gFlashMgr:ExecuteToolMenuCommand(Resource("/Lotus/Commands/CmdForcePurchaseItem"), "RailjackKeyShipFeatureItem")
        Sleep(3)
        gGameData:UnlockShipFeature(LOTUS_UTIL.SF_RAILJACK_KEY, WeakResource(""), 0, "OnRailjackUnlocked")
    else
        Broadcast("Railjack Key already installed!")
    end
    
    while not gGameData:HasShipFeature(LOTUS_UTIL.SF_RAILJACK_KEY) do
        Sleep(0)
    end
    
    Broadcast("Your Railjack is ready to launch!")
end

function ActivateRailjack()
    _ActivateRailjack()  
end



function GiveAndActivateRailjack()
    gFlashMgr:ExecuteToolMenuCommand(Resource("/Lotus/Commands/CmdForcePurchaseItem"), "Railjack")
    Sleep(3)
    _ActivateRailjack() 
end
