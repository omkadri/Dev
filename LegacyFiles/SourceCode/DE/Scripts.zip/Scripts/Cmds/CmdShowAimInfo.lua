function CmdShowAimInfo()
    if _T.CmdShowAimInfo then
        _T.CmdShowAimInfo = nil
        return
    end

    local rootColor = Color(255,0,0,255)
    local cursorColor = Color(255,255,255,255)
    local textColor = cursorColor

    _T.CmdShowAimInfo = true
    while _T.CmdShowAimInfo do
        local playerAvatar = gRegion:GetLocalPlayerAvatar()
        if not IsNull(playerAvatar) then
            local inv = playerAvatar:InventoryControl()
            if not IsNull(inv) then
                local aimPos = inv:GetAimEndPoint()
                local aimEntity = inv:GetAimEndPointEntity()
                local aimEntityPos = aimPos
                local str = "nil"
                if not IsNull(aimEntity) then
                    aimEntityPos = aimEntity:GetSimPosition()
                    str = aimEntity:GetFullName() .. "\n" .. tostring(aimEntityPos) .. ", " .. tostring(aimEntity:GetSimRotation()) .. "\n" .. aimEntity:GetTag():c_str()
                end
                gRegion:VisAddSphere(aimPos, 0.025, cursorColor, 0.0)
                gRegion:VisAddSphere(aimEntityPos, 0.025, rootColor, 0.0)
                gRegion:VisAddLine(aimPos, aimEntityPos, cursorColor, 0)
                gRegion:VisAddText(aimPos, textColor, str, 1.0, 0.0)
            end
        end

        Sleep(0)
    end
end