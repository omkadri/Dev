success = true

local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"

function EndEncounter(tag)
    local hints = gRegion:FindAll(gEncounterHintType)
    for i, hint in ipairs(hints) do
        local template = hint:GetCurrentEncounterTemplate()
        if not IsNull(template) then
            if tag ~= nil and type(tag) == 'string' then
                if template:HasEncounterTag(Symbol(tag)) then
                    hint:SetEncounterStatus(Npc.ES_SUCCEEDED)
                    Broadcast("Completing " .. template:GetFullName())
                end
            elseif template:HasEncounterTag(Symbol("ExterminateSubObjective")) then
                hint:SetEncounterDynamicState(RAIL.SUB_OBJECTIVE_COMPLETE)
                Broadcast("Completing " .. template:GetFullName())
            elseif template:HasEncounterTag(Symbol("POI")) or template:HasEncounterTag(Symbol("CrewShipPatrol")) or template:HasEncounterTag(Symbol("RadarTower")) or template:HasEncounterTag(Symbol("AsteroidHangar")) or template:HasEncounterTag(Symbol("SuperWeapon")) then
                hint:SetEncounterStatus(Npc.ES_SUCCEEDED)
                Broadcast("Completing " .. template:GetFullName())
            end
        end
    end
end