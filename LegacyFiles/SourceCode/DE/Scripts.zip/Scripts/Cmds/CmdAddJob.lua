function CmdAddJob(arg, minEnemyLevel, maxEnemyLevel)
    local jobType = Resource(arg)
    if IsNull(jobType) then
        Broadcast "Job type not found"
        return
    end

    local jobs = _T.DEBUG_JOBS or {}
    _T.DEBUG_JOBS = jobs
    
    for i=1,#jobs do
        if jobs[i].jobType == jobType then
            return
        end
    end

    local stages = {}
    local xpAmounts = {}
    local jobStages = jobType:GetStages()
    for i=1,#jobStages do
        stages[i] = jobStages[i].encounterChoices[RandomInt(1,#jobStages[i].encounterChoices)]
        xpAmounts[i] = 0
    end
    
    table.insert(jobs,
        {
            jobId = jobType:GetFullName(),
            name = Localize(tostring(jobType:GetLocTag()), nil),
            desc = Localize(tostring(jobType:GetDescTag()), nil),
            icon = jobType:GetIconTexture(),
            stages = stages,
            reward = nil,
            seed = UnsignedToRandSeed(RandomInt(0,math.pow(2,30))),
            jobType = jobType,
            jobTypeName = jobType:GetFullName(),
            masteryReq = 0,
            minEnemyLevel = tonumber(minEnemyLevel) or 15,
            maxEnemyLevel = tonumber(maxEnemyLevel) or 20,
            xpAmounts = xpAmounts,
            syndicateTag = EMPTY_SYMBOL,
            transmissionSet = jobType:GetTransmissionSet(),
            skipInventoryUpdate = true,
            expiry = nil,
            hasCompleted = false
        }
    )

    _T.RefreshJobs = true
end