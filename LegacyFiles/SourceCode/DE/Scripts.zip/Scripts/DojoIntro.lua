dojoFX= Type()
kneelAnim = Resource()
standAnim = Resource()
startingTransmission = Type()
standAnimDelay = 1
destroySentinel = false

local postFade = require "Lotus.Scripts.PostProcess.BasePostProcessFade"

function Start()

    local avatar = gRegion:GetPlayerAvatar(0)

    while IsNull(avatar) do
        Sleep(0)
        avatar = gRegion:GetPlayerAvatar(0)
    end

    if _G.IsTrainingMissionPractise then
        avatar:InventoryControl():ToggleTrackKills(false)
    end

    if destroySentinel then
        local sentinel = avatar:InventoryControl():GetSentinel()
        if not IsNull(sentinel) then
            sentinel:Destroy()
        end
    end

    local gameCameraEntity = gRegion:GetGameCamera()
    gameCameraEntity:Attach(dojoFX, EMPTY_SYMBOL, Vector(0,-0.5,0))
    
    postFade.Fade(-1,-1,0)
    avatar:PlayNonReplicatedAnimation(kneelAnim, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_FREEZE, true)
    
    Sleep(1.5)
    postFade.Fade(-1,0,2)
    avatar:GiveItem(startingTransmission, true)

    Sleep(standAnimDelay)
    if not IsNull(standAnim) then
        avatar:PlayNonReplicatedAnimation(standAnim, true, Engine.ATMM_PHYSICS_DRIVEN,Engine.PRT_ONCE, true)
    end

end