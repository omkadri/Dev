
local speed = 0.02
local radiusX = 30.0
local radiusZ = 70.0

function FlarePulse(lensFlare)
    local t = math.random()
    while not IsNull(lensFlare) do
    
        t = t + DeltaTime() * 0.7
        if t > 1.0 then
            t = t - 1.0
        end
        
        local s = math.abs(math.sin(t * math.pi * 2.0) * math.sin((t + 0.66) * math.pi * 2.0))
        lensFlare:SetSize(s * 0.6)
        
        Sleep(0)
    end
end

function PodFlight(deco)
    Sleep(0)
    local startPos = deco:GetPosition()
    local lastPos = startPos
    local t = 0.0
    
    local radiusXX = radiusX
    if math.random() > 0.5 then
        radiusXX = -radiusXX
    end
    
    local radiusZZ = radiusZ
    if math.random() > 0.5 then
        radiusZZ = -radiusZZ
    end

    local flares = deco:GetAllAttachments(gLensFlareType)
    
    for i=1,#flares do
        flares[i]:ScriptRunChildScript(Symbol("FlarePulse"), false)
    end
    
    local newPos = Vector()
    local arcPos = Vector()

    while not IsNull(deco) do
        local dt = DeltaTime()
        
        t = t + dt * speed
        if t > 1.0 then
            t = t - 1.0
        end
        local x = math.cos(t * math.pi * -2)
        local z = math.sin(t * math.pi * 2)
        
        local noiseY = Noise2D(3, 0.5, Time() * 0.03, 0.5) * -10
        arcPos.x = x * radiusXX
        arcPos.y = noiseY
        arcPos.z = z * radiusZZ

        VectorAdd(newPos, startPos, arcPos)
        local rotation = LookTo(lastPos, newPos)
        
        rotation.heading = rotation.heading + Noise2D(3, 0.5, 0.5, 0.5) * 15 * dt
        rotation.bank = rotation.bank + Noise2D(3, 0.5, 0.5, 0.5) * 15 * dt
        
        lastPos = newPos
        deco:SetRotation(rotation)
        
        --[[
        
        position = deco:GetPosition()
        
        local rotation = deco:GetRotation()
        rotation.heading = rotation.heading + Noise2D(3, 0.5, 0.5, 0.5) * 15 * dt
        deco:SetRotation(rotation)
        
        local dir = AngleToDirection(rotation)
        position = position + dir * speed * dt
        --]]
        deco:SetPosition(newPos)
        
        Sleep(0)
    
    
    
    end


end