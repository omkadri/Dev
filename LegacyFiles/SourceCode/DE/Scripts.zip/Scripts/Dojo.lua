enemy = Type()
meleeEnemy = Type()
marineEnemy = Type()
warframe = Type()
firstPowerUpgradeType = Type()
weaponOne = Type()
weaponTwo = Type()
meleeWeapon = Type()
waypoints = {Instance()}
spawnPoints = {Instance()}
energySpawn = Instance()
energyType = Type()
healthSpawn = Instance()
healthType = Type()
objectivemarker = Instance()
endMissionMovie = WeakResource()
eomDialog = Instance()
transmissionMovie = Resource()
music = Resource()
introTextMovie = Resource()

fightingMusic = Resource()
transitionSound = Resource()
dojoFX= Type()
StandAnim = Resource()

teleporttrigger = Instance()
portalmeshes = {Instance()}

trans = {WeakResource()}
abilityNoTouchpadTrans = WeakResource("/Lotus/Sounds/Lotus/TutorialNew/Trans/TransX_NoTouchpad")
duration = 30.0
message = Symbol()
expiryEndMission = false

hudEmphasisFX = Type()
enemyProjectorFX = Type()


endcin = Instance()

modType = Type()

preBridgeTrigger = Instance()
postBridgeTrigger = Instance()
pitFallTrigger = Instance()

wallrunGuide = Instance()
wallrunGuideAnim = Resource()

disableTrig = Instance()
enableTrig = Instance()

local fightingMusicInstance = nil
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local rankPromotedStr = "/Lotus/Language/ActivityFeed/ActivityFeedRankPromoted"
local rank1Loc = Localize("/Lotus/Language/Ranks/Rank1", args)

local function EnableTimer()
    gGameRules:SetMissionTimer(Symbol(), message, duration, expiryEndMission, true)
end

local function DisableTimer()
    gGameRules:SetMissionTimer(Symbol(), Symbol(), -1.0, false)
end

local function TriggerReturnToLobby()

    local endMissionInstance = gFlashMgr:FindMovie(endMissionMovie)
    if not IsNull(endMissionInstance) then
        endMissionInstance:Execute("AutoClose", "")
    end
    
end

local function TriggerEndOfTutorial()
    local HUDInstance = gGameRules:GetHudMovieInstance()
    if not IsNull(HUDInstance) then
        HUDInstance:SetVisible(false)
    end
    --gFlashMgr:PushMovie(tutorialRewardMovie)
    _T.tutorialActive = false
end

local function GetAIInRadius(center, radius)
    local avatars = gRegion:GetAvatars()
    local count = 0
    
    for i=1, #avatars do
    
        local avatar = avatars[i]
        if not avatar:IsKilled() then
            if not IsNull(avatar:GetAgent()) then
                local d = avatar:DistanceToPoint(center)
                if d < radius then
                    count = count + 1
                end
            
            end
        end
    end
    
    return count
    
end

local function AddHudEmphasis(movie, clipName, offX, offY)
    if offX == nil then
        offX = 0
    end
    if offY == nil then
        offY = 0
    end
    if not IsNull(hudEmphasisFX) then
        local mx, my = LOTUS_UTIL.GetRootBasedPosition(movie, clipName)
        if mx ~= nil and my ~= nil then
            movie:Execute("ScreenDuck", "")
            return LOTUS_UTIL.CreateScreenParticles(movie, hudEmphasisFX, mx + offX, my + offY)
        end
    end
end

local function QuickBurn()
    local levelInfo = gRegion:GetLevelInfo()
    local postProcess = levelInfo.postProcess
    
    UTIL.PlaySound(transitionSound)
    local t = 1.0
    while t > 0.0 do
        postProcess.fade = -t
        t = t - DeltaTime()
        Sleep(0)
    end
    postProcess.fade = 0
end

function FlyIn()
    UTIL.PlaySound(music)
    gFlashMgr:PushMovie(introTextMovie)
end

function ToWhite()
    local levelInfo = gRegion:GetLevelInfo()
    local postProcess = levelInfo.postProcess
    local t = 0.0
    while t > -1.0 do
        t = t - DeltaTime() * 1
        postProcess.fade = t
        Sleep(0)
    end
    postProcess.fade = -1
end

function ToWhiteAndBack()
    local levelInfo = gRegion:GetLevelInfo()
    local postProcess = levelInfo.postProcess
    local t = 0.0
    while t > -1.0 do
        t = t - DeltaTime() * 2.25
        postProcess.fade = t
        Sleep(0)
    end
    postProcess.fade = -1
    Sleep(1)
    while t < 0.0 do
        t = t + DeltaTime() * 1
        postProcess.fade = t
        Sleep(0)
    end
    postProcess.fade = 0.0
end


local function SetupEnemyVisuals(entity)
    if IsNull(entity) then
        return
    end
    entity:Attach(enemyProjectorFX, EMPTY_SYMBOL)
    local attachments = entity:GetAllAttachments(gEntityType)
    for i=1,#attachments do
        attachments[i]:Attach(enemyProjectorFX, EMPTY_SYMBOL)
    end
end

local function IsTransmissionPlaying()
    if gFlashMgr:HasMovie(transmissionMovie) then
        return true
    end
    return false
end

local function SleepOnTransmission()
    while IsTransmissionPlaying() do
        Sleep(0)
    end
end

function Tutorial()
    if _T.tutorialActive then
        return
    end
    _T.tutorialActive = true
    
    local levelInfo = gRegion:GetLevelInfo()
    local postProcess = levelInfo.postProcess
    --gameCameraEntity:Attach(dojoFX, EMPTY_SYMBOL, Vector(0,-0.5,0))
    
    gGameRules:SetConsumablesDisabled(true)
    gGameRules:SetQuitToMainMenuDisabled(true)
    gGameRules:SetCommitInventoryDisabled(true)
    gGameRules:SetSaveMatchStatsDisabled(true)
    
    local npcManager = gRegion:GetNpcMgr()
    local players = gRegion:GetHumanPlayers()
    local avatar = players[1]:GetAvatar()
    local invControl = avatar:InventoryControl()
    local damageControl = avatar:DamageControl()
    invControl:RemoveAllItems()

    -- Disable shield (will be re-enabled later on)
    invControl:AddUpgrade(Game.AVATAR_SHIELD_MAX, Game.SET, 0)
    damageControl:SetShield(0)

    --Give the player his default warframe 
    local activeWarframe = avatar:GiveItem(warframe, true)
    activeWarframe:SetXP(0)
    local HUDInstance = gGameRules:GetHudMovieInstance()
    
     --Hide Hud elements so we can turn them on slowly as needed.
    HUDInstance:SetVariable("SuitFrame", "_visible", false)    
    HUDInstance:SetVariable("WeaponFrame", "_visible", false)
    _T.DisableMiniMap = true
    HUDInstance:SetVariable("Reticle", "_visible", false)
    
    postProcess.bloom = .1

    local t = 1.0
    while t > 0.0 do
        postProcess.fade = -t
        t = t - DeltaTime() * 0.25
        Sleep(0)
    end
    postProcess.fade = 0.0

    
    --Take away some ammo, this will be important later...
    --[[local ammoAmount = invControl:GetAmmoExCount(rifleAmmoType)
    invControl:TakeAmmoEx(rifleAmmoType, ammoAmount / 2)]]--

    while not IsNull(gRegion:GetPlayingCinematic()) do
        Sleep(0)
    end
    Sleep(1)
    avatar:GiveTransmissionAsync(trans[1])
    QuickBurn()
    SleepOnTransmission()
    
    avatar:GiveTransmissionAsync(trans[2])
    Sleep(4)

    invControl:GetActivePowerSuit():SetEnergy(0)
    avatar:SetHealth(avatar:GetHealth() - 25)
    HUDInstance:SetVariable("SuitFrame", "_visible", true)
    AddHudEmphasis(HUDInstance, "SuitFrame.EnergyPanel.Health", 25, 20)

    Sleep(5) --Sleeps will be replaced with dialog from the lotus
    avatar:GiveTransmissionAsync(trans[3])
    Sleep(5)
    
    if Engine.IsBigPic() then
        avatar:GiveTransmissionAsync(trans[30])
    else
        avatar:GiveTransmissionAsync(trans[4])
    end
    Sleep(2)
    local health = gRegion:CreateEntity(healthType,healthSpawn:GetPosition(),energySpawn:GetRotation())
    while not IsNull(health) do
        Sleep(0)
    end
    Sleep(1)
    avatar:GiveTransmissionAsync(trans[5])
    --Give the player his Shield
    invControl:RemoveUpgrade(Game.AVATAR_SHIELD_MAX, Game.SET, 0)
    damageControl:SetShield(damageControl:GetMaxShield())

    AddHudEmphasis(HUDInstance, "SuitFrame.EnergyPanel.Shield", 25, 20)
    Sleep(7)
    gRegion:RadialDamage(waypoints[1], avatar:GetSimPosition(), 100, 5, 100, Engine.DT_EXPLOSION)
    avatar:GiveTransmissionAsync(trans[6])
    AddHudEmphasis(HUDInstance, "SuitFrame.EnergyPanel.Shield", 25, 20)
    Sleep(5)
    avatar:GiveTransmissionAsync(trans[7])
    Sleep(8)

    --give the player his melee weapon
    local activeMeleeWeapon = avatar:GiveItem(meleeWeapon, true)
    activeMeleeWeapon:SetXP(0)
    QuickBurn()

      -- Make sure we don't die in tutorial
    damageControl:SetImmortal(true)

    Sleep(1)
    
    -- TEST TO KILL A DUDE
    avatar:GiveTransmissionAsync(trans[8])
    local target = gRegion:CreateEntity(enemy,waypoints[3]:GetPosition(),waypoints[1]:GetRotation())
    SetupEnemyVisuals(target)
    target:FaceTo(avatar:GetSimPosition())
    HUDInstance:SetVariable("Reticle", "_visible", true)
    while target:GetHealth() > 0 do
        Sleep(0)
    end

    -- RIFLE
    avatar:GiveTransmissionAsync(trans[9])
    Sleep(4)
    local activeWeaponTwo = avatar:GiveItem(weaponTwo, false)
    activeWeaponTwo:SetXP(0)
    invControl:Equip(Engine.SLOT_6, Engine.EXTRA2, Engine.InventoryControllerBase_ES_INSTANT_EQUIP)
    invControl:Equip(Engine.SLOT_2, Engine.MAIN_HAND, Engine.InventoryControllerBase_ES_INSTANT_EQUIP)
    QuickBurn()
    Sleep(2)

    -- SHOOT SOME BAD GUYS
    avatar:GiveTransmissionAsync(trans[10])
    Sleep(2)
    local target2 = gRegion:CreateEntity(enemy,waypoints[2]:GetPosition(),waypoints[2]:GetRotation())
    local target3 = gRegion:CreateEntity(enemy,waypoints[1]:GetPosition(),waypoints[3]:GetRotation())
    target2:FaceTo(avatar:GetSimPosition())
    target3:FaceTo(avatar:GetSimPosition())
    
    SetupEnemyVisuals(target2)
    SetupEnemyVisuals(target3)
    
    while (not IsNull(target2) and target2:GetHealth() > 0) or (not IsNull(target3) and target3:GetHealth() > 0) do
        Sleep(0)
    end
    Sleep(1)
 
    -- SHOW WEAPON HUD INFO
    --avatar:GiveTransmissionAsync(trans[11])
    HUDInstance:SetVariable("WeaponFrame", "_visible", true)
    --[[AddHudEmphasis(HUDInstance, "WeaponFrame.LabelA", 50, 20)
    AddHudEmphasis(HUDInstance, "WeaponFrame.LabelB", 25, 20)
    Sleep(4)
    avatar:GiveTransmissionAsync(trans[12])
    Sleep(2)
    avatar:GiveTransmissionAsync(trans[13])
    Sleep(2)

    -- TAKE THE AMMO!
    local ammo = gRegion:CreateEntity(ammoType,ammoSpawn:GetPosition(),ammoSpawn:GetRotation())
    while not IsNull(ammo) or (activeWeaponTwo:GetAmmoInClip() ~= activeWeaponTwo:GetClipSize()) do
        Sleep(0)
    end
    Sleep(2)]]--
    
    -- AFFINTY
    local wfXP = activeWarframe:GetNextLevelRatio()
    local wepXP = invControl:GetWeaponInHand(Engine.MAIN_HAND):GetNextLevelRatio()
    AddHudEmphasis(HUDInstance, "SuitFrame.EnergyPanel.XPBar", Lerp(-245, 0, wfXP), 10)
    AddHudEmphasis(HUDInstance, "WeaponFrame.XPBar", Lerp(-211, 0, wepXP), -10)
    
    avatar:GiveTransmissionAsync(trans[14])
    Sleep(6)
    avatar:GiveTransmissionAsync(trans[15])
    Sleep(10)
    
    -- PISTOL
    avatar:GiveTransmissionAsync(trans[16])
    Sleep(4)
    local activeWeaponOne = avatar:GiveItem(weaponOne, false)
    activeWeaponOne:SetXP(0)
    QuickBurn()
    Sleep(1)
    -- check for weapon switch
    while (invControl:GetWeaponInHand(Engine.MAIN_HAND) ~= activeWeaponOne) do
        Sleep(0)
    end
    Sleep(1)
    
    -- SHOOT MORE BAD GUYS
    avatar:GiveTransmissionAsync(trans[17])
    Sleep(2)
    local target4 = gRegion:CreateEntity(enemy,waypoints[1]:GetPosition(),waypoints[1]:GetRotation())
    local target5 = gRegion:CreateEntity(enemy,waypoints[5]:GetPosition(),waypoints[5]:GetRotation())
    target4:FaceTo(avatar:GetSimPosition())
    target5:FaceTo(avatar:GetSimPosition())
    
    SetupEnemyVisuals(target4)
    SetupEnemyVisuals(target5)
    
    while (not IsNull(target4) and target4:GetHealth() > 0) or (not IsNull(target5) and target5:GetHealth() > 0) do
        Sleep(0)
    end
    Sleep(1)
    
    -- talk about comining swords and guns
    avatar:GiveTransmissionAsync(trans[18])
    QuickBurn()
    Sleep(4)
    
    --Spawn multiple targets from all directions.. combine what you have learned.
    avatar:GiveTransmissionAsync(trans[19])
    Sleep(4)
    local count = 0
    local agentAvatars = {}
    local agent = nil
    
    while count <= 3 do
        local temp = RandomInt(1,2)
        if temp == 1 then
            agent = npcManager:CreateAgent(meleeEnemy, spawnPoints[RandomInt(1, #spawnPoints)])
        else
            agent = npcManager:CreateAgent(marineEnemy, spawnPoints[RandomInt(1, #spawnPoints)])
        end
        agent:SetTeam(Symbol("RandomTeam"))
        SetupEnemyVisuals(agent:GetAvatar())
        count = count + 1
        agentAvatars[count] = agent:GetAvatar()
        Sleep(Random(2,3))
    end

    for agentCount = 1, #agentAvatars do
        while (not IsNull(agentAvatars[agentCount]) and not agentAvatars[agentCount]:IsKilled()) do
            if avatar:GetHealth() < 50 then
                avatar:SetHealth(100, false)
            end
            Sleep(0)
        end
    end

    local abilityUpgrade = gRegion:CreateObject(firstPowerUpgradeType)
    invControl:GetActivePowerSuit():AddUpgrade(abilityUpgrade)
    invControl:GetActivePowerSuit():FinalizeUpgrades(0)
    Sleep(1)

    local ability1 = {x=0, y=0}
    AddHudEmphasis(HUDInstance, "SuitFrame.EnergyPanel.Ability1", ability1.x, ability1.y)
   
    avatar:GiveTransmissionAsync(trans[20])
    Sleep(8)
    avatar:GiveTransmissionAsync(trans[21])
    Sleep(2)
    --Talk about powers and leveling
    --create energy orb and tell player about it
    invControl:GetActivePowerSuit():SetEnergy(0)
    local energy = gRegion:CreateEntity(energyType,energySpawn:GetPosition(),energySpawn:GetRotation())
    while not IsNull(energy) do
        Sleep(0)
    end
    AddHudEmphasis(HUDInstance, "SuitFrame.EnergyPanel.Ability1", ability1.x, ability1.y)

    -- Check to see if we need to show the special PS4 "no touchpad" version of the ability transmission
    if Engine.IsPlayingWithController() then
        local useNoTouchpadVersion = false

        local playerProfile = gPlayerProfileMgr:GetPlayerProfile(0)
        if not IsNull(playerProfile) then
            local settings = playerProfile:Settings()

            useNoTouchpadVersion = UTIL.Ternary(Engine.IsPS4(), false, true) -- HACKS: The second keybinding type is the "non touchpad" one
        end

        if useNoTouchpadVersion or Engine.IsBigPic() then
            avatar:GiveTransmissionAsync(abilityNoTouchpadTrans)
        else
            avatar:GiveTransmissionAsync(trans[22])
        end
    else
        avatar:GiveTransmissionAsync(trans[22])
    end

    target = gRegion:CreateEntity(enemy,waypoints[1]:GetPosition(),waypoints[1]:GetRotation())
    target:FaceTo(avatar:GetSimPosition())
    SetupEnemyVisuals(target)
    local enemyPos = target:GetPosition()
    while target:GetHealth() > 0 do
        Sleep(0)
    end
    
    -- DROP A MOD... only if you haven't done the tutorial before
    local playerProfileData = gPlayerProfileMgr:GetPlayerProfile(0):GetGameSpecificData()
    if not IsNull(playerProfileData) and not playerProfileData:HasReceivedStartingGear() then
        Sleep(0.5)    
        local modDrop = gRegion:CreateEntity(modType, enemyPos, ZERO_ROTATION)
        Sleep(1)
        avatar:GiveTransmissionAsync(trans[23])
        while not IsNull(modDrop) do
            Sleep(0)
        end
    end    
    Sleep(1)

    avatar:GiveTransmissionAsync(trans[24])
    Sleep(6)
    --[[avatar:GiveTransmissionAsync(trans[25])
    Sleep(2)]]--
    
    _T.DisableMiniMap = nil
    Sleep(1.5)
    teleporttrigger:Disable()
    for i=1,#portalmeshes do
        portalmeshes[i]:Destroy()
    end
    objectivemarker:FirePort("Enable")
    AddHudEmphasis(HUDInstance, "MiniMapContainer.MiniMap", 0, 0)
    
    -- check for player getting close to the portal
    while not IsNull(preBridgeTrigger) do
        Sleep(0)
    end
    
    -- message about wallrun
    avatar:GiveTransmissionAsync(trans[26])
    Sleep(6)
    if not IsNull(postBridgeTrigger) then
        avatar:GiveTransmissionAsync(trans[27])
        if not IsNull(wallrunGuide) and not IsNull(wallrunGuideAnim) then
            wallrunGuide:FirePort("Show")
            wallrunGuide:SetAmbientAnimation(wallrunGuideAnim)
        end
        Sleep(4)
    end
    
    -- check for player on other side of bridge
    while not IsNull(postBridgeTrigger) do
        Sleep(0)
    end
    
    if not IsNull(pitFallTrigger) and not pitFallTrigger:IsEnabled() then
        avatar:GiveTransmissionAsync(trans[28])    -- Completed wall run, play one message
    else
        avatar:GiveTransmissionAsync(trans[29])    -- Failed wall run, play a different message
    end
    if not IsNull(wallrunGuide) then
        wallrunGuide:FirePort("Hide")
    end
    
    --need to get if player is close to objective marker
    local dist = 100
    while dist > 5 do
        dist = avatar:DistanceToEntity(objectivemarker)
        Sleep(0)
    end

    objectivemarker:FirePort("Disable")
    
    if not avatar:IsKilled() then
        avatar:SetHealth(100, false)
    end

    --TestOneTrigger:FirePort("Execute")
    fightingMusicInstance = UTIL.PlaySound(fightingMusic)
    
    while not IsNull(avatar) do
        if avatar:GetHealth() < 50 and not avatar:IsKilled() then
            avatar:SetHealth(100, false)
        end
        Sleep(0)
    end
 
end

function ToggleTriggers()
    if not IsNull(disableTrig) then
        disableTrig:Disable()
    end
    
    if not IsNull(enableTrig) then
        enableTrig:Enable()
    end
end

function OnTrainingResultUploaded(result, body)
    print("Dojo: OnTrainingResultUploaded result=" .. tostring(result) .. ", body=" .. tostring(body))
end

local function TestCommon(rankUpOnCompletion)
    local players = gRegion:GetHumanPlayers()
    local avatar = players[1]:GetAvatar()
    local playerRank = gPlayerProfileMgr:GetPlayerProfile(0):GetGameSpecificData():GetCachedPlayerLevel()

    gGameRules:SetSaveMatchStatsDisabled(true)
    
    if not IsNull(endcin) then
        endcin:FirePort("StartPlaying")
    end
    Sleep(2)
    
    while not IsNull(gRegion:GetPlayingCinematic()) do
        Sleep(0)
    end  
    
     if rankUpOnCompletion and (_T.tutorialActive ~= true or playerRank == 0) then
        local numLevelsGained = 1
        if _T.tutorialActive == true then
            numLevelsGained = 0
        end
        local playerProfile = gPlayerProfileMgr:GetPlayerProfile(0)
        playerProfile:GetGameSpecificData():SubmitTrainingResult(numLevelsGained, "OnTrainingResultUploaded")
        local rArgs = {}
        rArgs["PLAYER_NAME"] = gPlayerProfileMgr:GetPlayerProfile(0):GetPlayerName()
        local rankPromotedLoc = Localize(rankPromotedStr, rArgs)
        playerProfile:PostActivityMessage(rankPromotedLoc .. " " .. rank1Loc)
    end

    if _T.tutorialActive then
        TriggerEndOfTutorial()
    else
        eomDialog:FirePort("Open")
        Sleep(3)
        TriggerReturnToLobby()
    end
end

function TestOne()
    TestCommon(true)
end

function TestTutorial()
    TestCommon(false)
end

function TestSetup()
    local players = gRegion:GetHumanPlayers()
    local avatar = players[1]:GetAvatar()
    local gameCameraEntity = gRegion:GetGameCamera()
    gameCameraEntity:Attach(dojoFX, EMPTY_SYMBOL, Vector(0,-0.5,0))
    Sleep(1)
    avatar:PlayNonReplicatedAnimation(StandAnim, true, Engine.ATMM_PHYSICS_DRIVEN,Engine.PRT_ONCE, true)
end
