bounceTriggerType = Type()
damageRatio = 0.1 -- ratio of total health to deal as damage to the player when standing in the grenade explosion
lifeTime = 1 -- lifeTime in seconds

local mBlocking = false
local mHasBounced = false

function Update(trigger)
    Sleep(0)
    local projectile = trigger:GetAttachParent()
    if IsNull(projectile) then
        return
    end

    local weapon = projectile:GetInstigatorItem()

    if not IsNull(weapon) then
        local instigatorAvatar = weapon:GetAvatarOwner()
        
        if not IsNull(instigatorAvatar) then
            trigger:SetThrowingEntity(instigatorAvatar)
        end
    end

    Sleep(0.1)
    trigger:Enable()
    while not IsNull(trigger:GetAttachParent()) do
        Sleep(0)
    end
    Sleep(lifeTime)
    trigger:Destroy()
end

function OnBounce(entity,avatar)
    if IsNull(avatar) or IsNull(entity) then
        return
    end
    local weapon = entity:GetCreator()
    if IsNull(weapon) then
        return
    end
    local instigatorAvatar = weapon:GetAvatarOwner()
    if IsNull(instigatorAvatar) then
       return
    end
    if instigatorAvatar == avatar then
        local impulseDir = avatar:GetPosition() - entity:GetPosition()
        Normalize(impulseDir)
        local totalHealth = avatar:GetMaxHealth() + avatar:DamageControl():GetMaxShield()
        local damage = totalHealth * damageRatio
        local dd = Engine.DamageData()
        dd.baseAmount = damage
        dd:SetDamagePct(Engine.DT_EXPLOSION, 1.0)
        dd:SetSource(instigatorAvatar)
        dd:SetSourceObject(weapon)
        dd:SetHitPart(Engine.TORSO)
        dd:SetImpulse(impulseDir * 0)
        avatar:DamageDD(dd)
    end
end

function OnContact(trigger)
    local entities = trigger:GetEntitiesTouching()
    local projectile = trigger:GetAttachParent()
    local instigatorAvatar = trigger:GetThrowingEntity()
    if IsNull(instigatorAvatar) or IsNull(projectile) then
        return
    end
    local weapon = projectile:GetInstigatorItem()

    if projectile:GetRiftStatus() == Engine.RS_IN_RIFT and gGameRules:IsRiftPaused(projectile:GetInstigatorFaction()) then
        return
    end
    
    if IsNull(instigatorAvatar) then
        return
    end
    for i=1, #entities do
        local avatar = entities[i]
        if not IsNull(avatar) and avatar:IsA(gBaseAvatarType) then
            if instigatorAvatar == avatar then
                if not IsNull(projectile) then
                    projectile:Die()
                end
                local pos = avatar:GetPosition()
                local rot = Rotation(0,-90,0)
                local bounceTrigger = gRegion:CreateEntity(bounceTriggerType,pos, rot, weapon)
            end
        end
    end
end

function SelfDestruct(entity)
    if entity:IsEnabled() and lifeTime > 0 then
        Sleep(lifeTime)
        if not IsNull(entity) then
            entity:Destroy()
        end
    end
end