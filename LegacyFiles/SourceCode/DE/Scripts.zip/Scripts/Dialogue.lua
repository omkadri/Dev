helloSound = Resource()
GuildBarkSound = { Resource() }
GuildType = Type()

warbirdsWarningSound = Resource()
warbirdsFiringSound = Resource()


function Hello(avatar)
    avatar:PlaySound(helloSound, false)
end

function GuildBark(avatar)
    Sleep(4.0)
    
    while true do
        local b = GuildBarkSound[RandomInt(1, #GuildBarkSound)]
        local GuildAvatar = gRegion:FindNearest(GuildType, Vector(), FLT_MAX)
        if GuildAvatar ~= nil then
            GuildAvatar:PlaySound(b, false)
        end
        
        Sleep(Random(4.0, 30.0))
    end
end

function BridgeComm()
    gRegion:PlaySound(warbirdsWarningSound, Vector(), true)
    Sleep(1)
    gRegion:PlaySound(warbirdsFiringSound, Vector(), true)
end
