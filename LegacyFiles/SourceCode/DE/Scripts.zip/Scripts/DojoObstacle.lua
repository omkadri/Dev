staminaIncrease = 100
resetPoint = Instance()
defaultResetPoint = Instance()
maxTime = 300
console = Instance()
normalPhysics = Resource()
startPoint = Instance()
trigger = Instance()
fadeOut = true
fadeIn = true
movers = {Instance()}
musicSeq = Instance()

local timeLoc = "/Lotus/Language/Menu/AlertPopup_Time"
confirmMovie = Resource()

courseStartInputFilter = Resource()

local postFade = require "Lotus.Scripts.PostProcess.BasePostProcessFade"

local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local mInstigator = nil
local mAction = nil

function SetResetPoint(instigator)
    if instigator:IsA(gLotusSentinelAvatarType) then
        return
    end
    if IsNull(_T.gObstacleResetPoint) then 
        _T.gObstacleResetPoint = {}
    end
    if IsNull(instigator) then
        instigator = mInstigator
    end
    if not IsNull(instigator) then
        local player = instigator:GetPlayer()
        if not IsNull(player) then
            local name = instigator:GetPlayer():GetPlayerName()
            _T.gObstacleResetPoint[name] = resetPoint
        end
    else
        _T.gObstacleResetPoint = {}
    end
end

local function _Reset(target, rsPoint)
    target:InputControl():StopCrouching()
    target:SetPosture(Engine.WALK)
    target:MotionControl():SetPushVelocity(ZERO_VECTOR)
    target:Teleport(rsPoint:GetPosition())
    target:MotionControl():SetTorsoFromView(rsPoint:GetRotation())
    target:SetCameraView(rsPoint:GetRotation())
    target:SetVelocity(Vector())
    target:ClearLandStyle()
    local companion = target:InventoryControl():GetCompanion()
    if not IsNull(companion) then
        companion:Teleport(rsPoint:GetPosition())
    end
end

function Reset(instigator)
    local rsPoint
    
    if instigator == trigger or IsNull(instigator) then
        return  --some weird case going on after host migration, where this gets triggered - instigator ends up being the trigger itself
    end
    
    local avatar
    local player = instigator:GetPlayer()
    if IsNull(player) then
        if instigator:IsA(gLotusOperatorAvatarType) then
            avatar = LOTUS_UTIL.GetWarframeFromOperator(instigator)
            player = gRegion:GetLocalPlayer()
            if IsNull(player) then
                return
            end
        else
            return
        end
    end
    local name = player:GetPlayerName()
    
    if IsNull(_T.gObstacleResetPoint) or IsNull(_T.gObstacleResetPoint[name]) or IsNull( _T.gCourseState) or _T.gCourseState[name] ~= "STARTED" then
        rsPoint = defaultResetPoint
    else
        rsPoint = _T.gObstacleResetPoint[name]
    end
    
    if fadeOut then
        postFade.AvatarFade(instigator, 0, 1, 0.5, 0)
    end
    
    if instigator:ReplicaLocallyControlled() and trigger:IsTouching(instigator) then
        _Reset(instigator, rsPoint)
    elseif not IsNull(avatar) and avatar:ReplicaLocallyControlled() then
        while not  instigator:ReplicaLocallyControlled() do
            Sleep(0.1) -- if player transfered to operator mid-fall, wait for transference to complete before resetting operator
        end
        _Reset(instigator, rsPoint)
    end
    
    if fadeIn then
        postFade.AvatarFade(instigator, 1, 0, 0.5, 0)
    end
    
end

function CourseComplete(instigator)
    if IsNull(instigator) or IsNull(instigator:GetPlayer()) then
        return
    end
    local name = instigator:GetPlayer():GetPlayerName()
    if IsNull(_T.gCourseState) or IsNull(_T.gCourseState[name]) or _T.gCourseState[name] == "COMPLETE" then
        return
    end

    _T.gCourseState[name] = "COMPLETE"
    
end

function CancelCourse(action, instigator)
    if IsNull(instigator) or IsNull(instigator:GetPlayer()) then
        return
    end
    local name = instigator:GetPlayer():GetPlayerName()
    if IsNull(_T.gCourseState) or IsNull(_T.gCourseState[name]) or _T.gCourseState[name] == "COMPLETE" then
        return
    end
    if IsNull(mInstigator) then
        mInstigator = instigator
    elseif mInstigator ~= instigator then
        mInstigator = instigator
    end
    _T.gCourseState[name] = "CANCELED"
    
    Sleep(2)
    
    action:Enable()
end

local function DissolveConsole(dur, target)
    local t = 0
    local curDis = console:GetDissolve()
    
    if curDis > target then
        t = dur
        console:SetPhysicsBehaviorAndRegister(normalPhysics)
    else
        console:SetPhysicsBehaviorAndRegister(nil)
    end
    
    while t < dur do
        console:SetDissolve(Lerp(curDis, target, t/dur))
        Sleep(0)
        t = t + DeltaTime()
    end
    
    console:SetDissolve(target)
    
end

local function ResetCourse(zone)

    local objects = gRegion:FindTagged(Symbol("ResetPillarTrigger"))
    
    for i, object in ipairs(objects) do
        if object:GetZone() == zone then
            object:FirePort("Execute")
        end
    end

end

local function Teleport(avatar, point)
    avatar:InputControl():StopCrouching()
    avatar:SetPosture(Engine.WALK)
    avatar:MotionControl():SetPushVelocity(ZERO_VECTOR)
    avatar:Teleport(point:GetPosition())
    avatar:MotionControl():SetTorsoFromView(point:GetRotation())
    avatar:SetCameraView(point:GetRotation())
    avatar:SetVelocity(Vector())
    avatar:ClearLandStyle()
end

local function AvatarCares(avatar, zone)
    return not IsNull(avatar) and not IsNull(avatar:GetZone()) and avatar:GetZone() == zone
end

local function _StartObstacleCourse(jsonComponent)
    
    -- Make sure the Obstacle Course room is finished!
    if not IsNull(jsonComponent) and (not jsonComponent:IsValid() or jsonComponent:IsCollectingMaterials() or jsonComponent:IsUnderConstruction()) then
        local popup = gFlashMgr:GotoMovie(confirmMovie)
        UTIL.ShowMessage("/Lotus/Language/Dojo/ObstacleCourseNotFinishedBuilding")
        return
    end

    --reset course here
    ResetCourse(mAction:GetZone())

    local name = mInstigator:GetPlayer():GetPlayerName()
    local zoneSymbol = Symbol(mInstigator:GetZone():GetFullName())
    local humanAvatars
    local hostMigrated = false
    local player = mInstigator:GetPlayer()
    mInstigator:GetPlayer():AddTimerOfInterest(zoneSymbol)
    
    if mInstigator:ReplicaLocallyControlled() then
        mInstigator:PushInputFilter(courseStartInputFilter)
    end

    DissolveConsole(1, 1)
    
    if mInstigator:ReplicaLocallyControlled() then
        Teleport(mInstigator, startPoint)
        mInstigator:PopInputFilter(courseStartInputFilter)
    end
    
    local gameRules = gGameRules
    gameRules:SetMissionTimer(zoneSymbol, Symbol("/Lotus/Language/Game/BeginObstacleCourse"), maxTime, false, true, true)
    
    if not IsNull(musicSeq) then
        musicSeq:Enable()
    end
    
    --mInstigator dc'ed
    if IsNull(mInstigator) then
        DissolveConsole(1, 0)
    end
    
    if IsNull(_T.gCourseState) then
        _T.gCourseState = {}
    end
    
    _T.gCourseState[name] = "STARTED"
    while not IsNull(mInstigator) and _T.gCourseState[name] == "STARTED" do
        Sleep(0)
        if not IsNull(gameRules) and gameRules:GetMissionTimeLeft(zoneSymbol) <= 0 then
            humanAvatars = gRegion:GetHumanPlayerAvatars()
            for i, av in ipairs(humanAvatars) do
                if AvatarCares(av, mAction:GetZone()) then
                    _T.ShowImpactMessage("/Lotus/Language/Dojo/ObstacleCourseTimeLimitExpired", 5, false, nil, false)
                end
            end
            _T.gCourseState[name] = "FAILED"
            Teleport(mInstigator, defaultResetPoint)
        end
        --host migration - teleport the player who was running the course outside of the course
        if IsNull(gameRules) then
            hostMigrated = true
            while IsNull(gameRules) or gameRules:GetStartState() ~= 4 do
                gameRules = gGameRules
                Sleep(0)
            end
            local humanPlayers = gRegion:GetHumanPlayers()
            
            for i, player in ipairs(humanPlayers) do
                if player:GetPlayerName() == name then
                    Teleport(player:GetAvatar(), defaultResetPoint)
                end
            end
        end
    end
    
    if not hostMigrated and _T.gCourseState[name] == "CANCELED" then
        Teleport(player:GetAvatar(), defaultResetPoint)
        humanAvatars = gRegion:GetHumanPlayerAvatars()
        for i, av in ipairs(humanAvatars) do
            if AvatarCares(av, mAction:GetZone()) then
                _T.ShowImpactMessage("/Lotus/Language/Dojo/ObstacleCourseCancelled", 5, false, nil, false)
            end
        end
    end
    
    if not hostMigrated and not IsNull(mInstigator) and _T.gCourseState[name] == "COMPLETE" then
        local remainingTime = gameRules:GetMissionTimeLeft(zoneSymbol)
        local timeTaken = maxTime - remainingTime
        local mins = math.floor(timeTaken / 60)
        local secs = timeTaken - 60 * mins
        
        mins = string.format("%02d", mins)
        local secStr = string.format("%0.2f", secs)
        
        --zero padding since i can't seem 
        if secs < 10 then
            secStr = "0" .. secStr
        end
        
        humanAvatars = gRegion:GetHumanPlayerAvatars()
        for i, av in ipairs(humanAvatars) do
            if AvatarCares(av, mAction:GetZone()) then
                local timeStr = Localize(timeLoc, false)
                _T.ShowImpactMessage(timeStr .. " " .. mins .. ":" .. secStr, 5, true, nil, false)
            end
        end

        
        if player:IsLocal() then
            if not IsNull(gGameStatsMgr) and not gameRules:GodModeEnabled() then
                --save the score as the amount of time remaining in milliseconds so existing MaxEvent code can be used
                --profile screens will have to convert back to fastest times
                gGameStatsMgr:MaxEvent(Symbol("DojoObstacleScore"), "", "", remainingTime * 1000) 
                gGameStatsMgr:Upload()
            end
        end
    end
    
    if not hostMigrated then
        _T.gCourseState[name] = nil
    end
    
    if not IsNull(gameRules) then
        gameRules:SetMissionTimer(zoneSymbol, Symbol("Complete"), -1, false)
    end
    if not IsNull(musicSeq) then
        musicSeq:Disable()
    end
    
    if not IsNull(player) then
        player:RemoveTimerOfInterest(zoneSymbol)
    end

    DissolveConsole(1, 0)
    mAction:Enable()
end

function StartObstacleCourse(action, instigator)
    mAction = action
    mInstigator = instigator

    -- Get the JsonComponent for this room and make sure it is finished before starting the obstacle course!
    if not IsNull(_T.DojoMgr) then
        local componentParams = _T.DojoMgr:BuildComponentParams(mAction)
        _T.DojoMgr:GetComponent(componentParams.id, _StartObstacleCourse)
    else
        _StartObstacleCourse(nil)
    end
end

function StaminaPickUp(action, instigator)

    if not gRegion:IsMaster() and instigator:ReplicaLocallyControlled() then
        instigator:SetStamina(instigator:GetStamina() + staminaIncrease)
    end
end

function ResetPillars()
    if not IsNull(trigger) then
        trigger:Enable()
    end    
    for i, mover in ipairs(movers) do
        mover:FirePort("Beginning")
    end
end
