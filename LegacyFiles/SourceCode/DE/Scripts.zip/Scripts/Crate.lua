
function Crate(crateDeco)
    local scriptForEachCrate = false
    
    if _T.mAnimatedCrates == nil then
        _T.mAnimatedCrates = {}
    end
    local t = math.random()
    local dir = 1.0
    if not scriptForEachCrate then
        local animatedCrate = {t=t, dir=dir, deco=crateDeco}
        
        table.insert(_T.mAnimatedCrates, animatedCrate)
    else
        
        while not IsNull(crateDeco) do
        
            t = t + DeltaTime() * dir
            if t >= 1.0 or t <= 0.0 then
                dir = -dir
            end
            
            local final = math.abs(t - 0.5) * 2
            final = final * 5.0

            final = AbsNoise(Time()) * 5.0
            
            crateDeco:SetMaterialParam(Lotus_Game.EMISSIVE_MAP_ATTEN, final, 0.0, 0.0, 0.0)
            
            Sleep(0)
        
        end
    end

end