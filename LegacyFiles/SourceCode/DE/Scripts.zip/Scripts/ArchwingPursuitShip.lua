engineWeakpointType = Type()
shieldGeneratorType = Type()
shieldGeneratorDecoType = Type()
reinforcementDelay = 3
maxSimultaneousReinforcements = 4
spawnBone = Symbol("GAME_C1_ROOT")
weakPointProjType = Type()
engineFxType = Type()
engineFxOffest = Vector(-5, 0, 0)
engineSpeedUpEffect = Type()
engineDisableSound = Resource()
engineEnabledSound = Resource()
engineDisableTime = 5.0
engineAccelerationTime = 3.0
engineDisableSpeedMult = 0.6
engineHealthRatio = 0.1                     -- percentage of avatar health to use as engine health
engineBone = Symbol("GAME_C1_EXHAUSTFX")
engineBoneLocalOffset = Vector()
engineBoneLocalRotation = Rotation()
spaceSpawnPointType = WeakResource()
disableHealthPercentage = 0.3
combatModeSound = Resource()
combatModeEndSound = Resource()
MaxRangeToWarp = 400 -- remember that distances in archwing are scaled
WarpAwayEffectType = Type()
WarpAwayDestroctionDelay = 1

shipSequencerType = WeakResource()
shipCloseSequencerType = WeakResource()

--Transmissions
shipTurretDestroyedTrans = Resource()
shipTurretsDestroyedTrans = Resource()
shieldGensDestroyedTrans = Resource()
engineDisabledTrans = Resource()
engineRepairedTrans = Resource()
dronesLaunchedTrans = Resource()

turretAgentTypes = {Type()}

vulnerableEffect = Type()

destroyMarkerWres = WeakResource("/Lotus/Types/Game/MarkerInfos/ObjectiveMarkerInfoPursuitShip")

--Libraries-------------------------
local UTIL = require "EE.Interface.Utilities"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
----------------------------------

local turretBoneList = {Symbol("GAME_L1_TURRETMOUNTS"), Symbol("GAME_R1_TURRETMOUNTS"), 
                        Symbol("GAME_L1_TURRETMOUNTF"), Symbol("GAME_R1_TURRETMOUNTF"),
                        Symbol("GAME_L1_TURRETMOUNTB"), Symbol("GAME_R1_TURRETMOUNTB")}

local shieldGenBoneList = {Symbol("GAME_L1_GENERATORMOUNTS"), Symbol("GAME_R1_GENERATORMOUNTS"), 
                           Symbol("GAME_L2_GENERATORMOUNTS"), Symbol("GAME_R2_GENERATORMOUNTS"),
                           Symbol("GAME_L3_GENERATORMOUNTS"), Symbol("GAME_R3_GENERATORMOUNTS"), 
                           Symbol("GAME_L4_GENERATORMOUNTS"), Symbol("GAME_R4_GENERATORMOUNTS")}
                                    
local DAMAGE_MULT_SYMBOL = Symbol("PursuitShip")
local npcManager = gRegion:GetNpcMgr()
local aiDir = npcManager:GetAiDirector()
local remainingEngineDisabledTime = -1


local NV_TURRETCOUNT = Symbol("PursuitTurretCount")
local NV_TOTALTURRETS = Symbol("PursuitTotalTurretCount")
local NV_GENERATORCOUNT = Symbol("PursuitGeneratorCount")
local NV_TOTALGENERATORS = Symbol("PursuitTotalGeneratorCount")
local NV_PURSUIT_STAGE = Symbol("PursuitStage") -- 0: Search, 1: Chase/Disable, 2:Defend
local NV_SHIPINITIALIZED = Symbol("PursuitInitialized")
local NV_SHIPENGINEDOWN = Symbol("PursuitEngineDown")

local TennoFaction = Symbol("TENNO")

local function IncrementNetVar(symbol)
    local gameRules = gGameRules
    local val = gameRules:GetNetPersistentVar(symbol)
    val = val + 1
    gameRules:SetNetPersistentVar(symbol, val)
end

local function DecrementNetVar(symbol)
    local gameRules = gGameRules
    local val = gameRules:GetNetPersistentVar(symbol)
    val = val - 1
    gameRules:SetNetPersistentVar(symbol, val)
end

function OnKilled(avatar)
    DecrementNetVar(NV_TURRETCOUNT)
    local turretCount = gGameRules:GetNetPersistentVar(NV_TURRETCOUNT)
    
    if turretCount > 0 then
        gGameRules:GiveTransmissionAsyncToAllPlayers(shipTurretDestroyedTrans)
    else
        gGameRules:GiveTransmissionAsyncToAllPlayers(shipTurretsDestroyedTrans)
    end
end
    
function OnDestroyed(entity)
    DecrementNetVar(NV_GENERATORCOUNT)
    local genCount = gGameRules:GetNetPersistentVar(NV_GENERATORCOUNT)
    
    if genCount == 0 then
        gGameRules:GiveTransmissionAsyncToAllPlayers(shieldGensDestroyedTrans)
    end
end

local function CountPlayersInRange(entity, maxRange)
    local count = 0
    
    if not IsNull(entity) then
        local players = gRegion:GetHumanPlayerAvatars()
        local myPos = entity:GetPosition()

        for i = 1, #players do
            if not IsNull(players[i]) then
                local dist = players[i]:DistanceToPoint(myPos)
                if dist < maxRange then
                    count = count + 1
                end
            end
        end
    end

    return count
end

local function WarpOut(pursuitAvatar, warpOutTime)
    if not IsNull(WarpAwayEffectType) then
        gRegion:CreateEntity(WarpAwayEffectType, pursuitAvatar:GetSimPosition(), pursuitAvatar:GetSimRotation(), pursuitAvatar, pursuitAvatar)
    end
    
    local finalScale = Vector(1, 0.1, 10)
    local startScale = Vector(1, 1, 1)
    local tim = 0
    local bone = Symbol("GAME_C1_SHIP1")
    while tim < warpOutTime do
        local t = Clamp(tim / warpOutTime, 0, 1)
        t = t * t * t
        local s = (finalScale * t) + (startScale * (1 - t))
        pursuitAvatar:SetBoneDirectorEx(bone, ZERO_ROTATION, ZERO_VECTOR, s)
        Sleep(0)
        tim = tim + DeltaTime()
    end
    
    print("PursuitShip.lua -- Ship Warped away! -- Migration status: " .. tostring(gPromotedToHost))
    --Sleep(WarpAwayDestroctionDelay)
end

local function UpdateMarkers(shipEnginesAreDown, engineMarker, shieldGenMarkers)
    if gRegion:IsMaster() then
        local enginePort = UTIL.Ternary(shipEnginesAreDown, "Disable", "Enable")
        local shieldGenPort = UTIL.Ternary(shipEnginesAreDown, "Enable", "Disable")
        engineMarker:FirePort(enginePort)
        for i, marker in ipairs(shieldGenMarkers) do
            if not IsNull(marker) then
                marker:FirePort(shieldGenPort)
            end
        end
    else
        if shipEnginesAreDown then
            engineMarker:Disable()
            for i, marker in ipairs(shieldGenMarkers) do
                if not IsNull(marker) then
                    marker:Enable()
                end
            end
        else
            engineMarker:Enable()
            for i, marker in ipairs(shieldGenMarkers) do
                if not IsNull(marker) then
                    marker:Disable()
                end
            end
        end
    end
end

local function ClientLoop(pursuitAvatar)
    if IsNull(pursuitAvatar) then
        return
    end
    
    local initialized = false
    local gameRules = gGameRules
    local sleepTime = 0.1
    
    local engineMarker = nil
    local engineDown = gameRules:GetNetPersistentVar(NV_SHIPENGINEDOWN, 0)
    
    local weakpointDecos = {}
    local shieldGenMarkers = {}
    
    while gameRules:GetNetPersistentVar(NV_PURSUIT_STAGE, 0) ~= 2  and not _T.pursuitShipDisabled do
        if not initialized then
            if gameRules:GetNetPersistentVar(NV_SHIPINITIALIZED, 0) == 1 then
                engineMarker = pursuitAvatar:GetAttachment(destroyMarkerWres)
                weakpointDecos = pursuitAvatar:GetAllAttachments(shieldGeneratorDecoType)
                for i = 1, #weakpointDecos do
                    local marker = weakpointDecos[i]:GetAttachment(destroyMarkerWres)
                    if not IsNull(marker) then
                        table.insert(shieldGenMarkers, marker)
                    end
                end
                initialized = true
            end
        else 
            local currEngineDown = gameRules:GetNetPersistentVar(NV_SHIPENGINEDOWN, 0)
            if currEngineDown ~= engineDown then
                engineDown = currEngineDown
                UpdateMarkers(engineDown == 1, engineMarker, shieldGenMarkers)
            end
        end
        Sleep(sleepTime)
    end
end

function Start(pursuitAvatar)
    if not gRegion:IsMaster() then
        ClientLoop(pursuitAvatar)
        return
    end
    
    local playerAvatar = gRegion:GetLocalPlayerAvatar()
    local gameRules = gGameRules

    if IsNull(pursuitAvatar) then
        return
    end

    _T.originalMaxSpeed = pursuitAvatar:MotionControl():GetRunSpeed()

    Broadcast("ArchwingPursuitShip.lua Started!")

    Sleep(1)
    
    playerAvatar = gRegion:GetLocalPlayerAvatar()

    local weakpoints = {}
    local weakpointDecos = {}
    local turrets = {}
    local originalNumWeakpoints = gameRules:GetNetPersistentVar(NV_TOTALGENERATORS, 0)
    local numWeakpoints = 0
    local pursuitAttachments = pursuitAvatar:GetAllAttachments(spaceSpawnPointType)
    
    local turretCount = gameRules:GetNetPersistentVar(NV_TURRETCOUNT, 0)
    
    -- Creation of turrets an generator shields
    if not gPromotedToHost or gGameRules:GetNetPersistentVar(NV_PURSUIT_STAGE, 0) == 0 then
        --Pick 4----- Gogul: Not the best way should revisit 
        local startIdx = UTIL.Ternary(RandomInt(0, 1) == 0, 1, 3) --1
        local endIdx =  startIdx + 3 --#pursuitAttachments
        ------------------------------------------

        for i = startIdx, endIdx do
            if pursuitAttachments[i]:IsA(spaceSpawnPointType) then
                local turretAgent = aiDir:CreateAgent(turretAgentTypes[RandomInt(1, #turretAgentTypes)], pursuitAttachments[i], Symbol("RandomTeam"), aiDir:GetMaxEnemyLevel())
                if not IsNull(turretAgent) then
                    local turretAvatar = turretAgent:GetAvatar()
                    if not IsNull(turretAvatar) then
                        turretAvatar:AttachToInPlace(pursuitAvatar, turretBoneList[i])
                        ObjectPortHandler(turretAvatar, "OnKilled")
                        IncrementNetVar(NV_TURRETCOUNT)
                        table.insert(turrets, turretAvatar)
                    end
                end
            end
        end
        
        --Pick 4 Again Randomly--------
        local pairIdx = {1, 3, 5}
        startIdx = pairIdx[RandomInt(1, 3)] --1
        endIdx = startIdx + 3 --#shieldGenBoneList 
        -----------------------------
        
        for i = startIdx, endIdx do
            local gen = pursuitAvatar:Attach(shieldGeneratorType, shieldGenBoneList[i])
            if not IsNull(gen) then
                ObjectPortHandler(gen, "OnDestroyed")
                table.insert(weakpoints, gen)
                IncrementNetVar(NV_GENERATORCOUNT)
                -- we want to use hitproxies for weakpoints so we can hit them correctly with all weapon types
                -- but we also need to attach visual decos for these weak points
                gen = pursuitAvatar:Attach(shieldGeneratorDecoType, shieldGenBoneList[i])
                if not IsNull(gen) then
                    table.insert(weakpointDecos, gen)
                end
            end
        end

        gameRules:SetNetPersistentVar(NV_TOTALTURRETS, #turrets)
        gameRules:SetNetPersistentVar(NV_TOTALGENERATORS, #weakpoints)
        originalNumWeakpoints = #weakpoints
    else
        -- Recreate turrets on host migration
        local numTurrets = gameRules:GetNetPersistentVar(NV_TURRETCOUNT, 0)
        local startIdx = UTIL.Ternary(RandomInt(0, 1) == 0, 1, 3) --1
        local endIdx =  startIdx + numTurrets -1

        for i = startIdx, endIdx do
            if pursuitAttachments[i]:IsA(spaceSpawnPointType) then
                local turretAgent = aiDir:CreateAgent(turretAgentTypes[RandomInt(1, #turretAgentTypes)], pursuitAttachments[i], Symbol("RandomTeam"), aiDir:GetMaxEnemyLevel())
                if not IsNull(turretAgent) then
                    local turretAvatar = turretAgent:GetAvatar()
                    if not IsNull(turretAvatar) then
                        turretAvatar:AttachToInPlace(pursuitAvatar, turretBoneList[i])
                        ObjectPortHandler(turretAvatar, "OnKilled")
                        table.insert(turrets, turretAvatar)
                    end
                end
            end
        end

        -- Recreate generators on host migration
        local numGens = gameRules:GetNetPersistentVar(NV_GENERATORCOUNT, 0)
        local pairIdx = {1, 3, 5}
        startIdx = pairIdx[RandomInt(1, 3)] --1
        endIdx = startIdx + numGens - 1 --#shieldGenBoneList 
        
        for i = startIdx, endIdx do
            local gen = pursuitAvatar:Attach(shieldGeneratorType, shieldGenBoneList[i])
            if not IsNull(gen) then
                ObjectPortHandler(gen, "OnDestroyed")
                table.insert(weakpoints, gen)
                -- we want to use hitproxies for weakpoints so we can hit them correctly with all weapon types
                -- but we also need to attach visual decos for these weak points
                gen = pursuitAvatar:Attach(shieldGeneratorDecoType, shieldGenBoneList[i])
                if not IsNull(gen) then
                    table.insert(weakpointDecos, gen)
                end
            end
        end
    end

    numWeakpoints = #weakpoints

    --Set health of the weakpoints
    if numWeakpoints > 0 then
        pursuitAvatar:DamageControl():AddDamageModifier(DAMAGE_MULT_SYMBOL, Engine.DT_ANY, Engine.ANY_PART, 0)
        pursuitAvatar:DamageControl():AddShieldDamageModifier(DAMAGE_MULT_SYMBOL, Engine.DT_ANY, Engine.ANY_PART, 0)

        local weakpointHealth = pursuitAvatar:GetMaxHealth() / originalNumWeakpoints
        for i = 1, numWeakpoints do
            weakpoints[i]:SetHealth(weakpointHealth, true)
        end
    end

    --Set health of the turrets
    if #turrets > 0 then
        local turretHealth = pursuitAvatar:GetMaxHealth() / #turrets
        for i = 1, #turrets do
            turrets[i]:SetMaxHealth(turretHealth, true)
            turrets[i]:SetHealth(turretHealth, true)
        end
    end
    
    gameRules:SetNetPersistentVar(NV_SHIPINITIALIZED, 1)
    
    local sleepTime = 0.1
    local engineFx = nil
    local engineFxLower = nil
    local engineDisableProxy = nil
    local engineWeakSpotFx = nil

    local nextSpawn = reinforcementDelay
    local reinforcements = {}
    local prevCombatMode = _T.pursuitCombatMode
    
    local shipSequencer = pursuitAvatar:GetAttachment(shipSequencerType)
    local shipCloseSequencer = pursuitAvatar:GetAttachment(shipCloseSequencerType)
    local engineMarker = pursuitAvatar:GetAttachment(destroyMarkerWres)
    
    local shieldGenMarkers = {}
    for i = 1, #weakpointDecos do
        local marker = weakpointDecos[i]:GetAttachment(destroyMarkerWres)
        if not IsNull(marker) then
            table.insert(shieldGenMarkers, marker)
        end
    end

    local proximitySafeTime = 15
    local proximitySafeTimeElapsed = nil

    
    --Main Loop-----------
    while gameRules:GetNetPersistentVar(NV_PURSUIT_STAGE, 0) ~= 2  and not _T.pursuitShipDisabled do
    
        if CountPlayersInRange(pursuitAvatar, MaxRangeToWarp) == 0 then
            if IsNull(proximitySafeTimeElapsed) then
                OBJTXT.SetPrimaryObjText("/Lotus/Language/Game/PursuitPhaseOneObj")
                OBJTXT.ClearSecondaryObjText()
                OBJTXT.SetObjTimer(proximitySafeTime, false, true, false, OBJTXT.TIMELIMIT_STRING)
                proximitySafeTimeElapsed = 0
            elseif proximitySafeTimeElapsed >= proximitySafeTime then
                WarpOut(pursuitAvatar, WarpAwayDestroctionDelay)
                pursuitAvatar:Destroy()
                _T.pursuitAvatarEscaped = true
                break
            else
                proximitySafeTimeElapsed = proximitySafeTimeElapsed + sleepTime
            end
        else
            OBJTXT.RemoveObjTimer()
            OBJTXT.SetPrimaryObjText("/Lotus/Language/Objectives/PursuitPursueCourier")
            OBJTXT.SetSecondaryObjText("/Lotus/Language/Game/PursuitPhaseTwoObj", 2)
            proximitySafeTimeElapsed = nil
        end

        --Play sounds for entering and exiting combat mode
        if prevCombatMode ~= _T.pursuitCombatMode then
            prevCombatMode = _T.pursuitCombatMode
            if #turrets > 0 then
                if _T.pursuitCombatMode == true then
                    pursuitAvatar:PlaySound(combatModeSound, false, 0, true)
                else
                    pursuitAvatar:PlaySound(combatModeEndSound, false, 0, true)
                end
            end
        end

        --Spawn reinforcements
        if nextSpawn > 0 then
            nextSpawn = nextSpawn - (sleepTime + DeltaTime())
        end
        if _T.pursuitCombatMode and nextSpawn <= 0.0 and #reinforcements < maxSimultaneousReinforcements then
            if aiDir:GetLiveAICount(true) < aiDir:GetNpcHardCap() then
                local agentType = aiDir:GetRandomEnemyAgentType(pursuitAvatar:GetFaction(), 0, false)
                local agent = gRegion:GetNpcMgr():CreateAgentFromParent(agentType, pursuitAvatar:GetBonePosition(spawnBone), Rotation(), pursuitAvatar:GetAgent())
                if not IsNull(agent) then
                    nextSpawn = reinforcementDelay
                    aiDir:IncrementMaxPopulationSpawnCount(1)
                    gameRules:GiveTransmissionAsyncToAllPlayers(dronesLaunchedTrans)
                    table.insert(reinforcements, agent)
                end
            end
        end
        
        for i = #reinforcements, 1, -1 do
            if IsNull(reinforcements[i]) then
                table.remove(reinforcements, i)
            end
        end

        --Add the engine proxy
        if remainingEngineDisabledTime < 0.0 and engineDisableTime > 0.0 then
            pursuitAvatar:PlaySound(engineEnabledSound, false, 0, true)
            engineFx = gRegion:CreateEntity(engineFxType, pursuitAvatar:GetPosition(), ZERO_ROTATION)
            if not IsNull(engineFx) then
                engineFx:AttachTo(pursuitAvatar, engineBone)
                engineFx:SetAttachLocalSpace(engineFxOffest, Rotation(-90, 15, 0))
            end
            engineFxLower = pursuitAvatar:Attach(engineFxType, EMPTY_SYMBOL, Vector(0, 0.6, -2), Rotation(0, 150, 0))
            engineDisableProxy = gRegion:CreateEntity(engineWeakpointType, pursuitAvatar:GetPosition(), ZERO_ROTATION, pursuitAvatar, pursuitAvatar)
            engineWeakSpotFx = pursuitAvatar:Attach(weakPointProjType, engineBone)
            if not IsNull(engineDisableProxy) then
                engineDisableProxy:SetHealth(engineHealthRatio * pursuitAvatar:GetMaxHealth() * gRegion:GetHumanPlayerAvatarCount())
                engineDisableProxy:AttachTo(pursuitAvatar, engineBone)
                engineDisableProxy:SetAttachLocalSpace(engineBoneLocalOffset, engineBoneLocalRotation)
                remainingEngineDisabledTime = 0.0
            end

            if not IsNull(shipSequencer) and shipSequencer:IsA(gSequencerType) then
                shipSequencer:Enable()
            end

            if not IsNull(shipCloseSequencer) and shipCloseSequencer:IsA(gSequencerType) then
                shipCloseSequencer:Enable()
            end
            
            gameRules:SetNetPersistentVar(NV_SHIPENGINEDOWN, 0)
            UpdateMarkers(false, engineMarker, shieldGenMarkers)
        end

        if #turrets > 0 then
            for i = #turrets, 1, -1 do
                if IsNull(turrets[i]) then
                    table.remove(turrets, i)
                end
            end
        end

        if numWeakpoints > 0 then
            for i = #weakpoints, 1, -1 do
                --Count Weakpoints, set avatar health
                if IsNull(weakpoints[i]) then
                    table.remove(weakpoints, i)
                    numWeakpoints = numWeakpoints - 1
                    local newHealth = ((pursuitAvatar:GetMaxHealth() / originalNumWeakpoints) * numWeakpoints * (1 - disableHealthPercentage)) + (disableHealthPercentage * pursuitAvatar:GetMaxHealth());
                    pursuitAvatar:SetHealth(newHealth, true)

                    -- The weakspot proxy has been destroyed, so we need to destroy the deco too
                    if i <= #weakpointDecos then
                        if not IsNull(weakpointDecos[i]) then
                            weakpointDecos[i]:Destroy()
                        end
                        table.remove(weakpointDecos, i)
                    end
                end 
                
                --All Weakpoints Destroyed, ship is now vulnerable
                if numWeakpoints == 0 then
                    pursuitAvatar:DamageControl():RemoveDamageModifier(DAMAGE_MULT_SYMBOL)
                    pursuitAvatar:DamageControl():RemoveShieldDamageModifier(DAMAGE_MULT_SYMBOL)
                    pursuitAvatar:Attach(vulnerableEffect, EMPTY_SYMBOL)
                end
            end
        end
        
        --Check for predeath
        local pursuitDmgCtrl = pursuitAvatar:DamageControl()
        if pursuitDmgCtrl:IsPreDeath() then
            _T.pursuitShipDisabled = true
            _T.pursuitCombatMode = true

            if not IsNull(engineFx) then
                engineFx:Destroy()
            end

            if not IsNull(engineFxLower) then
                engineFxLower:Destroy()
            end

            if not IsNull(engineWeakSpotFx) then
                engineWeakSpotFx:Destroy()
            end

            if not IsNull(shipSequencer) and shipSequencer:IsA(gSequencerType) then
                shipSequencer:Disable()
            end

            if not IsNull(shipCloseSequencer) and shipCloseSequencer:IsA(gSequencerType) then
                shipCloseSequencer:Disable()
            end
            
            gameRules:SetNetPersistentVar(NV_SHIPENGINEDOWN, 1)
            UpdateMarkers(true, engineMarker, shieldGenMarkers)

            pursuitAvatar:SetFaction(TennoFaction)
            pursuitAvatar:InventoryControl():AddUpgrade(Game.AVATAR_MOVEMENT_SPEED, Game.MULTIPLY, 0.0)
            if #turrets > 0 then
                --switch all remaining turrets to TENNO faction too
                for i = 1, #turrets do
                    if not IsNull(turrets[i]) then
                        turrets[i]:SetFaction(TennoFaction)
                    end
                end
            end
            pursuitAvatar:SetAnimAction(Symbol("ShipDisabled"))
            pursuitAvatar:SetHealth(pursuitDmgCtrl:PreDeathHealthThreshold())
            pursuitDmgCtrl:SetPreDeathHealthPortion(-1)
            pursuitDmgCtrl:SetPreDeathEnabled(false)
            pursuitDmgCtrl:SetMaxShield(0)
            aiDir:OrderNpcsStormTarget(pursuitAvatar)
        end
        
        --Add/remove speed slow upgrade from destroying the engine proxy
        if remainingEngineDisabledTime >= 0.0 and IsNull(engineDisableProxy) then -- Engines Disabled
            if remainingEngineDisabledTime == 0.0 then
                _T.shipMaxSpeed = _T.originalMaxSpeed * engineDisableSpeedMult
                pursuitAvatar:ScriptRunChildScript(Symbol("ChangeShipSpeed"), false) 
                _T.pursuitShipSlowed = true
                _T.pursuitCombatMode = true

                pursuitAvatar:PlaySound(engineDisableSound, false, 0, true)
                gameRules:GiveTransmissionAsyncToAllPlayers(engineDisabledTrans)
                if not IsNull(engineFx) then
                    engineFx:Destroy()
                end
                if not IsNull(engineFxLower) then
                    engineFxLower:Destroy()
                end

                if not IsNull(engineWeakSpotFx) then
                    engineWeakSpotFx:Destroy()
                end

                if not IsNull(shipSequencer) and shipSequencer:IsA(gSequencerType) then
                    shipSequencer:Disable()
                end

                if not IsNull(shipCloseSequencer) and shipCloseSequencer:IsA(gSequencerType) then
                    shipCloseSequencer:Disable()
                end
                
                gameRules:SetNetPersistentVar(NV_SHIPENGINEDOWN, 1)
                UpdateMarkers(true, engineMarker, shieldGenMarkers)

            elseif remainingEngineDisabledTime >= engineDisableTime then --Engines Repaired
                gameRules:GiveTransmissionAsyncToAllPlayers(engineRepairedTrans)
                _T.shipMaxSpeed = _T.originalMaxSpeed
                pursuitAvatar:ScriptRunChildScript(Symbol("ChangeShipSpeed"), false)
                pursuitAvatar:InventoryControl():RemoveUpgrade(Game.AVATAR_MOVEMENT_SPEED, Game.MULTIPLY, engineDisableSpeedMult)
                pursuitAvatar:Attach(engineSpeedUpEffect, engineBone, engineFxOffest, Rotation(-90, 15, 0))
                remainingEngineDisabledTime = -1.0
                _T.pursuitShipSlowed = false
                if not _T.pursuitLoopingPath then
                    _T.pursuitCombatMode = false
                end
                gameRules:SetNetPersistentVar(NV_SHIPENGINEDOWN, 0)
                UpdateMarkers(false, engineMarker, shieldGenMarkers)
            end

            if remainingEngineDisabledTime >= 0.0 then
                remainingEngineDisabledTime = remainingEngineDisabledTime + sleepTime + DeltaTime()
            end
        end
        
        Sleep(sleepTime)
    end
    
    Broadcast("ArchwingPursuitShip.lua Complete!")
    
end

function TurretActivationMonitor(turretAvatar)
    local prevState = _T.pursuitCombatMode
    while true do
        if _T.pursuitCombatMode ~= prevState then
            prevState = _T.pursuitCombatMode
            if _T.pursuitCombatMode == true then
                 turretAvatar:IncrementActivationRequests()
            else
                turretAvatar:DecrementActivationRequests()
            end
        end
        Sleep(0.1)
    end
end

function ChangeShipSpeed(ship)
    if IsNull(_T.shipMaxSpeed) or IsNull(ship) then
        return
    end
    local duration = math.max(1.0, engineAccelerationTime)
    local startSpeed = ship:MotionControl():GetRunSpeed()
    local x = 0
    while true do
        if IsNull(ship) then
            return
        end
        
        x = math.min(1.0, x + (DeltaTime() / duration))
        local newSpeed = Lerp(startSpeed, _T.shipMaxSpeed, x)
        ship:MotionControl():SetMaxRunVelocity(newSpeed)

        if x >= 1.0 then
            return
        end
        Sleep(0)
    end
end

function SwapHitProxyFx(spawner)
    --Replicated spawner when ship becomes vulnerable so we no longer display shield hit fx
    Sleep(0)
    local avatar = spawner:GetAttachRoot()
    if IsNull(avatar) or not avatar:IsA(gBaseAvatarType) then
        return
    end
    avatar:DamageControl():SetFlashOnHit(false)
end
