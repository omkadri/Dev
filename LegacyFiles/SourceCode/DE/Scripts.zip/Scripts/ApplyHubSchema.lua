railSchemaIcon = Resource()
hubSchemaProcLevelRes = Resource()
hubProcLevel = WeakResource()

local mGameData = nil
local mChildMovie = nil
local mMadeSchemaChoice = false
local mSchemaChoiceElement = nil
local mSchemaApplyResult = nil
local mSchemaApplyBody = nil
local mSchemaApplyConfirm = nil
local mSchemaData = nil

local UTIL = require "EE.Interface.Utilities"

local function _BuildElementFromItem(item)
    local element =
    {
        Item = item,
        Name = item.mName
    }

    return(element)
end

function ApplySchemaConfirm(btnState)
    mSchemaApplyConfirm = (tonumber(btnState) == Engine.CI_SELECT)
end

function OnSchemaData(result, body)
    mSchemaData = { Result = result, Body = body }
end

function OnSchemaApplied(result, body)
    mSchemaApplyResult = result
    mSchemaApplyBody = body
end

function ApplyHubSchema(action, avatar)
    if not avatar:ReplicaLocallyControlled() then
        return
    end

    mGameData = gPlayerProfileMgr:GetPlayerProfile(0):GetGameSpecificData()

    local guildVault = mGameData:GetGuildVault()
    local allianceVault = mGameData:GetAllianceVault()

    local customGuildSchemas = guildVault.mHubAreaSchemas
    local customAllianceSchemas = allianceVault.mHubAreaSchemas

    mChildMovie = gFlashMgr:GotoMovie(_G.UIMovie_ItemBrowsingMovie)

    local title = mChildMovie:GetLocalized("/Lotus/Language/Dojo/ChooseSchemaToApply", false, {RAIL_NAME = "(this place here)"})

    mChildMovie:Execute("SetTitle", title)
    mChildMovie:Execute("SetRequiredSelections", 1)
    mChildMovie:Execute("SetRequiresConfirmation", "false")
    mChildMovie:Execute("SetExitCallout", "/Lotus/Language/Menu/Select")

    _T.BrowseDone =
        function(pElements)
            _T.BrowseDone = nil

            if pElements ~= nil and pElements[1] ~= nil then
                mSchemaChoiceElement = pElements[1]
            end

            mMadeSchemaChoice = true
        end
    mChildMovie:Execute("SetCallBack", "BrowseDone")

    _T.GetAllItems = 
        function()

            local allItems = { }

            for i = 1, #customGuildSchemas do
                local customRail = customGuildSchemas[i]
                --if mSchemaEditMode or customRail.mNumComponents == 3 then
                    local element = _BuildElementFromItem(customRail)
                    element.IsAlliance = false
                    element.Name = customRail.mName
                    element.CustomRail = customRail
                    element.Icon = railSchemaIcon
                    table.insert(allItems, element)
                --end
            end

            for i = 1, #customAllianceSchemas do
                local customRail = customAllianceSchemas[i]
                --if mSchemaEditMode or customRail.mNumComponents == 3 then
                    local element = _BuildElementFromItem(customRail)
                    element.IsAlliance = true
                    element.Name = customRail.mName
                    element.CustomRail = customRail
                    element.Icon = railSchemaIcon
                    table.insert(allItems, element)
                --end
            end

            return(allItems)
            
        end
    mChildMovie:Execute("SetElementsFunction", "GetAllItems")

    while not mMadeSchemaChoice do
        Sleep(0)
    end

    if not IsNull(mSchemaChoiceElement) then
        local applyConfirmMessage = Localize("/Lotus/Language/Dojo/ApplySchemaConfirm", { RAIL_NAME = "(this place here)", SCHEMA_NAME = mSchemaChoiceElement.CustomRail.mName })
            
        UTIL.ShowConfirmMessage(applyConfirmMessage, "ApplySchemaConfirm")

        while IsNull(mSchemaApplyConfirm) do
            Sleep(0)
        end

        if not mSchemaApplyConfirm then
            return
        end

        -- Get the schema data:
        local schemaId = mSchemaChoiceElement.CustomRail.mItemId.mId
        local allianceSchema = mSchemaChoiceElement.IsAlliance

        local ownerId = mGameData:GetGuildId()
        if allianceSchema then
            ownerId = mGameData:GetAllianceId()
        end

        mGameData:GetCustomSolarRail(schemaId, ownerId, allianceSchema, true, true, 0, "", "OnSchemaData")

        while IsNull(mSchemaData) do
            Sleep(0)
        end

        if mSchemaData.Result then
            hubSchemaProcLevelRes:Refresh(mSchemaData.Body)
            local schemaComponents = hubSchemaProcLevelRes:GetComponents()

            local hubProcLevelRes = _T.DojoMgr.mDojo
            local mergeParams = hubProcLevelRes:BuildComponentParams(action)

            local newComponentJson = hubProcLevelRes:MergeLayout(schemaComponents, mergeParams)
            if newComponentJson ~= "" then
                local node = "VenusHUB" -- TODO: Get node name!!
                gGameRules:ApplyHubSchema(node, schemaId, allianceSchema, newComponentJson, "OnSchemaApplied")

                while IsNull(mSchemaApplyResult) do 
                    Sleep(0)
                end

                if mSchemaApplyResult then
                    -- Tell everyone to reload
                    local reloadJson = cjson.encode({ reload = true })
                    gMatchingService:SendRelayP2P("all", reloadJson)

                    -- And reload ourselves!
                    local levelArgs = gRegion:GetLevelArgs()
                    levelArgs.level = hubProcLevel

                    local mergedHub = _T.DojoMgr.mDojo:GetLevelWResFromMergedJsonAndProc(mSchemaApplyBody, levelArgs)
                    if not IsNull(mergedHub) then
                        _T.DojoMgr.mJsonProcLevelHelper:NotifyNumComponentsChanged(1, mergedHub)
                        return
                    end
                end

                UTIL.ShowMessage("/Lotus/Language/Menu/HubSchemaApplyFail")
            else
                print("Failed to merge layouts!")
                return
            end
        end
    end
end