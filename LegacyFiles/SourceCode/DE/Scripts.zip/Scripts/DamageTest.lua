

function DamageTest(deco, scriptDamageData)

    local a = 1
    local b = 2
    local bbb = 333
    local ssd = scriptDamageData
    local tempDeco = deco
    

    local fireDmg = ssd:GetDamagePct(Engine.DT_FIRE)
    local impactDmg = ssd:GetDamagePct(Engine.DT_IMPACT)
    
    local c = 3

end