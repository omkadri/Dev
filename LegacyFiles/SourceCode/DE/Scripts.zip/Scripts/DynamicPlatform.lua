--Randomized platform that can be in 3 different states.
    
function PlatformStart(instance)
    
    local mover = instance
    local movementSpeed = Random(0.5,1.5)
    mover:SetAnimationTime(movementSpeed)
    
    local state = RandomInt(0,3)
    local waitDelay = RandomInt(4,6)
    local randPosition = Random(0,1)
    
    
    
    if state == 0 then
        -- Do nothing, Down position.
        return
        
    elseif state== 1 then
        -- Move to fully up postion.
        
        while true do
            local delta = mover:GetDelta()
            mover:StartMovement()
        
            mover:StartForwardMovement()
            Sleep(4)
            
            mover:StopMovement()
            return
            
        end
        
    elseif state== 2 then
        -- Random postion.
        
        while true do
            local delta = mover:GetDelta()
            mover:StartMovement()
        
            mover:StartForwardMovement()
            Sleep(0)
            if delta >= randPosition then
                mover:StopMovement()
                return
            
            end
        end
        
    elseif state == 3 then
        -- Moving back and forth
        
        while true do
            local delta = mover:GetDelta()
            mover:StartMovement()
        
            mover:StartForwardMovement()
            Sleep(waitDelay)
            
            mover:StartBackwardMovement()
            Sleep(waitDelay)
            
        end
    end
end