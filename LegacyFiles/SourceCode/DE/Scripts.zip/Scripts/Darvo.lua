
testing = false
-- Darvo mobile defense alert
local transmissionOverridesAlertTag = Symbol("Darvo")
local endOfMissionOverride = Resource("/Lotus/Sounds/Dialog/Alerts/DarvoRescue/DDarvoRescRadioPlay170FrohdBek_en.wav")
local transmissionOverrides =
{
    {Type("/Lotus/Sounds/Lotus/CorpusBipedsTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoMobileDefense/DarvoBipedDetected")},
    {Type("/Lotus/Sounds/Lotus/ByPassCompleteTransmission"), nil},
    {Type("/Lotus/Sounds/Lotus/LockdownBypassedTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoMobileDefense/DarvoBypassComplete")},
    {Type("/Lotus/Sounds/Lotus/EnemiesAwareTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoMobileDefense/DarvoDetected")},
    {Type("/Lotus/Sounds/Lotus/EnemiesUnawareTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoMobileDefense/DarvoUndetected")},
    {Type("/Lotus/Sounds/Lotus/ShipOnLockdownTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoMobileDefense/DarvoLockdown")},
    
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseGoalReenforcementTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoMobileDefense/DarvoMDefGoalReinf"), 1}, -- Plays once, then gets replaced with nothing
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseGoalReenforcementTransmission"), nil},
    
    {Type("/Lotus/Sounds/Lotus/MissionObjectiveRescueTransmission"), nil},
    {Type("/Lotus/Sounds/Lotus/RescueMissionSearchCellsTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoRescue/DarvoRescRadioPlay150Darvo")},
    {Type("/Lotus/Sounds/Lotus/GoalReinforcementRescueTransmission"), nil},
    {Type("/Lotus/Sounds/Lotus/ObjectiveFoundAssassinateTransmission"), nil},
    {Type("/Lotus/Sounds/Lotus/ObjectiveFoundRescueTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoRescue/DarvoRescRadioPlay160Darvo")},
    {Type("/Lotus/Sounds/Lotus/ObjectiveCompleteRescueTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoRescue/DarvoRescRadioPlay170ForhdBek")}, -- There's a typo here(Forhd) but it's also in the type, so this should still work.
    
    --{Type(""), Type("/Lotus/Sounds/Dialog/Alerts/DarvoMobileDefense/DarvoMDefMissionFail")},  -- Not used?
    --{Type(""), Type("/Lotus/Sounds/Dialog/Alerts/DarvoMobileDefense/DarvoMDefObjComplete")},    -- extraction: which does this replace? Not used?
    
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseObjectiveTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoMobileDefense/DarvoMDefMissionObj")}, -- intro
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseHackingProgressMiddleTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoMobileDefense/DarvoMDefProgress"), 2},
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseHackingProgressMiddleTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoMobileDefense/DarvoMDefProgressStart"), 1},
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseHackingProgressMiddleTransmission"), nil},
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseNewMissionModifierTransmission"), nil},
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseCustomMissionCompleteTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoMobileDefense/DarvoMDefTerminalAllComplete")},
    
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseHackingProgressEndTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoMobileDefense/DarvoMDefTerminalComp"), 1},   -- first terminal finished
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseHackingProgressEndTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoMobileDefense/DarvoMDefTerminalCompThird"), 1},   -- second terminal finished
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseHackingProgressEndTransmission"), nil},   -- third terminal finished; should we play something here?
    
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseDataTerminalCompletedTransmission"), nil}, -- doesn't seem to be used anywhere, but we'll blank it out just in case
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseBridgeTransmission"), nil},   -- does this get played?
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseDataTerminalLocatedTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoMobileDefense/DarvoMDefTerminalLoc")},
    
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseHackingProgressStartTransmission"), nil, 1},  -- play nothing for the first and second terminal, for the third play a message
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseHackingProgressStartTransmission"), nil, 1},
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseHackingProgressStartTransmission"), Type("/Lotus/Sounds/Dialog/Alerts/DarvoMobileDefense/DarvoMDefTerminalCompLure"), 1},
    {Type("/Lotus/Sounds/Lotus/MobileDefense/MobileDefenseHackingProgressStartTransmission"), nil},
    
    {Type("/Lotus/Sounds/Lotus/ShipOnFireTransmission"), nil},
    {Type("/Lotus/Sounds/Lotus/ShipIcedUpTransmission"), nil}
}


function AddTransmissionOverrides()
    local gameRules = gGameRules
    
    if gameRules:GetMission().alertTag == transmissionOverridesAlertTag or testing == true then
        _T.EndOfMissionVoiceOverride = endOfMissionOverride
        for i = 1, #transmissionOverrides do
            local count = 0
            if not IsNull(transmissionOverrides[i][3]) then
                count = transmissionOverrides[i][3]
            end
            gameRules:AddTransmissionOverride(transmissionOverrides[i][1], transmissionOverrides[i][2], count)
        end
    end
end