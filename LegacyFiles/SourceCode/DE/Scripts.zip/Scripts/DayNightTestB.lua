fogMaterial = Resource("/EE/Materials/FogMaterial")
skyMaterial = Resource("/EE/Materials/Defaults/DynamicSkyboxMaterial")
waterMaterial = Resource("/Lotus/Fx/Levels/EidolonPlains/EPWater")

atmosNightTexture= Resource()
atmosDawnTexture= Resource()
atmosDayTexture= Resource()
atmosDuskTexture= Resource()
atmosEveningTexture = Resource()

local SunDirSymbol = Symbol("SunDir")
local AtmosphereBlendSymbol = Symbol("AtmosphereBlend")
local AtmosphereTextureASymbol = Symbol("AtmosphereTextureA")
local AtmosphereTextureBSymbol = Symbol("AtmosphereTextureB")
local BlendSymbol = Symbol("Blend")

local function SetLight(light, brightArray, colorArray, index, nextIndex, v)
    local b = Lerp(brightArray[index], brightArray[nextIndex], v)
    local color = colorArray[index]
    color = color:Lerp(colorArray[nextIndex], v)
    light:SetBrightness(b)
    light:SetColor(color)
end

local function BlendKeys(a, b, t, state, curTime)

    local brightnessAtten = 1.0
    local p = -90
    local sunUp = 7
    local sunDown = 23

    state.postProcess = gRegion:GetLevelInfo().postProcess

    if curTime >= sunUp and curTime <= sunDown then
        local width = (sunDown - sunUp)
        p = Clamp((curTime - sunUp) / width, 0, 1)
        p = Lerp(-190, 10, p)
        --local curPitch = state.sunRotation.pitch
        --curPitch = Lerp(curPitch, p, DeltaTime() * 4)
        --brightnessAtten = 1.0-Clamp(math.abs(curPitch - p) / 90, 0, 1)
        --p = curPitch
    else
        -- lazy converge to midnight
        p = state.sunRotation.pitch
        p = Lerp(p, -60, DeltaTime() * 1)
        brightnessAtten = Clamp(math.abs(p - 60) / 90, 0, 1)
    end
    state.sunRotation.pitch = p
    
    state.sunLight:SetDirectionalLightDir(AngleToDirection(state.sunRotation) * -1.0)
    state.sunLight:SetColor(a.sunColor:Lerp(b.sunColor, t))
    state.sunLight:SetBrightness(Lerp(a.sunBrightness, b.sunBrightness, t) * brightnessAtten)
    
    local sunDir = AngleToDirection(state.sunRotation)
    
    if not IsNull(state.fogMaterial) then
        state.fogMaterial:SetParam(SunDirSymbol, sunDir.x, sunDir.y, sunDir.z, 0.0)
        state.fogMaterial:SetParam(AtmosphereBlendSymbol, t)
        state.fogMaterial:SetShaderSampler(AtmosphereTextureASymbol, a.atmosphereTexture)
        state.fogMaterial:SetShaderSampler(AtmosphereTextureBSymbol, b.atmosphereTexture)
    end
    
    if not IsNull(skyMaterial) then
        skyMaterial:SetParam(SunDirSymbol, sunDir.x, sunDir.y, sunDir.z, 0.0)
        skyMaterial:SetParam(BlendSymbol, t)
        skyMaterial:SetShaderSampler(AtmosphereTextureASymbol, a.atmosphereTexture)
        skyMaterial:SetShaderSampler(AtmosphereTextureBSymbol, b.atmosphereTexture)
    end
    
    if not IsNull(waterMaterial) then
        waterMaterial:SetParam(SunDirSymbol, sunDir.x, sunDir.y, sunDir.z, 0.0)
        waterMaterial:SetParam(BlendSymbol, t)
        waterMaterial:SetShaderSampler(AtmosphereTextureASymbol, a.atmosphereTexture)
        waterMaterial:SetShaderSampler(AtmosphereTextureBSymbol, b.atmosphereTexture)
    end
    
    if not IsNull(state.bgZone) and not IsNull(state.sunFlare) then
        state.skyboxSunPos.x = sunDir.x * 20.0
        state.skyboxSunPos.y = sunDir.y * 20.0
        state.skyboxSunPos.z = sunDir.z * 20.0
        VectorAdd(state.flarePos,  state.bgZonePos, state.skyboxSunPos)
        state.sunFlare:SetPosition(state.flarePos)
        state.sunFlare:SetOpacity(Lerp(a.sunFlare, b.sunFlare, t))
    end
    
    --state.postProcess.lightMapTint = a.lmColor:Lerp(b.lmColor, t)
    state.postProcess.saturation = Lerp(a.saturation, b.saturation, t)
    --state.postProcess.targetExposure = Lerp(a.exposure, b.exposure, t)
    --state.postProcess.lightMapBoost = Lerp(a.lmAtten, b.lmAtten, t) * 3
end

local function CalcHour(t)
    --[[
    January 1, 1970 GMT
    Human readable time     Seconds
    1 hour  3600 seconds
    1 day   86400 seconds
    1 week  604800 seconds
    1 month (30.44 days)    2629743 seconds
    1 year (365.24 days)     31556926 seconds
    ]]
    local currentDay = math.floor(t / 86400) % 365
    local currentHour = math.floor(t / 3600) % 24
    local currentMinute = math.floor(t / 60) % 60
    local currentYear = 1970 + math.floor(t / 31556926)
    return currentHour
end

function TestDirLight(sunLight)

    if true then
        return -- moving to DynamicSky.cpp
    end

    Sleep(0)

    local gameRules = gGameRules
    local worldTime = gameRules:GetGlobalWorldTime()
    local worldHour = CalcHour(worldTime)

    worldHour = worldHour * 2
    

    -- 50% day/night
    -- 'blue hour' before sun is directly visible
    -- 2 magic hours sunrise & sunset
    -- 6 hour cycle
    
    local midNight = 
    {
        time=0,
        blendTime=1,
        sunColor=Color(80, 80, 128),
        sunBrightness=0.5,
        sunFlare=0,
        lmColor=Color(64,64,96),
        lmAtten=1,
        saturation=0.6,
        exposure=0.07,
        atmosphereTexture=atmosNightTexture
    }
        
    local blueMorning = 
    {
        time=6,
        blendTime=7,
        sunColor=Color(255,137,14),
        sunBrightness=0.3,
        sunFlare=0,
        lmColor=Color(76 * 1.2,78* 1.2,98* 1.2),
        lmAtten=1,
        saturation=1.0,
        exposure=0.1,
        atmosphereTexture=atmosEveningTexture
    }
    
    local sunRise = 
    {
        time=8,
        blendTime=9,
        sunColor=Color(255,137,14),
        sunBrightness=1.0,
        sunFlare=1,
        lmColor=Color(56 * 1.2,58* 1.2,78* 1.2),
        lmAtten=1,
        saturation=1.0,
        exposure=0.1,
        atmosphereTexture=atmosDawnTexture
    }
    
    local day = 
    {
        time=10,
        blendTime=11,
        sunColor=Color(255,240,210),
        sunBrightness=1,
        sunFlare=1,
        lmColor=Color(111 * 1.1,123* 1.1,142* 1.1),
        lmAtten=0.75,
        saturation=1.0,
        exposure=0.1,
        atmosphereTexture=atmosDayTexture
    }
    
    local sunSet = 
    { 
        time=19,
        blendTime=20,
        sunColor=Color(255,137,14),
        sunBrightness=1.0,
        sunFlare=1,
        lmColor=Color(96 * 1.2,58* 1.2,48* 1.2),
        lmAtten=1,
        saturation=1.0,
        exposure=0.1,
        atmosphereTexture=atmosDuskTexture
    }
    
    local blueEvening = 
    {
        time=21,
        blendTime=22,
        sunColor=Color(255,137,14),
        sunBrightness=0.1,
        sunFlare=0,
        lmColor=Color(76 * 1.7,78* 1.7,98* 1.7),
        lmAtten=1,
        saturation=1.0,
        exposure=0.1,
        atmosphereTexture=atmosEveningTexture
    }

    local night = 
    {
        time=23,
        blendTime=24,
        sunColor=Color(80, 80, 128),
        sunBrightness=1,
        sunFlare=0,
        lmColor=Color(64,64,96),
        lmAtten=2,
        saturation=0.6,
        exposure=0.08,
        atmosphereTexture=atmosNightTexture
    }

    local cycles = {
        midNight, blueMorning, sunRise, day, sunSet, blueEvening, night
    }
    
    local bgZone = gRegion:FindFirstTagged(Symbol("BackdropZone"))
    local bgZonePos = Vector()
    if not IsNull(bgZone) then
        bgZonePos = bgZone:GetPosition()
    end
    
    local state = {
        bgZone = bgZone,
        sunFlare = gRegion:FindFirstTagged(Symbol("SunFlare")),
        fogMaterial = fogMaterial,
        skyMaterial = skyMaterial,
        waterMaterial = waterMaterial,
        sunRotation = Rotation(120,-90,0),
        sunLight = sunLight,
        skyboxSunPos = Vector(),
        bgZonePos = bgZonePos,
        flarePos = Vector(),
        postProcess = gRegion:GetLevelInfo().postProcess
    }
    
    if not IsNull(fogMaterial) then
        fogMaterial:AddShaderOption(Symbol("GRADIENT_ATMOSPHERE"))
    end
    
    local curTime = 11--worldHour
    local timeRate = 0--(24 / 60.0 / 60.0) * 10.0 
    local lastCyle = nil
    local skies
    while #skies == 0 do
        Sleep(0)
        skies = gRegion:FindAll(gDynamicSkyType)
    end
    
    while true do
        curTime = curTime + DeltaTime() * timeRate
        if curTime >= 24 then
            curTime = curTime - 24
        end
        
        for i=1, #skies do
            local sky = skies[i]
            if not IsNull(sky) then
                sky:SetTimeOfDay(curTime)
            end
        end
                
        local cycleIdx = 0
        for i=1,#cycles do
            local testCycle = cycles[i]
            if cycles[i].time > curTime then
                break
            end
            cycleIdx = cycleIdx + 1
        end
        
        if cycleIdx == 0 then
            cycleIdx = #cycles
        end
        if cycleIdx > #cycles then
            cycleIdx = 1
        end
        
        local priorCycleIdx = cycleIdx - 1
        if priorCycleIdx == 0 then
            priorCycleIdx = #cycles
        end
        
        local cycle = cycles[cycleIdx]
        local cyclePrior = cycles[priorCycleIdx]
        local blend = Clamp((curTime - cycle.time) / (cycle.blendTime - cycle.time), 0, 1)
        --blend = SmoothStep(blend)
        if cycle ~= lastCyle then
            --print("cycle: " .. cycleIdx .. " prior: " .. priorCycleIdx)
            lastCyle = cycle
        end
        
        --local txt = "cycle: " .. cycleIdx .. " prior: " .. priorCycleIdx .. " blend: " .. blend
        --Broadcast("DayNight: " .. curTime .. " " .. txt)
        
        BlendKeys(cyclePrior, cycle, blend, state, curTime)
        Sleep(0)
    end
end

function DayNightTest()

    local midSunLight = gRegion:FindFirstTagged(Symbol("MidSun"))
    local dawnSunLight = gRegion:FindFirstTagged(Symbol("DawnSun"))
    local duskSunLight = gRegion:FindFirstTagged(Symbol("DuskSun"))
    
    if IsNull(midSunLight) then
        return
    end
    
    midSunLight:TurnOn()
    dawnSunLight:TurnOn()
    duskSunLight:TurnOn()
    duskSunLight:SetBrightness(0.0)
    dawnSunLight:SetColor(Color(255,196,64))
    duskSunLight:SetColor(Color(255,128,64))
    
    local t = 0
    local dir = 0.01
    
    -- midnight
    local midBright = { 0.75, -0.2, 2, 0 }
    local dawnBright = { 0, 0.9, 0, 0 }
    local duskBright = { 0, 0, 0, 0.9 }
    local saturations = { 0.7, 1, 1, 1 }
    local exposures = { 0.05, 0.07, 0.1, 0.07 }
    
    
    local rates = { 0.5, 1, 1, 1 }
    local midColor = { Color(64, 128, 164), Color(0,0,0), Color(255,240,190), Color(0,0,0) }
    local dawnColor= { Color(255,96,64), Color(255,96,64), Color(255,196,64), Color(255,196,64) }
    local duskColor = { Color(255,96,64), Color(255,128,64), Color(255,128,64), Color(255,120,90) }
    local fogColors = { Color(30,30,30), Color(255,96,64), Color(196,196,255), Color(255,128,64) }
    local lightMapColors = { Color(64,64,96), Color(255,128,64), Color(128,128,196), Color(255,128,96) }
    
    local lastIndex = 1
    while true do
    
        t = t + DeltaTime() * dir * rates[lastIndex]
        if t > 1.0 then
            t = t - 1.0
        end
        local index = 1 + t * 4.0
        local nextIndex = math.floor(index) + 1
        if nextIndex > 4 then
            nextIndex = 1
        end
        
        
        
        local v = index - math.floor(index)    
        --v = SmoothStep(v)
        --v = SmoothStep(v)
        v = (v * v)
        
        index = math.floor(index)
        lastIndex = index
        
        SetLight(midSunLight, midBright, midColor, index, nextIndex, v)
        SetLight(dawnSunLight, dawnBright, dawnColor, index, nextIndex, v)
        SetLight(duskSunLight, duskBright, duskColor, index, nextIndex, v)
        
        local levelInfo = gRegion:GetLevelInfo()
        local fogColor = fogColors[index]
        fogColor = fogColor:Lerp(fogColors[nextIndex], v)
        levelInfo.postProcess.fogColor = fogColor
        
        local lmColor = lightMapColors[index]
        lmColor = lmColor:Lerp(lightMapColors[nextIndex], v)
        levelInfo.postProcess.lightMapTint = lmColor

        levelInfo.postProcess.lightMapBoost = 1
        
        levelInfo.postProcess.saturation = Lerp(saturations[index], saturations[nextIndex], v)
        --levelInfo.postProcess.targetExposure = Lerp(exposures[index], exposures[nextIndex], v)
        
        Sleep(0)
    end

end
