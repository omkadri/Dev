primaryCameraSpot = Instance()
cameraSpots = { Instance() }
musicSequencer = Instance()
cameraPanSound = Resource()
monsterSounds = { Resource() }
totalTime = 48.0

local UTIL = require "EE.Interface.Utilities"

local function LerpToCamera(cameraA, cameraB, timing)

    local dt = 1.0 / timing
    
    local startP = cameraA:GetPosition()
    local endP = cameraB:GetPosition()
    
    local startR = cameraA:GetRotation()
    local endR = cameraB:GetRotation()
    
    local startF = cameraA:GetFOV()
    local endF = cameraB:GetFOV()
    
    local t = 0.0
    while t < 1.0 do
        t = t + DeltaTime() * dt
        t = Clamp(t, 0.0, 1.0)
        
        local interpT = t
        interpT = SmoothStep(SmoothStep(interpT))

        local newP = LerpVector(startP, endP, interpT)
        cameraA:SetPosition(newP)
        
        local newR = LerpRotation(startR, endR, interpT)
        cameraA:SetRotation(newR)
        
        local newF = Lerp(startF, endF, interpT)
        cameraA:SetFOV(newF)
        Sleep(0)        
    end

end

function SwitchCameras()
    if not IsNull(musicSequencer) then
        musicSequencer:Enable()
    end

    if IsNull(primaryCameraSpot) or #cameraSpots == 0 then
        return
    end

    local timePer = totalTime / (#cameraSpots) -- about 5 secs
    local camIdx = 1

    local t = 1.25 -- time to transition

    Sleep(16)
    while true and camIdx <= #cameraSpots and not IsNull(gPortraitRegion) do
        --cameraSpots[camIdx]:Activate() won't work in transmission scenes :(
    
        if camIdx > 1 and not IsNull(cameraPanSound) then
            UTIL.PlaySound(cameraPanSound)
        end
        LerpToCamera(primaryCameraSpot, cameraSpots[camIdx], t)
        if camIdx > 1 and camIdx ~= #cameraSpots and not IsNull(monsterSounds[camIdx - 1]) then
            UTIL.PlaySound(monsterSounds[camIdx - 1])
        end
        camIdx = camIdx + 1
        Sleep(timePer - t)
    end

    if not IsNull(musicSequencer) then
        musicSequencer:Disable()
    end
end
