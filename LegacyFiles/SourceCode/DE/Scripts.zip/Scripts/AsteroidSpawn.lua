possibleOrigins = {Instance()}
asteroid = Type()
frequency = 10
multiAvatarTrigger = Instance()

function AsteroidSpawn()
--run while players are still in the area
    local tempArray = possibleOrigins
    local fullArray= {}

    while not multiAvatarTrigger:IsEmpty() do
        if not IsNull(tempArray) then
            if #tempArray <= 0 then
                tempArray = fullArray
                fullArray = {}
            end
            --grab a random origin point
         
            local randomOrigin = SRandomInt(1, #tempArray)
            local origin = tempArray[randomOrigin]
            table.insert(fullArray, tempArray[randomOrigin])
            table.remove(tempArray, randomOrigin)
--~             
--~             local dd = Engine.DamageData()
--~             dd:SetImpulse(Vector(10000, 0, 0))
            --spawn asteroid projectile every (x) seconds
            local ast = gRegion:CreateEntity(asteroid, origin:GetPosition(), origin:GetRotation())
--~             Sleep(0)
--~             ast:DamageDD(dd)
            
        end
        Sleep(frequency)
    end
    
    
end

function CollideCheck(asteroid)
    

end