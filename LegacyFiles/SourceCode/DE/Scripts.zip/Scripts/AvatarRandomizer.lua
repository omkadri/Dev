--TintTable = {Resource()}
HeadTable = {Type()}
AttachmentTable = {Type()}
overrideMaterial = Resource()
attachedEffect = Type()

function RandomizeAvatar(avatar)
    local head = RandomInt(1, #HeadTable)
    local attachment = RandomInt(1, #AttachmentTable)

    --if #TintTable ~= 0 then
    --  if RandomInt(1,#TintTable) ~= 0 then --default mesh has a texture
    --      avatar:SetOverrideMaterial(0, TintTable[tint])
    --  end
    --end
    
    if #HeadTable ~= 0 then
        avatar:Attach(HeadTable[head], EMPTY_SYMBOL)
    end

    if #AttachmentTable ~= 0 then
        avatar:Attach(AttachmentTable[attachment], EMPTY_SYMBOL)
    end

    Sleep(0)
    
    if not IsNull(overrideMaterial) then
        avatar:SetOverrideMaterialForAllSections(overrideMaterial, true)
    end
    if not IsNull(attachedEffect) then
        avatar:Attach(attachedEffect, EMPTY_SYMBOL)
    end
end

