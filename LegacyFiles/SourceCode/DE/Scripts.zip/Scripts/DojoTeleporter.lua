genericMenuMovie = Resource()
inWorldText = Resource()
teleportEffect = Type()
teleportSound = Resource()

local mChildMovie = nil
local mWorldTextMovie = nil

local UTIL = require "EE.Interface.Utilities"

local function Fade(instigator, changeTime, finalValue)
    Sleep(0.01)
--  local postProcess = playerAvatar:CameraControl():GetPostProcessInfo()
    local postProcess = gRegion:GetLevelInfo().postProcess
    local startFade = postProcess.fade

    if changeTime == 0 then
        postProcess.fade = finalValue
        Sleep(0)
        return
    end
    
    local t = 0
    local val
    
    while t < 1 do
        val = Lerp(startFade, finalValue, t)
        postProcess.fade = val
        t = t + DeltaTime() / changeTime
        Sleep(0)
    end
    
    postProcess.fade = finalValue
    Sleep(0)
end

function ActivateTeleport(action, avatar)
    if not avatar:ReplicaLocallyControlled() then
        return
    end

    local decoParent = gRegion:FindNearest(gDojoPlaceableDecorationType, action:GetPosition())
    if IsNull(decoParent) then
        return
    end

    local numTeleporters = 0
    local teleporters = {}
    local choseTeleporter = false
    for roomId, room in pairs (_T.DojoMgr.mIdToZoneMap) do
        for decoId, deco in pairs(_T.DojoMgr.mIdToPlacedDecos[roomId]) do
            if deco:IsFinished() and deco:GetName() ~= "" then
                teleporters[deco:GetName()] = deco
                numTeleporters = numTeleporters + 1
            end
        end
    end

    if numTeleporters == 1 then
        UTIL.ShowMessage("/Lotus/Language/Dojo/NeedMoreTeleporters")
        return
    end

    local teleporterName = decoParent:GetName()
    if teleporterName == "" then
        -- Shouldn't be possible, since these are named during placement
        return
    end
    
    mChildMovie = gFlashMgr:GotoMovie(genericMenuMovie)
    mChildMovie:Execute("SetTitle", "/Lotus/Language/Dojo/ChooseTeleporter")

    local teleportTo = nil

    _T.MenuSelectionDone =
        function(pElements)
            if pElements[1] ~= nil then
                teleportTo = teleporters[pElements[1].mName]
            end

            choseTeleporter = true
        end

    mChildMovie:Execute("SetCallBack", "MenuSelectionDone")

    local sortFunc = function(a, b)
            return(a.mName < b.mName)
        end

    _T.GetMenuEntries =
        function()
            local menuEntries = {}
            for name, deco in pairs(teleporters) do
                if name ~= teleporterName then
                    table.insert(menuEntries, { mName = name})
                end
            end

            table.sort(menuEntries, sortFunc)
            return(menuEntries)
        end

    mChildMovie:Execute("SetElementsFunction", "GetMenuEntries")

    while not choseTeleporter do
        if not IsNull(avatar) and not avatar:ReplicaLocallyControlled() then
            mChildMovie:Close()
            return
        end
        -- Hacks!
        Sleep(0)
    end

    if not IsNull(teleportTo) then
        avatar:PlaySound(teleportSound, false)
        gRegion:CreateEntity(teleportEffect, avatar:GetSimPosition(), ZERO_ROTATION)
        Fade(avatar, .25, 1)

        local rot = teleportTo:GetSimRotation()
        rot.heading = rot.heading - 180

        avatar:Teleport(teleportTo:GetSimPosition(), rot)
        avatar:SetCameraView(rot)
        
        gRegion:CreateEntity(teleportEffect, teleportTo:GetSimPosition(), ZERO_ROTATION)
        Fade(avatar, .25, 0)
    end
end

function SetDialogTriggerText(trigger)
    repeat
        --SetLiteMode will try to use this colour, but it will be Null at first. Also we need to wait at least one frame for the deco's name to be set
        Sleep(0)
    until not IsNull(_G.UIColor_DarkGrey)

    local decoParent = nil
    repeat
        Sleep(0)
        decoParent = gRegion:FindNearest(gDojoPlaceableDecorationType, trigger:GetPosition())
    until not IsNull(decoParent) and decoParent:DistanceToEntity(trigger) < 1  -- Distance check is a hack to ensure we found the right deco

    if not IsNull(decoParent) and decoParent:GetName() ~= "" then
        mWorldTextMovie = gFlashMgr:GotoMovie(inWorldText)
        if not IsNull(mWorldTextMovie) then
            mWorldTextMovie:Execute("SetMessage", decoParent:GetName())
            mWorldTextMovie:AttachToEntity(decoParent, Vector(0, 1.35, .65), Rotation(180, 0, 0), Vector(1, 1, 1))

            mWorldTextMovie:Execute("SetLiteMode", "true")
            mWorldTextMovie:Execute("SetUserText", "")
        end
    end
end
