glowDecoFx = Type("/Lotus/Fx/Levels/ClanDojo/MasteryAltarGlowDeco")
rankUpFx = Type("/Lotus/Fx/Levels/ClanDojo/MasteryAltarRankUp")
activateAnim = Resource("/Lotus/Objects/Tenno/Props/TnoClanMasteryAltarActivate_anim.fbx")
activeLoopAnim = Resource("/Lotus/Objects/Tenno/Props/TnoClanMasteryAltarActiveCycle_anim.fbx")
closedLoopAnim = Resource("/Lotus/Objects/Tenno/Props/TnoClanMasteryAltarClosed_anim.fbx")
deactivateAnim = Resource("/Lotus/Objects/Tenno/Props/TnoClanMasteryAltarDeactivate_anim.fbx")
emblemBackerMaterialOn = Resource("/Lotus/Objects/Tenno/Props/TnoClanMasteryEmblemBacker")
emblemBackerMaterialOff = Resource("/Lotus/Objects/Tenno/Props/TnoClanMasteryEmblemBackerOff")

local mGameRules = nil
local mGameData = nil
local mDeco = nil
local mGlowFx = nil

local mPrevState = {CanRankUp  = false, Active = false}
local mCurrentState = {CanRankUp = false, Active = false}

local function ToggleGlowDeco(active)
    if active then
        mGlowFx = mDeco:Attach(glowDecoFx, EMPTY_SYMBOL)
    else
        mGlowFx:Unattach()
        mGlowFx:Destroy()
        mGlowFx = nil
    end
end

local function DoRankUpEffect()
    mDeco:Attach(rankUpFx, EMPTY_SYMBOL, Vector(0, 2, 0))
end

local function ActiveStateChanged(active)
    if active then
        mDeco:PlayAnimation(activateAnim, true, false)
        mDeco:PlayAnimation(activeLoopAnim, false, true)
        mDeco:SetOverrideMaterial(0, emblemBackerMaterialOn)
        ToggleGlowDeco(active)
    else
        ToggleGlowDeco(active)
        mDeco:PlayAnimation(deactivateAnim, true, false)
        mDeco:PlayAnimation(closedLoopAnim, false, true)
        mDeco:SetOverrideMaterial(0, emblemBackerMaterialOff)
    end
end

local function Update()

    -- Possible when going dojo->mission
    if IsNull(mGameRules) then
        Sleep(1)
        return
    end

    mCurrentState.Active = mGameRules:CanContribute()
    mCurrentState.CanRankUp = mGameRules:CanIncreaseGuildClass()
    if mCurrentState.Active ~= mPrevState.Active then
        ActiveStateChanged(mCurrentState.Active)
        mPrevState.Active = mCurrentState.Active
    end
    if mCurrentState.CanRankUp ~= mPrevState.CanRankUp then
        if not mCurrentState.CanRankUp then
            DoRankUpEffect()
        end
        mPrevState.CanRankUp = mCurrentState.CanRankUp
    end
    Sleep(0.25)
end

function Start(deco)
    mGameRules = gGameRules
    if mGameRules:IsA(gLotusDojoGameRulesType) then
        mGameData = gPlayerProfileMgr:GetPlayerProfile(0):GetGameSpecificData()
    end
    mDeco = deco
    if not IsNull(mGameData) and not IsNull(mDeco) then
        mDeco:SetOverrideMaterial(0, emblemBackerMaterialOff)

        mCurrentState.CanRankUp = mGameRules:CanIncreaseGuildClass()
        mCurrentState.Active = mGameRules:CanContribute()
        mDeco:PlayAnimation(closedLoopAnim, false, true)
        while true do
            Update()
        end
    end
end