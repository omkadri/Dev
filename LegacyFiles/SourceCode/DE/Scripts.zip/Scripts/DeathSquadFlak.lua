damagePerSecond = 10

local sentinelMinEmbedTime = .25
local sentinelMaxEmbedTime = .75

local LEECH_SHAKE = Symbol("LeechShake")

function OnAttached(projectile)
    if gRegion:IsMaster() then
        local victim = projectile:GetAttachParent()

        if not IsNull(victim) and victim:IsA(gBaseAvatarType) then
            projectile:Destroy()
            local isSentinel = victim:IsA(gLotusSentinelAvatarType)
            local isEnemy = victim:IsA(gLotusNpcAvatarType)
            local damage = 0
            local embedTime = 0
            local embedDuration = Random(sentinelMinEmbedTime, sentinelMaxEmbedTime) -- Used for Sentinels

            while not IsNull(victim) and not victim:IsKilled() do
                
                if isEnemy then
                    projectile:Destroy()
                end
                
                local dt = DeltaTime()
                if victim:IsPlayingAnimAction(Engine.FBA_ROLL) or victim:InventoryControl():IsMeleeing() then
                    projectile:Destroy()
                    --projectile:Unattach()
                else
                    damage = damage + dt * damagePerSecond
                    if damage > 1 then
                        local r = math.fmod(damage, 1.0)
                        victim:DamageEx(damage, Engine.DT_SHIELD_DRAIN, Engine.ANY_PART, 0, projectile:GetInstigator(), projectile)
                        damage = r
                    end
                end

                if isSentinel then
                    if victim:IsPlayingAbilityReactionAnim(LEECH_SHAKE) then
                        Sleep(.2)
                        projectile:Destroy()
                        --projectile:Unattach()
                        break
                    end

                    embedTime = embedTime + dt
                    if embedTime >= embedDuration then
                        local anim = victim:PlayAbilityReactionAnim(LEECH_SHAKE, false, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_ONCE, true)
                        if not IsNull(anim) then
                            victim:SuspendScriptUntilAnimEvent("ShakeOff", 2.5)   -- PlayAbilityReactionAnim doesn't return time, so just hardcode the timeout
                        else
                            Sleep(.5)
                        end

                        projectile:Destroy()
                        --projectile:Unattach()
                        break
                    end
                end

                Sleep(0)
            end
        end
    end
end