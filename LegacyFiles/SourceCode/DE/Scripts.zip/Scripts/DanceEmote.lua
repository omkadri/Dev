stepSequencerType = Type()
trailType = Type()

local SEQUENCER_UTIL = require "Lotus.Interface.SequencerUtilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local bardType = WeakResource("/Lotus/Powersuits/Bard/Bard")
local musicVolumeType = WeakResource("/Lotus/Objects/Gameplay/OctaviaMusicVolume")

local mStepSequencer = nil
local trails = {}

function EMO_START(avatar)
    if IsNull(avatar) then
        return
    end
    
    if IsNull(stepSequencerType) then
        return
    end
    
    local suit = avatar:InventoryControl():GetActivePowerSuit()
    if IsNull(suit) or not suit:IsA(bardType) then
        return
    end
    
    -- Only play in the dojo and designated spots in hubs
    local uiMode = LOTUS_UTIL.GetUIMode()
    if uiMode == LOTUS_UTIL.UI_MODE_IN_SPACE_HUB then
        local pos = avatar:GetPosition()
        local inVolume = false
        local musicVolumes = gRegion:FindAll(musicVolumeType)
        for i, volume in ipairs(musicVolumes) do
            if volume:IsInsideBox(pos) then
                inVolume = true
                break
            end
        end
        
        if not inVolume then
            return
        end
    elseif uiMode ~= LOTUS_UTIL.UI_MODE_IN_DOJO then
        return
    end
    
    mStepSequencer = gRegion:CreateEntity(stepSequencerType, avatar:GetPosition(), ZERO_ROTATION, avatar, avatar)
    if not IsNull(mStepSequencer) then
        local css = suit:GetCustomization():GetSong(0)
        for i = 0, Lotus_Game.MAX_NoteType do
            if css:HasNotePack(i) then
                mStepSequencer:SetNotePack(i, Resource(css:GetNotePack(i)))
            end
        end
        
        if css.mHasFingerPrint then
            mStepSequencer:DecodeFingerPrint(css.mFingerPrint)
        else
            mStepSequencer:DecodeFingerPrint(mStepSequencer:GetDefaultFingerPrint())
        end
        
        SEQUENCER_UTIL.SyncSequencer(mStepSequencer)
        
        local trail = avatar:Attach(trailType, Symbol("GAME_L1_WEAPON1"), ZERO_VECTOR, ZERO_ROTATION, avatar)
        trail:Enable()
        table.insert(trails, trail)
        
        trail = avatar:Attach(trailType, Symbol("GAME_R1_WEAPON1"), ZERO_VECTOR, ZERO_ROTATION, avatar)
        trail:Enable()
        table.insert(trails, trail)
    end
end

function EMO_LOOP(avatar, emoteType)
    local pos = avatar:GetPosition()
    while not IsNull(mStepSequencer) do
        if IsNull(avatar) or avatar:GetCurrentEmote() ~= emoteType or avatar:DistanceToPoint(pos) > 5 then
            mStepSequencer:Destroy()
            break
        end
        
        Sleep(0.25)
    end
end

function EMO_END(avatar)
    if not IsNull(mStepSequencer) then
        mStepSequencer:Destroy()
    end
    
    for i, trail in ipairs(trails) do
        if not IsNull(trail) then
            trail:Destroy()
        end
    end
end