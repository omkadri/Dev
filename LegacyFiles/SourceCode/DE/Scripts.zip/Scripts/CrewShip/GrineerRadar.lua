noiseDecos = {Instance()}
hideDecos = {Instance()}
showDecos = {Instance()}
destroyDecos = {Instance()}

function StartNoise() --OnLevelStarted, position battery+beam, spawn reward
    if #noiseDecos == 0 then
        return
    end
    
    Broadcast("Ouch")
    
    for i = 1, #noiseDecos do
        if not IsNull(noiseDecos[i]) then
            noiseDecos[i]:SetNoiseEnable(true)
        end
    end
end

function StopNoise() --OnLevelStarted, position battery+beam, spawn reward
    if #noiseDecos == 0 then
        return
    end
        
    for i = 1, #noiseDecos do
        if not IsNull(noiseDecos[i]) then
            noiseDecos[i]:SetNoiseEnable(false)
        end
    end
end

function SwapDecorations()
    if #hideDecos == 0 and #showDecos == 0 then
        return
    end

    for i = 1, #hideDecos do
        if not IsNull(hideDecos[i]) then
            hideDecos[i]:SetVisibility(false)
        end
    end
    
    for i = 1, #showDecos do
        if not IsNull(showDecos[i]) then
            showDecos[i]:SetVisibility(true)
        end
    end

end

function AnnihilateDecorations()
    if #destroyDecos == 0 then
        return
    end

    for i = 1, #destroyDecos do
        if not IsNull(destroyDecos[i]) then
            destroyDecos[i]:Destroy()
            Sleep(0.15)
        end
    end

end