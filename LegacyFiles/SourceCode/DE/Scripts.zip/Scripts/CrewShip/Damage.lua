impactSound = Resource()
stumbleAnims = {Resource()}
shakeTime = 2
crpBoardingTimer = 10
maxScreenShake = 12
transDelay = 4
superWeaponType = Type()
fighterType = Type()
local viewShakeSpeed = 2

squibsPerSecond = 25
maxSequentialSquibs = 25

shakesPerSecond = 15
maxSequentialShakes = 15

hullTransmissionSet = Resource()
hullTag = Symbol()

brdTransmissionSet = Resource()
brdTag = Symbol()

fighterTransmissionSet = Resource()
fighterTag = Symbol()

local UTIL = require "EE.Interface.Utilities"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"

--Malfunctions--
local mChanceOfBreachOnHit = 0.1
local mChanceOfElectricityOnHit = 0.05
local mChanceOfFireOnHit = 0.05
local mChanceOfIceOnHit = 0.05

local secondsBetweenFires = Range(15, 60)
local secondsBetweenElectricity = Range(15, 60)
local secondsBetweenIce = Range(15, 60)
local secondsBetweenBreaches = Range(15, 60)
local secondsBetweenBase = Range(30, 60)
local secondsBetweenThrottle = Range (15, 60)

--------------

local function GiveTransmissionFromSet(transmissionSet, tag)
    if gRegion:IsMaster() then
        DIALOG.PlayLocalTransmission(transmissionSet, tag, 0, gRegion:GetLocalPlayerAvatar())
    end
end

local function NewRateLimiter(ratePerSecond, startingAllowance, maxAllowance)
    local limiter = {}
    limiter.lastTime = Time()
    limiter.ratePerSecond = ratePerSecond    
    limiter.allowance = startingAllowance    
    limiter.maxAllowance = maxAllowance
    
    return limiter
end

local function UpdateRateLimiter(limiter)
    local currentTime = Time()
    local elapsedTime = currentTime - limiter.lastTime
    limiter.lastTime = currentTime
    
    limiter.allowance = limiter.allowance + (elapsedTime * limiter.ratePerSecond)
    
    if limiter.allowance > limiter.maxAllowance then
        limiter.allowance = limiter.maxAllowance
    end
end

local function ConsumeLimiterAllowance(limiter, amount)
    limiter.allowance = limiter.allowance - amount
end

local function LimiterHasAllowance(limiter)

    UpdateRateLimiter(limiter)
    --return(limiter.allowance > 1)
    return(true)
end

local function SpawnSquib(numToBurst)
    local squibSpawners = gRegion:FindTaggedInRadius(Symbol("RailJackExplosionSquib"), gRegion:GetGameCamera():GetPosition(), 0, 25) 
    if not squibSpawners or #squibSpawners == 0 then
        return
    end
    
    for i=1, numToBurst do
        local squib = squibSpawners[RandomInt(1, #squibSpawners)]
        local spawnerType = WeakResource("/EE/Types/Effects/Spawner")
        if squib:IsA(spawnerType) or squib:IsA(gParticleSysType) then
            squib:FirePort("Burst")
        end
    end
end

local function FindSpawner(tag)
    if IsNull(_T.MalfunctionSpawners) then
        _T.MalfunctionSpawners = {}
    end
    if IsNull(_T.MalfunctionSpawners[tag]) then
        local spawner = gRegion:FindFirstTagged(tag)
        if not IsNull(spawner) then
            _T.MalfunctionSpawners[tag] = spawner
            return _T.MalfunctionSpawners[tag]
        end
    else
        return _T.MalfunctionSpawners[tag]
    end
    
    return nil
end

local function throttleScale()
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
   
    local level = 1
    if not IsNull(aiDir) then
        level = aiDir:GetSpaceMaxEnemyLevel()
    end
    if level < 10 then
        secondsBetweenThrottle = Range(30, 90)
        
    elseif level > 30 then 
        secondsBetweenThrottle = Range(5, 45)
        
    end
    
    return(secondsBetweenThrottle:Rand())
end

local function SpawnMalfunction(scriptDamageData)
    if not IsNull(scriptDamageData) then
        local reactToDamageTypes = {Engine.DT_FIRE, Engine.DT_FREEZE, Engine.DT_ELECTRICITY}
        local matchingDamageTypes = {}
        for i, damType in ipairs(reactToDamageTypes) do
            if scriptDamageData:Matches(damType) then
                table.insert(matchingDamageTypes, damType)
            end
        end
        
        local t = Time()
        local spawner = nil
        
        if IsNull(_T.chanceOfBreachHitAttenuator) then
            _T.chanceOfBreachHitAttenuator = 1
        end

        if #matchingDamageTypes > 0 then
            local damageTypeToUse = matchingDamageTypes[math.random(#matchingDamageTypes)]
            if damageTypeToUse == Engine.DT_FIRE and _T.RJFireThrottle <= t and FRand() <= mChanceOfFireOnHit then
                spawner = FindSpawner(Symbol("FireSpawner"))
                _T.RJFireThrottle = t + throttleScale()
            elseif damageTypeToUse == Engine.DT_ELECTRICITY and _T.RJElectricityThrottle <= t and FRand() <= mChanceOfElectricityOnHit then
                spawner = FindSpawner(Symbol("FireSpawner"))
                _T.RJElectricityThrottle = t + throttleScale() 
            elseif damageTypeToUse == Engine.DT_FREEZE and _T.RJIceThrottle <= t and FRand() <= mChanceOfIceOnHit then
                spawner = FindSpawner(Symbol("IceSpawner"))
                _T.RJIceThrottle = t + throttleScale()
            end

            if not IsNull(spawner) then
                spawner:Spawn(damageTypeToUse, scriptDamageData:GetHitProxy())
            end
        elseif _T.RJBreachThrottle <= t and FRand() <= (mChanceOfBreachOnHit * _T.chanceOfBreachHitAttenuator) then
            spawner = FindSpawner(Symbol("BreachSpawner"))
            if not IsNull(spawner) then
                spawner:Spawn()
                _T.RJBreachThrottle = t + throttleScale()
                gChallengeMgr:NotifyTag(gRegion:GetLocalPlayer(), Symbol("RAILJACK_BREACH"))
            end
        end
    end
end

local function norm(val, max, min) 
    --return (val - min) / (max - min)
    return math.max(0, math.min(1, (val-min) / (max-min)))
end

local function ShakeView(shakeAmount, damagedShip)
    local levelInfo = gRegion:GetLevelInfo()
    levelInfo.postProcess.viewShake.mShakeSpeed = viewShakeSpeed
    local curShakeAmount = levelInfo.postProcess.viewShake.mShakeAmbient  
    local t = 1  
    
   
    local lerpamount = norm(shakeAmount, 1000, 0 )
    local viewShake = Lerp(5, 15, lerpamount) + curShakeAmount
    shakeTime = Lerp(0.5, 1, lerpamount)
    if not IsNull(viewShake) and viewShake > maxScreenShake then
        viewShake = maxScreenShake
    end

    local player = gRegion:GetLocalPlayerAvatar()
    local localPlayerShip = nil
    if not IsNull(player) then
        localPlayerShip = player:InventoryControl():GetOnBoardShip()
    end

    if not IsNull(player) and not player:IsKilled() and not player:HasPostureModifier(Engine.PM_AIRBORNE) and damagedShip == localPlayerShip then
        if
            not player:HasPostureModifier(Engine.PM_EMPLACEMENT) and
            not player:HasPostureModifier(Engine.PM_IN_AIR) and
            viewShake > 10 and
            RandomInt(1,20) >= 20
        then
            player:PlayAnimation(stumbleAnims[RandomInt(1, #stumbleAnims)], false, Engine.ATMM_ANIMATION_DRIVEN)
        end
        
        player:PlaySound(impactSound, false, 0, false) 
        while t > 0 do
            levelInfo.postProcess.viewShake.mShakeAmbient = t * viewShake
            levelInfo.postProcess.viewShake.mShakeSpeed = t  * viewShakeSpeed
            t = t - (1/shakeTime) * DeltaTime()
            Sleep(0)
        end
    end
    levelInfo.postProcess.viewShake.mShakeAmbient = 0
    levelInfo.postProcess.viewShake.mShakeSpeed = 0
end

local function HasShields(damagedShipAvatar)
    local shields = 0
    if not IsNull(damagedShipAvatar) then
        local damageController = damagedShipAvatar:DamageControl()
        if not IsNull(damageController) and damageController:IsA(gCrewShipDamageControllerType)  then
            shields = damageController:GetShield()
        end
    end

    return (shields > 0)
end

local function DamageIsInvalid(entity, source)
    return ( 
        IsNull(source) or
        HasShields(entity) or
        _T.EnableRailJackDamageResponse == false)
end

local function initialScale()
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    local scale = 1
    local level = 1
    if not IsNull(aiDir) then
        level = aiDir:GetSpaceMaxEnemyLevel()
    end
    if level < 15 then
        scale =  secondsBetweenBase:Rand()
    end
    return(scale)
end


function OnDamaged(entity, scriptDamageData)
    local source = scriptDamageData:GetSource()
    
    if DamageIsInvalid(entity, source) then
        return
    end

    entity:PlaySound(impactSound, false, 0, false) 
    
    if _T.HullPlayed == false then
        if not IsNull(source) then
            if source:IsA(fighterType) then
                GiveTransmissionFromSet(hullTransmissionSet, hullTag)
                _T.HullPlayed = true 
            end
        end
    end
   
    
    if not _T.RJFireThrottle then
        _T.RJFireThrottle = Time() +  initialScale()
    end
    if not _T.RJElectricityThrottle then
        _T.RJElectricityThrottle = Time() +  initialScale()
    end    
    if not _T.RJIceThrottle then
        _T.RJIceThrottle = Time() + initialScale()
    end
    if not _T.RJBreachThrottle then
        _T.RJBreachThrottle = Time() +  initialScale()
    end
    
    local damagedShip = entity:InventoryControl():GetActivePowerSuit()
    if gRegion:IsMaster() then
        SpawnMalfunction(scriptDamageData)
    end

    local hitBySuperWeapon = (not IsNull(source)) and source:IsA(superWeaponType)
    
    if IsNull(_T.SquibRateLimiter) then
        _T.SquibRateLimiter = NewRateLimiter(squibsPerSecond, maxSequentialSquibs, maxSequentialSquibs)
    end
    if LimiterHasAllowance(_T.SquibRateLimiter) then
        local usedSquib = false
        if RandomInt(1,2) >= 2 then
            SpawnSquib(2)
            usedSquib = true
        end
        
        if hitBySuperWeapon then
            SpawnSquib(3)
            usedSquib = true
        end
        
        if usedSquib then
            ConsumeLimiterAllowance(_T.SquibRateLimiter, 1.0)
        end
    end
        
    if IsNull(_T.ShakeRateLimiter) then
        _T.ShakeRateLimiter = NewRateLimiter(shakesPerSecond, maxSequentialShakes, maxSequentialShakes)
    end        
    if LimiterHasAllowance(_T.ShakeRateLimiter) then
        local shakeAmount = UTIL.Ternary(hitBySuperWeapon, 15, scriptDamageData:GetAmount())
        ShakeView(shakeAmount, damagedShip)
        ConsumeLimiterAllowance(_T.ShakeRateLimiter, 1.0)
    end
end

function CorpusBoarding()
    Sleep(math.max(crpBoardingTimer - 6, 0))
    GiveTransmissionFromSet(brdTransmissionSet, Symbol("NefBoardingPods"))
    Sleep(10)
    local crpSciptTriggers = gRegion:FindTagged(Symbol("TennoConBoardingActivate"))
    if not IsNull(crpSciptTriggers) then
        for x=1,#crpSciptTriggers do
            crpSciptTriggers[x]:FirePort("TriggerPort")
            GiveTransmissionFromSet(brdTransmissionSet, brdTag)
        end
    end
end

function SimpleTrans()
    Sleep(transDelay)
    GiveTransmissionFromSet(fighterTransmissionSet, fighterTag)
    if not _T.HullPlayed then
        _T.HullPlayed = false
    end
end

function EnableRailJackDamageResponse()
    _T.EnableRailJackDamageResponse = true
end
