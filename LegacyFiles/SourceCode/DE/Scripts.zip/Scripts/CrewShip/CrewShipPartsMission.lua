jammingDroneAgent = Type()
jammingDroneAvatar = WeakResource()
jammingDronesSpawnedSound = Resource()
sentientAgents = {Type()}
activeRingType = Type()
areaMarkerType = Type()
captureCompleteSound = Resource()
beaconActivateEffect = Type()
tickingSound = Resource()
stepBackInSound = Resource()

sentientThresholds = {0.0}
sentientCounts = {1}
enemyCountMultiplier = 1.0
stageThresholds = {0.3, 0.6, 0.85}
stageDroneCounts = {2, 3, 5}

local doNotUseTag = Symbol("DoNotUse")
local tennoFaction = Symbol("TENNO")
local defendTime = 60

local mObjectiveDeco
local mSpawnPoints
local mDroneSpawnPointMaxIndex = 1

local SPAWN = require "Lotus.Scripts.Libs.EndlessSpawnLib"
local GAMEMODE = require "Lotus.Scripts.Libs.CommonGamemodeFunctions"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local MODE = require "Lotus.Scripts.Libs.CommonGamemodeFunctions"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"


function DefendObjective(captureArea, instigator)
    if IsNull(instigator) or not instigator:IsA(gTennoAvatarType) then
        return
    end

    if captureArea:GetState() > 0 then
        return
    end
    captureArea:SetState(1)
    captureArea:Attach(activeRingType, EMPTY_SYMBOL, Vector(0, -44, 0), ZERO_ROTATION)
    
    DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("CaptureStart"))

    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    aiDir:OrderNpcsStormTarget(captureArea, 3)
    aiDir:SetEnableAutoSpawns(false, captureArea)
    aiDir:SetFactionAllies(Symbol("Corpus"), Symbol("Sentient"))
    aiDir:SetFactionAllies(Symbol("Grineer"), Symbol("Sentient"))
    aiDir:SetAllowLockDown(false)

    mObjectiveDeco = gRegion:FindFirstTagged(Symbol("CrewShipPartDeco"))
    mSpawnPoints = gRegion:FindAll(gNpcSpawnPointType)
    for i=#mSpawnPoints,1,-1 do
        if aiDir:GetDistanceToObjective(mSpawnPoints[i]) < 30 or mSpawnPoints[i]:HasTag(doNotUseTag) then
            table.remove(mSpawnPoints, i)
        end
    end
    table.sort(mSpawnPoints, function(a, b) return aiDir:GetDistanceToObjective(a) < aiDir:GetDistanceToObjective(b) end)
    mDroneSpawnPointMaxIndex = #mSpawnPoints
    for i=#mSpawnPoints,1,-1 do
        if aiDir:GetDistanceToObjective(mSpawnPoints[i]) < 150 then
            mDroneSpawnPointMaxIndex = i
            break
        end
    end

    stageThresholds = _T.RJHuntStageThresholds or stageThresholds
    stageDroneCounts = _T.RJHuntStageDroneCounts or stageDroneCounts
    sentientThresholds = _T.SentientStageThresholds or {}
    sentientCounts = _T.SentientStageCounts or {}
    enemyCountMultiplier = _T.RJHuntEnemyCountMultiplier or 1

    local stage = 1
    local sentientStage = 1
    local blockingMsg = false
    local captureProgress = 0
    local lastJammingDroneCount = 0
    local npcHardCap = aiDir:GetNpcHardCap()
    local minLevel = aiDir:GetMinEnemyLevel()
    local maxLevel = aiDir:GetMaxEnemyLevel()
    local minNumEnemies = {12, 15, 25, 30}
    local maxNumEnemies = {20, 25, 30, 35}
    local enemyData = {}
    --enemyData.maxSpawnCount = 1
    --enemyData.customDebugLabel = "[RailjackHunt]"
    enemyData.eximusChance = 0

    OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/CaptureRailjackPartCapture", 5)
    OBJTXT.SetObjProgressBar("/Lotus/Language/Railjack/CaptureRailjackPartProgress", 0, 100, nil, true)
    local areaMarker = MODE.CreateAreaMarker(areaMarkerType, captureArea:GetPosition(), 12)

    local stayInAreaTransmissionReady = true
    local stayInAreaTransmissionCooldown = 0
    local enemyBlockingTransmissionReady = true
    local enemyBlockingTransmissionCooldown = 0

    SPAWN.SetupReinforcements(30, 200, true, aiDir, 0, 2)
    aiDir:SetAllowTeleportDistToEndThreshold(0.0) --allow paused agents to teleport to active areas from anywhere in the map
    aiDir:SetLevelAlert(true)
    aiDir:SetMaxEnhancedAgents(0) -- Don't auto spawn leaders
    aiDir:SetAllowLevelAlerts(false)
    aiDir:SetCustomSpawnSource(captureArea)
    
    local spawnTime = 0.5
    
    -- Play transmission
    while captureProgress < 1 do
        Sleep(0)

        if IsNull(gGameRules) then
            return
        end

        local lastProgress = captureProgress

        spawnTime = spawnTime - DeltaTime()
        if spawnTime < 0 then
            local playerCount = Clamp(gRegion:GetHumanPlayerAvatarCount(), 1, 4)
            enemyData.level = math.floor(Lerp(minLevel, maxLevel, captureProgress))
            SPAWN.SpawnReinforcements(0.5, math.floor(enemyCountMultiplier * math.min(npcHardCap, Lerp(minNumEnemies[playerCount], maxNumEnemies[playerCount], captureProgress))), enemyData)
            spawnTime = 0.5
            
            local currentTier = aiDir:GetCurrentTier()
            local scaledTier = math.min( math.floor(Lerp(0, 5, (captureProgress / 0.75))), 1)
            if currentTier ~= scaledTier then
                aiDir:SetCurrentTier(scaledTier)
            end
        end

        OBJTXT.UpdateObjProgressBarPct(math.floor(0.5 + captureProgress * 100), 100)

        local playerAvatar = gRegion:GetLocalPlayerAvatar()
        local lastBlockingMsg = blockingMsg
        blockingMsg = nil
        local blocked = false
        local friendliesInside = 0
        local playerInside = true

        local touchingEntities = captureArea:GetEntitiesTouching()
        for j=1,#touchingEntities do
            local e = touchingEntities[j]
            if e:IsA(gTennoAvatarType) then
                friendliesInside = friendliesInside + 1
                if e == playerAvatar then
                    playerInside = true
                end
            end
            
            local agent = e:GetAgent()
            if (IsNull(agent) or not agent:IsA(jammingDroneAgent)) and not e:IsFactionFriendly(tennoFaction) then
                blocked = true
            end
        end

        local jammingDroneCount = aiDir:CountAvatarsByType(jammingDroneAvatar)
        if lastJammingDroneCount ~= jammingDroneCount then
            if stageDroneCounts[stage - 1] then
                if not IsNull(areaMarker) then
                    areaMarker:Destroy()
                end
                OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/DestroyJammingDrones", 2, ": " .. (stageDroneCounts[stage - 1] - jammingDroneCount) .. " / " .. stageDroneCounts[stage - 1])
                _T.ObjProgressBar.SetLabel("/Lotus/Language/Railjack/DestroyJammingDronesJammed", 1)
                OBJTXT.SetObjProgressBarColor(Color(119,119,119))
            end
            if jammingDroneCount == 0 then
                DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("DronesDestroyed"))
                captureArea:Attach(activeRingType, EMPTY_SYMBOL, Vector(0, -44, 0))
                areaMarker = MODE.CreateAreaMarker(areaMarkerType, captureArea:GetPosition(), 12)
                OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/CaptureRailjackPartCapture", 5)
                _T.ObjProgressBar.SetLabel("/Lotus/Language/Railjack/CaptureRailjackPartProgress", 1)
                OBJTXT.SetObjProgressBarColor(Color(255,255,255))
            end
        end
        lastJammingDroneCount = jammingDroneCount

        if jammingDroneCount == 0 then
            if blocked then
                if enemyBlockingTransmissionReady then
                    local currentTime = gGameRules:GetTruncatedWorldTimeSecs()
                    if enemyBlockingTransmissionCooldown < currentTime then
                        DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("EnemyBlocking"))
                        enemyBlockingTransmissionCooldown = currentTime + 30
                        enemyBlockingTransmissionReady = false
                    end
                end
            else
                if friendliesInside > 0 then
                    if not stayInAreaTransmissionReady then
                        captureArea:PlaySound(stepBackInSound, false, Engine.SP_VERY_LOW, true, nil)
                    end
                    stayInAreaTransmissionReady = true
                    enemyBlockingTransmissionReady = true
                    captureProgress = captureProgress + (DeltaTime() / defendTime) * friendliesInside
                    if captureProgress >= 1.0 then
                        if not IsNull(captureArea) then
                            local ring = captureArea:GetAttachment(activeRingType)
                            if not IsNull(ring) then
                                ring:PlayTriggeredFade(true)
                            end
                            if not IsNull(areaMarker) then
                                areaMarker:Destroy()
                            end
                        end
                    end
                elseif stayInAreaTransmissionReady then
                    stayInAreaTransmissionReady = false
                    local currentTime = gGameRules:GetTruncatedWorldTimeSecs()
                    if stayInAreaTransmissionCooldown < currentTime then
                        DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("StayInArea"))
                        stayInAreaTransmissionCooldown = currentTime + 30
                    end
                end
            end
        else
            stayInAreaTransmissionReady = false
            enemyBlockingTransmissionReady = false
        end

        if math.floor(captureProgress * 100) > math.floor(lastProgress * 100) then
            captureArea:PlaySound(tickingSound, false, Engine.SP_VERY_LOW, true, nil)
        end
        
        blockingMsg = blockingMsg or (blocked and friendliesInside > 0 and "/Lotus/Language/Railjack/CaptureRailjackPartProgressBlocked")
        if lastBlockingMsg ~= blockingMsg then
            if blockingMsg then
                _T.ShowImpactMessage(blockingMsg, -1, false, nil, nil, nil)
            else
                _T.HideImpactMessage()
            end
        end

        if sentientThresholds and sentientThresholds[sentientStage] and lastProgress < sentientThresholds[sentientStage] and captureProgress > sentientThresholds[sentientStage] then
            local playerAv = gRegion:GetLocalPlayerAvatar()
            for i=1,sentientCounts[sentientStage] do
                local agent = aiDir:CreateAgent(sentientAgents[RandomInt(1,#sentientAgents)], nil, Symbol("RailjackHuntSentients"))
                if not IsNull(agent) then
                    agent:SetAlert()
                    agent:StormTarget(playerAv, 10)
                end
            end

            sentientStage = sentientStage + 1
        end

        if stageThresholds[stage] and lastProgress < stageThresholds[stage] and captureProgress > stageThresholds[stage] then
            DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("DronesSpawned"))
            captureArea:PlaySound(jammingDronesSpawnedSound, false, Engine.SP_VERY_LOW, true, nil)

            local ring = captureArea:GetAttachment(activeRingType)
            if not IsNull(ring) then
                ring:PlayTriggeredFade(true)
            end

            for i=1, stageDroneCounts[stage] or 1 do
                local attempts = 20
                local agent
                while IsNull(agent) and attempts > 0 do
                    agent = aiDir:CreateAgent(jammingDroneAgent, mSpawnPoints[RandomInt(1,mDroneSpawnPointMaxIndex)], Symbol("JammingDrone"))
                    attempts = attempts - 1
                end
                if IsNull(agent) then
                    agent = aiDir:CreateAgent(jammingDroneAgent, nil, Symbol("JammingDrone"))
                end
                
                if not IsNull(agent) then
                    agent:SetAlert()
                    local contextAction = gRegion:FindFirstTagged(Symbol("CrewShipPartContextAction"))
                    if not IsNull(contextAction) then
                        local marker = contextAction:GetAttachment(gBaseMarkerInfoType)
                        if not IsNull(marker) then
                            marker:Disable()
                        end
                    end
                end
            end
            
            if stageDroneCounts[stage - 1] then
                OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/DestroyJammingDrones", 2, ": 0 / " .. stageDroneCounts[stage - 1])
            end

            stage = stage + 1
        end
    end

    OBJTXT.ClearPrimaryObjText()
    OBJTXT.RemoveObjProgressBar()

    captureArea:SetState(2)

    SPAWN.ShutDownReinforcements(aiDir)
    aiDir:SetEnableAutoSpawns(true, captureArea)

    DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("CaptureComplete"))

    captureArea:PlaySound(captureCompleteSound, false, Engine.SP_VERY_LOW, true, nil)

    GAMEMODE.MarkExtraction()
    OBJTXT.SetExtractObjText()
end

function ObjectiveSetup(trigger)
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    while IsNull(aiDir) or not aiDir:IsEnabled() do
        Sleep(0)
        aiDir = gRegion:GetNpcMgr():GetAiDirector()
    end
    
    aiDir:SetObjective(trigger:GetAttachParent())
    aiDir:SetEnableAutoSpawns(true)
    aiDir:SetAllowLockDown(false)
    OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/CaptureRailjackPartFind")
    
    DIALOG.PlayGlobalTransmission(_T.MissionTransmissionSet, Symbol("Intro"))
end

function DisableMarker(contextAction)
    gRegion:CreateEntity(beaconActivateEffect, contextAction:GetPosition(), ZERO_ROTATION)
    local marker = contextAction:GetAttachment(gBaseMarkerInfoType)
    if not IsNull(marker) then
        marker:Disable()
    end
end

function OnLevelLoaded()
    _T.RJHuntStageThresholds = stageThresholds
    _T.RJHuntStageDroneCounts = stageDroneCounts
    _T.SentientStageThresholds = sentientThresholds
    _T.SentientStageCounts = sentientCounts
    _T.RJHuntEnemyCountMultiplier = enemyCountMultiplier
end
