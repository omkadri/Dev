pilotAction = Instance()

function PreparePilotCinematic(arg0, arg1, arg2)
    local instigatorAvatar = nil
    if not IsNull(pilotAction) then
        instigatorAvatar = pilotAction:GetCurrUser()
    end
    
    if IsNull(instigatorAvatar) then
        instigatorAvatar = gRegion:GetLocalPlayerAvatar()
    end
    
    local animationName = Symbol("RJTurretHarnessTenno1")
    
    if not IsNull(instigatorAvatar) then
        instigatorAvatar:SetAnimName(animationName)
    end
    
    for i,v in ipairs(gRegion:FindAll(gLotusOperatorAvatarType) or {}) do
        if not IsNull(v) then
            v:SetDissolve(1)
        end
    end
end