malfunctionSpawnerType = Type()

function SpawnMalfunctionInShip()
    local malfunctionSpawners = gRegion:FindAll(malfunctionSpawnerType)
    local potentialSpawners = {}
    for i, spawner in ipairs(malfunctionSpawners) do
        if spawner:IsEnabled() then
            table.insert(potentialSpawners, spawner)
        end
    end
    
    if #potentialSpawners <= 0 then
        print("SpawnMalfunction; Could not find any enabled/available spawner to spawn a malfunction.")
    else
        potentialSpawners[RandomInt(1, #potentialSpawners)]:Spawn()
    end
end