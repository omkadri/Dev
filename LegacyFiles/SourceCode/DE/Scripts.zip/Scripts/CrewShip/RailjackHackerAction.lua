droneDeco = Type()
referenceEntity = { Instance() }

SYSTEM_MOD = 0

local _DisableMods =  { DISABLE_GUNS = 1, DISABLE_CANNONS = 2, DISABLE_BATTLE_CRAFTING = 3, DISABLE_BATTLE_AVIONICS = 4, DISTORT_RAILJACK_SPEED_AND_BOOST = 5}
local STATUS = { NOTARGET = 1, MOVINGTOTARGET = 2, JAMMING = 3, SEARCHINGNEXTTARGET = 4 }
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"

railJackSpeedChangePercentage = 0.5


local function _GetShip()
    if not gRegion:IsMaster() then
        return
    end
    
   while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    return crewShipMgr:GetPlayerShip()
end

local function _DistortRailJackSpeedAndBoost(percentage, enableBoost)
    local ship = _GetShip()
    
      if IsNull(ship) then
        return
    end
    
    local shipAvatar = ship:GetAvatarOwner()
    if IsNull(shipAvatar) then
        return
    end
    
    if enableBoost  then
         shipAvatar:InventoryControl():RemoveUpgrade(Game.AVATAR_MOVEMENT_SPEED, Game.MULTIPLY, percentage)
    else
         shipAvatar:InventoryControl():AddUpgrade(Game.AVATAR_MOVEMENT_SPEED, Game.MULTIPLY, percentage)
    end
    
    shipAvatar:SetCanRun(enableBoost)
    print("RailJackSpeed change by percentage " .. percentage)
    print("Battle Boost enabled ".. tostring(enableBoost))
end

local function _EBattleAvionics(enable)
    local ship = _GetShip()
    
      if IsNull(ship) then
        return
    end
    
    local emplacements = RJ_UTIL.FindTypeOnShip(gEmplacementType, ship) 
    for i, emplacement in ipairs(emplacements) do
        emplacement:SetUseAbilities(enable) -- need to start a level
    end
    
    print("Battle Avionics enabled ".. tostring(enable))
end

local function _EnableArchwingCannon(enable)
   local ship = _GetShip()
    
      if IsNull(ship) then
        return
    end
    
    local rjEmplacements = gRegion:FindTagged(Symbol("RailjackEmplacement"))
    for _, emplacement in pairs(rjEmplacements) do
        
        local cannon  =  emplacement
        if enable then
            cannon:Enable()
        else
            cannon:Disable()
        end
        break
    end
   
    print("Arch wing disabled ".. tostring(enable))
end

function OnArrived(poi, avatar)
    if SYSTEM_MOD == 0 then
        return
    end
    
    if SYSTEM_MOD == _DisableMods.DISABLE_GUNS  or SYSTEM_MOD == _DisableMods.DISABLE_BATTLE_CRAFTING then
                 for i = 1,  #referenceEntity do
                    referenceEntity[i]:Disable()
                end
            elseif SYSTEM_MOD == _DisableMods.DISABLE_BATTLE_AVIONICS then
                _EBattleAvionics(false)
            elseif SYSTEM_MOD == _DisableMods.DISTORT_RAILJACK_SPEED_AND_BOOST then
                _DistortRailJackSpeedAndBoost(railJackSpeedChangePercentage,false)
            elseif SYSTEM_MOD == _DisableMods.DISABLE_CANNONS then
                _EnableArchwingCannon(false)
    end
end


function OnHacked(poi, avatar, succeeded)
            --SYSTEM_MOD =_DisableMods.DISABLE_GUNS
            if SYSTEM_MOD == 0 then
                return
            end
            
            local drone = nil
            
            if succeeded then
                if not IsNull(poi) then
                    poi:Disable()
                end
    
                drone = gRegion:CreateEntity(droneDeco, poi:GetPosition() , poi:GetRotation())
            end
            
            while not IsNull(drone)  do
                Sleep(0)
            end
            
            
            if SYSTEM_MOD == _DisableMods.DISABLE_GUNS  or SYSTEM_MOD == _DisableMods.DISABLE_BATTLE_CRAFTING then
                for i = 1,  #referenceEntity do
                     referenceEntity[i]:Enable()
                end
            elseif SYSTEM_MOD == _DisableMods.DISABLE_BATTLE_AVIONICS then
                _EBattleAvionics(true)
            elseif SYSTEM_MOD == _DisableMods.DISTORT_RAILJACK_SPEED_AND_BOOST then
                _DistortRailJackSpeedAndBoost(railJackSpeedChangePercentage,true)
             elseif SYSTEM_MOD == _DisableMods.DISABLE_CANNONS then
                _EnableArchwingCannon(true)
            end
            
           
			if not IsNull(poi) then
	            poi:Enable()            
			end
end

function JammingDrone(droneAvatar)
	local poiJammed = nil
	local lastPoiJammed = nil
	local agent = droneAvatar:GetAgent()
	local jammedTime = Time()
	local status = STATUS.NOTARGET
	local hackerPoiTags = gRegion:FindTagged(Symbol("SentientHackerStation"))
    while not IsNull(droneAvatar) and not droneAvatar:IsPreDeath() and not droneAvatar:IsKilled() do
        if IsNull(agent) then
            agent = droneAvatar:GetAgent()
        elseif status == STATUS.NOTARGET then
			if not IsNull(hackerPoiTags) then
				--for i = 1, #hackerPoiTags do
				local i = SRandomInt(1, #hackerPoiTags)
					local hackerPoiTag = hackerPoiTags[i]
					if hackerPoiTag:IsEnabled() then
						poiJammed = hackerPoiTag
						if agent then
							agent:SetDesiredPosition(hackerPoiTag:GetPosition())
						end
						status = STATUS.MOVINGTOTARGET
						--break
					end
				--end
			end
        elseif status == STATUS.MOVINGTOTARGET then
			if not poiJammed:IsEnabled() then
				--someone has taken my poi. let's move to other poi
				poiJammed = nil
				status = STATUS.NOTARGET
				if agent then
					agent:ClearDesiredPosition()
				end
			elseif droneAvatar:DistanceToEntitySqr(poiJammed) < 9 then
				--arrived. start jamming!
				poiJammed:Disable()
				poiJammed:RunArriveScript(droneAvatar)
				jammedTime = Time()
				status = STATUS.JAMMING
			end
        elseif status == STATUS.JAMMING then
			if jammedTime < Time() - 10 then
				--time's up. let's move to next poi
				status = STATUS.SEARCHINGNEXTTARGET
			end
        elseif status == STATUS.SEARCHINGNEXTTARGET then
			if not IsNull(hackerPoiTags) then
				--for i = 1, #hackerPoiTags do
				local i = SRandomInt(1, #hackerPoiTags)
					local hackerPoiTag = hackerPoiTags[i]
					if hackerPoiTag:IsEnabled() and lastPoiJammed ~= hackerPoiTag then
						lastPoiJammed = poiJammed
						poiJammed = hackerPoiTag
						if agent then
							agent:SetDesiredPosition(hackerPoiTag:GetPosition())
						end
						status = STATUS.MOVINGTOTARGET
						--break
					end
				--end
			end
		end
		if not IsNull(lastPoiJammed) and droneAvatar:DistanceToEntitySqr(lastPoiJammed) > 9 then
			--left poi. stop jamming
			lastPoiJammed:Enable()
			lastPoiJammed:RunLeaveScript(droneAvatar, false)
			lastPoiJammed = nil
		end
        Sleep(0)
    end

	if not IsNull(lastPoiJammed) then
		--left poi. stop jamming
		lastPoiJammed:Enable()
		lastPoiJammed:RunLeaveScript(droneAvatar, false)
	end
	if not IsNull(poiJammed) and not poiJammed:IsEnabled() then
		poiJammed:Enable()
		poiJammed:RunLeaveScript(droneAvatar, false)
	end
end