-- This is to preload most of the level when loading to Dojo (so that streaming takes less time)
interiorLevel = Resource("/Lotus/Levels/Railjack/RailjackInterior.level")

function EmptyFunction()
end
