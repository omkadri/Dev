local mLocalPlayer = nil
local mTrackers = {}

local function UpdateLayerIndex()
    local avatar = mLocalPlayer:GetAvatar()
    if IsNull(avatar) then
        return false
    end
    
    local zone = avatar:GetZone()
    if IsNull(zone) then
        return false
    end
    
    local zoneLayerIndex = zone:GetRegionIndex()
    for i = #mTrackers, 1, -1 do
        local tracker = mTrackers[i]
        if tracker.Removing then
            table.remove(mTrackers, i)
        elseif tracker.Data.Location ~= zoneLayerIndex and tracker.Data.Visible then
            tracker.SetVisible(false)
        elseif tracker.Data.Location == zoneLayerIndex and not tracker.Data.Visible then
            tracker.SetVisible(true)
        end
    end
end

local function LocationTrackerAdded(tracker)
    if tracker.AutonomousVisibility then
        table.insert(mTrackers, tracker)
    end
end

--determines whether or not
function RailjackHudTrackers()   
    while IsNull(gGameRules) or not gGameRules:GameStarted() do
        Sleep(1)
    end

    while IsNull(_T.LocationTrackerAddedCallbacks) do
        Sleep(1)
    end
    
    mLocalPlayer = gRegion:GetLocalPlayer()
    
    table.insert(_T.LocationTrackerAddedCallbacks, LocationTrackerAdded)
    
    while true do
        UpdateLayerIndex()
        Sleep(0)
    end
end