function HideInDojo(marker)
    while IsNull(gGameRules) do
        Sleep(0)
    end
    if gGameRules:IsA(gLotusDojoGameRulesType) then
        marker:Disable()
    end
end