startAnim = Resource()
idleAnim = Resource()
endAnim = Resource()
craftingMovie = Resource()

function StartCrafting(trigger)

    local av = trigger:GetInstigator()
    
    if not IsNull(av) then
        local inventoryController = av:InventoryControl()
        local weapon = inventoryController:GetWeaponInHand(Engine.MAIN_HAND)   
    
        -- switch to data knife weapon
        if not IsNull(weapon) then
            _T.prevSlot = weapon:GetCurrentInventorySlot()
        end
        if not IsNull(_T.lastSlot) and not av:IsA(gLotusOperatorAvatarType) then
            inventoryController:Unequip(Engine.MAIN_HAND, Engine.InventoryControllerBase_ES_INSTANT_EQUIP)
        end
        
        if not av:IsA(gLotusOperatorAvatarType) then
            -- nerf during refactor: inventoryController:Equip(Engine.SLOT_12, Engine.MAIN_HAND, Engine.InventoryControllerBase_ES_INSTANT_EQUIP)
        end
        
        --Really hacky teleport of pos and rot, will not be an issue when we swap to OverlayWaitForInputAction
        av:Teleport(trigger:GetPosition(), trigger:GetRotation())
        av:PlayAnimation(startAnim, true, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_ONCE)
        
    end
    
    if not IsNull(av) and av:ReplicaLocallyControlled() then
        av:ClientRequestPlayAnimation(idleAnim, false, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_LOOP)
        local movie = gFlashMgr:PushMovie(craftingMovie)
        while not IsNull(movie) do
            Sleep(0)
        end
            
        -- todo: move to the screen when you actually craft something?
        if not IsNull(av) then
            av:ClientRequestPlayAnimation(endAnim, true, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_ONCE)
        end
    end

    if gRegion:IsMaster() then
        
        while not IsNull(av) and not av:IsPlayingAnimation(endAnim) do
            Sleep(0)
        end
        
        while not IsNull(av) and av:IsPlayingAnimation(endAnim) do
            Sleep(0)
        end

        if not IsNull(av) then
            if not IsNull(_T.prevSlot) then
                -- nerf during refactor: av:InventoryControl():Equip(_T.prevSlot, Engine.MAIN_HAND, Engine.InventoryControllerBase_ES_INSTANT_EQUIP)
            else 
                -- nerf during refactor: av:InventoryControl():Unequip(Engine.MAIN_HAND, Engine.InventoryControllerBase_ES_INSTANT_EQUIP)
            end
        end
        
        trigger:Enable()
    end

end