commonChance = 0.7
maxCommon = 25
uncommonChance = 0.3
maxUncommon = 10
rareChance = 0.02
maxRare = 1
ultraRareChance = 0.01
maxUltraRare = 1
minPOIs = 2    --The above max values are based on the assumption that this many POIs will spawn - will scale the max values accordingly if less, to avoid crazy density

local TABLE = require "Lotus.Scripts.Libs.TableLib"

function SpawnLootCrates()
    Sleep(1)
    
    while IsNull(gRegion) do
        Sleep(0)
    end

    local numCrewShips = #_T.CrewShipLootSpawnFuncs
    TABLE.InPlaceShuffle(_T.CrewShipLootSpawnFuncs)
    
    numCrewShips = math.max(minPOIs, numCrewShips)

    local numCommonToSpawn = 0
    for i = 1, maxCommon do
        local r = math.random()
        if r <= commonChance then
            numCommonToSpawn = numCommonToSpawn + 1
        end
    end
    
    local numUncommonToSpawn = 0
    for i = 1, maxUncommon do
        local r = math.random()
        if r <= uncommonChance then
            numUncommonToSpawn = numUncommonToSpawn + 1
        end
    end
    
    local numRareToSpawn = 0
    for i = 1, maxRare do
        local r = math.random()
        if r <= rareChance then
            numRareToSpawn = numRareToSpawn + 1
        end
    end
    
    local numUltraRareToSpawn = 0
    for i = 1, maxUltraRare do
        local r = math.random()
        if r <= ultraRareChance then
            numUltraRareToSpawn = numUltraRareToSpawn + 1
        end
    end
    
    
    for i, func in ipairs(_T.CrewShipLootSpawnFuncs) do
        local common = math.ceil(numCommonToSpawn / numCrewShips)
        numCommonToSpawn = numCommonToSpawn - common
        
        local uncommon = math.ceil(numUncommonToSpawn / numCrewShips)
        numUncommonToSpawn = numUncommonToSpawn - uncommon
        
        local rare = math.ceil(numRareToSpawn / numCrewShips)
        numRareToSpawn = numRareToSpawn - rare
        
        local ultraRare = math.ceil(numUltraRareToSpawn / numCrewShips)
        numUltraRareToSpawn = numUltraRareToSpawn - ultraRare
        
        func(common, uncommon, rare, ultraRare)
    end

    _T.CrewShipLootSpawnFuncs = {}
end