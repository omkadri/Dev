shipType = Type()
shipPlacement = Instance()
playerShip = false
backdropLevel = WeakResource()
backdropPlacement = Vector()
waitForPlayers = true
exitPushVelocity = Vector()

exitRailjackAnim = Resource() --first part of anim we play when exiting railjack before fade

enterRailjackCenterAnim = Resource()
enterCenterLimit = 20

enterRailjackLeftAnim = Resource()
enterRailjackRightAnim = Resource()

exitPointType = WeakResource() --second part of exit anim that plays post fade
exitCinematicType = WeakResource() 
exitCameraSpotType = WeakResource()

enterCinematicType = WeakResource("/Lotus/Types/Game/CrewShip/RailJack/EnterRailjackInstigatorCinematic") 
hangarExitTag = Symbol("RailjackExitPoint")
setViewAfterTeleport = false

fadeDelay = 0.3
fadeOutTime = 0.5
fadeInTime = 0.5
fadeValue = 1.0
detachAnim = Resource() --first part of anim we play when entering railjack before fade
enterAnim = Resource() --second part of anim we play when entering railjack after fade. 

hyperDriveState = Lotus_Game.CrewShipAvatar_HDS_READY
onBoardTransmission = WeakResource()

archwingCannonBoardedEffect = Type("/Lotus/Fx/SpaceBattle/Abilities/ArchwingCannonBoardingAttach")

pointOfInterestTag = Symbol()
boardShipType = WeakResource()

local boardShipInvulnTime = 2.0
local boardShipFromAWCannonInvulnTime = 4.0

local LOTUS_NET = require "Lotus.Interface.LotusNetworkUtilities"
local UI_UTIL = require "Lotus.Interface.UIUtilities"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local mNotificationsMovie = WeakResource("/Lotus/Interface/Notifications.swf")

local TransferenceSym = Symbol("OPERATOR_TRANSFERENCE")

local CrewShipEnterSeq = Symbol("CrewShipEnterSeq")
local CrewShipExitSeq = Symbol("CrewShipExitSeq")
local BoardShipPositionTag = Symbol("BoardShipPosition")

function BackdropReady(level, layer)
    _T.DemoBackdropReady = not IsNull(level)
    _T.DemoBackdropStreaming = false
end

function StreamBackdrop()
    if _T.DemoBackdropReady or _T.DemoBackdropStreaming then
        return
    end

    if waitForPlayers then
        local playerAvatars = gRegion:GetHumanPlayerAvatars()
        while #playerAvatars == 0 do
            Sleep(0)
            playerAvatars = gRegion:GetHumanPlayerAvatars()
        end
    end

    if not IsNull(backdropLevel) then
        local levelArgs = gRegion:GetLevelArgs()
        levelArgs.level = backdropLevel
        levelArgs.streamingLayer = 505
        levelArgs.streamingMode = GraphicsRes.StreamRegion_InPlace
        levelArgs.isAutonomous = true
        levelArgs:SetStreamingOffset(backdropPlacement, ZERO_ROTATION)
        levelArgs:SetStreamingCallback("BackdropReady")
        
        _T.DemoBackdropStreaming = true
        Engine.StreamRegion(levelArgs)
        
        while _T.DemoBackdropReady == nil do
            Sleep(0.1)
        end
        
        local greenRoomAttribs = gRegion:FindFirstTagged(Symbol("GreenRoom"))
        greenRoomAttribs:SetBackDropId(EMPTY_SYMBOL)
        greenRoomAttribs:SetBackDropId(Symbol("BackDropSpace"))
    end
end

local function TellMiniMapStatus(onShip)
    local player = gRegion:GetLocalPlayer()
    if not IsNull(player) then
        local avatar = player:GetAvatar()
        local minimap = avatar:GetPlayer():GetMiniMap()

        if not IsNull(minimap) then
            minimap:SetOnRailJack(onShip)
        end
    end
end

local function FadeTeleport(avatar, destination)
    local postProcess = avatar:CameraControl():ScriptGetCurrentPostProcessInfo()
    local initialVal = postProcess.fade
    local endVal = 1.0
    
    local t = 0
    local duration = 0.5

    
    while t < 1 do
        t = math.min(1.0, t + DeltaTime() / duration)
        local val = Lerp(initialVal, endVal, t)
        postProcess.fade = val
        Sleep(0)
    end
    
    print("CREWSHIP: FadeTeleport to "..tostring(destination:GetPosition()))
    avatar:Teleport(destination:GetPosition(), destination:GetRotation())
    if setViewAfterTeleport then
        avatar:SetView(destination:GetRotation())
    end
    
    while t > 0 do
        t = math.max(0.0, t - DeltaTime() / duration)
        local val = Lerp(initialVal, endVal, t)
        postProcess.fade = val
        Sleep(0)
    end
end

local function TeleportToShip(ship, avatar)
    if IsNull(avatar) then
        return
    end
    
    local spawnPoint = ship:GetPlayerSpawn()
        
    while IsNull(spawnPoint) do
        Sleep(0)
        spawnPoint = ship:GetPlayerSpawn()
    end
    
    if gGameRules:IsBootLevel() then
        -- setup the greenroom nicely
        local greenRoomAttribs = ship:GetGreenRoom()
        local greenRoomZone = greenRoomAttribs:GetZone()
        
        local backdropZone = greenRoomZone:GetBackdrop()
        backdropZone:GetZoneAttribs():SetParallaxCenter(greenRoomAttribs)
        FadeTeleport(avatar, spawnPoint)

        if not IsNull( avatar:MotionControl()) then
            avatar:MotionControl():SetForceWalk(false)
        end
    else
        avatar:Teleport(spawnPoint:GetPosition(), spawnPoint:GetRotation())
    end
    
    avatar:InventoryControl():SetOnBoardShip(ship)
    if gRegion:IsMaster() then
        if gGameRules:IsBootLevel() then
            ship:GetAvatarOwner():SetHyperDriveState(Lotus_Game.CrewShipAvatar_HDS_READY)
        else
            ship:GetAvatarOwner():SetHyperDriveState(Lotus_Game.CrewShipAvatar_HDS_POWERING_DOWN)
        end
    end
end

local function SetEnableShipMissionFunctions(enable)

    local exitActions = gRegion:FindTagged(Symbol("ExitShipAction"))

    for i=1,#exitActions do
        if not IsNull(exitActions[i]) then
            if enable == true then
                exitActions[i]:Enable()
            else
                exitActions[i]:Disable()
            end
        end
    end
    
    
    local enterActions = gRegion:FindTagged(Symbol("EnterShipAction"))
    for i=1,#enterActions do
        if not IsNull(enterActions[i]) then
            if enable == true then
                enterActions[i]:Enable()
            else
                enterActions[i]:Disable()
            end
        end
    end
end

local mEnemyShip = nil

function EnemyShipReady(enemyShip)
    if not IsNull(enemyShip) then
        mEnemyShip = enemyShip
    else
        mEnemyShip = false
    end
end

function SummonEnemyShip()
    while IsNull(gRegion:GetLocalPlayer()) do
        Sleep(1.0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    if IsNull(crewShipMgr) then
        return
    end
    
    crewShipMgr:CreateCrewShipFromType(shipType, nil, false, false, "EnemyShipReady")
    
    while mEnemyShip == nil do
        Sleep(0)
    end
    
    if mEnemyShip == false then
        -- Error
    else
        if not IsNull(shipPlacement) then
            mEnemyShip:GetAvatarOwner():Teleport(shipPlacement:GetPosition(), shipPlacement:GetRotation())
        else
            mEnemyShip:GetAvatarOwner():Teleport(Vector(), Rotation()) -- gotta spawn somewhere
        end
    end
end

function ShipReady(ship)
    if not gGameRules:IsBootLevel() then
        TeleportToShip(ship, gRegion:GetLocalPlayerAvatar())
        --if gRegion:IsMaster() then
            --ship:GetAvatarOwner():SetHyperDriveState(Lotus_Game.CrewShipAvatar_HDS_POWERING_DOWN)
        --end
    end
end

function SummonCrewShip(action, avatar)
    while IsNull(gRegion:GetLocalPlayer()) do
        Sleep(1.0)
    end

    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    if IsNull(crewShipMgr) then
        return
    end
    
    local existingShip = crewShipMgr:GetPlayerShip()
    
    if not IsNull(existingShip) then
        -- we good, just teleport us there now
        TeleportToShip(existingShip, avatar)
        return
    end
    
    if not crewShipMgr:IsLoadingShip(playerShip) then
        local crewShipLoadOut = nil
        
        if gGameRules:IsBootLevel() then
            crewShipLoadOut = gPlayerProfileMgr:GetPlayerProfile(0):GetGameSpecificData():GetLoadOut().mCrewShipLoadOut
            _T.BackgroundMovie:Execute("ShowBlockingMessage", "1")
        else
            local player = gRegion:GetLocalPlayer()
            while IsNull(player) do
                player = gRegion:GetLocalPlayer()
                Sleep(0)
            end
            
            local loadOut = player:GetLoadOut()
            crewShipLoadOut = loadOut.mCrewShipLoadOut
        end

        local highPriority = true
        
        local shipTypeOverride = gFlashMgr:GetConfigString("CrewShip.DefaultShipOverride")
        if shipTypeOverride ~= "" then
            shipTypeOverride = Type(shipTypeOverride)
            if IsNull(shipTypeOverride) then
                shipTypeOverride = shipType
            end
            crewShipMgr:CreateCrewShipFromType(shipTypeOverride, nil, playerShip, highPriority, "ShipReady")
        elseif crewShipLoadOut ~= nil and crewShipLoadOut.mShip.mItemId.mId ~= Lotus_Game.InvalidItemID then
            crewShipMgr:CreateCrewShipFromLoadout(crewShipLoadOut, playerShip, highPriority, "ShipReady")
        elseif not IsNull(shipType) then
            crewShipMgr:CreateCrewShipFromType(shipType, nil, playerShip, highPriority, "ShipReady")
        end
    end
    
    -- Wait for the ship to finish
    while crewShipMgr:IsLoadingShip(playerShip) do
        Sleep(0)
    end
    if gGameRules:IsBootLevel() then    
        _T.BackgroundMovie:Execute("ShowBlockingMessage", "0")
    end
    local playerShip = crewShipMgr:GetPlayerShip()
    local localPlayerAvatar = gRegion:GetLocalPlayerAvatar()
    
    while IsNull(playerShip) or IsNull(localPlayerAvatar) do
        playerShip = crewShipMgr:GetPlayerShip()
        localPlayerAvatar = gRegion:GetLocalPlayerAvatar()
        Sleep(0)
    end
    
    TeleportToShip(playerShip, localPlayerAvatar)
end

function CreateAdHocShip(action, avatar)
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    if IsNull(crewShipMgr) then
        return
    end
    
    if not IsNull(crewShipMgr:GetPlayerShip()) then
        return
    end
        
    local crewShipLoadOut = gPlayerProfileMgr:GetPlayerProfile(0):GetGameSpecificData():GetLoadOut().mCrewShipLoadOut

    local greenRoom = gRegion:FindFirstTagged(Symbol("GreenRoom"))
    
    if IsNull(greenRoom) then
        return
    end
    
    local greenRoomZone = greenRoom:GetZone()
    
    if IsNull(greenRoomZone) then
        return
    end
    
    local layerIndex = greenRoomZone:GetLayerIndex() - 1
    
    local highPriority = true
    if crewShipLoadOut ~= nil and crewShipLoadOut.mShip.mItemId.mId ~= Lotus_Game.InvalidItemID and crewShipLoadOut.mShip.mItemType == shipType then
        crewShipMgr:CreateCrewShipFromLoadout(crewShipLoadOut, playerShip, highPriority, "ShipReady", layerIndex)
    elseif shipType then
        crewShipMgr:CreateCrewShipFromType(shipType, nil, playerShip, highPriority, "ShipReady", layerIndex)
    end
end

function CanExitShip(scriptTrigger, avatar)
    if IsNull(avatar) then
        return false
    end

    local inventoryController = avatar:InventoryControl()
    local boardedShip = inventoryController:GetOnBoardShip()
    
    if not IsNull(boardedShip) then
        local hds = boardedShip:GetAvatarOwner():GetHyperDriveState() 
        if (hds == Lotus_Game.CrewShipAvatar_HDS_READY or hds == Lotus_Game.CrewShipAvatar_HDS_COOLING_DOWN)  then
            return true
        end
    end

    return false
end

local function GetInstigatorCinematic(instigator, attachedParent, cinematicType)
    local playerIds = {}
    local players = gRegion:GetHumanPlayers()
    for i = 1, #players do
        local player = players[i]
        table.insert(playerIds, player:GetPlayerID())
    end 

    table.sort(playerIds)
    local playerIndex = nil
    local localPlayerId = instigator:GetAuthoritativePlayer():GetPlayerID()
    for i = 1, #playerIds do
        if localPlayerId == playerIds[i] then
            playerIndex = i
            break
        end
    end    

    local allCins = attachedParent:GetAllAttachments(cinematicType)
    local cins = {}
    for i = 1, #allCins do
        table.insert(cins, { cin=allCins[i], distance=DistanceSqr(ZERO_VECTOR, allCins[i]:GetLocalAttachPosition()) })
    end 

    if #allCins < playerIndex then
        print("PlayerIndex is greater than number of cinematics ")
        return nil
    end

    table.sort(cins, function(a,b) return a.distance < b.distance end)
    
    for i = 2, #cins do
        if cins[i-1].distance == cins[i].distance then
            print("ERROR: Same distance instigator cin"..tostring(cins[i-1].cin:GetFullName()))
        end
    end 

    local cin = (cins[playerIndex].cin)
    if not IsNull(cin) then
        print(tostring(instigator:GetFullName()).." picked "..tostring(cin:GetFullName()))
    end

    return cin
end

local function GetInstigatorInstancedCinematicInShip(instigator, cinematicTag, ship)
    
    if IsNull(ship) then
        return
    end

    local players = gRegion:GetHumanPlayers()
    local playerAvatars = gRegion:GetHumanPlayerAvatars()
    
    local avatars = {}
    for i = 1, #playerAvatars do
        local player = players[i]
        table.insert(avatars, { id=player:GetPlayerID(), avatar=playerAvatars[i] })
    end 

    table.sort(avatars, function(a,b) return a.id < b.id end)
    local playerIndex = nil
    for i = 1, #playerAvatars do
        if avatars[i].avatar == instigator then
            playerIndex = i
            break
        end
    end    
        
    local allCins = gRegion:FindTagged(cinematicTag)
    local cins = {}
    for i = 1, #allCins do
        if ship:IsEntityOnBoardShip(allCins[i]) then
            table.insert(cins, allCins[i])
        end
    end 

    if #cins < playerIndex then
        print("PlayerIndex is greater than number of cinematics ")
        return nil
    end

    table.sort(cins, function(a,b) return a:GetInstance() < b:GetInstance() end)

    local cin = (cins[playerIndex])
    if not IsNull(cin) then
        print(tostring(instigator:GetFullName()).." picked "..tostring(cin:GetFullName()))
    end

    return cin
end

local _exitCin = nil
local _pushVeclocity = nil
local _shipRotation = ZERO_ROTATION

local function PlayCinematic(instigator, cinematic, fromCanon)
    if IsNull(cinematic) or IsNull(instigator) then
        return
    end

    if cinematic:IsPlaying() and gRegion:IsMaster() then
        cinematic:FirePort("StopPlaying")
    end

    Sleep(0)

    if IsNull(instigator) then
        return
    end

    instigator:SetAnimName(Symbol("Excalibur")) 
    instigator:SetView(cinematic:GetRotation())
    instigator:PlayAnimation(nil, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_ONCE, false, 1.0)

    if gRegion:IsMaster() then
        if not fromCanon then
            instigator:Teleport(cinematic:GetPosition(), cinematic:GetRotation())
            instigator:SetView(cinematic:GetRotation())
            Sleep(0.1)
        end        
        if IsNull(cinematic) then
            return
        end
        cinematic:SetInstigatorAvatar(instigator)
        cinematic:FirePort("StartPlaying")
    end

    local t = 0
    while not IsNull(cinematic) and not cinematic:IsPlaying() and t < 5 do -- client timeout (waiting for host to start cin)
        Sleep(0)
        t = t + DeltaTime()
    end
    
    while not IsNull(cinematic) and cinematic:IsPlaying() do
        Sleep(0)
    end

    if not IsNull(instigator) then
        instigator:PlayAnimation(nil, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_ONCE, false, 1.0)
    end
end

function PlayAWCannonCinematic(instigator)
    local ship = instigator:InventoryControl():GetOnBoardShip()
    local t = 0
    while IsNull(ship) and t < 5 do -- wait till actutally inside the ship
        Sleep(0)
        ship = instigator:InventoryControl():GetOnBoardShip()
        t = t + DeltaTime()
    end

    if IsNull(ship) then
        return
    end
    
    local cinematic = GetInstigatorInstancedCinematicInShip(instigator, Symbol("EnterFromCannonCin"), ship)
    if not IsNull(cinematic) then
        instigator:Attach(archwingCannonBoardedEffect, EMPTY_SYMBOL)
        PlayCinematic(instigator, cinematic, true)
        if gRegion:IsMaster() and not IsNull(gRegion:GetNpcMgr()) then
            gRegion:GetNpcMgr():SendPerception(Npc.ITB_CONTACT, Npc.IST_ENEMY , instigator:GetPosition(), instigator, 100 , 100, true)
        end
    end
end

function StartExitSeq(instigator)
    if IsNull(instigator) then
        return
    end

    local leavingCin = _exitCin
    local postProcess = instigator:CameraControl():ScriptGetCurrentPostProcessInfo()
    local val
    local t
    local pushVelocity = _pushVeclocity
    local shipRotation = _shipRotation
    
    if not IsNull(leavingCin) then

        if leavingCin:IsPlaying() and gRegion:IsMaster() then
            leavingCin:FirePort("StopPlaying")
        end

        instigator:SetAnimName(Symbol("Excalibur")) 
        instigator:SetView(leavingCin:GetRotation())
        instigator:PlayAnimation(nil, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_ONCE, false, 1.0)

        if gRegion:IsMaster() then
            leavingCin:SetInstigatorAvatar(instigator)
            leavingCin:FirePort("StartPlaying")
        end

        t = 0
        while not IsNull(leavingCin) and not leavingCin:IsPlaying() and t < 5 do -- client timeout (waiting for host to start cin)
            Sleep(0)
            t = t + DeltaTime()
        end

        t = 0
        while t < 1 do
            val = Lerp(1, 0, t)
            postProcess.fade = val
            t = t + DeltaTime() / fadeInTime
            Sleep(0)
        end

        while not IsNull(leavingCin) and leavingCin:IsPlaying() do
            Sleep(0)
        end
    end
        
    t = 0
    while t < 1 do
        if pushVelocity ~= nil then
            --TODO: Attenuate this by zone scale, or make the code for it zone scale aware
            instigator:MotionControl():SetPushVelocity(pushVelocity, true)
        end
        val = Lerp(1, 0, t)
        --postProcess.fade = val
        t = t + DeltaTime() / fadeInTime
        Sleep(0)
    end

    postProcess.fade = 0
        
    
    if pushVelocity ~= nil then
        pushVelocity = RotateVector(pushVelocity, shipRotation)
    end
end

local function _ExitShip(instigator, pushVelocity)
    if IsNull(instigator) then
        return
    end
    
    local player = instigator:GetAuthoritativePlayer()
    local warframeSuit = player:GetOwnedPowerSuitAvatar():InventoryControl():GetActivePowerSuit()
    local operatorSuit = nil
    if not IsNull(player:GetOperatorAvatar()) then
        operatorSuit = player:GetOperatorAvatar():InventoryControl():GetActivePowerSuit()
    end
    
    if not IsNull(warframeSuit) and not warframeSuit:IsAbilityIdentifierBlocked(TransferenceSym) then
        warframeSuit:SetAbilityIdentifierBlocked(true, TransferenceSym)
    end
    if not IsNull(operatorSuit) and not operatorSuit:IsAbilityIdentifierBlocked(TransferenceSym) then
        operatorSuit:SetAbilityIdentifierBlocked(true, TransferenceSym)
    end
    
    if instigator:IsA(gLotusOperatorAvatarType) then
        instigator:ForceOperatorTransference()
        while player:GetAvatar() == instigator do
            Sleep(0)
        end
        instigator = player:GetAvatar()
    elseif instigator:IsOperatorTransferenceInProgress() or IsNull(instigator:GetPlayer()) then
        while player:GetAvatar() == instigator do
            Sleep(0)
        end
        player:GetOperatorAvatar():ForceOperatorTransference()
        while player:GetAvatar() ~= instigator do
            Sleep(0)
        end
    end

    local inventoryController = instigator:InventoryControl()
    local boardedShip = inventoryController:GetOnBoardShip()
    
    if not IsNull(boardedShip) then
        while IsNull(instigator:CameraControl()) do
            Sleep(0)
        end
        local postProcess = instigator:CameraControl():ScriptGetCurrentPostProcessInfo()
        local startFade = 0 
        local t = 0
        local val

        instigator:PlayAnimation(exitRailjackAnim, false, Engine.ATMM_ANIMATION_DRIVEN)

        if fadeDelay > 0 then
            local fadeT = fadeDelay
            while fadeT > 0 do
                fadeT = fadeT - DeltaTime()
                Sleep(0)
            end
        end
    
        while t < 1 do
            val = Lerp(0, 1, t)
            postProcess.fade = val
            t = t + DeltaTime() / fadeOutTime
            Sleep(0)
        end
        postProcess.fade = 1

        local shipAvatar = boardedShip:GetAvatarOwner()
        local shipRotation = shipAvatar:GetRotation()
        local shipPosition = shipAvatar:GetPosition() -- Temp; need to transform it

        local spawnPos
        local spawnRot
        local viewRot

        local spawnRelativeEntity = nil
        if not IsNull(exitPointType) then
            spawnRelativeEntity = shipAvatar:GetAttachment(exitPointType)
        end
        
        if IsNull(spawnRelativeEntity) then
            spawnRelativeEntity = boardedShip:GetExitShipRelativeEntity(instigator:GetPosition())
        end
        
        if not IsNull(spawnRelativeEntity) then
            spawnPos = spawnRelativeEntity:GetPosition() 
            spawnRot = spawnRelativeEntity:GetRotation()
            viewRot = spawnRelativeEntity:GetRotation()
        else
            spawnPos = shipAvatar:GetPosition()
            spawnRot = CombineRotations(shipRotation, instigator:GetSimRotation())
            viewRot = CombineRotations(shipRotation, instigator:GetCameraView())
        end

        instigator:DamageControl():GiveTemporaryImmunity(3.0, 0.0)
        instigator:Teleport(spawnPos, spawnRot)
        instigator:SetView(viewRot)
        
        if not IsNull(spawnRelativeEntity) and not IsNull(exitCinematicType) then
            local cinematicParent = spawnRelativeEntity
            if cinematicParent:IsA(gCinematicType) then
                cinematicParent = cinematicParent:GetAttachParent()
            end
            _exitCin = GetInstigatorCinematic(instigator, cinematicParent, exitCinematicType)
        else
            _exitCin = nil
        end
        _pushVeclocity = pushVelocity
        _shipRotation = shipRotation
        instigator:ScriptRunChildScript(Symbol("StartExitSeq"), false)
        if not IsNull(_T.OnExitRailjackSubroutines) then
            _T.OnExitRailjackSubroutines(instigator)
        end
    end
    
    if not IsNull(warframeSuit) then
        warframeSuit:SetAbilityIdentifierBlocked(false, TransferenceSym)
    end
    if not IsNull(operatorSuit) then
        operatorSuit:SetAbilityIdentifierBlocked(false, TransferenceSym)
    end
end


function ExitShip(scriptTrigger, instigator)
    _ExitShip(instigator, exitPushVelocity)
end

function EvaluateReturnToOrbiter(action, avatar)
    if gGameRules:IsBootLevel() then
        -- We can only leave our own RJ
        return gMatchingService:IsSquadHost() or gRegion:IsMaster()
    elseif gGameRules:IsA(gLotusHubGameRulesType) then -- Hangar
        return true
    else
        local shipManager = gGameRules:GetCrewShipManager()
        if IsNull(shipManager) then
            return false
        end

        local ship = shipManager:GetShipForZone(action:GetZone())
        if IsNull(ship) then
            return false
        end
        
        local shipAvatar = ship:GetAvatarOwner()
        if IsNull(shipAvatar) then
            return false
        end
        
        local hds = shipAvatar:GetHyperDriveState()
        if  hds ~= Lotus_Game.CrewShipAvatar_HDS_READY and hds ~= Lotus_Game.CrewShipAvatar_HDS_COOLING_DOWN then
            return false
        end
        
        return true
    end
end

function ReturnToOrbiter(action, avatar)
    local crewship = avatar:InventoryControl():GetOnBoardShip()
    if not IsNull(crewship) then
        local nextBoardPoint = gRegion:FindNearestTagged(BoardShipPositionTag, action:GetPosition())
        if not IsNull(nextBoardPoint) then
            crewship:SetNextBoardPoint(avatar, nextBoardPoint)
        end
    end
    
    if not IsNull(onBoardTransmission) and not IsNull(gGameRules) and not gGameRules:IsA(gLotusAttractModeGameRulesType) then
        gGameRules:GiveTransmissionAsyncToAllPlayers(onBoardTransmission)
    end

    if gGameRules:IsBootLevel() then
        -- We can go back!
        local tubeAction = gRegion:FindFirstTagged(Symbol("RailJackTube"))
        
        -- Clear the parallax offset
        local orbiterZone = tubeAction:GetZone()
        local orbiterBackdrop = orbiterZone:GetBackdrop()
        orbiterBackdrop:GetZoneAttribs():SetParallaxCenter(nil)
        
        if not IsNull(tubeAction) then
            FadeTeleport(avatar, tubeAction)

            if not IsNull(avatar) and not IsNull( avatar:MotionControl()) then
                avatar:MotionControl():SetForceWalk(true)
            end
        end
    elseif gGameRules:IsA(gLotusHubGameRulesType) then -- Hangar
        local refEntity = gRegion:FindNearestTagged(Symbol(hangarExitTag), avatar:GetPosition())
        if not IsNull(refEntity) then
            FadeTeleport(avatar, refEntity)
        else
            print("CREWSHIP: Could not find reference entity for RJ->Dojo exit")
        end
        TellMiniMapStatus(false)
    else
        -- Drop out of the ship
        _ExitShip(avatar, exitPushVelocity)
    end
    
end

function BoardCorpusObelisk(trigger, instigator)   
    if IsNull(shipPlacement) or IsNull(instigator:GetPlayer()) then
        Broadcast("No waypoint set for boarding ship")
        return
    end
    
    local fadeValue = 1.0
    local postProcess = instigator:CameraControl():ScriptGetCurrentPostProcessInfo()
    local startFade = 0 
    local t = 0
    local val
    
    while t < 1 do
        val = Lerp(startFade, fadeValue, t)
        postProcess.fade = val
        t = t + DeltaTime() / 0.5
        Sleep(0)
    end
    postProcess.fade = fadeValue

    instigator:Teleport(shipPlacement:GetPosition(), shipPlacement:GetRotation())
    instigator:SetView(shipPlacement:GetRotation())
    instigator:SetCameraView(shipPlacement:GetRotation())
        
    t = 0
    while t < 1 do
        val = Lerp(fadeValue, startFade, t)
        postProcess.fade = val
        t = t + DeltaTime() / 0.5
        Sleep(0)
    end

    postProcess.fade = startFade
end

local mLevelDestroyed = nil
local mStreamingLayer = 0

function OnLevelDestroyed(levelType, levelLayer)
    if IsNull(levelType) then
        mLevelDestroyed = false
    else
        mLevelDestroyed = true
    end
end

local mLevelCreated = nil
local mWarpTime = 1
local mWarpDistance = 2000

function OnLevelCreated(levelType, levelLayer)
    if IsNull(levelType) then
        mLevelCreated = false
    else
        mLevelCreated = true
    end

    if not IsNull(gGameRules) then 
        if gGameRules:IsBootLevel() == false then
            SetEnableShipMissionFunctions(true)
        else
            SetEnableShipMissionFunctions(false)
        end
    end
end

local function ActivateFlameScript(tag, layer)
    local flameScripts = gRegion:FindTagged(tag)
            
    for i,v in ipairs(flameScripts) do
        local zone = v:GetZone()
        if not IsNull(v:GetZone()) then
            local regionIndex = zone:GetRegionIndex()
            if (regionIndex - 1) == layer then
                v:FirePort("Execute")
            end
        end
    end
end

function Navigate(contextAction, instigator)
--[[
    if not gRegion:IsMaster() then
        return
    end
    
    local shipManager = gGameRules:GetCrewShipManager()
    
    if IsNull(shipManager) then
        return
    end

    local ship = shipManager:GetShipForZone(contextAction:GetZone())

    if IsNull(ship) then
        return
    end
    
    local regionLayer = ship:GetInteriorLayer()
    local shipAvatar = ship:GetAvatarOwner()
    
    if _T.crewShip == nil then
        _T.crewShip = {}
    end
    
    local avInstance = shipAvatar:GetInstance()
    if _T.crewShip[avInstance] == nil then
        _T.crewShip[avInstance] = {}
    end
    
    local crewShipData = _T.crewShip[avInstance]
    
    if not IsNull(shipAvatar) then
        local currentState = shipAvatar:GetHyperDriveState()
        
        if currentState == Lotus_Game.CrewShipAvatar_HDS_READY then
            crewShipData.inHyperSpace = false
            shipAvatar:SetHyperDriveState(Lotus_Game.CrewShipAvatar_HDS_POWERING_UP)
        else
        
            while not crewShipData.inHyperSpace do
                Sleep(0)
            end

            shipAvatar:SetHyperDriveState(Lotus_Game.CrewShipAvatar_HDS_POWERING_DOWN)
        end
    end
    ]]--
end


function BoardHyperDrive(crewShipAvatar)  
    if not gRegion:IsMaster() then
        return
    end

    local ship = crewShipAvatar:InventoryControl():GetActivePowerSuit()
    if IsNull(ship) then
        return
    end

    
    local allPlayersInShip = false
    while not allPlayersInShip do 
        Sleep(0)
        allPlayersInShip = true
        local playerAvatars = gRegion:GetHumanPlayerAvatars()
        for i = 1, #playerAvatars do
            local playerShip = playerAvatars[i]:InventoryControl():GetOnBoardShip()
            if IsNull(playerShip) or playerAvatars[i]:InventoryControl():GetOnBoardShip():GetAvatarOwner() ~= crewShipAvatar then
                allPlayersInShip = false
                break
            end
        end
    end
    crewShipAvatar:SetHyperDriveState(Lotus_Game.CrewShipAvatar_HDS_POWERING_UP)
    
    local instance = gFlashMgr:FindMovie(mNotificationsMovie)
    if not IsNull(instance) then
        instance:Close()
    end
    
end

function PowerUpHyperDrive(crewShipAvatar)
    local ship = crewShipAvatar:InventoryControl():GetActivePowerSuit()
    
    if IsNull(ship) then
        return
    end
    
    if _T.crewShip == nil then
        _T.crewShip = {}
    end
    
    local avInstance = crewShipAvatar:GetInstance()
    if _T.crewShip[avInstance] == nil then
        _T.crewShip[avInstance] = {}
    end
    
    local crewShipData = _T.crewShip[avInstance]
    
    crewShipData.warpPos = crewShipAvatar:GetSimPosition()
    crewShipData.warpRot = crewShipAvatar:GetSimRotation()
    crewShipData.warpZone = crewShipAvatar:GetZone()
    
    local regionLayer = ship:GetInteriorLayer()
    
    ActivateFlameScript(Symbol("FlameOn"), regionLayer)
    
    local shipDriveState = crewShipAvatar:GetHyperDriveState()
    while not IsNull(crewShipAvatar) and shipDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP do
        Sleep(0)
        shipDriveState = crewShipAvatar:GetHyperDriveState()
    end
    
    if shipDriveState ~= Lotus_Game.CrewShipAvatar_HDS_ACTIVE then
        -- Deactivate warp fx if warp out was interrupted
        ActivateFlameScript(Symbol("FlameOff"), regionLayer)
        gRegion:DestroyObject(crewShipData.waypoint)
    end
end

function EnterHyperSpace(crewShipAvatar)
    local ship = crewShipAvatar:InventoryControl():GetActivePowerSuit()
    
    if IsNull(ship) then
        return
    end
    
    if _T.crewShip == nil then
        _T.crewShip = {}
    end
    
    local avInstance = crewShipAvatar:GetInstance()
    if _T.crewShip[avInstance] == nil then
        _T.crewShip[avInstance] = {}
    end
    
    local shipManager = gGameRules:GetCrewShipManager()
    while IsNull(shipManager) do
        shipManager = gGameRules:GetCrewShipManager()
        Sleep(0)
    end
    local crewShipData = _T.crewShip[avInstance]
    
    local greenRoom = ship:GetGreenRoom()
    local greenRoomZone = greenRoom:GetZone()
    
    local regionLayer = ship:GetInteriorLayer()
    local alreadyInGreenRoom = crewShipAvatar:GetZone() == greenRoomZone
    if alreadyInGreenRoom then
        print("CREWSHIP: EnterHyperSpace - inside green room")
    end
    
    if crewShipData.warpPos ~= nil and crewShipData.warpRot ~= nil and not IsNull(crewShipData.warpZone) then

        local warpZoneAttribs = crewShipData.warpZone:GetZoneAttribs()
        crewShipData.waypoint = gRegion:CreateEntity(Type(gWaypointType), crewShipData.warpPos, crewShipData.warpRot)
        if not alreadyInGreenRoom then
            crewShipData.warpZone:SetTransformEntity(crewShipData.waypoint)
            greenRoom:SetBackDropId(warpZoneAttribs:GetZoneId())
            greenRoomZone:SetBackdrop(crewShipData.warpZone)
        end
    end
    
    if gRegion:IsMaster() then
        -- TODO: There might be no harm in having clients do the teleport too
        local greenRoomPosition = greenRoom:GetPosition()
        print("CREWSHIP: Teleport to greenrom: "..tostring(greenRoomPosition))
        crewShipAvatar:Teleport(greenRoom:GetPosition(), greenRoom:GetRotation())
    end
    
    -- Just in case, wait until the ship is inside the green room before proceeding
    while crewShipAvatar:GetZone() ~= greenRoomZone do
        if not gRegion:IsMaster() then
            Sleep(0)
        end
        Sleep(0)
    end
    
    ActivateFlameScript(Symbol("InstantOn"), regionLayer)
    ActivateFlameScript(Symbol("WarpOn"), regionLayer)
    
    local warpOut = Symbol("CREWSHIP_WARP_OUT")
    
    if not alreadyInGreenRoom then
        if not IsNull(crewShipData.waypoint) then
            local waypoint = crewShipData.waypoint
        
            local forwardDirection = waypoint:GetForwardVector()
        
            local t = 0
            while t < mWarpTime do
                Sleep(0)
                t = math.min(mWarpTime, t + DeltaTime())
                local offset = forwardDirection * (mWarpDistance * SmoothStep(t / mWarpTime))
                waypoint:Teleport(crewShipData.warpPos + offset, crewShipData.warpRot)
            end
        
            -- Clear the backdrop
            greenRoom:SetBackDropId(Symbol())
            greenRoomZone:SetBackdrop(nil)
            gRegion:DestroyObject(waypoint)
        end
        
        gGameRules:SignalMultiplayerFence(warpOut)
    end
    
    if gRegion:IsMaster() then
        -- Host waits until everyone has warped out before destroying the level
        gGameRules:SuspendUntilMultiplayerFenceReached(warpOut)
        
        shipManager:SetMissionState(Lotus_Game.CrewShipMgr_MISSION_DESTREAMING)
    end
        
    local missionState = shipManager:GetMissionState()
    while missionState ~= Lotus_Game.CrewShipMgr_MISSION_DESTREAMING and missionState ~= Lotus_Game.CrewShipMgr_MISSION_LOADING do
        Sleep(0)
        missionState = shipManager:GetMissionState()
    end
    
    local regionDestroyed = Symbol("CREWSHIP_REGION_DESTROYED")

    if missionState == Lotus_Game.CrewShipMgr_MISSION_DESTREAMING then
        -- Destroy the old level
        print("CREWSHIP: Destroying "..tostring(mStreamingLayer))
        local levelArgs = Engine.OpenLevelArgs()
        levelArgs.streamingLayer = mStreamingLayer
        levelArgs.streamingMode = GraphicsRes.StreamRegion_InPlace
        levelArgs:SetStreamingCallback("OnLevelDestroyed")
        
        Engine.RemoveStreamedRegion(levelArgs)
        
        while mLevelDestroyed == nil do
            Sleep(0.1)
        end
        
        -- Destroy ship PQ
        for pqLayer = UI_UTIL.PQ_FIRST_LAYER, UI_UTIL.PQ_LAST_LAYER do
            mLevelDestroyed = nil
            levelArgs.streamingLayer = pqLayer
            Engine.RemoveStreamedRegion(levelArgs)
            
            while mLevelDestroyed == nil do
                Sleep(0.1)
            end
        end
        
        mLevelDestroyed = nil
        
        gGameRules:SignalMultiplayerFence(regionDestroyed)
    end
    
    if gRegion:IsMaster() then
        -- Host waits until everyone has finished destroying the level
        gGameRules:SuspendUntilMultiplayerFenceReached(regionDestroyed)
        shipManager:SetMissionState(Lotus_Game.CrewShipMgr_MISSION_LOADING)
        
        if _T.SeamlessRailJackTransition then
            _T.SeamlessRailJackTransition = nil
            gMatchingService:SendHubMissionLoad()

            local timeout = 20 -- don't wait more than 20 seconds for clients to connect
            while timeout > 0 do
                Sleep(0)
                local numSquadMembers = gMatchingService:NumSquadMembers()
                local players = gRegion:GetHumanPlayers()
                
                if numSquadMembers == #players then
                    break
                end
                timeout = timeout - RealDeltaTime()
            end
        end
    end
    
    while true do -- loop until success (this helps handle race conditions for clients)    
        while shipManager:GetMissionState() ~= Lotus_Game.CrewShipMgr_MISSION_LOADING do
            Sleep(0)
        end

        local levelArgs = Engine.OpenLevelArgs()
        levelArgs.streamingLayer = mStreamingLayer
        levelArgs.streamingMode = GraphicsRes.StreamRegion_InPlace
        
        levelArgs:SetStreamingCallback("OnLevelCreated")
        
        --if gRegion:IsMaster() then
            local missionInfo = shipManager:GetNextMission()
            local missionLevel = missionInfo.levelOverride
            levelArgs.level = missionLevel

            LOTUS_NET.AddMissionContextObjects(levelArgs, missionInfo)
            local isPvp = false
            local isArchwing = true
            LOTUS_NET.SetContextObjectsFromSquadLoadOuts(levelArgs, isPvp, isArchwing)

        --end
            
        Engine.StreamRegion(levelArgs)

        while mLevelCreated == nil do
            Sleep(0.1)
        end
        
        local success = mLevelCreated
        mLevelCreated = nil
        
        if success then
            print("CREWSHIP: Resetting level info")
            local levelInfo = gRegion:GetLevelInfo()
            gRegion:DestroyObject(levelInfo)
    
            if gRegion:IsMaster() then
                -- TODO: Clients will need to do this too, so I guess we need to send that encoded string thing to squad members somehow
                local missionInfo = shipManager:GetNextMission()
                gGameRules:SetMission(missionInfo)
            end
            break
        elseif gRegion:IsMaster() then
            -- Host will reset mission state in hopes that we try to choose something else
            shipManager:SetMissionState(Lotus_Game.CrewShipMgr_MISSION_SELECTION)
            
            -- TODO: Re-enable the action
        else
            -- Clients will just try again
        end
    end
    
    local regionCreated = Symbol("CREWSHIP_REGION_CREATED")
    
    gGameRules:SignalMultiplayerFence(regionCreated)
    
    if gRegion:IsMaster() then
        -- Host waits until everyone has finished creating the level
        gGameRules:SuspendUntilMultiplayerFenceReached(regionCreated)
        shipManager:SetMissionState(Lotus_Game.CrewShipMgr_MISSION_READY)
        crewShipAvatar:SetHyperDriveState(Lotus_Game.CrewShipAvatar_HDS_POWERING_DOWN)
    end
end

function TurnOffFlames(crewShipAvatar)   
    local ship = crewShipAvatar:InventoryControl():GetActivePowerSuit()
    
    if IsNull(ship) then
        return
    end
    
    local regionLayer = ship:GetInteriorLayer()
    local shipManager = gGameRules:GetCrewShipManager()
    ActivateFlameScript(Symbol("FlameOff"), regionLayer)    
end

function PowerDownHyperDrive(crewShipAvatar)   
    local ship = crewShipAvatar:InventoryControl():GetActivePowerSuit()
    
    if IsNull(ship) then
        return
    end
    
    if _T.crewShip == nil then
        _T.crewShip = {}
    end
    
    local avInstance = crewShipAvatar:GetInstance()
    if _T.crewShip[avInstance] == nil then
        _T.crewShip[avInstance] = {}
    end
    
    local crewShipData = _T.crewShip[avInstance]
    
    local regionLayer = ship:GetInteriorLayer()
    local shipManager = gGameRules:GetCrewShipManager()
    
    local warpTag = Symbol("WarpInSpot")
    local warpPoint = gRegion:FindFirstTagged(warpTag)
    
    local destinationPoint = nil
    local destinationRotation = nil
    
    if not IsNull(warpPoint) then
        destinationPoint = warpPoint:GetPosition()
        destinationRotation = warpPoint:GetRotation()
    else
        destinationPoint = ZERO_VECTOR
        destinationRotation = Rotation()
    end
    
    local forwardDirection = RotateVector(Vector(0, 0, 1), destinationRotation)

    local waypoint = gRegion:CreateEntity(Type(gWaypointType), destinationPoint, destinationRotation)
    local newZone = nil
    
    while IsNull(newZone) do
        Sleep(0)
        newZone = waypoint:GetZone()
    end

    local newZoneAttribs = newZone:GetZoneAttribs()
    local greenRoom = ship:GetGreenRoom()
    newZone:SetTransformEntity(waypoint)
    greenRoom:SetBackDropId(newZoneAttribs:GetZoneId())
    local greenRoomZone = greenRoom:GetZone()
    greenRoomZone:SetBackdrop(newZone)
    
--    ActivateFlameScript(Symbol("FlameOff"), regionLayer)
    ActivateFlameScript(Symbol("WarpOff"), regionLayer)
    
    local t = mWarpTime
    while t > 0 do
        Sleep(0)
        t = math.max(0, t - DeltaTime())
        local offset = forwardDirection * (mWarpDistance * SmoothStep(t / mWarpTime))
        waypoint:Teleport(destinationPoint - offset, destinationRotation)
    end
    
    local warpIn = Symbol("CREWSHIP_WARP_IN")
    
    gGameRules:SignalMultiplayerFence(warpIn)

    local proceduralLevelTrigger = gRegion:FindFirstTagged(Symbol("ProceduralLevelTrigger"))

    if not IsNull(proceduralLevelTrigger) then
        proceduralLevelTrigger:RunScripts()        
    end
    
    if gRegion:IsMaster() then
        -- Host waits until everyone has finished creating the level
        gGameRules:SuspendUntilMultiplayerFenceReached(warpIn)

        shipManager:SetMissionState(Lotus_Game.CrewShipMgr_MISSION_ACTIVE)
        ship:TeleportShipToEntity(waypoint)
        crewShipAvatar:SetHyperDriveState(Lotus_Game.CrewShipAvatar_HDS_COOLING_DOWN)
    end
end

function HyperDriveCommentVisibility(comment)
    local commentZone = comment:GetZone()
    local shipManager
    local ship
    local shipAvatar
    while IsNull(shipAvatar) do
        if IsNull(shipManager) and not IsNull(gGameRules) then
            shipManager = gGameRules:GetCrewShipManager()
        end
        if not IsNull(shipManager) then
            ship = shipManager:GetShipForZone(commentZone)
        end
        if not IsNull(ship) then
            shipAvatar = ship:GetAvatarOwner()
        end
        if IsNull(shipAvatar) then
            Sleep(0)
        end
    end

    while not IsNull(shipAvatar) do
        comment:SetVisibility(shipAvatar:GetHyperDriveState() == hyperDriveState)
        Sleep(0)
    end
end

local function _CheckGameRules()
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    return gGameRules:IsBootLevel()
end

function CheckGameRules(entity)
    if _CheckGameRules(entity) then
        entity:Disable()
    end
end

function ExecuteInAttractMode(entity)
    if _CheckGameRules() then
        local shipManager = gGameRules:GetCrewShipManager()
        if not IsNull(shipManager) then
            local ship = nil
            while IsNull(ship) do
                ship = shipManager:GetShipForZone(entity:GetZone())
                Sleep(0)
            end
        end

        entity:FirePort("Execute")
    end
end

function EnableIfHasShip(entity)
    while IsNull(gRegion:GetLocalPlayer()) do
        Sleep(0)
    end
    
    entity:Disable()
    while true do
        local enable = false --gFlashMgr:GetConfigBool("Engine.DeveloperMode")
        
        if not IsNull(gGameData) then
            local loadOut = gGameData:GetLoadOut()
            local crewShipLoadOut = loadOut.mCrewShipLoadOut
            
            --only enable if we have installed the key and can run missions
            if crewShipLoadOut.mShip.mItemId.mId ~= Lotus_Game.InvalidItemID and
                gGameData:HasShipFeature(LOTUS_UTIL.SF_RAILJACK_KEY)
            then
                enable = true
            end
        end
        
        if enable then
            entity:Enable()
            break
        end
        Sleep(1.0)
    end
end

local _boardingAction = nil
local _boardShipAvatar = nil
local _boardShipType = nil
local _boardShipPosition = nil

function BoardShipSequence(instigator)
    local cachedBoardingAction = _boardingAction
    local cachedBoardShipAvatar = _boardShipAvatar
    local cachedBoardShipType = _boardShipType
    local cachedBoardShipPosition = _boardShipPosition
    local invulnTime = boardShipInvulnTime
    if IsNull(cachedBoardShipAvatar) or IsNull(cachedBoardShipPosition) then
        return
    end
    
    if cachedBoardShipAvatar:IsA(gBaseAvatarType) then
        if cachedBoardShipAvatar:IsKilled() then
            return
        end
    end

    local shipInventory = cachedBoardShipAvatar:InventoryControl()
    if IsNull(shipInventory) then
        shipInventory = cachedBoardShipAvatar:GetAttachParent():InventoryControl()
    end

    local fromArchwingCannon = false
    if cachedBoardShipType == Lotus_Game.CrewShipAvatar_BST_AW_CANNON then
        fromArchwingCannon = true
        invulnTime = boardShipFromAWCannonInvulnTime
    end
    
    local fromDojo = false
    if cachedBoardShipType == Lotus_Game.CrewShipAvatar_BST_FROM_DOJO then
        fromDojo = true
        TellMiniMapStatus(true)
    end

    if not fromDojo then
        if RJ_UTIL.IsRailjackSeqPlaying(instigator, CrewShipEnterSeq) then
            return
        end
        RJ_UTIL.SetRailjackSeqPlaying(instigator, CrewShipEnterSeq)
    end

    local crewShip = shipInventory:GetActivePowerSuit()

    local isLocalAvatar = instigator:ReplicaLocallyControlled()

    if cachedBoardShipType == Lotus_Game.CrewShipAvatar_BST_ENTER_ACTION or cachedBoardShipType == Lotus_Game.CrewShipAvatar_BST_ENTER_ACTION_SIMPLE then
        local enterCin = nil
        if not fromDojo and not fromArchwingCannon then
            enterCin = GetInstigatorCinematic(instigator, cachedBoardingAction, enterCinematicType)
            if not IsNull(enterCin) then
                PlayCinematic(instigator, enterCin, false)
            end
        end
    end

    local t = 0
    local val
    
    if IsNull(instigator) then
        return
    end
    
    -- check if cachedBoardShipAvatar is destroyed somehow
    if not IsNull(cachedBoardShipAvatar) and not IsNull(cachedBoardShipPosition) and not cachedBoardShipAvatar:IsKilled() then
        local crewShip = cachedBoardShipAvatar:InventoryControl():GetActivePowerSuit()
        
        if isLocalAvatar or gRegion:IsMaster() then        
            instigator:Teleport(cachedBoardShipPosition:GetPosition(), cachedBoardShipPosition:GetRotation())
        end

        instigator:InventoryControl():SetOnBoardShip(crewShip)

        local dmgCtrl = instigator:DamageControl()
        if not IsNull(dmgCtrl) then
            if dmgCtrl:HasTemporaryImmunity() then
                dmgCtrl:ChangeTemporaryImmunityDuration(invulnTime)
            else
                dmgCtrl:GiveTemporaryImmunity(invulnTime, 0)
            end
        end

        print("Giving " .. instigator:GetFullName() .. " immunity for " .. invulnTime .. " seconds for boarding " .. crewShip:GetFullName())

        if fromArchwingCannon then
            instigator:ScriptRunChildScript(Symbol("PlayAWCannonCinematic"), false)
        end
    end

    -- return for non local
    if not isLocalAvatar then
        t = 0
        while not RJ_UTIL.IsPlayerAvatarOnShip(instigator, crewShip) and t < 5 do -- wait till client is teleported in ship
            t = t + DeltaTime()
            Sleep(0)
        end
        if not fromDojo then
            RJ_UTIL.ResetRailjackSeqPlaying(instigator, CrewShipEnterSeq)
        end
        return
    end

    --Ugh.. so it seems that SetCameraView needs 2 frames before it can be set after a teleport, otherwise camera view will not be correct - Evgenii is investigating
    Sleep(0)    
    Sleep(0)
    if IsNull(instigator) then 
        return
    end
    
    if not IsNull(cachedBoardShipPosition) then
        instigator:SetCameraView(cachedBoardShipPosition:GetRotation())
    end

    -- So that SimPosition is refreshed
    Sleep(0)

    if IsNull(instigator) then
        return
    end

    local cameraControl = instigator:CameraControl()
    local postProcess = nil
    if not IsNull(cameraControl) then
        postProcess = cameraControl:ScriptGetCurrentPostProcessInfo()
    else
        print("CameraControl is NULL for player:" .. instigator:GetFullName())
    end

    if not fromDojo and not fromArchwingCannon then
        instigator:PlayAnimation(enterAnim, false, Engine.ATMM_ANIMATION_DRIVEN)
        if not IsNull(postProcess) then
            t = 0
            local fadeTime = 0.2
            while t < 1 do
                val = Lerp(1, 0, t)
                postProcess.fade = val
                t = t + DeltaTime() / fadeTime
                Sleep(0)
            end
            postProcess.fade = 0
        end
        
        gGameRules:GiveTransmissionAsyncToAllPlayers(onBoardTransmission)
    end

    if not fromDojo and not IsNull(instigator) then
        RJ_UTIL.ResetRailjackSeqPlaying(instigator, CrewShipEnterSeq)
    end
end

local function _BoardShip(shipAvatar, instigator, enterRailJackAction, boardShipType)
    if not IsNull(shipAvatar) and shipAvatar:IsA(gBaseAvatarType) then
        if shipAvatar:IsKilled() then
            return
        end
    end
    
    local shipInventory = shipAvatar:InventoryControl()
    if IsNull(shipInventory) then
        shipInventory = shipAvatar:GetAttachParent():InventoryControl()
    end
    
    local crewShip = shipInventory:GetActivePowerSuit()
    local boardPosition = crewShip:GetBoardShipPositionForPlayer(instigator)

    -- If going from dojo, spawn at a predefined point
    local fromDojo = false
    if boardShipType == Lotus_Game.CrewShipAvatar_BST_FROM_DOJO then
        boardPosition = gRegion:FindFirstTagged(Symbol("BoardShipPositionDojo"))
        fromDojo = true
    end
    
    if IsNull(boardPosition) or boardPosition:IsA(gCinematicType) and boardPosition:IsPlaying() then
        return -- sorry bub
    end

    _boardingAction = enterRailJackAction
    _boardShipAvatar = shipAvatar
    _boardShipType = boardShipType
    _boardShipPosition = boardPosition

    instigator:ScriptRunChildScript(Symbol("BoardShipSequence"), false)
end

function BoardShip(shipAvatar, instigator, boardShipType)
    _BoardShip(shipAvatar, instigator, nil, boardShipType)
end

function BoardRailjackAction(enterRailJackAction, instigator)
    local shipAvatar = enterRailJackAction:GetAttachParent()
    if not IsNull(shipAvatar) and shipAvatar:IsA(gCrewShipAvatarType) then
        _BoardShip(shipAvatar, instigator, enterRailJackAction, Lotus_Game.CrewShipAvatar_BST_ENTER_ACTION)
    end
end

function SimpleBoardPointOfInterest(action, instigator)
    local shipAvatar = gRegion:FindNearestTagged(pointOfInterestTag, action:GetPosition())
    if not IsNull(shipAvatar) and shipAvatar:IsA(gCrewShipAvatarType) then
        _BoardShip(shipAvatar, instigator, action, Lotus_Game.CrewShipAvatar_BST_ENTER_ACTION_SIMPLE)
    end
end

function SimpleBoardShipFromPOI(action, instigator)
    local crewShipMgr = gGameRules:GetCrewShipManager()
    local poiShip = crewShipMgr:GetShipForZone(action:GetZone())
    local poiAvatar = poiShip:GetAvatarOwner()
    local distance = math.huge
    local shipAvatar = nil
    
    for i=1,5 do
        local ships = crewShipMgr:GetShips(false)
        for i, ship in ipairs(ships) do
            if ship:IsA(boardShipType) then
                local avatar = ship:GetAvatarOwner()
                local distToPoi = avatar:DistanceToEntity(poiAvatar)
                if distToPoi < distance then
                    distance = distToPoi
                    shipAvatar = avatar
                end
            end
        end
        
        if IsNull(shipAvatar) then
            Sleep(3)
        else
            break
        end
    end
    
    if not IsNull(shipAvatar) and shipAvatar:IsA(gCrewShipAvatarType) then
        _BoardShip(shipAvatar, instigator, action, Lotus_Game.CrewShipAvatar_BST_ENTER_ACTION_SIMPLE)
    end
end

function SimpleBoardShip(action, instigator)
    local shipAvatar = action:GetAttachParent()
    if not IsNull(shipAvatar) and shipAvatar:IsA(gCrewShipAvatarType) then
        _BoardShip(shipAvatar, instigator, action, Lotus_Game.CrewShipAvatar_BST_ENTER_ACTION_SIMPLE)
    end
end

function HackBoardRailjackAction(instigator, result, hackEnterRailJackAction)
    if result == nil or result == 1 then
        local shipAvatar = hackEnterRailJackAction:GetAttachParent()
        if not IsNull(shipAvatar) and shipAvatar:IsA(gCrewShipAvatarType) then
            _BoardShip(shipAvatar, instigator, hackEnterRailJackAction, Lotus_Game.CrewShipAvatar_BST_ENTER_ACTION)
            local crewship = shipAvatar:InventoryControl():GetActivePowerSuit()
            if not IsNull(crewship) then
                crewship:EnableClosestEnterAction(hackEnterRailJackAction:GetPosition(), true, true)
            end
        end
    end
end

function CanBoardShip(enterRailJackAction, instigator)
    local avatar = enterRailJackAction:GetAttachParent()
    if not IsNull(avatar) and avatar:IsA(gBaseAvatarType) then
        if avatar:IsKilled() then
            return false
        end
    end
    return true
end

local function _WaitForStreaming()
    while not gClient:IsStreamingLevel() do
        Sleep(0)
    end

    while gClient:IsStreamingLevel() do
        Sleep(0)
    end

end

function RailjackSoakLoop()

    print("RJ SOAK: Start")

    local rj_nodes =
    {
        Symbol("CrewBattleNode501"),
        Symbol("CrewBattleNode502"),
        Symbol("CrewBattleNode503"),
        Symbol("CrewBattleNode504"),
        Symbol("CrewBattleNode505"),
        --Symbol("CrewBattleNodeDojo")
    }

    local hasTunnel = false
    while true do

        if gGameRules:GameStarted() and not gClient:IsStreamingLevel() then

            _WaitForStreaming()
            print("RJ SOAK: Streaming done (1)")

            -- Wait for actual level
            if hasTunnel then
                _WaitForStreaming()
            end

            print("RJ SOAK: Streaming done (2)")

            Sleep(20)

            local node = rj_nodes[math.random(1, #rj_nodes)]
            --local mission = gGameRules:GetCurrentStarChart():BuildMissionForLocation(node):Copy()
            --local nextLevel = tostring(mission.levelOverride:GetFullName())
            local shipManager = gGameRules:GetCrewShipManager()

            _T.RailJackNextMissionNode = node
        
            local travelSector = gGameRules:GetCurrentStarChart():GetNodeForMission(Symbol("CrewShipGenericTunnel"))
            shipManager:SetNextMission(travelSector.mission)

            print("RJ SOAK: Streaming next "..tostring(node))
            hasTunnel = true
        end

        Sleep(1)
    end
end

function AWCannonDamageHull(cinematic)
    local avatar = cinematic:GetInstigatorAvatar()
    if not IsNull(avatar) then
        local boardedShip = avatar:InventoryControl():GetOnBoardShip()
        if not IsNull(boardedShip) then
            local damagePortForwarder = RJ_UTIL.FindFirstTaggedOnShip(Symbol("AWCannonDamagePort"), boardedShip)
            if not IsNull(damagePortForwarder) then
                damagePortForwarder:FirePort("TriggerPort")
            else
                if gRegion:IsMaster() then
                    print("Cannont find portforwarder with AWCannonDamagePort Tag inside ship interior")
                else
                    print("Cannont find portforwarder with AWCannonDamagePort Tag inside ship interior. Set Replication to NEVER")
                end
            end

        end
    end
end

function RefillRevivesAndAmmo()
    if gRegion:IsMaster() then
        local humanPlayers = gRegion:GetHumanPlayers()
        
        -- Reset a bunch of stuff for players between missions
        for i,player in ipairs(humanPlayers) do
            local av = player:GetAvatar()
            
            if not IsNull(av) then
                av:SetNumRevivesUsed(0)
            
                if av:IsKilled() or av:IsDeadType() then
                    gGameRules:RespawnPlayer(player, false)
                else
                    -- revives
                    av:InstantRevive()
                
                    -- ammo
                    local ic = av:InventoryControl()
                    ic:GiveMaxAmmo()
                    for slot=0,Engine.INVALID do
                        local weapon = ic:GetWeaponInSlot(slot)
                        if not IsNull(weapon) then
                            weapon:SetAmmoInClip(weapon:GetClipSize())
                        end
                    end
                    --sentinel
                    ic:ReviveSentinelIfNecessary()
                end
            end
        end
    end
end