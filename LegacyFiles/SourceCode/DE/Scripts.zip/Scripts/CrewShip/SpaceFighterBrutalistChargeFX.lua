FxType = Type()
FxAttachBone = Symbol()
FxAttachOffset = Vector()

function CreateFX(attachment)
    local weapon = attachment:GetWeapon()
    if IsNull(weapon) then
        return
    end
    
    local avatar = weapon:GetAvatarOwner()
    if IsNull(avatar) or avatar:IsKilled() then
        return
    end
    
    local fx = avatar:Attach(FxType, FxAttachBone, FxAttachOffset, ZERO_ROTATION, avatar)
    if IsNull(fx) then
        return
    end


end

function DestroyFX(attachment)
    local weapon = attachment:GetWeapon()
    if IsNull(weapon) then
        return
    end
    
    local avatar = weapon:GetAvatarOwner()
    if IsNull(avatar) or avatar:IsKilled() then
        return
    end
    
    if IsNull(avatar) then
        return
    end
    
    local effects = avatar:GetAllAttachments(FxType)
    
    if IsNull(effects) then
        return
    end
    
    for i = #effects, 1, -1 do
        local fx = effects[i]
        if not IsNull(fx) then
            fx:Destroy()
        end
    end

end