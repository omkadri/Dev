captureAgentType = Type()
captureAvatarType = WeakResource()
captureActionType = Type()
captureTargetMarkerType = Resource()

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local CREW_SHIP = require "Lotus.Scripts.Libs.CrewShipLib"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"

--LOC
local NV_MODE_STATE = Symbol("MODE_STATE")
local NV_ESCAPE_STAGE = Symbol("ESCAPE_STAGE")

local sDamageTime = Symbol("DamageTimer")

local findTargetLoc = "/Lotus/Language/EidolonPlains/CaptureFindTarget"
local pursueTargetLoc = "/Lotus/Language/EidolonPlains/CapturePursueTarget"
local captureTargetLoc = "/Lotus/Language/EidolonPlains/CaptureTarget"
local missionNameLoc = nil

local DAMAGE_TIME = 20
local TARGET_LEVEL_MULTIPLIER = 1.2
local ESCAPE_DELAY = 30

local mGameRules = nil
local mAiDir = nil
local mHint = nil
local mHintPos = nil
local mHintActivationRadius = 0
local mDeactivateRadius = 0
local mParentHint = nil
local mTransmissionSet = nil

local reinforcementDelay = 2

--STATES
local INVALID = 0
local STARTED = 1
local WAIT_FOR_ALERT = 2
local WAIT_FOR_DAMAGE = 3
local WAIT_FOR_CAPTURE = 4
local ESCAPE = 5
local mModeState = INVALID
local SetModeState

local mPlayers = {}
local mCaptured = false
local mCaptureAgent = nil
local mCaptureAvatar = nil
local mEscapeButton = nil
local mStartHealthPercentage = 100
local mTimerMgr = nil

function Evaluate(hint)
    local spawn = gRegion:FindNearestTagged(Symbol("CaptureAgentSpawn"), hint:GetPosition())
    if spawn:DistanceToEntity(hint) > hint:GetActivationRadius() then
        return 0
    else
        return 1
    end
end

local function FindValidSpawns(spawnControls, zoneTag)
    local results = {}
    for i = 1, #spawnControls do
        local zone = spawnControls[i]:GetZone()
        local tag = zone:GetTag()
        if spawnControls[i]:IsEnabled() and tag == zoneTag then
            table.insert(results, spawnControls[i])
        end
    end
    return results
end

local function SelectEscapePoint(points)
    local bestPoint = points[RandomInt(1, #points)]
    local best = 0
    for i, point in ipairs(points) do        
        if not IsNull(point:GetZone()) then
            local playersFurther = 0
            for i, player in ipairs(mPlayers) do
                if point:DistanceToEntity(mCaptureAvatar) < point:DistanceToEntity(player:GetAvatar()) then
                    playersFurther = playersFurther + 1
                end
            end
            
            if playersFurther == #mPlayers then
                return point
            elseif playersFurther > best then
                bestPoint = point
                best = playersFurther
            end
        end
    end
    
    return bestPoint
end

local function StartEscape()
    if mModeState == WAIT_FOR_ALERT then
        SetModeState(ESCAPE)
    end
end

local function OnModeStateChanged()
    if mModeState == STARTED then
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("CampActivated"))
    
    elseif mModeState == WAIT_FOR_ALERT then
        mTimerMgr:AddTimer(ESCAPE_DELAY, StartEscape, false)
        LANDSCAPE.SetObjective("<MISSION_MARKER_ATTACK>", _G.UIColor_Red, findTargetLoc)
        
    elseif mModeState == WAIT_FOR_DAMAGE then
        mStartHealthPercentage = mCaptureAvatar:GetHealthPercentage()
        if not mGameRules:HasMissionTimer(sDamageTime) then
            mGameRules:SetMissionTimer(sDamageTime, Symbol(), DAMAGE_TIME, false, true, false)
            mGameRules:SetMissionTimerSurvivesMigration(sDamageTime, true)
        end
        
        LANDSCAPE.SetObjective("<MISSION_MARKER_ATTACK>", _G.UIColor_Red, pursueTargetLoc)
    
    elseif mModeState == ESCAPE then        
        LANDSCAPE.SetObjective("<MISSION_MARKER_ATTACK>", _G.UIColor_Red, pursueTargetLoc)
        
        local agents = mParentHint:GetRegisteredAgents()
        for i, agent in ipairs(agents) do
            agent:StormTarget(mCaptureAvatar)
        end
        mCaptureAgent:StormTarget(mEscapeButton)
        mGameRules:RemoveMissionTimer(sDamageTime)
    elseif mModeState == WAIT_FOR_CAPTURE then
        LANDSCAPE.SetObjective("<MISSION_MARKER_ATTACK>", _G.UIColor_Red, captureTargetLoc)
        mCaptureAvatar:Attach(captureActionType, EMPTY_SYMBOL)
    end
end

SetModeState = function(newState)
    if mModeState ~= newState then
        mModeState = newState
        mGameRules:SetNetPersistentVar(NV_MODE_STATE, newState)
        OnModeStateChanged()
        print("DynamicCapture.lua::SetModeState - New State: " .. mModeState)
    else
        print("DynamicCapture.lua::SetModeState - trying to set mode to state we're already in")
    end
end

local function PlayCaptureAnimation(playerAv)
    
end

local function FindClosestCaptureSpawn(hint, captureSpawnControls)
    local closestDistance = FLT_MAX
    local closestCaptureControl = nil
    for i, spawnControl in ipairs(captureSpawnControls) do
        local dist = spawnControl:DistanceToEntity(hint)
        if dist < closestDistance then
            closestDistance = dist
            closestCaptureControl = spawnControl
        end
    end
    
    if not IsNull(closestCaptureControl) then
        return closestCaptureControl
    else
        return captureSpawnControls[RandomInt(1, #captureSpawnControls)]
    end
end

local function Initialize(hint)
    mGameRules = gGameRules
    mParentHint = hint:GetRootParentEncounterHint()
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    mHint = hint
    mHintPos = hint:GetPosition()
    mHintActivationRadius = hint:GetActivationRadius()
    mDeactivateRadius = hint:GetDeactivationRadius()
    
    local template = hint:GetCurrentEncounterTemplate()
    mTransmissionSet = template:GetTransmissionSet()
    missionNameLoc = template:GetLocTag():c_str()

    mAiDir:SetReinforcementDroneDeployAllowed(false)
    
    gRegion:AddPlayersChangedBasicCallback("OnPlayersChanged")
    mPlayers = gRegion:GetHumanPlayers()
    
    local netState = mGameRules:GetNetPersistentVar(NV_MODE_STATE, STARTED)
    
    local spawnControls = gRegion:FindTagged(Symbol("CaptureSpawn"))
    local captureSpawnControls = FindValidSpawns(spawnControls, Symbol("Intermediate"))
    local closestCaptureSpawnControl = FindClosestCaptureSpawn(hint, captureSpawnControls)
    local spawn = closestCaptureSpawnControl:GetSpawnPoints()[1]
    
    -- Find nearest escape button
    local escapeButtons = gRegion:FindTagged(Symbol("EscapeButton"))
    local buttonDist = FLT_MAX
    for i = 1, #escapeButtons do -- Find closest escape button along nav
        if escapeButtons[i]:IsEnabled() then
            mAiDir:SetObjective(escapeButtons[i])
            local targetDistToObjective = mAiDir:GetDistanceToObjective(mCaptureAvatar)
            if targetDistToObjective < buttonDist then
                buttonDist = targetDistToObjective
                mEscapeButton = escapeButtons[i]
            end
        end
    end    

    mCaptureAvatar = gRegion:FindNearest(captureAvatarType, mHintPos, FLT_MAX)
    if IsNull(mCaptureAvatar) then
        local level = mAiDir:GetScaledEnemyLevel(mParentHint:GetPosition())
        local agent = mAiDir:CreateAgent(captureAgentType, spawn, Symbol(), level * TARGET_LEVEL_MULTIPLIER)
        if not IsNull(agent) then
            mCaptureAgent = agent
            mCaptureAvatar = agent:GetAvatar()
            mCaptureAgent:SetIsIgnoredByAiDirector(true)
            mCaptureAgent:StormTarget(mEscapeButton)
            print("DynamicCapture.lua::Initialize - Spawned target at " .. spawn:GetFullName())
        end
    else
        mCaptureAgent = mCaptureAvatar:GetAgent()
        mCaptureAvatar:Attach(captureTargetMarkerType, Symbol("GAME_C1_SPINE1"))
    end
    hint:RegisterAgent(mCaptureAgent)
        
    local dv = gRegion:FindNearest(gDefenseVolumeType, mHintPos, mHintActivationRadius)
    mCaptureAgent:SetDefenseVolume(dv, true)
    
    if netState <= WAIT_FOR_ALERT then
        hint:RegisterWarningEveryPlayerLeavingCallback("PlayersLeaving", Symbol("LeavingCB"))
        hint:RegisterPlayerArrivedCallback("PlayersReturning", Symbol("ReturningCB"))
    end
    
    mTimerMgr = TIMER.CreateTimerMgr()
    LANDSCAPE.AddObjectiveTracker(LOTUS_UTIL.HT_LABEL)
    
    SetModeState(netState)
    
    hint:SetEncounterStatus(Npc.ES_ACTIVE)
end

function CaptureStart(hint)
    Initialize(hint)
    
    local reinforcementTimer = 0
    while hint:GetEncounterStatus() < Npc.ES_SUCCEEDED do
        if mModeState == STARTED then
            if mParentHint:GetEncounterStatus() >= Npc.ES_ACTIVE or not mParentHint:IsActive() then   --finished spawning camp?
                SetModeState(WAIT_FOR_ALERT)
            end
        elseif mModeState == WAIT_FOR_ALERT then
            if mCaptureAvatar:IsPreDeath() then
                SetModeState(WAIT_FOR_CAPTURE)
            elseif not IsNull(mCaptureAgent) and mCaptureAgent:IsAlerted() then
                SetModeState(ESCAPE)
            elseif hint:ShouldShutDown() then
                LANDSCAPE.PlayersAbandonedObjective()
                hint:SetEncounterStatus(Npc.ES_FAILED)
            end
        elseif mModeState == WAIT_FOR_DAMAGE then
            if mCaptureAvatar:IsPreDeath() then
                SetModeState(WAIT_FOR_CAPTURE)
            end
        
            if 
                mCaptureAvatar:GetHealthPercentage() < mStartHealthPercentage - 0.2 or
                mGameRules:GetMissionTimeLeft(sDamageTime) <= 0
            then
                SetModeState(ESCAPE)
            end
        elseif mModeState == ESCAPE then
            if mCaptureAvatar:IsPreDeath() then
                SetModeState(WAIT_FOR_CAPTURE)
            else
                local distance = mCaptureAvatar:DistanceToEntity(mEscapeButton)
                
                if reinforcementTimer >= reinforcementDelay then
                    CREW_SHIP.SpawnReinforcementsForHint(hint, 3, 100, true, false, true, mCaptureAvatar, false)
                    reinforcementTimer = 0
                else
                    reinforcementTimer = reinforcementTimer + DeltaTime()
                end
            end
        elseif mModeState == WAIT_FOR_CAPTURE then
            if IsNull(mCaptureAvatar) then
                mCaptured = true
            end
        end
        
        mTimerMgr:Update(DeltaTime())
        
        if mCaptured then
            hint:SetEncounterStatus(Npc.ES_SUCCEEDED)
        elseif 
            mModeState > WAIT_FOR_ALERT and 
            not IsNull(mCaptureAvatar) and 
            IsNull(gRegion:FindNearestPlayerAvatar(mCaptureAvatar:GetPosition(), 200)) 
        then
            mCaptureAvatar:Destroy()
            hint:SetEncounterStatus(Npc.ES_FAILED)
        end
        
        Sleep(0)
    end

    LANDSCAPE.CleanUpDynamicMission(mParentHint)
    mGameRules:RemoveMissionTimer(sDamageTime)
    mGameRules:ClearNetPersistentVar(NV_ESCAPE_STAGE)
    
    if not IsNull(mCaptureAgent) then
        local marker = mCaptureAvatar:GetAttachment(gBaseMarkerInfoType)
        if not IsNull(marker) then
            marker:Destroy()
        end
        mCaptureAvatar:SendStartDissolve(1)
        Sleep(1)
        mCaptureAvatar:Destroy()
    end
end

function OnPlayersChanged()
    mPlayers = gRegion:GetHumanPlayers()
end

function PlayersLeaving()
    if mModeState <= WAIT_FOR_ALERT then
        LANDSCAPE.PlayersAbandoningObjective(mHint, true)
    end
end

function PlayersReturning()
    if mModeState <= WAIT_FOR_ALERT then
        LANDSCAPE.PlayersAbandoningObjective(mHint, false)
    end
end
