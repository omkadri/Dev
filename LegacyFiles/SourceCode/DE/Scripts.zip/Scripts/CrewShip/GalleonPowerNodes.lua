offMat = Resource()
decoType = WeakResource()

local NV_GALLEON_NODE_COUNT = Symbol("GALLEON_NODE_COUNT")

local function IncrementNetVar(s)
    local val = gGameRules:GetNetPersistentVar(s, 0)
    val = val + 1
    gGameRules:SetNetPersistentVar(s, val)
end


function GalleonPowerNode(entity)
    while IsNull(gGameRules) or not gGameRules:IsA(gLotusGameRulesType) do
        Sleep(0)
    end
    Sleep(0)
    local deco = entity:GetAttachment(decoType)
    while not IsNull(deco) and deco:GetHealth() > 0 do
        Sleep(0.3)
    end
        
    if gRegion:IsMaster() then
        IncrementNetVar(NV_GALLEON_NODE_COUNT)
    end
    
    entity:SetOverrideMaterial(2, offMat, false)
    
end