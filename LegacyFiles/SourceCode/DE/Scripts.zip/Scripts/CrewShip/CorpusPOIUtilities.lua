--Lightning Hazard
lightningDamageTrigger = Instance()
lightningPickupTrigger = Instance()
lightningForcedropTrigger = Instance()
lightningBeamFX = Instance()
light = Instance()
lightningSurfaceFX = Instance()
lightningStrikeFX = Instance()
strikeRiskDelay = 2
strikeTime = 5
strikeCooldown = 5
stallSpeed = 3
stallTime = 2
-- Cell charging
energyCellType = Resource()
energyCellEmptyType = Resource()
energyCellEmptySkelAttachmentType = Resource()
playerType = Resource()
minCellsPerLevel = 0
stationTrigger = Instance()
contextAction = Instance()
--Exterior Lightning
exteriorLightningWaypoint = Instance()
exteriorLightningFX = Instance()
--Camera Shake
local shakeRadius = 30
shakeMultiplier = 15
local shakeTime = 0.5
local shakeTimeMod = 2

local function StartCameraShake(pos)
    local t = 0
    local levelInfo = gRegion:GetLevelInfo()
    local player = gRegion:GetLocalPlayerAvatar()
    
    if IsNull(player) then
        return
    end
    
    if Length(player:GetSimPosition()-pos) > shakeRadius then
        return
    end

    while t < shakeTime  do
        levelInfo.postProcess.viewShake.mShakeAmbient = Abs(Sin(t*shakeTimeMod)) * shakeMultiplier
        t = t + DeltaTime()
        Sleep(0)
    end
    
    levelInfo.postProcess.viewShake.mShakeAmbient = 0
end

local function SpawnLightningOmen(pos)
    if not IsNull(light) then
        light:SetPosition(pos)
        light:TurnOn()
    end
    if not IsNull(lightningSurfaceFX) then
        lightningSurfaceFX:SetPosition(pos)
        lightningSurfaceFX:SetVisibility(true)
    end
end

local function SpawnLightningHazard(pos)
    if not IsNull(lightningDamageTrigger) then
        lightningDamageTrigger:Enable()
        lightningDamageTrigger:SetPosition(pos)
    end
    if not IsNull(lightningPickupTrigger) then
        lightningPickupTrigger:Enable()
        lightningPickupTrigger:SetPosition(pos)
    end
    if not IsNull(lightningForcedropTrigger) then
        lightningForcedropTrigger:Enable()
        lightningForcedropTrigger:SetPosition(pos)
    end
    if not IsNull(lightningBeamFX) then
        lightningBeamFX:Enable()
        lightningBeamFX:SetEndPoint(pos)
    end
    if not IsNull(lightningStrikeFX) then
        lightningStrikeFX:Enable()
        lightningStrikeFX:SetPosition(pos)
    end
end

local function SpawnLightningHazardMover(pos)
    if not IsNull(light) then
        light:TurnOn()
    end
    if not IsNull(lightningSurfaceFX) then
        lightningSurfaceFX:SetVisibility(true)
    end
    if not IsNull(lightningDamageTrigger) then
        lightningDamageTrigger:Enable()
    end
    if not IsNull(lightningBeamFX) then
        lightningBeamFX:Enable()
        lightningBeamFX:SetEndPoint(pos)
    end
    if not IsNull(lightningStrikeFX) then
        lightningStrikeFX:Enable()
    end
end

local function DespawnLightningHazard()

    if not IsNull(lightningDamageTrigger) then
        lightningDamageTrigger:Disable()
    end

    if not IsNull(lightningPickupTrigger) then
        lightningPickupTrigger:Disable()
    end
    
    if not IsNull(lightningForcedropTrigger) and lightningForcedropTrigger:IsEnabled() then
        lightningForcedropTrigger:Disable()
    end
    
    if not IsNull(lightningDamageTrigger) then
        lightningDamageTrigger:Disable()
    end
    
    if not IsNull(light) then
        light:TurnOff()
    end
    
    if not IsNull(lightningBeamFX) then
        lightningBeamFX:Disable()
    end
    
    if not IsNull(lightningSurfaceFX) then
        lightningSurfaceFX:SetVisibility(false)
    end

    if not IsNull(lightningStrikeFX) then
        lightningStrikeFX:Disable()
    end
end

local function DespawnLightningHazardMover()

    if not IsNull(lightningDamageTrigger) then
        lightningDamageTrigger:Disable()
    end

    if not IsNull(light) then
        light:TurnOff()
    end
    
    if not IsNull(lightningBeamFX) then
        lightningBeamFX:Disable()
    end
    
    if not IsNull(lightningSurfaceFX) then
        lightningSurfaceFX:SetVisibility(false)
    end

    if not IsNull(lightningStrikeFX) then
        lightningStrikeFX:Disable()
    end
end

function LightningHazard(instigator)

    local triggerFull = true
    local player
    local pos
    local lightningSpawned = false
    local lightningState = Symbol("LISTENING") -- LISTENING / ATTACK / COOLDOWN
    local currentSpeed
    local riskTime = strikeRiskDelay
    local attackTime = strikeTime - shakeTime
    local cooldownTime = strikeCooldown
    local currentStallTime = stallTime
    
    while triggerFull do
        if instigator:IsEnabled() and instigator:HasAvatarTouching() then
            player = instigator:GetEntitiesTouching()[1]
            if not IsNull (player) then
                if lightningState == Symbol("LISTENING") then
                    currentSpeed = player:GetSpeed()
                    if currentStallTime <= 0 then
                        lightningState = Symbol("ATTACK")
                        currentStallTime = stallTime
                    else 
                        if currentSpeed <= stallSpeed then
                            if not player:IsFalling() then
                                currentStallTime = currentStallTime - DeltaTime()
                            end
                        else 
                            if currentStallTime <= stallTime then
                                currentStallTime = currentStallTime + DeltaTime()
                            end
                        end
                    end
                elseif lightningState == Symbol("ATTACK") then
                    if not lightningSpawned then
                        pos = player:GetPosition()
                        if not IsNull(pos) then
                            SpawnLightningOmen(pos)
                            Sleep(strikeRiskDelay)
                            SpawnLightningHazard(pos)
                            StartCameraShake(pos)
                            lightningSpawned = true
                        end
                    else
                        if attackTime <= 0 then
                            DespawnLightningHazard()
                            lightningSpawned = false
                            lightningState = Symbol("COOLDOWN")
                            attackTime = strikeTime - shakeTime
                        else
                            attackTime = attackTime - DeltaTime()
                            --Broadcast(attackTime)
                        end
                    end
                elseif lightningState == Symbol("COOLDOWN") then
                    if cooldownTime <= 0 then
                        lightningState = Symbol("LISTENING")
                        cooldownTime = strikeCooldown
                    else
                        cooldownTime = cooldownTime - DeltaTime()
                        --Broadcast(cooldownTime)
                    end
                end
            end
        else
            triggerFull = false
        end
        Sleep(0)
    end
    
    DespawnLightningHazard()
    
end

function LightningHazardMover(waypoint) -- Place volumeless Script Trigger where you want the beam to emanate from
    
    local moverDisabled = false
    local pos
    
    if not IsNull(waypoint) then
        pos = waypoint:GetPosition()
    end
    
    if IsNull(pos) then
        return
    end
    
    SpawnLightningHazardMover(pos)
    
    while not moverDisabled do
        if waypoint:IsEnabled() == false then
            moverDisabled = true
        end
        Sleep(0)
    end
    
    DespawnLightningHazardMover()
end

function ExteriorLightning(trigger)
    if IsNull(exteriorLightningWaypoint) or IsNull(exteriorLightningFX) then
        return
    end
    
    local endPointPos = exteriorLightningWaypoint:GetPosition()
    exteriorLightningFX:SetEndPoint(endPointPos)
    
    while trigger:IsEnabled() do
        exteriorLightningFX:Enable()
        Sleep(math.random(1, 3))
        exteriorLightningFX:Disable()
        Sleep(math.random(0, 2))
    end
    exteriorLightningFX:Disable()
end

local function _ChargeCell(pickup, position, rotation)
    local newPickup = nil
    
    local pos = position
    if IsNull(pos) then
        pos = pickup:GetPosition()
    end

        local rot = rotation
    if IsNull(rot) then
        rot = pickup:GetRotation()
    end
    
    if not IsNull(pickup) then
        pickup:Destroy()
    end
    
    newPickup = gRegion:CreateEntity(energyCellType, pos, rot, gRegion:GetPlayerAvatar())
    
    return newPickup
end

function ChangeCell(trigger)
    local entitiesTouching = trigger:GetEntitiesTouching()
    local player
    local pickup
    local hand
    local newPickup = nil
    
    for i = 1, #entitiesTouching do
        if entitiesTouching[i]:IsA(playerType) then
            player = entitiesTouching[i]
            --hand = player:InventoryControl():GetActualHandFromSlot(Engine.SLOT_5)
            --player:InventoryControl():ForceDropCurrentWeapon(hand)
            --player:InventoryControl():RemoveItem(Engine.SLOT_5, true)
            --player:RemoveItem(energyCellEmptySkelAttachmentType)
            --pickup = player:GetAttachedChildren()
            --pickup = player:GetAttachment(energyCellEmptySkelAttachmentType)
            --pickup:Unattach()
            local inventoryControl = player:InventoryControl()
            local hand = inventoryControl:GetActualHandforSlot(Engine.SLOT_5)
            if hand < 4 then
                inventoryControl:ForceDropCurrentWeapon(hand)
            end
            --player:RemoveItem(energyCellEmptySkelAttachmentType)
            --local pos = player:GetPosition()
            --local rot = player:GetRotation()
            --_ChargeCell(nil, pos, rot)
        elseif entitiesTouching[i]:IsA(energyCellEmptyType) then
            pickup = entitiesTouching[i]
            newPickup = _ChargeCell(pickup)
            trigger:Disable()
        elseif entitiesTouching[i]:IsA(energyCellType) then
            if entitiesTouching[i] ~= newPickup then
                entitiesTouching[i]:Destroy()
            end
        end
    end

end

function ChargeCellAtStation()
    local pos = stationTrigger:GetPosition()
    local rot = stationTrigger:GetRotation()
    if IsNull(contextAction) then
       return
    end       
    Sleep(1)
        if not stationTrigger:HasEntityTouching() then
            gRegion:CreateEntity(energyCellType, pos, rot, gRegion:GetPlayerAvatar())
            contextAction:Disable()
        end
    Sleep(1)
    while stationTrigger:HasEntityTouching() do
        Sleep(1)
    end
    contextAction:Enable()
end

function SpawnCell(self)
    local energyCells
    local energyCellsEmpty
    local pos = stationTrigger:GetPosition()
    local rot = stationTrigger:GetRotation()
    while self:IsEnabled() do
        if not stationTrigger:HasEntityTouching() then
            energyCells = gRegion:FindAllObjects(energyCellType)
            energyCellsEmpty = gRegion:FindAllObjects(energyCellEmptyType)
            local total = #energyCells + #energyCellsEmpty
            if total < minCellsPerLevel then
                gRegion:CreateEntity(energyCellEmptyType, pos, rot, gRegion:GetPlayerAvatar())
            end
        end
        Sleep(1)
    end
end