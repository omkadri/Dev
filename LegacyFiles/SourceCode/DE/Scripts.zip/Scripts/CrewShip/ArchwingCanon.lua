local PLAYER_SKILL_LIB = require "Lotus.Scripts.Libs.PlayerSkillsLib"

spaceCanonStartCin = WeakResource()
spaceCanonLaunchCin = WeakResource()
mountCanonAnim = Resource("/Lotus/Animations/Tenno/Objects/RailJack/RJExitOrbiter_anim.fbx")
dismountCanonAnim = Resource("/Lotus/Animations/Tenno/Objects/RailJack/RJEntryOrbiter_anim.fbx")
canonLaunchAnim = Resource("/Lotus/Animations/FlightSuit/SprintNoise_anim.fbx")
canonHitExplosionAvatar = Type("/Lotus/Fx/SpaceBattle/Abilities/ArchwingCannonEnemyHitAvatarEffects")
canonHitExplosionEnemy = Type("/Lotus/Fx/Destruction/Railjack/FighterDeathA")
cannonLoadedTransmission = WeakResource()

maxDistanceToTravel = 1500 -- How far the archwing will go when fired
zoomTime = 0.3 -- Time taken to zoom in on targeted entity
minTargetZoom = 1.2 -- Zoom amount at closest range
maxTargetZoom = 2.2 -- Zoom amount at maxDistanceToTravel
targetHighlightFx = Type() -- FX to attach to targeted entity

local dissolveRate = 3 -- 1/dissolveRate seconds
local undissolveRate = 3 -- 1/undissolveRate seconds
local undissolveDelay = 0.1 -- time to wait before undissolve
local dissolveDelay = 0.2 -- time to wait before dissolve

local launchEffectType = Type("/Lotus/Fx/SpaceBattle/Abilities/ArchwingCannonLaunch")
local cameraAttachEffectType = Type("/Lotus/Fx/SpaceBattle/Abilities/ArchwingCannonCameraAttach")
local chargeSound = Resource("/Lotus/Sounds/Cinematics/RailJack/RailJackArchwingCanon/RailJackArchwingCanonCharge")
local fireSound = Resource("/Lotus/Sounds/Cinematics/RailJack/RailJackArchwingCanon/RailJackArchwingCanonFire")
local archcannonLoopSound = Type("/Lotus/Sounds/Cinematics/RailJack/RailJackArchwingCanon/RailJackArchwingCanonLoopSeq")
local exitSound = Resource("/Lotus/Sounds/Items/Railjack/RailjackRecallWarp")

-- Range finder vars
local mCurrentZoomTransition = 0
local mCurrentZoomDirection = -1
local mTargetZoomMagnification = 1.0
local mTargetEntity = nil

local SYM_AW_CANNON_FX = Symbol("ArchwingCanonHighlightFX")
local CAMERA_SPOT_TAG = Symbol("ArchwingCanonCameraSpot")
local SPLINE_TAG = Symbol("ArchwingCanonPathSpline")
local FORWARD_VECTOR = Vector(0,0,1)
local BACK_VECTOR = Vector(0,0,-1)
local radialBlurRange = Range(0, 0.2)
local shakeRange = Range(0, 0.2)

local radialBlurSymbol = Symbol("CannonBlur")

local deltaAtten = 0.2
local deltaAttenName = Symbol("ArchwingCannonHitSloMo")
local slomoTime = 5

local sCrewshipInvulnSymbol = Symbol("CrewShipBlockingInvuln")
local ramProjectileType = WeakResource("/Lotus/Types/Game/CrewShip/Ships/Abilities/Objects/RamProjectile")

local function _SetCrewShipVisible(crewShip, isVisible)
    local ramProj = crewShip:GetAttachment(ramProjectileType)
    if not IsNull(ramProj) then
        local projChildren = ramProj:GetAllAttachments(gDecorationType)
        for i=1, #projChildren do --For reasons, these children ignore parent visibility
            projChildren[i]:SetVisibility(isVisible, false)
        end
    end
    if isVisible then
        Sleep(undissolveDelay)
        
        local t = 1
        while t > 0 do
            crewShip:SetDitherDissolve(t)
            Sleep(0)
            t = t - DeltaTime() * undissolveRate
        end
        crewShip:SetDitherDissolve(0)
        
    else
        Sleep(dissolveDelay)
        local repMode = Script.ObjectType_RM_CLIENT_ONLY
        if gRegion:IsMaster() then
            repMode = Script.ObjectType_RM_SERVER_ONLY
        end

        local t = 0
        while t < 1 do
            crewShip:SetDitherDissolve(t)
            Sleep(0)
            t = t + DeltaTime() * dissolveRate
        end
        crewShip:SetDitherDissolve(1)
    end
end

local function AnimFadeOut(avatar, anim, fadeDelay, fadeOutTime)
    local cameraControl = avatar:CameraControl()
    if IsNull(cameraControl) then
        return
    end
    local postProcess = cameraControl:ScriptGetCurrentPostProcessInfo()
    local t = 0
    local val

    if not IsNull(anim) then
        avatar:PlayAnimation(anim, false, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_ONCE)
    end

    if fadeDelay > 0 then
        local fadeT = fadeDelay
        while fadeT > 0 do
            fadeT = fadeT - DeltaTime()
            Sleep(0)
        end
    end

    while t < 1 do
        val = Lerp(0, 1, t)
        postProcess.fade = val
        t = t + DeltaTime() / fadeOutTime
        Sleep(0)
    end
    postProcess.fade = 1
end

local function AnimFadeIn(avatar, anim, fadeDelay, fadeInTime)
    local cameraControl = avatar:CameraControl()
    if IsNull(cameraControl) then
        return
    end
    local postProcess = cameraControl:ScriptGetCurrentPostProcessInfo()
    local t = 0
    local val

    if not IsNull(anim) then
        avatar:PlayAnimation(anim, false, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_ONCE)
    end

    while t < 1 do
        val = Lerp(1, 0, t)
        postProcess.fade = val
        t = t + DeltaTime() / fadeInTime
        Sleep(0)
    end
    postProcess.fade = 0
end

local function PlayCinematic(instigator, cinematic, dolaunchFx, crewShip)    
    if not IsNull(instigator) then
        if not IsNull(crewShip) then
            local cin = crewShip:GetAttachment(cinematic)
            if not IsNull(cin) and not cin:IsPlaying() then
                instigator:SetView(cin:GetRotation())
                instigator:PlayAnimation(nil, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_ONCE, false, 1.0)
                if gRegion:IsMaster() then
                    instigator:SetAnimName(Symbol("Excalibur"))
                    cin:SetInstigatorAvatar(instigator)
                    cin:FirePort("StartPlaying")
                    local radialBlur = radialBlurRange:MapToRange(0)      
                    local shake = shakeRange:MapToRange(0)
                    local t = 0
                    while cin:IsPlaying() do
                        if dolaunchFx then
                            radialBlur = radialBlurRange:MapToRange(math.min(t  * 2.5, 1.0))
                            shake = shakeRange:MapToRange(math.min(t * 10.0, 1.0))
                            instigator:CameraControl():ShakeView(instigator:EyePosition(), 10, shake, 1)
                            instigator:CameraControl():RadialBlurView(radialBlur, radialBlur, radialBlur, 0.1, radialBlurSymbol)
                            t = t+ DeltaTime()
                        end
                        Sleep(0)
                    end
                end
            end
        end
    end
end

local function SetEnableCanon(enable, cannon)
    if enable then
        cannon:Enable()
    else
        cannon:Disable()
    end
end

local function _StartCameraSpot(instigator)
    local cameraSpot = gRegion:FindNearestTagged(CAMERA_SPOT_TAG, instigator:GetSimPosition())
    local cameraControl = instigator:CameraControl()
    if not IsNull(cameraSpot) and not IsNull(cameraControl) then
        cameraSpot:SetAdjustRot(ZERO_ROTATION)
        cameraSpot:ResetTrackingData()
        local cameraSpotTime = 0.1
        cameraControl:SetCameraSpot(cameraSpot, cameraSpotTime)
        --cameraSpot:Attach(cameraAttachEffectType, EMPTY_SYMBOL)
        cameraSpot:Attach(archcannonLoopSound, EMPTY_SYMBOL)
    end
end

local function DetachCameraSpot(instigator, doSetCameraSpotTransitionTime)
    local cameraControl = instigator:CameraControl()
    if not IsNull(cameraControl) and not cameraControl:IsNullCameraController() then
        local cameraSpot = cameraControl:GetCameraSpot()
        if not IsNull(cameraSpot) then
            local effects = cameraSpot:GetAttachment(cameraAttachEffectType)
            if not IsNull(effects) then
                effects:Destroy()
            end

            local sounds = cameraSpot:GetAttachment(archcannonLoopSound)
            if not IsNull(sounds) then
                sounds:Destroy()
            end

            if cameraSpot:IsA(gPlayerAimCameraSpotType) then
                cameraSpot:ClearIgnoreList()
            end
        end
        local savedCameraTransitionTime = cameraControl:GetTransitionToCameraSpotTime()
        if doSetCameraSpotTransitionTime then
            cameraControl:SetTransitionToCameraSpotTime(0.0)
        end
        cameraControl:SetCameraSpot(nil, 0.0)
        if doSetCameraSpotTransitionTime then
            cameraControl:SetTransitionToCameraSpotTime(savedCameraTransitionTime)
        end
    end
end

local function ClientWaitForCinematicStart()
    while IsNull(gRegion:GetPlayingCinematic()) do
        Sleep(0)
    end
end

local function ClientWaitForCinematicEnd()
    while not IsNull(gRegion:GetPlayingCinematic()) do
        Sleep(0)
    end
end

--[[
local drawFrequency = 1 -- draw every x seconds
local mDebugDrawTimer = 0

local function DrawPointList(list, radius, color, time, drawIndex, drawPoint, drawLine)
    if IsNull(list) then
        return
    end
    for i=2, #list do
        local p0 = list[i-1].point
        local p1 = list[i].point
        if drawIndex then
            gRegion:VisAddText(p0, color, tostring(i - 1), 2, time)
        end

        if drawLine then
            gRegion:VisAddLine(p0, p1, color, time)
        end

        if drawPoint then
            gRegion:VisAddSphere(p0, radius, color, time)
        end
    end
    if drawLine then
        gRegion:VisAddLine(list[#list-1].point, list[#list].point, color, time)
    end

    if drawIndex then
        gRegion:VisAddText(list[#list].point, color, tostring(#list), 2, time)
    end

    if drawPoint then
        gRegion:VisAddSphere(list[#list].point, radius, color, time)
    end
end

local function GetSamplePoints(spline)
    local samplePoints = {}
    local d = 0
    local numpoints  = 500
    while d <= numpoints do 
        local delta = d/numpoints
        table.insert( samplePoints, {point = spline:ScriptEvaluate(delta), delta=delta} )
        d = d + 1
    end
    return samplePoints
end

local function DebugDrawSpline(time, force, spline, splinePoints)
    mDebugDrawTimer = mDebugDrawTimer - DeltaTime()
    if force or mDebugDrawTimer <= 0 then
        
        local samplePoints = GetSamplePoints(spline)
--        Broadcast("Draw")
        local radius = 1
        local color = Color(255,0,0,255)
        local tangentColor = Color(55,50,50,100)
        local drawIndex = false
        local drawPoint = false
        local drawLine = true
        DrawPointList(samplePoints, radius, color, time, drawIndex, drawPoint, drawLine)

        if not IsNull(splinePoints) then
            gRegion:VisAddLine(splinePoints[1], splinePoints[1] + splinePoints[4], tangentColor, time) -- start to start OUT
            gRegion:VisAddLine(splinePoints[2], splinePoints[2] + splinePoints[3], tangentColor, time) -- end to end IN

            gRegion:VisAddSphere(splinePoints[1], radius, tangentColor, time)
            gRegion:VisAddSphere(splinePoints[2], radius, tangentColor, time)
            gRegion:VisAddSphere(splinePoints[2] + splinePoints[3], radius * 0.5, tangentColor, time)
            gRegion:VisAddSphere(splinePoints[1] + splinePoints[4], radius * 0.5, tangentColor, time)
        end

        mDebugDrawTimer = drawFrequency
    end
end
--]]

function StartCameraSpot(cin)
    local localPlayerAvatar = gRegion:GetLocalPlayerAvatar()
    local cinInstigator = cin:GetInstigatorAvatar()
    if localPlayerAvatar == cinInstigator then
        _StartCameraSpot(cinInstigator)
        local fadeDelay = 0.5
        local fadeInTime = 0.2
        AnimFadeIn(cinInstigator, nil, fadeDelay, fadeInTime)
    end
end

function CinDetachCameraSpot(cin)
    local localPlayerAvatar = gRegion:GetLocalPlayerAvatar()
    local cinInstigator = cin:GetInstigatorAvatar()
    if localPlayerAvatar == cinInstigator then
        local doSetCameraSpotTransitionTime = false
        DetachCameraSpot(cinInstigator, doSetCameraSpotTransitionTime)
    end
end

function PlayLaunchSounds(cin)
    local localPlayerAvatar = gRegion:GetLocalPlayerAvatar()
    local cinInstigator = cin:GetInstigatorAvatar()
    if localPlayerAvatar == cinInstigator then
        cinInstigator:PlaySound(chargeSound, false, 0, false)
            
        local timeTillLaunch = 1.1
        while timeTillLaunch > 0 do
            Sleep(0)
            timeTillLaunch = timeTillLaunch - DeltaTime()
        end
        cinInstigator:PlaySound(fireSound, false, 0, false)
    end   
end

local function UpdateAim(instigator, crewShip, cannon)
    local cameraSpot = gRegion:FindNearestTagged(CAMERA_SPOT_TAG, instigator:GetSimPosition())
    --local rotation = instigator:CameraControl():GetViewRotation()
    local startPoint = cameraSpot:GetSimPosition()

    local hitEntity = cameraSpot:GetTrackingTarget()
    
    -- TC 2019 - Only target avatars
    if not IsNull(hitEntity) and not hitEntity:IsA(gBaseAvatarType) then
        hitEntity = nil
    end
    
    if hitEntity ~= mTargetEntity then
        -- Remove highlight
        -- local highlightFX = gRegion:FindFirstTagged(SYM_AW_CANNON_FX)
        -- if not IsNull(highlightFX) then
        --     highlightFX:FadeOut()
        -- end
        
        mTargetEntity = hitEntity
        cannon:SetLaunchTarget(mTargetEntity)
        
        -- if not IsNull(mTargetEntity) and not IsNull(targetHighlightFx) then
        --     highlightFX = mTargetEntity:Attach(targetHighlightFx, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, instigator)
        --     if not IsNull(highlightFX) then
        --         highlightFX:SetTag(SYM_AW_CANNON_FX)
        --     end
        --     -- Add highlight
        -- end
    end
          
    if not IsNull(hitEntity) then   
        instigator:InventoryControl():ScriptedSetAimEndPoint(mTargetEntity)     
        --local dist = mTargetEntity:DistanceToPoint(startPoint)
        --mTargetZoomMagnification = minTargetZoom + (dist / maxDistanceToTravel)

        --mCurrentZoomDirection = 1
    --else
        --mCurrentZoomDirection = -1
    end

    --local zoomDelta = DeltaTime() / zoomTime
    --mCurrentZoomTransition = Clamp(mCurrentZoomTransition + (zoomDelta * mCurrentZoomDirection), 0, 1)

    --cameraSpot:SetFOV(Lerp(45, 45 / mTargetZoomMagnification, SmoothStep(mCurrentZoomTransition)))
end

function DissolveCrewShip(crewShip)
    _SetCrewShipVisible(crewShip, false)
end

function UndissolveCrewShip(crewShip)
    _SetCrewShipVisible(crewShip, true)
end

local function SetBlockedOperatorTransference(playerAv, blocked)
    if IsNull(playerAv) or IsNull(blocked) then
        return
    end

    local transferenceSymbol = Symbol("OPERATOR_TRANSFERENCE")
    local player = playerAv:GetAuthoritativePlayer()
    local warframeSuit = player:GetOwnedPowerSuitAvatar():InventoryControl():GetActivePowerSuit()

    if not IsNull(warframeSuit) and warframeSuit:IsAbilityIdentifierBlocked(transferenceSymbol) ~= blocked then
        warframeSuit:SetAbilityIdentifierBlocked(blocked, transferenceSymbol)
        if blocked then
            print("Transference blocked for " .. playerAv:GetFullName())
        else
            print("Transference unblocked for " .. playerAv:GetFullName())
        end
    end

    -- if we're blocking make sure we're already not in operator mode or in progress to be in operator mode
    if blocked then
        local player = playerAv:GetAuthoritativePlayer()
        if playerAv:IsOperatorTransferenceInProgress() then
            while playerAv == player:GetAvatar() do
                Sleep(0)
            end
            playerAv = player:GetAvatar()
        end
        if playerAv:IsA(gLotusOperatorAvatarType) then
            if gRegion:IsMaster() then
                playerAv:ForceOperatorTransference()
            end
            while IsNull(playerAv) or playerAv:IsA(gLotusOperatorAvatarType) do
                Sleep(0)
                playerAv = player:GetAvatar()
            end
        end
    end
end

function MountArchwingCanon(trigger, instigator, crewShip)     
    if IsNull(instigator) then
        return
    end
    local humanPlayer = instigator:GetPlayer()
    local isLocalPlayer = not IsNull(humanPlayer) and humanPlayer:IsLocal()
    if gRegion:IsMaster() then
        SetEnableCanon(false, trigger)
    end

    instigator:InventoryControl():StopWeapons()

    local boardedFromInterior = trigger:GetBoardedFromInterior()

    if boardedFromInterior then
        local fadeDelay = 0.7
        local fadeInTime = 0.1
        if isLocalPlayer then
            gGameRules:SetPauseDisabled(true)
        end
        
        if gRegion:IsMaster() then
            SetEnableCanon(false, trigger)
            gGameRules:GiveTransmissionAsyncToAllPlayers(cannonLoadedTransmission)
        end
        AnimFadeOut(instigator, mountCanonAnim, fadeDelay, fadeInTime)
        
        gRegion:AddToActivePVS(trigger) -- we're going to space, need ticks
    
        if gRegion:IsMaster() then
            local doLaunchFx = false
            PlayCinematic(instigator, spaceCanonStartCin, doLaunchFx, crewShip)
        else
            ClientWaitForCinematicStart()
            ClientWaitForCinematicEnd()
        end
        if isLocalPlayer then
            crewShip:ScriptRunChildScript(Symbol("DissolveCrewShip"), false)
        end
    end
    
    if isLocalPlayer and not boardedFromInterior then
        _StartCameraSpot(instigator)
    end

    if IsNull(instigator) then
        return
    end
    
    local cameraSpot = gRegion:FindNearestTagged(CAMERA_SPOT_TAG, instigator:GetSimPosition())
    if not IsNull(cameraSpot) then
        cameraSpot:AddToIgnoreList(crewShip, true)
        cameraSpot:AddToIgnoreList(instigator, true)
    end
    
    if not IsNull(crewShip) then
        if trigger:IsA(gCrewShipArchwingCannonEmplacementType) then
            local rangeMultiplier = instigator:InventoryControl():GetUpgradeModifiedValue(1.0, Game.AVATAR_ABILITY_RANGE, trigger:GetType())
            if rangeMultiplier > 1.0 then
                trigger:SetMaxDistanceMultiplier(rangeMultiplier)
                if not IsNull(cameraSpot) and cameraSpot:IsA(gPlayerAimCameraSpotType) then
                    cameraSpot:SetTrackingDistanceMultiplier(rangeMultiplier)
                end                
            end       
        end         
    end

    if isLocalPlayer and not boardedFromInterior then
        crewShip:ScriptRunChildScript(Symbol("DissolveCrewShip"), false)
    end

    trigger:NotifyMountComplete()

    local mounted = true
    local launched = false
    while mounted and not launched do
        if not IsNull(instigator) and instigator:IsLocallyAuthoritative() then
            UpdateAim(instigator, crewShip, trigger)
        
            -- TC2019 - don't allow launch without target
            --trigger:AllowLaunch(not IsNull(mTargetEntity) and mTargetEntity:IsA(gBaseAvatarType))
        end

        Sleep(0)
        mounted = trigger:GetCurrUser() == instigator
        launched = trigger:HasLaunched()
    end

    if gRegion:IsMaster() then
        SetEnableCanon(true, trigger)
    end

    SetBlockedOperatorTransference(instigator, false)
end

function RunDismountAction(trigger, instigator, crewShip, isInteriorBoard, forceImmediateDismount)
    if IsNull(instigator) then
        if not IsNull(trigger) and trigger:IsA(gContextActionType) then
            instigator = trigger:GetCurrUser()
        end
        
        if IsNull(instigator) then
            print("Trying to dismount archwing cannon but no instigator")
            trigger:NotifyDismountComplete()
            return
        end
    end
    
    if IsNull(crewShip) then
        print("Trying to dismount archwing cannon with null crewShip")
    end

    if not IsNull(instigator) then
        instigator:PlaySound(exitSound,false)
    end

    local humanPlayer = instigator:GetPlayer()
    local isLocalPlayer = not IsNull(humanPlayer) and humanPlayer:IsLocal()
    if isInteriorBoard then
        if isLocalPlayer and not forceImmediateDismount then
            local fadeDelay = 0.5
            local fadeInTime = 0.2
            AnimFadeOut(instigator, nil, fadeDelay, fadeInTime)
        end

        if not IsNull(crewShip) then
            instigator:InventoryControl():SetOnBoardShip(crewShip:InventoryControl():GetActivePowerSuit())
        end
    end
    trigger:NotifyDismountComplete()

    if isLocalPlayer then
        local doSetCameraSpotTransitionTime = true
        DetachCameraSpot(instigator, doSetCameraSpotTransitionTime)
        if isInteriorBoard and not forceImmediateDismount then
            local boardEntity = trigger:GetInteriorBoardEntity()
            if not IsNull(boardEntity) then
                instigator:Teleport(boardEntity:GetSimPosition(), boardEntity:GetSimRotation())
            end
        end
        if not IsNull(crewShip) then
            crewShip:ScriptRunChildScript(Symbol("UndissolveCrewShip"), false)
        end
    end

    if isInteriorBoard and not forceImmediateDismount then
        instigator:PlayNonReplicatedAnimation(dismountCanonAnim, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_ONCE)
        if isLocalPlayer then
            local fadeDelay = 0.2
            local fadeInTime = 0.2
            AnimFadeIn(instigator, nil, fadeDelay, fadeInTime)
        end
    end
     
    if isLocalPlayer then
        gGameRules:SetPauseDisabled(false)
    end
    if gRegion:IsMaster() then
        SetEnableCanon(true, trigger)
    end 

    SetBlockedOperatorTransference(instigator, false)
end

function RemoveSloMo(entity)
    Sleep(slomoTime)
    entity:RemoveDeltaAttenuation(deltaAttenName)
end

function RunActivateCanonAction(trigger, instigator, crewShip)
    if IsNull(instigator) then
        return
    end
    
    local humanPlayer = instigator:GetPlayer()
    local isLocalPlayer = not IsNull(humanPlayer) and humanPlayer:IsLocal()

    if isLocalPlayer then
        crewShip:ScriptRunChildScript(Symbol("UndissolveCrewShip"), false)
        --UpdateAim(instigator, crewShip, trigger)
        --instigator:Attach(attachEffectType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, instigator)
    end
    if gRegion:IsMaster() then
        local dolaunchFx = true
        PlayCinematic(instigator, spaceCanonLaunchCin, dolaunchFx, crewShip)
        if not IsNull(_T.OnArchwingCannonSubroutines) then
            _T.OnArchwingCannonSubroutines(instigator)
        end
    else
        ClientWaitForCinematicEnd()
    end

    gGameRules:SetPauseDisabled(false)
    instigator:Attach(launchEffectType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, instigator)
end


function CanonHitEntity(hitEntity, hitPosition, cannon, instigator, crewShip)
    -- we hit something, so kill it or board it (if its crewship)
    if instigator:IsIntrinsicSkillAbilityAdded(PLAYER_SKILL_LIB.sSkillAWCannonDamage) then
        instigator:Attach(canonHitExplosionAvatar, EMPTY_SYMBOL)
        gRegion:CreateEntity(canonHitExplosionEnemy, hitPosition, ZERO_ROTATION)
        local rootEnt = hitEntity:GetAttachRoot()
        if rootEnt:IsA(gCrewShipAvatarType) and not rootEnt:DamageControl():HasDamageModifier(sCrewshipInvulnSymbol) then
            rootEnt:BoardShipScript(instigator, Lotus_Game.CrewShipAvatar_BST_AW_CANNON)
        else
            --TC2019 This could probably be done better by letting the motion control collision handle it
            local isLotusAvatar = hitEntity:IsA(gLotusAvatarType)

            if isLotusAvatar and instigator:IsAvatarFriendly(hitEntity) then
                return -- dont damage friendlies
            end
            if(isLotusAvatar) then
                hitEntity:SetCollideWithControllers(false)
            end
            local dd = Engine.DamageData()
            dd.baseAmount = 10000
            dd:SetDamagePct(Engine.DT_EXPLOSION, 1.0)
            hitEntity:DamageDD(dd)
        end
    end
end

local mCannon = nil
function MountArchwingCannonInterior(trigger, instigator, a, b)
    if IsNull(instigator) then
        return
    end

    if instigator and not instigator:IsIntrinsicSkillAbilityAdded(PLAYER_SKILL_LIB.sSkillAWCannon) then
        return
    end

    local humanPlayer = instigator:GetAuthoritativePlayer()
    local isLocalPlayer = not IsNull(humanPlayer) and humanPlayer:IsLocal()
    
    SetBlockedOperatorTransference(instigator, true)

    local timeout = 3
    local crewShip = nil
    while IsNull(mCannon) and timeout > 0 do
        local crewShipMgr = gGameRules:GetCrewShipManager()
        if not IsNull(crewShipMgr) then
            local crewShipSuit = crewShipMgr:GetPlayerShip()
            if not IsNull(crewShipSuit) then
                crewShip = crewShipSuit:GetAvatarOwner()
            end
            if not IsNull(crewShip) then
                local rjEmplacements = gRegion:FindTagged(Symbol("RailjackEmplacement"))
                for _, emplacement in pairs(rjEmplacements) do
                    if emplacement:GetAttachParent() == crewShip then
                        mCannon = emplacement
                        break
                    end
                end
            end
            if not IsNull(mCannon) then
                break
            end
        end
        Sleep(0)
        timeout = timeout - DeltaTime()
    end

    if IsNull(mCannon) then
        return
    end

    if isLocalPlayer then
        print("Localplayer")
    end

    Sleep(0)
    mCannon:SetBoardedFromInterior(true)
    if isLocalPlayer then
        while humanPlayer:GetAvatar():IsA(gLotusOperatorAvatarType) or IsNull(humanPlayer:GetAvatar():GetPlayer()) do
            Sleep(0)
        end
        mCannon:ScriptMount(humanPlayer:GetAvatar())
    end

    if gRegion:IsMaster() then
        while IsNull(mCannon:GetCurrUser()) do
            Sleep(0)
            local playerAv = humanPlayer:GetAvatar()
            if not IsNull(playerAv) and playerAv:IsA(gLotusOperatorAvatarType) then
                playerAv:ForceOperatorTransference()
            end
        end
    end
end


