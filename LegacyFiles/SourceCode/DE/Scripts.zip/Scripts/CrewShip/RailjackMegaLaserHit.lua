superWeaponType = WeakResource()

local sReactor = Symbol("EngineReactor")
local mReactor = nil
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"

function OnDamaged(victim, sdd)
    if IsNull(victim) then 
        return false 
    end
    
    if victim:IsPreDeath() then
        local sourceObjectType = sdd:GetSourceObjectType()
        if sourceObjectType == superWeaponType then
            local crewship = victim:InventoryControl():GetActivePowerSuit()
            mReactor = RAIL.FindFirstTaggedOnShip(sReactor, crewship)
            if not IsNull(mReactor) then
                mReactor:Destroy()
            end
        end    
    end
end