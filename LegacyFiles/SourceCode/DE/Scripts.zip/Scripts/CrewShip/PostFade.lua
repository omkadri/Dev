targetFade = 1
duration = 1
returnDelay = 1
returnToNormal = true
returnDuration = 1

local mPlayerAv

local function DoFade(startFadeValue, targetFadeValue, fadeDuration, postInfo)
    local t = 0
    while t < fadeDuration do
        Sleep(0)
        if IsNull(mPlayerAv) then
            return
        else
            t = t + DeltaTime()
            postInfo.fade = Lerp(startFadeValue, targetFadeValue, t / fadeDuration)
        end
    end
    
    postInfo.fade = targetFadeValue
end

--perform fade for players on same crewship as this script trigger
function FadeOnCrewShip(trigger)
    local crewShipMgr
    while IsNull(crewShipMgr) do
        if not IsNull(gGameRules) then
            crewShipMgr = gGameRules:GetCrewShipManager()
        end
        if IsNull(crewShipMgr) then
            Sleep(0)
        end
    end

    -- Make sure it hasn't died while we've been waiting for manager replication
    local crewShip = crewShipMgr:GetShipForZone(trigger:GetZone())
    if IsNull(crewShip) then
        return
    end

    mPlayerAv = gRegion:GetLocalPlayerAvatar()
    if IsNull(mPlayerAv) or not crewShip:IsEntityOnBoardShip(mPlayerAv) then
        return
    end
    
    local cameraControl = mPlayerAv:CameraControl()
    if IsNull(cameraControl) or cameraControl:IsA(WeakResource("/EE/Types/Engine/NullCameraController")) then
        return
    end
        
    local postInfo = cameraControl:ScriptGetCurrentPostProcessInfo()
    local startFadeValue = postInfo.fade
    
    DoFade(startFadeValue, targetFade, duration, postInfo)
    
    if returnToNormal then
        Sleep(returnDelay)
        DoFade(targetFade, startFadeValue, returnDuration, postInfo)
    end
end
