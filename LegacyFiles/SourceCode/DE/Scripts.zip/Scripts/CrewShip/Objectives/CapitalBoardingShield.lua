updateDeltaTime = 1
capitalBoardingShieldTag = Symbol("CapitalBoardingShield")
boardingShieldTowerTag = Symbol("BoardingShieldTower")
boardingShieldTowerWaypointTag = Symbol("BoardingShieldTowerWaypoint")

numTowersToCreate = 3

capitalBoardingShieldType = Type()
capitalBoardingShieldTowerType = Type()

screenType = WeakResource()
screenOffMaterials = {Resource()}

local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"

local NV_BOARDING_SHIELD_STATE = Symbol("RJ_BOARDINGSHIELD_STATE")
local BOARDING_SHIELD_NOT_STARTED = 0
local BOARDING_SHIELD_STARTED = 1
local BOARDING_SHIELD_COMPLETED = 2

local mBoardingShieldDeco = nil
local mBoardingTowerDecos = {}
local mBoardingTowerMarkers = {}
local mBoardingShieldScriptTrigger = nil

local function CheckForHackedCondition()
    local hackedTowers = 0
    for i=1,#mBoardingTowerDecos do
        if not mBoardingTowerDecos[i]:IsEnabled() then
            hackedTowers = hackedTowers + 1

            if #mBoardingTowerDecos == hackedTowers then
                gGameRules:SetNetPersistentVar(NV_BOARDING_SHIELD_STATE, BOARDING_SHIELD_COMPLETED)
            end
        end
    end
end

local function Update(deltaTime)
    CheckForHackedCondition()
end

local function Initialize()
    for i=1,#mBoardingTowerDecos do
        local towerMarker = mBoardingTowerDecos[i]:GetAttachment(gBaseMarkerInfoType)
        table.insert(mBoardingTowerMarkers, towerMarker)

        if not IsNull(towerMarker:Enable()) and towerMarker:IsEnabled()  == false then
            towerMarker:Enable()
        end
    end

    OBJTXT.SetSecondaryObjText("/Lotus/Language/Railjack/DestroyBoardingShieldTowers", 2)
end

function OnDestroyed(deco)
    if deco == mBoardingShieldDeco then

        for i=1,#mBoardingTowerDecos do
            mBoardingTowerDecos[i]:Disable()
        end

        gGameRules:SetNetPersistentVar(NV_BOARDING_SHIELD_STATE, BOARDING_SHIELD_COMPLETED)
    else
        for i=1,#mBoardingTowerDecos do
            if mBoardingTowerDecos[i] == deco then
                table.remove(mBoardingTowerDecos, i)
                deco:Destroy()

                --send a squadron to go investigate the blown up towers.

                if #mBoardingTowerDecos < 1 then
                    gGameRules:SetNetPersistentVar(NV_BOARDING_SHIELD_STATE, BOARDING_SHIELD_COMPLETED)
                end
            end
        end
    end

    OBJTXT.ClearSecondaryObjText() 
end

function CapitalBoardingShield(scriptTrigger)
    mBoardingShieldScriptTrigger = scriptTrigger
    local boardingShieldDecoration = gRegion:FindFirstTagged(capitalBoardingShieldTag)
    local boardingTowerDecos = gRegion:FindTagged(boardingShieldTowerTag) --or create the radio towers
    local boardingShieldState = gGameRules:GetNetPersistentVar(NV_BOARDING_SHIELD_STATE, 0)

    if boardingShieldState == BOARDING_SHIELD_NOT_STARTED then
        --create shield/towers
        mBoardingShieldDeco = gRegion:CreateEntity(capitalBoardingShieldType, scriptTrigger:GetPosition(), ZERO_ROTATION, scriptTrigger, scriptTrigger, 1) -- 1 - ReplicationMode:RM_REPLICATED

        local potentialPositions = gRegion:FindTagged(boardingShieldTowerWaypointTag)

        if #potentialPositions >= 1 then
            for i=1,numTowersToCreate do
                local newPos = potentialPositions[RandomInt(1, #potentialPositions)]
                local newTower = gRegion:CreateEntity(capitalBoardingShieldTowerType, newPos, ZERO_ROTATION, scriptTrigger, scriptTrigger, 1) -- 1 - ReplicationMode:RM_REPLICATED
                table.insert(mBoardingTowerDecos, newTower)
            end
        end

        if not IsNull(mBoardingShieldDeco) and #mBoardingTowerDecos == numTowersToCreate then
            gGameRules:SetNetPersistentVar(NV_BOARDING_SHIELD_STATE, BOARDING_SHIELD_STARTED)
        end
    elseif boardingShieldState == BOARDING_SHIELD_STARTED then
        --find all the objec
        local boardingShieldDecoration = gRegion:FindFirstTagged(capitalBoardingShieldTag)
        local boardingTowerDecos = gRegion:FindTagged(boardingShieldTowerTag) --or create the radio towers

        if not IsNull(boardingShieldDecoration) then
            mBoardingShieldDeco = boardingShieldDecoration
            ObjectPortHandler(mBoardingShieldDeco, "OnDestroyed")
        end

        for i=1,#boardingTowerDecos do
            table.insert(mBoardingTowerDecos, boardingTowerDecos[i])
            ObjectPortHandler(boardingTowerDecos[i], "OnDestroyed")
            mBoardingTowerDecos:MakeVulnerable()
        end
    end

    while (gClient:IsLoadingScreenOpen() or not IsNull(gRegion:GetPlayingCinematic())) do
        Sleep(0)
    end
    
    Initialize()

    while true do
        Update(updateDeltaTime)
        Sleep(updateDeltaTime)
    end
end

function BoardingTowerPanel(avatar, result, instigator)
    if IsNull(avatar) then
        return
    end
    
    if not IsNull(avatar:GetAgent()) or result == nil then
        result = 1
    end

    if result == 1 then
        local attachParent = instigator:GetAttachParent()
        local light = attachParent:GetAttachment(gLightType)
        light:TurnOff()
        local screen = attachParent:GetAttachment(screenType)
        
        for i, mat in ipairs(screenOffMaterials) do
            screen:SetOverrideMaterial(i-1, mat)
        end
        --instigator:FirePort("Disable")
        
        attachParent:Disable()

        if gRegion:IsMaster() then
            print("BoardingShield: Tower: TowerPanelHacked panel (host)")
            --gGameRules:SetNetPersistentVar(NV_CONSOLE_STATE, 2)
        else
            print("BoardingShield: Tower: TowerPanelHacked panel (client)")
        end
    end
end
