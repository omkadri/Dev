warpPoint = Instance()
transformEntity = Instance()
exitHyperSpaceMovie = Resource()

local mWarpTime = 2
local mWarpDistance = 2000

fadeOutTime = 0.5
fadeInTime = 0.5
fadeValue = 1.0

hyperDriveState = Lotus_Game.CrewShipAvatar_HDS_ACTIVE

local mEnterHyperSpaceCinematicTag = Symbol("EnterHyperSpaceCinematic")
local mEnterHyperSpaceCinematicHideTag = Symbol("HangarHide")
local mEnterHyperSpaceCinematicShowTag = Symbol("HangarShow")

local EXIT_HYPERSPACE_SEQ = Symbol("ExitHyperSpace")
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"

--local sTennoFaction = Symbol("TENNO")
local sBoardingHintSymbol = Symbol("BoardingPartyHint")
local sRamsledHideSymbol = Symbol("HideGrineerPod")

function ExitHyperSpace(trigger)

    gGameRules:SignalMultiplayerFence(Symbol("EH_Start"), EXIT_HYPERSPACE_SEQ)

    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetPlayerShip()
    -- Wait for the ship to finish streaming
    while IsNull(ship) do
        Sleep(0)
        ship = crewShipMgr:GetPlayerShip()
    end
    
    while ship:GetCrewShipState() ~= Lotus_Game.CrewShip_CSS_READY do
        Sleep(0)
    end
    
    local crewShipAvatar = ship:GetAvatarOwner()
    
    if gRegion:IsMaster() then
        crewShipAvatar:SetHyperDriveState(Lotus_Game.CrewShipAvatar_HDS_POWERING_DOWN)
    end
       
    local destinationPoint = nil
    local destinationRotation = nil
    
    if IsNull(warpPoint) then
        local warpTag = Symbol("WarpInSpot")
        warpPoint = gRegion:FindFirstTagged(warpTag)
    end

    if not IsNull(warpPoint) then
        destinationPoint = warpPoint:GetPosition()
        destinationRotation = warpPoint:GetRotation()
    else
        destinationPoint = ZERO_VECTOR
        destinationRotation = Rotation()
    end
    
    local forwardDirection = RotateVector(Vector(0, 0, 1), destinationRotation)

    local waypoint = gRegion:CreateEntity(Type(gWaypointType), destinationPoint, destinationRotation)
    local newZone = nil
    local greenRoom = ship:GetGreenRoom()
    local attempts = 0
    while IsNull(newZone) and attempts < 8 do
        Sleep(0) -- Need to wait for connectivity to set a zone
        newZone = waypoint:GetZone()
        attempts = attempts + 1
    end
    
    ship:ExecuteScriptedEvent(Symbol("WarpOff"))
    ship:ExecuteScriptedEvent(Symbol("FlameOff"))
    
    if not IsNull(newZone) and not IsNull(greenRoom) then
        local greenRoomPos = ZERO_VECTOR

        local newZoneAttribs = newZone:GetZoneAttribs()
        newZone:SetTransformEntity(waypoint)
        greenRoom:SetBackDropId(newZoneAttribs:GetZoneId())
        local greenRoomZone = greenRoom:GetZone()
        greenRoomZone:SetBackdrop(newZone)
        greenRoomPos = greenRoom:GetPosition()
        
    --    local localAvatar = gRegion:GetLocalPlayerAvatar()
    --    localAvatar:GetZone():SetBackdrop(newZone)
        
        ship:RefreshBackdrops()
        
        local t = mWarpTime
        while t > 0 and not IsNull(crewShipAvatar) do
            Sleep(0)
            t = math.max(0, t - DeltaTime())
            local offset = forwardDirection * (mWarpDistance * SmoothStep(t / mWarpTime))
            offset = offset + crewShipAvatar:GetPosition() - greenRoomPos
            waypoint:Teleport(destinationPoint - offset, destinationRotation)
        end
    else
        print("ERROR: Warp point wasn't in any zone")
    end
    
    local warpIn = Symbol("CREWSHIP_WARP_IN")
    
    gGameRules:SignalMultiplayerFence(warpIn, EXIT_HYPERSPACE_SEQ)

    if gRegion:IsMaster() then
        local proceduralLevelTrigger = gRegion:FindFirstTagged(Symbol("ProceduralLevelTrigger"))

        if not IsNull(proceduralLevelTrigger) then
            proceduralLevelTrigger:RunScripts()
        end

        -- Host waits until everyone has finished doing the cosmetic warp in sequence
        gGameRules:SuspendUntilMultiplayerFenceReached(warpIn)
--        Broadcast("WARP IN COMPLETE")

--        ship:TeleportShipToEntity(waypoint)
        if not IsNull(crewShipAvatar) then
            local rotation = CombineRotations(waypoint:GetRotation(), crewShipAvatar:GetRotation())
            crewShipAvatar:Teleport(waypoint:GetPosition(), rotation)
        end
    end
    
    while not IsNull(crewShipAvatar) and not IsNull(greenRoom) and crewShipAvatar:GetZone() == greenRoom:GetZone() do
        -- Wait for the teleport to go through
        Sleep(0)
    end
    
    local teleportSuccess = Symbol("CREWSHIP_TELEPORT")
    
    gGameRules:SignalMultiplayerFence(teleportSuccess, EXIT_HYPERSPACE_SEQ)
    
    if gRegion:IsMaster() then
        -- Host waits until everyone has acknowledged the teleport
        gGameRules:SuspendUntilMultiplayerFenceReached(teleportSuccess)
        
--        Broadcast("POST WARP TELEPORT COMPLETE")
        crewShipMgr:SetMissionState(Lotus_Game.CrewShipMgr_MISSION_ACTIVE)
        if not IsNull(crewShipAvatar) then
            crewShipAvatar:SetHyperDriveState(Lotus_Game.CrewShipAvatar_HDS_COOLING_DOWN)
            crewShipAvatar:SetAnimAction(Symbol("Undock"))
        end
    end

    gGameRules:FinishMultiplayerFenceSequence(EXIT_HYPERSPACE_SEQ)

    if not IsNull(gFlashMgr) and not IsNull(exitHyperSpaceMovie) then
        --gFlashMgr:GotoMovie(exitHyperSpaceMovie)
    end
end

local function SetEnableShipMissionFunctions(enable, ship)
    local exitActions = gRegion:FindTagged(Symbol("ExitShipAction"))

    for i=1,#exitActions do
        if not IsNull(exitActions[i]) then
            if enable == true then
                exitActions[i]:Enable()
            else
                exitActions[i]:Disable()
            end
        end
    end
    
    
    local enterActions = gRegion:FindTagged(Symbol("EnterShipAction"))
    for i=1,#enterActions do
        if not IsNull(enterActions[i]) then
            if enable == true then
                enterActions[i]:Enable()
            else
                enterActions[i]:Disable()
            end
        end
    end
    
    if not IsNull(ship) then
        local shipAvatar = ship:GetAvatarOwner()
        if not IsNull(shipAvatar) then
            local moverType = WeakResource("/Lotus/Types/Game/CrewShip/CrewShipOuterVolume")
            local moverTrigger = shipAvatar:GetAttachment(moverType)
            
            if not IsNull(moverTrigger) then
                if enable then
                    moverTrigger:Enable()
                else
                    moverTrigger:Disable()
                end
            end
        end
    end
end

local function CleanUpAfterShipEncounters(ship)
    -- Remove/Hide any lingering things we don't want to persist during hyperspace
    
    -- Boarding Party shutdown/cleanup
    local boardingPartyHints = gRegion:FindTagged(sBoardingHintSymbol)   
    for i = 1, #boardingPartyHints do
        boardingPartyHints[i]:SetEncounterDynamicState(4)
    end    
    
    -- Clean up any lingering Ramsleds
    local boardingPods = gRegion:FindTagged(sRamsledHideSymbol)
    for j = 1, #boardingPods do
        local hidePod = boardingPods[j]
        if not IsNull(hidePod) then
            hidePod:FirePort("TriggerPort")
        end
    end
    
        -- Remove any lingering pickups
    local pickups = RJ_UTIL.FindTypeOnShip(gPickUpType, ship) 
    for i, pickup in ipairs(pickups) do
        pickup:Destroy()
    end
    
    --Disable new encounters when charging up for hyperspace
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    if not IsNull(aiDir) and aiDir:EncountersEnabled() then
        aiDir:EnableEncounters(false)
    end
end

function EnableShipMissionFunctions()
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetPlayerShip()
    
    SetEnableShipMissionFunctions(true, ship)
end

function PrepareForHyperSpace(trigger)
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetPlayerShip()
    
    if IsNull(ship) then
        return
    end
    
    local crewShipAvatar = ship:GetAvatarOwner()
    
    if gRegion:IsMaster() then
        crewShipAvatar:SetHyperDriveState(Lotus_Game.CrewShipAvatar_HDS_BOARDING) -- Do we still need this state?
    end
    
    local allPlayersInShip = not LOTUS_UTIL.IsInMission();
    while not allPlayersInShip do 
        Sleep(0)
        allPlayersInShip = true
        local players = gRegion:GetHumanPlayers()
        for _,player in ipairs(players) do
            local hudStatus = player:GetHudStatus()
            local playerAvatar = player:GetAvatar()
            if not IsNull(playerAvatar) then
                local onBoardShip = playerAvatar:InventoryControl():GetOnBoardShip()
                local message = "/Lotus/Language/Railjack/WaitingForPlayers"
                if IsNull(onBoardShip) or onBoardShip ~= ship then
                    allPlayersInShip = false
                    message = "/Lotus/Language/Railjack/LeavingSoon"
                end
                
                if not IsNull(hudStatus) then
                    hudStatus:SetGenericMessage(message)
                end
            end
        end
    end
    
    local players = gRegion:GetHumanPlayers()
    for _,player in ipairs(players) do
        local hudStatus = player:GetHudStatus()
        if not IsNull(hudStatus) then
            hudStatus:SetGenericMessage("")
        end
    end

    -- Now that everybody is inside, prevent them from leaving
    SetEnableShipMissionFunctions(false, ship)
    
    -- Prevent pause menu from being opened when preparing to stream the level, as it sleeps during the open animation and can be closed without shutdown being called
    gGameRules:SetPauseDisabled(true)
    
    local prepareComplete = Symbol("CREWSHIP_PREPARE")
    if not gGameRules:IsBootLevel() then
        gGameRules:SignalMultiplayerFence(prepareComplete)
    end
    
    if gRegion:IsMaster() then
        -- Host waits until everyone has finished preparing
        if not gGameRules:IsBootLevel() then
            gGameRules:SuspendUntilMultiplayerFenceReached(prepareComplete)
        end
        crewShipAvatar:SetHyperDriveState(Lotus_Game.CrewShipAvatar_HDS_POWERING_UP)
        ship:ExecuteScriptedEvent(Symbol("PowerupHyperDrive"))
    end
    
    CleanUpAfterShipEncounters(ship)
end

function PowerupHyperDrive(trigger)
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetPlayerShip()
    
    if IsNull(ship) then
        return
    end
    
    ship:ExecuteScriptedEvent(Symbol("FlameOn"))
    
    local crewShipAvatar = ship:GetAvatarOwner()
    
    while IsNull(crewShipAvatar) or crewShipAvatar:GetHyperDriveState() == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP or crewShipAvatar:GetHyperDriveState() == Lotus_Game.CrewShipAvatar_HDS_BOARDING do
        Sleep(0)
    end
    
    if crewShipAvatar:GetHyperDriveState() ~= Lotus_Game.CrewShipAvatar_HDS_ACTIVE then
        -- Deactivate warp fx if warp out was interrupted
        ship:ExecuteScriptedEvent(Symbol("FlameOff"))
    end
end

function WaitForHyperDrive(trigger)
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetPlayerShip()
    
    while IsNull(ship) do
        Sleep(0)
        ship = crewShipMgr:GetPlayerShip()
    end
    
    local crewShipAvatar = ship:GetAvatarOwner()
    
    while IsNull(crewShipAvatar) or crewShipAvatar:GetHyperDriveState() ~= Lotus_Game.CrewShipAvatar_HDS_ACTIVE do
        Sleep(0)
    end
    
    ship:ExecuteScriptedEvent(Symbol("ActivateHyperDrive"))
end

function HyperDriveSound(sequencer)
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetPlayerShip()
    
    while IsNull(ship) do
        Sleep(0)
        ship = crewShipMgr:GetPlayerShip()
    end
    
    local crewShipAvatar = ship:GetAvatarOwner()
    
    while IsNull(crewShipAvatar) or crewShipAvatar:GetHyperDriveState() == Lotus_Game.CrewShipAvatar_HDS_ACTIVE do
        Sleep(0)
    end
end

function SendLoadLevelRequestToClients()

    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetPlayerShip()
    
    while IsNull(ship) do
        Sleep(0)
        ship = crewShipMgr:GetPlayerShip()
    end
    
    local crewShipAvatar = ship:GetAvatarOwner()
    
    while IsNull(crewShipAvatar) or crewShipAvatar:GetHyperDriveState() ~= Lotus_Game.CrewShipAvatar_HDS_ACTIVE do
        Sleep(0)
    end

    local sendToAllPlayers = not gFlashMgr:GetConfigBool("CrewShip.SeamlessDojoMissionTransition")
    gMatchingService:SendHubMissionLoad(sendToAllPlayers)
end

function LisetEnterHyperSpace(trigger)
    -- Simplified cosmetic warp sequence
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetPlayerShip()
    
    if IsNull(ship) then
        return
    end

    gFlashMgr:CloseAllMovies()

    if not IsNull(gRegion) then
        local avatar = gRegion:GetLocalPlayerAvatar()
        if not IsNull(avatar) then
            local cameraControl = avatar:CameraControl()
            cameraControl:SetCameraSpot(nil, 0)
        end
    end

    ship:ExecuteScriptedEvent(Symbol("WarpOn"))
    
    Sleep(2)
    ship:ExecuteScriptedEvent(Symbol("SetupRailjackGameRules"))
    Sleep(1)
    ship:ExecuteScriptedEvent(Symbol("StreamVoidTunnel"))
end

function EnterHyperSpace(trigger)
    while IsNull(gGameRules) do
        Sleep(0)
    end

    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetPlayerShip()
    
    if IsNull(ship) then
        return
    end

    ship:ExecuteScriptedEvent(Symbol("SetupRailjackGameRules"))
    Sleep(0.1)
    
    local crewShipAvatar = ship:GetAvatarOwner()
    
    local greenRoom = ship:GetGreenRoom()
    local greenRoomZone = greenRoom:GetZone()

    local startPos = crewShipAvatar:GetPosition()
    local startRot = crewShipAvatar:GetRotation()
    local warpZone = crewShipAvatar:GetZone()
    
    local numAttempts = 0
    while IsNull(warpZone) and numAttempts < 8 do
        Sleep(0)
        warpZone = crewShipAvatar:GetZone()
        numAttempts = numAttempts + 1
    end
    
    if not IsNull(transformEntity) then
        if transformEntity:GetZone() ~= warpZone then
            warpZone = transformEntity:GetZone()
            startPos = transformEntity:GetPosition()
            startRot = transformEntity:GetRotation()
        end
    end
    local waypoint = gRegion:CreateEntity(Type(gWaypointType), startPos, startRot)
    
    if not IsNull(warpZone) then
        local warpZoneAttribs = warpZone:GetZoneAttribs()
        warpZone:SetTransformEntity(waypoint)
        greenRoom:SetBackDropId(warpZoneAttribs:GetZoneId())
        greenRoomZone:SetBackdrop(warpZone)
    end
    
    if gRegion:IsMaster() then
        -- TODO: There might be no harm in having clients do the teleport too
        local greenRoomPosition = greenRoom:GetPosition()
        print("HYPERSPACE: Teleporting RJ to "..tostring(greenRoomPosition).." ("..tostring(greenRoom:GetFullName())..")")
        crewShipAvatar:Teleport(greenRoom:GetPosition(), greenRoom:GetRotation())
    end

    -- Just in case, wait until the ship is inside the green room before proceeding
    while crewShipAvatar:GetZone() ~= greenRoomZone do
        Sleep(0)
    end
    
    ship:ExecuteScriptedEvent(Symbol("WarpOn"))
    local forwardDirection = waypoint:GetForwardVector()

    local t = 0
    while t < mWarpTime do
        Sleep(0)
        t = math.min(mWarpTime, t + DeltaTime())
        local offset = forwardDirection * (mWarpDistance * SmoothStep(t / mWarpTime))
        offset = offset + crewShipAvatar:GetPosition() - greenRoom:GetPosition()
        waypoint:Teleport(startPos + offset, startRot)
    end

    -- Clear the backdrop
    greenRoom:SetBackDropId(Symbol())
    greenRoomZone:SetBackdrop(nil)
    gRegion:DestroyObject(waypoint)
    
    local warpOut = Symbol("CREWSHIP_WARP_OUT")
    if not _T.Railjack_FromDojo then
        gGameRules:SignalMultiplayerFence(warpOut)
    end
    
    if gRegion:IsMaster() and not _T.Railjack_FromDojo then
        -- Host waits until everyone has finished warping out
        gGameRules:SuspendUntilMultiplayerFenceReached(warpOut)
--        Broadcast("WARP OUT COMPLETE")
    end

    print("EnterHyperSpace done")
end

function StreamNextMission()
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetPlayerShip()
    
    if IsNull(ship) then
        return
    end
    
    ship:ExecuteScriptedEvent(Symbol("StreamVoidTunnel"))
end

function StreamNextMissionVoidTunnel()
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetPlayerShip()
    
    if IsNull(ship) then
        return
    end
    
    ship:ExecuteScriptedEvent(Symbol("StreamNextMissionVoidTunnel"))
end

local function SquadJsonCallback(json)
    print("CREWSHIP: Squad JSON received: "..tostring(json))

    -- For the time being cinematicDone is the only JSON message, so don't bother with trying
    -- to decode it.
    if string.find(json, "cinematicDone") then
        _T.dojoCinematicDone = true;
    end
end

function PlayMissionStartCinematic(instigator)
    
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetPlayerShip()

    if IsNull(ship) then
        print("CREWSHIP: No player ship")
        return
    end

    local shipAvatar = ship:GetAvatarOwner()
    if IsNull(shipAvatar) then
        print("CREWSHIP: No ship avatar")
        return
    end

    shipAvatar:SetVisibility(true, true) -- if we're starting a mission from hubs, railjack avatar will be hidden, not anymore
    
    local localPlayerAvatar = gRegion:GetLocalPlayerAvatar()
    while IsNull(localPlayerAvatar) do
        Sleep(0)
        localPlayerAvatar = gRegion:GetLocalPlayerAvatar()
    end

    if not IsNull(gRegion) then
        local avatar = gRegion:GetLocalPlayerAvatar()
        if not IsNull(avatar) then
            local cameraControl = avatar:CameraControl()
            cameraControl:SetCameraSpot(nil, 0)
        end
    end
    
    gFlashMgr:CloseAllMovies()

    gMatchingService:SetSquadJsonMessageCallback(SquadJsonCallback)

    -- If there is some other cinematic playing (most likely boarding cin)
    -- let it go first. Otherwise we'd stomp over it (or it'll stomp over us)
    local currentCin = gRegion:GetPlayingCinematic()
    local needCinematic = true
    if not IsNull(currentCin) then
        print("CREWSHIP: Boarding cinematic playing, waiting")
        needCinematic = false
    end
    while not IsNull(currentCin) and currentCin:IsPlaying() do
        Sleep(0)
    end

    -- It is also possible that we're still playing the docking cinematic, in such case we have to wait as well
    -- (if client is slow coming back and host goes to mission  
    local dockCin = gRegion:FindFirstTagged(Symbol("SummonRailjack"))
    while not IsNull(dockCin) and dockCin:IsPlaying() do
        Sleep(0)
    end

    -- If necessary, board the ship
    print("CREWSHIP: Before teleport "..tostring(localPlayerAvatar:GetPosition()))
    local avZone = localPlayerAvatar:GetZone()
    if not IsNull(avZone) then
        print("Avatar zone: "..tostring(avZone:GetFullName()))
    end
    if IsNull(crewShipMgr:GetShipForZone(localPlayerAvatar:GetZone())) then
        print("CREWSHIP: Player needs teleport")

        local action = localPlayerAvatar:GameActionControl():GetCurrentGameAction()
        if not IsNull(action) and action:IsA(gDecoModeActionType) then
            action:ForceCancel()
        end

        local boardCin = gRegion:FindFirstTagged(Symbol("BoardFromDojoCin"))
        localPlayerAvatar:Teleport(boardCin:GetPosition(), boardCin:GetRotation())
        -- Teleport is delayed. Have to make sure it's done before we leave and change the game rules (..and respawn)
        -- (1st frame is late because script runs after entity update, so teleport isn't even requested)
        Sleep(0)
        -- Here we kick the teleport
        Sleep(0)
        -- .. and now it's done
        Sleep(0)
    end

    local cin = gRegion:FindNearestTagged(mEnterHyperSpaceCinematicTag, shipAvatar:GetPosition())
    local postProcess = localPlayerAvatar:CameraControl():ScriptGetCurrentPostProcessInfo()
    local startFade = 0 
    local t = 0
    local val

    if gGameRules:IsHubLevel() then
        gGameRules:PauseHubUpdates(true)
    end

    _T.Railjack_FromDojo = true
    if gMatchingService:IsSquadHost() then
        gMatchingService:StartSeamlessMission()
    end

    if needCinematic and not IsNull(cin) and not cin:IsPlaying() then

        while t < 1 do
            val = Lerp(0, 1, t)
            postProcess.fade = val
            t = t + DeltaTime() / fadeOutTime
            Sleep(0)
        end
        postProcess.fade = 1

        -- hide all the objects that need hidin
        local hide = gRegion:FindTagged(mEnterHyperSpaceCinematicHideTag)
        for i=1,#hide do
            local entityToHide = hide[i]
            if not IsNull(entityToHide) then
                entityToHide:SetVisibility(false, true)
            end
        end

        -- show all the objects that need showin
        local show = gRegion:FindTagged(mEnterHyperSpaceCinematicShowTag)
        for i=1,#show do
            local entityToShow = show[i]
            if not IsNull(entityToShow) then
                entityToShow:SetVisibility(true, true)
            end
        end
    
        shipAvatar:PlayAnimation(nil, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_ONCE, false, 1.0)
    
        if gRegion:IsMaster() and IsNull(gRegion:GetPlayingCinematic()) then
            shipAvatar:SetAnimName(Symbol("RailJack"))
            cin:FirePort("StartPlaying")
            ship:ExecuteScriptedEvent(Symbol("InstantOn")) -- so we're already warping when the cin ends
        end

        t = 0
        while t < 1 do
            val = Lerp(1, 0, t)
            postProcess.fade = val
            t = t + DeltaTime() / fadeInTime
            Sleep(0)
        end
        postProcess.fade = 0

        while cin:IsPlaying() and not _T.dojoCinematicDone do
            Sleep(0)
        end

        if _T.dojoCinematicDone then
            cin:FirePort("StopPlaying")
        else
            gMatchingService:SendSquadJsonMessage(cjson.encode({cinematicDone = true}))
        end
        _T.dojoCinematicDone = nil

        t = 0
        while t < 1 do
            val = Lerp(1, 0, t)
            postProcess.fade = val
            t = t + DeltaTime() / fadeInTime
            Sleep(0)
        end
        postProcess.fade = 0
    end
end

local missionSet = false

local function _DojoMissionCallback(_, mission)
    if not gGameRules:IsA(gLotusHubGameRulesType) then
        print("Dojo mission callback - ignored (invalid game rules)")
        return
    end
    
    local squadMission = cjson.decode(mission)
    if squadMission and squadMission.name then
        if _T.SquadOverlayEnforceSquadMissionEligibility and not _T.SquadOverlayEnforceSquadMissionEligibility(squadMission.name) then
            print("Dojo mission callback: ineligible for selected mission")
            return
        end

        local starChart = LOTUS_UTIL.GetStarChart()

        local node, _, _ = LOTUS_UTIL.GetNodeInfo(squadMission.name, starChart, nil)

        if not IsNull(node) and node.mission.missionType ~= Lotus_Game.MT_RAILJACK then
            -- Keys do not have starchart entries, so mission type might be wrong
            if not (string.find(squadMission.name, LOTUS_UTIL.KEY_TAG) and string.find(squadMission.name, "CrewBattle")) then
                print("Dojo mission callback - ignoring non-railjack mission " .. squadMission.name)
                return
            else
                print("Suspicious mission type, but classified as railjack mission: ".. squadMission.name)
            end
        end

        local shipManager = gGameRules:GetCrewShipManager()
        local missionName = Symbol(squadMission.name)
    
        _T.RailJackNextMissionNode = missionName
        _T.SeamlessRailJackTransition = gGameRules:IsA(gLotusAttractModeGameRulesType)
    
        local travelSector = starChart:GetNodeForMission(Symbol("CrewShipGenericTunnel"))
        shipManager:SetNextMission(travelSector.mission)

        print("Dojo mission callback - handled")

        return true
    else
        print("Dojo mission callback - ignored (no mission)")
    end
end

function WaitForNextMissionSet(e)
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end

    local squadMission = gMatchingService:GetSquadMission()
    print("Set DOJO callback. Squad mission="..squadMission)

    local missionCallbacks = _T.OnSquadMissionSelectedCallbacks or {}
    _T.OnSquadMissionSelectedCallbacks = missionCallbacks
    local dojoCallback = function(onlineId, mission)
        if IsNull(e) then
            return false -- original script trigger that set up this callback is dead
        end
        local handled = _DojoMissionCallback(onlineId, mission)
        if handled then
            return false -- signal ThemedSquadOverlay.lua to remove this callback from _T.OnSquadMissionSelectedCallbacks
        end
    end
    table.insert(missionCallbacks, dojoCallback)

    crewShipMgr:SetNextMissionSetCallback("OnNextMissionSet")

    -- If we got here, but mission already select, we have to fire the callback immediately
    -- (registered too late)
    if squadMission ~= "" then
        _DojoMissionCallback("", squadMission)
    end
    
    while not missionSet do
        Sleep(0.1)
    end

    -- Mission selected, we're ready to go
    if gMatchingService:IsSquadHost() then
        gMatchingService:SetSquadMissionReady(true)
    end
    
    -- OnEnded port triggers cinematic
end

function OnNextMissionSet()
    missionSet = true
end

function SetHyperDriveState()
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetPlayerShip()

    if IsNull(ship) then
        return
    end
    local crewShipAvatar = ship:GetAvatarOwner()
    if not IsNull(crewShipAvatar) then
        crewShipAvatar:SetHyperDriveState(hyperDriveState)
    end
end

function SetupRailjackGameRules()
    if not gRegion:IsMaster() then
        return
    end

    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
        
    local ship = crewShipMgr:GetPlayerShip()
    if not IsNull(ship) then
        ship:ExecuteScriptedEvent(Symbol("SetupRailjackGameRules"))
    end
end
