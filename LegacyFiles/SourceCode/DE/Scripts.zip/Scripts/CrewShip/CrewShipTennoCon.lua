explosionType = Type()
pitchIncreaseOnTargetDestroy = 0.05
newIntensity = 1

spaceZoneAttribs = Instance()
spaceTransformEntity = Instance()
shipDecos = {Instance()}
destroyAvatarsType = WeakResource()



local GAMEMODE = require "Lotus.Scripts.Libs.CommonGamemodeFunctions"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"

local cachedCin1
local cachedCin2
local cachedPlayerIndex
local cachedAvatarName

local sCapitalShipRegionIndex = 1

function StartCin(avatar)
    local cin1 = cachedCin1
    local cin2 = cachedCin2

    avatar:SetAnimName(Symbol("ArchwingA"))
    if not cin1:IsPlaying() then
        avatar:PlayAnimation(nil, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_ONCE, false, 1.0)
        if avatar == gRegion:GetLocalPlayerAvatar() then
            -- Prepare the zone attribs so we get a radical backdrop
            if not IsNull(spaceZoneAttribs) then
                -- TODO
                -- Find a tagged entity inside the corpus ship and set an appropriate parallax scale
                    spaceZoneAttribs:SetParallaxCenter(nil)
                    spaceZoneAttribs:GetZone():SetActualScale(1.0)
                -- END TODO
                spaceZoneAttribs:GetZone():SetTransformEntity(spaceTransformEntity)
            
                local corpusZoneAttribs = gRegion:FindTagged(Symbol("CorpusZoneAttribs"))
                for i,v in ipairs(corpusZoneAttribs) do
                    v:SetBackDropId(spaceZoneAttribs:GetZoneId())
                    v:GetZone():SetBackdrop(spaceZoneAttribs:GetZone())
                end
            end
        end
        if gRegion:IsMaster() then
            cin1:SetInstigatorAvatar(avatar)
            cin1:FirePort("StartPlaying")
        end

        while not cin1:IsPlaying() do
            Sleep(0)
        end
    end

    while cin1:IsPlaying() do
       Sleep(0)
    end

    avatar:SetAnimName(Symbol("ArchwingA"))
    if not cin2:IsPlaying() then
        if gRegion:IsMaster() then
            cin2:SetInstigatorAvatar(avatar)
            cin2:FirePort("StartPlaying")
       end
   
       if avatar == gRegion:GetLocalPlayerAvatar() then
           -- Also need to hide the ship decos, since we'll have a point of view from inside
           for i,v in ipairs(shipDecos) do
               if not IsNull(v) then
                   v:SetVisibility(false, true)
               end
           end
       
           local extraShipEntities = gRegion:FindTagged(Symbol("CorpusShipExtra")) or {}
           for i,v in ipairs(extraShipEntities) do
               if not IsNull(v) then
                   v:SetVisibility(false, true)
               end
           end

       end

       while not cin2:IsPlaying() do
           Sleep(0)
       end

       if gRegion:GetLocalPlayerAvatar() == avatar then
            avatar:SetView(cin2:GetSimRotation())
       end
    end

    while cin2:IsPlaying() do
        Sleep(0)
    end
end

function LandingCin(trigger, avatar)

    if IsNull(avatar) then
        return
    end

    local players = gRegion:GetHumanPlayers()
    local playerAvatars = gRegion:GetHumanPlayerAvatars()
    
    local avatars = {}
    
    for i = 1, #playerAvatars do
        local player = players[i]
        table.insert(avatars, { name=player:GetPlayerName(), avatar=playerAvatars[i] })
    end
    table.sort(avatars, function(a,b) return a.name < b.name end) -- Sort clients alphabetically by player name and make first one TennoB

    local playerIndex = nil
    for i = 1, #playerAvatars do
        if avatars[i].avatar == avatar then
            playerIndex = i
            break
        end
    end    

    if playerIndex ==  nil then
        print("Cant find player Index for CorpusShipApproachCin and CorpusShipLandCin")
        return
    end

    local avatarName = avatars[playerIndex].name 

    local allCins1 = gRegion:FindTagged(Symbol("CorpusShipApproachCin"))
    if #allCins1 < playerIndex then
        print("PlayerIndex is greater than number of  CorpusShipApproachCin Cinematics")
        return
    end

    table.sort(allCins1, function(a,b) return a:GetInstance() < b:GetInstance() end)

    local allCins2 = gRegion:FindTagged(Symbol("CorpusShipLandCin"))
    if #allCins2 < playerIndex then
        print("PlayerIndex is greater than number of  CorpusShipLandCin Cinematics")
        return
    end
    table.sort(allCins2, function(a,b) return a:GetInstance() < b:GetInstance() end)

    cachedCin1 = allCins1[playerIndex]
    cachedCin2 = allCins2[playerIndex]
    cachedAvatarName = avatarName
    cachedPlayerIndex = playerIndex

    avatar:ScriptRunChildScript(Symbol("StartCin"), false)   
end

function ShowCorpusShip()
    for i,v in ipairs(shipDecos) do
        if not IsNull(v) then
            v:SetVisibility(true, true)
        end
    end
    
    local extraShipEntities = gRegion:FindTagged(Symbol("CorpusShipExtra")) or {}
    for i,v in ipairs(extraShipEntities) do
        if not IsNull(v) then
            v:SetVisibility(true, true)
        end
    end
end

function ExitToSpace(trigger, avatar)
    if not IsNull(_T.curTransmission) then
        _T.QueuedTransmissions = {}
        LOTUS_UTIL.InterruptTransmission(_T.curTransmission)
    end
    _T.BlockTransmissionsFromSender = "/Lotus/Language/Bosses/Ordis"

    --[[local showShip = gRegion:FindFirstTagged(Symbol("ShowCorpusShip"))
    if not IsNull(showShip) then
        showShip:FirePort("Execute")
    end]]

    if gRegion:IsMaster() then
        if not IsNull(destroyAvatarsType) then
            local destroyAvatars = gRegion:FindAll(destroyAvatarsType) or {}
            for i,v in ipairs(destroyAvatars) do
                if not IsNull(v) then
                    v:Destroy()
                end
            end
        end
    end

    local t = 0
    while t < 1 do
        Sleep(0)
        t = t + DeltaTime() / 0.3
        gRegion:GetLevelInfo():GetPostProcessBias().fade = -SmoothStep(Clamp(t, 0, 1))
    end
        gRegion:GetLevelInfo():GetPostProcessBias().fade = -1
    Sleep(3)

    local cin1 = gRegion:FindFirstTagged(Symbol("BoardingRailJackCin"))
    if gRegion:IsMaster() then
        local destroyAvatars = gRegion:FindAll(destroyAvatarsType) or {}
        for i,v in ipairs(destroyAvatars) do
            if not IsNull(v) then
                v:Destroy()
            end
        end
        -- avatar:Teleport(cin1:GetPosition(), ZERO_ROTATION)
        -- Sleep(0)
        -- Sleep(0)

        avatar:SetAnimName(Symbol("ArchwingA"))
        avatar:PlayAnimation(nil, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_ONCE, false, 1.0)
        cin1:FirePort("StartPlaying")
    end
    while IsNull(gRegion:GetPlayingCinematic()) do
        Sleep(0)
    end

    local t = 0
    while t < 1 do
        Sleep(0)
        t = t + DeltaTime() / 0.3
        gRegion:GetLevelInfo():GetPostProcessBias().fade = -1 + SmoothStep(Clamp(t, 0, 1))
        for i,v in ipairs(gRegion:GetHumanPlayerAvatars() or {}) do
            if v:GetMeshScale() < 1.0 then
                v:SetMeshScale(1.0)
            end
        end
    end
    gRegion:GetLevelInfo():GetPostProcessBias().fade = 0

    while not IsNull(gRegion:GetPlayingCinematic()) do
        for i,v in ipairs(gRegion:GetHumanPlayerAvatars() or {}) do
            if v:GetMeshScale() < 1.0 then
                v:SetMeshScale(1.0)
            end
        end
        Sleep(0)
    end

    local waypoint = gRegion:FindFirstTagged(Symbol("TennoConBackToRailJackWaypoint"))
    if gRegion:IsMaster() and not IsNull(waypoint) and not IsNull(avatar) then
        avatar:Teleport(waypoint:GetPosition(), ZERO_ROTATION)
    end
end

function SetExplosionsIntensity()
    _T.CorpusShipExplosionsIntensity = Clamp(math.floor(newIntensity), 1, 3)
end

function Explosions(trigger, avatar)
    local INTERVAL_MIN = {0.9, 0.4, 0.3}
    local INTERVAL_MAX = {2.0, 1.0, 0.8}
    local COUNT_MIN = {1, 1, 1}
    local COUNT_MAX = {1, 2, 3}
    
    while IsNull(avatar) do
        Sleep(0)
        avatar = gRegion:GetLocalPlayerAvatar()
    end

    if RJ_UTIL.IsInCapitalShip(avatar) == false then
        return
    end
    
    Sleep(Random(INTERVAL_MIN[1], INTERVAL_MAX[1]))

    while trigger:IsEnabled() and not IsNull(avatar) and not IsNull(avatar:GetZone()) and avatar:GetZone():GetRegionIndex() == sCapitalShipRegionIndex do
        local intensityIdx = _T.CorpusShipExplosionsIntensity or 1
        local avoid = {avatar}
        
        for i=1,RandomInt(COUNT_MIN[intensityIdx], COUNT_MAX[intensityIdx]) do
            local angle = Random(0,360)
            local pos = avatar:GetSimPosition() --+ Vector(math.sin(math.rad(angle)) * distance, offset, math.cos(math.rad(angle)) * distance)
            pos.y = pos.y + 0.5
            
            local dir = Vector(math.sin(math.rad(angle)), Random(-0.1, 0.5), math.cos(math.rad(angle)))
            Normalize(dir)
            dir = dir * 100
            local hitPos = Vector()
            if gRegion:Raycast(pos, pos + dir, avatar, nil, hitPos, true, true) then
                local tooClose = false
                for j=1,#avoid do
                    tooClose = avoid[j]:DistanceToPoint(hitPos) < 3
                    if tooClose then
                        break
                    end
                end
                
                if not tooClose then
                    local explosion = gRegion:CreateEntity(explosionType, hitPos, Rotation(Random(0,360), Random(0,360), Random(0,360)))
                    table.insert(avoid, explosion)
                end
            end
        end
        
        Sleep(Random(INTERVAL_MIN[intensityIdx], INTERVAL_MAX[intensityIdx]))
    end
end

function CoreDecoFadeOut(coreDeco)
    coreDeco:SetTestRotate(false)
    local EMISSIVE_MAP_ATTEN = Symbol("EmissiveMapAtten")
    local baseEmissive = coreDeco:GetMaterialParam(EMISSIVE_MAP_ATTEN, 0)
    local t = 0
    while t < 1 do
        Sleep(0)
        t = t + DeltaTime() / 0.3
        coreDeco:SetMaterialParam(EMISSIVE_MAP_ATTEN, Lerp(baseEmissive, 0, SmoothStep(Clamp(t, 0, 1))))
    end
end

function DestroyCoreObjective(trigger, avatar)
    local objMarker = gRegion:FindFirstTagged(Symbol("CoreRoomObjectiveMarker")) 
    if not IsNull(objMarker) then
        objMarker:Enable()

        local npcManager = gRegion:GetNpcMgr()
        local aiDir = npcManager:GetAiDirector()
        aiDir:SetObjective(objMarker)
    end

    --TODO: Get some VO that mentions: "Break Into The Core Room!"
end

function CoreRoomObjective(trigger, avatar)
    local player = avatar:GetPlayer()
    local targets = gRegion:FindTagged(Symbol("CoreRoomPillarTarget")) 
    local numTargets = #targets

    while numTargets > 0 do
        for i=numTargets,1,-1 do
            if IsNull(targets[i]) then
                table.remove(targets, i)
                numTargets = numTargets - 1

                local shieldOrb = gRegion:FindFirstTagged(Symbol("ShieldOrbSeq"))
                if not IsNull(shieldOrb) then
                    local shieldOrbSoundInstance = shieldOrb:GetSoundInstance()
                    if not IsNull(shieldOrbSoundInstance) then
                        local currentPitch = shieldOrbSoundInstance:GetPitch()
                        local newPitch = currentPitch + pitchIncreaseOnTargetDestroy
                        shieldOrbSoundInstance:SetPitch(newPitch)
                    end
                end

                if numTargets == 1 then
                    local voTrigger = gRegion:FindFirstTagged(Symbol("Ordis1MinVO"))
                    if not IsNull(voTrigger) then
                        voTrigger:FirePort("Execute")
                    end
                end
            end
        end
        Sleep(0)
    end
    
    local coreExposedForwarder = gRegion:FindFirstTagged(Symbol("ShieldCoreExposedForwarder"))
    if not IsNull(coreExposedForwarder) then
        coreExposedForwarder:FirePort("TriggerPort")
    end

    local coreDeco = gRegion:FindFirstTagged(Symbol("ShieldCoreDeco"))
    if not IsNull(coreDeco) then
        coreDeco:ScriptRunChildScript(Symbol("CoreDecoFadeOut"), false)
    end
    
    if not gRegion:IsMaster() then
        return
    end
    
    local scanDecos = {coreDeco}

    while IsNull(player:GetAvatar()) do
        Sleep(0)
    end
    
    -- while GAMEMODE.NumItemsScanned(player:GetAvatar(), scanDecos, false) < 1 do
    --     Sleep(0)
    -- end
    
    -- local scannedSeq = gRegion:FindFirstTagged(Symbol("SonarScanSeq"))
    -- if not IsNull(scannedSeq) then
    --     scannedSeq:Enable()
    -- end

    local outsideMarker = gRegion:FindFirstTagged(Symbol("ShieldCoreOutsideTarget"))
    if not IsNull(outsideMarker) then
        outsideMarker:Enable()
    end

    local weakpointProj = gRegion:FindFirstTagged(Symbol("ObeliskWeakPointProj"))
    if not IsNull(weakpointProj) then
        weakpointProj:SetVisibility(true)
    end
    
    local objMarker = gRegion:FindFirstTagged(Symbol("CoreRoomObjectiveMarker")) 
    if not IsNull(objMarker) then
        objMarker:Disable()
    end
    
    _T.EnableRailJackDamageResponse = false
    -- local fighters = gRegion:GetAvatarsByFaction(CORPUS_FACTION, true)
    -- for i, enemy in ipairs(fighters) do
    --     if not IsNull(enemy) then
    --         enemy:Destroy()
    --     end
    -- end
    -- local spawnpoints = gRegion:FindTagged(Symbol("FighterSpawner"))
    --  for i, spawn in ipairs(spawnpoints) do
    --     if not IsNull(spawn) then
    --         spawn:FirePort("Disable")
    --         spawn:FirePort("Stop")
    --     end
    -- end
    local ordisPreFire = gRegion:FindFirstTagged(Symbol("OrdisPreFireVO"))
    if not IsNull(ordisPreFire) then
        ordisPreFire:Enable()
    end
    
    while not _T.TennoConTargetHit do
        Sleep(0)
    end

    if not IsNull(outsideMarker) then
        outsideMarker:Disable()
    end

    if not IsNull(weakpointProj) then
        weakpointProj:SetVisibility(false)
    end
    
    local crpObeliskDeco = gRegion:FindFirstTagged(Symbol("CrpObeliskDeco"))
    if not IsNull(crpObeliskDeco) then
        crpObeliskDeco:MakeVulnerable()
    end
    
    local exitMarker = gRegion:FindFirstTagged(Symbol("ExitMarker")) 
    if not IsNull(exitMarker) then
        exitMarker:Enable()
    end
    
    local explosions = gRegion:FindFirstTagged(Symbol("CorpusShipInteriorExplosions"))
    if not IsNull(explosions) then
        while IsNull(player:GetAvatar()) do
            Sleep(0)
        end
        explosions:RunScriptsOnEntity(player:GetAvatar())
    end
    
    local shieldCoreDestroyedForwarder = gRegion:FindFirstTagged(Symbol("ShieldCoreDestroyedForwarder"))
    if not IsNull(shieldCoreDestroyedForwarder) then
        shieldCoreDestroyedForwarder:FirePort("TriggerPort")
    end
end

local function UpdateHyperDriveState(shipAvatar, hyperDriveState)
    
end

local mQueryId = 0
local mHitEntity = nil
local mQueryReturned = false

function AsyncRaycastCallback(queryID, hitEntity)
    mQueryReturned = true
    mQueryId = queryID
    mHitEntity = hitEntity
end

local function UpdateLightVis(shipAvatar, dir)
    local dir2 = dir * 200
    local pos = shipAvatar:GetSimPosition()
    local hitPos = Vector()
    mQueryReturned = false
    mHitEntity = nil
    local raycastId = gRegion:AsyncRaycast(pos, pos + dir2, shipAvatar, nil, hitPos, true, true, false, "AsyncRaycastCallback")
    mQueryId = raycastId
    Sleep(0)
    while not mQueryReturned do
    print("Waiting for query to return")
        Sleep(0)
    end

    if not IsNull(mHitEntity) then
        return 0.0
    end
    return 1.0
end

function CrewShipLightFollower(light)
    local sunTag = Symbol("Sun")
    local sunDir = Vector(0,0.2,1)
    local sourceSunDir = Vector(0,0.2,1)
    Normalize(sunDir)

    local sunColor = light:GetColor()
    local sceneSun = nil
    local sunIntensity = 1.0
    local ignoreSunLight = nil
    local rjVis = 1.0
    local localAv = nil
    local inventoryControl = nil
    local ship = nil
    local shipAvatar = nil

    while not IsNull(light) do
        if IsNull(localAv) then
            localAv = gRegion:GetLocalPlayerAvatar()
            if not IsNull(localAv) then
                inventoryControl = localAv:InventoryControl()
            end
        end

        if not IsNull(localAv) then
            if IsNull(ship) then
                ship = inventoryControl:GetOnBoardShip()
                shipAvatar = nil
            end

            if not IsNull(ship) then
                if IsNull(shipAvatar) then
                    shipAvatar = ship:GetAvatarOwner()
                end

                if IsNull(sceneSun) then
                    sceneSun = gRegion:FindFirstTagged(sunTag)
                    if sceneSun == ignoreSunLight then
                        sceneSun = nil
                    else
                        ignoreSunLight = nil
                    end
                end
                
                if not IsNull(sceneSun) then
                    sourceSunDir = sceneSun:GetDirectionalLightDir()
                    sourceSunDir.y = sourceSunDir.y + 0.1
                    Normalize(sourceSunDir)
                    sunDir = LerpVector(sunDir, sourceSunDir, DeltaTime() * 1.75)
                    Normalize(sunDir)
                    sunColor = sceneSun:GetColor()
                end

                if not IsNull(_T.CrewShipActiveEntity) then
                    
                    -- blend
                    shipAvatar = _T.CrewShipActiveEntity

                    local vis = UpdateLightVis(shipAvatar, sunDir)
                    rjVis = Lerp(rjVis, vis, DeltaTime() * 1.75)

                    local rot = shipAvatar:GetRotation()
                    rot = InverseRotation(rot)
                    local dir = RotateVector(sunDir, rot)
                    local oldDir = light:GetDirectionalLightDir()
                    dir = LerpVector(oldDir, dir, DeltaTime() * 1.75)
                    Normalize(dir)
                    light:SetDirectionalLightDir(dir)
                    sunColor = sunColor * Clamp(rjVis, 0.01, 1.0)
                    light:SetColor(light:GetColor():Lerp(sunColor, DeltaTime() * 1.75))

                elseif not IsNull(shipAvatar) then
                    local hyperDriveState = shipAvatar:GetHyperDriveState()
                    UpdateHyperDriveState(shipAvatar, hyperDriveState)
                    
                    local isAugmentedReality = false
                    local attachParent = localAv:GetAttachParent()
                    if not IsNull(attachParent) and attachParent:IsA(gShipGunnerEmplacementType) then
                        isAugmentedReality = attachParent:IsAugmentedRealityDarkened()
                    end
                    
                    if isAugmentedReality or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP then
                        sunIntensity = math.max(sunIntensity - DeltaTime(), 0.0)
                        if IsNull(ignoreSunLight) and not IsNull(sceneSun) then
                            ignoreSunLight = sceneSun
                        end
                    elseif not ignoreSunLight then
                        sunIntensity = math.min(sunIntensity + DeltaTime(), 1.0)
                    end
                
                    local rot = shipAvatar:GetSimRotation()
                    
                    local greenRoom = ship:GetGreenRoom()
                    if not IsNull(greenRoom) and shipAvatar:GetZone() == greenRoom:GetZone() then
                        local backdropZone = greenRoom:GetZone():GetBackdrop()
                        
                        if not IsNull(backdropZone) then
                            local backdropTransformEntity = backdropZone:GetTransformEntity()
                            if not IsNull(backdropTransformEntity) then
                                rot = backdropTransformEntity:GetSimRotation() -- TODO: Combine rotations?
                            end
                        end
                    end
                    
                    
                    local vis = UpdateLightVis(shipAvatar, sunDir)
                    rjVis = Lerp(rjVis, vis, DeltaTime() * 1.75)
                    
                    rot = InverseRotation(rot)
                    local dir = RotateVector(sunDir, rot)
                    local oldDir = light:GetDirectionalLightDir()
                    dir = LerpVector(oldDir, dir, DeltaTime() * 1.75)
                    Normalize(dir)
                    light:SetDirectionalLightDir(dir)
                    
                    local targetColor = Color(sunColor.red * sunIntensity * rjVis, sunColor.green * sunIntensity * rjVis, sunColor.blue * sunIntensity * rjVis)
                    light:SetColor(light:GetColor():Lerp(targetColor, DeltaTime() * 1.75))
                end
            end
        end
        Sleep(0)
    end
end
