mine = Instance()
rotationTime = 0.5
flare = Instance()
flareColorPassive = Color(255, 195, 15)
flareColorSuspicious = Color(255, 139, 15)
flareColorAlarm = Color(255, 54, 15)
volumetricLightPassive = Instance()
volumetricLightSuspicious = Instance()
volumetricLightAlarm = Instance()
roundLamp = Instance()
roundLampSlot = 0
secondaryLamps = {Instance()}
secondaryLampsSlot = 0
materialRoundLampPassive = Resource()
materialRoundLampSuspicious = Resource()
materialRoundLampAlarm = Resource()
materialSecondaryLampsPassive = Resource()
materialSecondaryLampsSuspicious = Resource()
materialSecondaryLampsAlarm = Resource()
shipSpeedThreshold = 20
suspiciousTimeMax = 5
reinforcementsSpawnPoints = {Instance()}

local function SwitchToPassive()
--Lights
--if IsNull(volumetricLightPassive) or IsNull(volumetricLightSuspicious) or IsNull(volumetricLightAlarm) then
--   return
--end

--volumetricLightPassive:TurnOn()
--volumetricLightSuspicious:TurnOff()
--volumetricLightAlarm:TurnOff()


if IsNull(flare) then
    return
end

flare:SetTint(flareColorPassive)

-- Materials
if not IsNull(materialRoundLampPassive) then
    return
end

if not IsNull(roundLamp) then
    roundLamp:SetOverrideMaterial(roundLampSlot, materialRoundLampPassive)
end

if #secondaryLamps > 0 or not IsNull(materialSecondaryLampsPassive) then
    for i = 1, #secondaryLamps do
        secondaryLamps[i]:SetOverrideMaterial(secondaryLampsSlot, materialSecondaryLampsPassive)
    end
end


end


local function SwitchToSuspicious()
--Lights
--if IsNull(volumetricLightPassive) or IsNull(volumetricLightSuspicious) or IsNull(volumetricLightAlarm) then
--   return
-- end

--volumetricLightPassive:TurnOff()
--volumetricLightSuspicious:TurnOn()
--volumetricLightAlarm:TurnOff()

if IsNull(flare) then
    return
end

flare:SetTint(flareColorSuspicious)

-- Materials
if IsNull(materialRoundLampSuspicious) then
    return
end

if not IsNull(roundLamp) then
    roundLamp:SetOverrideMaterial(roundLampSlot, materialRoundLampSuspicious)
end

if #secondaryLamps > 0 or not IsNull(materialSecondaryLampsSuspicious) then
    for i = 1, #secondaryLamps do
        secondaryLamps[i]:SetOverrideMaterial(secondaryLampsSlot, materialSecondaryLampsSuspicious)
    end
end


end


local function SwitchToAlarm()
--Lights
--if IsNull(volumetricLightPassive) or IsNull(volumetricLightSuspicious) or IsNull(volumetricLightAlarm) then
--    return
--end

--volumetricLightPassive:TurnOff()
--volumetricLightSuspicious:TurnOff()
--volumetricLightAlarm:TurnOn()

if IsNull(flare) then
    return
end

flare:SetTint(flareColorAlarm)

-- Materials
if IsNull(materialRoundLampAlarm) then
    return
end

if not IsNull(roundLamp) then
    roundLamp:SetOverrideMaterial(roundLampSlot, materialRoundLampAlarm)
end

if #secondaryLamps > 0 or not IsNull(materialSecondaryLampsAlarm) then
    for i = 1, #secondaryLamps do
        secondaryLamps[i]:SetOverrideMaterial(secondaryLampsSlot, materialSecondaryLampsAlarm)
    end
end

end

local function SpawnReinforcements()

    if #reinforcementsSpawnPoints == 0 then
        return
    end

    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    if not aiDir:HasRoomTillHardCap(#reinforcementsSpawnPoints) then
        return
    end
    local faction = Symbol("Grineer")
    local level = aiDir:GetRandomSpaceEnemyLevel()
    local team = Symbol("RandomTeam")
    local enemyFighterTier = 95
    for i = 1, #reinforcementsSpawnPoints do
        local agentType = aiDir:GetRandomEnemyAgentType(faction, level, false, false, enemyFighterTier, true)
        if not IsNull(agentType) then
            local agent = aiDir:CreateAgent(agentType, reinforcementsSpawnPoints[i], team, level)
            if not IsNull(agent) then
                agent:SetAlert()
            end
        end
        Sleep(0)
    end

end


function EnableVelocityMine(trigger) --OnLevelStarted, position battery+beam, spawn reward
    local minePos = nil
    local ship = nil
    local shipPos = nil
    local mineRotDesired = nil
    local entitiesTouching = nil
    local mineRot
    local mineRotOld
    
    if IsNull(mine) then
        return
    end
    
    mineRotOld = mine:GetRotation()
    minePos = mine:GetPosition()
    
    if IsNull(trigger) then
        return
    end
    
    local t = 0
    local suspiciousTime = 0
    local shipSpeed = 0
    local isAlarm = false
    
    while true do
        if not IsNull(mine) then
            if trigger:HasAvatarTouching() then
                entitiesTouching = trigger:GetEntitiesTouching()
                if #entitiesTouching == 1 then
                    ship = entitiesTouching[1]
                else
                    --Will eventually get the speed of the fastest one
                    ship = entitiesTouching[1]
                end
                
                shipSpeed = ship:GetSpeed()
                --Broadcast(shipSpeed)
                
                if shipSpeed >= shipSpeedThreshold then
                    suspiciousTime = suspiciousTime + DeltaTime()
                else
                    suspiciousTime = suspiciousTime - DeltaTime()
                end
                
                if t == 0 then
                    shipPos = ship:GetPosition()
                    mineRot = mine:GetRotation()
                    mineRotDesired = LookTo(minePos, shipPos)
                    Sleep(0)
                    t = t + DeltaTime()
                elseif t < rotationTime then
                    local mineRotNew = LerpRotation(mineRot, mineRotDesired, t / rotationTime)
                    mine:SetRotation(mineRotNew)
                    Sleep(0)
                    t = t + DeltaTime()
                elseif t >= rotationTime then
                    t = 0
                else Sleep(0)
                end
            else
                Sleep(0)
            end
            
            -- Managing States
            
            if not isAlarm then
                    if suspiciousTime >= suspiciousTimeMax then
                        SwitchToAlarm()
                        SpawnReinforcements()
                        isAlarm = true
                    elseif suspiciousTime < suspiciousTimeMax and suspiciousTime > 0 then
                        SwitchToSuspicious()
                    else
                        SwitchToPassive()
                        suspiciousTime = 0
                    end
                elseif isAlarm and not trigger:HasAvatarTouching() then
                    suspiciousTime = suspiciousTime - DeltaTime()
                    if suspiciousTime <= 0 then
                        isAlarm = false
                        SwitchToPassive()
                        return
                    end
                end
            
        else -- Destroying attachments and leaving script
            if not IsNull(trigger) then
                trigger:Destroy()
            end
            if not IsNull(volumetricLightPassive) then
                volumetricLightPassive:Destroy()
            end
            if not IsNull(volumetricLightSuspicious) then
                volumetricLightSuspicious:Destroy()
            end
            if not IsNull(volumetricLightAlarm) then
                volumetricLightAlarm:Destroy()
            end
            if not IsNull(flare) then
                flare:Destroy()
            end
            return
        end
            
    end

end