local PLAYER_SKILL_LIB = require "Lotus.Scripts.Libs.PlayerSkillsLib"

local function AddSkillUpgrades(upgrade, avatar, add)
    if add then
        local damageControl = avatar:DamageControl()
        local maxShield = damageControl:GetMaxShield()
        
        local healthPct = avatar:GetHealthPercentage()
        local shieldPct = (maxShield > 0 and damageControl:GetShield() / maxShield) or 1
        
        avatar:InventoryControl():AddUpgrade(upgrade)
        --print("Added Skill Upgrade "..upgrade:GetUpgradeType().. " to " .. avatar:GetName())
        
        -- Compensate for AVATAR_HEALTH_MAX and AVATAR_SHIELD_MAX upgrades
        if not avatar:IsKilled() and not avatar:IsPreDeath() then
            if upgrade:GetUpgradeType() == Game.AVATAR_HEALTH_MAX then
                local health = math.floor(avatar:GetMaxHealth() * healthPct + 0.5)
                health = math.max(health, damageControl:PreDeathHealthThreshold())
                avatar:SetHealth(health)
            elseif upgrade:GetUpgradeType() == Game.AVATAR_SHIELD_MAX then
                damageControl:SetShield(math.floor(damageControl:GetMaxShield() * shieldPct + 0.5), true)
            end
        end
    else
        avatar:InventoryControl():RemoveUpgrade(upgrade)
        --print("Removed Skill Upgrade "..upgrade:GetUpgradeType().. " to " .. avatar:GetName())
    end
end

local function ApplyUpgrades(avatar, player, add, archwingOnly)
    if IsNull(player) then -- crashing in dojo?
        return
    end

    for i = 1, Lotus_Game.MAX_LotusPlayerSkill - 1 do
        --local playerSkillRank = playerProfileData:GetPlayerSkill(i)
        local playerSkillRank = player:GetSkillRank(i)

--~         -- TEST VALUES
--~         if i == Lotus_Game.LPS_TACTICAL then
--~             playerSkillRank = 10
--~         end
--~         if i == Lotus_Game.LPS_GUNNERY then
--~             playerSkillRank = 10
--~         end
--~         -- TEST VALUES

        if playerSkillRank > 0 then
            --print("Player Skill ".. i.. " Rank"..playerSkillRank)
            local upgrades = PLAYER_SKILL_LIB.GetUpgrades(i, playerSkillRank, false, archwingOnly)
            if not IsNull(upgrades) then
                for rankUpgradeIndex = 1, #upgrades do
                    AddSkillUpgrades(upgrades[rankUpgradeIndex], avatar, add)
                    --print(upgrades[rankUpgradeIndex].upgrade:GetUpgradeType())
                    --print(upgrades[rankUpgradeIndex].isPlayerUpgrade)
                end
            end
        end
    end
end

function ApplySkillUpgrades(avatar, player)
    ApplyUpgrades(avatar, player, true, false)
end

function ApplyArchwingUpgrades(avatar, player)
    ApplyUpgrades(avatar, player, true, true)
end

function RemoveArchwingUpgrades(avatar, player)
    ApplyUpgrades(avatar, player, false, true)
end