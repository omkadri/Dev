openAnim = Resource()
closeAnim = Resource()
openIdleAnim = Resource()
closeIdleAnim = Resource()
dummyVersion = false
explosionFxType = Type()
explosionFxOffset = Vector(0,0,0)

local pointOfInterestAvatarType = WeakResource("/Lotus/Types/Game/CrewShip/PointOfInterestAvatar")

local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"

local mRadiator = nil
local mMarker = nil
local mProxies
local mOpen = false

local RECOVER_TIME = 10

local function SetInvulnerable(invuln)
    if mRadiator:GetHealth() <= 0 then
        return
    end

    if invuln then
        mRadiator:MakeInvulnerable()
        mMarker:Disable()
    else
        mRadiator:MakeVulnerable()
        mMarker:Enable()
    end
    
    for i, proxy in ipairs(mProxies) do
        proxy:SetInvulnerable(invuln)
    end
end

local function Open()
    mOpen = true
    local pos = mRadiator:GetPosition()
    print("MissilePlatformWeakpoint.lua - Weakpoint exposed at " .. pos.x .. " " .. pos.y .. " " .. pos.z)
    mRadiator:PlayAnimation(openAnim, true, false)
    mRadiator:PlayAnimation(openIdleAnim, false, true)
    if not dummyVersion then
        SetInvulnerable(false)
    end
end

local function Close()
    mOpen = false
    mRadiator:PlayAnimation(closeAnim, true, false)
    mRadiator:PlayAnimation(closeIdleAnim, false, true)
    if not dummyVersion then
        SetInvulnerable(true)
    end
end

function Visibility(mRadiator)
    local player = gRegion:GetLocalPlayer()
    while IsNull(player) do
        Sleep(1)
        player = gRegion:GetLocalPlayer()
    end
    local avatar = player:GetAvatar()
    
    local shipAvatar = gRegion:FindNearest(pointOfInterestAvatarType, mRadiator:GetPosition())
    while IsNull(shipAvatar) do
        Sleep(1)
        shipAvatar = gRegion:FindNearest(pointOfInterestAvatarType, mRadiator:GetPosition())
    end
    local ship = shipAvatar:InventoryControl():GetActivePowerSuit()
    
    while not IsNull(mRadiator) do
    
        if IsNull(player) then
            player = gRegion:GetLocalPlayer()
        elseif IsNull(avatar) or avatar:IsKilled() then
            avatar = player:GetAvatar()
        elseif mRadiator:GetDissolve() == 0 and RAIL.IsPlayerAvatarOnShip(avatar, ship) then
            mRadiator:SetDissolve(1)
        elseif mRadiator:GetDissolve() == 1 and not RAIL.IsPlayerAvatarOnShip(avatar, ship) then
            mRadiator:SetDissolve(0)
        end
        
        Sleep(0)
    end
end

function Radiator(radiator)
    mRadiator = radiator
    if not dummyVersion then
        mRadiator:ScriptRunChildScript(Symbol("Visibility"), false)
    end
    
    mMarker = mRadiator:GetAttachment(gBaseMarkerInfoType)
    while IsNull(mMarker) do
        Sleep(0)
        mMarker = mRadiator:GetAttachment(gBaseMarkerInfoType)
    end
    mMarker:Disable()
    
    mProxies = mRadiator:GetAllAttachments(gHitProxyType)
    while IsNull(mProxies) or #mProxies < 3 do
        Sleep(0)
        mProxies = mRadiator:GetAllAttachments(gHitProxyType)
    end
    
    SetInvulnerable(true)
    
    if mRadiator:IsActivated() then
        Open()
    end
    
    while mRadiator:IsEnabled() do
        if mRadiator:GetHealth() <= 0 then
            break
        end

        if mOpen and not mRadiator:IsActivated() then
            Close()
        elseif not mOpen and mRadiator:IsActivated() then
            Open()
        end
        
        Sleep(0)
        
        if IsNull(mRadiator) then
            return
        end
    end
    
    mRadiator:Disable()
    print("MissilePlatformWeakpoint.lua - Weakpoint disabled")
    SetInvulnerable(true)

    if not IsNull(mMarker) then
        mMarker:Disable()
    end
    mRadiator:Attach(explosionFxType, Symbol("FX_C1_TOP"), explosionFxOffset, ZERO_ROTATION)
end
