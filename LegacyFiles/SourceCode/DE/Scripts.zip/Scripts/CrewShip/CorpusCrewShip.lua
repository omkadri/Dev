warpFxType = Type()
engineFxType = Type()
weakPointType = WeakResource()
shieldFxType = Type()
retreatTimer = 10 --dissolve and remove after retreating for this long

local TIMER = require "Lotus.Interface.Libs.TimerMgr"

local engineDecoType = WeakResource("/Lotus/Fx/Enemies/Grineer/SpaceCrewShip/GrnCrewShipV2ThrusterCapDeco")
local engineOverrideParam = Symbol("EmissiveTintColorZZZ")
local engineOnColor = Color(200,255,0,255)
local engineOffColor = Color(0,0,0,255)
local disabledFxTag = Symbol("disabledFx")
local engineExplosionFxTag = Symbol("engineExplosionFx")
local sInvulnSymbol = Symbol("CrewShipBlockingInvuln")
local sEnterShipAction = Symbol("EnterShipAction")

local mAvatar
local mTimerMgr
local mNeedsTimerUpdate = 0

local mLeftEngineFx
local mRightEngineFx
local mCenterEngineFx = {}

local mEnterShipAction
local mEnginesPowered = true
local mDamagedEngines = {}
local mWeakpoints = {}
local mShieldFx

local centerEngineTag = Symbol("MainEngine")
local leftEngineTag = Symbol("LeftManeuverThruster")
local rightEngineTag = Symbol("RightManeuverThruster")

local LEFT_ENGINE_BONE = Symbol("FX_L1_ENGINETHRUSTER")
local RIGHT_ENGINE_BONE = Symbol("FX_R1_ENGINETHRUSTER")
local CENTER_TOP_ENGINE_BONE = Symbol("FX_C1_TOPTHRUSTER")
local CENTER_LEFT_ENGINE_BONE = Symbol("FX_L1_TOPTHRUSTER")
local CENTER_RIGHT_ENGINE_BONE = Symbol("FX_R1_TOPTHRUSTER")

local damageMultipliers = { MainEngine = {type=Engine.DT_ANY, part=Engine.HEAD, factor=5}, LeftManeuverThruster = {type=Engine.DT_ANY, part=Engine.ARM_LEFT, factor=5}, RightManeuverThruster = {type=Engine.DT_ANY, part=Engine.ARM_RIGHT, factor=5}}

local function UpdateEngineFx(specificTag, isDamage)
    local destroyed = mDamagedEngines[specificTag:c_str()]
    local engineOn = mEnginesPowered and not destroyed
    
    if not specificTag then
        for _, fx in pairs(mCenterEngineFx) do
            if fx:HasTag(disabledFxTag) then
                if isDamage then
                    if destroyed then
                        fx:Enable()
                        fx:SetVisibility(true, false)
                    else
                        fx:Disable()
                        fx:SetVisibility(false, false)
                    end
                end
            elseif fx:HasTag(engineExplosionFxTag) and not engineOn and isDamage then
                fx:FirePort("Burst")
            else
                fx:SetVisibility(engineOn, true)
            end
        end
        
        if mLeftEngineFx:HasTag(disabledFxTag) then
            if isDamage then
                if destroyed then
                    mLeftEngineFx:Enable()
                    mLeftEngineFx:SetVisibility(true, false)
                else
                    mLeftEngineFx:Disable()
                    mLeftEngineFx:SetVisibility(false, false)
                end
            end
        elseif mLeftEngineFx:HasTag(engineExplosionFxTag) and not engineOn and isDamage then
            mLeftEngineFx:FirePort("Burst")
        else
            mLeftEngineFx:SetVisibility(engineOn, true)
        end
        
        if mRightEngineFx:HasTag(disabledFxTag) then
            if isDamage then
                if destroyed then
                    mRightEngineFx:Enable()
                    mRightEngineFx:SetVisibility(true, false)
                else
                    mRightEngineFx:Disable()
                    mRightEngineFx:SetVisibility(false, false)
                end
            end
        elseif mRightEngineFx:HasTag(engineExplosionFxTag) and not engineOn and isDamage then
            mRightEngineFx:FirePort("Burst")
        else
            mRightEngineFx:SetVisibility(engineOn, true)
        end
    elseif specificTag == centerEngineTag then
        for _, fx in pairs(mCenterEngineFx) do
            if fx:HasTag(disabledFxTag) then
                if isDamage then
                    if destroyed then
                        fx:Enable()
                        fx:SetVisibility(true, false)
                    else
                        fx:Disable()
                        fx:SetVisibility(false, false)
                    end
                end
            elseif fx:HasTag(engineExplosionFxTag) and not engineOn and isDamage then
                fx:FirePort("Burst")
            else
                fx:SetVisibility(engineOn, true)
            end
        end
    elseif specificTag == leftEngineTag 
        local fx = mLeftEngineFx
        if fx:HasTag(disabledFxTag) then
            if isDamage then
                if destroyed then
                    fx:Enable()
                    fx:SetVisibility(true, false)
                else
                    fx:Disable()
                    fx:SetVisibility(false, false)
                end
            end
        elseif fx:HasTag(engineExplosionFxTag) and not engineOn and isDamage then
            fx:FirePort("Burst")
        else
            fx:SetVisibility(engineOn, true)
        end
    elseif specificTag == rightEngineTag 
        local fx = mRightEngineFx
        if fx:HasTag(disabledFxTag) then
            if isDamage then
                if destroyed then
                    fx:Enable()
                    fx:SetVisibility(true, false)
                else
                    fx:Disable()
                    fx:SetVisibility(false, false)
                end
            end
        elseif fx:HasTag(engineExplosionFxTag) and not engineOn and isDamage then
            fx:FirePort("Burst")
        else
            fx:SetVisibility(engineOn, true)
        end
    end
    
    mNeedsTimerUpdate = mNeedsTimerUpdate + 1
end

local function UnboardNonRailjackBoardedPlayers()
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetPlayerShip()
    
    if IsNull(ship) then
        return
    end
    
    local players = gRegion:GetHumanPlayers()
    local playerData= {}
    for _,player in ipairs(players) do
        local playerAvatar = player:GetAvatar()
        if not IsNull(playerAvatar) then
            local onBoardShip = playerAvatar:InventoryControl():GetOnBoardShip()
            if not IsNull(onBoardShip) and onBoardShip ~= ship then
                local onBoardShipAvatar = onBoardShip:GetAvatarOwner()
                if not IsNull(onBoardShipAvatar) then
                         local action = playerAvatar:GameActionControl():GetCurrentGameAction()
                         if not IsNull(action) and action:IsA(gEmplacementType) then
                            action:Disable()
                        end
                        table.insert(playerData, {playerAvatar,onBoardShipAvatar})
                end
            end
        end
    end
    
    Sleep(0.1)
    
    for i=1, #playerData do
            playerData[i][1]:Teleport(playerData[i][2]:GetPosition(), playerData[i][2]:GetRotation())
    end
end

function CorpusCrewShip(avatar)
    mTimerMgr = TIMER.CreateTimerMgr()
    
    local ship = avatar:InventoryControl():GetActivePowerSuit()
    while IsNull(ship) do
        Sleep(0)
        ship = avatar:InventoryControl():GetActivePowerSuit()
    end
    
    mAvatar = avatar
    
    avatar:RegisterOnPredeathCallback("OnPreDeath")
    avatar:DamageControl():RegisterArmourDestroyedChangedCallback("OnArmourGroupDestroyedChanged")

    for i,v in pairs(damageMultipliers) do
        local tag = Symbol(i)
        avatar:DamageControl():RemoveDamageModifier(tag)
        avatar:DamageControl():AddDamageModifier(tag, v.type, v.part, v.factor)
    end

    ship:RegisterEnginesPoweredCallback("OnEnginesPowerChanged")
    
    mLeftEngineFx = avatar:Attach(engineFxType, LEFT_ENGINE_BONE)
    mRightEngineFx = avatar:Attach(engineFxType, RIGHT_ENGINE_BONE)
    
    local engineFx = avatar:Attach(engineFxType, CENTER_TOP_ENGINE_BONE)
    table.insert(engineFx, mCenterEngineFx)
    engineFx = avatar:Attach(engineFxType, CENTER_LEFT_ENGINE_BONE)
    table.insert(engineFx, mCenterEngineFx)
    engineFx = avatar:Attach(engineFxType, CENTER_RIGHT_ENGINE_BONE)
    table.insert(engineFx, mCenterEngineFx)
  
    while true do
        Sleep(0)
        
        if mNeedsTimerUpdate > 0 then
            mTimerMgr:Update(DeltaTime())
        end
    end
end

function OnArmourGroupDestroyedChanged(group, destroyed)
    local tag = group:GetTag()
    mDamagedEngines[tag:c_str()] = destroyed
    mAvatar:DamageControl():RemoveDamageModifier(tag)
    if not destroyed then
        local props = damageMultipliers[tag:c_str()]
        mAvatar:DamageControl():AddDamageModifier(tag, props.type, props.part, props.factor)
    end
    UpdateEngineFx(tag, true)
end

function OnEnginesPowerChanged(avatar, powered)
    mEnginesPowered = powered
    UpdateEngineFx(nil, false)
end

function OnPreDeath()
    UpdateEngineFx(nil, true)
end

function RemoveOnRetreat(agent)
    local t = 0
    while t <= retreatTimer and not IsNull(agent) do
        t = t + DeltaTime()
        Sleep(0)
    end
    
    if IsNull(agent) then
        return
    end
    local avatar = agent:GetAvatar()
    if not IsNull(avatar) then
        local warpFxAttached = false
        local dissolve = 0
        while dissolve <= 1 and not IsNull(avatar) do
            avatar:SetMaterialParam(Lotus_Game.CLOAK, dissolve)
            avatar:SetDissolve(dissolve)
            dissolve = dissolve + DeltaTime() + 0.1
            if dissolve >= 0.5 and not warpFxAttached then
                avatar:Attach(warpFxType,  EMPTY_SYMBOL)
                warpFxAttached = true
            end
            Sleep(0)
        end
        
        if not IsNull(avatar) then
            if  gRegion:IsMaster() then
                UnboardNonRailjackBoardedPlayers()
            end
            Sleep(0.1)
            avatar:Destroy()
        end
    end
    
end
