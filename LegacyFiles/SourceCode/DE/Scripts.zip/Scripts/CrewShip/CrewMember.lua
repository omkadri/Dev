
flavorTextDataType = Type()

local UTIL = require "EE.Interface.Utilities"
local MARKOV_NAME_GENERATOR = require "Lotus.Scripts.Generators.MarkovNameGenerator"

local function FlavorTextGen(flavorTextData, flavorTextTag, isFemale)
    local flavorTextLib = require "Lotus.Interface.Libs.FlavorTextGenerator"
    local text = flavorTextLib.ProcessFlavorText(nil, "", flavorTextData, flavorTextTag, isFemale)
    return text
end

function GenerateFlavorText(seed, isFemale, faction)
    local oldSeed = GetSeed()
    local flavorText = ""
    SetSeed(UnsignedToRandSeed(tonumber(seed))) -- truncated

    local flavorTextData = gRegion:CreateObject(flavorTextDataType)

    if not IsNull(flavorTextData) then
        local locTag = flavorTextData:GetFlavorTextLocTag()
        local locData = flavorTextData:GetFlavorTextLocData()
        flavorText = FlavorTextGen(locData, locTag, isFemale)
    end
    SetSeed(oldSeed)
    return flavorText
end

function GenerateMarkovName(seed, isFemale, faction)
    local oldSeed = GetSeed()
    SetSeed(UnsignedToRandSeed(tonumber(seed))) -- truncated
    local name
    if isFemale then
        name = MARKOV_NAME_GENERATOR.GrineerFemaleName()
    else
        name = MARKOV_NAME_GENERATOR.GrineerMaleName()
    end
    SetSeed(oldSeed)
    return name
end