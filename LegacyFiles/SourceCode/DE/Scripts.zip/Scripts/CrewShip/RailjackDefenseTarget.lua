repairStartAnim = Resource()
repairAnim = Resource()
repairCompleteAnim = Resource()
repairInterval = 2      --how many seconds should pass between repairs
healthPerRepair = 0.2   --percentage of max health to repair per loop
invulnThreshold = 0.25  --deco is invuln when repairs until it is at or greater than this percentage of max health
hullBreach = Instance()

demoHackAvatarType = Type()
locTag = Symbol()

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local mCancelPressed = false

function DefenseTargetRepairAction(decoration)
    local repairAction = nil
    while not IsNull(decoration) do
        Sleep(1)
        if (IsNull(repairAction) or not repairAction:IsEnabled()) and decoration:GetHealth() < decoration:GetDefaultHealth() then
            if IsNull(repairAction) then
                repairAction = decoration:GetAttachment(gContextActionType)
            end
            
            repairAction:Enable()
        end
    end
end

function UsePressed(inputEventData)
    if inputEventData == 1 then
        mCancelPressed = true
    end
end

function Repair(action, instigator)
    local target = action:GetAttachParent()
    local health = target:GetHealth()
    local maxHealth = target:GetDefaultHealth()
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()
    local breachHull = aiDir:GetHullBreach()
    
    if health == 0 then
        target:FirePort("Regenerate")
    end
    
    if health < invulnThreshold * maxHealth then
        target:MakeInvulnerable()
    end
    
    instigator:PlayNonReplicatedAnimation(repairStartAnim, true, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_FREEZE, true)
    instigator:PlayNonReplicatedAnimation(repairAnim, false, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_LOOP, true)
    instigator:GetPlayer():PushScriptedInputHandler(Symbol("DefenseTargetRepair"), gFlashMgr:GetInputCodeValue("USE"), "UsePressed")
    
    local t = 0
    while 
        not mCancelPressed and
        not instigator:IsKilled() and 
        target:GetHealth() < maxHealth 
    do
        Sleep(0)
        
        t = t + DeltaTime()
        
        if t > repairInterval then
            t = 0
            health = target:GetHealth() + maxHealth * healthPerRepair
            target:SetHealth(health)
            
            if health >= invulnThreshold * maxHealth then
                target:MakeVulnerable()
            end
        end
        if target:GetHealth() >  (maxHealth / 2) and breachHull then
            aiDir:ClearHullBreachSource(hullBreach)
            aiDir:SetHullBreach(false)
            breachHull = false
        end
        
        
    end
    
    if health >= invulnThreshold * maxHealth then
        target:MakeVulnerable()
    end
    
    instigator:GetPlayer():PopScriptedInputHandler(Symbol("DefenseTargetRepair"), gFlashMgr:GetInputCodeValue("USE"))
    instigator:PlayNonReplicatedAnimation(repairCompleteAnim, true, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_ONCE, true)
    if target:GetHealth() == maxHealth then
        action:Disable()
    end
end

local mDemoHackAvatar = nil
local mVisibleTime = 0
local mReactorTracker = nil
function OnDamaged(entity)
    mVisibleTime = 10
    mReactorTracker.SetVisible(true)
    if mDemoHackAvatar:DamageControl():IsPreDeath() then
        mDemoHackAvatar:InstantRevive()
    end
    if not mDemoHackAvatar:IsKilled() then
        mDemoHackAvatar:SetHealth(entity:GetHealth())
    end
end

function Reactor(reactor)
    while IsNull(gGameRules) do
        Sleep(1)
    end
    
    while IsNull(_T.AddHudTracker) do
        Sleep(1)
    end
    
    local hudTrackerName = reactor:GetFullName() .. "Tracker"
    ObjectPortHandler(reactor, "OnDamaged")
    
    if gRegion:IsMaster() then
        mDemoHackAvatar = gRegion:CreateEntity(demoHackAvatarType, reactor:GetPosition(), ZERO_ROTATION)
        mDemoHackAvatar:SetMaxHealth(reactor:GetDefaultHealth(), true)
        mDemoHackAvatar:SetVisibility(false, true)
        mDemoHackAvatar:SetHealth(reactor:GetDefaultHealth())
        
        mReactorTracker = _T.AddHudTracker(hudTrackerName, LOTUS_UTIL.HT_HEALTH_TRACKER)
        mReactorTracker.SetTarget(mDemoHackAvatar)
        mReactorTracker.SetVisible(false)
    else
        while IsNull(mReactorTracker) do
            Sleep(1)
            if _T.GetHudTracker then
                mReactorTracker = _T.GetHudTracker(hudTrackerName)
            end
        end
    end
    
    if reactor:GetLocTag() == EMPTY_SYMBOL then
        reactor:SetLocTag(locTag)
    end
    
    while not IsNull(reactor) do
        if gRegion:IsMaster() then
            mVisibleTime = mVisibleTime - DeltaTime()
            if mVisibleTime <= 0 and mReactorTracker.Data.Visible then
                mReactorTracker.SetVisible(false)
            end
        end
        
        Sleep(0)
    end
end