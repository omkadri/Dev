local PLAYER_SKILL_LIB = require "Lotus.Scripts.Libs.PlayerSkillsLib"

rotationShake = true

useOverrides = false

delayOverride = 0
tiltAttackOverride = 1
tiltReleaseOverride = 1.5
tiltHoldOverride = 0
maxTiltOverride = 7
engineeringStation = 1

local function GetRegionIndex(entity)
    local zone = entity:GetZone()
    if IsNull(zone) then
        return -1
    end
    
    return zone:GetRegionIndex()
end

function CameraTiltForRegionIndex(scriptTrigger)
    local triggerIndex = GetRegionIndex(scriptTrigger)
    while IsNull(gRegion:GetLocalPlayer()) or IsNull(gRegion:GetLocalPlayer():GetAvatar()) do
        Sleep(0)
    end
    local playerIndex = GetRegionIndex(gRegion:GetLocalPlayer():GetAvatar())
    
    if triggerIndex == -1 or playerIndex == -1 or triggerIndex ~= playerIndex then
        return
    end

    local INITIAL_DELAY = 0
    local TILT_ATTACK = 2
    local TILT_RELEASE = 1.5
    local TILT_HOLD = 0.0
    
    local MAX_TILT = 16
    
    if useOverrides then
        INITIAL_DELAY = delayOverride
        TILT_ATTACK = tiltAttackOverride
        TILT_RELEASE = tiltReleaseOverride
        TILT_HOLD = tiltHoldOverride
        MAX_TILT = maxTiltOverride
    end

    -- if you re-enable this be careful because playerAv may *go* null mid-way through loops below
    -- local tiltRot = Rotation()

    Sleep(INITIAL_DELAY)
    
    local playerAv = gRegion:GetLocalPlayerAvatar()
    while IsNull(playerAv) do
        Sleep(0)
        playerAv = gRegion:GetLocalPlayerAvatar()
    end

    local post = gRegion:GetLevelInfo().postProcess
    post.viewShake.mShakeSpeed = 0.8
    post.viewShake.mShakeStrength = 0.5
    if rotationShake then
        post.viewShake.mShakeFactorRot = Rotation(0.5, 0.5, 1)
        post.viewShake.mShakeFactorPos = 0.2
    end


    local t = 0
    while t < 1 do
        Sleep(0)
        t = t + DeltaTime() / TILT_ATTACK

        local a = Clamp(SmoothStep(1 - math.pow(1 - t, 8)), 0, 1)

        --local playerView = playerAv:GetCameraView()
        --tiltRot.bank = Lerp(0, MAX_TILT, (a + Noise(t)) * math.cos(math.rad(playerView.heading)))
        --playerAv:SetCameraView(CombineRotations(playerView, tiltRot))
        --playerAv:CameraControl():ShakeView(playerAv:GetPosition(), 10, 3 * Lerp(1, 0.3, a), 2)
        local shake = Noise(gGameRules:GetCurrentGameTime())
        post.viewShake.mShakeSpeed = Lerp(2, 1, a)
        post.viewShake.mShakeStrength = Lerp(shake * 7, 4, a)
    end

    t = 0
    while t < 1 do
        Sleep(0)
        t = t + DeltaTime() / TILT_HOLD

        --local playerView = playerAv:GetCameraView()
        --tiltRot.bank = MAX_TILT * math.cos(math.rad(playerView.heading)) 
        --playerAv:SetCameraView(CombineRotations(playerView, tiltRot))
    end

    t = 0
    while t < 1 do
        Sleep(0)
        t = t + DeltaTime() / TILT_RELEASE
        local a = SmoothStep(Clamp(t + Noise(t), 0, 1))

        --playerAv:CameraControl():ShakeView(playerAv:GetPosition(), 10, 3 * Lerp(0.3, 0.1, t), 1)
        post.viewShake.mShakeSpeed = Lerp(1, 0.8, a)
        post.viewShake.mShakeStrength = Lerp(4, 0.5, a)

        --local playerView = playerAv:GetCameraView()
        --tiltRot.bank = Lerp(MAX_TILT, 0, a) * math.cos(math.rad(playerView.heading))
        --playerAv:SetCameraView(CombineRotations(playerView, tiltRot))
    end
    
    post.viewShake.mShakeSpeed = 0.0
    post.viewShake.mShakeStrength = 0
    post.viewShake.mShakeFactorRot = Rotation(0.08, 0.08, 0.08)
    post.viewShake.mShakeFactorPos = 0.04
end

function PrepareRailjackStarchart()
    -- RJ host mode
    _T.InRailJackMode = 1
end

function CanOpenRailjackStarchart(consoleAction, instigator)
    if IsNull(gGameRules) or IsNull(gRegion) then
        return false
    end

    if IsNull(instigator) or not instigator:IsHumanPlayer() then
        return false
    end

    local crewShipMgr = gGameRules:GetCrewShipManager()
    if IsNull(crewShipMgr) or not crewShipMgr:CanOpenRailjackStartMap(instigator) then
        return false
    end

    return true
end

-- Do not want to include LotsUtilities, this is supposed to be lightweight
local function _IsInMission()
    if not IsNull(gMatchingService) and string.find(gMatchingService:GetSquadMission(), "Dojo") then
        return false
    end

    if not IsNull(gGameRules) then
        if gGameRules:IsA(gLotusPhotoBoothGameRulesType) then
            return false
        elseif gGameRules:IsA(gLotusGameRulesType) or gGameRules:IsA(gLotusBasePvpGameRulesType) then
            return true
        end
    end
    return false
end

function IsInMission()
    return _IsInMission()
end


function HostRailjackStarchartLoop(consoleAction)
    if IsNull(gRegion) then
        return
    end

    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    
    while not IsNull(gRegion)  do
        if gRegion:IsMaster() and _IsInMission() then
            local shouldEnable = true
        
            if IsNull(aiDir) or (aiDir:IsEnabled() and not aiDir:GetObjectiveComplete()) then
                if not gFlashMgr:GetConfigBool("CrewShip.AlwaysAllowStarChart") then
                    shouldEnable = false
                end
            end
        
            if shouldEnable then
                consoleAction:Enable()
            else
                consoleAction:Disable()
            end
        end
        
        if consoleAction:IsEnabled() then
            Sleep(0)
        else
            Sleep(1)
        end
    end
end


function CanUseAWCannon(contextAction, instigator)
    local inMission = _IsInMission()
    if inMission == false then
        return false
    end

    local crewShipMgr = gGameRules:GetCrewShipManager()
    if IsNull(crewShipMgr) or crewShipMgr:GetMissionState() ~= Lotus_Game.CrewShipMgr_MISSION_ACTIVE then
        return false
    end   
    
    return true    
end

function GetSuperWeaponText(pEmplacement, pAvatar)
    if pAvatar and pEmplacement and pEmplacement:IsA(gShipGunnerEmplacementType) then
        if pEmplacement:IsLockedBehindIntrinscSkill(pAvatar) then
            return "/Lotus/Language/Intrinsics/RailjackIntrinsicGunner_5_Required"
        end
    end
    
    return "/Lotus/Language/CrewShip/Emplacement_Forward"
end

function GetAWCannonText(pEmplacement, pAvatar)
    if pAvatar and pEmplacement then
        if not pAvatar:IsIntrinsicSkillAbilityAdded(PLAYER_SKILL_LIB.sSkillAWCannon) then
            return "/Lotus/Language/Intrinsics/RailjackIntrinsicGunner_3_Required"
        end
    end
    return "/Lotus/Language/Railjack/ArchwingCannon"
end

function EngineeringIndicator(deco)
    Engine.EnableZoneCull(deco) -- only update if player can see
    local matParam1 = Symbol("Scalar1")
    local matParam2 = Symbol("Scalar2")

    while IsNull(gGameRules) do
        Sleep(0.1)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    while IsNull(crewShipMgr) and not IsNull(gGameRules) do
        crewShipMgr = gGameRules:GetCrewShipManager()
        Sleep(0)
    end
    
    if IsNull(crewShipMgr) then
        return
    end
    
    local crewShip = crewShipMgr:GetPlayerShip()
    while IsNull(crewShip) and not IsNull(crewShipMgr) do
        crewShip = crewShipMgr:GetPlayerShip()
        Sleep(0)
    end
    
    if IsNull(crewShip) then
        return
    end
    
    local crewShipAv = crewShip:GetAvatarOwner()
    while IsNull(crewShipAv) and not IsNull(crewShip) do
        crewShipAv = crewShip:GetAvatarOwner()
        Sleep(0)
    end
    
    if IsNull(crewShipAv) then
        return
    end

    local prevAtten
    local maxCooldown = crewShipAv:GetAmmoConsoleCooldownMax(engineeringStation)
    if maxCooldown > 0 then
        while not IsNull(crewShipAv) and not IsNull(deco) do
            -- engineeringStation data driven
            local cooldown = crewShipAv:GetAmmoConsoleCooldown(engineeringStation)
            local enableAtten = 0
            if cooldown <= 0 then
                enableAtten = 10
            end
            if (prevAtten == nil) or (prevAtten ~= enableAtten) then
                deco:SetMaterialParam(matParam1, enableAtten, 0, 0, 0)
                deco:SetMaterialParam(matParam2, enableAtten, 0, 0, 0)
                prevAtten = enableAtten
            end
            Sleep(0)
        end
    end
end

function RailjackGotoCheat(tag)
    local crewShipMgr = gGameRules:GetCrewShipManager()
    local playerShip = crewShipMgr:GetShips(true)[1]
    local playerShipAvatar = playerShip:GetAvatarOwner()

    local entity = gRegion:FindNearestTagged(Symbol(tag), playerShipAvatar:GetPosition())

    if not IsNull(entity) then
        playerShipAvatar:Teleport(entity:GetPosition(), ZERO_ROTATION)
    else
        Broadcast("Teleport failed, could not find tagged entity")
    end
end
