WarningRefreshTime = 30
RailjackTurnWarnRefreshTime = 10

worldRadius=4500 -- hard maximum xz position
worldHeightMin=-2000 -- hard minimum y position
worldHeightMax=4500 -- hard maximum y position
worldRadiusWarning=500 -- distance from max radius when we start warning
worldHeightWarning=500 -- distance from min or max height when we start warning

local lastAvatarWarning
local lastTurnWarning

-- TODO : ALSO ADD CHECKS IF TRANSMISSION IS ALREADY PLAYING

local function WarnForPlayerAvatar(targetAvatar)
    if IsNull(lastAvatarWarning) or (lastAvatarWarning + RailjackTurnWarnRefreshTime < RealTime()) then
        lastAvatarWarning = RealTime()
        print("AVATAR IS GOING OUT OF BOUND")
    end
end

local function WarnForRailjackAvatar(targetAvatar)
    if IsNull(lastAvatarWarning) or (lastAvatarWarning + WarningRefreshTime < RealTime()) then
        lastAvatarWarning = RealTime()
        print("RAILJACK AVATAR IS GOING OUT OF BOUND.. SLOWING DOWN")
    end    
end

local function WarnForRailjackAvatarTurn(targetAvatar)
    if IsNull(lastTurnWarning) or (lastTurnWarning + RailjackTurnWarnRefreshTime < RealTime()) then
        lastTurnWarning = RealTime()
        print("RAILJACK IS AT WORLD BOUND.. AUTO Turning")
    end    
end

local function AddAiHints(spline, objective)
    local npcMgr = gRegion:GetNpcMgr()
    if IsNull(npcMgr) then
        return
    end
    
    local aiDir = npcMgr:GetAiDirector()
    
    if not IsNull(spline) then
        aiDir:AddLevelSplineToTacAreaMap(spline)
    end

    if not IsNull(objective) then
        aiDir:SetObjective(objective)
    end

    local playerRailjack = gGameRules:GetCrewShipManager():GetPlayerShip()
    if not IsNull(playerRailjack) then
        local pilotAction = playerRailjack:GetShipEmplacement(0)  --0 is pilot atm
        if not IsNull(pilotAction) then
            aiDir:SetObjective(pilotAction)
        end
    end
end

function InitializeWorldDimensions()
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipMgr()
    end
    
    crewShipMgr:InitializeWorldDimensions(worldRadius, worldHeightMin, worldHeightMax, worldRadiusWarning, worldHeightWarning)
    
    local splineTag = Symbol("MainPath")
    local splines = gRegion:FindAll(Type("/EE/Types/Engine/SplineEntity"))
    local spline = nil
    for i,v in ipairs(splines) do
        if v:GetTag() == splineTag then
            spline = v
            break
        end
    end
    
    local objective = gRegion:FindFirstTagged(Symbol("Start"))
    AddAiHints(spline, objective)

end

function CheckOutOfWorldAvatars2(crewShipMgr)
    while true do
        if not IsNull(gRegion) then
            local warned = false
            local localAvatar = gRegion:GetLocalPlayerAvatar()
            
            if not IsNull(localAvatar) then
                local inventoryController = localAvatar:InventoryControl()
                local boardedShip = inventoryController:GetOnBoardShip()
                if IsNull(boardedShip) then 
                    local outOfWorldRatio = crewShipMgr:GetAvatarOutOfBoundRatio(localAvatar) 
                    if outOfWorldRatio > 0.0 then
                        WarnForPlayerAvatar(localAvatar)
                    end
                elseif not IsNull(boardedShip) and boardedShip:GetPilot() == localAvatar then
                    local crewShipAv = boardedShip:GetAvatarOwner()
                    local outOfWorldSpeedMultiplier = crewShipAv:MotionControl():GetOutOfWorldSpeedMultiplier()
                    if outOfWorldSpeedMultiplier < 1.0 then
                        if outOfWorldSpeedMultiplier <=  crewShipAv:MotionControl():GetOutOfWorldMultiplierForAutoTurn() then
                            WarnForRailjackAvatarTurn(crewShipAv)
                        elseif outOfWorldSpeedMultiplier <= 0.2 then
                            WarnForRailjackAvatar(crewShipAv)
                        end
                    end
                end                
            end
        end
        Sleep(0)
    end
end