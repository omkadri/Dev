capitalShipAiSpec = Resource()
enemyTargetTier = 90

transmissionSet = Resource()

rjObjectiveConsoleWRes = WeakResource()
enterShipMarkerWRes = WeakResource()
crewshipObjectiveMarkerWRes = WeakResource()
crewshipPatrolTemplateWRes = WeakResource()

keyholderKeyPickupType = Type()

crewShipType = Type()
enemyFaction = Symbol("Grineer")
enemyTeam = Symbol("RandomTeam")
RJConsoleDecoTag = Symbol("RJConsoleDeco")

numOfKeycodesToAcquire = 2

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local PANIC = require "Lotus.Scripts.Libs.PanicLib"
local QUERY = require "Lotus.Scripts.Libs.Query"

local NV_RJ_NUM_KEYCODES_ACQUIRED = Symbol("RJ_NUM_KEYCODES_ACQUIRED")
local NV_RJ_ACQUIRE_KEYCODES_STATE = Symbol("RJ_ACQUIRE_KEYCODES_STATE")

local NOT_STARTED = 1
local STARTED = 2
local CONSOLE_LOCATED = 3
local COMPLETE = 99
local mModeState = INVALID
local SetModeState

local UPDATE_INTERVAL = 0.1 -- How frequently we will tick 

local mHint = nil
local mAiSpec = nil
local mAiDir = nil
local mUsedCrewShips = { }
local mKeyholderPickUps = { }

local mTemplate = nil
local mTransmissionSet = nil

local mKeycodeEnemyTargetAvatars = { }

local baseEnemyTargetType = Type("/Lotus/Types/Enemies/Grineer/RailJack/Avatars/GrnKeycodeHolderBaseAvatar")

function NPCAlertStart(npc)
    PANIC.SetPanicLevel(PANIC.ALERT)
end

function NPCAlertEnd(npc)
    PANIC.SetPanicLevel(PANIC.UNALERT) 
end

function EnemyShipReady(enemyShip)
    if not IsNull(enemyShip) then
        table.insert(mUsedCrewShips, enemyShip)
    else
        print("AcquireKeycodesEncounter.lua - Warning: Attempted to make a crewship but failed.")
    end
end

function OnPickedUp(item)
    local defaultKeyCodeType = Type("/Lotus/Types/PickUps/KeyholderKeyPickup")
    if not IsNull(item) then
        if item:IsA(keyholderKeyPickupType) then
            local numOfCodes = gGameRules:GetNetPersistentVar(NV_RJ_NUM_KEYCODES_ACQUIRED, 0)
            numOfCodes = numOfCodes + 1
            gGameRules:SetNetPersistentVar(NV_RJ_NUM_KEYCODES_ACQUIRED, numOfCodes)

            local missionState = gGameRules:GetNetPersistentVar(NV_RJ_ACQUIRE_KEYCODES_STATE, NOT_STARTED)
            if missionState == STARTED and numOfCodes >= numOfKeycodesToAcquire then
                gGameRules:SetNetPersistentVar(NV_RJ_ACQUIRE_KEYCODES_STATE, CONSOLE_LOCATED)
            end
        elseif item:IsA(defaultKeyCodeType) then
            local numOfCodes = gGameRules:GetNetPersistentVar(NV_RJ_NUM_KEYCODES_ACQUIRED, 0)
            numOfCodes = numOfCodes + 1
            gGameRules:SetNetPersistentVar(NV_RJ_NUM_KEYCODES_ACQUIRED, numOfCodes)

            local missionState = gGameRules:GetNetPersistentVar(NV_RJ_ACQUIRE_KEYCODES_STATE, NOT_STARTED)
            if missionState == STARTED and numOfCodes >= numOfKeycodesToAcquire then
                gGameRules:SetNetPersistentVar(NV_RJ_ACQUIRE_KEYCODES_STATE, CONSOLE_LOCATED)
            end
        end
    end
    
end

local function _KeycodeHolderKilled(avatar)
    if not IsNull(avatar) then
        local spawnPos = avatar:GetPosition()
        local pickup = gRegion:CreateEntity(keyholderKeyPickupType, spawnPos, ZERO_ROTATION)
        local keyMarker = pickup:GetAttachment(gBaseMarkerInfoType)

        if not IsNull(keyMarker) then
            keyMarker:Enable()
        end

        table.insert(mKeyholderPickUps, pickup)
        ObjectPortHandler(pickup, "OnPickedUp") 
    end
    -- local numOfCodes = gGameRules:GetNetPersistentVar(NV_RJ_NUM_KEYCODES_ACQUIRED, 0)
    -- numOfCodes = numOfCodes + 1
    -- gGameRules:SetNetPersistentVar(NV_RJ_NUM_KEYCODES_ACQUIRED, numOfCodes)

    -- local missionState = gGameRules:GetNetPersistentVar(NV_RJ_ACQUIRE_KEYCODES_STATE, NOT_STARTED)
    -- if missionState == STARTED and numOfCodes >= numOfKeycodesToAcquire then
    --     gGameRules:SetNetPersistentVar(NV_RJ_ACQUIRE_KEYCODES_STATE, CONSOLE_LOCATED)
    -- end
end

function OnKilled(avatar)
    if not IsNull(avatar) then 
        if avatar:IsA(gBaseAvatarType) then
            for i=1,#mKeycodeEnemyTargetAvatars do
                if mKeycodeEnemyTargetAvatars[i] == avatar then
                   _KeycodeHolderKilled(avatar)
                   break
                end
            end
            
        elseif avatar:IsA(gCrewShipAvatarType) then
            local crewShip = avatar:InventoryControl():GetActivePowerSuit()

            local pickUps = RJ_UTIL.FindTypeOnShip(keyholderKeyPickupType, crewShip)
            local targets = RJ_UTIL.FindTypeOnShip(baseEnemyTargetType, crewShip)

            for i=1, #targets do
                local target = targets[i]
                for j=1,#mKeycodeEnemyTargetAvatars do
                    if not IsNull(target) and target == mKeycodeEnemyTargetAvatars[j] then
                        table.remove(mKeycodeEnemyTargetAvatars, j)
                    end
                end
            end

            if #pickUps > 0 then
                for j=1, #pickUps do
                    local pickUp = pickUps[j]
                    pickUp:Teleport(avatar:GetPosition(), ZERO_ROTATION)
                end
            else
                for i=1,#mUsedCrewShips do
                    if mUsedCrewShips[i] == crewShip then
                        _KeycodeHolderKilled(avatar)
                        break
                    end
                end
            end 
        end
    end
end

function OnActivated(trigger)
    local missionState = gGameRules:GetNetPersistentVar(NV_RJ_ACQUIRE_KEYCODES_STATE, NOT_STARTED)
    if missionState == CONSOLE_LOCATED then
        gGameRules:SetNetPersistentVar(NV_RJ_ACQUIRE_KEYCODES_STATE, COMPLETE)

        if not IsNull(trigger) then
            local consoleDeco = trigger:GetAttachParent()
            local consoleMarker = consoleDeco:GetAttachment(gBaseMarkerInfoType)
            local consoleAction = consoleDeco:GetAttachment(gContextActionType)

            if not IsNull(consoleMarker) then
                consoleMarker:Disable()
            end

            if not IsNull(consoleAction) then
                consoleAction:Disable()
            end
        end
    end
end

local function ShouldShutDown()
    local crewShipMgr = gGameRules:GetCrewShipManager()
    local ship = crewShipMgr:GetPlayerShip()
    local crewShipAvatar = ship:GetAvatarOwner()
    local hyperDriveState = crewShipAvatar:GetHyperDriveState()

    if mModeState == COMPLETE or (hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_ACTIVE) then
        return true
    end

    return false
end

local function ActivateConsole()
    local crewshipMgr = gGameRules:GetCrewShipManager()
    local ships = crewshipMgr:GetShips(false)
    
    while IsNull(ships) do
        ships = crewshipMgr:GetShips(false)
        Sleep(0)
    end

    while #ships > 0 do
        local randomIndex = RandomInt(1, #ships)
        local ship = ships[randomIndex]

        local consoleDeco = RJ_UTIL.FindFirstTaggedOnShip(RJConsoleDecoTag, ship)

        if not IsNull(consoleDeco) then
            local consoleMarker = consoleDeco:GetAttachment(gBaseMarkerInfoType)
            local consoleAction = consoleDeco:GetAttachment(gContextActionType)

            consoleDeco:SetVisibility(true, true)

            if not IsNull(consoleMarker) then
                consoleMarker:Enable()
            end

            if not IsNull(consoleAction) then
                ObjectPortHandler(consoleAction, "OnActivated")
                consoleAction:Enable()
                RJ_UTIL.SetCrewShipEnterMarker(true, ship)
                RJ_UTIL.SetAllCrewShipExitMarkers(true, { ship })
                break
            end
        end
        
        table.remove(ships, randomIndex)
        
        Sleep(0)
    end
end

local function SpawnKeycodeTargets()
    local playerAvatars = gRegion:GetHumanPlayerAvatars()
    local crewShipMgr = gGameRules:GetCrewShipManager()
    local crewShips = crewShipMgr:GetShips(false)
    
    while IsNull(crewShips) do
        crewShips = crewShipMgr:GetShips(false)
        Sleep(0)
    end

    local ships = { }
    for i=1, #crewShips do
        if not IsNull(crewShips[i]) then
            table.insert(ships, crewShips[i])
        end
    end

    for i=1,numOfKeycodesToAcquire do
        local nextShip = nil
        while IsNull(nextShip) do
            local ship = nil
            local randomIndex = RandomInt(1, #ships + 1)

            if randomIndex > #ships then
                local prevCrewShipsSize = #mUsedCrewShips
                local query = gRegion:GetNpcMgr():GetAiDirector():EmptyTacQuery()
                local playerShip = crewShipMgr:GetShips(true)
                local playerShipAvatar = playerShip[1]:GetAvatarOwner()
                query = RJ_UTIL.GetSpawnPositionQuery(query, playerShipAvatar, Range(1500, 3000), 30)
                local points = query:GetPoints() --QUERY.GetPosition(BuildAnimalStartQuery(playerShipPos, Range(0, 100), 30))

                if #points > 0 then
                    local randomPosIndex = RandomInt(1, #points)
                    local destroyerPos = points[randomPosIndex]
                    crewShipMgr:CreateCrewShipFromType(crewShipType, nil, false, false, "EnemyShipReady")
    
                    while #mUsedCrewShips == prevCrewShipsSize do
                        Sleep(0)
                    end

                    local enemyShip = mUsedCrewShips[#mUsedCrewShips]
                    if enemyShip == false then
                        -- Error
                    else
                        local enemyCrewAvatar = enemyShip:GetAvatarOwner()

                        while enemyCrewAvatar:GetAgent() == nil do
                            Sleep(0)
                        end

                        local agent = enemyCrewAvatar:GetAgent()
                        agent:SetTeam(enemyTeam)
                        enemyCrewAvatar:Teleport(destroyerPos, Rotation())
                        nextShip = enemyShip
                    end
                end
            else
                ship = ships[randomIndex]

                local playerFound = false
                if not IsNull(ship) then
                    for i=1, #playerAvatars do
                        local playerAvatar = playerAvatars[i]

                        if not IsNull(playerAvatar) and ship:IsEntityOnBoardShip(playerAvatar) then
                            playerFound = true
                            break
                        end
                    end

                    if not playerFound then
                        nextShip = ship
                        table.insert(mUsedCrewShips, nextShip)
                        break
                    end
                end   
            end 

            Sleep(0)
        end

        if not IsNull(nextShip) then
            local shipAvatar = nextShip:GetAvatarOwner()
            local spawnPoints = RJ_UTIL.FindTypeOnShip(gNpcSpawnPointType, nextShip)
            local randIndex = RandomInt(1, #spawnPoints)
            local spawnPoint = spawnPoints[randIndex]

            if not IsNull(spawnPoint) and not IsNull(shipAvatar) then
                local mission = gGameRules:GetMission()
                local level = RandomInt(mission.minEnemyLevel, mission.maxEnemyLevel)
                local enemyTargetType = mAiDir:GetRandomEnemyAgentType(enemyFaction, level, true, false, enemyTargetTier, true)
                
                if IsNull(enemyTargetType) then
                    Broadcast("Enemy target type is Nil -- AI Spec Issue? Tier: " .. enemyTargetTier)
                    enemyTargetType = baseEnemyTargetType
                end
                
                local enemyTargetAgent = mAiDir:CreateAgent(enemyTargetType, spawnPoint, enemyTeam, level)

                local enemyTargetAvatar = enemyTargetAgent:GetAvatar()
                while IsNull(enemyTargetAvatar) do
                    enemyTargetAvatar = enemyTargetAgent:GetAvatar()
                    Sleep(0)
                end

                table.insert(mKeycodeEnemyTargetAvatars, enemyTargetAvatar)
                ObjectPortHandler(enemyTargetAvatar, "OnKilled")
                ObjectPortHandler(shipAvatar, "OnKilled")
                mHint:RegisterAgent(enemyTargetAgent)
                
                local targetMarkers = enemyTargetAvatar:GetAllAttachments(crewshipObjectiveMarkerWRes)
                for j=1, #targetMarkers  do
                    local marker = targetMarkers[j] 
                    if not IsNull(marker) and not marker:IsEnabled() then
                        marker:Enable()
                    end
                end

                RJ_UTIL.SetCrewShipEnterMarker(true, nextShip)
            end
        end
    end

    RJ_UTIL.SetAllCrewShipExitMarkers(true, mUsedCrewShips)    
end

local function ShutDownAcquireKeycodesObjective(hint)
    --Destroy crewships
    --set net variables back to 0.
    mAiDir:SetEnableAutoSpawns(false)
    gGameRules:SetNetPersistentVar(NV_RJ_ACQUIRE_KEYCODES_STATE, NOT_STARTED)
    gGameRules:SetNetPersistentVar(NV_RJ_NUM_KEYCODES_ACQUIRED, 0)
end

function ConsoleLocated()
    --gGameRules:GiveTransmissionAsyncToAllPlayers(crewShipIntroTransmission)
end

local function PlayAcquireKeycodesIntro()
    --gGameRules:GiveTransmissionAsyncToAllPlayers(crewShipIntroTransmission)
end

local function OnModeStateChanged()
    if mModeState == STARTED then
        SpawnKeycodeTargets()
        PlayAcquireKeycodesIntro() --Patrol ship transmissions
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/KillTheKeyHolders", 1)
        -- mAiDir:SetNpcHardCap(60) -- TC hack to get enemies to spawn inside the destroyers and cap ship while keeping fighters alive in space.
    elseif mModeState == CONSOLE_LOCATED then
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/ExtractTheKeycodes", 1)
        ActivateConsole()
    elseif mModeState == COMPLETE then
        RJ_UTIL.SetAllCrewShipExitMarkers(false, nil)

        for i=1, #mUsedCrewShips do
            local ship = mUsedCrewShips[i]

            if not IsNull(ship) then
                RJ_UTIL.SetCrewShipEnterMarker(false, ship)
            end
        end

        mHint:SetEncounterStatus(Npc.ES_SUCCEEDED)
    end
end

local function Initialize(hint)
    mHint = hint
    mTemplate = mHint:GetCurrentEncounterTemplate()
    mTransmissionSet = mTemplate:GetTransmissionSet()

    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    if not IsNull(gGameRules) then
        --mAiSpec = capitalShipAiSpec
        local mission = gGameRules:GetMission()
        mAiSpec = mission.enemySpec
        if IsNull(mAiSpec) then
            mAiSpec = capitalShipAiSpec
            mission.enemySpec = capitalShipAiSpec
            gGameRules:SetMission(mission)
            mAiDir:AssignMissionAISpec(mAiSpec)
        end
    end

    local levelInfo = gRegion:GetLevelInfo()
    ObjectPortHandler(levelInfo, "NPCAlertStart")
    ObjectPortHandler(levelInfo, "NPCAlertEnd")
    --ObjectPortHandler(panelForwarder, "OnActivated")

    SetModeState(gGameRules:GetNetPersistentVar(NV_RJ_ACQUIRE_KEYCODES_STATE, NOT_STARTED))

    if mModeState == NOT_STARTED then
        SetModeState(STARTED)
    elseif mModeState >= STARTED then
        
        --there must be an enc hint that we previously monitored, find that one.
    end
end

local function Update(deltaTime)
    local modeState = gGameRules:GetNetPersistentVar(NV_RJ_ACQUIRE_KEYCODES_STATE, NOT_STARTED)
    if modeState ~= mModeState then
        mModeState = modeState
        mHint:SetEncounterDynamicState(modeState)
        OnModeStateChanged(modeState)
    end

    if mModeState == STARTED then
        local regAgents = mHint:GetRegisteredAgents()

        for i=1, #regAgents do
            local regAgent = regAgents[i]
            local regAvatar = regAgent:GetAvatar()

            if IsNull(regAvatar) or regAvatar:IsKilled() then
                table.remove(regAgents, i)
                _KeycodeHolderKilled()
            end
        end

        local numOfCodes = gGameRules:GetNetPersistentVar(NV_RJ_NUM_KEYCODES_ACQUIRED, 0)
        if numOfCodes >= numOfKeycodesToAcquire then
            SetModeState(CONSOLE_LOCATED)
        end
    elseif mModeState == CONSOLE_LOCATED then

    elseif mModeState == COMPLETE then
        --increment railjackmanagernetvar to move onto the next mission.
    end
end

SetModeState = function(newState)
    if mModeState ~= newState then
        mModeState = newState
        mHint:SetEncounterDynamicState(newState)
        gGameRules:SetNetPersistentVar(NV_RJ_ACQUIRE_KEYCODES_STATE, newState)
        OnModeStateChanged()
    else
        print("AcquiredKeycodesEncounter.lua::SetModeState - trying to set mode to state we're already in")
    end
end

function CanActivateAcquireKeycodesEncounter()
    -- check if the proc system placed the correct rooms/objects in thte node. If not return false

    local playerAvatars = gRegion:GetHumanPlayerAvatars()
    local crewshipMgr = gGameRules:GetCrewShipManager()
    local ships = crewshipMgr:GetShips(false)

    local numOfAvailShips = 0

    for i=1, #ships do
        local ship = ships[i]

        local playerFound = false
        if not IsNull(ship) then
            for i=1, #playerAvatars do
                local playerAvatar = playerAvatars[i]

                if not IsNull(playerAvatar) and ship:IsEntityOnBoardShip(playerAvatar) then
                    playerFound = true
                    break
                end
            end

            if not playerFound then
                local consoleDeco = RJ_UTIL.FindFirstTaggedOnShip(RJConsoleDecoTag, ship)

                if not IsNull(consoleDeco) then
                    numOfAvailShips = numOfAvailShips + 1

                    if numOfAvailShips >= numOfKeycodesToAcquire then
                        break
                    end
                end
            end
        end
    end

    if numOfAvailShips >= numOfKeycodesToAcquire then
        return 1
    end

    return 0
    -- local missilePlatformHints = gRegion:FindAll(missilePlatformHintWRes)

    -- for i=1, #missilePlatformHints do
    --     local missileHint = missilePlatformHints[i]
    --     local missileHintState = missileHint:GetEncounterDynamicState()
    --     if missileHintState >= PLATFORM_SPAWNED and missileHintState < PLATFORM_DISABLED then
    --         return 1
    --     end
    -- end

    -- print("DisableMisslePlatform.lua::CanActivate - couldn't find any missile platforms in the level")
    -- return 0
end

function AcquireKeycodes(hint)

    Broadcast("AcquiredKeycodesEncounter.lua -- Acquired Keycodes SubObjective Started")
    Initialize(hint)

    local sleepTime = UPDATE_INTERVAL

    while not ShouldShutDown() do
        Update(sleepTime)
        Sleep(sleepTime)
    end

    ShutDownAcquireKeycodesObjective(hint)
end