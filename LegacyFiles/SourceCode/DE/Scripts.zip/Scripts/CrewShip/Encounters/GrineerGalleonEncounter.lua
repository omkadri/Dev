--ARGS
crewShipType = Type()
markerType = Type()
vipAgentTypes = {Type()}
killTargetLoc = Symbol()
extractLoc = Symbol()
spottedTransmissionDistance = 50

--LIBS
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
--local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local RAILOBJ = require "Lotus.Scripts.Libs.RailjackObjectiveUI"

--RESOURCES
local pointOfInterestAgentType = WeakResource("/Lotus/Types/Game/CrewShip/PointOfInterestAgent")

--SYMBOLS
local sHide = Symbol("Hide")
local sMissileCoreTag = Symbol("RJMissilePlatformCore")

--CACHED VARS
local mGameRules = nil
local mAiDir = nil
local mHint = nil
local mHintPos = nil
local mHintActivationRadius = 0
local mDeactivateRadius = 0
local mParentHint = nil
local mTransmissionSet = nil
local mTimerMgr = nil
local mModeMgr = nil
local mSpawnMgr = nil
local mPlayers = nil
local mVipAgent = nil
local mVipZone = nil

--STATES
local INVALID = 0
local STARTED = 1
local APPROACHED = 2
local BOARDED = 3
local SPOTTED = 4
local KILLED = 5
local DONE = 6

--SETTINGS
local MIN_ENEMY_COUNT = 10

--VARS
local mCrewShip = nil
local mAvatar = nil
local mEnterAction = nil
local mDisableMarker = nil
local mDisableAction = nil
--local mHudTracker = nil
 

local function CrewShipInitialize()
    local setupScript = gRegion:FindNearestTagged(Symbol("PoiSetupScript"), mHintPos)
    if not IsNull(setupScript) then
        setupScript:FirePort("Execute")
    else
        print("POI - Could not find setup script")
    end
    
    mAvatar = mCrewShip:GetAvatarOwner()

    local objectiveWaypoint = RAIL.FindFirstTaggedOnShip(Symbol("Objective"), mCrewShip)
    mAiDir:SetObjective(objectiveWaypoint)
    mEnterAction = gRegion:FindNearestTagged(Symbol("EnterShipAction"), mHintPos)
    mDisableMarker = RAIL.FindFirstTaggedOnShip(Symbol("HangarDisableObjective"), mCrewShip)
    mDisableAction = RAIL.FindFirstTaggedOnShip(Symbol("HangarDisableAction"), mCrewShip)
    mSpawnMgr = RAIL.CreateSpawnMgr(mHint, mCrewShip)
end

function ShipReady(ship)
    mCrewShip = ship
    mAvatar = mCrewShip:GetAvatarOwner()
    mHint:RegisterAgent(mAvatar:GetAgent())
end

-- OnModeStateChanged - this is called immediately when state changes - use this function for setting up the state (UI changes, creating objects, etc)
-- This func is called after host migration, so you can recover from the state you migrated during
local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    if curState == STARTED then
        local avatar = mCrewShip:GetAvatarOwner()
        avatar:SetPosition(mHintPos) 
        mEnterAction:Enable()
        RAIL.SetCrewShipEnterMarker(true, mCrewShip)
        RAIL.SetCrewShipExitMarker(false, mCrewShip)
    elseif curState == BOARDED then
        mSpawnMgr:ShipBoarded()
        local aiDir = gRegion:GetNpcMgr():GetAiDirector()
        local spawnPoint = RAIL.FindFirstTaggedOnShip(Symbol("CaptainBossSpawn"), mCrewShip)
        mVipZone = spawnPoint:GetZone()
        mVipAgent = aiDir:CreateAgentAtPosition(vipAgentTypes[RandomInt(1,#vipAgentTypes)], spawnPoint:GetPosition(), spawnPoint:GetRotation(), Symbol("GalleonBridge"))
        if not IsNull(mVipAgent) then
            mHint:RegisterAgent(mVipAgent)
            local avatar = mVipAgent:GetAvatar()
            avatar:SetIsVIP()
            avatar:Attach(markerType, EMPTY_SYMBOL, Vector(0, 1, 0))
            aiDir:SetObjective(avatar)
            local avatarLoc = tostring(avatar:GetLocTag())
            if not IsNull(avatarLoc) then
                RAILOBJ.SetSubObjective(mHint, "GalleonVip", avatarLoc, 2)
            else
                RAILOBJ.SetSubObjective(mHint, "GalleonVip", "/Lotus/Language/RailjackMissions/GalleonObjective", 2)
            end
        end
    elseif curState == SPOTTED then
        DIALOG.PlayGlobalTransmission(mHint:GetCurrentEncounterTemplate():GetTransmissionSet(), Symbol("TargetSpotted"))
    elseif curState == KILLED then
        mVipAgent = nil
        RAIL.SetCrewShipEnterMarker(false, mCrewShip)
        RAIL.SetCrewShipExitMarker(true, mCrewShip)
        --OBJTXT.SetObjectiveTextUI(mHudTracker, extractLoc:c_str(), OBJTXT.EXTRACT_ICON, nil, OBJTXT.GetPriorityOffset(), true, false)
        DIALOG.PlayGlobalTransmission(mHint:GetCurrentEncounterTemplate():GetTransmissionSet(), Symbol("ObjectiveComplete"))
    elseif curState == DONE then
        mHint:SetEncounterStatus(Npc.ES_SUCCEEDED)
    end
end

-- Initialize - first thing that runs when a mission encounter starts - do your initial setup here. This is called again on migration.
-- Because gPromotedToHost is unreliable here, you will need to search for mission entities first, and create if not found (see mMissionObject)
local function Initialize(hint)
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    mGameRules = gGameRules
    mHint = hint
    mParentHint = hint:GetRootParentEncounterHint()
    mHintPos = hint:GetPosition()
    mHintActivationRadius = hint:GetActivationRadius()
    mDeactivateRadius = hint:GetDeactivationRadius()
    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()
    gRegion:AddPlayersChangedBasicCallback("OnPlayersChanged")
    mPlayers = gRegion:GetHumanPlayers()
    
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})
    mTimerMgr = TIMER.CreateTimerMgr()
    
    local instanceRefs = mHint:GetInstanceReferences()
    for i, instance in ipairs(instanceRefs) do
        if instance:GetTag() == sHide then
            instance:SetVisibility(false, true)
        end
    end
    
    local netState = mHint:GetEncounterDynamicState()
    if netState > INVALID then
        --recover crewship/avatar after migration
        while IsNull(mCrewShip) do
            local registeredAgents = mHint:GetRegisteredAgents()
            for i, agent in ipairs(registeredAgents) do
                if agent:IsA(pointOfInterestAgentType) then
                    mAvatar = agent:GetAvatar()
                    mCrewShip = mAvatar:InventoryControl():GetActivePowerSuit()
                    break
                end
            end
            if IsNull(mCrewShip) then
                Sleep(0)
            else
                for i, agent in ipairs(registeredAgents) do
                    for k=1,#vipAgentTypes do
                        if agent:IsA(vipAgentTypes[k]) then
                            mVipAgent = agent
                            break
                        end
                    end
                end
            end
        end
    else
        local crewShipMgr = gGameRules:GetCrewShipManager()
        crewShipMgr:CreateCrewShipFromType(crewShipType, nil, false, true, "ShipReady")
    end
    
    while IsNull(mCrewShip) do
        Sleep(0)
    end
    
    CrewShipInitialize()
    
    if netState >= BOARDED then
        local avatarLoc = tostring(mVipAgent:GetAvatar():GetLocTag())
        if not IsNull(avatarLoc) then
            RAILOBJ.SetSubObjective(mHint, "GalleonVip", avatarLoc, 2)
        else
            RAILOBJ.SetSubObjective(mHint, "GalleonVip", "/Lotus/Language/RailjackMissions/GalleonObjective", 2)
        end
    end
    
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))
    hint:SetEncounterStatus(Npc.ES_ACTIVE)
end

local function Shutdown(hint)
    local instanceRefs = mHint:GetInstanceReferences()
    for instance in ipairs(instanceRefs) do
        if instance:GetTag() == sHide then
            instance:SetVisibility(true, true)
            mCrewShip:DestroyShip()
        end
    end
end

--Main function - Contains main update loop, monitor mode state here
function Start(hint)
    Initialize(hint)
    
    local delta = 0
    local curState = INVALID
    while true do
        if gGameRules:MissionCompleted() or gGameRules:MissionFailed() or hint:GetEncounterStatus() >= Npc.ES_COMPLETE then
            break
        end
        
        delta = DeltaTime()
        curState = mModeMgr:GetModeState()
        
        if curState == STARTED then
            if RAIL.ArePlayersNearEntity(mEnterAction, RAIL.POI_APPROACH_DISTANCE) then
                DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("ObjectiveProximity"))
                mModeMgr:SetModeState(APPROACHED)
            end
        
        elseif curState == APPROACHED then
            local onShip = RAIL.GetPlayerAvatarsOnShip(mCrewShip)   --not great because its gets an array and counts it..
            if #onShip > 0 then
                mModeMgr:SetModeState(BOARDED)
            end
        
        elseif curState > APPROACHED then
            mSpawnMgr:Update(delta)

            if curState == BOARDED then
                local players = gRegion:GetHumanPlayerAvatars()
                for i=1,#players do
                    if mAiDir:GetDistanceToObjective(players[i]) < spottedTransmissionDistance then
                        mModeMgr:SetModeState(SPOTTED)
                        break
                    end
                end
            end

            if curState == KILLED then
                local onShip = RAIL.GetPlayerAvatarsOnShip(mCrewShip)
                if #onShip == 0 then
                    mModeMgr:SetModeState(DONE)
                    break
                end
            elseif curState < KILLED and (IsNull(mVipAgent) or IsNull(mVipAgent:GetAvatar()) or mVipAgent:GetAvatar():IsKilled()) then
                mModeMgr:SetModeState(KILLED)
            --elseif not mHudTracker and _T.LocationTrackerAddedCallbacks then
                --mHudTracker = _T.AddHudTracker("GalleonVip", LOTUS_UTIL.HT_LABEL, 0.5, OBJTXT.GetPriorityOffset(), true)
                --OBJTXT.SetObjectiveTextUI(mHudTracker, killTargetLoc:c_str(), OBJTXT.ATTACK_ICON, nil, OBJTXT.GetPriorityOffset(), true, false)
                --mHudTracker.SetLocation(IsNull(mVipAgent) and RAIL.FindFirstTaggedOnShip(Symbol("CaptainBossSpawn"), mCrewShip):GetZone():GetRegionIndex() or mVipAgent:GetAvatar():GetZone():GetRegionIndex())
            end
        elseif not mSpawnMgr.mCleanedUp and curState == DONE and mAiDir:CountPlayersInRegion(mCrewShip:GetInteriorLayer()) == 0 then
            mSpawnMgr:CleanUp()
        end

        mTimerMgr:Update(delta)
        
        Sleep(0)
    end
    
    Shutdown()
    mModeMgr:ShutDown()
    --[[if mHudTracker then
        _T.RemoveHudTracker(mHudTracker)
    end]]
    RAILOBJ.RemoveObjective(mHint, "GalleonVip")
    RAILOBJ.RemoveObjective(mHint)
    RAIL.SetCrewShipExitMarker(false, mCrewShip)
    if not IsNull(mEnterAction) then
        mEnterAction:Disable()
    end
end

--CALLBACKS
function OnPlayersChanged()
    mPlayers = gRegion:GetHumanPlayers()
end
