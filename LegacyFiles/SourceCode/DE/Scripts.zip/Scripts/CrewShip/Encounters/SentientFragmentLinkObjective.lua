--ARGS
attackMarkerType = Type()
attackAreaMarkerType = Type()
aerolystAgentType = Type()

beaconGlow = Instance()
beaconDeco = Instance()
beaconOpenAnim = Resource()
beaconOpenIdleAnim = Resource()
beaconEffect = Resource()

activeRingType = Type()
objectiveAreaMarkerType = Type()
hideFx = Resource()

recallFxType = Type()
recallFxTypeAW = Type()
recallFxFailType = Type()
teleportSound = Resource()
teleportWarningSound = Resource()
activateTeleportSound = Resource()

objectiveMarkerType = Type()

fragmentWarpWarningFx = Type()
fragmentWarpInFx = Type()
beaconKillcodeUploadedFx = Type()
satelliteKillcodeConsumedFx = Type()

--LIBS
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local MODE = require "Lotus.Scripts.Libs.CommonGamemodeFunctions"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local RAILOBJ = require "Lotus.Scripts.Libs.RailjackObjectiveUI"
local TABLE = require "Lotus.Scripts.Libs.TableLib"
local ABILITIES = require "Lotus.Scripts.Libs.AbilitiesLib"

--RESOURCES
local pointOfInterestAgentType = WeakResource("/Lotus/Types/Game/CrewShip/PointOfInterestAgent")
local completionReward = Resource("/Lotus/Types/Items/MiscItems/SentientFragmentLootItem")

--LOC
local objectiveLoc = "[HC] CAPTURE THE TRANSMITTER"
local xOfYLoc = "/Lotus/Language/Menu/ProgressXOfY"

--SYMBOLS
local NV_POI_KILL_GOAL = Symbol("NVPoiKillGoal")
local NV_KILL_COUNT = Symbol("NVSentientFragmentKillCount")
local sHide = Symbol("Hide")
local sMissileCoreTag = Symbol("RJMissilePlatformCore")

--CACHED VARS
local mGameRules = nil
local mAiDir = nil
local mHint = nil
local mHintPos = nil
local mHintActivationRadius = 0
local mDeactivateRadius = 0
local mParentHint = nil
local mTransmissionSet = nil
local mTimerMgr = nil
local mModeMgr = nil
local mSpawnMgr = nil
local mPlayers = nil

--STATES
local INVALID = 0
local STARTED = 1
local WAITING_FOR_SATELLITE = 2
local WAITING_FOR_BEACON = 4
local BEACON_DEFENSE = 5
local CONSUMING_KILLCODES = 6
local WARPING_AWAY = 7
local WAITING_FOR_REUSE = 8
local COMPLETED = 10

--SETTINGS 
local MIN_AEROLYST_TIMER = 60
local MAX_AEROLYST_TIMER = 120
local KILLCODE_RATE = {1.67, 2, 2.5, 3.33} --% per second
local KILLCODE_GOAL = 9
local WARP_DELAY = 10

--VARS
local mCrewShip = nil
local mAvatar = nil
local mEnterAction = nil
local mDisableMarker = nil
local mDisableAction = nil
local mSpawns = {}
local mAerolyst = nil
local mAerolystsDefeated = 0
local mTransmitters = {}
local mBeaconActions = {}
local mBeaconsActivated = 0
local mExitAction = nil

local mBeaconTriggers = nil
local mBeaconAreaMarkers = {}
local mBeaconRings = {}

local mKillCodeProgressTracker = nil
local mKillCodeProgress = 0
local mHaveKillCode = false
local mKillCodesCompleted = 0
local mLocalSquadHostName = EMPTY_STRING
local mSender = nil
local mWaitingForKillCode = false
local mAwayTeamTracker = nil
local mDropOffMarker = nil
local mDropOffPoint = nil
local mSatelliteAvatar = nil

local function UpdateUI()
    if not IsNull(mKillCodeProgressTracker) then
        if mHaveKillCode then
            mKillCodeProgressTracker.SetLabel("[HC] KILL CODE UPLOAD:" .. math.floor(mKillCodeProgress) .. "%")
        else
            mKillCodeProgressTracker.SetLabel("[HC] WAITING FOR KILL CODE")
        end
    end
    
    if mModeMgr:GetModeState() == CONSUMING_KILLCODES then
        if not IsNull(mAwayTeamTracker) then
            local extraString = mAwayTeamTracker.Localize(xOfYLoc, { CURRENT = mKillCodesCompleted, TOTAL = UTIL.Ternary(gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug"), 1, KILLCODE_GOAL) })
            RAILOBJ.SetExternalTrackerLabel(mAwayTeamTracker, true, "[HC] AWAY TEAM: UPLOAD KILLCODES: ", extraString, RAILOBJ.GENERIC_ICON)
        end
    end
end

local function SpawnAerolyst()
    _T.ShowImpactMessage("AEROLYST SPAWNED", 5, false, nil, nil)
    mAerolyst = mAiDir:CreateAgent(aerolystAgentType, mSpawns[RandomInt(1, #mSpawns)], EMPTY_SYMBOL)
end

local function SetupGlobalFunctions()
    if IsNull(_T.ScenarioPullHandlers) then
        _T.ScenarioPullHandlers = {}
    end
    _T.ScenarioPullHandlers["KillCodes"] = function(requester, sender)
        if sender == "" then
            return
        end
        if requester == mLocalSquadHostName then
            local rotation = LookTo(mSatelliteAvatar:GetPosition(), mAvatar:GetPosition())
            gRegion:CreateEntity(satelliteKillcodeConsumedFx, mSatelliteAvatar:GetPosition(), rotation)
            mHaveKillCode = true
            mWaitingForKillCode = false
            mSender = sender
        end
    end

    _T.IsFragmentObjectiveComplete = function()
        return mModeMgr:GetModeState() == WAITING_FOR_REUSE
    end
    
    _T.FragmentBeaconsPlaced = function()
        return mModeMgr:GetModeState() == BEACON_DEFENSE or mModeMgr:GetModeState() == CONSUMING_KILLCODES
    end
end

local function ClearGlobalFunctions()
    _T.FragmentBeaconsPlaced = nil
    _T.IsFragmentObjectiveComplete = nil
    _T.ScenarioPullHandlers["KillCodes"] = nil
end

-- OnModeStateChanged - this is called immediately when state changes - use this function for setting up the state (UI changes, creating objects, etc)
-- This func is called after host migration, so you can recover from the state you migrated during
local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    if curState == STARTED then
        for i, trigger in ipairs(mBeaconTriggers) do
            trigger:Enable()
            
            local marker = MODE.CreateAreaMarker(objectiveAreaMarkerType, trigger:GetPosition(), trigger:GetRadius())
            trigger:AttachEntity(marker, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION)
            table.insert(mBeaconAreaMarkers, marker)
            
            local defendRing = gRegion:CreateEntity(activeRingType, trigger:GetPosition(), ZERO_ROTATION)
            defendRing:SetMeshScale(trigger:GetRadius() / 10)
            table.insert(mBeaconRings, defendRing)
        end
    
    elseif curState == WAITING_FOR_SATELLITE then
        if not mAvatar:IsVisible() then
            gRegion:CreateEntity(fragmentWarpInFx, mAvatar:GetPosition(), ZERO_ROTATION)
            mTimerMgr:AddTimer(
                0.15,
                function()
                    mAvatar:SetVisibility(true, true)
                    mEnterAction:Disable()
                end
            )
        end
        
        mDropOffMarker = gRegion:CreateEntity(objectiveMarkerType, mDropOffPoint:GetPosition(), ZERO_ROTATION)
        mDropOffMarker:SetTag(Symbol("Sentient"))
        SetupGlobalFunctions()
        
    elseif curState == WAITING_FOR_BEACON then
        mSpawnMgr:ShipBoarded()
        UpdateUI()
        mAwayTeamTracker = _T.GetHudTracker("AwayTeamTracker")
        RAILOBJ.SetExternalTrackerLabel(mAwayTeamTracker, true, "[HC] AWAY TEAM: PLANT SQUAD BEACONS", nil, RAILOBJ.GENERIC_ICON)
        
    elseif curState == BEACON_DEFENSE then
        
    elseif curState == CONSUMING_KILLCODES then
        if not IsNull(_T.ScenarioSetLocalSquadMissionStatus) then
            _T.ScenarioSetLocalSquadMissionStatus("RelayingCodes")
        end
        mKillCodeProgressTracker = _T.AddHudTracker("KillCodeProgress", LOTUS_UTIL.HT_LABEL, nil, 15)
        mKillCodeProgressTracker.SetOffset(25, 0, true)
        UpdateUI()
        
    elseif curState == WARPING_AWAY then    
        mEnterAction:Disable()
        gRegion:CreateEntity(fragmentWarpWarningFx, mBeaconTriggers[1]:GetPosition(), ZERO_ROTATION)
        
        mKillCodesCompleted = 0
        
        local crewShipMgr = gGameRules:GetCrewShipManager()
        local playerShip = crewShipMgr:GetShips(true)[1]
        local pos = RAIL.FindFirstTaggedOnShip(Symbol("BoardShipPosition"), playerShip):GetPosition()
        
        local avatars = gRegion:GetHumanPlayerAvatars()
        for i, avatar in ipairs(avatars) do
            if avatar:InventoryControl():GetOnBoardShip() == mCrewShip then
                ABILITIES.RailjackRecall(avatar, recallFxType, recallFxTypeAW, recallFxFailType, teleportSound, teleportWarningSound, activateTeleportSound)
            end
        end
        
        ClearGlobalFunctions()
        
        mAwayTeamTracker = _T.GetHudTracker("AwayTeamTracker")
        mAwayTeamTracker.SetVisible(false)
        _T.RemoveHudTracker(mKillCodeProgressTracker)
        RAIL.RemoveCheatTracker()
        
        for i, avatar in ipairs(_T.ScenarioBeacons) do
            avatar:SetVisibility(false, true)
        end
        
        mTimerMgr:AddTimer(
            WARP_DELAY,
            function()
                gRegion:CreateEntity(hideFx, mAvatar:GetPosition(), ZERO_ROTATION)
                mTimerMgr:AddTimer(
                    2, 
                    function() 
                        mAvatar:SetVisibility(false, true) 
                        mModeMgr:SetModeState(WAITING_FOR_REUSE)
                    end
                )
            end
        )
    
    elseif curState == WAITING_FOR_REUSE then
        mSpawnMgr:CleanUp()
        for i, ring in ipairs(mBeaconRings) do
            ring:SetVisibility(true, true)
        end
        
        for i, marker in ipairs(mBeaconAreaMarkers) do
            marker:Enable()
        end
        mSpawnMgr:ResetSpawns()
    end
end

-- Initialize - first thing that runs when a mission encounter starts - do your initial setup here. This is called again on migration.
-- Because gPromotedToHost is unreliable here, you will need to search for mission entities first, and create if not found (see mMissionObject)
local function Initialize(hint)
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    mGameRules = gGameRules
    mHint = hint
    mParentHint = hint:GetRootParentEncounterHint()
    mHintPos = hint:GetPosition()
    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()
    gRegion:AddPlayersChangedBasicCallback("OnPlayersChanged")
    mPlayers = gRegion:GetHumanPlayers()
    
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})
    mTimerMgr = TIMER.CreateTimerMgr()
    
    mDropOffPoint = gRegion:FindNearestTagged(Symbol("SatelliteDropOffPoint"), mParentHint:GetPosition())
    
    local squadMembers = gMatchingService:GetSquadMembers()
    for i=1,#squadMembers do
        local squadPlayer = squadMembers[i]
        if squadPlayer.isHost then
            mLocalSquadHostName = squadPlayer.name
            break
        end
    end
    
    local registeredAgents = mParentHint:GetRegisteredAgents()
    for i, agent in ipairs(registeredAgents) do
        if agent:IsA(pointOfInterestAgentType) then
            mAvatar = agent:GetAvatar()
            mCrewShip = mAvatar:InventoryControl():GetActivePowerSuit()
            break
        end
    end
    
    mSpawns = RAIL.FindTypeOnShip(gNpcSpawnPointType, mCrewShip)
    
    mEnterAction = gRegion:FindNearestTagged(Symbol("EnterPoiAction"), mParentHint:GetPosition())

    mSpawnMgr = RAIL.CreateSpawnMgr(mHint, mCrewShip)
    mBeaconTriggers = RAIL.FindTaggedOnShip(Symbol("CondrixDefendArea"), mCrewShip)
    mSatelliteAvatar = gRegion:FindFirstTagged(Symbol("SquadLinkDefenseAvatar"))
    
    local BeaconCallback = function(beaconAvatar)
        if mModeMgr:GetModeState() == WAITING_FOR_BEACON then
            mSpawnMgr:EnableDefenseMode(mBeaconTriggers[1]:GetZone())
            mModeMgr:SetModeState(BEACON_DEFENSE)
        end
    end
    
    if IsNull(_T.ScenarioBeaconSpawnedCallback) then
        _T.ScenarioBeaconSpawnedCallback = {}
    end
    table.insert(_T.ScenarioBeaconSpawnedCallback, BeaconCallback)
    
    RAIL.CreateCheatTracker()
    
    if IsNull(_T.StartFragmentObjective) then
        _T.StartFragmentObjective = {}
    end
    local name = mAvatar:GetFullName()
    _T.StartFragmentObjective[name] = function()
        mModeMgr:SetModeState(WAITING_FOR_SATELLITE)
        return mDropOffMarker
    end

    -- Restore callbacks
    local agents = mHint:GetRegisteredAgents()
    for i, agent in ipairs(agents) do
        local avatar = agent:GetAvatar()
        if not IsNull(avatar) and avatar ~= mAvatar then
            agent:SetOwningEncounter(mHint)
            ObjectPortHandler(avatar, "OnKilled")
        end
    end
    
    local netState = mHint:GetEncounterDynamicState()
    
    if netState == 0 then
        
    else
        
    end
    
    _T.OpLinkSpaceMission = true
    
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))
    hint:SetEncounterStatus(Npc.ES_ACTIVE)
end

local function GetNumBeaconsOnShip()
    local count = 0
    for i, beacon in ipairs(_T.ScenarioBeacons) do
        if not beacon:IsKilled() and mCrewShip:IsEntityOnBoardShip(beacon) then
            count = count + 1
        end
    end
    return count
end

--Main function - Contains main update loop, monitor mode state here
function Start(hint)
    Initialize(hint)
    
    local delta = 0
    local curState = INVALID
    while true do
        if gGameRules:MissionCompleted() or gGameRules:MissionFailed() or hint:GetEncounterStatus() >= Npc.ES_SUCCEEDED then
            break
        end
        
        delta = DeltaTime()
        curState = mModeMgr:GetModeState()
        
        RAIL.UpdateCheatTracker()
        
        if curState == STARTED then
        
        elseif curState == WAITING_FOR_SATELLITE then
            local onShip = RAIL.GetPlayerAvatarsOnShip(mCrewShip)   --not great because its gets an array and counts it..
            if #onShip > 0 then
            
                local gooSpawners = RAIL.FindTypeOnShip(WeakResource("/Lotus/Types/LevelObjects/Sentient/SpawnedObjects/GooSpawner"), mCrewShip)
                for i, sp in ipairs(gooSpawners) do 
                    sp:SetSourceObject(mHint)
                end
                
                mModeMgr:SetModeState(WAITING_FOR_BEACON)
            end
            
        elseif curState == WAITING_FOR_BEACON then  --TODO: Not sure this separate state is necessary
            if GetNumBeaconsOnShip() > 0 then
                mModeMgr:SetModeState(CONSUMING_KILLCODES)
            end
        
        elseif curState == BEACON_DEFENSE then
            mModeMgr:SetModeState(CONSUMING_KILLCODES)
            
        elseif curState == CONSUMING_KILLCODES then
            if mHaveKillCode then
                local numBeacons = GetNumBeaconsOnShip()
                if numBeacons > 0 then
                    mKillCodeProgress = math.min(100, mKillCodeProgress + DeltaTime() * KILLCODE_RATE[numBeacons])
                end
                
                if mKillCodeProgress >= 100 then
                    mKillCodeProgress = 0
                    mKillCodesCompleted = mKillCodesCompleted + 1
                    
                    if mKillCodesCompleted >= KILLCODE_GOAL or (gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug") and mKillCodesCompleted > 0) then
                        mModeMgr:SetModeState(WARPING_AWAY)
                    else
                        for i, beacon in ipairs(_T.ScenarioBeacons) do
                            gRegion:CreateEntity(beaconKillcodeUploadedFx, beacon:GetPosition(), ZERO_ROTATION)
                        end
                        mHaveKillCode = false
                    end
                    
                    print("Consumed kill code from " .. mSender)
                end
            elseif not mWaitingForKillCode then
                if not IsNull(_T.SendScenarioHubEvent) then
                    _T.SendScenarioHubEvent(nil, nil, "KillCodes", nil, "pull")
                    mWaitingForKillCode = true
                end
            end
            
            UpdateUI()
        elseif curState == WARPING_AWAY then
            
        
        end
        
        if curState > STARTED then
            mSpawnMgr:Update(delta)
        end

        mTimerMgr:Update(delta)
        
        Sleep(0)
    end

    mModeMgr:ShutDown()
end

--CALLBACKS
function OnPlayersChanged()
    mPlayers = gRegion:GetHumanPlayers()
end


function PlaceBeacon(action)
    local instigatorAvatar = action:GetCurrUser()
    beaconGlow:FirePort("Hide")
    beaconDeco:FirePort("Show")
    action:Disable()
    beaconDeco:PlayAnimation(beaconOpenAnim, true, false)
    beaconDeco:PlayAnimation(beaconOpenIdleAnim, false, true)
    local effect = gRegion:CreateEntity(beaconEffect, beaconDeco:GetPosition(), ZERO_ROTATION)
    
end

function UploadKillCodeCheat()
    _T.SendScenarioHubEvent(nil, nil, "KillCodes", nil, "push")
end
