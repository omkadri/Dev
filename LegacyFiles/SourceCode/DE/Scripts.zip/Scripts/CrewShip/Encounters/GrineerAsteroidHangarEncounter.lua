--ARGS
crewShipType = Type()
destroyerType = Type()

--LIBS
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local RAILOBJ = require "Lotus.Scripts.Libs.RailjackObjectiveUI"

--RESOURCES
local replicatedHitSwitchRes = WeakResource("/EE/Types/Actions/ReplicatedHitSwitch")
local pointOfInterestAgentType = WeakResource("/Lotus/Types/Game/CrewShip/PointOfInterestAgent")

--LOC
local exposeFirstWeakpointLoc = "/Lotus/Language/RailjackMissions/POIExposeFirstRadiator"
local destroyFirstWeakpointLoc = "/Lotus/Language/RailjackMissions/POIDestroyFirstRadiator"
local exposeSecondWeakpointLoc = "/Lotus/Language/RailjackMissions/POIExposeSecondRadiator"
local destroySecondWeakpointLoc = "/Lotus/Language/RailjackMissions/POIDestroySecondRadiator"
local stealDestroyerLoc = "/Lotus/Language/RailjackMissions/HangarStealDestroyer"

--SYMBOLS
local subObjTrackerName = "HangarSubObj"

--CACHED VARS
local mGameRules = nil
local mAiDir = nil
local mHint = nil
local mHintPos = nil
local mHintActivationRadius = 0
local mDeactivateRadius = 0
local mParentHint = nil
local mTransmissionSet = nil
local mTimerMgr = nil
local mModeMgr = nil
local mSpawnMgr = nil
local mPlayers = nil
local MINOR_KILL_GOALS = {20, 23, 26, 29}

--STATES
local INVALID = 0
local STARTED = 1
local APPROACHED = 2
local EXPOSE_WP1 = 3
local DESTROY_WP1 = 4
local EXPOSE_WP2 = 5
local DESTROY_WP2 = 6
local STEAL_DESTROYER = 7
local DISABLED = 8

--SETTINGS

--VARS
local mCrewShip = nil
local mAvatar = nil
local mEnterAction = nil
local mFirstWeakpoint = nil
local mSecondWeakpoint = nil
local mFirstWeakpointAction = nil
local mSecondWeakpointAction = nil
local mCheatTracker = nil
local mObjectiveTracker = nil
local mBoardCrewShipAction = nil
local mDestroyerShip = nil

function OnActivated(action)
    --TODO: disable steal action 
    mModeMgr:SetModeState(DISABLED)
end

function FirePort(forwarder)
    if mModeMgr:GetModeState() == EXPOSE_WP1 then
        mModeMgr:SetModeState(DESTROY_WP1)
    elseif mModeMgr:GetModeState() == EXPOSE_WP2 then
        mModeMgr:SetModeState(DESTROY_WP2)
    end
end

function OnDisabled(entity)
    if entity == mFirstWeakpoint then
        mModeMgr:SetModeState(EXPOSE_WP2)
    elseif entity == mSecondWeakpoint then
        mSpawnMgr:QueueCustomSpawns(2)
        mModeMgr:SetModeState(STEAL_DESTROYER)
    end
end

local function CrewShipInitialize()
    local setupScript = gRegion:FindNearestTagged(Symbol("PoiSetupScript"), mHintPos)
    if not IsNull(setupScript) then
        setupScript:FirePort("Execute")
    else
        print("POI - Could not find setup script")
    end
    
    mAvatar = mCrewShip:GetAvatarOwner()
    
    local objectiveWaypoint = RAIL.FindFirstTaggedOnShip(Symbol("ObjectiveWaypoint"), mCrewShip)
    mAiDir:SetObjective(objectiveWaypoint)
    mSpawnMgr = RAIL.CreateSpawnMgr(mHint, mCrewShip)
    mEnterAction = gRegion:FindNearestTagged(Symbol("EnterPoiAction"), mHintPos)    
    
    mFirstWeakpointAction = RAIL.FindFirstTaggedOnShip(Symbol("WeakpointConsole"), mCrewShip)
    mSecondWeakpointAction = RAIL.FindFirstTaggedOnShip(Symbol("WeakpointConsole2"), mCrewShip)
    local forwarder = gRegion:FindNearestTagged(Symbol("SuccessfulHackForwarder"), mFirstWeakpointAction:GetPosition())
    ObjectPortHandler(forwarder, "FirePort")
    local forwarder = gRegion:FindNearestTagged(Symbol("SuccessfulHackForwarder"), mSecondWeakpointAction:GetPosition())
    ObjectPortHandler(forwarder, "FirePort")
    
    local weakpoints = RAIL.FindTaggedInScope(Symbol("MissilePlatformWeakpoint"), mEnterAction:GetScope())
    table.sort(
        weakpoints,
        function(a, b)
            local posA, posB = a:GetPosition(), b:GetPosition()
            if posA.x == posB.x then
                if posA.y == posB.y then
                    return posA.z < posB.z
                else
                    return posA.y < posB.y
                end
            else
                return posA.x < posB.x
            end
        end
    )
    mFirstWeakpoint = weakpoints[1]
    mSecondWeakpoint = weakpoints[2]
    ObjectPortHandler(mFirstWeakpoint, "OnDisabled")
    ObjectPortHandler(mSecondWeakpoint, "OnDisabled")
    
    mBoardCrewShipAction = RAIL.FindFirstTaggedOnShip(Symbol("BoardCrewShipAction"), mCrewShip)
    
    local lockDoorScript = RAIL.FindFirstTaggedOnShip(Symbol("LockDoorScript"), mCrewShip)
    lockDoorScript:FirePort("Execute")
    
    --[[mObjectiveTracker = _T.GetHudTracker(mHint:GetFullName() .. "Tracker")
    if IsNull(mObjectiveTracker) then
        mObjectiveTracker = _T.AddHudTracker(mHint:GetFullName() .. "Tracker", LOTUS_UTIL.HT_LABEL)
        mObjectiveTracker.SetVisible(false)
    end]]
    
    mCheatTracker = _T.AddHudTracker("Cheat", LOTUS_UTIL.HT_LABEL)
    local textOpen = "<p><font face=\"Noto Sans\" color=\"#FF0000\">"
    local textClose = "</font></p>"
    mCheatTracker.SetLabel(textOpen .. "LotusGameRules.MissionDebug ENABLED" .. textClose)
    mCheatTracker.SetVisible(false)
end

function ShipReady(ship)
    mCrewShip = ship
    mAvatar = mCrewShip:GetAvatarOwner()
    mHint:RegisterAgent(mAvatar:GetAgent())
end

function DestroyerReady(ship)
    mDestroyerShip = ship
    local agent = mDestroyerShip:GetAvatarOwner():GetAgent()
    mHint:RegisterAgent(agent)
    agent:StopMoving()
    agent:SetPaused(true, Symbol("HangarEncounter"))
    
    local waypoint = gRegion:FindNearestTagged(Symbol("EnemyCrewShipSpawnHijack"), mHintPos)
    agent:GetAvatar():Teleport(waypoint:GetPosition(), waypoint:GetRotation())
    agent:GetAvatar():SetView(waypoint:GetRotation())
    
    local doors = gRegion:FindTagged(Symbol("CrewshipDoors"))
    for i = 1, #doors do
        doors[i]:FirePort("Open")
    end

    _T.GrineerDestroyerEmptySpawned = function(crewShip)
        if crewShip == ship then
            mBoardCrewShipAction:Enable()
        end
    end
end

-- OnModeStateChanged - this is called immediately when state changes - use this function for setting up the state (UI changes, creating objects, etc)
-- This func is called after host migration, so you can recover from the state you migrated during
local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    
    if curState == STARTED then
        mAvatar:SetPosition(mHintPos)
        mEnterAction:Enable()
        RAIL.SetCrewShipEnterMarker(true, mCrewShip)
        print("Spawned Asteroid Hangar")
        
    elseif curState == EXPOSE_WP1 then
        mSpawnMgr:ShipBoarded()
        mFirstWeakpointAction:Enable()
        --mObjectiveTracker.SetVisible(true)
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(exposeFirstWeakpointLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, exposeFirstWeakpointLoc, RAILOBJ.GENERIC_ICON)
    
    elseif curState == DESTROY_WP1 then
        if gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug") then
            mTimerMgr:AddTimer(10, function() mFirstWeakpoint:Disable() end)
        end
        mFirstWeakpoint:Activate()
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(destroyFirstWeakpointLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, destroyFirstWeakpointLoc, RAILOBJ.ATTACK_ICON)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("WeakpointExposed"))
    
    elseif curState == EXPOSE_WP2 then
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(exposeSecondWeakpointLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, exposeSecondWeakpointLoc, RAILOBJ.GENERIC_ICON)
        mSecondWeakpointAction:Enable()
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("FirstWeakpointDestroyed"))
    
    elseif curState == DESTROY_WP2 then
        if gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug") then
            mTimerMgr:AddTimer(10, function() mSecondWeakpoint:Disable() end)
        end
        mSecondWeakpoint:Activate()
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(destroySecondWeakpointLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, destroySecondWeakpointLoc, RAILOBJ.ATTACK_ICON)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("WeakpointExposed"))
    
    elseif curState == STEAL_DESTROYER then
        local unlockDoorScript = RAIL.FindFirstTaggedOnShip(Symbol("UnlockDoorScript"), mCrewShip)
        unlockDoorScript:FirePort("Execute")
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(stealDestroyerLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, stealDestroyerLoc, RAILOBJ.GENERIC_ICON)
        -- mBoardCrewShipAction:Enable()
        ObjectPortHandler(mBoardCrewShipAction, "OnActivated")
        local crewShipMgr = gGameRules:GetCrewShipManager()
        crewShipMgr:CreateCrewShipFromType(destroyerType, nil, false, true, "DestroyerReady")
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("ObjectiveStealDestroyer"))
        
    elseif curState == DISABLED then
        --_T.RemoveHudTracker(mObjectiveTracker)
        RAILOBJ.RemoveObjective(mHint, subObjTrackerName)
        RAILOBJ.RemoveObjective(mHint)
        RAIL.SetCrewShipEnterMarker(false, mCrewShip)
        RAIL.SetCrewShipExitMarker(true, mCrewShip)
        mHint:SetEncounterStatus(Npc.ES_COMPLETE)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("ObjectiveComplete"))
    end
end

-- Initialize - first thing that runs when a mission encounter starts - do your initial setup here. This is called again on migration.
-- Because gPromotedToHost is unreliable here, you will need to search for mission entities first, and create if not found (see mMissionObject)
local function Initialize(hint)
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    mGameRules = gGameRules
    mHint = hint
    mParentHint = hint:GetRootParentEncounterHint()
    mHintPos = hint:GetPosition()
    mHintActivationRadius = hint:GetActivationRadius()
    mDeactivateRadius = hint:GetDeactivationRadius()
    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()
    gRegion:AddPlayersChangedBasicCallback("OnPlayersChanged")
    mPlayers = gRegion:GetHumanPlayers()
    
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})
    mTimerMgr = TIMER.CreateTimerMgr()

    local netState = mHint:GetEncounterDynamicState()
    if netState > INVALID then
        --recover crewship/avatar after migration
        while IsNull(mCrewShip) do
            local registeredAgents = mHint:GetRegisteredAgents()
            for i, agent in ipairs(registeredAgents) do
                if agent:IsA(pointOfInterestAgentType) then
                    mAvatar = agent:GetAvatar()
                    mCrewShip = mAvatar:InventoryControl():GetActivePowerSuit()
                    break
                end
            end
            if IsNull(mCrewShip) then
                Sleep(0)
            end
        end
    else
        local crewShipMgr = gGameRules:GetCrewShipManager()
        crewShipMgr:CreateCrewShipFromType(crewShipType, nil, false, true, "ShipReady")
    end
    
    while IsNull(mCrewShip) do
        Sleep(0)
    end
    
    CrewShipInitialize()
    
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))
    hint:SetEncounterStatus(Npc.ES_ACTIVE)
end

--Main function - Contains main update loop, monitor mode state here
function Start(hint)
    Initialize(hint)
    
    local delta = 0
    local curState = INVALID
    while true do
        if gGameRules:MissionCompleted() or gGameRules:MissionFailed() or hint:GetEncounterStatus() >= Npc.ES_SUCCEEDED then
            break
        end
    
        delta = DeltaTime()
        curState = mModeMgr:GetModeState()
        
        if gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug") then
            mCheatTracker.SetVisible(true)
        else
            mCheatTracker.SetVisible(false)
        end
        
        if curState == STARTED then
            if RAIL.ArePlayersNearEntity(mEnterAction, RAIL.POI_APPROACH_DISTANCE) then
                DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("ObjectiveProximity"))
                mModeMgr:SetModeState(APPROACHED)
            end
        
        elseif curState == APPROACHED then
            local onShip = RAIL.GetPlayerAvatarsOnShip(mCrewShip)   --not great because its gets an array and counts it..
            if #onShip > 0 then
                mModeMgr:SetModeState(EXPOSE_WP1)
            end
        end
        
        if curState > STARTED then
            mSpawnMgr:Update(delta)
        end
        
        if not mSpawnMgr.mCleanedUp and curState == DISABLED and mAiDir:CountPlayersInRegion(mCrewShip:GetInteriorLayer()) == 0 then
            mSpawnMgr:CleanUp()
        end

        mTimerMgr:Update(delta)
        
        Sleep(0)
    end
    
    mModeMgr:ShutDown()
end

--CALLBACKS
function OnPlayersChanged()
    mPlayers = gRegion:GetHumanPlayers()
end
