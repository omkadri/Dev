encounterAiSpec = Resource()
enemyTargetTier = 90
defensePrefabType = Resource()
transmissionSet = Resource()

enemyFaction = Symbol("Grineer")

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local UTIL = require "EE.Interface.Utilities"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"

local NV_RJ_DEFEND_ORBITER_STATE = Symbol("RJ_DEFEND_ORBITER_STATE")

local NOT_STARTED = 1
local WAITING_TO_START = 2
local STARTED = 3
local COMPLETE = 4
local FAILED = 5
local mModeState = INVALID
local SetModeState

local UPDATE_INTERVAL = 0.1 -- How frequently we will tick 

local mHint = nil
local mAiSpec = nil
local mAiDir = nil
local mTemplate = nil
local mTransmissionSet = nil

local activeDefendTimer = false
local defendMarker = nil
local orbiter = nil
local orbiterAgent = nil
local defendMarkerType = Type("/Lotus/Types/Game/MarkerInfos/CrewShipObjectiveMarkerInfoNoReticleAlwaysInRange")
local fighterPatrolType = Type("/Lotus/Types/Gameplay/CrewShip/Encounters/GrineerFighterPatrolEncounterHint")
local defendAgentType = Type("/Lotus/Types/Gameplay/CrewShip/Objectives/RJRescueExtractionPodAgent")

--local EXIT_HYPERSPACE_SEQ = Symbol("ExitHyperSpace")

local function ShouldShutDown()
    if mModeState == COMPLETE then
        Broadcast("DefendTennoOrbiterSubObjective.lua -- Defend Tenno Orbiter SubObjective Comlpete: Shutdown")
        return true
    elseif mModeState == FAILED then
        Broadcast("DefendTennoOrbiterSubObjective.lua -- Defend Tenno Orbiter SubObjective FAILED: Shutdown")
        return true
    end

    return false
end

local function ShutDownDefendTennoOrbiterObjective(hint)
    --Destroy crewships
    --set net variables back to 0.
    mAiDir:SetEnableAutoSpawns(false)
    gGameRules:SetNetPersistentVar(NV_RJ_DEFEND_ORBITER_STATE, 1)

end

function OnKilled(avatar)
    Broadcast("DefendTennoOrbiterSubObjective.lua -- THE ORBITER IS DEAD!!")
    gGameRules:SetNetPersistentVar(NV_RJ_DEFEND_ORBITER_STATE, FAILED)

end

local function OnModeStateChanged()
    if mModeState == WAITING_TO_START then
    
    elseif mModeState == STARTED then
        Broadcast("DefendTennoOrbiterSubObjective.lua -- Defend Tenno Orbiter SubObjective STARTED OnModeStateChanged")
        OBJTXT.SetNpcHealthTracker(orbiter)
        
        local defensePoint = mHint:GetSimPosition()
        local defenseRot = ZERO_ROTATION
        
        --createAgent instead?
        orbiterAgent = mAiDir:CreateAgentAtPosition(defendAgentType, defensePoint, defenseRot, Symbol("Tenno"))
        orbiter = orbiterAgent:GetAvatar()
        
        if not IsNull(orbiter) then
            ObjectPortHandler(orbiter, "OnKilled")
        end
        
        local localAlertLevel = mAiDir:GetLocalAlertAtPos(defensePoint)
    
        defendMarker = gRegion:CreateEntity(defendMarkerType, defensePoint, defenseRot)
        defendMarker:Enable()
        defendMarker:SetShowDistance(true)
        
        mAiDir:OrderNpcsStormTarget(orbiter, 200)
    
    
    elseif mModeState == COMPLETE then
        Broadcast("DefendTennoOrbiterSubObjective.lua -- Defend Tenno Orbiter SubObjective COMPLETE OnModeStateChanged")
    
        OBJTXT.ClearNpcHealthTracker()
        orbiter:Destroy()
    
    elseif mModeState == FAILED then
        Broadcast("DefendTennoOrbiterSubObjective.lua -- Defend Tenno Orbiter SubObjective FAILED OnModeStateChanged")
        
        defendMarker:Destroy()
        OBJTXT.ClearNpcHealthTracker()
        orbiter:Destroy()
        
        if not IsNull(OBJTXT.GetObjTimeTracker()) then
            OBJTXT.RemoveObjTimer()
        end
    
    end
end

local function Update(deltaTime)
    local modeState = gGameRules:GetNetPersistentVar(NV_RJ_DEFEND_ORBITER_STATE, NOT_STARTED)
    if modeState ~= mModeState then
        mModeState = modeState
        mHint:SetEncounterDynamicState(modeState)
        OnModeStateChanged(modeState)
    end

    if mModeState == WAITING_TO_START then
    
        SetModeState(STARTED)
        
    elseif mModeState == STARTED then
        --Broadcast("DefendTennoOrbiterSubObjective.lua -- Defend Tenno Orbiter SubObjective Started State Update")
        if not activeDefendTimer then
            OBJTXT.SetObjTimer(150, false, true, false, 2)
        end
        activeDefendTimer = true
        
        if activeDefendTimer then
            if IsNull(OBJTXT.GetObjTimeTracker()) then
                defendMarker:Destroy()
                SetModeState(COMPLETE)
            end
        end
    
    elseif mModeState == COMPLETE then
        Broadcast("DefendTennoOrbiterSubObjective.lua -- Defend Tenno Orbiter SubObjective WAS COMPLETED")
    elseif mModeState == FAILED then
        Broadcast("DefendTennoOrbiterSubObjective.lua -- Defend Tenno Orbiter SubObjective WAS FAILED")
    
    end
end

function CanActivateDefendTennoOrbiterObjective()
    --check if the proc system placed the correct rooms/objects in thte node. If not return false
    Broadcast("DefendTennoOrbiterSubObjective.lua -- Defend Tenno Orbiter SubObjective  - I Can begin?")
    return 1
end

local function Initialize(hint)
    mHint = hint
    mTemplate = mHint:GetCurrentEncounterTemplate()
    mTransmissionSet = mTemplate:GetTransmissionSet()

    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    if not IsNull(gGameRules) then
        --mAiSpec = capitalShipAiSpec
        local mission = gGameRules:GetMission()
        mAiSpec = mission.enemySpec
        if IsNull(mAiSpec) then
            mAiSpec = encounterAiSpec
            mission.enemySpec = encounterAiSpec
            gGameRules:SetMission(mission)
            mAiDir:AssignMissionAISpec(mAiSpec)
        end
    end

    local levelInfo = gRegion:GetLevelInfo()
    
    
    SetModeState(gGameRules:GetNetPersistentVar(NV_RJ_DEFEND_ORBITER_STATE, NOT_STARTED))

    if mModeState == NOT_STARTED then
        SetModeState(WAITING_TO_START)
    elseif mModeState >= STARTED then
    
    end
end

function DefendTennoOrbiter(hint)

    Broadcast("DefendTennoOrbiterSubObjective.lua -- Defend Tenno Orbiter SubObjective Initializing")
    Initialize(hint)

    local sleepTime = UPDATE_INTERVAL

    while not ShouldShutDown() do
        Update(sleepTime)
        Sleep(sleepTime)
    end

    ShutDownDefendTennoOrbiterObjective(hint)
end

SetModeState = function(newState)
    if mModeState ~= newState then
        mModeState = newState
        mHint:SetEncounterDynamicState(newState)
        gGameRules:SetNetPersistentVar(NV_RJ_DEFEND_ORBITER_STATE, newState)
        OnModeStateChanged()
    else
        print("DefendTennoOrbiterSubObjective.lua::SetModeState - trying to set mode to state we're already in")
    end
end