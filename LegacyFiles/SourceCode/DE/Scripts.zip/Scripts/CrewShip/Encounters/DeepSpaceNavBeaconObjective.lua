aiSpec = Resource()
transmissionSet = Resource()

enemyFaction = Symbol("Grineer")
enemyTeam = Symbol("RandomTeam")

navBeaconTriggerTag = Symbol("RJ_DS_NavBeaconTrigger")
navBeaconMarkerTag = Symbol("RJ_DS_NavBeaconMarker")
navBeaconLookTriggerTag = Symbol("RJ_DS_NavBeaconLookTrigger")

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local UTIL = require "EE.Interface.Utilities"

--local NV_RJ_NAVBEACON_STATE = Symbol("RJ_NAVBEACON_STATE")

local WAITING_TO_START = 1
local UNDISCOVERED = 2
local DISCOVERED = 3
local STARTED = 4
local COMPLETE = 99

local mModeState = INVALID
local SetModeState

local UPDATE_INTERVAL = 0.1 -- How frequently we will tick 

local mHint = nil
local mAiSpec = nil
local mAiDir = nil

local mTemplate = nil
local mTransmissionSet = nil

local mBeaconProgess = 0
local mNavBeaconProgessTracker = nil
local mNavBeaconTrigger = nil
local mNavBeaconMarker = nil
local mLookTrigger = nil

local mTouchingEntities = {}
local mPlayers

local captureRatePerSecond = 0.1
local abandonRatePerSecond = 0.2

local navBeaconGatherLoc = "[HC] EXTRACT NAV COORDINATES FROM DEBRIS"
local navBeaconPctLoc = "[HC] DATA ANALYZED: "

function OnPlayersChanged()
    mPlayers = gRegion:GetHumanPlayerAvatars()
end

local function ShouldShutDown()
    if mModeState == COMPLETE then
        return true
    end

    return false
end

local function ShutDownNavBeaconObjective(hint)
    --set net variables back to 0.
    --gGameRules:SetNetPersistentVar(NV_RJ_NAVBEACON_STATE, 0)
    
    --OBJTXT.ClearSecondaryObjText()
    _T.RemoveHudTracker(mNavBeaconProgessTracker)
    _T.HideImpactMessage()
end

local function UpdateNavBeaconProgress(deltaTime)
    if IsNull(mNavBeaconTrigger) then
        return
    end
    
    local beaconProgress = mBeaconProgess
    if #mTouchingEntities > 0 then
        beaconProgress = beaconProgress + deltaTime * captureRatePerSecond
    else
        beaconProgress = beaconProgress - deltaTime * abandonRatePerSecond
    end
    
    beaconProgress = Clamp(beaconProgress, 0, 1.0)
    
    mNavBeaconProgessTracker.SetLabel(mNavBeaconProgessTracker.Localize(navBeaconPctLoc) .. math.floor(100 * beaconProgress) .. "%")
    
    if beaconProgress > 0 then
        _T.ShowImpactMessage(math.floor(100 * beaconProgress) .. "%", -1, true, nil, false)
    else
        _T.HideImpactMessage()
    end

    mBeaconProgess = beaconProgress
    if mBeaconProgess >= 1.0 then
        return true
    else
        return false
    end
end

local function OnModeStateChanged()
    if mModeState == WAITING_TO_START then
    
    elseif mModeState == UNDISCOVERED then

    elseif mModeState == DISCOVERED then
        -- Turn on Objective Marker
        if not IsNull(mNavBeaconMarker) then
            mNavBeaconMarker:Enable()
        end
        --OBJTXT.SetSecondaryObjText(navBeaconGatherLoc)
        mNavBeaconProgessTracker = _T.AddHudTracker("NavDataDebris", LOTUS_UTIL.HT_LABEL)
        mNavBeaconProgessTracker.SetLabel(mNavBeaconProgessTracker.Localize(navBeaconPctLoc) .. math.floor(0) .. "%")
    elseif mModeState == STARTED then
        
    elseif mModeState == COMPLETE then
        mHint:SetEncounterStatus(Npc.ES_SUCCEEDED)
        if not IsNull(mNavBeaconMarker) then
            mNavBeaconMarker:Disable()
        end
        mNavBeaconTrigger:FirePort("Execute")
    end
end

local function Update(deltaTime)
    --local modeState = gGameRules:GetNetPersistentVar(NV_RJ_NAVBEACON_STATE, WAITING_TO_START)
    --if modeState ~= mModeState then
    --    mModeState = modeState
    --    mHint:SetEncounterDynamicState(modeState)
    --    OnModeStateChanged(modeState)
    --end

    if mModeState == UNDISCOVERED then
        if not IsNull(mLookTrigger) then
            for i=1, #mPlayers do
                if not IsNull(mPlayers[i]) then
                    local ship = mPlayers[i]:InventoryControl():GetOnBoardShip()
                    if IsNull(ship) then
                        if mLookTrigger:AvatarCanSeeMe(mPlayers[i]) then
                            SetModeState(DISCOVERED)
                            break
                        end
                    else
                        local check = ship:GetAvatarOwner()
                        if mLookTrigger:AvatarCanSeeMe(ship:GetAvatarOwner()) then
                            SetModeState(DISCOVERED)
                            break
                        end
                    end
                end
            end
        end
        
        -- Players managed to hit the objective trigger without hitting the look trigger, advance anyway
        if #mTouchingEntities > 0 then
            SetModeState(STARTED)
        end
    elseif mModeState == DISCOVERED then
        if #mTouchingEntities > 0 then
            SetModeState(STARTED)
        end
    elseif mModeState == STARTED then
        if UpdateNavBeaconProgress(deltaTime) then
            SetModeState(COMPLETE)
        end
    elseif mModeState == COMPLETE then
    
    end
end

function CanActivateNavBeaconEncounter(hint)
    mNavBeaconTrigger = gRegion:FindFirstTaggedInRadius(navBeaconTriggerTag, hint:GetPosition(), 0, 20)
    if IsNull(mNavBeaconTrigger) then
        return 0
    end

    mLookTrigger = gRegion:FindFirstTaggedInRadius(navBeaconLookTriggerTag, hint:GetPosition(), 0, 20)
    if IsNull(mLookTrigger) then
        return 0
    end
    
    mNavBeaconMarker = gRegion:FindFirstTaggedInRadius(navBeaconMarkerTag, hint:GetPosition(), 0, 20)
    if IsNull(mNavBeaconMarker) then
        return 0
    end

    return 1
end

function OnTouched(trigger)    
    local checkEntities = trigger:GetEntitiesTouching()
    for i=1, #checkEntities do
        local found = false
        local entity = checkEntities[i]
        if not IsNull(entity) then
            for j=1, #mTouchingEntities do
                if entity == mTouchingEntities[j] then
                    found = true
                    break
                end
            end
            
            if not found then
                table.insert(mTouchingEntities, entity)
            end
        end
    end
end

function OnUntouched(trigger)
    local checkEntities = trigger:GetEntitiesTouching()
    for i=1, #mTouchingEntities do
        local found = false
        local entity = mTouchingEntities[i]
        for j=1, #checkEntities do
             if entity == checkEntities[j] then
                found = true
                break
            end
        end
        
        if not found and not IsNull(entity) then            
            table.remove(mTouchingEntities, i) 
        end
    end
end

local function Initialize(hint)
    mHint = hint
    mTemplate = mHint:GetCurrentEncounterTemplate()
    mTransmissionSet = mTemplate:GetTransmissionSet()

    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    mPlayers = gRegion:GetHumanPlayerAvatars()
    
    gRegion:AddPlayersChangedBasicCallback("OnPlayersChanged")

    if not IsNull(gGameRules) then
        --mAiSpec = aiSpec
        local mission = gGameRules:GetMission()
        mAiSpec = mission.enemySpec
        if IsNull(mAiSpec) then
            mAiSpec = aiSpec
            mission.enemySpec = aiSpec
            gGameRules:SetMission(mission)
            mAiDir:AssignMissionAISpec(mAiSpec)
        end
    end
    
    mNavBeaconTrigger = gRegion:FindFirstTaggedInRadius(navBeaconTriggerTag, hint:GetPosition(), 0, 20)
    if IsNull(mNavBeaconTrigger) then
        return 0
    end

    mLookTrigger = gRegion:FindFirstTaggedInRadius(navBeaconLookTriggerTag, hint:GetPosition(), 0, 20)
    if IsNull(mLookTrigger) then
        return 0
    end
    
    mNavBeaconMarker = gRegion:FindFirstTaggedInRadius(navBeaconMarkerTag, hint:GetPosition(), 0, 20)
    if IsNull(mNavBeaconMarker) then
        return 0
    end
    
    mNavBeaconTrigger:Enable()
    ObjectPortHandler(mNavBeaconTrigger, "OnTouched")
    ObjectPortHandler(mNavBeaconTrigger, "OnUntouched")
    
    -- TEMP FOR TESTING
    if not IsNull(mNavBeaconMarker) then
        mNavBeaconMarker:Enable()
    end

    --local mModeState = gGameRules:GetNetPersistentVar(NV_RJ_NAVBEACON_STATE, WAITING_TO_START)
    SetModeState(UNDISCOVERED)
end

function NavBeaconEncounter(hint)
    Broadcast("DeepSpaceNavBeaconObjective.lua -- Nav Beacon SubObjective Started")
    Initialize(hint)

    local sleepTime = UPDATE_INTERVAL

    while not ShouldShutDown() do
        Update(sleepTime)
        Sleep(sleepTime)
    end

    ShutDownNavBeaconObjective(hint)
end

SetModeState = function(newState)
    if mModeState ~= newState then
        mModeState = newState
        mHint:SetEncounterDynamicState(newState)
    --    gGameRules:SetNetPersistentVar(NV_RJ_NAVBEACON_STATE, newState)
        OnModeStateChanged()
    else
        print("DeepSpaceNavBeaconObjective.lua::SetModeState - trying to set mode to state we're already in")
    end
end