-- boardShipContextActionWeakRes = WeakResource()
-- corpusCrewShipPilotAction = WeakResource()
crewshipObjectiveMarkerWRes = WeakResource()
enemyCrewShipSpawnPointsTag = Symbol("EnemyCrewShipSpawnPoint")
numOfCrewShips = 1
shipTypes = { Type() }

enemyFaction = Symbol()

local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"

local NV_HIJACK_CREWSHIP_STATE = Symbol("HIJACK_CREWSHIP_STATE")
local NOT_STARTED = 1
local WAITING_TO_START = 2
local STARTED = 3
local COMPLETE = 4
local mModeState = INVALID
local SetModeState

local UPDATE_INTERVAL = 0.1 -- How frequently we will tick 

local mHint = nil
local mGameRules = nil
local mEnemyCrewShips = { }
local mHijackedCrewShips = { }

local sTennoFaction = Symbol("TENNO")
local hijackedSymbol = Symbol("CrewShipHijacked")

local function ShouldShutDown()
    if mModeState == COMPLETE then
        return true
    end

    local crewShipMgr = gGameRules:GetCrewShipManager()
    if not IsNull(crewShipMgr) then
        local ship = crewShipMgr:GetPlayerShip()
        local shipAvatar = ship:GetAvatarOwner()
        local hyperDriveState = shipAvatar:GetHyperDriveState()

        if hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_BOARDING or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP then
            return true
        end
    end

    return false
end

local function ShutDownHijackEnemyCrewShipEncounter(hint)
    --Destroy crewships
    --set net variables back to 0.
    mGameRules:SetNetPersistentVar(NV_HIJACK_CREWSHIP_STATE, 1)
end

local function OnModeStateChanged()
    if mModeState == WAITING_TO_START then

    elseif mModeState == STARTED then
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/HijackEnemyCrewShip", 1)
        --do lotus vo

        if not IsNull(crewshipObjectiveMarkerWRes) then
            for i=1,#mEnemyCrewShips do
                if not IsNull(mEnemyCrewShips[i]) then
                    local enemyCrewShipAvatar = mEnemyCrewShips[i]:GetAvatarOwner()
                    local crewShipObjectiveMarker = enemyCrewShipAvatar:GetAttachment(crewshipObjectiveMarkerWRes)

                    if not IsNull(crewShipObjectiveMarker) then
                        crewShipObjectiveMarker:Enable()
                    end
                end
            end

            for i=1,#mHijackedCrewShips do
                if not IsNull(mHijackedCrewShips[i]) then
                    local hijackedCrewShipAvatar = mHijackedCrewShips[i]:GetAvatarOwner()
                    local crewShipObjectiveMarker = hijackedCrewShipAvatar:GetAttachment(crewshipObjectiveMarkerWRes)

                    if not IsNull(crewShipObjectiveMarker) then
                        crewShipObjectiveMarker:Enable()
                    end
                end
            end
        end
    elseif mModeState == COMPLETE then
        if not IsNull(crewshipObjectiveMarkerWRes) then
            for i=1,#mEnemyCrewShips do
                if not IsNull(mEnemyCrewShips[i]) then
                    local enemyCrewShipAvatar = mEnemyCrewShips[i]:GetAvatarOwner()
                    local crewShipObjectiveMarker = enemyCrewShipAvatar:GetAttachment(crewshipObjectiveMarkerWRes)

                    if not IsNull(crewShipObjectiveMarker) then
                        crewShipObjectiveMarker:Disable()
                    end
                end
            end

            for i=1,#mHijackedCrewShips do
                if not IsNull(mHijackedCrewShips[i]) then
                    local hijackedCrewShipAvatar = mHijackedCrewShips[i]:GetAvatarOwner()
                    local crewShipObjectiveMarker = hijackedCrewShipAvatar:GetAttachment(crewshipObjectiveMarkerWRes)

                    if not IsNull(crewShipObjectiveMarker) then
                        crewShipObjectiveMarker:Disable()
                    end
                end
            end
        end

        _T.ObjectiveComplete()
    end

end

function EnemyShipReady(enemyShip)
    if not IsNull(enemyShip) then
        table.insert(mEnemyCrewShips, enemyShip)
    end
end

function OnEnded(trigger)
    -- local pilotActions = gRegion:FindAllObjects(corpusCrewShipPilotAction)

    -- for
    -- check to see if a pilot action now exists and hold onto it.
    -- Add port handler on pilot action usage
    -- 
end

function OnKilled(avatar)
    for i=1,#mEnemyCrewShips do
        local enemyCrewShip = mEnemyCrewShips[i]
        if not IsNull(enemyCrewShip) and not IsNull(enemyCrewShip:GetAvatarOwner()) then
            local enemyCrewShipAvatar = enemyCrewShip:GetAvatarOwner()

            if enemyCrewShipAvatar == avatar then
                table.remove(mEnemyCrewShips, i)
                return
            end
        end
    end

    for i=1,#mHijackedCrewShips do
       local hijackedCrewShip = mHijackedCrewShips[i]
        if not IsNull(hijackedCrewShip) and not IsNull(hijackedCrewShip:GetAvatarOwner()) then
            local hijackedCrewShipAvatar = hijackedCrewShip:GetAvatarOwner()

            if hijackedCrewShipAvatar == avatar then
                table.remove(mHijackedCrewShips, i)
                return
            end
        end 
    end
end

local function UpdateShips()
    for i=1,#mHijackedCrewShips do
        local hijackedCrewShip = mHijackedCrewShips[i]
        local hijackedCrewShipAvatar = hijackedCrewShip:GetAvatarOwner()
        local hijackedCrewShipAgent = hijackedCrewShipAvatar:GetAgent()
        local isHijacked = hijackedCrewShipAgent:GetAgentBlackboardValue(hijackedSymbol)

        if hijackedCrewShip:HasPilot() == true then
            local shipPilot = hijackedCrewShip:GetPilot()
            

            if not IsNull(shipPilot) and shipPilot:GetFaction() ~= sTennoFaction then
                table.insert(mEnemyCrewShips, hijackedCrewShip)
                table.remove(mHijackedCrewShips, i)
                i = i - 1
            end
        elseif isHijacked == 0 then
            table.insert(mEnemyCrewShips, hijackedCrewShip)
            table.remove(mHijackedCrewShips, i)
            i = i - 1
        end
    end

    for j=1,#mEnemyCrewShips do
        local enemyCrewShip = mEnemyCrewShips[j]
        local enemyCrewShipAvatar = enemyCrewShip:GetAvatarOwner()
        local enemyCrewShipAgent = enemyCrewShipAvatar:GetAgent()
        local isHijacked = enemyCrewShipAgent:GetAgentBlackboardValue(hijackedSymbol)
        if enemyCrewShip:HasPilot() == true then
            local shipPilot = enemyCrewShip:GetPilot()

            if not IsNull(shipPilot) and shipPilot:GetFaction() == sTennoFaction then
                table.insert(mHijackedCrewShips, enemyCrewShip)
                table.remove(mEnemyCrewShips, j)
                j = j - 1
            end
        elseif isHijacked == 1 then
            table.insert(mHijackedCrewShips, enemyCrewShip)
            table.remove(mEnemyCrewShips, j)
            j = j - 1
        end
    end
end

local function SpawnEnemyCrewShips()
    local crewShipMgr = gGameRules:GetCrewShipManager()
    local crewShipSpawnPoints = gRegion:FindTagged(enemyCrewShipSpawnPointsTag)
    
    if IsNull(crewShipMgr) or #shipTypes < 1 or #crewShipSpawnPoints < numOfCrewShips then
        return
    end

    for i=1,numOfCrewShips do
        local shipType = shipTypes[RandomInt(1,#shipTypes)]
        local prevCrewShipsSize = #mEnemyCrewShips

        crewShipMgr:CreateCrewShipFromType(shipType, nil, false, false, "EnemyShipReady")

        while #mEnemyCrewShips == prevCrewShipsSize do
            Sleep(0)
        end
        
        local enemyShip = mEnemyCrewShips[#mEnemyCrewShips]
        if enemyShip == false then
            -- Error
        else

            local enemyCrewAvatar = enemyShip:GetAvatarOwner()
            ObjectPortHandler(enemyCrewAvatar, "OnKilled")

            while enemyCrewAvatar:GetAgent() == nil do
                Sleep(0)
            end

            local enemyCrewAgent = enemyCrewAvatar:GetAgent()
            mHint:RegisterAgent(enemyCrewAgent)

            local spawnIndex = RandomInt(1, #crewShipSpawnPoints)
            local spawnPos = crewShipSpawnPoints[spawnIndex]
            table.remove(crewShipSpawnPoints, spawnIndex)

            if not IsNull(spawnPos) then
                enemyCrewAvatar:Teleport(spawnPos:GetPosition(), spawnPos:GetRotation())
            else
                enemyCrewAvatar:Teleport(Vector(), Rotation()) -- gotta spawn somewhere
            end
        end
    end
end

local function Initialize(hint)
    mGameRules = gGameRules
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not aiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    SetModeState(mGameRules:GetNetPersistentVar(NV_HIJACK_CREWSHIP_STATE, NOT_STARTED))
    
    if mModeState == NOT_STARTED then
        SpawnEnemyCrewShips()
        SetModeState(WAITING_TO_START)
    elseif mModeState == STARTED then
        --find all existing pilot actions
        --outputhandler them all
        --check if anyone is flying and check/reset blackboard values
    end


end

local function Update(deltaTime)
    local modeState = mGameRules:GetNetPersistentVar(NV_HIJACK_CREWSHIP_STATE, NOT_STARTED)
    if modeState ~= mModeState then
        mModeState = modeState
        OnModeStateChanged(modeState)
    end

    UpdateShips()

    if mModeState == WAITING_TO_START then
        if _T.IsCurrentObjective(mHint) then
            SetModeState(STARTED)
        end
    elseif mModeState == STARTED then
        if #mHijackedCrewShips > 0 and #mEnemyCrewShips == 0 then
            SetModeState(COMPLETE)
        end  
    elseif mModeState == COMPLETE then
        --increment railjackmanagernetvar to move onto the next mission.
    end
end

SetModeState = function(newState)
    if IsNull(mGameRules) then
        mGameRules = gGameRules
    end    
    if mModeState ~= newState then
        mModeState = newState
        mGameRules:SetNetPersistentVar(NV_HIJACK_CREWSHIP_STATE, newState)
        OnModeStateChanged()
    else
        print("HijackEnemyCrewShipEncounter.lua::SetModeState - trying to set mode to state we're already in")
    end
end

function HijackEnemyCrewShip(hint)
    mHint = hint

    Broadcast("Hijack Enemy Crew Ship Started")
    Initialize(hint)

    local sleepTime = UPDATE_INTERVAL

    while not ShouldShutDown() do
        Update(sleepTime)
        Sleep(sleepTime)
    end

    ShutDownHijackEnemyCrewShipEncounter(hint)
end 
