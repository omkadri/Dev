squadSizeMin = 3 -- Min # fighters to spawn in a fighter squadron
squadSizeMax = 5 -- Min # fighters to spawn in a fighter squadron
spawnPointTag = Symbol("FighterReinforceSpawner")
enemyFaction = Symbol("Grineer")
enemyReinforcementTag = Symbol("ReinforcementFighter")
enemyFighterTier = 95
railjackAvatarType = WeakResource()
ramSledActive = false
ramSledTier = 85
spawnFx = Type()
alert = true
killObjective = false
registerAgentsToParent = true

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"

function EnemyReinforcements(hint)
    
    if IsNull(hint) then
        return
    end
    
    print("Spawning reinforcements")
    
    local npcMgr = gRegion:GetNpcMgr()
    local hintPos = hint:GetPosition()
    local parentHint = hint:GetRootParentEncounterHint()
    
    local hintDeactivateRadius = hint:GetDeactivationRadius()
    local hintRadius = hint:GetActivationRadius()
    local hintSpawnRadius = hint:GetSpawnRadius()
    
    local aiDir = npcMgr:GetAiDirector()
    local minLevel = aiDir:GetMinEnemyLevel()
    local maxLevel = aiDir:GetMaxEnemyLevel()
    local level = RandomInt(minLevel, maxLevel)
    local squadSize = aiDir:ScaleNpcCountForPlayers(squadSizeMin, squadSizeMax)
    squadSize = math.min(aiDir:GetRoomTillHardCap(), squadSize)
    local searchRadius = 1500
    local spawnTag = spawnPointTag
    local template = hint:GetCurrentEncounterTemplate()
    local transmissionSet = template:GetTransmissionSet()

    local allSpawnPoints = gRegion:FindTaggedInRadius(spawnTag, hintPos, 400, searchRadius)
    while IsNull(allSpawnPoints) do
        searchRadius = searchRadius + 500
        allSpawnPoints = gRegion:FindTaggedInRadius(spawnTag, hintPos, 400, searchRadius)
        
        if ( IsNull(allSpawnPoints) or #allSpawnPoints == 0 ) and searchRadius > 2500 then
            spawnTag = Symbol("FighterSpawner")
            allSpawnPoints = gRegion:FindTaggedInRadius(spawnTag, parentHint:GetPosition(), 0, parentHint:GetSpawnRadius())
        end
        Sleep(0)
    end
    
    local seedPoint = allSpawnPoints[RandomInt(1, #allSpawnPoints)]
    local spawnPoints = gRegion:FindTaggedInRadius(spawnTag, seedPoint:GetPosition(), 0, 600)
    local squadTeam = Symbol("RandomTeam")
    --local squadTeam = Symbol(parentHint:GetUniqueHintName())
    local spawnIndex = 0
    local spawner = nil

    if squadSize > 0 and #spawnPoints > 0 then
        for i = 1, squadSize do
            
            spawnIndex = RandomInt(1, #spawnPoints)
            spawner = spawnPoints[spawnIndex]
            table.remove(spawnPoints, spawnIndex)

            if IsNull(spawner) then
                break
            end 
            
            local spawnTier = enemyFighterTier
            if i == 1 and ramSledActive then
                spawnTier = ramSledTier
            end

            local agentType = aiDir:GetRandomEnemyAgentType(enemyFaction, level, false, false, spawnTier, true)
            local agent = aiDir:CreateAgentAtPosition(agentType, spawner:GetPosition(), ZERO_ROTATION, squadTeam)
            Sleep(0)

            if not IsNull(agent) then
                if ramSledActive and i == 1 then
                    DIALOG.PlayGlobalTransmission(transmissionSet, Symbol("LaunchRamSled"), 0)
                end

                if registerAgentsToParent == true then
                    parentHint:RegisterAgent(agent)
                else
                    hint:RegisterAgent(agent)
                end

                while IsNull(agent:GetAvatar()) do
                    Sleep(0.1)
                end

                local avatar = agent:GetAvatar()

                if not IsNull(avatar) and not IsNull(enemyReinforcementTag) then
                    avatar:SetTag(enemyReinforcementTag)
                end
                
                if alert then
                    agent:SetAlert()
                end

                if ramSledActive then
                    local target = gGameRules:GetCrewShipManager():GetPlayerShip():GetAvatarOwner()

                    if not IsNull(target) then
                        agent:StormTarget(target, 300)
                    end
                else
                    agent:StormTarget(parentHint, 300)
                end
                
                if killObjective then
                    agent:SetCountedAsKillTarget(true)
                    Broadcast("Spawned kill target")
                end
                
                if not IsNull(agent:GetAvatar()) and not IsNull(spawnFx) then
                    agent:GetAvatar():Attach(spawnFx, EMPTY_SYMBOL)
                end
                
                Sleep(0.1)
            elseif ramSledActive and i == 1 then
                print("No ramsled was able to be spawned")
            end

        end
    end

    Broadcast("Reinforcements Spawned @" .. hint:GetName())

    hint:SetEncounterStatus(Npc.ES_COMPLETE)
end