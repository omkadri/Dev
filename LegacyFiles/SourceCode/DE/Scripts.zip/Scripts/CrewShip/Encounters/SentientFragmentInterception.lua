--ARGS
attackMarkerType = Type()
attackAreaMarkerType = Type()
aerolystAgentType = Type()

controlPointIcon = String("MISSION_MARKER_A")

--LIBS
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local MODE = require "Lotus.Scripts.Libs.CommonGamemodeFunctions"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local RAILOBJ = require "Lotus.Scripts.Libs.RailjackObjectiveUI"
local SQUADLINK = require "Lotus.Scripts.Libs.SquadLink"
local TABLE = require "Lotus.Scripts.Libs.TableLib"

--RESOURCES
local pointOfInterestAgentType = WeakResource("/Lotus/Types/Game/CrewShip/PointOfInterestAgent")
local completionReward = Resource("/Lotus/Types/Items/MiscItems/SentientFragmentLootItem")

--LOC
local objectiveLoc = "[HC] CAPTURE THE TRANSMITTER"

--SYMBOLS
local NV_POI_KILL_GOAL = Symbol("NVPoiKillGoal")
local NV_KILL_COUNT = Symbol("NVSentientFragmentKillCount")
local sHide = Symbol("Hide")
local sMissileCoreTag = Symbol("RJMissilePlatformCore")

--CACHED VARS
local mGameRules = nil
local mAiDir = nil
local mHint = nil
local mHintPos = nil
local mHintActivationRadius = 0
local mDeactivateRadius = 0
local mParentHint = nil
local mTransmissionSet = nil
local mTimerMgr = nil
local mModeMgr = nil
local mSpawnMgr = nil
local mPlayers = nil

--STATES
local INVALID = 0
local STARTED = 1
local APPROACHED = 2
local TRANSMITTER_1 = 3
local TRANSMITTER_2 = 4
local TRANSMITTER_3 = 5
local DISABLED = 9
local COMPLETED = 10

--SETTINGS 
local MIN_AEROLYST_TIMER = 60
local MAX_AEROLYST_TIMER = 120

--VARS
local mCrewShip = nil
local mAvatar = nil
local mEnterAction = nil
local mDisableMarker = nil
local mDisableAction = nil
local mAreasHeld = 0
local mAreasToHold = 3
local mLinkedSquadWaiting = false
local mTriggerFull = false
local mSpawns = {}
local mAerolyst = nil
local mAerolystsDefeated = 0
local mKillsTracker = nil
local mLinked = false
local mTransmitters = {}

local function UpdateUI()
    local objString = ": " .. mAreasHeld .. " / " .. mAreasToHold
    RAILOBJ.SetSubObjective(mHint, "Kills", objectiveLoc, RAILOBJ.ATTACK_ICON, objString)
end

local function IsHostInTile(tileTag)
    tileTag = Symbol(tileTag)
    local player = gRegion:GetLocalPlayer()
    local avatar = player:GetAvatar()
    
    if IsNull(avatar) then
        return false
    end
    
    local zone = avatar:GetZone()
    if not IsNull(zone) then
        if zone:GetTag() == tileTag then
            return true
        end
    end
end

local function SpawnAerolyst()
    _T.ShowImpactMessage("AEROLYST SPAWNED", 5, false, nil, nil)
    mAerolyst = mAiDir:CreateAgent(aerolystAgentType, mSpawns[RandomInt(1, #mSpawns)], EMPTY_SYMBOL)
    ObjectPortHandler(mAerolyst:GetAvatar(), "OnKilled")
end

function OnKilled(avatar)
    mAerolystsDefeated = mAerolystsDefeated + 1
    mTimerMgr:AddTimer(RandomInt(MIN_AEROLYST_TIMER, MAX_AEROLYST_TIMER), SpawnAerolyst)
end

-- OnModeStateChanged - this is called immediately when state changes - use this function for setting up the state (UI changes, creating objects, etc)
-- This func is called after host migration, so you can recover from the state you migrated during
local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    if curState == STARTED then
        local avatar = mCrewShip:GetAvatarOwner()
        avatar:SetPosition(mHintPos)
        
    elseif curState == TRANSMITTER_1 then
        mSpawnMgr:ShipBoarded()
        UpdateUI()

        mSpawnMgr:ReinforceAndAttack(gRegion:GetLocalPlayerAvatar(), 20)
        mTimerMgr:AddTimer(RandomInt(MIN_AEROLYST_TIMER, MAX_AEROLYST_TIMER), SpawnAerolyst)
        mTransmitters[1]:FirePort("Execute")
        
    elseif curState == TRANSMITTER_2 then
        mTransmitters[2]:FirePort("Execute")
        
    elseif curState == TRANSMITTER_3 then
        mTransmitters[3]:FirePort("Execute")
        
    elseif curState == COMPLETED then
        RAILOBJ.RemoveObjective(mHint, "Kills")
        RAILOBJ.RemoveObjective(mHint)
        mHint:SetEncounterStatus(Npc.ES_COMPLETE)
        
    elseif curState == DISABLED then
        
    end
end

-- Initialize - first thing that runs when a mission encounter starts - do your initial setup here. This is called again on migration.
-- Because gPromotedToHost is unreliable here, you will need to search for mission entities first, and create if not found (see mMissionObject)
local function Initialize(hint)
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    mGameRules = gGameRules
    mHint = hint
    mParentHint = hint:GetRootParentEncounterHint()
    mHintPos = hint:GetPosition()
    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()
    gRegion:AddPlayersChangedBasicCallback("OnPlayersChanged")
    mPlayers = gRegion:GetHumanPlayers()
    
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})
    mTimerMgr = TIMER.CreateTimerMgr()
    
    local registeredAgents = mParentHint:GetRegisteredAgents()
    for i, agent in ipairs(registeredAgents) do
        if agent:IsA(pointOfInterestAgentType) then
            mAvatar = agent:GetAvatar()
            mCrewShip = mAvatar:InventoryControl():GetActivePowerSuit()
            break
        end
    end
    
    mSpawns = RAIL.FindTypeOnShip(gNpcSpawnPointType, mCrewShip)
    
    mEnterAction = gRegion:FindNearestTagged(Symbol("EnterPoiAction"), mHintPos)
    mDisableMarker = RAIL.FindFirstTaggedOnShip(Symbol("HangarDisableObjective"), mCrewShip)
    mDisableAction = RAIL.FindFirstTaggedOnShip(Symbol("HangarDisableAction"), mCrewShip)

    mSpawnMgr = RAIL.CreateSpawnMgr(mHint, mCrewShip)
    mSpawnMgr.mIgnoreNpcHardCap = true
    
    local endPoint = RAIL.FindFirstTaggedOnShip(Symbol("ExitMarker"), mCrewShip)
    
    mTransmitters = RAIL.FindTaggedOnShip(Symbol("Transmitter"), mCrewShip)
    
    -- Restore callbacks
    local agents = mHint:GetRegisteredAgents()
    for i, agent in ipairs(agents) do
        local avatar = agent:GetAvatar()
        if not IsNull(avatar) and avatar ~= mAvatar then
            agent:SetOwningEncounter(mHint)
            ObjectPortHandler(avatar, "OnKilled")
        end
    end
    
    local netState = mHint:GetEncounterDynamicState()
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))
    hint:SetEncounterStatus(Npc.ES_ACTIVE)
end

--Main function - Contains main update loop, monitor mode state here
function Start(hint)
    Initialize(hint)
    
    local delta = 0
    local curState = INVALID
    while true do
        if gGameRules:MissionCompleted() or gGameRules:MissionFailed() or hint:GetEncounterStatus() >= Npc.ES_SUCCEEDED then
            break
        end
        
        delta = DeltaTime()
        curState = mModeMgr:GetModeState()
        
        if curState == STARTED then
            if RAIL.ArePlayersNearEntity(mEnterAction, RAIL.POI_APPROACH_DISTANCE) then
                DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("ObjectiveProximity"))
                mModeMgr:SetModeState(APPROACHED)
            end
        
        elseif curState == APPROACHED then
            local onShip = RAIL.GetPlayerAvatarsOnShip(mCrewShip)   --not great because its gets an array and counts it..
            if #onShip > 0 then
            
                local gooSpawners = RAIL.FindTypeOnShip(WeakResource("/Lotus/Types/LevelObjects/Sentient/SpawnedObjects/GooSpawner"), mCrewShip)
                for i, sp in ipairs(gooSpawners) do 
                    sp:SetSourceObject(mHint)
                end
                
                mModeMgr:SetModeState(TRANSMITTER_1)
            end
        
        elseif curState == TRANSMITTER_1 then
            if not mTransmitters[1]:IsEnabled() then
                mModeMgr:SetModeState(TRANSMITTER_2)
            end
        
        elseif curState == TRANSMITTER_2 then
            if not mTransmitters[2]:IsEnabled() then
                mModeMgr:SetModeState(TRANSMITTER_3)
            end
        end
        
        if curState > STARTED then
            mSpawnMgr:Update(delta)
        end

        if not mSpawnMgr.mCleanedUp and curState == DISABLED and mAiDir:CountPlayersInRegion(mCrewShip:GetInteriorLayer()) == 0 then
            mSpawnMgr:CleanUp()
        end

        mTimerMgr:Update(delta)
        
        Sleep(0)
    end

    gGameRules:SetNetPersistentVar(NV_KILL_COUNT, 0)
    mModeMgr:ShutDown()
end

--CALLBACKS
function OnPlayersChanged()
    mPlayers = gRegion:GetHumanPlayers()
end

-- INTERCEPTION LOGIC
local TRANSFER_RATE = 1     --% per second

local mControlPoints = {}
local mTransferProgress = 0

function Transmitter(trigger)
    local tracker = _T.AddHudTracker("TransmitProgress", LOTUS_UTIL.HT_PROGRESS_BAR)
    tracker.SetLabel("[HC] TRANSMITTING")
    tracker.SetGoalLabel(mTransferProgress .. "%")
    tracker.SetValue(mTransferProgress / 100)
    
    local layer = trigger:GetZone():GetLayerIndex()
    local crewShipMgr = gGameRules:GetCrewShipManager()
    local ships = crewShipMgr:GetShips(false)
    for i, ship in ipairs(ships) do
        if ship:IsEntityOnBoardShip(trigger) then
            mCrewShip = ship
            break
        end
    end
    
    local points = RAIL.FindTaggedOnShip(Symbol("ControlPoint"), mCrewShip)
    mControlPoints = {}
    for i, point in ipairs(points) do
        if point:GetZone():GetLayerIndex() == layer then
            table.insert(mControlPoints, point)
            point:Enable()
        end
    end
    
    while not IsNull(trigger) do
        Sleep(0)
        
        local count = 0
        for i, point in ipairs(mControlPoints) do
            if point:GetState() == Lotus_Game.TS_PLAYER_OWNED then
                count = count + 1
            end
        end
        
        if count == #mControlPoints then
            mTransferProgress = math.min(100, mTransferProgress + TRANSFER_RATE * DeltaTime())
        end
        
        tracker.SetValue(mTransferProgress / 100)
        tracker.SetGoalLabel(math.floor(mTransferProgress) .. "%")
        
        if mTransferProgress >= 100 then
            break
        end
        
        
    end
    
    --TODO: consume a package
    trigger:Disable()
    _T.RemoveHudTracker(tracker)
    for i, point in ipairs(mControlPoints) do
        trigger:Disable()
    end
  
end

local mAvatar = nil
local mTouching = false

function OnTouched(trigger)
    if not IsNull(mAvatar) and not mAvatar:IsKilled() and trigger:IsTouching(mAvatar) then
        mTouching = true
    end
end

function OnUntouched(trigger)
    if not IsNull(mAvatar) and not trigger:IsTouching(mAvatar) then
        mTouching = false
        _T.HideImpactMessage()
    end
end

function ControlPoint(trigger)
    while not trigger:IsEnabled() do
        Sleep(1)
    end

    local player = gRegion:GetLocalPlayer()
    ObjectPortHandler(trigger, "OnTouched")
    ObjectPortHandler(trigger, "OnUntouched")
    local tracker = _T.AddHudTracker(trigger:GetFullName(), LOTUS_UTIL.HT_LABEL)
    tracker.SetLabel(tracker.Localize(controlPointIcon) .. " " .. math.floor(math.abs(trigger:GetCaptureProgress()) * 100) .. "%")
    
    while not IsNull(trigger) do
        if not IsNull(player) and (IsNull(mAvatar) or mAvatar:IsKilled()) then
            mAvatar = player:GetAvatar()
        end
    
        local positive = false
        local state = trigger:GetState()
        if state == Lotus_Game.TS_PLAYER_OWNED then
            
            positive = true
        end
        
        if mTouching then
            _T.ShowImpactMessage(math.floor(math.abs(trigger:GetCaptureProgress()) * 100) .. "%", -1, positive, nil, false)
        end
        
        if not trigger:IsEnabled() then
            break
        end
        
        tracker.SetLabel(tracker.Localize(controlPointIcon) .. " " .. math.floor(math.abs(trigger:GetCaptureProgress()) * 100) .. "%")
        Sleep(0)
    end
    
    _T.RemoveHudTracker(tracker)
    _T.HideImpactMessage()
end

