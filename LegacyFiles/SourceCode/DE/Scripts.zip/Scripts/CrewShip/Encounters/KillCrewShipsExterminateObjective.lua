majorKillGoals = { 5,  7,  9,  11} --kill goal = majorKillGoals[x] if maxSpaceLevel of mission <= spaceLevelThresholds[x]
spaceLevelThresholds = {15, 30, 45, 60 } --kill goal = majorKillGoals[x] if maxSpaceLevel of mission <= spaceLevelThresholds[x]
globalAlertLevelThresholds = { 0.25, 0.5 } --advance to next GAL level threshold

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
--local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local RAILOBJ = require "Lotus.Scripts.Libs.RailjackObjectiveUI"

local NV_MAJOR_KILL_COUNT = Symbol("NVMajorKillCount")
local SYM_TENNO = Symbol("TENNO")

local majorTargetsLoc = "/Lotus/Language/RailjackMissions/KillCrewshipsObjective"

local STARTED = 1
local COMPLETED = 10

local mHint = nil
local mAiDir = nil
local mModeMgr = nil
local mTransmissionSet = nil
local mMajorKillCount = 0 
local mMajorKillGoal = 0

local function UpdateUI()
    --mMajorKillsTracker.SetLabel(mMajorKillsTracker.Localize(majorTargetsLoc) .. " " .. math.min(mMajorKillCount, mMajorKillGoal) .. "/" .. mMajorKillGoal)
    local killCountText = " " .. math.min(mMajorKillCount, mMajorKillGoal) .. "/" .. mMajorKillGoal
    RAILOBJ.SetMainObjective(mHint, majorTargetsLoc, killCountText)
end

local function OnDeath(dd)
    if IsNull(mHint) or mHint:GetEncounterStatus() ~= Npc.ES_ACTIVE then
        return
    end

    if mMajorKillCount >= mMajorKillGoal then
        return
    end

    local victim = dd:GetVictim()
    if IsNull(victim) then
        return
    end

    if not victim:IsFactionOriginalFriendly(SYM_TENNO) then
        if victim:IsA(gCrewShipAvatarType) then
            mMajorKillCount = mMajorKillCount + 1
            DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("CrewshipDestroyed"))
            gGameRules:SetNetPersistentVar(NV_MAJOR_KILL_COUNT, mMajorKillCount)
            UpdateUI()
        end
    end
end

local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    if curState == STARTED then
    
    end
end

local function ShutDownKillCrewShipsExterminateObjective(hint)
    gGameRules:RemoveOnDeathCallback(OnDeath)
    gGameRules:SetNetPersistentVar(NV_MAJOR_KILL_COUNT, 0)
    --_T.RemoveHudTracker(mMajorKillsTracker)
    RAILOBJ.RemoveObjective(mHint, nil, true)
    --Sleep(3)
    --OBJTXT.RemoveObjProgressBar()
end

local function ShouldShutDown()
    local crewShipMgr = gGameRules:GetCrewShipManager()
    local ship = crewShipMgr:GetPlayerShip()
    local hintStatus = mHint:GetEncounterStatus() 

    if hintStatus >= Npc.ES_SUCCEEDED then
        return true
    end

    if not IsNull(ship) then
        local crewShipAvatar = ship:GetAvatarOwner()
        local hyperDriveState = crewShipAvatar:GetHyperDriveState()

        if hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_ACTIVE then
            return true
        end
    end
    
    return false
end

local function SetKillGoal()

    local maxSpaceLevel = mAiDir:GetSpaceMaxEnemyLevel()
    for i, int in ipairs(spaceLevelThresholds) do
        if maxSpaceLevel <= int then
            mMajorKillGoal = majorKillGoals[math.min(i, #majorKillGoals)]
            break
        end
    end
    
    _T.majorKillGoal = mMajorKillGoal
    
end

local function Initialize(hint)
    mHint = hint
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()
    
    gGameRules:RemoveOnDeathCallback(OnDeath)
    gGameRules:AddOnDeathCallback(OnDeath)

    local missionDebug = gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug")
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})

    local majorKillCount = gGameRules:GetNetPersistentVar(NV_MAJOR_KILL_COUNT, 0)
    mMajorKillCount = majorKillCount

    SetKillGoal()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    
    --mMajorKillGoal = UTIL.Ternary(missionDebug, 1, majorKillGoals[numPlayers])
    --mMajorKillsTracker = _T.AddHudTracker("MajorKills", LOTUS_UTIL.HT_LABEL)    
    -- mCheatTracker = _T.AddHudTracker("Cheat", LOTUS_UTIL.HT_LABEL)
    -- local textOpen = "<p><font face=\"Noto Sans\" color=\"#FF0000\">"
    -- local textClose = "</font></p>"
    -- mCheatTracker.SetLabel(textOpen .. "LotusGameRules.MissionDebug ENABLED" .. textClose)
    -- mCheatTracker.SetVisible(false)
    UpdateUI()

    local netState = mHint:GetEncounterDynamicState()
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))

    if hint:GetEncounterStatus() == Npc.ES_SETUP then
        hint:SetEncounterStatus(Npc.ES_ACTIVE)
    end
end

function KillCrewShipsExterminateObjective(hint)
    Initialize(hint)

    while not ShouldShutDown() do
        local goalRatio = mMajorKillCount / mMajorKillGoal
        local globalAlertLevel = mAiDir:GetGlobalAlertLevel()
        local newGlobalAlertLevel = globalAlertLevel
        
        for i, v in ipairs(globalAlertLevelThresholds) do
            if goalRatio >= v then
                --if i <= 2 or ( i > 2 and mHighLevelMission ) then --don't increase alert level past 2 if in low level mission
                    newGlobalAlertLevel = math.max(i, newGlobalAlertLevel)
                --end
            end
        end
        
        if ( newGlobalAlertLevel > globalAlertLevel ) then
            mAiDir:SetGlobalAlertLevel(newGlobalAlertLevel)
        end
        
        if goalRatio >= 1 and mModeMgr:GetModeState() ~= COMPLETED  then
            mAiDir:ModifyEncounterTagProbability(Symbol("CrewshipPatrol"), 0)
            RAILOBJ.RemoveObjective(mHint)
            mModeMgr:SetModeState(COMPLETED)
        end
        
        Sleep(0)
    end

    ShutDownKillCrewShipsExterminateObjective(hint)
end