crewshipAiSpec = Resource()
crewShipIntroTransmission = WeakResource()
transmissionSet = Resource()
hostageAgent = Resource()
crewShipType = Resource()
validSubObjectives = { WeakResource() }
numOfSubObjectives = 1

local QUERY = require "Lotus.Scripts.Libs.Query"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local GAMEMODE = require "Lotus.Scripts.Libs.CommonGamemodeFunctions"

local NV_RESCUE_CREWSHIP_HOSTAGE_STATE = Symbol("RESCUE_CREWSHIP_HOSTAGE_STATE")
local NV_RESCUE_MISSION_FAILED = Symbol("RescueMissionFailed")
local NV_SUB_OBJECTIVE_STATE = Symbol("SUB_OBJECTIVE_STATE")
local NV_NUM_OF_SUB_OBJECTIVES = Symbol("NUM_OF_SUB_OBJECTIVES")

local NOT_STARTED = 1
local STARTED = 2
local ENTERED = 3
local HOSTAGE_FOUND = 4
local ESCAPE = 5
local END = 6
local COMPLETE = 99
local mModeState = INVALID
local SetModeState 

local mSubObjectiveState = NOT_STARTED
local SetSubObjectivesState 

local UPDATE_INTERVAL = 0.1 -- How frequently we will tick 

local mHint = nil
local mAiSpec = nil
local mAiDir = nil
local mTemplate = nil
local mTransmissionSet = nil        
local ships = nil
local hostage = nil
local hostageSpawn = nil
local extractionMarker = nil
local crewshipMarker = nil
local extractionPos = nil
local activeExtractionTimer = false
local mActiveSubObjectiveHint = nil
local mCompleteSubObjectives = { }
local avatarsOnBoardShips = {}
local mEmplacementData = {}
local hostagePoints = {}
local mEnemyCrewShips = { }

--need hostage marker instead
local extractionMarkerType = Type("/Lotus/Types/Game/MarkerInfos/CrewShipExtractionMarkerInfoAlwaysInRange")
local rescueMarkerType = Type("/Lotus/Types/Game/MarkerInfos/RescueObjectiveMarkerInfo")
local areaMarkerType = Type("/Lotus/Types/Game/MarkerInfos/AreaMarker")
local crewShipEncounter = Type("/Lotus/Types/Gameplay/CrewShip/Encounters/GrineerCrewShipPatrolRescue")
local reinforcementsEncounter = Type("/Lotus/Types/Gameplay/CrewShip/Encounters/GrineerFighterReinforcements")
local fighterEncounter = Type("/Lotus/Types/Gameplay/CrewShip/Encounters/GrineerFighterPatrol")
local powersuitType = Type("/Lotus/Types/Game/PowerSuit")
local grnZeplen = Type("/Lotus/Types/Game/CrewShip/GrineerMissilePlatform/GrineerMissilePlatformNonEnterable")

local enemyFaction = Symbol("Grineer")
local sTenno = Symbol("TENNO")
local sHostageSpawnPoints = Symbol("DoNotUse")
local sPrisonConsole = Symbol("HostageFound")
local sCellMarkerType = Symbol("RescueCellObjectiveMarker")

local function ReturnWeaponToPlayer()
    local hostageAvatar = nil
    if not IsNull(hostage) then
        hostageAvatar = hostage:GetAvatar()
    end
        
    for i = 1, #mEnemyCrewShips do
        avatarsOnBoardShips = RJ_UTIL.GetPlayerAvatarsOnShip(mEnemyCrewShips[i])
    end
        
    if #avatarsOnBoardShips == 0 then
        avatarsOnBoardShips = gRegion:GetHumanPlayerAvatars()
    end
        
    local hostageInventoryController = hostageAvatar:InventoryControl()
        
    if not IsNull(avatarsOnBoardShips) then
        for i = 1, #avatarsOnBoardShips do
            local playerInventoryController = avatarsOnBoardShips[i]:InventoryControl()
            local player = avatarsOnBoardShips[i]:GetPlayer()
        
            -- Get current weapon owner
            if not _T.hostageWeaponPlayers then
                _T.hostageWeaponPlayers = {}
            end
            local hostageInstance = hostageAvatar:GetInstance()
            local weaponOwnerPlayer = _T.hostageWeaponPlayers[hostageInstance]
        
            if player == weaponOwnerPlayer then
                -- Give weapon back to owning player if we have one
                if not IsNull(weaponOwnerPlayer) then
                    local weaponOwnerAvatar = weaponOwnerPlayer:GetAvatar()
                    if not IsNull(weaponOwnerAvatar) then
                        local weaponOwnerInventory = weaponOwnerAvatar:InventoryControl()
                        if weaponOwnerInventory:WeaponDisabled(Engine.SLOT_1) then
                            weaponOwnerInventory:SetWeaponEnabled(Engine.SLOT_1)
                        end
                    end
                end
            end
            
            -- Remove weapons from hostage
            for i = Engine.SLOT_1, Engine.SLOT_9 do
                local item = hostageInventoryController:GetWeaponInSlot(i)
                if not IsNull(item) then
                    if not item:IsA(powersuitType) then
                        hostageInventoryController:RemoveItem(i, true)
                    end
                end
            end
        end
    end
end

local function BuildVisibilityQuery(center, targetPosition, minRange, maxRange, spacing)

    local query = mAiDir:EmptyTacQuery()
    query:SetDebugFilterId(Symbol("ship Visibility"), Color(255, 255, 0));
    local range = Range(minRange, maxRange)
    query:SetupGeneration(center, range, spacing)
    query:SetUseFlightNav(true)
    query:SetFlightClearance(5)
    query:SetResultCount(10)
    query:PreparePointScoreVars()
    query:AddOctreeGridGenerator()
    
    --local isVisible = false
    
    query:PrepareGeneratorSkipVars()
    --query:AddVisibilityFilter(center, 1.5, isVisible)

    
    query:AddOctreeRaycastScoring(targetPosition, 0, 1, 0)
    
    query:Start()
    while not query:IsFinished() do
        Sleep(0.1)
    end
    
    return query
end

local function ShouldShutDown()
    local crewShipMgr = gGameRules:GetCrewShipManager()
    local ship = crewShipMgr:GetPlayerShip()
    local crewShipAvatar = ship:GetAvatarOwner()
    local hyperDriveState = crewShipAvatar:GetHyperDriveState()

    if mModeState == COMPLETE or (hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_ACTIVE) then
        return true
    end

    return false
end

local function ShutDownCrewShipStateEncounter(hint)
    OBJTXT.ClearTitleObjText()
    OBJTXT.ClearPrimaryObjText()
    mAiDir:SetEnableAutoSpawns(false)
    gGameRules:SetNetPersistentVar(NV_RESCUE_CREWSHIP_HOSTAGE_STATE, NOT_STARTED)
end

local function PlayCrewShipPatrolIntro()
    gGameRules:GiveTransmissionAsyncToAllPlayers(crewShipIntroTransmission)
end

function HostageDied()
    --do what needs to be done for failure state
    Broadcast("RescueCrewshipHostageEncounter.lua -- Hostage is DEAD!! ;_;")
    
    if gRegion:IsMaster() then
        local AIDir = gRegion:GetNpcMgr():GetAiDirector()
        
        gGameRules:SetNetPersistentVar(NV_RESCUE_MISSION_FAILED, 1)
        gGameRules:SetNetPersistentVar(NV_RESCUE_CREWSHIP_HOSTAGE_STATE, 1)
        AIDir:SetEnableAutoSpawns(false)
        
        gGameRules:EndGame(Engine.GameRules_GS_FAILURE)
    end
end

function HostageFound(trigger)
    local sHostageCell = Symbol("CorrectConsole")
    
    if gRegion:IsMaster() then
        if not IsNull(trigger) then
            local triggerTag = trigger:GetTag()
            if triggerTag == sHostageCell then
                Broadcast("RescueCrewshipHostageEncounter.lua -- Hostage Global function -- Switch States!")
                trigger:Disable()
                
                gGameRules:SetNetPersistentVar(NV_RESCUE_CREWSHIP_HOSTAGE_STATE, HOSTAGE_FOUND)
                SetModeState(gGameRules:GetNetPersistentVar(NV_RESCUE_CREWSHIP_HOSTAGE_STATE, HOSTAGE_FOUND))
            else
                Broadcast("RescueCrewshipHostageEncounter.lua -- Hostage Global function -- Not Hostage Cell!")
                trigger:Disable()
            end
        end
    end
end

local function IncrementSubObjCount()
    local subObjCompletedCount = gGameRules:GetNetPersistentVar(NV_NUM_OF_SUB_OBJECTIVES, 0)
    local newCount = subObjCompletedCount + 1
    gGameRules:SetNetPersistentVar(NV_NUM_OF_SUB_OBJECTIVES, newCount)
end

local function ActivateRandomSubObjective()
    local randomEncIndex = RandomInt(1, #validSubObjectives)
    local encounterType = validSubObjectives[randomEncIndex]
    mActiveSubObjectiveHint = mAiDir:ActivateSpecificEncounterAtPos(ZERO_VECTOR, encounterType, nil, 0)
    if not IsNull(mActiveSubObjectiveHint) then
        table.remove(validSubObjectives, randomEncIndex)
        SetSubObjectivesState(STARTED)
    else
        --there's no available subobjectives so just start the main objective
        SetSubObjectivesState(COMPLETE)
    end 
end

local function OnModeStateChanged()
    if mModeState == NOT_STARTED then
        OBJTXT.SetTitleObjText("/Lotus/Language/Railjack/RescueCrewshipHostageTitle", nil, nil, OBJTXT.FONT_S)
    
    elseif mModeState == STARTED then

        PlayCrewShipPatrolIntro() --Patrol ship transmissions
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/RescueCrewshipHostage", 1)
        
        local spawnPoint = gRegion:FindFirstTagged(Symbol("RescueCrewshipWaypoint"))
        local spawnPointPos = spawnPoint:GetPosition()
        local crewShipMgr = gGameRules:GetCrewShipManager()
        local patrolPath = gRegion:FindFirstTagged(Symbol("RescueCrewshipPatrol"))
    
        while #mEnemyCrewShips == 0 do
            if not IsNull(crewShipType) then
                crewShipMgr:CreateCrewShipFromType(crewShipType, nil, false, true, "EnemyShipReady")
                Sleep(4)
            end
        end
        --Move the prison crewship to a POI
        local crewship = mEnemyCrewShips[1]:GetAvatarOwner()
        crewship:Teleport(spawnPointPos, ZERO_ROTATION)
        
        --Set up Objective marker for Crewship
        local crewshipAgent = crewship:GetAgent()
        local crewshipPos = crewship:GetPosition()
        crewshipMarker = gRegion:CreateEntity(areaMarkerType, crewshipPos, ZERO_ROTATION)
        crewshipMarker:AttachTo(crewship, Symbol("GAME_C1_DOORT"))
        crewshipMarker:Enable()
        
        --Set crewship to POI patrol route
        crewshipAgent:SetPatrolRoute(patrolPath)
        
        --mAiDir:ClearEncounters()
        
        --create a tacpos query for starting fighter spawns near the prison crewship
        --local gasDepotQuery = BuildVisibilityQuery(spawnPointPos, crewshipPos, 100, 600, 40)
        --local shipLocations = QUERY.GetPositions(10, gasDepotQuery)
        --local gasDepotSpawn = RandomInt(1, #shipLocations)
        
        mAiDir:SetAllowTeleportOldAgentsForNewSpawns(true)
        mAiDir:SetObjective(spawnPoint)
        mAiDir:OrderStragglersToObjective(100)
        
    elseif mModeState == ENTERED then
        --the crewship has been entered, spawn hostage and set up marker to lead player to them    
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/RescueCrewshipHostage", 1) 
        Broadcast("RescueCrewshipHostageEncounter.lua -- Entered the CrewShip!")
        
        for i = 1, #mEnemyCrewShips do
            hostagePoints = RJ_UTIL.FindTaggedOnShip(sHostageSpawnPoints, mEnemyCrewShips[i])
        end
        hostageSpawn = RandomInt(1, #hostagePoints)
        
        hostage = mAiDir:CreateAgent(hostageAgent, hostagePoints[hostageSpawn], sTenno, 25)
        
        local hostageMarker = gRegion:FindFirstTagged(Symbol("HostageMarker"))
        if not IsNull(hostageMarker) then
            hostageMarker:Disable()
        end
        
        --turn on only 2 hackable console markers
        local cellMarkers
        for i = 1, #mEnemyCrewShips do
            cellMarkers = RJ_UTIL.FindTaggedOnShip(sCellMarkerType, mEnemyCrewShips[i])
        end
        
        local activeCellMarkers = {}
        if not IsNull(cellMarkers) then
            while #activeCellMarkers < 2 do
                local randCell = RandomInt(1, #cellMarkers)
                
                table.insert(activeCellMarkers, cellMarkers[randCell])
                table.remove(cellMarkers, randCell)
            end
        
            for i, marker in ipairs(activeCellMarkers) do
                marker:Enable()
            end
        end
        
        --Find the objective marker of the hostage's cell to ensure its turned on
        if not IsNull(cellMarkers) then
            for i = 1, #cellMarkers do
                local distanceToHostage = cellMarkers[i]:Distance2DToEntity(hostagePoints[hostageSpawn])
                if distanceToHostage <= 5 then
                    cellMarkers[i]:Enable()
                end
            end
        end
        
        --Get the consoles so we can change the tag of the one blocking the hostage's cell 
        local consoles
        local hostageConsole = nil
        for i = 1, #mEnemyCrewShips do
            consoles = RJ_UTIL.FindTaggedOnShip(sPrisonConsole, mEnemyCrewShips[i])
        end
        
        if not IsNull(consoles) then
            for i = 1, #consoles do
                local distanceToHostage = consoles[i]:Distance2DToEntity(hostagePoints[hostageSpawn])
                if distanceToHostage <= 5 then
                    hostageConsole = consoles[i]
                end
            end
        end
        
        if not IsNull(hostageConsole) then
            hostageConsole:SetTag(Symbol("CorrectConsole"))
        end
        
    elseif mModeState == HOSTAGE_FOUND then
        --update objective stuff when hostage is found
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/ExtractCrewshipHostage", 1)
        Broadcast("RescueCrewshipHostageEncounter.lua -- Hostage Found!!")
        
        local hostageAvatar = nil
        if not IsNull(hostage) then
            hostageAvatar = hostage:GetAvatar()
        end
        
        --turn off any markers that might still be active
        local cellMarkers
        for i = 1, #mEnemyCrewShips do
            cellMarkers = RJ_UTIL.FindTaggedOnShip(sCellMarkerType, mEnemyCrewShips[i])
        end
        
        for i, marker in ipairs(cellMarkers) do
            marker:Disable()
        end
        
        OBJTXT.SetNpcHealthTracker(hostageAvatar)
        
    elseif mModeState == ESCAPE then
        local extractionPod = gRegion:FindFirstTagged(Symbol("RescueExtractionPod"))
        local fighterSpawn = gRegion:FindNearestTagged(Symbol("RescueFighterSpawn"), extractionPod:GetPosition())
        OBJTXT.SetNpcHealthTracker(extractionPod)
        
        mAiDir:DestroyInactiveAgents()
        
        --update to extraction marker
        local extractionBasePos = gRegion:FindFirstTagged(Symbol("RescueExtraction"))
        local extractionPoint = extractionBasePos:GetPosition()
        local extractionRot = ZERO_ROTATION
        local reinforcementsPos = fighterSpawn:GetPosition()
        extractionPos = extractionPoint
        
        extractionMarker = gRegion:CreateEntity(rescueMarkerType, extractionPoint, extractionRot)
        extractionMarker:Enable()
        extractionMarker:SetShowDistance(true)
        
        mAiDir:SetObjective(extractionPod)
        
        --create zeplyn at crewship location -- player has to destroy to proceed
        --local zeplen = mAiDir:CreateAgentNearEntity(grnZeplen, crewship, 550, enemyFaction)
        --local zeplen2 = mAiDir:CreateAgentNearEntity(grnZeplen, extractionBasePos, 500, enemyFaction)
        
        mAiDir:ActivateSpecificEncounterAtPos(reinforcementsPos, reinforcementsEncounter, mHint, 0)
        --mAiDir:ActivateSpecificEncounterAtPos(reinforcementsPos, reinforcementsEncounter, mHint, 0)
        
        mAiDir:OrderNpcsStormTarget(extractionPod, 250)
        --zeplen2:StormTarget(extractionPod, 250)
        mAiDir:OrderStragglersToObjective(100)
        mAiDir:SetAllowTeleportOldAgentsForNewSpawns(true)
        
    elseif mModeState == END then
        --we want the player to go back to the RJ to get the mission complete and allow the Hostage to take the crewship and port out
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/EndCrewshipHostage", 3)
        Broadcast("RescueCrewshipHostageEncounter.lua -- Return to the RJ so the Hostage can void jump!")
    elseif mModeState == COMPLETE then
        Broadcast("RescueCrewshipHostageEncounter.lua -- You win some REWARD!!!")
        OBJTXT.ClearPrimaryObjText()
        OBJTXT.ClearTitleObjText()
        OBJTXT.ClearNpcHealthTracker()
        
        mAiDir:ClearEncounters()
        mAiDir:SetAllowAutoEncounters(false)
        
        ReturnWeaponToPlayer()
        
        for i = 1, #mEnemyCrewShips do
            if not IsNull(mEnemyCrewShips[i]) then
                mEnemyCrewShips[i]:DestroyShip()
            end
        end
        
        if not IsNull(hostage) then
            local hostageAvatar = hostage:GetAvatar()
            hostageAvatar:Destroy()
            hostage:DestroyWhenPaused()
        end
        
        local extractionPod = gRegion:FindFirstTagged(Symbol("RescueExtractionPod"))
         
        if not IsNull(extractionPod) then
            extractionPod:Destroy()
        end

        mHint:SetEncounterStatus(Npc.ES_SUCCEEDED)
    end
end

local function OnSubObjectivesStateChanged()
    if mSubObjectiveState == NOT_STARTED then

    elseif mSubObjectiveState == STARTED then
        RJ_UTIL.SetAllCrewShipExitMarkers(false, nil)
        
        local capitalEntranceMarker = gRegion:FindFirstTagged(Symbol("CapitalShipEntranceMarker"))
        if not IsNull(capitalEntranceMarker) then
            capitalEntranceMarker:Disable()
        end

    elseif mSubObjectiveState == COMPLETE then
    
    end
end

local function Update(deltaTime)
    local modeState = gGameRules:GetNetPersistentVar(NV_RESCUE_CREWSHIP_HOSTAGE_STATE, NOT_STARTED)
    if modeState ~= mModeState then
        mModeState = modeState
        OnModeStateChanged(modeState)
    end
    
    local subObjState = gGameRules:GetNetPersistentVar(NV_SUB_OBJECTIVE_STATE, NOT_STARTED)
    if subObjState ~= mSubObjectiveState then
        mSubObjectiveState = subObjState
        OnSubObjectivesStateChanged(subObjState)
    end
    
    if mModeState == NOT_STARTED then
        if mSubObjectiveState == NOT_STARTED then
            if mActiveSubObjectiveHint == nil then
                --[[local capitalEntranceMarker = gRegion:FindFirstTagged(Symbol("CapitalShipEntranceMarker"))
                local railjackAvatar = gGameRules:GetCrewShipManager():GetPlayerShip()
                if not IsNull(railjackAvatar) then
                    railjackAvatar = railjackAvatar:GetAvatarOwner()
                end
                
                if not IsNull(railjackAvatar) and not IsNull(capitalEntranceMarker) then
                    local distance = railjackAvatar:DistanceToEntity(capitalEntranceMarker)
                    if distance < 2500 then]]--
                        ActivateRandomSubObjective()
                    --end
                --end
            end
        elseif mSubObjectiveState == STARTED then
            if not IsNull(mActiveSubObjectiveHint) then
                local encState = mActiveSubObjectiveHint:GetEncounterDynamicState()
                if encState == COMPLETE then --Confirm COMPLETE is the same across all subobjectives
                    IncrementSubObjCount()
                    local subObjCompletedCount = gGameRules:GetNetPersistentVar(NV_NUM_OF_SUB_OBJECTIVES, 0)
                    if subObjCompletedCount >= numOfSubObjectives then
                        SetSubObjectivesState(COMPLETE)
                    else
                        ActivateRandomSubObjective()
                    end
                end
            end
        elseif mSubObjectiveState == COMPLETE then
            SetModeState(STARTED)
        end
    elseif mModeState == STARTED then
        --Check if there are any players on a crewship so we can switch states
        for i = 1, #mEnemyCrewShips do
            avatarsOnBoardShips = RJ_UTIL.GetPlayerAvatarsOnShip(mEnemyCrewShips[i])
        end
        
        if not IsNull(avatarsOnBoardShips) then
            if #avatarsOnBoardShips > 0 then
                SetModeState(ENTERED)
            end
        end
    elseif mModeState == ENTERED then
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/RescueCrewshipHostage", 1)
        
    elseif mModeState == HOSTAGE_FOUND then
        --when we find the hostage and free them, we need to escape. Also need to update text to tell the player
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/ExtractCrewshipHostage", 1)
        
        for i = 1, #mEnemyCrewShips do
            avatarsOnBoardShips = RJ_UTIL.GetPlayerAvatarsOnShip(mEnemyCrewShips[i])
        end
        
         --Get the hostage marker and avatar so we can turn it on
        local hostageMarker = gRegion:FindFirstTagged(Symbol("HostageMarker"))
        local hostageAvatar = nil
        if not IsNull(hostage) then
            hostageAvatar = hostage:GetAvatar()
        end
        
        --If the player gets close to the hostage, turn on the marker
        for i = 1, #avatarsOnBoardShips do
            local distanceToHostage = avatarsOnBoardShips[i]:Distance2DToEntity(hostageAvatar)
            if distanceToHostage < 5 then
                hostageMarker:Enable()
            end
        end
        
        --mAiDir:OrderNpcsStormTarget(hostageAvatar, 50)
        
        local emplacements = {}
        local index = 0
        local emp
        for i = 1, #mEnemyCrewShips do
            emp = mEnemyCrewShips[i]:GetShipEmplacement(index)
        end
        
        while not IsNull(emp) do
            ObjectPortHandler(emp, "OnActivated")
            ObjectPortHandler(emp, "OnDismount")
            local data = 
            {
                user = emp:GetCurrUser(),
                emplacement = emp
            }
        
            mEmplacementData[index + 1] = data
            index = index + 1
            for i = 1, #mEnemyCrewShips do
                emp = mEnemyCrewShips[i]:GetShipEmplacement(index)
            end
        end
    
        for i = 1, #avatarsOnBoardShips do
            for i, data in ipairs (mEmplacementData) do
                local user = data.user
                if not IsNull(user) then
                    if avatarsOnBoardShips[i] == user then
                        hostageMarker:Disable()
                        SetModeState(ESCAPE)
                    end
                end
            end
        end
        
        --alternate case: If the player leaves the crewship prison (presumably to go back to their railjack) set mode to ESCAPE and teleport the hostage to RJ
        local hostageRJTeleport = gRegion:FindFirstTagged(Symbol("ShipEmplacement"))
        local hostageRJTeleportPos = hostageRJTeleport:GetPosition()
        
        if not IsNull(avatarsOnBoardShips) then
            if #avatarsOnBoardShips == 0 then
                hostageAvatar:Teleport(hostageRJTeleportPos, ZERO_ROTATION)
                SetModeState(ESCAPE)
            end
        end
        
    elseif mModeState == ESCAPE then
        crewshipMarker:Disable()
        --when we've escaped we need to complete the objective
        if not activeExtractionTimer then
            OBJTXT.SetObjTimer(150, false, true, false, 2)
        end
        activeExtractionTimer = true
        
        if activeExtractionTimer then
            if IsNull(OBJTXT.GetObjTimeTracker()) then
                extractionMarker:Destroy()
                SetModeState(END)
            end
        end
        
    elseif mModeState == END then
        -- stuff for getting back to the RJ - change state to COMPLETE
        local playersInInterior = RJ_UTIL.NumOfTennoOnRailjackShip()
        if not IsNull(playersInInterior) and playersInInterior > 0 then
            SetModeState(COMPLETE)
        end
    end
end

function EnemyShipReady(enemyShip)
    if not IsNull(enemyShip) then
        table.insert(mEnemyCrewShips, enemyShip)
    end
end

local function Initialize(hint)
    mHint = hint
    mTemplate = mHint:GetCurrentEncounterTemplate()
    mTransmissionSet = mTemplate:GetTransmissionSet()
    
    while _T.MissionInitReady ~= true do
        Sleep(10)
    end
    
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

     if not IsNull(gGameRules) then
        local mission = gGameRules:GetMission()
        mAiSpec = mission.enemySpec
        if IsNull(mAiSpec) then
            mAiSpec = crewshipAiSpec
            mission.enemySpec = crewshipAiSpec
            gGameRules:SetMission(mission)
            mAiDir:AssignMissionAISpec(mAiSpec)
        end
    end

    local levelInfo = gRegion:GetLevelInfo()
        
    SetModeState(gGameRules:GetNetPersistentVar(NV_RESCUE_CREWSHIP_HOSTAGE_STATE, NOT_STARTED))

    if mModeState == NOT_STARTED then
        --SetModeState(STARTED)
    elseif mModeState == STARTED then

    elseif mModeState == ENTERED then
    
    elseif mModeState == HOSTAGE_FOUND then
    
    elseif mModeState == ESCAPE then
    
    elseif mModeState == END then
    
    end
end

function CanActivateRescueHostageEncounter()
    -- check if the proc system placed the correct rooms/objects in thte node. If not return false

    return 1
end

SetModeState = function(newState)
    if mModeState ~= newState then
        mModeState = newState
        gGameRules:SetNetPersistentVar(NV_RESCUE_CREWSHIP_HOSTAGE_STATE, newState)
        OnModeStateChanged()
    else
        print("RescueCrewshipHostageEncounter.lua::SetModeState - trying to set mode to state we're already in")
    end
end

SetSubObjectivesState = function(newState)
    if mSubObjectiveState ~= newState then
        mSubObjectiveState = newState
        gGameRules:SetNetPersistentVar(NV_SUB_OBJECTIVE_STATE, newState)
        OnSubObjectivesStateChanged()
    else
        print("RescueCrewshipHostageEncounter.lua::SetSubObjectivesState - trying to set mode to state we're already in")
    end
end

function RescueCrewshipHostage(hint)

    Broadcast("RescueCrewshipHostageEncounter.lua -- Rescue Hostage Objective Started")
    Initialize(hint)

    local sleepTime = UPDATE_INTERVAL

    while not ShouldShutDown() do
        Update(sleepTime)
        Sleep(sleepTime)
    end
    
    ShutDownCrewShipStateEncounter(hint)
    
end

