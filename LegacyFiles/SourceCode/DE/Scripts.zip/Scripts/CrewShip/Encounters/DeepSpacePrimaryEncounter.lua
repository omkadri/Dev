local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local PANIC = require "Lotus.Scripts.Libs.PanicLib"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local TABLE = require "Lotus.Scripts.Libs.TableLib"
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local encounterHintType = WeakResource("/EE/Types/Npc/Encounters/DeepSpaceEncounterHint")
local navBeaconPilotEncounterType = Type("/Lotus/Types/Gameplay/CrewShip/Encounters/DeepSpaceNavPilotKillObjective")

local objectiveLoc = "[HC] DEEP SPACE"
local navCoordinatesLoc = "[HC] NAV COORDINATES ACQUIRED: "

local INVALID = 0
local STARTED = 1
local mModeState = INVALID

local mHint = nil
local mAiSpec = nil
local mAiDir = nil
local mModeMgr = nil
local mTemplate = nil
local mTransmissionSet = nil

local mDeepSpaceEncounterHints = {}

local mNavCoordinatesTracker = nil
local mNavCoordinateCurrent = 0
local mNavCoordinateMax = 4

local sCrewShipHint = Symbol("GrineerCrewShipPatrolEncounterHint")
local navCoordinateAcquiredLoc = "[HC] NAV COORDINATE ACQUIRED "

local impactMessageSound = WeakResource("/Lotus/Sounds/Levels/Missions/Defense/DefenseWaveCleared")

local NV_RJ_DEEPSPACE_NAVCOORDINATE_COUNT = Symbol("RJ_DEEPSPACE_NAVCOORDINATE_COUNT")

local function ShutDownDeepSpaceEncounter(hint)
    mAiDir:SetAllowAutoEncounters(false)
    OBJTXT.RemoveObjProgressBar()
    OBJTXT.ClearPrimaryObjText()
    _T.RemoveHudTracker(mNavCoordinatesTracker)
    
    if hint:GetEncounterStatus() < Npc.ES_SUCCEEDED then
        gGameRules:SetNetPersistentVar(NV_RJ_DEEPSPACE_NAVCOORDINATE_COUNT, 0)
        gGameRules:EndGame(Engine.GameRules_GS_FAILURE)
    end
end

function EncounterHintStatusChanged(hint)
    if hint:GetEncounterStatus() == Npc.ES_SUCCEEDED then
        mNavCoordinateCurrent = mNavCoordinateCurrent + 1
        gGameRules:SetNetPersistentVar(NV_RJ_DEEPSPACE_NAVCOORDINATE_COUNT, mNavCoordinateCurrent)
        
        Sleep(0)
        
        local players = gRegion:GetHumanPlayers()
        for i=1, #players do
            gGameRules:DisplayMessage(players[i], navCoordinateAcquiredLoc, "", 0, 4.0, true,"","",impactMessageSound)
        end
    end
end

local function UpdateUI()
    mNavCoordinatesTracker.SetLabel(mNavCoordinatesTracker.Localize(navCoordinatesLoc) .. math.min(mNavCoordinateCurrent, mNavCoordinateMax) .. "/" .. mNavCoordinateMax)
end

local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    if curState == STARTED then
        
    end
end

local function Initialize(hint)
    mHint = hint
    mTemplate = mHint:GetCurrentEncounterTemplate()
    mTransmissionSet = mTemplate:GetTransmissionSet()
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    local crewShipMgr = gGameRules:GetCrewShipManager()

    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})
    
    -- Get Nav Coordinate Counts
    local missionInfo = gGameRules:GetMission()
    --mNavCoordinateMax = missionInfo.maxWaveNum
    
    mNavCoordinateCurrent = gGameRules:GetNetPersistentVar(NV_RJ_DEEPSPACE_NAVCOORDINATE_COUNT, 0)

    -- Get a list of random Deep Space encounters  
    local allDeepSpaceEncounterHints = gRegion:FindAll(encounterHintType)
    if IsNull(allDeepSpaceEncounterHints) or #allDeepSpaceEncounterHints == 0 then
        return 0
    end

    local count = mNavCoordinateMax - 1
    while count > 0 and #allDeepSpaceEncounterHints > 0 do
        local index = SRandomInt(1, #allDeepSpaceEncounterHints)
        local hint = allDeepSpaceEncounterHints[index]
        
        if not IsNull(hint) then
            hint:RegisterStatusChangedCallback("EncounterHintStatusChanged", Symbol("EncounterHintCallback"))
            local enc = mAiDir:ActivateRandomEncounterAtSpecificHint(hint, 0, 0)
            table.insert(mDeepSpaceEncounterHints, hint)
            table.remove(allDeepSpaceEncounterHints, index)
            count = count - 1
        else        
            table.remove(allDeepSpaceEncounterHints, index)
        end
    end
    
    if #mDeepSpaceEncounterHints < mNavCoordinateMax then
        -- Search for Crew Ship encounters to populate list
        -- Potentially add any more dynamic encounters that can fit a nav coordinate
        local crewShipHints = gRegion:FindTagged(sCrewShipHint)

        count = #mDeepSpaceEncounterHints
        while count < mNavCoordinateMax and #crewShipHints > 0 do
            local index = SRandomInt(1, #crewShipHints)
            local hint = crewShipHints[index]
            
            if not IsNull(hint) then
                hint:RegisterStatusChangedCallback("EncounterHintStatusChanged", Symbol("EncounterHintCallback"))
                mAiDir:PrimeMissionOnHintWithType(navBeaconPilotEncounterType, hint)
                
                --local enc = mAiDir:ActivateRandomEncounterAtSpecificHint(hint, 0, 0)
                table.insert(mDeepSpaceEncounterHints, hint)
                table.remove(crewShipHints, index)
                count = count + 1
            else        
                table.remove(crewShipHints, index)
            end
        end
        
        mNavCoordinateMax = #mDeepSpaceEncounterHints
    end  
    
    OBJTXT.SetPrimaryObjText(objectiveLoc)
    mNavCoordinatesTracker = _T.AddHudTracker("NavCoordinates", LOTUS_UTIL.HT_LABEL)
    UpdateUI()

    local netState = mHint:GetEncounterDynamicState()
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))

    if hint:GetEncounterStatus() == Npc.ES_SETUP then
        hint:SetEncounterStatus(Npc.ES_ACTIVE)
    end
end

function DeepSpaceObjective(hint)
    Initialize(hint)
    
    Sleep(0)

    local mNavCoordinateCurrent = gGameRules:GetNetPersistentVar(NV_RJ_DEEPSPACE_NAVCOORDINATE_COUNT, 0)
    while mNavCoordinateCurrent < mNavCoordinateMax do
        mNavCoordinateCurrent = gGameRules:GetNetPersistentVar(NV_RJ_DEEPSPACE_NAVCOORDINATE_COUNT, 0)
        UpdateUI()   
        
        Sleep(0)
    end
    
    Sleep(3)
    
    if mNavCoordinateCurrent >= mNavCoordinateMax then
        hint:SetEncounterStatus(Npc.ES_SUCCEEDED)
    end
    
    Sleep(0)
    
    ShutDownDeepSpaceEncounter(hint)
end