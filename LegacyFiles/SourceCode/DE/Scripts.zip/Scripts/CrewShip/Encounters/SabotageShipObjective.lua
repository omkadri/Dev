capitalShipAiSpec = Resource()
interiorShipRegionIndex = 1

transmissionSet = Resource()
enemyFaction = Symbol("Grineer")

shipCoreTag = Symbol("RJMissilePlatformCore")
missilePlatformHintWRes = WeakResource()
crewshipObjectiveMarkerWRes = WeakResource()

enterShipMarkerWRes = WeakResource()

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local PANIC = require "Lotus.Scripts.Libs.PanicLib"

local NV_RJ_SABOTAGE_SHIP_STATE = Symbol("RJ_SABOTAGE_SHIP_STATE")

local NOT_STARTED = 1
local STARTED = 3
local COMPLETE = 4
local mModeState = INVALID
local SetModeState

local SHIP_STARTED = 1
local SHIP_CORE_DESTROYED = 2

local UPDATE_INTERVAL = 0.1 -- How frequently we will tick 

local mHint = nil
local mAiSpec = nil
local mAiDir = nil

local mPotentialShipHints = nil
local mActiveShipHint = nil
local mCrewShip = nil
local mTemplate = nil
local mTransmissionSet = nil

function NPCAlertStart(npc)
    PANIC.SetPanicLevel(PANIC.ALERT)
end

function NPCAlertEnd(npc)
    PANIC.SetPanicLevel(PANIC.UNALERT) 
end

local function ShouldShutDown()
    local crewShipMgr = gGameRules:GetCrewShipManager()
    local ship = crewShipMgr:GetPlayerShip()
    local crewShipAvatar = ship:GetAvatarOwner()
    local hyperDriveState = crewShipAvatar:GetHyperDriveState()

    if mModeState == COMPLETE or (hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_ACTIVE) then
        return true
    end

    return false
end

local function ActivateShip()
    if not IsNull(mCrewShip) then
        RJ_UTIL.SetAllCrewShipExitMarkers(true, { mCrewShip })
        RJ_UTIL.SetCrewShipEnterMarker(true, mCrewShip)

        local coreDeco = RJ_UTIL.FindFirstTaggedOnShip(shipCoreTag, mCrewShip)

        if not IsNull(coreDeco) then
            local coreMarker = coreDeco:GetAttachment(crewshipObjectiveMarkerWRes)

            if not IsNull(coreMarker) and not coreMarker:IsEnabled() then
                coreMarker:Enable()
            end
        end
    end
end

local function SelectShip()
    
    while mActiveShipHint == nil do
        local randIndex = RandomInt(1, #mPotentialShipHints) --net serialize this for migration.
        local platform = mPotentialShipHints[randIndex]
        local platformState = platform:GetEncounterDynamicState()

        if platformState >= SHIP_STARTED and platformState < SHIP_CORE_DESTROYED then
            mActiveShipHint = platform
            
            local registeredAgents = mActiveShipHint:GetRegisteredAgents()

            for i=1,#registeredAgents do
                local agent = registeredAgents[i]
                local avatar = agent:GetAvatar()

                if not IsNull(avatar) and avatar:IsA(gCrewShipAvatarType) then
                    mCrewShip = avatar:InventoryControl():GetActivePowerSuit()
                end
            end
        end
        
        Sleep(0)
    end
end

local function ShutDownSabotageShipObjective(hint)
    --Destroy crewships
    --set net variables back to 0.
    mAiDir:SetEnableAutoSpawns(false)
    gGameRules:SetNetPersistentVar(NV_RJ_SABOTAGE_SHIP_STATE, 1)
end

function ShipEntered()
    --gGameRules:GiveTransmissionAsyncToAllPlayers(crewShipIntroTransmission)
end

local function PlaySabotageShipIntro()
    --gGameRules:GiveTransmissionAsyncToAllPlayers(crewShipIntroTransmission)
end

local function OnModeStateChanged()
    if mModeState == STARTED then
        SelectShip()
        ActivateShip()
        PlaySabotageShipIntro() --Patrol ship transmissions
        OBJTXT.SetTitleObjText("/Lotus/Language/Railjack/SabotageTheShip", nil, nil, OBJTXT.FONT_S)
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/EnterTheShip", 1)
        mAiDir:SetAllowTeleportOldAgentsForNewSpawns(false)
    elseif mModeState == COMPLETE then
        RJ_UTIL.SetAllCrewShipExitMarkers(false, nil)
        RJ_UTIL.SetCrewShipEnterMarker(false, mCrewShip)
    end
end

local function Initialize(hint)
    mHint = hint
    mTemplate = mHint:GetCurrentEncounterTemplate()
    mTransmissionSet = mTemplate:GetTransmissionSet()
    mPotentialShipHints = gRegion:FindAll(missilePlatformHintWRes)

    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    if not IsNull(gGameRules) then
        --mAiSpec = capitalShipAiSpec
        local mission = gGameRules:GetMission()
        mAiSpec = mission.enemySpec
        if IsNull(mAiSpec) then
            mAiSpec = capitalShipAiSpec
            mission.enemySpec = capitalShipAiSpec
            gGameRules:SetMission(mission)
            mAiDir:AssignMissionAISpec(mAiSpec)
        end
    end

    local levelInfo = gRegion:GetLevelInfo()
    ObjectPortHandler(levelInfo, "NPCAlertStart")
    ObjectPortHandler(levelInfo, "NPCAlertEnd")
    --ObjectPortHandler(panelForwarder, "OnActivated")

    SetModeState(gGameRules:GetNetPersistentVar(NV_RJ_SABOTAGE_SHIP_STATE, NOT_STARTED))

    if mModeState == NOT_STARTED then
        SetModeState(STARTED)
    elseif mModeState >= STARTED then
        --there must be an enc hint that we previously monitored, find that one.
    end
end

local function Update(deltaTime)
    local modeState = gGameRules:GetNetPersistentVar(NV_RJ_SABOTAGE_SHIP_STATE, NOT_STARTED)
    if modeState ~= mModeState then
        mModeState = modeState
        OnModeStateChanged(modeState)
    end

    if mModeState == STARTED then
        if not IsNull(mActiveShipHint) then
            local shipHintState = mActiveShipHint:GetEncounterDynamicState()
            if shipHintState == SHIP_CORE_DESTROYED then 
                SetModeState(COMPLETE)
            end
        end
    elseif mModeState == COMPLETE then
        --increment railjackmanagernetvar to move onto the next mission.
    end
end

SetModeState = function(newState)
    if mModeState ~= newState then
        mModeState = newState
        gGameRules:SetNetPersistentVar(NV_RJ_SABOTAGE_SHIP_STATE, newState)
        OnModeStateChanged()
    else
        print("SabotageShipObjective.lua::SetModeState - trying to set mode to state we're already in")
    end
end

function CanActivateSabotageShipEncounter()
    -- check if the proc system placed the correct rooms/objects in thte node. If not return false

    local shipHints = gRegion:FindAll(missilePlatformHintWRes)

    for i=1, #shipHints do
        local shipHint = shipHints[i]
        local shipHintState = shipHint:GetEncounterDynamicState()
        if shipHintState >= SHIP_STARTED and shipHintState < SHIP_CORE_DESTROYED then
            return 1
        end
    end

    print("SabotageShipObjective.lua::CanActivate - couldn't find any sabotage ships in the level")
    return 0
end

function SabotageShipObjective(hint)

    Broadcast("SabotageShipObjective.lua -- Sabotage Ship Objective Started")
    Initialize(hint)

    local sleepTime = UPDATE_INTERVAL

    while not ShouldShutDown() do
        Update(sleepTime)
        Sleep(sleepTime)
    end

    ShutDownSabotageShipObjective(hint)
end