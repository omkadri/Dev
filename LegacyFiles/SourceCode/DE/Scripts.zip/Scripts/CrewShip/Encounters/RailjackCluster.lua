capitalShipAiSpec = Resource()
transmissionSet = Resource()

fighterPatrolHintType = Type()
crewShipPatrolHintType = Type()

crewShipHintActivationChance = 0.5
maxHintsToActivate = 1
numOfActivationAttempts = 10

firstFighterReinforcementDelay = 10
fighterReinforcementDelay = 30

reinforcementEncounterActivationedLimit = 3
minNumAgentsInCluster = 3
maxNumAgentsInCluster = 12

reinforceWaypointTag = Symbol("Reinforcement")

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local PANIC = require "Lotus.Scripts.Libs.PanicLib"
local UTIL = require "EE.Interface.Utilities"

local NV_RJ_CLUSTER_STATE = Symbol("RJ_CLUSTER_STATE")

local sPatrolTag = Symbol("Patrol")
local sReinforcementTag = Symbol("Reinforcement") 
local sGrineerFaction = Symbol("Grineer")
local sFighterPatrolTag = Symbol("FighterPatrol")
local sCrewshipPatrolTag = Symbol("CrewshipPatrol")
local sEnemyReinforcementTag = Symbol("ReinforcementFighter")
--local sPausedSymb = Symbol("CrewShipPaused")

local NOT_STARTED = 1
local STARTED = 2
local COMPLETE = 3

local UPDATE_INTERVAL = 0.1 -- How frequently we will tick 

local mHint = nil
local mAiSpec = nil
local mModeMgr = nil
local mAiDir = nil
local mReinforceMgr = nil
local mInitialPatrolCreated = false
local mIsInCombat = false
local mInitialReinforcement = true
local mNumOfReinforcementEncountersActivated = 0

local mActiveShipHints = nil
local mTemplate = nil
local mTransmissionSet = nil

local mNumOfActivatedCrewShipHints = 0
local mNumOfActivatedFighterHints = 0

function NPCAlertStart(npc)
    PANIC.SetPanicLevel(PANIC.ALERT)
end

function NPCAlertEnd(npc)
    PANIC.SetPanicLevel(PANIC.UNALERT) 
end

-- function OnKilled(avatar)
--     if not IsNull(avatar) and avatar:IsA(gCrewShipAvatarType) then
--         for i=1,#mCrewShipAvatars do
--             if mCrewShipAvatars[i] == avatar then
--                 table.remove(mCrewShipAvatars, i)
--                 break
--             end
--         end
--     else
--         local found = false
--         for i=1,#mFighterAvatars do
--             if mFighterAvatars[i] == avatar then
--                 found = true
--                 table.remove(mFighterAvatars, i)
--                 break
--             end
--         end

--         if found == false then
--             for i=1,#mReinforcementFighterAvatars do
--                 if mReinforcementFighterAvatars[i] == avatar then
--                     found = true
--                     table.remove(mReinforcementFighterAvatars, i)
--                     break
--                 end
--             end
--         end
--     end 
-- end

-- function ClusterHintChanged(hint)
--     if not IsNull(hint) then
--         local state = hint:GetEncounterStatus()
--         if state == Npc.ES_SHUTDOWN or state == Npc.ES_COMPLETE then
--             for i=1,#mActivatedCrewShipsHints do
--                 if IsNull(mActivatedCrewShipsHints[i]) or mActivatedCrewShipsHints[i] == hint then
--                     table.remove(mActivatedCrewShipsHints, i)
--                     return
--                 end
--             end

--             for i=1,#mActivatedFighterHints do
--                 if IsNull(mActivatedFighterHints[i]) or mActivatedFighterHints[i] == hint then
--                     table.remove(mActivatedFighterHints, i)
--                     return
--                 end
--             end
--         end
--     end
-- end

-- function OnAgentRegistered(agent)
--     local avatar = agent:GetAvatar()
--     ObjectPortHandler(avatar, "OnKilled")
--     mHint:RegisterAgent(agent)

--     if not IsNull(avatar) and avatar:IsA(gCrewShipAvatarType) then
--         table.insert(mCrewShipAvatars, avatar)
--     else
--         table.insert(mFighterAvatars, avatar)
--     end
-- end

local function IsPlayerOnCrewship(agent)
    --always return true if there is a player on the crewship
    if not IsNull(agent) then
        local avatar = agent:GetAvatar()
        if not IsNull(avatar) and avatar:IsA(gCrewShipAvatarType) then
            local playersOnShip = RJ_UTIL.GetPlayerAvatarsOnShip(avatar:InventoryControl():GetActivePowerSuit())
            if not IsNull(playersOnShip) and #playersOnShip > 0 then
                return true
            end
        end
    end
    
    return false
end

local function ShouldShutDown()
    local crewShipMgr = gGameRules:GetCrewShipManager()
    local ship = crewShipMgr:GetPlayerShip()
    local crewShipAvatar = ship:GetAvatarOwner()
    local hyperDriveState = crewShipAvatar:GetHyperDriveState()
    local curState = mModeMgr:GetModeState()
    local hintStatus = mHint:GetEncounterStatus()

    if curState == COMPLETE or hintStatus > Npc.ES_ACTIVE or (hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_ACTIVE) then
        return true
    end

    return false
end

local function ActivateHints()
    local spawnRadius = mHint:GetSpawnRadius()
    local activationAttempts = 0
    local crewshipPatrolHints = gRegion:FindAll(crewShipPatrolHintType, mHint:GetPosition(), 0, spawnRadius) 
    local fighterPatrolHints = gRegion:FindAll(fighterPatrolHintType, mHint:GetPosition(), 0, spawnRadius)

    local numOfHintsToActivate = maxHintsToActivate
    math.randomseed( os.time() )

    local numOfCrewShipHints = #crewshipPatrolHints
    local numOfFighterHints = #fighterPatrolHints

    local numOfCrewShipsHintsToActivate = 0
    local numOfFighterHintsToActivate = 0

    while numOfHintsToActivate > 0 do
        if math.random() < crewShipHintActivationChance then
            numOfCrewShipsHintsToActivate = numOfCrewShipsHintsToActivate + 1
        else
            numOfFighterHintsToActivate = numOfFighterHintsToActivate + 1
        end

        numOfHintsToActivate = numOfHintsToActivate - 1
    end

    while (mNumOfActivatedCrewShipHints < numOfCrewShipsHintsToActivate) and activationAttempts <= numOfActivationAttempts do
        local randomIndex = RandomInt(1, #crewshipPatrolHints)
        local selectedHint = crewshipPatrolHints[randomIndex]
        
        local ent = mAiDir:ActivateRandomEncounterAtSpecificHint(selectedHint, { sPatrolTag }, Npc.ET_NONE, Npc.ET_STRONG_POINT, mHint)
        --ent:RegisterOnAgentRegisteredCallback("OnAgentRegistered", Symbol("CrewShipHintCreated" .. String(ent:GetInstance())))
        --ent:RegisterStatusChangedCallback("ClusterHintChanged", Symbol("CrewShipHint" .. String(ent:GetInstance()) .. "Changed"))
        if not IsNull(ent) then
            mNumOfActivatedCrewShipHints = mNumOfActivatedCrewShipHints + 1
            table.remove(crewshipPatrolHints, randomIndex)
        else
            activationAttempts = activationAttempts + 1
        end

        Sleep(0)
    end

    activationAttempts = 0
    while (mNumOfActivatedFighterHints < numOfFighterHintsToActivate) and activationAttempts <= numOfActivationAttempts do
        local randomIndex = RandomInt(1, #fighterPatrolHints)
        local selectedHint = fighterPatrolHints[randomIndex]
        
        local ent = mAiDir:ActivateRandomEncounterAtSpecificHint(selectedHint, { sPatrolTag }, Npc.ET_NONE, Npc.ET_STRONG_POINT, mHint)
        --ent:RegisterOnAgentRegisteredCallback("OnAgentRegistered", Symbol("FighterHintCreated" .. String(ent:GetInstance())))
        --ent:RegisterStatusChangedCallback("ClusterHintChanged", Symbol("FighterHint" .. String(ent:GetInstance()) .. "Changed"))
        if not IsNull(ent) then
            mNumOfActivatedFighterHints = mNumOfActivatedFighterHints + 1
            table.remove(fighterPatrolHints, randomIndex)
        else
            activationAttempts = activationAttempts + 1
        end

        Sleep(0)
    end
end

local function ShutDownRailjackCluster(hint)
    local curState = mModeMgr:GetModeState()
    if curState == STARTED then
        local agents = hint:GetRegisteredAgents()
        if not IsNull(agents) then
            for i = 1, #agents do
                if agents[i]:GetAvatar():IsA(gCrewShipAvatarType) then
                    hint:DeregisterAgent(agents[i])
                    if not IsPlayerOnCrewship(agents[i]) then
                        agents[i]:GetAvatar():SetAgentPaused(true)
                    end
                elseif not IsNull(agents[i]) and not IsNull(agents[i]:GetAvatar()) then
                    print("RailjackPatrol.lua - Destroying " .. agents[i]:GetAvatar():GetFullName())
                    agents[i]:GetAvatar():Destroy()
                    Sleep(0.1)
                end
            end
        end
        Broadcast("Patrol Shutdown @" .. hint:GetName())
        hint:SetEncounterStatus(Npc.ES_SHUTDOWN)
    elseif curState == COMPLETE then
        hint:SetEncounterStatus(Npc.ES_COMPLETE)
    end

    mModeMgr:ShutDown()
end

local function PlayerChatter()
    --gGameRules:GiveTransmissionAsyncToAllPlayers(crewShipIntroTransmission)
end

local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    if curState == STARTED then
        ActivateHints()
        mAiDir:SetAllowTeleportOldAgentsForNewSpawns(false)
    elseif curState == COMPLETE then

    end
end

local function Initialize(hint)
    mHint = hint
    mTemplate = mHint:GetCurrentEncounterTemplate()
    mTransmissionSet = mTemplate:GetTransmissionSet()
    --mPotentialShipHints = gRegion:FindAll(missilePlatformHintWRes)

    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {NV_RJ_CLUSTER_STATE})
    mReinforceMgr = LANDSCAPE.CreateReinforcementMgr(mAiDir, hint)
    
    -- local agentRegistered = function(agent)
    --     local avatar = agent:GetAvatar()
    --     ObjectPortHandler(avatar, "OnKilled")

    --     if not IsNull(avatar) and avatar:IsA(gCrewShipAvatarType) then
    --         table.insert(mCrewShipAvatars, avatar)
    --     else
    --         table.insert(mReinforcementFighterAvatars, avatar)
    --         mNumOfReinforcementAvatarsCreated = mNumOfReinforcementAvatarsCreated + 1
    --     end
    -- end
    
    mReinforceMgr.mActivationStyle = LANDSCAPE.AS_RANDOM
    mReinforceMgr.mSpecificActivationHint = nil
    mReinforceMgr.mActivationPosStyle = LANDSCAPE.APS_SPECIFIC_POS_WITH_TAGS
    mReinforceMgr.mRandomActivationFaction = sGrineerFaction
    mReinforceMgr.mSpecificRequiredTags = { sReinforcementTag }
    mReinforceMgr.mReinforceDelay = fighterReinforcementDelay
    -- mReinforceMgr.mRegisteredAgentCallback = agentRegistered
    -- mReinforceMgr.mRegisteredAgentCallbackId = String("ClusterReinforcementHint")
    mReinforceMgr.ShouldReinforce = function(this, numPlayers)
        local delay = this.mReinforceDelay
        local isObjectiveComplete = mAiDir:GetObjectiveComplete()
        local numOfAgents = mHint:GetNumRegisteredAgents()
        if mInitialReinforcement == true then
            delay = firstFighterReinforcementDelay
        end
        
        --if this.mRapid then
            --delay = this.mRapidReinforceDelay
        --end

        if mIsInCombat and isObjectiveComplete == false and
            ((((numOfAgents - mNumOfActivatedCrewShipHints) < maxNumAgentsInCluster) and this.mTimeSinceLastReinforcement > delay) or
            ((numOfAgents - mNumOfActivatedFighterHints) < minNumAgentsInCluster)) and mNumOfReinforcementEncountersActivated < reinforcementEncounterActivationedLimit then --check agent counts
            local activationRadius = mHint:GetActivationRadius()

            local waypoints = gRegion:FindTaggedInRadius(reinforceWaypointTag, mHint:GetPosition(), 0, activationRadius)    

            if not IsNull(waypoints) and #waypoints > 0 then
                local randomIndex = RandomInt(1, #waypoints)
                local waypoint = waypoints[randomIndex]

                this.mActivationPos = waypoint:GetPosition()

                if mInitialReinforcement == true then
                    mInitialReinforcement = false
                end

                mNumOfReinforcementEncountersActivated = mNumOfReinforcementEncountersActivated + 1

                return true
            end
        elseif mIsInCombat == false and this.mTimeSinceLastReinforcement > 0 then
            this.mTimeSinceLastReinforcement = 0
        end
        
        return false
    end

    if not IsNull(gGameRules) then
        mAiSpec = capitalShipAiSpec
        local mission = gGameRules:GetMission()
        mAiSpec = mission.enemySpec
        if IsNull(mAiSpec) then
            mAiSpec = capitalShipAiSpec
            mission.enemySpec = capitalShipAiSpec
            gGameRules:SetMission(mission)
            mAiDir:AssignMissionAISpec(mAiSpec)

            local npcEncounters = mAiSpec:GetNpcEncounters()
            for i=1, #npcEncounters do
                mAiDir:AddEncounter(Type(npcEncounters[i]))
            end
        end
    end

    local levelInfo = gRegion:GetLevelInfo()
    ObjectPortHandler(levelInfo, "NPCAlertStart")
    ObjectPortHandler(levelInfo, "NPCAlertEnd")
    --ObjectPortHandler(panelForwarder, "OnActivated")
    local netState = mHint:GetEncounterDynamicState()

    if netState > 0 then
        local agents = mHint:GetRegisteredAgents()
        local numOfFighters = 0
        local numOfReinforcementFighters = 0 
        for i=1, #agents do
            local agent = agents[i]
            local avatar = agent:GetAvatar()

            if not IsNull(agent) then
                if agent:IsA(gCrewShipAvatarType) then
                    mNumOfActivatedCrewShipHints = mNumOfActivatedCrewShipHints + 1
                elseif avatar:HasTag(sEnemyReinforcementTag) then
                    numOfReinforcementFighters = numOfReinforcementFighters + 1
                else
                    numOfFighters = numOfFighters + 1
                end
            end
        end

        if numOfFighters > 0 then
            mNumOfActivatedFighterHints = UTIL.Round(numOfFighters / 2)
        end

        if numOfReinforcementFighters > 0 then
            mNumOfReinforcementEncountersActivated = UTIL.Round(numOfReinforcementFighters / 2)
        end

        if #agents > 0 then
            mInitialPatrolCreated = true
        end
    end
    
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))
end

local function Update(deltaTime)
    local curState = mModeMgr:GetModeState()
    local agents = mHint:GetRegisteredAgents()
    local isObjectiveComplete = mAiDir:GetObjectiveComplete()

    if curState == STARTED then

        if mInitialPatrolCreated == false and #agents > 0 then
            mInitialPatrolCreated = true
        end

        if mInitialPatrolCreated == true and (#agents == 0 or IsNull(agents)) and (mNumOfActivatedCrewShipHints > 0 or mNumOfActivatedFighterHints > 0) then
            mModeMgr:SetModeState(COMPLETE)
        end

        local wasInCombat = mIsInCombat

        for i=1, #agents do
            local agent = agents[i]

            if not IsNull(agent) and agent:IsCombatAwareness() then
                --Maybe check the agent's target?
                mIsInCombat = true
                break
            end
        end

        if wasInCombat == mIsInCombat then
            for i=1, #agents do
                local agent = agents[i]

                if not IsNull(agent) and agent:IsCombatAwareness() then
                    --Maybe check the agent's target?
                    mIsInCombat = true
                    break
                end

                if i == #agents and mIsInCombat == true and wasInCombat == true then
                    mIsInCombat = false
                end
            end
        end

        if not IsNull(mReinforceMgr) and mIsInCombat == true and isObjectiveComplete == false then
            mReinforceMgr:Update(deltaTime)
        end
    elseif curState == COMPLETE then
        
    end
end

function CanActivateRailjackCluster()
    -- check if the proc system placed the correct rooms/objects in thte node. If not return false
    return 1
end

function RailjackCluster(hint)

    Broadcast("RailjackCluster.lua - Railjack Cluster Encounter Started")
    Initialize(hint)

    local sleepTime = UPDATE_INTERVAL

    while not ShouldShutDown() and not hint:ShouldShutDown() do
        Update(sleepTime)
        Sleep(sleepTime)
    end

    ShutDownRailjackCluster(hint)
end