--ARGS
radarShipType = Type()
firingLaserType = Type()
weaponChargeFx = Type()
weaponFireFx = Type()
targetMarkerType = Type()

--LIBS
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local RAILOBJ = require "Lotus.Scripts.Libs.RailjackObjectiveUI"

--RESOURCES
local pointOfInterestAgentType = WeakResource("/Lotus/Types/Game/CrewShip/PointOfInterestAgent")
local pointOfInterestAvatarType = WeakResource("/Lotus/Types/Game/CrewShip/PointOfInterestAvatar")

--LOC
local exposeFirstWeakpointLoc = "/Lotus/Language/RailjackMissions/POIExposeFirstRadiator"
local destroyFirstWeakpointLoc = "/Lotus/Language/RailjackMissions/POIDestroyFirstRadiator"
local exposeSecondWeakpointLoc = "/Lotus/Language/RailjackMissions/POIExposeSecondRadiator"
local destroySecondWeakpointLoc = "/Lotus/Language/RailjackMissions/POIDestroySecondRadiator"
local destroyFirstCoreLoc = "/Lotus/Language/RailjackMissions/SuperWeaponDestroyFirstCore"
local destroySecondCoreLoc = "/Lotus/Language/RailjackMissions/SuperWeaponDestroySecondCore"

--SYMBOLS
local sObjForwarder = Symbol("ObjCompleteForwarder")
local sDeadWeaponTag = Symbol("WeaponDisabledPoint")
local subObjTrackerName = "SuperWeapon"

--CACHED VARS
local mGameRules = nil
local mAiDir = nil
local mHint = nil
local mHintPos = nil
local mHintActivationRadius = 0
local mDeactivateRadius = 0
local mParentHint = nil
local mTransmissionSet = nil
local mTimerMgr = nil
local mModeMgr = nil
local mSpawnMgr = nil

--STATES
local INVALID = 0
local STARTED = 1
local APPROACHED = 2
local EXPOSE_WP1 = 3
local DESTROY_WP1 = 4
local DESTROY_CORE1 = 5
local EXPOSE_WP2 = 6
local DESTROY_WP2 = 7
local DESTROY_CORE2 = 8
local DISABLED = 9

--SETTINGS

--VARS
local mCrewShip = nil
local mEnterAction = nil
local mFiringPoint = nil
local mFiringLaser = nil
local mChargePoint = nil
local mChargeFX = nil
local mTurret = nil
local mAvatar = nil
local mObjForwarder = nil
local mFirstWeakpoint = nil
local mSecondWeakpoint = nil
local mFirstWeakpointAction = nil
local mSecondWeakpointAction = nil
local mCheatTracker = nil
--local mObjectiveTracker = nil
local mFirstCoreCover = nil
local mSecondCoreCover = nil
local mFirstCore = nil
local mSecondCore = nil
local mFireFx = nil
local mEmOnScript = nil
local mEmOffScript = nil
function FirePort(forwarder)
    if mModeMgr:GetModeState() == EXPOSE_WP1 then
        mModeMgr:SetModeState(DESTROY_WP1)
    elseif mModeMgr:GetModeState() == EXPOSE_WP2 then
        mModeMgr:SetModeState(DESTROY_WP2)
    end
end

function OnDisabled(entity)
    if entity == mFirstWeakpoint then
        mModeMgr:SetModeState(DESTROY_CORE1)
    elseif entity == mSecondWeakpoint then
        mModeMgr:SetModeState(DESTROY_CORE2)
    end
end

function OnDestroyed(entity)
    if entity == mFirstCore then
        mModeMgr:SetModeState(EXPOSE_WP2)
    elseif entity == mSecondCore then
        mModeMgr:SetModeState(DISABLED)
    end
end

local function CrewShipInitialize()
    local setupScript = gRegion:FindNearestTagged(Symbol("PoiSetupScript"), mHintPos)
    if not IsNull(setupScript) then
        setupScript:FirePort("Execute")
    else
        print("POI - Could not find setup script")
    end
    
    mAvatar = mCrewShip:GetAvatarOwner()

    mObjForwarder = RAIL.FindFirstTaggedOnShip(sObjForwarder, mCrewShip)
    ObjectPortHandler(mObjForwarder, "FirePort")
    RAIL.SetCrewShipEnterMarker(true, mCrewShip)
    mSpawnMgr = RAIL.CreateSpawnMgr(mHint, mCrewShip)
    
    mFirstWeakpointAction = RAIL.FindFirstTaggedOnShip(Symbol("WeakpointConsole"), mCrewShip)
    mSecondWeakpointAction = RAIL.FindFirstTaggedOnShip(Symbol("WeakpointConsole2"), mCrewShip)
    local forwarder = gRegion:FindNearestTagged(Symbol("SuccessfulHackForwarder"), mFirstWeakpointAction:GetPosition())
    ObjectPortHandler(forwarder, "FirePort")
    forwarder = gRegion:FindNearestTagged(Symbol("SuccessfulHackForwarder"), mSecondWeakpointAction:GetPosition())
    ObjectPortHandler(forwarder, "FirePort")
    
    local weakpoints = RAIL.FindTaggedInScope(Symbol("MissilePlatformWeakpoint"), mEnterAction:GetScope())
    table.sort(
        weakpoints,
        function(a, b)
            local posA, posB = a:GetPosition(), b:GetPosition()
            if posA.x == posB.x then
                if posA.y == posB.y then
                    return posA.z < posB.z
                else
                    return posA.y < posB.y
                end
            else
                return posA.x < posB.x
            end
        end
    )
    mFirstWeakpoint = weakpoints[1]
    mSecondWeakpoint = weakpoints[2]
    ObjectPortHandler(mFirstWeakpoint, "OnDisabled")
    ObjectPortHandler(mSecondWeakpoint, "OnDisabled")
    
    mFirstCoreCover = RAIL.FindFirstTaggedOnShip(Symbol("CoreCover"), mCrewShip)
    mSecondCoreCover = RAIL.FindFirstTaggedOnShip(Symbol("CoreCover2"), mCrewShip)
    mFirstCore = RAIL.FindFirstTaggedOnShip(Symbol("Core"), mCrewShip)
    ObjectPortHandler(mFirstCore, "OnDestroyed")
    mSecondCore = RAIL.FindFirstTaggedOnShip(Symbol("Core2"), mCrewShip)
    ObjectPortHandler(mSecondCore, "OnDestroyed")
    
    --[[mObjectiveTracker = _T.GetHudTracker(mHint:GetFullName() .. "Tracker")
    if IsNull(mObjectiveTracker) then
        mObjectiveTracker = _T.AddHudTracker(mHint:GetFullName() .. "Tracker", LOTUS_UTIL.HT_LABEL)
        mObjectiveTracker.SetVisible(false)
    end]]
    
    mCheatTracker = _T.AddHudTracker("Cheat", LOTUS_UTIL.HT_LABEL)
    local textOpen = "<p><font face=\"Noto Sans\" color=\"#FF0000\">"
    local textClose = "</font></p>"
    mCheatTracker.SetLabel(textOpen .. "LotusGameRules.MissionDebug ENABLED" .. textClose)
    mCheatTracker.SetVisible(false)
end

function ShipReady(ship)
    mCrewShip = ship
    mAvatar = mCrewShip:GetAvatarOwner()
    mHint:RegisterAgent(mAvatar:GetAgent())
end

-- OnModeStateChanged - this is called immediately when state changes - use this function for setting up the state (UI changes, creating objects, etc)
-- This func is called after host migration, so you can recover from the state you migrated during
local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    if curState == STARTED then
        mAvatar:SetPosition(mHintPos)
        mEnterAction:Enable()
        local objectiveWaypoint = RAIL.FindFirstTaggedOnShip(Symbol("Objective"), mCrewShip)
        mAiDir:SetObjective(objectiveWaypoint)
    elseif curState == EXPOSE_WP1 then
        mFirstWeakpointAction:Enable()
        --mObjectiveTracker.SetVisible(true)
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(exposeFirstWeakpointLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, exposeFirstWeakpointLoc, RAILOBJ.GENERIC_ICON)
    
    elseif curState == DESTROY_WP1 then
        if gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug") then
            mTimerMgr:AddTimer(10, function() mFirstWeakpoint:Disable() end)
        end
        mFirstWeakpoint:Activate()
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(destroyFirstWeakpointLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, destroyFirstWeakpointLoc, RAILOBJ.ATTACK_ICON)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("WeakpointExposed"))
    
    elseif curState == DESTROY_CORE1 then
        mFirstCoreCover:FirePort("Start")
        mFirstCore:MakeVulnerable()
        mFirstCore:Attach(targetMarkerType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION)
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(destroyFirstCoreLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, destroyFirstCoreLoc, RAILOBJ.ATTACK_ICON)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("FirstWeakpointDestroyed"))
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("DestroyInteriorWeakpoint"))
    
    elseif curState == EXPOSE_WP2 then
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(exposeSecondWeakpointLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, exposeSecondWeakpointLoc, RAILOBJ.GENERIC_ICON)
        mSecondWeakpointAction:Enable()
    
    elseif curState == DESTROY_WP2 then
        if gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug") then
            mTimerMgr:AddTimer(10, function() mSecondWeakpoint:Disable() end)
        end
        mSecondWeakpoint:Activate()
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(destroySecondWeakpointLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, destroySecondWeakpointLoc, RAILOBJ.ATTACK_ICON)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("WeakpointExposed"))
    
    elseif curState == DESTROY_CORE2 then
        mSecondCoreCover:FirePort("Start")
        mSecondCore:MakeVulnerable()
        mSecondCore:Attach(targetMarkerType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION)
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(destroySecondCoreLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, destroySecondCoreLoc, RAILOBJ.ATTACK_ICON)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("SecondWeakpointDestroyed"))
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("DestroyInteriorWeakpoint"))
        
    elseif curState == DISABLED then
        mTurret:Disable()
        mTimerMgr:ClearTimers()
        RAIL.SetCrewShipEnterMarker(false, mCrewShip)
        RAIL.SetCrewShipExitMarker(true, mCrewShip)
        --_T.RemoveHudTracker(mObjectiveTracker)
        RAILOBJ.RemoveObjective(mHint, subObjTrackerName)
        RAILOBJ.RemoveObjective(mHint)
        mHint:SetEncounterStatus(Npc.ES_COMPLETE)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("ObjectiveComplete"))
    end
end

-- Initialize - first thing that runs when a mission encounter starts - do your initial setup here. This is called again on migration.
-- Because gPromotedToHost is unreliable here, you will need to search for mission entities first, and create if not found (see mMissionObject)
local function Initialize(hint)
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    mGameRules = gGameRules
    mHint = hint
    mParentHint = hint:GetRootParentEncounterHint()
    mHintPos = hint:GetPosition()
    mHintActivationRadius = hint:GetActivationRadius()
    mDeactivateRadius = hint:GetDeactivationRadius()
    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()
    gRegion:AddPlayersChangedBasicCallback("OnPlayersChanged")
    --mPlayers = gRegion:GetHumanPlayers()
    
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})
    mTimerMgr = TIMER.CreateTimerMgr()
    
    --Mission specific initialization--
    mEnterAction = gRegion:FindNearestTagged(Symbol("EnterPoiAction"), mHintPos)
    mTurret = gRegion:FindNearestTagged(Symbol("LaserTurret"), mHintPos)

    local netState = mHint:GetEncounterDynamicState()
    if netState > INVALID then
        --recover crewship/avatar after migration
        while IsNull(mCrewShip) do
            local mAvatar = gRegion:FindNearestTagged(Symbol("SuperWeapon"), mHintPos)
            if not IsNull(mAvatar) then
                mCrewShip = mAvatar:InventoryControl():GetActivePowerSuit()
            end
            if IsNull(mCrewShip) then
                Sleep(0)
            end
        end
    else
        local crewShipMgr = gGameRules:GetCrewShipManager()
        crewShipMgr:CreateCrewShipFromType(radarShipType, nil, false, true, "ShipReady")
    end
    
    while IsNull(mCrewShip) do
        Sleep(0)
    end
    
    CrewShipInitialize()
    
    if netState < DISABLED then
        mTurret:Enable()
    end
    
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))
    hint:SetEncounterStatus(Npc.ES_ACTIVE)
end

--Main function - Contains main update loop, monitor mode state here
function Start(hint)
    Initialize(hint)
    
    local delta = 0
    local curState = INVALID
    while true do
        if gGameRules:MissionCompleted() or gGameRules:MissionFailed() or hint:GetEncounterStatus() >= Npc.ES_SUCCEEDED then
            break
        end
        
        delta = DeltaTime()
        curState = mModeMgr:GetModeState()
        
        if curState == STARTED then
            if RAIL.ArePlayersNearEntity(mEnterAction, RAIL.POI_APPROACH_DISTANCE) then
                DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("ObjectiveProximity"))
                mModeMgr:SetModeState(APPROACHED)
            end
        elseif curState == APPROACHED then
            local onShip = RAIL.GetPlayerAvatarsOnShip(mCrewShip)   --not great because its gets an array and counts it..
            if #onShip > 0 then
                mSpawnMgr:ShipBoarded()
                mModeMgr:SetModeState(EXPOSE_WP1)
            end
        end
        
        if curState >= STARTED then
            mSpawnMgr:Update(delta)
        elseif not mSpawnMgr.mCleanedUp and curState == DISABLED and mAiDir:CountPlayersInRegion(mCrewShip:GetInteriorLayer()) == 0 then
            mSpawnMgr:CleanUp()
        end
        
        mTimerMgr:Update(delta)
        
        Sleep(0)
    end
    
    mModeMgr:ShutDown()
end

--CALLBACKS
function OnPlayersChanged()
    --mPlayers = gRegion:GetHumanPlayers()
end

----------------------------------SUPER WEAPON------------------------------------
--WEAPON STATES
local IDLE = 1
local TARGETING = 2
local CHARGING = 3
local FIRING = 4
local COOLDOWN = 5
local OFFLINE = 6
local FindTarget

local CHARGE_TIME = 10
local FIRING_TIME = 5
local COOLDOWN_TIME = 10
local TURN_RATE = 20
local FIRING_TURN_RATE = 5
local LASER_RANGE = 1000
local LOSE_TARGET_RANGE = 1200
local TARGET_CHECK_RATE = 1     --how often to check for a target
local CHARGING_ANGLE = 30
local SHOW_LASER_RANGES = false
 
local function OnWeaponStateChanged()
    local state = mTurret:GetScriptState()
    
    local stateStr = ""

    if state == IDLE then
        stateStr = "IDLE"
        if TARGET_CHECK_RATE > 0 then
            mTimerMgr:AddTimer(TARGET_CHECK_RATE, FindTarget, true)
        end
    elseif state == TARGETING then
        stateStr = "TARGETING"
    
    elseif state == CHARGING then
        stateStr = "CHARGING"
        --add targeting laser and/or hint that we're being targetted
        if gRegion:IsMaster() then
            mTimerMgr:AddTimer(CHARGE_TIME,
                function() 
                    if not IsNull(mTurret) then 
                        mTurret:SetScriptState(FIRING) 
                    end 
                end)
        end
        mChargeFX = mChargePoint:Attach(weaponChargeFx, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION)
        mChargeFX:FirePort("Burst")
        if not IsNull(mEmOnScript) then
            mEmOnScript:FirePort("Execute")
        end
    elseif state == FIRING then
        stateStr = "FIRING"
        if gRegion:IsMaster() then
            mFiringLaser:Enable()
            mTimerMgr:AddTimer(FIRING_TIME, 
                function() 
                    if not IsNull(mTurret) then 
                        mTurret:SetScriptState(COOLDOWN) 
                    end 
                end)
        end
        if not IsNull(mFiringLaser) then
            mFiringLaser:SetMaterialParam(Symbol("UnlitAtten"), 4)
        end
        if not IsNull(mFireFx) then
            mFireFx = mChargePoint:Attach(weaponFireFx, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION)
        end
    elseif state == COOLDOWN then
        stateStr = "COOLDOWN"
        if not IsNull(mFiringLaser) then
            mFiringLaser:SetMaterialParam(Symbol("UnlitAtten"), 0)
        end
        if gRegion:IsMaster() then
            mFiringLaser:Disable()
            mTimerMgr:AddTimer(COOLDOWN_TIME, 
                function() 
                    if not IsNull(mTurret) then 
                        mTurret:SetScriptState(IDLE) 
                    end 
                end)
        end
		if not IsNull(mFireFx) then
			mFireFx:Destroy()
		end
        if not IsNull(mEmOffScript) then
            mEmOffScript:FirePort("Execute")
        end
    end
    
    --print("SUPER WEAPON - " .. stateStr)
end

local function CanTarget(entity)
    if entity:IsA(gWaypointType) then
        return true
    end

    if entity:GetFaction() == Symbol("GRINEER") or entity:IsA(pointOfInterestAvatarType) then
        --can't target friendly ships
        return false
    end
    
    if entity == mTurret:GetOwner() and mTurret:GetOwner():DistanceToEntity(mFiringPoint) > LOSE_TARGET_RANGE then
        --existing target got too far
        return false
    end
    
    if entity:DistanceToEntity(mFiringPoint) > LASER_RANGE then
        --too far to start targeting
        return false
    end
    
    if not entity:CanSeeEntity(mFiringPoint) then
        --something is between entity and firing point
        return false
    end
    
    return true
end

local function FaceTarget(delta)
    --TODO: track via heading if > then some difference between current heading and desired facing angle heading
    local turretPos = mTurret:GetPosition()
    local targetPos = mTurret:GetOwner():GetPosition()
    local dir = targetPos - turretPos
    local dir2D = Vector(dir.x, 0.0, dir.z)
    if Length(dir2D) == 0.0 then
        return
    end

    --gRegion:VisAddLine(mTurret:GetPosition(), turretPos + (dir * 100), Color(255, 0, 0), 0.1)
    Normalize(dir)
    Normalize(dir2D)
    local turnRate = UTIL.Ternary(mTurret:GetScriptState() == FIRING, FIRING_TURN_RATE, TURN_RATE)
    local newDir = nil
    local currDir = mTurret:GetForwardVector()
    
    local angle = AngleBetween(currDir, dir2D)
    if angle <= CHARGING_ANGLE and angle > 5 then
        newDir = RotateTowards(currDir, dir, turnRate * delta)
    elseif angle > 5 then
        newDir = RotateTowards(currDir, dir2D, turnRate * delta)
    end

    if not IsNull(newDir) then
        local newRot = LookTo(ZERO_VECTOR, newDir)
        newRot.pitch = Clamp(newRot.pitch, -45, 45)

        local turretParent = mTurret:GetAttachParent()
        if not IsNull(turretParent) then
            newRot = CombineRotations(newRot, InverseRotation(turretParent:GetRotation()))
        end
        local localPos = mTurret:GetLocalAttachPosition()
        mTurret:SetAttachLocalSpace(localPos, newRot)
    end
end

FindTarget = function()
    local curState = mTurret:GetScriptState()
    
    if curState ~= IDLE or not gRegion:IsMaster() then
        return
    end
    
    if curState ~= OFFLINE then
        local crewships = gRegion:FindAll(gCrewShipAvatarType)
        for i, ship in ipairs(crewships) do
            if CanTarget(ship) then
                mTurret:SetOwner(ship)
                mTurret:SetScriptState(TARGETING)
                return
            end
        end
    elseif curState == OFFLINE then
        mTurret:SetOwner(gRegion:FindFirstTagged(sDeadWeaponTag))
    end
end


function SuperWeaponTurret(turret)
    while not turret:IsEnabled() do
        Sleep(1)
    end
    
    turret:RegisterOnStateChangedCallback(OnWeaponStateChanged)
    
    mTurret = turret    
    mFiringPoint = gRegion:FindNearestTagged(Symbol("FiringPoint"), mTurret:GetPosition())
    mChargePoint = gRegion:FindNearestTagged(Symbol("ChargePoint"), mTurret:GetPosition())
    mEmOnScript = gRegion:FindNearestTagged(Symbol("EmOnScript"), mTurret:GetPosition())
    mEmOffScript = gRegion:FindNearestTagged(Symbol("EmOffScript"), mTurret:GetPosition())
    mTimerMgr = TIMER.CreateTimerMgr()
    
    if gRegion:IsMaster() then
        mFiringLaser = mFiringPoint:Attach(firingLaserType, EMPTY_SYMBOL, ZERO_VECTOR, Rotation(180,0,0))
        mTurret:SetScriptState(IDLE)
    else
        mFiringLaser = mFiringPoint:GetAttachment(firingLaserType)
        while IsNull(mFiringLaser) do
            Sleep(0)
            mFiringLaser = mFiringPoint:GetAttachment(firingLaserType)
        end
    end
    
    local wasMaster = gRegion:IsMaster()
    
    while mTurret:GetScriptState() ~= OFFLINE do
        local curState = mTurret:GetScriptState()
        
        if not wasMaster and gRegion:IsMaster() then
            wasMaster = true
            OnWeaponStateChanged()
        end
        
        if gRegion:IsMaster() then
            local turretOwner = mTurret:GetOwner()
            if IsNull(turretOwner) then
                mTurret:SetScriptState(IDLE)
            elseif curState == TARGETING then
                local dir = turretOwner:GetPosition() - mTurret:GetPosition()
                Normalize(dir)
                local forward = mTurret:GetForwardVector()
                Normalize(forward)
                if math.abs(AngleBetween(forward, dir)) <= CHARGING_ANGLE then
                    mTurret:SetScriptState(CHARGING)
                end
            end
        end
        
        if SHOW_LASER_RANGES then
            gRegion:VisAddCircle(mFiringPoint:GetPosition(), LASER_RANGE, Color(255, 0, 0), Rotation(0,90,0), 0.1)
            gRegion:VisAddCircle(mFiringPoint:GetPosition(), LOSE_TARGET_RANGE, Color(0, 255, 0), Rotation(0,90,0), 0.1)
            gRegion:VisAddCircle(mFiringPoint:GetPosition(), LASER_RANGE, Color(255, 0, 0), Rotation(90,0,0), 0.1)
            gRegion:VisAddCircle(mFiringPoint:GetPosition(), LOSE_TARGET_RANGE, Color(0, 255, 0), Rotation(90,0,0), 0.1)
        end
        
        if not IsNull(mTurret:GetOwner()) then
            if not CanTarget(mTurret:GetOwner()) then
                if gRegion:IsMaster() then
                    mTurret:SetOwner(nil)
                end
            else
                FaceTarget(DeltaTime())
            end
        end
        
        mTimerMgr:Update(DeltaTime())
        Sleep(0)
    end
    
    if gRegion:IsMaster() then
        mTurret:SetScriptState(OFFLINE)
    end
end
