uiEncounterOrder = {WeakResource()}

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local PANIC = require "Lotus.Scripts.Libs.PanicLib"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local TABLE = require "Lotus.Scripts.Libs.TableLib"
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local RAILOBJ = require "Lotus.Scripts.Libs.RailjackObjectiveUI"

local NV_NUM_PLAYERS = Symbol("NVNumPlayers")
local sTenno = Symbol("TENNO")

local mHint = nil
local mAiDir = nil
local mCrewShip = nil
local mObjectiveText = ""
--local mObjectiveTracker = nil
local mPoiHint = nil


local function ShutDown(hint)
    --Sleep(3)
    --_T.RemoveHudTracker(mObjectiveTracker)
    RAILOBJ.RemoveObjective(mPoiHint, nil, true)
    --RAILOBJ.RemoveObjective(mHint)
end

local function ShouldShutDown()
    local hintStatus = mHint:GetEncounterStatus() 

    if hintStatus >= Npc.ES_COMPLETE then
        return true
    end

    local crewShipMgr = gGameRules:GetCrewShipManager()
    local ship = crewShipMgr:GetPlayerShip()

    if not IsNull(ship) then
        local crewShipAvatar = ship:GetAvatarOwner()
        local hyperDriveState = crewShipAvatar:GetHyperDriveState()

        if hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_ACTIVE then
            return true
        end
    end
    
    return false
end

local function HintStatusChanged(hint)
    if hint:GetEncounterStatus() == Npc.ES_COMPLETE or hint:GetEncounterStatus() == Npc.ES_SUCCEEDED then
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(mObjectiveText) .. ": 1 / 1")
        --RAILOBJ.SetMainObjective(hint, mObjectiveText, ": 1 / 1")
        mHint:SetEncounterDynamicState(RAIL.SUB_OBJECTIVE_COMPLETE)
    end
end

local function Initialize(hint)
    mHint = hint
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    mPoiHint = gRegion:FindNearestTagged(Symbol("PointOfInterestHint"), mHint:GetPosition())
    mPoiHint:RegisterStatusChangedCallback(HintStatusChanged, Symbol(mPoiHint:GetFullName() .. "SubObjective"))
    
    local encounter = mPoiHint:GetCurrentEncounterTemplate()
    while IsNull(encounter) do
        Sleep(0)
        encounter = mPoiHint:GetCurrentEncounterTemplate()
    end
    
    mObjectiveText = encounter:GetObjectiveLocTag():c_str()
    
    if mObjectiveText == "" then
        mObjectiveText = "[NO LOC TAG] " .. tostring(mPoiHint:GetCurrentEncounterTemplate():GetName())
    end
    
    if IsNull(_T.UiEncounterOrder) then
        _T.UiEncounterOrder = uiEncounterOrder
    end
    
    --[[mObjectiveTracker = _T.GetHudTracker(encounter:GetFullName() .. "Tracker")
    if IsNull(mObjectiveTracker) and mHint:GetEncounterStatus() <= Npc.ES_SUCCEEDED then
        mObjectiveTracker = _T.AddHudTracker(encounter:GetFullName() .. "Tracker", LOTUS_UTIL.HT_LABEL)
        mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(mObjectiveText) .. ": 0 / 1")
    end]]
    
    if not ShouldShutDown() then
        RAILOBJ.SetMainObjective(mPoiHint, mObjectiveText)
    end

    if hint:GetEncounterStatus() == Npc.ES_SETUP then
        hint:SetEncounterStatus(Npc.ES_ACTIVE)
    end
end

function PoiSubObjective(hint)
    Initialize(hint)

    while not ShouldShutDown() do
        --[[local goalRatio = mPoiMinorKillCount / mPoiMinorKillGoal
        local globalAlertLevel = mAiDir:GetGlobalAlertLevel()
        local newGlobalAlertLevel = globalAlertLevel
        
        for i, v in ipairs(globalAlertLevelThresholds) do
            if goalRatio >= v then
                newGlobalAlertLevel = math.max(i, newGlobalAlertLevel)
            end
        end
        
        if ( newGlobalAlertLevel > globalAlertLevel ) then
            mAiDir:SetGlobalAlertLevel(newGlobalAlertLevel)
        end]]

        
        
        Sleep(0)
    end

    ShutDown(hint)
end