--ARGS
grineerMissilePlatformType = Type()
turretBonesTop = { Symbol("GAME_C1_LGUN"), Symbol("GAME_C1_MGUN"), Symbol("GAME_C1_RGUN") }
turretAgentTypeTop = Type()
turretBonesBottom = { Symbol("GAME_C1_BTURRET"), Symbol("GAME_C1_LTURRET"), Symbol("GAME_C1_FTURRET"), Symbol("GAME_C1_RTURRET") }
turretAgentTypeBottom = Type()

--LIBS
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local RAILOBJ = require "Lotus.Scripts.Libs.RailjackObjectiveUI"

--RESOURCES
local pointOfInterestAgentType = WeakResource("/Lotus/Types/Game/CrewShip/PointOfInterestAgent")
local replicatedHitSwitchRes = WeakResource("/EE/Types/Actions/ReplicatedHitSwitch")
local crewshipObjectiveMarkerWRes = WeakResource("/Lotus/Types/Game/MarkerInfos/CrewShipObjectiveMarkerInfoNoReticleAlwaysInRange")

--LOC
local exposeFirstWeakpointLoc = "/Lotus/Language/RailjackMissions/POIExposeFirstRadiator"
local destroyFirstWeakpointLoc = "/Lotus/Language/RailjackMissions/POIDestroyFirstRadiator"
local exposeSecondWeakpointLoc = "/Lotus/Language/RailjackMissions/POIExposeSecondRadiator"
local destroySecondWeakpointLoc = "/Lotus/Language/RailjackMissions/POIDestroySecondRadiator"
local reachCoreLoc = "/Lotus/Language/RailjackMissions/MissilePlatformReachCore"
local destroyCoreLoc = "/Lotus/Language/RailjackMissions/POIDestroyCore"

--SYMBOLS
local sHide = Symbol("Hide")
local sMissileCoreTag = Symbol("RJMissilePlatformCore")
local subObjTrackerName = "MissilePlatform"

--CACHED VARS
local mGameRules = nil
local mAiDir = nil
local mHint = nil
local mHintPos = nil
local mHintActivationRadius = 0
local mDeactivateRadius = 0
local mParentHint = nil
local mTransmissionSet = nil
local mTimerMgr = nil
local mModeMgr = nil
local mSpawnMgr = nil
local mPlayers = nil

--STATES
local INVALID = 0
local STARTED = 1
local APPROACHED = 2
local EXPOSE_WP1 = 3
local DESTROY_WP1 = 4
local EXPOSE_WP2 = 5
local DESTROY_WP2 = 6
local REACH_BRIDGE = 7
local REACHED_BRIDGE = 8
local DISABLED = 9

--VARS
local mCrewShip = nil
local mAvatar = nil
local mEnterActions = {}
local mDisableAction = nil
local mPlatformDeco = nil
local mFirstWeakpoint = nil
local mSecondWeakpoint = nil
local mFirstWeakpointAction = nil
local mSecondWeakpointAction = nil
local mUnlockCoreRoomScriptTrigger = nil
local mFirstDummyWeakpoint = nil
local mSecondDummyWeakpoint = nil
local mCheatTracker = nil
local mCoreRoomMarker = nil
local mCoreDeco = nil
--local mObjectiveTracker = nil
local mCrewShipMgr = nil

function OnDisabled(weakpoint)
    if weakpoint == mFirstWeakpoint then
        mFirstDummyWeakpoint:Disable()
        mModeMgr:SetModeState(EXPOSE_WP2)
    elseif weakpoint == mSecondWeakpoint then
        mSecondDummyWeakpoint:Disable()
        mModeMgr:SetModeState(REACH_BRIDGE)
    end
end

function OnDestroyed(deco)
    if deco == mCoreDeco then
        mModeMgr:SetModeState(DISABLED)

        local coreMarker = deco:GetAttachment(crewshipObjectiveMarkerWRes)

        if not IsNull(coreMarker) and coreMarker:IsEnabled() then
            coreMarker:Disable()
        end
        
        --local exitMarker = RAIL.FindFirstTaggedOnShip(Symbol("PoiExitMarker"), mCrewShip)
        --exitMarker:Enable()
        RAIL.SetCrewShipExitMarker(true, mCrewShip)
        
        local agent = mAvatar:GetAgent()
        agent:SetPaused(true, Symbol("PoiDisabled"))    --should stop missile volley
        local agents = mHint:GetRegisteredAgents()
        for i, agent in ipairs(agents) do
            local avatar = agent:GetAvatar()
            if avatar:IsA(gAutoTurretAvatarType) then
                avatar:DecrementActivationRequests()
            end
        end
        
        mHint:SetEncounterStatus(Npc.ES_COMPLETE)
    end
end

function FirePort(forwarder)
    if mModeMgr:GetModeState() == EXPOSE_WP1 then
        mFirstWeakpoint:Activate()
        mFirstDummyWeakpoint:Activate()
        --mSpawnMgr:ReinforceAndAttack(mFirstWeakpointAction, 3)
        if gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug") then
            mTimerMgr:AddTimer(10, function() mFirstWeakpoint:Disable() end)
        end
        mModeMgr:SetModeState(DESTROY_WP1)
    elseif mModeMgr:GetModeState() == EXPOSE_WP2 then
        mSecondWeakpoint:Activate()
        mSecondDummyWeakpoint:Activate()
        --mSpawnMgr:ReinforceAndAttack(mSecondWeakpointAction, 3)
        if gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug") then
            mTimerMgr:AddTimer(10, function() mSecondWeakpoint:Disable() end)
        end
        mModeMgr:SetModeState(DESTROY_WP2)
    end
end

local function CrewShipInitialize()
    local setupScript = gRegion:FindNearestTagged(Symbol("PoiSetupScript"), mHintPos)
    if not IsNull(setupScript) then
        setupScript:FirePort("Execute")
    else
        print("POI - Could not find setup script")
    end
    
    RAIL.SetCrewShipEnterMarker(true, mCrewShip)
    mSpawnMgr = RAIL.CreateSpawnMgr(mHint, mCrewShip)
    local objectiveWaypoint = RAIL.FindFirstTaggedOnShip(Symbol("Objective"), mCrewShip)
    mAiDir:SetObjective(objectiveWaypoint)
    
    Sleep(0)
    
    local weakpointConsoleActions = RAIL.FindTaggedOnShip(Symbol("WeakpointConsole"), mCrewShip)
    if #weakpointConsoleActions >= 2 then
        --should always be 2
        if weakpointConsoleActions[1]:GetZone():GetLayerIndex() < weakpointConsoleActions[2]:GetZone():GetLayerIndex() then
            mFirstWeakpointAction = weakpointConsoleActions[2]
            mSecondWeakpointAction = weakpointConsoleActions[1]
        else
            mFirstWeakpointAction = weakpointConsoleActions[1]
            mSecondWeakpointAction = weakpointConsoleActions[2]
        end
        
        Sleep(1)
        
        local hackForwarder = gRegion:FindNearestTagged(Symbol("SuccessfulHackForwarder"), mFirstWeakpointAction:GetPosition())
        ObjectPortHandler(hackForwarder, "FirePort")
        print("ObjectPortHandler " .. hackForwarder:GetFullName())
        
        hackForwarder = gRegion:FindNearestTagged(Symbol("SuccessfulHackForwarder"), mSecondWeakpointAction:GetPosition())
        ObjectPortHandler(hackForwarder, "FirePort")
        print("ObjectPortHandler " .. hackForwarder:GetFullName())
        
        ObjectPortHandler(mFirstWeakpointAction, "OnActivated")
        ObjectPortHandler(mSecondWeakpointAction, "OnActivated")
    end
    
    --TODO: match weakpoint with action, right now they are sometimes on opposite sides
    local weakpoints = RAIL.FindTaggedInScope(Symbol("MissilePlatformWeakpoint"), mHint:GetScope())
    table.sort(
        weakpoints,
        function(a, b)
            local posA, posB = a:GetPosition(), b:GetPosition()
            if posA.x == posB.x then
                if posA.y == posB.y then
                    return posA.z < posB.z
                else
                    return posA.y < posB.y
                end
            else
                return posA.x < posB.x
            end
        end
    )
    mFirstWeakpoint = weakpoints[1]
    mSecondWeakpoint = weakpoints[2]
    ObjectPortHandler(mFirstWeakpoint, "OnDisabled")
    ObjectPortHandler(mSecondWeakpoint, "OnDisabled")
    
    mFirstDummyWeakpoint = gRegion:FindNearestTagged(Symbol("MissilePlatformWeakpoint"), mFirstWeakpointAction:GetPosition())
    mSecondDummyWeakpoint = gRegion:FindNearestTagged(Symbol("MissilePlatformWeakpoint"), mSecondWeakpointAction:GetPosition())
    
    mUnlockCoreRoomScriptTrigger = RAIL.FindFirstTaggedOnShip(Symbol("UnlockCoreRoom"), mCrewShip)
    
    mCheatTracker = _T.AddHudTracker("Cheat", LOTUS_UTIL.HT_LABEL)
    local textOpen = "<p><font face=\"Noto Sans\" color=\"#FF0000\">"
    local textClose = "</font></p>"
    mCheatTracker.SetLabel(textOpen .. "LotusGameRules.MissionDebug ENABLED" .. textClose)
    mCheatTracker.SetVisible(false)
    
    --[[mObjectiveTracker = _T.GetHudTracker("MissilePlatformObjective" .. mAvatar:GetInstance())
    if IsNull(mObjectiveTracker) then
        mObjectiveTracker = _T.AddHudTracker("MissilePlatformObjective" .. mAvatar:GetInstance(), LOTUS_UTIL.HT_LABEL)
        mObjectiveTracker.SetVisible(false)
    end]]
    
    mCoreRoomMarker = RAIL.FindFirstTaggedOnShip(Symbol("CoreRoomMarker"), mCrewShip)
    mCoreDeco = RAIL.FindFirstTaggedOnShip(sMissileCoreTag, mCrewShip)
    ObjectPortHandler(mCoreDeco, "OnDestroyed")
end

function ShipReady(ship)
    if not IsNull(ship) then
        mCrewShip = ship
        mAvatar = mCrewShip:GetAvatarOwner()
        mHint:RegisterAgent(mAvatar:GetAgent())
    else
        LogBug("Failed to create ship!")
    end
end

function OnActivated(action)
    local currUser = action:GetCurrUser()
    
    if IsNull(currUser:GetPlayer()) then
        if action == mFirstWeakpointAction then
            mFirstWeakpoint:Deactivate()
            mFirstDummyWeakpoint:Deactivate()
        elseif action == mSecondWeakpointAction then
            mSecondWeakpoint:Deactivate()
            mSecondDummyWeakpoint:Deactivate()
        end
    end
end

local function WeakpointReminder(state)
    if mModeMgr:GetModeState() == state then
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("WeakpointReminder"))
    end
end

-- OnModeStateChanged - this is called immediately when state changes - use this function for setting up the state (UI changes, creating objects, etc)
-- This func is called after host migration, so you can recover from the state you migrated during
local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    if curState == STARTED then
        mAvatar:SetPosition(mHintPos) 
        for i, action in ipairs(mEnterActions) do
            action:Enable()
        end
        
    elseif curState == EXPOSE_WP1 then
        mSpawnMgr:ShipBoarded()
        mFirstWeakpointAction:Enable()
        --mObjectiveTracker.SetVisible(true)
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(exposeFirstWeakpointLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, exposeFirstWeakpointLoc, RAILOBJ.GENERIC_ICON)
        
    elseif curState == DESTROY_WP1 then
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(destroyFirstWeakpointLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, destroyFirstWeakpointLoc, RAILOBJ.ATTACK_ICON)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("WeakpointExposed"))
        mTimerMgr:AddTimer(10, WeakpointReminder, curState)
    
    elseif curState == EXPOSE_WP2 then
        mSecondWeakpointAction:Enable()
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(exposeSecondWeakpointLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, exposeSecondWeakpointLoc, RAILOBJ.GENERIC_ICON)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("FirstWeakpointDestroyed"))
    
    elseif curState == DESTROY_WP2 then
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(destroySecondWeakpointLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, destroySecondWeakpointLoc, RAILOBJ.ATTACK_ICON)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("WeakpointExposed"))
    
    elseif curState == REACH_BRIDGE then
        mCoreRoomMarker:Enable()
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(reachCoreLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, reachCoreLoc, RAILOBJ.GENERIC_ICON)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("SecondWeakpointDestroyed"))
    
    elseif curState == REACHED_BRIDGE then
        mCoreRoomMarker:Disable()
        mSpawnMgr:QueueCustomSpawns(5)
        mUnlockCoreRoomScriptTrigger:FirePort("Execute")
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(destroyCoreLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, destroyCoreLoc, RAILOBJ.ATTACK_ICON)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("DestroyInteriorWeakpoint"))
        
    elseif curState == DISABLED then
        --_T.RemoveHudTracker(mObjectiveTracker)
        RAILOBJ.RemoveObjective(mHint, subObjTrackerName)
        RAILOBJ.RemoveObjective(mHint)
        RAIL.SetCrewShipEnterMarker(false, mCrewShip)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("ObjectiveComplete"))
    end
end

-- Initialize - first thing that runs when a mission encounter starts - do your initial setup here. This is called again on migration.
-- Because gPromotedToHost is unreliable here, you will need to search for mission entities first, and create if not found (see mMissionObject)
local function Initialize(hint)
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    mGameRules = gGameRules
    mHint = hint
    mParentHint = hint:GetRootParentEncounterHint()
    mHintPos = hint:GetPosition()
    mHintActivationRadius = hint:GetActivationRadius()
    mDeactivateRadius = hint:GetDeactivationRadius()
    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()
    gRegion:AddPlayersChangedBasicCallback("OnPlayersChanged")
    mPlayers = gRegion:GetHumanPlayers()
    
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})
    mTimerMgr = TIMER.CreateTimerMgr()
    
    mPlatformDeco = gRegion:FindNearestTagged(Symbol("MissilePlatformDeco"), mHintPos)
    mEnterActions = RAIL.FindTaggedInScope(Symbol("EnterPoiAction"), mHint:GetScope())
    
    local netState = mHint:GetEncounterDynamicState()
    if netState > INVALID then
        --recover crewship/avatar after migration
        while IsNull(mCrewShip) do
            local registeredAgents = mHint:GetRegisteredAgents()
            for i, agent in ipairs(registeredAgents) do
                if agent:IsA(pointOfInterestAgentType) then
                    mAvatar = agent:GetAvatar()
                    mCrewShip = mAvatar:InventoryControl():GetActivePowerSuit()
                    break
                end
            end
            if IsNull(mCrewShip) then
                Sleep(0)
            end
        end
    else
        mCrewShipMgr = gGameRules:GetCrewShipManager()
        mCrewShipMgr:CreateCrewShipFromType(grineerMissilePlatformType, nil, false, true, "ShipReady")
    end
    
    while IsNull(mCrewShip) do
        Sleep(0)
    end
    
    CrewShipInitialize()

    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))
    hint:SetEncounterStatus(Npc.ES_ACTIVE)
end

local function SpawnTurrets()
    local team = Symbol("RandomTeam")
    local level = mAiDir:GetRandomSpaceEnemyLevel()
    
    if not IsNull(turretAgentTypeTop) then
        for i = 1, #turretBonesTop do
            local bone = turretBonesTop[i]

            if  not IsNull(bone) then
                local agent = mAiDir:CreateAgentAtPosition(turretAgentTypeTop, mPlatformDeco:GetBonePosition(bone), ZERO_ROTATION, team, level)
                if not IsNull(agent) then
                    mHint:RegisterAgent(agent)
                    local avatar = agent:GetAvatar()
                    avatar:AttachTo(mPlatformDeco, bone)
                    avatar:IncrementActivationRequests()
                end 
            end
            
            Sleep(0)
        end
    end
    
    if not IsNull(turretAgentTypeBottom) then
        for i = 1, #turretBonesBottom do
            local bone = turretBonesBottom[i]

            if  not IsNull(bone) then
                local agent = mAiDir:CreateAgentAtPosition(turretAgentTypeBottom, mPlatformDeco:GetBonePosition(bone), ZERO_ROTATION, team, level)
                if not IsNull(agent) then
                    mHint:RegisterAgent(agent)
                    local avatar = agent:GetAvatar()
                    avatar:AttachTo(mPlatformDeco, bone)
                    avatar:IncrementActivationRequests()
                end 
            end

            Sleep(0)
        end
    end
end

--Main function - Contains main update loop, monitor mode state here
function Start(hint)
    Initialize(hint)
    
    local delta = 0
    local curState = INVALID
    
    SpawnTurrets()
    
    while true do
        if gGameRules:MissionCompleted() or gGameRules:MissionFailed() or hint:GetEncounterStatus() >= Npc.ES_SUCCEEDED then
            break
        end
        
        delta = DeltaTime() 
        curState = mModeMgr:GetModeState()
        
        if gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug") then
            mCheatTracker.SetVisible(true)
        else
            mCheatTracker.SetVisible(false)
        end
        
        if curState == STARTED then
            if RAIL.ArePlayersNearEntity(mEnterActions[1], RAIL.POI_APPROACH_DISTANCE) then
                DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("ObjectiveProximity"))
                mModeMgr:SetModeState(APPROACHED)
            end
            
        elseif curState == APPROACHED then
            
            local onShip = RAIL.GetPlayerAvatarsOnShip(mCrewShip)   --not great because its gets an array and counts it..
            if #onShip > 0 then
                mModeMgr:SetModeState(EXPOSE_WP1)
            end
        elseif curState == REACH_BRIDGE then
            local avatars = RAIL.GetPlayerAvatarsOnShip(mCrewShip)
            for i, avatar in ipairs(avatars) do
                if avatar:DistanceToEntity(mCoreRoomMarker) < 15 then
                    mModeMgr:SetModeState(REACHED_BRIDGE)
                    break
                end
            end
        end
        
        if curState > STARTED and mAiDir:CountPlayersInRegion(mCrewShip:GetInteriorLayer()) > 0 then
            mSpawnMgr:Update(delta)
        end
        
        if not mSpawnMgr.mCleanedUp and curState == DISABLED and mAiDir:CountPlayersInRegion(mCrewShip:GetInteriorLayer()) == 0 then
            mSpawnMgr:CleanUp()
        end

        mTimerMgr:Update(delta)
        
        Sleep(0)
    end

    _T.RemoveHudTracker(mCheatTracker)
    mModeMgr:ShutDown()
end

--CALLBACKS
function OnPlayersChanged()
    mPlayers = gRegion:GetHumanPlayers()
end
