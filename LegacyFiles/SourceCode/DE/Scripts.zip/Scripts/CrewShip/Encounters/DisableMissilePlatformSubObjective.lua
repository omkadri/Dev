capitalShipAiSpec = Resource()
interiorShipRegionIndex = 1

transmissionSet = Resource()
enemyFaction = Symbol("Grineer")

consoleAvatarSpawnControl = Instance()
consoleVisualsActive = Instance()
consoleVisualsDone = Instance()

missileCoreTag = Symbol("RJMissilePlatformCore")
missilePlatformHintWRes = WeakResource()
crewshipObjectiveMarkerWRes = WeakResource()

enterShipMarkerWRes = WeakResource()

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local PANIC = require "Lotus.Scripts.Libs.PanicLib"

-- local NV_RJ_DATA_THEFT_STATE = Symbol("RJ_DATA_THEFT_STATE")
-- local NV_RJ_NUM_DATA_STOLEN = Symbol("RJ_NUM_DATA_STOLEN")
local NV_RJ_DISABLE_MISSILE_PLATFORM = Symbol("RJ_DISABLE_MISSILE_PLATFORM")

local NOT_STARTED = 1
local WAITING_TO_START = 2
local STARTED = 3
local COMPLETE = 4
local mModeState = INVALID
local SetModeState


local PLATFORM_SPAWNED = 2
local PLATFORM_DISABLED = 5

local UPDATE_INTERVAL = 0.1 -- How frequently we will tick 

local mHint = nil
local mAiSpec = nil
local mAiDir = nil

local mPotentialMissileEncounterHints = nil
local mActiveMissileEncounterHint = nil
local mCrewShip = nil
local mTemplate = nil
local mTransmissionSet = nil

function NPCAlertStart(npc)
    PANIC.SetPanicLevel(PANIC.ALERT)
end

function NPCAlertEnd(npc)
    PANIC.SetPanicLevel(PANIC.UNALERT) 
end

local function ShouldShutDown()
    if mModeState == COMPLETE then
        return true
    end

    -- local crewShipMgr = gGameRules:GetCrewShipManager()
    -- if not IsNull(crewShipMgr) then
    --     local ship = crewShipMgr:GetPlayerShip()
    --     local shipAvatar = ship:GetAvatarOwner()
    --     local hyperDriveState = shipAvatar:GetHyperDriveState()

    --     if hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_BOARDING or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP then
    --         return true
    --     end
    -- end

    return false
end

local function ActivateMissilePlatform()
    if not IsNull(mCrewShip) then
        RJ_UTIL.SetAllCrewShipExitMarkers(true, { mCrewShip })
        RJ_UTIL.SetCrewShipEnterMarker(true, mCrewShip)

        local coreDeco = RJ_UTIL.FindFirstTaggedOnShip(missileCoreTag, mCrewShip)

        if not IsNull(coreDeco) then
            local coreMarker = coreDeco:GetAttachment(crewshipObjectiveMarkerWRes)

            if not IsNull(coreMarker) and not coreMarker:IsEnabled() then
                coreMarker:Enable()
            end
        end
    end
end

local function SelectMissilePlatform()
    
    while mActiveMissileEncounterHint == nil do
        local randIndex = RandomInt(1, #mPotentialMissileEncounterHints) --net serialize this for migration.
        local platform = mPotentialMissileEncounterHints[randIndex]
        local platformState = platform:GetEncounterDynamicState()

        if platformState >= PLATFORM_SPAWNED and platformState < PLATFORM_DISABLED then
            mActiveMissileEncounterHint = platform
            
            local registeredAgents = mActiveMissileEncounterHint:GetRegisteredAgents()

            for i=1,#registeredAgents do
                local agent = registeredAgents[i]
                local avatar = agent:GetAvatar()

                if not IsNull(avatar) and avatar:IsA(gCrewShipAvatarType) then
                    mCrewShip = avatar:InventoryControl():GetActivePowerSuit()
                end
            end
        end
        
        Sleep(0)
    end
end

local function ShutDownDisableMissilePlatformObjective(hint)
    --Destroy crewships
    --set net variables back to 0.
    mAiDir:SetEnableAutoSpawns(false)
    gGameRules:SetNetPersistentVar(NV_RJ_DISABLE_MISSILE_PLATFORM, 1)
end

function ConsoleLocated()
    --gGameRules:GiveTransmissionAsyncToAllPlayers(crewShipIntroTransmission)
end

local function PlayDisableMissilePlatformIntro()
    --gGameRules:GiveTransmissionAsyncToAllPlayers(crewShipIntroTransmission)
end

local function OnModeStateChanged()
    if mModeState == WAITING_TO_START then
        SelectMissilePlatform()
    elseif mModeState == STARTED then
        ActivateMissilePlatform()
        PlayDisableMissilePlatformIntro() --Patrol ship transmissions
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/DisableMissilePlatform", 1)
        -- mAiDir:SetNpcHardCap(60) -- TC hack to get enemies to spawn inside the destroyers and cap ship while keeping fighters alive in space.
        mAiDir:SetAllowTeleportOldAgentsForNewSpawns(false)
    elseif mModeState == COMPLETE then
        RJ_UTIL.SetAllCrewShipExitMarkers(false, nil)
        RJ_UTIL.SetCrewShipEnterMarker(false, mCrewShip)
        _T.ObjectiveComplete()
    end
end

local function Initialize(hint)
    mHint = hint
    mTemplate = mHint:GetCurrentEncounterTemplate()
    mTransmissionSet = mTemplate:GetTransmissionSet()
    mPotentialMissileEncounterHints = gRegion:FindAll(missilePlatformHintWRes)

    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    if not IsNull(gGameRules) then
        --mAiSpec = capitalShipAiSpec
        local mission = gGameRules:GetMission()
        mAiSpec = mission.enemySpec
        if IsNull(mAiSpec) then
            mAiSpec = capitalShipAiSpec
            mission.enemySpec = capitalShipAiSpec
            gGameRules:SetMission(mission)
            mAiDir:AssignMissionAISpec(mAiSpec)
        end
    end

    local levelInfo = gRegion:GetLevelInfo()
    ObjectPortHandler(levelInfo, "NPCAlertStart")
    ObjectPortHandler(levelInfo, "NPCAlertEnd")
    --ObjectPortHandler(panelForwarder, "OnActivated")

    SetModeState(gGameRules:GetNetPersistentVar(NV_RJ_DISABLE_MISSILE_PLATFORM, NOT_STARTED))

    if mModeState == NOT_STARTED then
        SetModeState(WAITING_TO_START)
    elseif mModeState == WAITING_TO_START then

    elseif mModeState >= STARTED then
        
        --there must be an enc hint that we previously monitored, find that one.
        
        
    end
end

local function Update(deltaTime)
    local modeState = gGameRules:GetNetPersistentVar(NV_RJ_DISABLE_MISSILE_PLATFORM, NOT_STARTED)
    if modeState ~= mModeState then
        mModeState = modeState
        OnModeStateChanged(modeState)
    end

    if mModeState == WAITING_TO_START then
        if _T.IsCurrentObjective(mHint) then

            if not IsNull(mActiveMissileEncounterHint) then
                local platformState = mActiveMissileEncounterHint:GetEncounterDynamicState()

                if platformState >= PLATFORM_SPAWNED and platformState < PLATFORM_DISABLED then
                    SetModeState(STARTED)
                elseif platformState == PLATFORM_DISABLED then
                    SetModeState(COMPLETE)
                end
            end
            
            
        end
    elseif mModeState == STARTED then
        if not IsNull(mActiveMissileEncounterHint) then
            local missileHintState = mActiveMissileEncounterHint:GetEncounterDynamicState()
            if missileHintState == PLATFORM_DISABLED then 
                SetModeState(COMPLETE)
            end
        end
        

    elseif mModeState == COMPLETE then
        --increment railjackmanagernetvar to move onto the next mission.
    end
end

SetModeState = function(newState)
    if mModeState ~= newState then
        mModeState = newState
        gGameRules:SetNetPersistentVar(NV_RJ_DISABLE_MISSILE_PLATFORM, newState)
        OnModeStateChanged()
    else
        print("DisableMisslePlatform.lua::SetModeState - trying to set mode to state we're already in")
    end
end

function CanActivateDisableMisslePlatformEncounter()
    -- check if the proc system placed the correct rooms/objects in thte node. If not return false

    local missilePlatformHints = gRegion:FindAll(missilePlatformHintWRes)

    for i=1, #missilePlatformHints do
        local missileHint = missilePlatformHints[i]
        local missileHintState = missileHint:GetEncounterDynamicState()
        if missileHintState >= PLATFORM_SPAWNED and missileHintState < PLATFORM_DISABLED then
            return 1
        end
    end

    print("DisableMisslePlatform.lua::CanActivate - couldn't find any missile platforms in the level")
    return 0
end

function DisableMisslePlatform(hint)

    Broadcast("DisableMisslePlatform.lua -- Rescue Capital Ship Captive Objective Started")
    Initialize(hint)

    local sleepTime = UPDATE_INTERVAL

    while not ShouldShutDown() do
        Update(sleepTime)
        Sleep(sleepTime)
    end

    ShutDownDisableMissilePlatformObjective(hint)
end