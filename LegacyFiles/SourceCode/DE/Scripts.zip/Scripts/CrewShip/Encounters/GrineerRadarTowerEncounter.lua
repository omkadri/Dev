--ARGS
radarShipType = Type()

--LIBS
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local RAILOBJ = require "Lotus.Scripts.Libs.RailjackObjectiveUI"

--SYMBOLS
local sDisableRadarPortTag = Symbol("DisableRadarParts")

local sRadarScannerTowerTag = Symbol("RadarScannerTower")

local pointOfInterestAgentType = WeakResource("/Lotus/Types/Game/CrewShip/PointOfInterestAgent")

local exposeFirstWeakpointLoc = "/Lotus/Language/RailjackMissions/POIExposeFirstRadiator"
local destroyFirstWeakpointLoc = "/Lotus/Language/RailjackMissions/POIDestroyFirstRadiator"
local exposeSecondWeakpointLoc = "/Lotus/Language/RailjackMissions/POIExposeSecondRadiator"
local destroySecondWeakpointLoc = "/Lotus/Language/RailjackMissions/POIDestroySecondRadiator"
local destroyRadarArrayLoc = "/Lotus/Language/RailjackMissions/RadarTowerDestroyArray"

local subObjTrackerName = "RadarTower"

--CACHED VARS
local mGameRules = nil
local mAiDir = nil
local mHint = nil
local mHintPos = nil
local mHintActivationRadius = 0
local mDeactivateRadius = 0
local mParentHint = nil
local mTransmissionSet = nil
local mTimerMgr = nil
local mModeMgr = nil
local mSpawnMgr = nil
local mPlayers = nil
local mDisableRadarPortFwdr = nil

--STATES
local INVALID = 0
local STARTED = 1
local APPROACHED = 2
local EXPOSE_WP1 = 3
local DESTROY_WP1 = 4
local EXPOSE_WP2 = 5
local DESTROY_WP2 = 6
local DESTROY_CORE = 7
local DISABLED = 8

--VARS
local mCrewShip = nil
local mAvatar = nil
local mEnterAction = nil
local mFuseCounter = nil
local mFirstWeakpoint = nil
local mSecondWeakpoint = nil
local mFirstWeakpointAction = nil
local mSecondWeakpointAction = nil
local mCheatTracker = nil
--local mObjectiveTracker = nil
local mRadarComputerAction = nil
local mRadarScannerAbilityTrigger = nil

function CountReached(entity)
    if mModeMgr:GetModeState() ~= DESTROY_WP1 then
        mModeMgr:SetModeState(DESTROY_WP1)
    end
end

function FirePort(forwarder)
    if mModeMgr:GetModeState() == EXPOSE_WP2 then
        mModeMgr:SetModeState(DESTROY_WP2)
    elseif mModeMgr:GetModeState() == DESTROY_CORE then
        mModeMgr:SetModeState(DISABLED)
    end
end

function OnDisabled(entity)
    if entity == mFirstWeakpoint then
        mModeMgr:SetModeState(EXPOSE_WP2)
    elseif entity == mSecondWeakpoint then
        mModeMgr:SetModeState(DESTROY_CORE)
    end
end

local function CrewShipInitialize()
    local setupScript = gRegion:FindNearestTagged(Symbol("PoiSetupScript"), mHintPos)
    if not IsNull(setupScript) then
        setupScript:FirePort("Execute")
    else
        print("POI - Could not find setup script")
    end

    mDisableRadarPortFwdr = gRegion:FindFirstTagged(sDisableRadarPortTag)
    RAIL.SetCrewShipEnterMarker(true, mCrewShip)
    
    mSpawnMgr = RAIL.CreateSpawnMgr(mHint, mCrewShip)
    
    mFirstWeakpointAction = RAIL.FindFirstTaggedOnShip(Symbol("WeakpointConsole"), mCrewShip)
    mSecondWeakpointAction = RAIL.FindFirstTaggedOnShip(Symbol("WeakpointConsole2"), mCrewShip)
    local forwarder = gRegion:FindNearestTagged(Symbol("SuccessfulHackForwarder"), mSecondWeakpointAction:GetPosition())
    ObjectPortHandler(forwarder, "FirePort")
    
    local weakpoints = RAIL.FindTaggedInScope(Symbol("MissilePlatformWeakpoint"), mEnterAction:GetScope())
    table.sort(
        weakpoints,
        function(a, b)
            local posA, posB = a:GetPosition(), b:GetPosition()
            if posA.x == posB.x then
                if posA.y == posB.y then
                    return posA.z < posB.z
                else
                    return posA.y < posB.y
                end
            else
                return posA.x < posB.x
            end
        end
    )
    mFirstWeakpoint = weakpoints[1]
    mSecondWeakpoint = weakpoints[2]

    ObjectPortHandler(mFirstWeakpoint, "OnDisabled")
    ObjectPortHandler(mSecondWeakpoint, "OnDisabled")
    
    mFuseCounter = RAIL.FindFirstTaggedOnShip(Symbol("FuseCounter"), mCrewShip)
    ObjectPortHandler(mFuseCounter, "CountReached")
    
    mRadarComputerAction = RAIL.FindFirstTaggedOnShip(Symbol("RadarComputer"), mCrewShip)
    forwarder = gRegion:FindNearestTagged(Symbol("SuccessfulHackForwarder"), mRadarComputerAction:GetPosition())
    ObjectPortHandler(forwarder, "FirePort")
    
    --[[mObjectiveTracker = _T.GetHudTracker("MissilePlatformObjective" .. mAvatar:GetInstance())
    if IsNull(mObjectiveTracker) then
        mObjectiveTracker = _T.AddHudTracker("MissilePlatformObjective" .. mAvatar:GetInstance(), LOTUS_UTIL.HT_LABEL)
        mObjectiveTracker.SetVisible(false)
    end]]
    
    mCheatTracker = _T.AddHudTracker("Cheat", LOTUS_UTIL.HT_LABEL)
    local textOpen = "<p><font face=\"Noto Sans\" color=\"#FF0000\">"
    local textClose = "</font></p>"
    mCheatTracker.SetLabel(textOpen .. "LotusGameRules.MissionDebug ENABLED" .. textClose)
    mCheatTracker.SetVisible(false)
end

function ShipReady(ship)
    mCrewShip = ship
    mAvatar = mCrewShip:GetAvatarOwner()
    mHint:RegisterAgent(mAvatar:GetAgent())
    print("Spawned Sentient Fragment")
end

-- OnModeStateChanged - this is called immediately when state changes - use this function for setting up the state (UI changes, creating objects, etc)
-- This func is called after host migration, so you can recover from the state you migrated during
local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    
    if curState == STARTED then
        mAvatar:SetPosition(mHintPos)
        mEnterAction:Enable()
        print("Spawned radar Tower")
        
    elseif curState == EXPOSE_WP1 then
        mSpawnMgr:ShipBoarded()
        mFirstWeakpointAction:Enable()
        --mObjectiveTracker.SetVisible(true)
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(exposeFirstWeakpointLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, exposeFirstWeakpointLoc, RAILOBJ.GENERIC_ICON)
    
    elseif curState == DESTROY_WP1 then
        if gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug") then
            mTimerMgr:AddTimer(10, function() mFirstWeakpoint:Disable() end)
        end
        mFirstWeakpoint:Activate()
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(destroyFirstWeakpointLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, destroyFirstWeakpointLoc, RAILOBJ.ATTACK_ICON)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("WeakpointExposed"))
    
    elseif curState == EXPOSE_WP2 then
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(exposeSecondWeakpointLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, exposeSecondWeakpointLoc, RAILOBJ.GENERIC_ICON)
        mSecondWeakpointAction:Enable()
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("FirstWeakpointDestroyed"))
    
    elseif curState == DESTROY_WP2 then
        if gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug") then
            mTimerMgr:AddTimer(10, function() mSecondWeakpoint:Disable() end)
        end
        mSecondWeakpoint:Activate()
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(destroySecondWeakpointLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, destroySecondWeakpointLoc, RAILOBJ.ATTACK_ICON)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("WeakpointExposed"))
    
    elseif curState == DESTROY_CORE then
        --mObjectiveTracker.SetLabel(mObjectiveTracker.Localize(destroyRadarArrayLoc))
        RAILOBJ.SetSubObjective(mHint, subObjTrackerName, destroyRadarArrayLoc, RAILOBJ.ATTACK_ICON)
        mRadarComputerAction:Enable()
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("SecondWeakpointDestroyed"))
        
    elseif curState == DISABLED then
        --_T.RemoveHudTracker(mObjectiveTracker)
        RAILOBJ.RemoveObjective(mHint, subObjTrackerName)
        RAILOBJ.RemoveObjective(mHint)
        
        if not IsNull(mDisableRadarPortFwdr) then
            mDisableRadarPortFwdr:FirePort("TriggerPort")
        end

        if not IsNull(mRadarScannerAbilityTrigger) then
            mRadarScannerAbilityTrigger:FirePort("Disable")
        end

        RAIL.SetCrewShipEnterMarker(false, mCrewShip)
        RAIL.SetCrewShipExitMarker(true, mCrewShip)
        mHint:SetEncounterStatus(Npc.ES_COMPLETE)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("ObjectiveComplete"))
    end
end

-- Initialize - first thing that runs when a mission encounter starts - do your initial setup here. This is called again on migration.
-- Because gPromotedToHost is unreliable here, you will need to search for mission entities first, and create if not found (see mMissionObject)
local function Initialize(hint)
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    mGameRules = gGameRules
    mHint = hint
    mParentHint = hint:GetRootParentEncounterHint()
    mHintPos = hint:GetPosition()
    mHintActivationRadius = hint:GetActivationRadius()
    mDeactivateRadius = hint:GetDeactivationRadius()
    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()
    gRegion:AddPlayersChangedBasicCallback("OnPlayersChanged")
    mPlayers = gRegion:GetHumanPlayers()
    
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})
    mTimerMgr = TIMER.CreateTimerMgr()

    local scanners = gRegion:FindTagged(sRadarScannerTowerTag)

    for i=1, #scanners do
        local scanner = scanners[i]

        local parent = scanner:GetAttachParent()

        if not IsNull(parent) and parent == hint then
            mRadarScannerAbilityTrigger = scanner        
        end
    end
    
    --Mission specific initialization--
    mEnterAction = gRegion:FindNearestTagged(Symbol("EnterRadarTowerAction"), mHintPos)
    
    local netState = mHint:GetEncounterDynamicState()
    if netState > INVALID then
        --recover crewship/avatar after migration
        while IsNull(mCrewShip) do
            local registeredAgents = mHint:GetRegisteredAgents()
            for i, agent in ipairs(registeredAgents) do
                if agent:IsA(pointOfInterestAgentType) then
                    mAvatar = agent:GetAvatar()
                    mCrewShip = mAvatar:InventoryControl():GetActivePowerSuit()
                    break
                end
            end
            if IsNull(mCrewShip) then
                Sleep(0)
            end
        end
    else
        local crewShipMgr = gGameRules:GetCrewShipManager()
        crewShipMgr:CreateCrewShipFromType(radarShipType, nil, false, true, "ShipReady")
    end
    
    while IsNull(mCrewShip) do
        Sleep(0)
    end
    
    CrewShipInitialize()

    if netState > 0 and netState < DISABLED and not IsNull(mRadarScannerAbilityTrigger) then
        mRadarScannerAbilityTrigger:FirePort("Execute")
    end
    
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))
    hint:SetEncounterStatus(Npc.ES_ACTIVE)
end

--Main function - Contains main update loop, monitor mode state here
function Start(hint)
    Initialize(hint)
    
    local delta = 0
    local curState = INVALID
    local poiKillGoal  = 0
    while true do
        if gGameRules:MissionCompleted() or gGameRules:MissionFailed() or hint:GetEncounterStatus() >= Npc.ES_SUCCEEDED then
            break
        end
        
        if gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug") then
            mCheatTracker.SetVisible(true)
        else
            mCheatTracker.SetVisible(false)
        end

        delta = DeltaTime()
        curState = mModeMgr:GetModeState()
        
        if curState == STARTED then
            if RAIL.ArePlayersNearEntity(mEnterAction, RAIL.POI_APPROACH_DISTANCE) then
                DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("ObjectiveProximity"))
                mModeMgr:SetModeState(APPROACHED)
            end
            
        elseif curState == APPROACHED then
            local onShip = RAIL.GetPlayerAvatarsOnShip(mCrewShip)   --not great because its gets an array and counts it..
            if #onShip > 0 then
                mModeMgr:SetModeState(EXPOSE_WP1)
            end
        end

        if curState > STARTED then
            if IsNull(mCrewShip) then
                print("RadarTowerEncounter: Error:Can't find radar tower crewship")
            else
                if hint:CountPlayersInEncounter() > 0 and mAiDir:CountPlayersInRegion(mCrewShip:GetInteriorLayer()) > 0 then
                    mSpawnMgr:Update(delta)
                end
            end
        end
        
        if not mSpawnMgr.mCleanedUp and curState == DISABLED and mAiDir:CountPlayersInRegion(mCrewShip:GetInteriorLayer()) == 0 then
            mSpawnMgr:CleanUp()
        end

        mTimerMgr:Update(delta)
        
        Sleep(0)
    end

    mModeMgr:ShutDown()
    _T.RemoveHudTracker(mCheatTracker)
end

--CALLBACKS
function OnPlayersChanged()
    mPlayers = gRegion:GetHumanPlayers()
end

function DoorDebug(trigger)
    local enabled = true
    local hint = gRegion:FindNearestTagged(Symbol("DoorHint"), trigger:GetPosition())
    while not IsNull(trigger) do
        if enabled and not trigger:IsEnabled() then
            local text = "unlocked"
            if hint:GetDoorStatus() == Npc.NpcDoorHint_DS_LOCKED then
                text = "locked"
            end
            print("Trigger " .. trigger:GetFullName() .. " on radar tower has been disabled. " .. hint:GetFullName() .. " is " .. text)
        end
        Sleep(0)
    end
end
