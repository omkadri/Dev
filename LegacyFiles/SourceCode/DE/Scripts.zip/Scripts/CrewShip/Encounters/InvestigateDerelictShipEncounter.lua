derelictShipType = Type()
oroConsoleDecoTag = Symbol("")
portForwarderWRes = WeakResource()
consoleChance = 0.05

local NV_SPAWNED_CACHE = Symbol("NV_SPAWNED_CACHE")
local NV_CACHES_FOUND = Symbol("EnemyCachesFound")

local pointOfInterestAgentType = WeakResource("/Lotus/Types/Game/CrewShip/PointOfInterestAgent")

local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local UTIL = require "EE.Interface.Utilities"

local INVALID = 0
local STARTED = 1
local APPROACHED = 2
local ENTERED = 3
local REACHED_LOOT = 4
local FINALE = 5
local COMPLETE = 6

local UPDATE_INTERVAL = 0.1 -- How frequently we will tick 

local mHint = nil
local mHintPos = nil
local mHintActivationRadius = nil
local mGameRules = nil
local mAncientSpawner = nil
local mAiDir = nil
local mTransmissionSet = nil
local mTimerMgr = nil
local mModeMgr = nil
local mMineDestroyed = false
local mCrewShip = nil
local mCrewShipAvatar = nil
local mPlayersInDerelict = nil
local mBackToSpaceMarker = nil
local mEnterAction = nil
local mSpawnMgr = nil
local mSpawnedCache = false
local mConsole = nil
local mCacheRewardScript = nil

--TODO:SetDynamicMusicState from MusicFunctions.lua with StateNumber 10

function FirePort(forwarder)
    local modeState = mModeMgr:GetModeState()
    if modeState == REACHED_LOOT then
        return
    end
    
    mSpawnMgr:ResetSpawns()
    mGameRules:SetNetPersistentVar(NV_CACHES_FOUND, 1)
    mCacheRewardScript:FirePort("Execute")
    DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("CacheFound"))
    mBackToSpaceMarker = gRegion:FindFirstTagged(Symbol("BackToSpaceMarker"))
    if not IsNull(mBackToSpaceMarker) then
        mBackToSpaceMarker:Enable()
    end
    mModeMgr:SetModeState(REACHED_LOOT)
end

local function ActivateOroConsole()
    local layerIndex = mGameRules:GetNetPersistentVar(NV_SPAWNED_CACHE, 0)
    
    if mModeMgr:GetModeState() > INVALID and layerIndex == 0 then
        return  --migration, we've already rolled against spawning a cache
    end
    
    if math.random() > consoleChance and not gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug") then
        return  --no cache
    end

    local oroConsoleDecos = gRegion:FindTagged(oroConsoleDecoTag)
    local oroConsoleDeco = nil
    if layerIndex == 0 then
        local randomIndex = RandomInt(1, #oroConsoleDecos)
        oroConsoleDeco = oroConsoleDecos[randomIndex]

        layerIndex = oroConsoleDeco:GetZone():GetLayerIndex()
        mGameRules:SetNetPersistentVar(NV_SPAWNED_CACHE, layerIndex)
    else
        for i, deco in ipairs(oroConsoleDecos) do
            if deco:GetZone():GetLayerIndex() == layerIndex then
                oroConsoleDeco = deco
                break
            end
        end
    end

    if not IsNull(oroConsoleDeco) then
        local portForwarder = oroConsoleDeco:GetAttachment(portForwarderWRes)
        local successForwarder = gRegion:FindNearestTagged(Symbol("SuccessForwarder"), oroConsoleDeco:GetPosition())
        mCacheRewardScript = gRegion:FindNearestTagged(Symbol("OroDebrisCacheScript"), oroConsoleDeco:GetPosition())

        if not IsNull(portForwarder) then
            portForwarder:FirePort("TriggerPort")
        end

        if not IsNull(successForwarder) then
            ObjectPortHandler(successForwarder, "FirePort")
        end
        mSpawnedCache = true
        mConsole = oroConsoleDeco
        mAiDir:SetObjective(oroConsoleDeco)
    end
end

local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    if curState == STARTED then
        mCrewShipAvatar:SetPosition(mHintPos) 
        mEnterAction:Enable()
        
    elseif curState == ENTERED then
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("OnDerelict"))
        
    elseif curState == REACHED_LOOT then

    elseif curState == FINALE then
        
        if not IsNull(mAncientSpawner) then
            local agentType = mAiDir:GetRandomEnemyAgentType(Symbol("Infestation"), 30, false, false, 90, true)
            local agent = mAiDir:CreateAgent(agentType, mAncientSpawner, Symbol("RandomTeam"))
        end
    
    elseif curState == COMPLETE then
        mHint:SetEncounterStatus(Npc.ES_SUCCEEDED)
        mSpawnMgr:CleanUp()
        RAIL.SetCrewShipEnterMarker(false, mCrewShip)
        RAIL.SetCrewShipExitMarker(true, mCrewShip)
    end
end

local function ShouldShutDown()
    local curState = mModeMgr:GetModeState()
    if curState == COMPLETE then
        return true
    end
    
    if gGameRules:MissionCompleted() or gGameRules:MissionFailed() then
        return true
    end

    return false
end

local function Update(deltaTime)
    local curState = mModeMgr:GetModeState()
    if curState == STARTED then
        if RAIL.ArePlayersNearEntity(mEnterAction, RAIL.POI_APPROACH_DISTANCE) then
            DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("ObjectiveProximity"))
            mModeMgr:SetModeState(APPROACHED)
        end
        
    elseif curState == APPROACHED then
        mPlayersInDerelict = RAIL.GetPlayerAvatarsOnShip(mCrewShip)
        if not IsNull(mPlayersInDerelict) and #mPlayersInDerelict > 0 then
            mSpawnMgr:ShipBoarded()
            mModeMgr:SetModeState(ENTERED)
        end
        
    elseif curState == ENTERED then
        if not mSpawnedCache then
            mPlayersInDerelict = RAIL.GetPlayerAvatarsOnShip(mCrewShip)
            if IsNull(mPlayersInDerelict) or #mPlayersInDerelict <= 0  then
                mModeMgr:SetModeState(COMPLETE)
            end
        end
        
    elseif curState == REACHED_LOOT then 
        mPlayersInDerelict = RAIL.GetPlayerAvatarsOnShip(mCrewShip)
        
        if not IsNull(mAncientSpawner) then
            for i = 1, #mPlayersInDerelict do
                if mAncientSpawner:DistanceToEntity(mPlayersInDerelict[i]) < 60 then
                    mModeMgr:SetModeState(FINALE)
                    break
                end
            end
        else
            mModeMgr:SetModeState(COMPLETE)
        end
    elseif curState == FINALE then
        mPlayersInDerelict = RAIL.GetPlayerAvatarsOnShip(mCrewShip)
        if IsNull(mPlayersInDerelict) or #mPlayersInDerelict <= 0  then
            mModeMgr:SetModeState(COMPLETE)
        end
    elseif curState == COMPLETE then
        
    end
    
    mTimerMgr:Update(deltaTime)
    
    if curState >= STARTED  and curState < COMPLETE then
        mSpawnMgr:Update(deltaTime)
    end
end

function ShipReady(ship)
    if not IsNull(ship) then
        mCrewShip = ship
        mCrewShipAvatar = mCrewShip:GetAvatarOwner()
        mHint:RegisterAgent(mCrewShipAvatar:GetAgent())
    else
        LogBug("Failed to create ship!")
    end
end

local function DerelictInitialize()
    local setupScript = gRegion:FindNearestTagged(Symbol("PoiSetupScript"), mHintPos)
    if not IsNull(setupScript) then
        setupScript:FirePort("Execute")
    else
        print("POI - Could not find setup script")
    end
    
    RAIL.SetCrewShipEnterMarker(true, mCrewShip)
    mAncientSpawner = gRegion:FindFirstTagged(Symbol("AncientTankSpawner"))
    if not IsNull(mAncientSpawner) then
        mAncientSpawner:SetTag(Symbol("DoNotUse"))
    end
    
    mSpawnMgr = RAIL.CreateSpawnMgr(mHint, mCrewShip)
    mSpawnMgr:SetMinEnemyTotal(50)
    ActivateOroConsole()
end

local function Initialize(hint)
    mGameRules = gGameRules
    mHint = hint
    mHintPos = hint:GetPosition()
    mHintActivationRadius = hint:GetActivationRadius()
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()
    mEnterAction = gRegion:FindNearestTagged(Symbol("EnterOrokinTowerAction"), mHintPos)
    mTimerMgr = TIMER.CreateTimerMgr()
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    local netState = mHint:GetEncounterDynamicState()
    if netState > INVALID then
        --recover crewship/avatar after migration
        while IsNull(mCrewShip) do
            local registeredAgents = mHint:GetRegisteredAgents()
            for i, agent in ipairs(registeredAgents) do
                if agent:IsA(pointOfInterestAgentType) then
                    mCrewShipAvatar = agent:GetAvatar()
                    mCrewShip = mCrewShipAvatar:InventoryControl():GetActivePowerSuit()
                    break
                end
            end
            if IsNull(mCrewShip) then
                Sleep(0)
            end
        end
    else
        crewShipMgr:CreateCrewShipFromType(derelictShipType, nil, false, true, "ShipReady")
    end
    
    while IsNull(mCrewShip) do
        Sleep(0)
    end
    
    DerelictInitialize()
    
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))
    
    hint:SetEncounterStatus(Npc.ES_ACTIVE)
end

function InvestigateShip(hint)
    Broadcast("Investigate Derelict Ship Started")
    Initialize(hint)

    local sleepTime = UPDATE_INTERVAL

    while not ShouldShutDown() do
        Update(sleepTime)
        Sleep(sleepTime)
    end


end
