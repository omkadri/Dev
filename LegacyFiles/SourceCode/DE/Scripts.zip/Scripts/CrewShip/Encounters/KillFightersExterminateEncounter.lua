minorKillGoals = {35, 45, 55, 65} --kill goal = minorKillGoals[x] if maxSpaceLevel of mission <= spaceLevelThresholds[x]
spaceLevelThresholds = {15, 30, 45, 60 } --kill goal = minorKillGoals[x] if maxSpaceLevel of mission <= spaceLevelThresholds[x]
globalAlertLevelThresholds = { 0.25, 0.5 }

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
--local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local RAILOBJ = require "Lotus.Scripts.Libs.RailjackObjectiveUI"
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local NV_MINOR_KILL_COUNT = Symbol("NVMinorKillCount")
local sTenno = Symbol("TENNO")

local minorTargetsLoc = "/Lotus/Language/RailjackMissions/KillFightersObjective"

local STARTED = 1
local HALF_KILLED = 2
local COMPLETED = 10

local mHint = nil
local mModeMgr = nil
local mAiDir = nil
local mTransmissionSet = nil
local mMinorKillCount = 0
local mMinorKillGoal = 0

local function UpdateUI()
    --mMinorKillsTracker.SetLabel(mMinorKillsTracker.Localize(minorTargetsLoc) .. " " .. math.min(mMinorKillCount, mMinorKillGoal) .. "/" .. mMinorKillGoal)
    local killCountText = " " .. math.min(mMinorKillCount, mMinorKillGoal) .. "/" .. mMinorKillGoal
    RAILOBJ.SetMainObjective(mHint, minorTargetsLoc, killCountText)
end

local function OnDeath(dd)
    if mMinorKillCount >= mMinorKillGoal then
        return
    end
    
    local victim = dd:GetVictim()
    if IsNull(victim) then
        return
    end
       
    if not victim:IsFactionOriginalFriendly(sTenno) then
        if victim:IsA(gSpaceFighterBaseAvatarType) then
            mMinorKillCount = mMinorKillCount + 1
            gGameRules:SetNetPersistentVar(NV_MINOR_KILL_COUNT, mMinorKillCount)
        
            UpdateUI()
        end
    end
end

local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    if curState == STARTED then
        
    elseif curState == HALF_KILLED then
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("HalfFightersDestroyed"))
    end
end

local function ShutDownKillFightersExterminateObjective(hint)
    gGameRules:SetNetPersistentVar(NV_MINOR_KILL_COUNT, 0)
    RAILOBJ.RemoveObjective(mHint)
    --_T.RemoveHudTracker(mMinorKillsTracker)
    gGameRules:RemoveOnDeathCallback(OnDeath)
    --Sleep(3)
    --OBJTXT.RemoveObjProgressBar()
end

local function ShouldShutDown()
    local crewShipMgr = gGameRules:GetCrewShipManager()
    local ship = crewShipMgr:GetPlayerShip()
    local hintStatus = mHint:GetEncounterStatus() 

    if hintStatus >= Npc.ES_SUCCEEDED then
        return true
    end

    if not IsNull(ship) then
        local crewShipAvatar = ship:GetAvatarOwner()
        local hyperDriveState = crewShipAvatar:GetHyperDriveState()

        if hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_ACTIVE then
            return true
        end
    end
    
    return false
end

local function SetKillGoal()

    local maxSpaceLevel = mAiDir:GetSpaceMaxEnemyLevel()
    for i, int in ipairs(spaceLevelThresholds) do
        if maxSpaceLevel <= int then
            mMinorKillGoal = minorKillGoals[math.min(i, #minorKillGoals)]
            break
        end
    end
    
    _T.minorKillGoal = mMinorKillGoal
    
end

local function Initialize(hint)
    mHint = hint
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()

    local missionDebug = gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug")
    
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})

    gGameRules:RemoveOnDeathCallback(OnDeath)
    gGameRules:AddOnDeathCallback(OnDeath)

    local minorKillCount = gGameRules:GetNetPersistentVar(NV_MINOR_KILL_COUNT, 0)
    mMinorKillCount = minorKillCount

    SetKillGoal()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    --mMinorKillGoal = UTIL.Ternary(missionDebug, 1, minorKillGoals[numPlayers])
    --mMinorKillsTracker = _T.AddHudTracker("MinorKills", LOTUS_UTIL.HT_LABEL)

    UpdateUI()

    local netState = mHint:GetEncounterDynamicState()
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))

    if hint:GetEncounterStatus() == Npc.ES_SETUP then
        hint:SetEncounterStatus(Npc.ES_ACTIVE)
    end
end

function KillFightersExterminateObjective(hint)
    Initialize(hint)

    while not ShouldShutDown() do
        local goalRatio = mMinorKillCount / mMinorKillGoal
        
        if goalRatio >= 0.5 and mModeMgr:GetModeState() == STARTED then
            mModeMgr:SetModeState(HALF_KILLED)
        end
        
        local globalAlertLevel = mAiDir:GetGlobalAlertLevel()
        local newGlobalAlertLevel = globalAlertLevel
        
        for i, v in ipairs(globalAlertLevelThresholds) do
            if goalRatio >= v then
                --if i <= 2 or ( i > 2 and mHighLevelMission ) then --don't increase alert level past 2 if in low level mission
                    newGlobalAlertLevel = math.max(i, newGlobalAlertLevel)
                --end
            end
        end
        
        if ( newGlobalAlertLevel > globalAlertLevel ) then
            mAiDir:SetGlobalAlertLevel(newGlobalAlertLevel)
        end
        
        if goalRatio >= 1 and mModeMgr:GetModeState() ~= COMPLETED  then
            mAiDir:ModifyEncounterTagProbability(Symbol("FighterPatrol"), 0)
            DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("FightersObjectiveComplete"))
            RAILOBJ.RemoveObjective(mHint)
            mModeMgr:SetModeState(COMPLETED)
            gGameRules:RemoveOnDeathCallback(OnDeath)
        end
        
        Sleep(0)
    end

    ShutDownKillFightersExterminateObjective(hint)
end
