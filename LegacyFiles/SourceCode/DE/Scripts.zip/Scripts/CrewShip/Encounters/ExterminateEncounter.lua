alwaysActivateSubObjectiveTypes = { WeakResource() }
globalSubObjectiveEncounterTypes = { WeakResource() }
exterminateObjectiveEncounterHintType = Type()
poiEncounterHintType = Type()
numOfSubObjectivesToActivate = 2

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
--local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local PANIC = require "Lotus.Scripts.Libs.PanicLib"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local TABLE = require "Lotus.Scripts.Libs.TableLib"
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local NV_NUM_PLAYERS = Symbol("NVNumPlayers")

local objectiveLoc = "[HC] EXTERMINATE"

local STARTED = 1
local COMPLETED = 2

local mHint = nil
local mAiDir = nil
local mModeMgr = nil
local mMissionTransmissionSet = nil
local mCheatTracker = nil

local sTenno = Symbol("TENNO")
local sMissionIntro = Symbol("MissionIntro")
local sMissionOutro = Symbol("MissionOutro")
local sMissionFailed = Symbol("MissionFailed")
local sWarpTag = Symbol("WarpInSpot")
local sTierOnePoiTags = { Symbol("SentientFragment"), Symbol("GrineerGalleon"), Symbol("AsteroidBase") }
local sTierTwoPoiTags = { Symbol("MissilePlatform"), Symbol("AsteroidHangar"), Symbol("RadarTower"), Symbol("SuperWeapon") }

local mActiveObjectives = { }

local function PlayMissionFailed()
    if not IsNull(mHint) then
        local transmissionSet = mHint:GetCurrentEncounterTemplate():GetTransmissionSet()
        if not IsNull(transmissionSet) then
            _T.QueuedTransmissions = {}
            DIALOG.PlayGlobalTransmission(transmissionSet, sMissionFailed)
        end
    end
end

local function PlayMissionIntro()
    if not IsNull(mMissionTransmissionSet) then
        DIALOG.PlayGlobalTransmission(mMissionTransmissionSet, sMissionIntro)
    end
end

local function PlayMissionOutro()
    if not IsNull(mMissionTransmissionSet) then
        DIALOG.PlayGlobalTransmission(mMissionTransmissionSet, sMissionOutro)
    end
end

local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    if curState == STARTED then
        PlayMissionIntro()
    elseif curState == COMPLETED then
        for i=1, #mActiveObjectives do
            local subObj = mActiveObjectives[i]

            if not IsNull(subObj) then
                subObj:SetEncounterStatus(Npc.ES_SUCCEEDED)
            end
        end

        mHint:SetEncounterStatus(Npc.ES_SUCCEEDED)

        PlayMissionOutro()
    end
end

local function FindTransmissionSet()
    local exterminateObjectiveHints = gRegion:FindAll(poiEncounterHintType, ZERO_VECTOR, 0, FLT_MAX) 
    local poiTagList = { }
    local currentTransmissionHint = nil

    for i=1, #exterminateObjectiveHints do
        local poiHint = exterminateObjectiveHints[i]

        local encounterTags = poiHint:GetEncounterTags()

        for j=1, #encounterTags do
            local encounterTag = encounterTags[j]

            for k=1, #sTierOnePoiTags do
                if encounterTag == sTierOnePoiTags[k] then
                    local template = exterminateObjectiveHints[i]:GetCurrentEncounterTemplate()
                    while IsNull(template) do
                        Sleep(0)
                        template = exterminateObjectiveHints[i]:GetCurrentEncounterTemplate()
                    end
                    mMissionTransmissionSet = template:GetTransmissionSet()
                    return
                end
            end

            for k=1, #sTierTwoPoiTags do
                if encounterTag == sTierTwoPoiTags[k] then
                    if IsNull(currentTransmissionHint) then
                        currentTransmissionHint = exterminateObjectiveHints[i]
                        local template = currentTransmissionHint:GetCurrentEncounterTemplate()
                        while IsNull(template) do
                            Sleep(0)
                            template = currentTransmissionHint:GetCurrentEncounterTemplate()
                        end
                        mMissionTransmissionSet = template:GetTransmissionSet()
                    else
                        local possibleHint = exterminateObjectiveHints[i]
                        local startPos = gRegion:FindFirstTagged(sWarpTag):GetPosition()
                        local distanceToCurrentHint = Distance(startPos, currentTransmissionHint:GetPosition())
                        local distancetoPossibleHint = Distance(startPos, possibleHint:GetPosition())

                        if distancetoPossibleHint > distanceToCurrentHint then
                            currentTransmissionHint = possibleHint
                            mMissionTransmissionSet = currentTransmissionHint:GetCurrentEncounterTemplate():GetTransmissionSet()
                        end
                    end
                end
            end
        end
    end

    if IsNull(mMissionTransmissionSet) then
        mMissionTransmissionSet = mHint:GetCurrentEncounterTemplate():GetTransmissionSet()
    end
end

local function ShutDownExterminateEncounter(hint)

    --mission is aborted or failed. Play fail 
    if hint:GetEncounterStatus() ~= Npc.ES_SUCCEEDED then
        PlayMissionFailed()
    end

    for i=1, #mActiveObjectives do
        local subObj = mActiveObjectives[i]
        if not IsNull(subObj) then
            subObj:SetEncounterStatus(Npc.ES_SUCCEEDED)
        end
    end

    mAiDir:SetEnableAutoSpawns(false)
    gGameRules:SetNetPersistentVar(NV_NUM_PLAYERS, 0)
    --OBJTXT.RemoveObjProgressBar()
    --OBJTXT.ClearPrimaryObjText()
end

local function ShouldShutDown()
    local crewShipMgr = gGameRules:GetCrewShipManager()
    if IsNull(crewShipMgr) then
        return false
    end
    
    local ship = crewShipMgr:GetPlayerShip()
    if IsNull(ship) then
        return false
    end
    
    local crewShipAvatar = ship:GetAvatarOwner()
    local hyperDriveState = crewShipAvatar:GetHyperDriveState()
    local hintStatus = mHint:GetEncounterStatus() 

    if hintStatus >= Npc.ES_SUCCEEDED or (hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_ACTIVE) then
        return true
    end

    return false
end

local function Initialize(hint)
    mHint = hint
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})

    local numPlayers = gGameRules:GetNetPersistentVar(NV_NUM_PLAYERS, 0)
    if numPlayers == 0 then
        numPlayers = math.min(gRegion:GetHumanPlayerAvatarCount() + gFlashMgr:GetConfigInt("Server.NumVirtualTestClients"), 4) --gRegion:GetNumHumanPlayers()
        gGameRules:SetNetPersistentVar(NV_NUM_PLAYERS, numPlayers)
    end

    local dynstate = hint:GetEncounterDynamicState()
    if dynstate == 0 then
        --we haven't start before, so we need to find and start our subobjectives

        --TODO: need to check if we're coming from hosts migration.
        local exterminateObjectiveHints = gRegion:FindAll(exterminateObjectiveEncounterHintType, ZERO_VECTOR, 0, FLT_MAX) 
        local objectiveEncounterTypes = { }

        for i=1,#globalSubObjectiveEncounterTypes do
            table.insert(objectiveEncounterTypes, globalSubObjectiveEncounterTypes[i])
        end

        if #alwaysActivateSubObjectiveTypes > 0 then
            local objectivesToAdd = { }
            for i=1, #alwaysActivateSubObjectiveTypes do
                local encounterType = alwaysActivateSubObjectiveTypes[i]
                mAiDir:AddEncounter(encounterType)
                local objHint = mAiDir:ActivateSpecificEncounterAtPos(ZERO_VECTOR, encounterType, mHint, 0)

                if not IsNull(objHint) then
                    table.insert(mActiveObjectives, objHint)
                end
            end
        end

        while #mActiveObjectives < numOfSubObjectivesToActivate and
              (#objectiveEncounterTypes + #exterminateObjectiveHints) > 0 do
            
            local maxObjCount = #objectiveEncounterTypes + #exterminateObjectiveHints
            local randIndex = RandomInt(1, maxObjCount)

            if randIndex <= #objectiveEncounterTypes then
                local encounterType = objectiveEncounterTypes[randIndex]
                local objHint = mAiDir:ActivateSpecificEncounterAtPos(ZERO_VECTOR, encounterType, mHint, 0)

                if not IsNull(objHint) then
                    table.insert(mActiveObjectives, objHint)
                    table.remove(objectiveEncounterTypes, randIndex)
                end
            else
                randIndex = randIndex - #objectiveEncounterTypes
                if randIndex <= #exterminateObjectiveHints then
                    local encounterHint = exterminateObjectiveHints[randIndex]
                    local objHint = mAiDir:ActivateRandomEncounterAtSpecificHint(encounterHint, Npc.ET_NONE, 7, mHint, 0)

                    if not IsNull(objHint) then
                        table.insert(mActiveObjectives, objHint)
                        table.remove(exterminateObjectiveHints, randIndex)
                    end
                end    
            end
            Sleep(0)
        end
        hint:SetEncounterDynamicState(1)
    else 
        --we have started before, so lets find our active objectives from our child hintStatus
        while not mAiDir:HasEncounterMgrCompletedMigration() do
            Sleep(0)
        end
        mActiveObjectives = mHint:GetChildEncounters()
    end

    FindTransmissionSet()
   
    local missionDebug = gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug")
    
    --OBJTXT.SetPrimaryObjText(objectiveLoc)
    mCheatTracker = _T.AddHudTracker("Cheat", LOTUS_UTIL.HT_LABEL)
    local textOpen = "<p><font face=\"Noto Sans\" color=\"#FF0000\">"
    local textClose = "</font></p>"
    mCheatTracker.SetLabel(textOpen .. "LotusGameRules.MissionDebug ENABLED" .. textClose)
    mCheatTracker.SetVisible(false)

    local netState = mHint:GetEncounterDynamicState()
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))

    if hint:GetEncounterStatus() == Npc.ES_SETUP then
        hint:SetEncounterStatus(Npc.ES_ACTIVE)
    end
end

function ExterminateObjective(hint)
    Initialize(hint)

    while not ShouldShutDown() do
        local modeState = mModeMgr:GetModeState()
        local globalAlertLevel = mAiDir:GetGlobalAlertLevel()

        local subObjCompleted = 0
        for i=1,#mActiveObjectives do
            local subObj = mActiveObjectives[i]

            if not IsNull(subObj) and subObj:GetEncounterDynamicState() == RAIL.SUB_OBJECTIVE_COMPLETE then
                subObjCompleted = subObjCompleted + 1
            end
        end

        if subObjCompleted >= #mActiveObjectives then
            mModeMgr:SetModeState(COMPLETED)
        end

        Sleep(0)
    end

    ShutDownExterminateEncounter(hint)
end

function MarkerVisibility(marker)
    local localPlayer = gRegion:GetLocalPlayer()
    while IsNull(localPlayer) do
        Sleep(1)
        localPlayer = gRegion:GetLocalPlayer()
    end
    
    while not IsNull(marker) and not IsNull(localPlayer) do
        if marker:IsEnabled() then
            local av = localPlayer:GetAvatar()
            local ship = av:InventoryControl():GetOnBoardShip()
            if not IsNull(ship) then
                local faction = ship:GetAvatarOwner():GetFaction()
                local onEnemyShip = not av:IsFactionFriendly(faction)
                if marker:GetTargetVisibility() and onEnemyShip then
                    marker:SetTargetVisibility(false)
                    marker:SetDisplayOnMiniMap(false)
                elseif not marker:GetTargetVisibility() and not onEnemyShip then
                    marker:SetTargetVisibility(true)
                    marker:SetDisplayOnMiniMap(true)
                end
            elseif not marker:GetTargetVisibility() then
                marker:SetTargetVisibility(true)
                marker:SetDisplayOnMiniMap(true)
            end
        end
        Sleep(1)
    end
end