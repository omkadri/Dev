pitchIncreaseOnTargetDestroy = 0.05

local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"

local NV_CAPSHIP_STATE = Symbol("CAPSHIP_STATE")
local NOT_STARTED = 1
local STARTED = 2
local INFILTRATED = 3
local CORE_PILLARS_DESTROYED = 4
local EVACUATING_SHIP = 5
local COMPLETE = 6
local mModeState = INVALID
local SetModeState

local UPDATE_INTERVAL = 0.1 -- How frequently we will tick 

local mHint = nil
local mGameRules = nil

local function ShouldShutDown()
    if mModeState == COMPLETE then
        return true
    end

    local crewShipMgr = gGameRules:GetCrewShipManager()
    if not IsNull(crewShipMgr) then
        local ship = crewShipMgr:GetPlayerShip()
        local shipAvatar = ship:GetAvatarOwner()
        local hyperDriveState = shipAvatar:GetHyperDriveState()

        if hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_BOARDING or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP then
            return true
        end
    end

    return false
end

local function ShutDownCapitalShipEncounter(hint)
    mGameRules:SetNetPersistentVar(NV_CAPSHIP_STATE, 0)
end

local function OnModeStateChanged()

    if mModeState == STARTED then
        --do lotus vo
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/InfiltrateCapitalShip", 1)

        local shipEntranceMarker = gRegion:FindFirstTagged(Symbol("CapitalShipEntranceMarker"))
        if not IsNull(shipEntranceMarker) then
            shipEntranceMarker:Enable()
        end
    elseif mModeState == INFILTRATED then

        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/DestroyTheCorePillars", 1)

         local objMarker = gRegion:FindFirstTagged(Symbol("CoreRoomObjectiveMarker")) 
        if not IsNull(objMarker) then
            objMarker:Enable()

            local npcManager = gRegion:GetNpcMgr()
            local aiDir = npcManager:GetAiDirector()
            aiDir:SetObjective(objMarker)
            aiDir:SetEnableAutoSpawns(true)
        end

        --TODO: Get some VO that mentions: "Break Into The Core Room!"
    elseif mModeState == CORE_PILLARS_DESTROYED then
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/ShootTheExposedCore", 2)


        local coreExposedForwarder = gRegion:FindFirstTagged(Symbol("ShieldCoreExposedForwarder"))
        if not IsNull(coreExposedForwarder) then
            coreExposedForwarder:FirePort("TriggerPort")
        end

        local coreDeco = gRegion:FindFirstTagged(Symbol("ShieldCoreDeco"))
        if not IsNull(coreDeco) then
            coreDeco:ScriptRunChildScript(Symbol("CoreDecoFadeOut"), false)
        end

        local outsideMarker = gRegion:FindFirstTagged(Symbol("ShieldCoreOutsideTarget"))
        if not IsNull(outsideMarker) then
            outsideMarker:Enable()
        end

        local weakpointProj = gRegion:FindFirstTagged(Symbol("ObeliskWeakPointProj"))
        if not IsNull(weakpointProj) then
            weakpointProj:SetVisibility(true)
        end
        
        local objMarker = gRegion:FindFirstTagged(Symbol("CoreRoomObjectiveMarker")) 
        if not IsNull(objMarker) then
            objMarker:Disable()
        end

        local ordisPreFire = gRegion:FindFirstTagged(Symbol("OrdisPreFireVO"))
        if not IsNull(ordisPreFire) then
            ordisPreFire:Enable()
        end

    elseif mModeState == EVACUATING_SHIP then
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/ReturnToRailjack", 3)

        local outsideMarker = gRegion:FindFirstTagged(Symbol("ShieldCoreOutsideTarget"))
        if not IsNull(outsideMarker) then
            outsideMarker:Disable()
        end
        
        local weakpointProj = gRegion:FindFirstTagged(Symbol("ObeliskWeakPointProj"))
        if not IsNull(weakpointProj) then
            weakpointProj:SetVisibility(false)
        end
        
        local crpObeliskDeco = gRegion:FindFirstTagged(Symbol("CrpObeliskDeco"))
        if not IsNull(crpObeliskDeco) then
            crpObeliskDeco:MakeVulnerable()
        end
        
        local exitMarker = gRegion:FindFirstTagged(Symbol("ExitMarker")) 
        if not IsNull(exitMarker) then
            exitMarker:Enable()
        end
        
        local explosions = gRegion:FindFirstTagged(Symbol("CorpusShipInteriorExplosions"))
        if not IsNull(explosions) then
            explosions:Enable()
            explosions:FirePort("Execute")
        end
        
        local shieldCoreDestroyedForwarder = gRegion:FindFirstTagged(Symbol("ShieldCoreDestroyedForwarder"))
        if not IsNull(shieldCoreDestroyedForwarder) then
            shieldCoreDestroyedForwarder:FirePort("TriggerPort")
        end
    elseif mModeState == COMPLETE then
        _T.ObjectiveComplete()
    end

end

local function Initialize(hint)
    mGameRules = gGameRules

    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not aiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    SetModeState(mGameRules:GetNetPersistentVar(NV_CAPSHIP_STATE, NOT_STARTED))
    
    if mModeState == NOT_STARTED then
        SetModeState(STARTED)
    end
end

local function Update(deltaTime)
    local numOfTennoOnCapitalShip = RJ_UTIL.NumOfTennoOnCapitalShip()
    local modeState = mGameRules:GetNetPersistentVar(NV_CAPSHIP_STATE, NOT_STARTED)
    if modeState ~= mModeState then
        mModeState = modeState
        OnModeStateChanged(modeState)
    end

    if mModeState == STARTED and numOfTennoOnCapitalShip >= 1 then
        SetModeState(INFILTRATED)
    elseif mModeState == INFILTRATED then
        local targets = gRegion:FindTagged(Symbol("CoreRoomPillarTarget")) 
        local numTargets = #targets

        if numTargets == 0 then
            SetModeState(CORE_PILLARS_DESTROYED)
        end

        for i=numTargets,1,-1 do
            if IsNull(targets[i]) then
                table.remove(targets, i)
                numTargets = numTargets - 1

                local shieldOrb = gRegion:FindFirstTagged(Symbol("ShieldOrbSeq"))
                if not IsNull(shieldOrb) then
                    local shieldOrbSoundInstance = shieldOrb:GetSoundInstance()
                    if not IsNull(shieldOrbSoundInstance) then
                        local currentPitch = shieldOrbSoundInstance:GetPitch()
                        local newPitch = currentPitch + pitchIncreaseOnTargetDestroy
                        shieldOrbSoundInstance:SetPitch(newPitch)
                    end
                end

                if numTargets == 1 then
                    local voTrigger = gRegion:FindFirstTagged(Symbol("Ordis1MinVO"))
                    if not IsNull(voTrigger) then
                        voTrigger:FirePort("Execute")
                    end
                end
            end
        end

    elseif mModeState == CORE_PILLARS_DESTROYED then
        if _T.TennoConTargetHit then
            SetModeState(EVACUATING_SHIP)
        end
    elseif mModeState == EVACUATING_SHIP and numOfTennoOnCapitalShip < 1 then
        SetModeState(COMPLETE)
    end
end

SetModeState = function(newState)
    if IsNull(mGameRules) then
        mGameRules = gGameRules
    end    
    if mModeState ~= newState then
        mModeState = newState
        mGameRules:SetNetPersistentVar(NV_CAPSHIP_STATE, newState)
        OnModeStateChanged()
    else
        print("DestroyCapitalShipEncounter.lua::SetModeState - trying to set mode to state we're already in")
    end
end

function DestroyCapitalShip(hint)
    mHint = hint

    Broadcast("Destroy Capital Ship Encounter Started")

    while _T.IsCurrentObjective(hint) == false do
        Sleep(0)
    end

    Initialize(hint)

    local sleepTime = UPDATE_INTERVAL

    while not ShouldShutDown() do
        Update(sleepTime)
        Sleep(sleepTime)
    end

    ShutDownCapitalShipEncounter(hint)
end 
