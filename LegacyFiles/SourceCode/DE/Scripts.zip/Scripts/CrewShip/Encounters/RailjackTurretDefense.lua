doPlayerDistanceCheck = false
--playerDistance = 300

turretCountMin = 2
turretCountMax = 3
agentType = Type()
spawnPointTag = Symbol("TurretSpawner")
enemyFaction = Symbol("Grineer")

local mEnemyCrewShips = { }

local function PlayersInRange(hint, hintPos, hintDeactivateRadius)
    local nearestPlayer = gRegion:FindNearestPlayerAvatar(hintPos, hintDeactivateRadius)
    local railjackAvatar = gRegion:FindFirstTaggedInRadius(Symbol("RailJackAvatar"), hintPos, 0, hintDeactivateRadius)
    
    if not IsNull(nearestPlayer) or not IsNull(railjackAvatar) then
        return true
    end
    
    return false

end

function TurretDefense(hint)
    
    if IsNull(hint) then
        return
    end
    
    local npcMgr = gRegion:GetNpcMgr()
    local hintPos = hint:GetPosition()
    local hintDeactivateRadius = hint:GetDeactivationRadius()

    local dynstate = hint:GetEncounterDynamicState()
    if dynstate == 0 then
        
        local hintRadius = hint:GetActivationRadius()
        local hintSpawnRadius = hint:GetSpawnRadius()
        local aiDir = npcMgr:GetAiDirector()
        local level = aiDir:GetRandomSpaceEnemyLevel()
        local spawnPoints = gRegion:FindTaggedInRadius(spawnPointTag, hintPos, 0, hintSpawnRadius)

        local squadTeam = Symbol("RandomTeam")
        local spawnIndex = 0
        local spawner = nil
        local squadSize = math.min(RandomInt(turretCountMin, turretCountMax), #spawnPoints)

        for i = 1, squadSize do
            Sleep(0)

            spawnIndex = RandomInt(1, #spawnPoints)
            spawner = spawnPoints[spawnIndex]
            if not IsNull(spawner) then
                table.remove(spawnPoints, spawnIndex)
                
                local agent = aiDir:CreateAgent(agentType, spawner, squadTeam, level)
                Sleep(0)
                hint:RegisterAgent(agent)

                if i == 1 and not IsNull(agent) then
                    local name = agent:GetAvatar():GetFullName()
                    Broadcast(name)
                    squadTeam = Symbol(name)
                    agent:SetTeam(squadTeam)
                end
            else
                print("TURRET NULL SpawnPoint!")
            end
        end

        Broadcast("Patrol Spawned @" .. hint:GetName())
        hint:SetEncounterDynamicState(1)
    else
        -- after host migration agents should be registered already
        -- but we can just wait short moment before marking ourselves active 
        -- just in case we have any delays with replication
        Sleep(1)
    end
    
    hint:SetEncounterStatus(Npc.ES_ACTIVE)

    local numAlive = hint:GetNumRegisteredAgents()
    
    while ( numAlive > 0 and not hint:ShouldShutDown() and hint:GetEncounterStatus() ~= Npc.ES_SHUTDOWN ) do
        Sleep(1)
        numAlive = hint:GetNumRegisteredAgents()
        
        if doPlayerDistanceCheck and not IsNull(hint) then
            if not PlayersInRange(hint, hintPos, hintDeactivateRadius) then
                hint:SetEncounterStatus(Npc.ES_SHUTDOWN)
            end
        end
    end

    if hint:ShouldShutDown() or hint:GetEncounterStatus() == Npc.ES_SHUTDOWN then
        local agents = hint:GetRegisteredAgents()
        if not IsNull(agents) then
            for i = 1, #agents do
                if not IsNull(agents[i]) and not IsNull(agents[i]:GetAvatar()) then
                    agents[i]:GetAvatar():Destroy()
                    Sleep(0.1)
                end
            end
        end
        Broadcast("Patrol Shutdown @" .. hint:GetName())
        hint:SetEncounterStatus(Npc.ES_SHUTDOWN)
    else
        Broadcast("Patrol Destroyed @" .. hint:GetName())
        hint:SetEncounterStatus(Npc.ES_COMPLETE)
    end
    
end

function EnemyShipReady(enemyShip)
    if not IsNull(enemyShip) then
        table.insert(mEnemyCrewShips, enemyShip)
    end
end