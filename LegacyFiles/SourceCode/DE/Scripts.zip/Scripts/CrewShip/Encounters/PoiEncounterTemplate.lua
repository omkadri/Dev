--ARGS
crewShipType = Type()
enterActionTag = Symbol()

--LIBS
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local RAILOBJ = require "Lotus.Scripts.Libs.RailjackObjectiveUI"

--RESOURCES
local pointOfInterestAgentType = WeakResource("/Lotus/Types/Game/CrewShip/PointOfInterestAgent")
local replicatedHitSwitchRes = WeakResource("/EE/Types/Actions/ReplicatedHitSwitch")

--LOC

--SYMBOLS

--CACHED VARS
local mGameRules = nil
local mAiDir = nil
local mHint = nil
local mHintPos = nil
local mHintActivationRadius = 0
local mDeactivateRadius = 0
local mParentHint = nil
local mTransmissionSet = nil
local mTimerMgr = nil
local mModeMgr = nil
local mSpawnMgr = nil
local mPlayers = nil

--STATES
local INVALID = 0
local STARTED = 1
local APPROACHED = 2
local FIRST_OBJ = 3
local DISABLED = 10

--VARS
local mCrewShip = nil
local mAvatar = nil
local mEnterActions = {}
local mCrewShipMgr = nil
local mCheatTracker = nil
local subObjTrackerName = "PoiEncounter"

local function CrewShipInitialize()
    local setupScript = gRegion:FindNearestTagged(Symbol("PoiSetupScript"), mHintPos)
    if not IsNull(setupScript) then
        setupScript:FirePort("Execute")
    else
        print("POI - Could not find setup script")
    end
    
    RAIL.SetCrewShipEnterMarker(true, mCrewShip)
    mSpawnMgr = RAIL.CreateSpawnMgr(mHint, mCrewShip)
    local objectiveWaypoint = RAIL.FindFirstTaggedOnShip(Symbol("Objective"), mCrewShip)
    mAiDir:SetObjective(objectiveWaypoint)
    
    Sleep(0)
    
    mCheatTracker = _T.AddHudTracker("Cheat", LOTUS_UTIL.HT_LABEL)
    local textOpen = "<p><font face=\"Noto Sans\" color=\"#FF0000\">"
    local textClose = "</font></p>"
    mCheatTracker.SetLabel(textOpen .. "LotusGameRules.MissionDebug ENABLED" .. textClose)
    mCheatTracker.SetVisible(false)
end

function ShipReady(ship)
    if not IsNull(ship) then
        mCrewShip = ship
        mAvatar = mCrewShip:GetAvatarOwner()
        mHint:RegisterAgent(mAvatar:GetAgent())
    else
        LogBug("Failed to create ship!")
    end
end

-- OnModeStateChanged - this is called immediately when state changes - use this function for setting up the state (UI changes, creating objects, etc)
-- This func is called after host migration, so you can recover from the state you migrated during
local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    if curState == STARTED then
        mAvatar:SetPosition(mHintPos) 
        for i, action in ipairs(mEnterActions) do
            action:Enable()
        end
    
    elseif curState == DISABLED then
        --_T.RemoveHudTracker(mObjectiveTracker)
        RAILOBJ.RemoveObjective(mHint, subObjTrackerName)
        RAILOBJ.RemoveObjective(mHint)
        RAIL.SetCrewShipEnterMarker(false, mCrewShip)
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("ObjectiveComplete"))
    end
end

-- Initialize - first thing that runs when a mission encounter starts - do your initial setup here. This is called again on migration.
-- Because gPromotedToHost is unreliable here, you will need to search for mission entities first, and create if not found (see mMissionObject)
local function Initialize(hint)
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    mGameRules = gGameRules
    mHint = hint
    mParentHint = hint:GetRootParentEncounterHint()
    mHintPos = hint:GetPosition()
    mHintActivationRadius = hint:GetActivationRadius()
    mDeactivateRadius = hint:GetDeactivationRadius()
    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()
    gRegion:AddPlayersChangedBasicCallback("OnPlayersChanged")
    mPlayers = gRegion:GetHumanPlayers()
    
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})
    mTimerMgr = TIMER.CreateTimerMgr()
    
    mEnterActions = RAIL.FindTaggedInScope(enterActionTag, mHint:GetScope())
    
    local netState = mHint:GetEncounterDynamicState()
    if netState > INVALID then
        --recover crewship/avatar after migration
        while IsNull(mCrewShip) do
            local registeredAgents = mHint:GetRegisteredAgents()
            for i, agent in ipairs(registeredAgents) do
                if agent:IsA(pointOfInterestAgentType) then
                    mAvatar = agent:GetAvatar()
                    mCrewShip = mAvatar:InventoryControl():GetActivePowerSuit()
                    break
                end
            end
            if IsNull(mCrewShip) then
                Sleep(0)
            end
        end
    else
        mCrewShipMgr = gGameRules:GetCrewShipManager()
        mCrewShipMgr:CreateCrewShipFromType(crewShipType, nil, false, true, "ShipReady")
    end
    
    while IsNull(mCrewShip) do
        Sleep(0)
    end
    
    CrewShipInitialize()

    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))
    hint:SetEncounterStatus(Npc.ES_ACTIVE)
end

--Main function - Contains main update loop, monitor mode state here
function Start(hint)
    Initialize(hint)
    
    local delta = 0
    local curState = INVALID
    
    while true do
        if gGameRules:MissionCompleted() or gGameRules:MissionFailed() or hint:GetEncounterStatus() >= Npc.ES_SUCCEEDED then
            break
        end
        
        delta = DeltaTime() 
        curState = mModeMgr:GetModeState()
        
        if gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug") then
            mCheatTracker.SetVisible(true)
        else
            mCheatTracker.SetVisible(false)
        end
        
        if curState == STARTED then
            if RAIL.ArePlayersNearEntity(mEnterActions[1], RAIL.POI_APPROACH_DISTANCE) then
                DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("ObjectiveProximity"))
                mModeMgr:SetModeState(APPROACHED)
            end
            
        elseif curState == APPROACHED then
            
            local onShip = RAIL.GetPlayerAvatarsOnShip(mCrewShip)   --not great because its gets an array and counts it..
            if #onShip > 0 then
                mModeMgr:SetModeState(FIRST_OBJ)
            end
        end
        
        if curState > STARTED and mAiDir:CountPlayersInRegion(mCrewShip:GetInteriorLayer()) > 0 then
            mSpawnMgr:Update(delta)
        end
        
        if not mSpawnMgr.mCleanedUp and curState == DISABLED and mAiDir:CountPlayersInRegion(mCrewShip:GetInteriorLayer()) == 0 then
            mSpawnMgr:CleanUp()
        end

        mTimerMgr:Update(delta)
        
        Sleep(0)
    end

    _T.RemoveHudTracker(mCheatTracker)
    mModeMgr:ShutDown()
end

--CALLBACKS
function OnPlayersChanged()
    mPlayers = gRegion:GetHumanPlayers()
end
