--ARGS
attackMarkerType = Type()
attackAreaMarkerType = Type()

--LIBS
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local MODE = require "Lotus.Scripts.Libs.CommonGamemodeFunctions"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local RAILOBJ = require "Lotus.Scripts.Libs.RailjackObjectiveUI"

--RESOURCES
local pointOfInterestAgentType = WeakResource("/Lotus/Types/Game/CrewShip/PointOfInterestAgent")
local completionReward = Resource("/Lotus/Types/Items/MiscItems/SentientFragmentLootItem")

--LOC
local objectiveLoc = "/Lotus/Language/Railjack/KillSentients"

--SYMBOLS
local NV_POI_KILL_GOAL = Symbol("NVPoiKillGoal")
local NV_KILL_COUNT = Symbol("NVSentientFragmentKillCount")
local sHide = Symbol("Hide")
local sMissileCoreTag = Symbol("RJMissilePlatformCore")

--CACHED VARS
local mGameRules = nil
local mAiDir = nil
local mHint = nil
local mHintPos = nil
local mHintActivationRadius = 0
local mDeactivateRadius = 0
local mParentHint = nil
local mTransmissionSet = nil
local mTimerMgr = nil
local mModeMgr = nil
local mSpawnMgr = nil
local mPlayers = nil

--STATES
local STATE = {INVALID = 0, STARTED = 1, APPROACHED = 2, BOARDED = 3, COMPLETED = 4, DISABLED = 5} -- Main mission stages

--SETTINGS 
local fadeTime = 0.5

--VARS
local mCrewShip = nil
local mAvatar = nil
local mEnterAction = nil
local mDisableMarker = nil
local mDisableAction = nil
local mKillCount = 0 -- To Do: Host migration
local mKillGoal = 20 -- To Do: Scaling for after preview
local mPathingMarker = nil
local mAreaMarker = nil


local function UpdatePathingMarker(isEnabled)
    if IsNull(mPathingMarker) then
        local exitPoints = gRegion:FindTagged(Symbol("ExitShipAction"))
        for i, ep in ipairs(exitPoints) do
            local zone = ep:GetZone()
            if not IsNull(zone) and zone:GetTag() == Symbol("Exit") then
                local pos = ep:GetPosition()
                mPathingMarker = gRegion:CreateEntity(attackMarkerType, pos, ZERO_ROTATION)
                mPathingMarker:SetShowDistance(false)
            end
        end
    end
    if isEnabled ~= mPathingMarker:IsEnabled() then
        if isEnabled then
            mPathingMarker:FirePort("Enable")
        else
            mPathingMarker:FirePort("Disable")
        end
    end
end

local function UpdateUI()
    local killCountString = ": " .. math.min(mKillCount, mKillGoal) .. " / " .. mKillGoal
    RAILOBJ.SetSubObjective(mHint, "Kills", objectiveLoc, RAILOBJ.ATTACK_ICON, killCountString)
end

local function UpdateMarker()
    if mKillCount < mKillGoal then
        if mHint:GetNumRegisteredAgents()-1 == 0 then -- -1 to account for the sentient fragment agent
            
            UpdatePathingMarker(true)
            if not IsNull(mAreaMarker) then
                mAreaMarker:Destroy()
            end
        else
            UpdatePathingMarker(false)
            local registeredAgents = mHint:GetRegisteredAgents()
            local avatars = {}
            for i, agent in ipairs(registeredAgents) do
                local avatar = agent:GetAvatar()
                if avatar:IsA(gLotusNpcAvatarType) then
                    table.insert(avatars, avatar)
                end
            end
            if IsNull(mAreaMarker) then
                mAreaMarker = MODE.CreateAreaMarkerAroundEntities(attackAreaMarkerType, avatars, 30, 20)
            else
                MODE.UpdateAreaMarkerAroundEntities(mAreaMarker, avatars, 30, 20)
            end
        end
    else
        if not IsNull(mAreaMarker) then
            mAreaMarker:Destroy()
        end
        if not IsNull(mPathingMarker) then
            mPathingMarker:Destroy()
        end
    end
end

function OnKilled(avatar)
    if mKillCount < mKillGoal then
        local agent = avatar:GetAgent()
        if not IsNull(agent) and agent:GetOwningEncounter() == mHint then
            mKillCount = mKillCount + 1
            gGameRules:SetNetPersistentVar(NV_KILL_COUNT, mKillCount)
            UpdateUI()
            UpdateMarker()
        end
    end
end

local function OnSentientSpawn(agent)
    local avatar = agent:GetAvatar()
    ObjectPortHandler(avatar, "OnKilled")
    UpdateMarker()
end

-- OnModeStateChanged - this is called immediately when state changes - use this function for setting up the state (UI changes, creating objects, etc)
-- This func is called after host migration, so you can recover from the state you migrated during
local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    if curState == STATE.STARTED then
        local avatar = mCrewShip:GetAvatarOwner()
        avatar:SetPosition(mHintPos)
        
    elseif curState == STATE.BOARDED then
        mSpawnMgr:ShipBoarded()
        mSpawnMgr:SetAgentSpawnedCallback(OnSentientSpawn)        
        UpdateUI()
        UpdateMarker()

        -- Restore callbacks
        local agents = mHint:GetRegisteredAgents()
        for i, agent in ipairs(agents) do
            local avatar = agent:GetAvatar()
            if not IsNull(avatar) and avatar ~= mAvatar then
                agent:SetOwningEncounter(mHint)
                ObjectPortHandler(avatar, "OnKilled")
            end
        end
        
    elseif curState == STATE.COMPLETED then
        RAILOBJ.RemoveObjective(mHint, "Kills")
        RAILOBJ.RemoveObjective(mHint)
        mHint:SetEncounterStatus(Npc.ES_COMPLETE)
        
    elseif curState == STATE.DISABLED then
        
    end
end

-- Initialize - first thing that runs when a mission encounter starts - do your initial setup here. This is called again on migration.
-- Because gPromotedToHost is unreliable here, you will need to search for mission entities first, and create if not found (see mMissionObject)
local function Initialize(hint)
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    mGameRules = gGameRules
    mHint = hint
    mParentHint = hint:GetRootParentEncounterHint()
    mHintPos = hint:GetPosition()
    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()
    gRegion:AddPlayersChangedBasicCallback("OnPlayersChanged")
    mPlayers = gRegion:GetHumanPlayers()
    
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})
    mTimerMgr = TIMER.CreateTimerMgr()
    
    if gPromotedToHost then
        mKillCount = gGameRules:GetNetPersistentVar(NV_KILL_COUNT, 0)
    else
        gGameRules:SetNetPersistentVar(NV_KILL_COUNT, 0)
        mKillCount = 0 
    end
    
    local registeredAgents = mParentHint:GetRegisteredAgents()
    for i, agent in ipairs(registeredAgents) do
        if agent:IsA(pointOfInterestAgentType) then
            mAvatar = agent:GetAvatar()
            mCrewShip = mAvatar:InventoryControl():GetActivePowerSuit()
            break
        end
    end
    
    mEnterAction = gRegion:FindNearestTagged(Symbol("EnterPoiAction"), mHintPos)
    mDisableMarker = RAIL.FindFirstTaggedOnShip(Symbol("HangarDisableObjective"), mCrewShip)
    mDisableAction = RAIL.FindFirstTaggedOnShip(Symbol("HangarDisableAction"), mCrewShip)

    mSpawnMgr = RAIL.CreateSpawnMgr(mHint, mCrewShip)
    mSpawnMgr.mIgnoreNpcHardCap = true
    mSpawnMgr:SetMinEnemyTotal(mKillGoal)
    
    local netState = mHint:GetEncounterDynamicState()
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STATE.STARTED, netState))
    hint:SetEncounterStatus(Npc.ES_ACTIVE)
end

--Main function - Contains main update loop, monitor mode state here
function Start(hint)
    Initialize(hint)
    
    local delta = 0
    local curState = STATE.INVALID
    while true do
        if gGameRules:MissionCompleted() or gGameRules:MissionFailed() or hint:GetEncounterStatus() >= Npc.ES_SUCCEEDED then
            break
        end
        
        delta = DeltaTime()
        curState = mModeMgr:GetModeState()
        
        if curState == STATE.STARTED then
            if RAIL.ArePlayersNearEntity(mEnterAction, RAIL.POI_APPROACH_DISTANCE) then
                DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("ObjectiveProximity"))
                mModeMgr:SetModeState(STATE.APPROACHED)
            end
        
        elseif curState == STATE.APPROACHED then
            local onShip = RAIL.GetPlayerAvatarsOnShip(mCrewShip)   --not great because its gets an array and counts it..
            if #onShip > 0 then
            
                local gooSpawners = RAIL.FindTypeOnShip(WeakResource("/Lotus/Types/LevelObjects/Sentient/SpawnedObjects/GooSpawner"), mCrewShip)
                for i, sp in ipairs(gooSpawners) do 
                    sp:SetSourceObject(mHint)
                end
                
                mModeMgr:SetModeState(STATE.BOARDED)
            end
        
        elseif curState == STATE.BOARDED then
        
            if not IsNull(_T.GooAvatars) and #_T.GooAvatars > 0 then
                for i = #_T.GooAvatars, 1, -1 do
                    ObjectPortHandler(_T.GooAvatars[i], "OnKilled")
                    table.remove(_T.GooAvatars, i)
                end
            end
            
            if mKillCount >= mKillGoal then
                DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("ObjectiveComplete"))
                mModeMgr:SetModeState(STATE.COMPLETED)

                -- pay out sentient shard loot
                local humanPlayers = gRegion:GetHumanPlayers()
                for i = 1, #humanPlayers do
                    local player = humanPlayers[i] 
                    if not IsNull(player) and not IsNull(player:GetAvatar()) and player:IsActive() then
                        player:GetAvatar():InventoryControl():AddMiscItem(completionReward, 1)
                    end
                end

                gGameRules:SetNetPersistentVar(NV_KILL_COUNT, 0)
            end
        end
        
        if curState > STATE.STARTED then
            mSpawnMgr:Update(delta)
        end

        if not mSpawnMgr.mCleanedUp and curState == STATE.DISABLED and mAiDir:CountPlayersInRegion(mCrewShip:GetInteriorLayer()) == 0 then
            mSpawnMgr:CleanUp()
        end
        
        --local STATE = {INVALID = 0, STARTED = 1, BOARDED = 2, DISABLED = 3} -- Main mission stages

        mTimerMgr:Update(delta)
        
        Sleep(0)
    end

    gGameRules:SetNetPersistentVar(NV_KILL_COUNT, 0)
    mModeMgr:ShutDown()
end

--CALLBACKS
function OnPlayersChanged()
    mPlayers = gRegion:GetHumanPlayers()
end
