fighterEncounterType = WeakResource()

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local PANIC = require "Lotus.Scripts.Libs.PanicLib"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local TABLE = require "Lotus.Scripts.Libs.TableLib"
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local NV_RJ_EXTERMINATE_COUNT = Symbol("RJ_EXTERMINATE_COUNT")
local sFighterObj = Symbol("FighterObjectiveHint")
local sPatrolHint = Symbol("GrineerFighterPatrolHint")
local sCrewShipHint = Symbol("GrineerCrewShipPatrolEncounterHint")
local sTenno = Symbol("TENNO")
local sPoiMarker = Symbol("PoiMarker")
local sPoiHint = Symbol("PointOfInterestHint")
local sPoiAvatar = Symbol("PointOfInterestAvatar")

local pointOfInterestType = WeakResource("/Lotus/Types/Game/CrewShip/PointOfInterestAvatar")
local railjackAvatarType = WeakResource("/Lotus/Types/Game/CrewShip/RailJack/RailJackAvatar")

local objectiveMarkerType = Type("/Lotus/Types/Game/MarkerInfos/ObjectiveMarkerInfo")
local enemyMarkerInfoType = Type("/Lotus/Types/Game/MarkerInfos/EnemyObjectiveMarkerInfo")

local objectiveLoc = "[HC] EXTERMINATE"
local majorTargetsLoc = "[HC] MAJOR TARGETS DESTROYED: "
local minorTargetsLoc = "[HC] MINOR TARGETS DESTROYED: "
local boardPoiLoc = "[HC] BOARD THE POI"
local disablePoiLoc = "[HC] DISABLE THE POI"

local INVALID = 0
local STARTED = 1
local mModeState = INVALID

local mHint = nil
local mAiSpec = nil
local mAiDir = nil
local mModeMgr = nil
local mTemplate = nil
local mTransmissionSet = nil

local mMinorKillCount = 0
local mMajorKillCount = 0 
local mRailjackAvatar = nil
local mMinorKillsTracker = nil
local mMajorKillsTracker = nil
local mPoiHints = {}

local mMinorKillGoal = 100
local mMajorKillGoal = 3

local function UpdateUI()
    
end

function PoiHintStatusChanged(hint)
    if hint:GetEncounterStatus() == Npc.ES_COMPLETE then
        mMajorKillCount = mMajorKillCount + 1
        local marker = gRegion:FindNearestTagged(sPoiMarker, hint:GetPosition())
        marker:Disable()
        UpdateUI()
    end
end

function OnDeath(dd)
    local victim = dd:GetVictim()
    if IsNull(victim) then
        return
    end
       
    if not victim:IsFactionOriginalFriendly(sTenno) then
        mMinorKillCount = mMinorKillCount + 1
        UpdateUI()
    end
end

local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    if curState == STARTED then
        
    end
end

local function AddPoiTracker(hint)
    
    local tracker = _T.AddHudTracker("Poi" .. #mTrackers + 1, LOTUS_UTIL.HT_LABEL)
    
    table.insert(mTrackers, tracker)
end

local function Initialize(hint)
    mHint = hint
    mTemplate = mHint:GetCurrentEncounterTemplate()
    mTransmissionSet = mTemplate:GetTransmissionSet()
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    local crewShipMgr = gGameRules:GetCrewShipManager()
    mRailjackAvatar = crewShipMgr:GetPlayerShip():GetAvatarOwner()
    
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})

    gGameRules:AddOnDeathCallback("OnDeath")
    
    mPoiHints = gRegion:FindTagged(sPoiHint)
    for i, hint in ipairs(mPoiHints) do
        local marker = gRegion:FindNearestTagged(sPoiMarker, hint:GetPosition())
        marker:Enable()
        hint:RegisterStatusChangedCallback("PoiHintStatusChanged", Symbol("PoiHintCallback"))
        AddPoiTracker(hint)
    end
    
    OBJTXT.SetPrimaryObjText(objectiveLoc)
    mPoiTrackerA = _T.AddHudTracker("PoiA", LOTUS_UTIL.HT_LABEL)
    mPoiTrackerB = _T.AddHudTracker("PoiB", LOTUS_UTIL.HT_LABEL)
    mPoiTrackerC = _T.AddHudTracker("PoiC", LOTUS_UTIL.HT_LABEL)
    
    mPoiTrackerA.Localize("<CHECKMARK_OUTLINE>", {}, true)
    
    UpdateUI()
    
    mMajorKillGoal = #mPoiHints

    local netState = mHint:GetEncounterDynamicState()
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))

    if hint:GetEncounterStatus() == Npc.ES_SETUP then
        hint:SetEncounterStatus(Npc.ES_ACTIVE)
    end
end

function ExterminateObjective(hint)
    Initialize(hint)

    while hint:GetEncounterStatus() < Npc.ES_SUCCEEDED do
        local modeState = mModeMgr:GetModeState()
        if modeState == STARTED then
        
        end
        
        Sleep(0)
    end

    gGameRules:RemoveOnDeathCallback("OnDeath")
    Sleep(3)
    OBJTXT.RemoveObjProgressBar()
    OBJTXT.ClearPrimaryObjText()
end

function MarkerVisibility(marker)
    local localPlayer = gRegion:GetLocalPlayer()
    while IsNull(localPlayer) do
        Sleep(1)
        localPlayer = gRegion:GetLocalPlayer()
    end
    
    while not IsNull(marker) and not IsNull(localPlayer) do
        if marker:IsEnabled() then
            local av = localPlayer:GetAvatar()
            local ship = av:InventoryControl():GetOnBoardShip()
            if not IsNull(ship) then
                local faction = ship:GetAvatarOwner():GetFaction()
                local onEnemyShip = not av:IsFactionFriendly(faction)
                if marker:GetTargetVisibility() and onEnemyShip then
                    marker:SetTargetVisibility(false)
                    marker:SetDisplayOnMiniMap(false)
                elseif not marker:GetTargetVisibility() and not onEnemyShip then
                    marker:SetTargetVisibility(true)
                    marker:SetDisplayOnMiniMap(true)
                end
            elseif not marker:GetTargetVisibility() then
                marker:SetTargetVisibility(true)
                marker:SetDisplayOnMiniMap(true)
            end
        end
        Sleep(1)
    end
end