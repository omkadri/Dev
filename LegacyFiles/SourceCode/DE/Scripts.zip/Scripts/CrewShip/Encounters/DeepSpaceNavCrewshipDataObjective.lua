capitalShipAiSpec = Resource()
transmissionSet = Resource()

navBeaconObjectiveMarkerType = Type()
navBeaconPickupType = Type()

enemyFaction = Symbol("Grineer")
enemyTeam = Symbol("RandomTeam")
enemyTargetTier = 90
baseEnemyTargetType = Type()

crewShipType = Type()

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local PANIC = require "Lotus.Scripts.Libs.PanicLib"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local NOT_STARTED = 1
local STARTED = 2
local ACTIVE = 3
local ITEM_DROPPED = 4
local ITEM_OBTAINED = 5
local COMPLETE = 99
local mModeState = INVALID
local SetModeState

local UPDATE_INTERVAL = 0.1 -- How frequently we will tick 

local mParentHint = nil
local mHint = nil
local mAiSpec = nil
local mAiDir = nil

local mPilotAvatar = nil
local mCrewShip = nil
local mCrewShipAvatar = nil
local mPickup = nil

local mObjTracker = nil

local mTemplate = nil
local mTransmissionSet = nil

local killPilotLoc = "[HC] RETRIEVE COORDINATES FROM PILOT: "
local pickupLoc = "[HC] PICK UP COORDINATES: "
local pilotTag = Symbol("CrewShipPilot")

function NPCAlertStart(npc)
    PANIC.SetPanicLevel(PANIC.ALERT)
end

function NPCAlertEnd(npc)
    PANIC.SetPanicLevel(PANIC.UNALERT) 
end

local function _PilotKilled(avatar)
    local spawnPos = avatar:GetPosition()
    mPickup = gRegion:CreateEntity(navBeaconPickupType, spawnPos, ZERO_ROTATION)
    local marker = mPickup:GetAttachment(gBaseMarkerInfoType)

    if not IsNull(marker) then
        marker:Enable()
    end
end

local function OnKilled(avatar)
    if not IsNull(avatar) then 
        if avatar == mPilotAvatar then
            _PilotKilled(avatar)
        elseif avatar == mCrewShipAvatar then
            local pickUps = RJ_UTIL.FindTypeOnShip(navBeaconPickupType, mCrewShip)

            if #pickUps > 0 then
                for j=1, #pickUps do
                    local pickUp = pickUps[j]
                    pickUp:Teleport(avatar:GetPosition(), ZERO_ROTATION)
                end
            else
                _PilotKilled(avatar)
            end 
        end
    end
end

local function ShouldShutDown()
    local crewShipMgr = gGameRules:GetCrewShipManager()
    local ship = crewShipMgr:GetPlayerShip()
    local crewShipAvatar = ship:GetAvatarOwner()
    local hyperDriveState = crewShipAvatar:GetHyperDriveState()

    if mModeState == COMPLETE or (hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_ACTIVE) then
        return true
    end

    return false
end

local function ShutDownCrewshipDataObjective(hint)
    --Destroy crewships
    --set net variables back to 0.
    _T.RemoveHudTracker(mObjTracker)
    mAiDir:SetEnableAutoSpawns(false)
end

local function SetUpNavBeaconTarget()
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    local crewShips
    while IsNull(crewShips) do
        crewShips = crewShipMgr:GetShips(false)
        if IsNull(crewShips) or #crewShips == 0 then
            local query = gRegion:GetNpcMgr():GetAiDirector():EmptyTacQuery()
            local playerShip = crewShipMgr:GetShips(true)
            local playerShipAvatar = playerShip[1]:GetAvatarOwner()
            query = RJ_UTIL.GetSpawnPositionQuery(query, playerShipAvatar, Range(1500, 6000), 30)
            local points = query:GetPoints()

            if #points > 0 then
                local index = RandomInt(1, #points)
                local shipPos = points[index]
                mCrewShip = crewShipMgr:CreateCrewShipFromType(crewShipType, nil, false, false)
            end
        else
            mCrewShip = crewShips[SRandomInt(1, #crewShips)]
        end
        
        Sleep(5)
    end
    
    Sleep(0)

    if not IsNull(mCrewShip) then
        mCrewShipAvatar = mCrewShip:GetAvatarOwner()
        ObjectPortHandler(mCrewShipAvatar, "OnKilled")
        
        local pilot = RJ_UTIL.FindFirstTaggedOnShip(pilotTag, mCrewShip)
        
        if not IsNull(pilot) then
            mPilotAvatar = pilot            
            mPilotAvatar:Attach(navBeaconObjectiveMarkerType, EMPTY_SYMBOL)
            RJ_UTIL.SetCrewShipEnterMarker(true, mCrewShip)
        end
        
        local spawnPoints = RJ_UTIL.FindTypeOnShip(gNpcSpawnPointType, mCrewShip)
        local randIndex = RandomInt(1, #spawnPoints)
        local spawnPoint = spawnPoints[randIndex]

        if not IsNull(spawnPoint) and not IsNull(mCrewShipAvatar) then
            local mission = gGameRules:GetMission()
            local level = RandomInt(mission.minEnemyLevel, mission.maxEnemyLevel)
            local enemyTargetType = mAiDir:GetRandomEnemyAgentType(enemyFaction, level, true, false, enemyTargetTier, true)
            
            if IsNull(enemyTargetType) then
                Broadcast("Enemy target type is Nil -- AI Spec Issue? Tier: " .. enemyTargetTier)
                enemyTargetType = baseEnemyTargetType
            end
            
            local enemyTargetAgent = mAiDir:CreateAgent(enemyTargetType, spawnPoint, enemyTeam, level)

            local enemyTargetAvatar = enemyTargetAgent:GetAvatar()
            while IsNull(enemyTargetAvatar) do
                enemyTargetAvatar = enemyTargetAgent:GetAvatar()
                Sleep(0)
            end

            ObjectPortHandler(enemyTargetAvatar, "OnKilled")
            mHint:RegisterAgent(enemyTargetAgent)
            
            local targetMarkers = enemyTargetAvatar:GetAllAttachments(navBeaconObjectiveMarkerType)
            for j=1, #targetMarkers  do
                local marker = targetMarkers[j] 
                if not IsNull(marker) and not marker:IsEnabled() then
                    marker:Enable()
                end
            end
            
            RJ_UTIL.SetCrewShipExitMarker(true, mCrewShip) 
        end
    end
end

local function OnModeStateChanged()
    if mModeState == STARTED then
        SetUpNavBeaconTarget()
        mObjTracker = _T.AddHudTracker("KillObjective", LOTUS_UTIL.HT_LABEL)
        mObjTracker.SetLabel(mObjTracker.Localize(killPilotLoc) .. 0 .. "/" .. 1)
    elseif mModeState == ACTIVE then
    elseif mModeState == ITEM_DROPPED then
        mObjTracker.SetLabel(mObjTracker.Localize(pickupLoc) .. 0 .. "/" .. 1)
    elseif mModeState == ITEM_OBTAINED then
        _T.RemoveHudTracker(mObjTracker)
    elseif mModeState == COMPLETE then
        if not IsNull(mCrewShip) then
            RJ_UTIL.SetCrewShipEnterMarker(false, mCrewShip)
            RJ_UTIL.SetCrewShipExitMarker(false, mCrewShip)
        end
        mHint:SetEncounterStatus(Npc.ES_SUCCEEDED)
    end
end

local function Initialize(hint)
    mHint = hint
    mTemplate = mHint:GetCurrentEncounterTemplate()
    mTransmissionSet = mTemplate:GetTransmissionSet()
    
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    mParentHint = hint:GetParentEncounterHint()
    if IsNull(mParentHint) then
        return 0
    end
    
    while not mParentHint:GetEncounterStatus() == Npc.ES_ACTIVE do
        Sleep(0)
    end

    if not IsNull(gGameRules) then
        --mAiSpec = capitalShipAiSpec
        local mission = gGameRules:GetMission()
        mAiSpec = mission.enemySpec
        if IsNull(mAiSpec) then
            mAiSpec = capitalShipAiSpec
            mission.enemySpec = capitalShipAiSpec
            gGameRules:SetMission(mission)
            mAiDir:AssignMissionAISpec(mAiSpec)
        end
    end

    local levelInfo = gRegion:GetLevelInfo()
    ObjectPortHandler(levelInfo, "NPCAlertStart")
    ObjectPortHandler(levelInfo, "NPCAlertEnd")

    SetModeState(STARTED)
end

local function Update(deltaTime)
    if mModeState == STARTED then
        if not IsNull(mPilotAvatar) then
            SetModeState(ACTIVE)
        end
    elseif mModeState == ACTIVE then
        if IsNull(mCrewShipAvatar) or mCrewShipAvatar:IsKilled() then
            OnKilled(mCrewShipAvatar)
            SetModeState(ITEM_DROPPED)
        elseif IsNull(mPilotAvatar) or mPilotAvatar:IsKilled() then
            OnKilled(mPilotAvatar)
            SetModeState(ITEM_DROPPED)
        end
    elseif mModeState == ITEM_DROPPED then
        -- TODO: NEEDS BETTER SOLUTION
        if IsNull(mPickup) then
            SetModeState(ITEM_OBTAINED)
        end
    elseif mModeState == ITEM_OBTAINED then
    elseif mModeState == COMPLETE then
    end
end

SetModeState = function(newState)
    if mModeState ~= newState then
        mModeState = newState
        mHint:SetEncounterDynamicState(newState)
        OnModeStateChanged()
    else
        print("DeepSpaceNavCrewshipDataObjective.lua::SetModeState - trying to set mode to state we're already in")
    end
end

function CanActivateCrewshipDataObjective(hint)
    local parentHint = hint:GetParentEncounterHint()
    if IsNull(parentHint) then
        return 0
    end
    
    local playerAvatars = gRegion:GetHumanPlayerAvatars()
    local crewshipMgr = gGameRules:GetCrewShipManager()
    local ships = crewshipMgr:GetShips(false)
    for i=1, #ships do
        local ship = ships[i]

        local playerFound = false
        if not IsNull(ship) then
            for i=1, #playerAvatars do
                local playerAvatar = playerAvatars[i]

                if not IsNull(playerAvatar) and ship:IsEntityOnBoardShip(playerAvatar) then
                    playerFound = true
                    break
                end
            end

            if not playerFound then
                return 1
            end
        end
    end

    return 0
end

function CrewShipNavDataEncounter(hint)

    Broadcast("DeepSpaceNavCrewshipDataObjective.lua -- Deep Space Crewship Objective Started")
    Initialize(hint)

    local sleepTime = UPDATE_INTERVAL

    while not ShouldShutDown() do
        Update(sleepTime)
        Sleep(sleepTime)
    end

    ShutDownCrewshipDataObjective(hint)
end