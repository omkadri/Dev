capitalShipAiSpec = Resource()
captainBossTier = 93
captainTargetObjectiveMarker = WeakResource()
interiorShipRegionIndex = 1
crewShipIntroTransmission = WeakResource()
shieldGeneratorDecoType = Type()
capitalShieldTimer = 60

galleonDeathAnim = Resource()
turretAvatarType = WeakResource()
isGalleonDeathTest = false

galleonEnterExitAction = WeakResource()

bossIntroMovie = Resource()
bossIntroMovieDelay = 0

transmissionSet = Resource()

validSubObjectives = { WeakResource() }
numOfSubObjectives = 1
activateSubObjectiveTimerMin = 40
activateSubObjectiveTimerMax = 60

enemyFaction = Symbol("Grineer")
enemyTeam = Symbol("RandomTeam")

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local PANIC = require "Lotus.Scripts.Libs.PanicLib"

local NV_KILL_CAPITAL_CAPTAIN_STATE = Symbol("KILL_CAPITAL_CAPTAIN_STATE")
local NV_GALLEON_NODE_COUNT = Symbol("GALLEON_NODE_COUNT")

local NOT_STARTED = 1
local STARTED = 2
local ENTERED = 3
local BOSS_SPAWNED = 4
local BOSS_COMBAT = 5
local BOSS_KILLED = 6
local COMPLETE = 99
local mModeState = INVALID
local SetModeState

local NV_SUB_OBJECTIVE_STATE = Symbol("SUB_OBJECTIVE_STATE")
local NV_NUM_OF_SUB_OBJECTIVES = Symbol("NUM_OF_SUB_OBJECTIVES")

-- local NOT_STARTED = 1
-- local STARTED = 2
-- local COMPLETE = 3
local mSubObjectiveState = NOT_STARTED
local SetSubObjectivesState 

local UPDATE_INTERVAL = 0.1 -- How frequently we will tick 

local mHint = nil
local mAiSpec = nil
local mAiDir = nil
local mCaptainBossAgent = nil
local mCaptainAvatar = nil
local mShieldGeneratorDeco = nil
local mBossSpawnTrigger = nil
local mActivateSubObjectiveTimer = 0

local mActiveSubObjectiveHint = nil
local mCompleteSubObjectives = { }

local mTemplate = nil
local mTransmissionSet = nil

local approachPlayed = false
local generatorOnePlayed = false
local generatorTwoPlayed = false
local bossHalfHealthPlayed = false
local stormWarningPlayed = false
local firstVoidWarningPlayed = false
local finalVoidWarningPlayed = false

local assassinateMarkerType = Type("/Lotus/Types/Enemies/CaptureTargets/CaptureTargetObjectiveMarker")
local captainBossAgentType = Type("/Lotus/Types/Enemies/Grineer/RailJack/GrnGalleonCommanderAgent")

local sGalleonCommanderAvatar = Symbol("GalleonCommanderAvatar")

function NPCAlertStart(npc)
    PANIC.SetPanicLevel(PANIC.ALERT)
end

function NPCAlertEnd(npc)
    PANIC.SetPanicLevel(PANIC.UNALERT) 
end

function OnDamaged(deco)
    --Detected()
end

function OnDestroyed(deco)

end

function OnKilled(avatar)
    if IsNull(avatar) then
        return
    end
    
    if mCaptainBossAgent:GetAvatar() == avatar or avatar:GetTag() == sGalleonCommanderAvatar then
        gGameRules:SetNetPersistentVar(NV_KILL_CAPITAL_CAPTAIN_STATE, BOSS_KILLED)
    end
end

function OnDeath(dd)
    local victim = dd:GetVictim()
    if IsNull(victim) then
        return
    end
    
    local faction = victim:GetOriginalFaction()
end

local function _GalleonDeath()
    local delay = 20
    if isGalleonDeathTest then
        delay = 0
    end
    Sleep(delay) -- delay before the Galleon starts to fall out of the sky
    local galleon = gRegion:FindFirstTagged(Symbol("AnimatedGalleonEntity"))
    if not IsNull(galleon) then
        local turrets = gRegion:FindAll(turretAvatarType)
        if not IsNull(turrets) then
            for i = 1, #turrets do
                --turrets[i]:attachToInPlace(galleon, Symbol())
                turrets[i]:Destroy()
            end
        end
        galleon:PlayAnimation(galleonDeathAnim, true, false, 0, Symbol(), 0.75)
        
        local t = 0
        while t < 2 do
            galleon:SetDissolve(t)
            t = t + DeltaTime()
            Sleep(0)
        end
        --galleon:SetVisibility(false, true)
    end
end

local function Closest(objects,pos,minRange)
    local closestDist = FLT_MAX
    local furthestDist = 0
    local closest
    local furthest
    for i = 1, #objects do
        local dist = objects[i]:DistanceToPoint(pos)
        if dist < closestDist and dist > minRange then
            closest = objects[i]
            closestDist = dist
        end
        if dist > furthestDist then
            furthest = objects[i]
            furthestDist = dist
        end
    end
    
    local result = closest
    if IsNull(result) then
        result = furthest   
    end
    return result
end

local function DisablePanicButtons()
    local panicButtons = gRegion:FindTagged(Symbol("PanicButton"))
    for i = 1, #panicButtons do
        if not IsNull(panicButtons[i]) then
            panicButtons[i]:Disable()
        end
    end
end


local function ShouldShutDown()
    local crewShipMgr = gGameRules:GetCrewShipManager()
    local ship = crewShipMgr:GetPlayerShip()
    local crewShipAvatar = ship:GetAvatarOwner()
    local hyperDriveState = crewShipAvatar:GetHyperDriveState()

    if mModeState == COMPLETE or (hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_ACTIVE) then
        return true
    end

    return false
end

local function GetTennoInInteriorShip()
    local avatars = gRegion:GetHumanPlayerAvatars()
    local playersInInterior = { }

    for i=1,#avatars do
        local avatar = avatars[i]

        if not IsNull(avatar) then
            local avatarZone = avatar:GetZone()
        
            if not IsNull(avatarZone) then
                local avatarRegionIndex = avatarZone:GetRegionIndex()

                if avatarRegionIndex == interiorShipRegionIndex then
                    table.insert(playersInInterior, avatar)
                end
            end
        end
    end

    return playersInInterior
end

local function ShutDownCapitalShipStateEncounter(hint)
    --Destroy crewships
    --set net variables back to 0.
    mAiDir:SetEnableAutoSpawns(false)
    gGameRules:SetNetPersistentVar(NV_KILL_CAPITAL_CAPTAIN_STATE, NOT_STARTED)
    gGameRules:SetNetPersistentVar(NV_SUB_OBJECTIVE_STATE, 1)
    gGameRules:SetNetPersistentVar(NV_GALLEON_NODE_COUNT, 0)
    gGameRules:SetNetPersistentVar(NV_NUM_OF_SUB_OBJECTIVES, 0)
end

local function PlayCrewShipPatrolIntro()
    gGameRules:GiveTransmissionAsyncToAllPlayers(crewShipIntroTransmission)
end

local function OnModeStateChanged()
    if mModeState == NOT_STARTED then
        PlayCrewShipPatrolIntro() --Patrol ship transmissions
        OBJTXT.SetTitleObjText("/Lotus/Language/Railjack/KillTheCaptain", nil, nil, OBJTXT.FONT_S)
        --OBJTXT.SetSubTitleObjText("/Lotus/Language/EidolonPlains/JobStageTracker", stageCountString)                            
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/ReachTheGalleon", 1)

        RJ_UTIL.SetAllCrewShipExitMarkers(true, nil)
        local capitalEntranceMarker = gRegion:FindFirstTagged(Symbol("CapitalShipEntranceMarker"))
        if not IsNull(capitalEntranceMarker) then
            capitalEntranceMarker:Enable()
        end

        local galleonDeco = gRegion:FindFirstTagged(Symbol("GalleonShipDeco"))
        if not IsNull(galleonDeco) then
            local enterShipActions = galleonDeco:GetAllAttachments(galleonEnterExitAction)
            
            for i=1, #enterShipActions do
                local enterShipAction = enterShipActions[i]

                if not IsNull(enterShipAction) and enterShipAction:IsEnabled() then
                    enterShipAction:Disable()
                end
            end
        end
    elseif mModeState == STARTED then
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/InfiltrateTheCapitalShip", 1)

        RJ_UTIL.SetAllCrewShipExitMarkers(true, nil)
        local capitalEntranceMarker = gRegion:FindFirstTagged(Symbol("CapitalShipEntranceMarker"))
        if not IsNull(capitalEntranceMarker) then
            capitalEntranceMarker:Enable()
        end

        local galleonDeco = gRegion:FindFirstTagged(Symbol("GalleonShipDeco"))
        if not IsNull(galleonDeco) then
            local enterShipActions = galleonDeco:GetAllAttachments(galleonEnterExitAction)
            
            for i=1, #enterShipActions do
                local enterShipAction = enterShipActions[i]

                if not IsNull(enterShipAction) and not enterShipAction:IsEnabled() then
                    enterShipAction:Enable()
                end
            end
        end

        mAiDir:SetNpcHardCap(60) -- TC hack to get enemies to spawn inside the destroyers and cap ship while keeping fighters alive in space.
        mAiDir:SetAllowTeleportOldAgentsForNewSpawns(false)
        
    elseif mModeState == ENTERED then 
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/AssassinateTheCaptain", 2) 
        
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("CephalonCyBoardGalleon"))

        --TODO: Replace these transmissions with some new ones from our "generic commander" agent
        -- DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("CommanderApproach03"))
        -- DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("CommanderApproach04"))
        DisablePanicButtons()
        
        mBossSpawnTrigger = gRegion:FindFirstTagged(Symbol("RailjackCaptainSpawnTrigger"))
        ObjectPortHandler(mBossSpawnTrigger, "OnTouched")
        
        local assassinateMarker = gRegion:CreateEntity(assassinateMarkerType, mBossSpawnTrigger:GetPosition(), ZERO_ROTATION)
        --local assassinateMarker = bossSpawnTrigger:Attach(assassinateMarkerType, EMPTY_SYMBOL)
        assassinateMarker:SetDisplayRange(Range(0,1000))
        mAiDir:SetObjective(assassinateMarker)
        mAiDir:SetEnableAutoSpawns(true)
        --assassinateMarker:AttachTo(bossSpawnTrigger, EMPTY_SYMBOL)
        --assassinateMarker:SetDisplayRestriction(Lotus_Game.BaseMarkerInfo_DR_NONE)
    elseif mModeState == BOSS_SPAWNED then
        --spawn boss
        mAiDir:SetEnableAutoSpawns(false)
        local mission = gGameRules:GetMission()
        local level = RandomInt(mission.minEnemyLevel, mission.maxEnemyLevel)
        local captainBossType = mAiDir:GetRandomEnemyAgentType(enemyFaction, level, true, false, captainBossTier, true)
        local spawnPoint = gRegion:FindFirstTagged(Symbol("CaptainBossSpawn"))
        if level < 30 then
            level = 30
        end
        
        if IsNull(captainBossType) then
            Broadcast("Captain Boss Type is Nil -- AI Spec Issue? Tier: " .. captainBossTier)
            captainBossType = captainBossAgentType
        end
        
        mCaptainBossAgent = mAiDir:CreateAgent(captainBossType, spawnPoint, enemyTeam, level)

        mCaptainAvatar = mCaptainBossAgent:GetAvatar()
        while IsNull(mCaptainAvatar) do
            mCaptainAvatar = mCaptainBossAgent:GetAvatar()
            Sleep(0)
        end
        
        SetModeState(BOSS_COMBAT)
        --DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("CommanderSpawned"))
        
    elseif mModeState == BOSS_COMBAT then
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/KillTheCaptain", 2) 
        --DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("CommanderApproach05"))

        mCaptainBossAgent:SetAlert()
        ObjectPortHandler(mCaptainAvatar, "OnKilled")

        mAiDir:SetObjective(mCaptainAvatar)
        
        local captureDoorHints = gRegion:FindTagged(Symbol("CaptureDoorHint"))
        local zone = mCaptainBossAgent:GetAvatar():GetZone()
        
        while IsNull(zone) do
            zone = mCaptainBossAgent:GetAvatar():GetZone()
            Sleep(0)
        end
        local zoneTag = zone:GetTag()
        
        captureDoorHints = RJ_UTIL.ZoneCheckArray(zoneTag, captureDoorHints)
        for i = 1, #captureDoorHints do
            captureDoorHints[i]:FirePort("Unlock")
        end

        --set desired position to middle of the boss room
        
    elseif mModeState == BOSS_KILLED then
        _T.TennoConDemoBossKilled = true
        DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("BossKilled"))
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/EscapeTheCapitalShip", 3)
        --_T.ShowImpactMessage("[PH] BOSS DOWN -- ESCAPE!", 6, nil, nil, false)

        local exitMarkers = gRegion:FindTagged(Symbol("ExitMarker"))

        for i=1, #exitMarkers do
            exitMarkers[i]:Enable()
        end

        local capitalShipEntranceMarkers = gRegion:FindTagged(Symbol("CapitalShipEntranceMarker"))
        for i=1, #capitalShipEntranceMarkers do
            capitalShipEntranceMarkers[i]:Disable()
        end
        
        --Firing off script trigger that can run the death anim on host and client
        local galleonDeathScript = gRegion:FindFirstTagged(Symbol("GalleonDeathScript"))
        if not IsNull(galleonDeathScript) then
            galleonDeathScript:FirePort("Execute")
        end
        
    elseif mModeState == COMPLETE then
        mHint:SetEncounterStatus(Npc.ES_SUCCEEDED)
    end
end

local function OnSubObjectivesStateChanged()
    if mSubObjectiveState == NOT_STARTED then

    elseif mSubObjectiveState == STARTED then
        RJ_UTIL.SetAllCrewShipExitMarkers(false, nil)
        local capitalEntranceMarker = gRegion:FindFirstTagged(Symbol("CapitalShipEntranceMarker"))
        if not IsNull(capitalEntranceMarker) then
            capitalEntranceMarker:Disable()
        end

    elseif mSubObjectiveState == COMPLETE then
        SetModeState(STARTED)
    end
end

local function IncrementSubObjCount()
    local subObjCompletedCount = gGameRules:GetNetPersistentVar(NV_NUM_OF_SUB_OBJECTIVES, 0)
    local newCount = subObjCompletedCount + 1
    gGameRules:SetNetPersistentVar(NV_NUM_OF_SUB_OBJECTIVES, newCount)
end

local function ActivateRandomSubObjective()
    local randomEncIndex = RandomInt(1, #validSubObjectives)
    local encounterType = validSubObjectives[randomEncIndex]
    mActiveSubObjectiveHint = mAiDir:ActivateSpecificEncounterAtPos(ZERO_VECTOR, encounterType, nil, 0)
    if not IsNull(mActiveSubObjectiveHint) then
        table.remove(validSubObjectives, randomEncIndex)
        SetSubObjectivesState(STARTED)
    end 
end

local function UpdateCapitalShip(deltaTime)

end

local function Initialize(hint)
    mHint = hint
    mTemplate = mHint:GetCurrentEncounterTemplate()
    mTransmissionSet = mTemplate:GetTransmissionSet()
    
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    mActivateSubObjectiveTimer = RandomInt(activateSubObjectiveTimerMin, activateSubObjectiveTimerMax)

    if not IsNull(gGameRules) then
        --mAiSpec = capitalShipAiSpec
        local mission = gGameRules:GetMission()
        mAiSpec = mission.enemySpec
        if IsNull(mAiSpec) then
            mAiSpec = capitalShipAiSpec
            mission.enemySpec = capitalShipAiSpec
            gGameRules:SetMission(mission)
            mAiDir:AssignMissionAISpec(mAiSpec)
        end
    end

    local levelInfo = gRegion:GetLevelInfo()
    ObjectPortHandler(levelInfo, "NPCAlertStart")
    ObjectPortHandler(levelInfo, "NPCAlertEnd")
    
    --hack for the recall failed moment after boss is killed. See RecallToRailjack.lua
    _T.TennoConDemoBossKilled = false

    SetModeState(gGameRules:GetNetPersistentVar(NV_KILL_CAPITAL_CAPTAIN_STATE, NOT_STARTED))
    SetModeState(gGameRules:GetNetPersistentVar(NV_SUB_OBJECTIVE_STATE, NOT_STARTED))

    if mModeState == NOT_STARTED then

    elseif mModeState == STARTED then
        --find all existing pilot actions
        --outputhandler them all
        --check if anyone is flying and check/reset blackboard values
    elseif mModeState == ENTERED then
    
    elseif mModeState == BOSS_SPAWNED then
    
    elseif mModeState == BOSS_COMBAT then

    elseif mModeState == BOSS_KILLED then

    elseif mModeState == COMPLETE then

    end
end

local function Update(deltaTime)
    local modeState = gGameRules:GetNetPersistentVar(NV_KILL_CAPITAL_CAPTAIN_STATE, NOT_STARTED)
    if modeState ~= mModeState then
        mModeState = modeState
        mHint:SetEncounterDynamicState(modeState)
        OnModeStateChanged(modeState)
    end

    local subObjState = gGameRules:GetNetPersistentVar(NV_SUB_OBJECTIVE_STATE, NOT_STARTED)
    if subObjState ~= mSubObjectiveState then
        mSubObjectiveState = subObjState
        OnSubObjectivesStateChanged(subObjState)
    end

    UpdateCapitalShip(deltaTime)

    if mModeState == NOT_STARTED then
        if mSubObjectiveState == NOT_STARTED then
            if mActiveSubObjectiveHint == nil then
                local capitalEntranceMarker = gRegion:FindFirstTagged(Symbol("CapitalShipEntranceMarker"))
                local railjackAvatar = gGameRules:GetCrewShipManager():GetPlayerShip()
                if not IsNull(railjackAvatar) then
                    railjackAvatar = railjackAvatar:GetAvatarOwner()
                end
                
                if not IsNull(railjackAvatar) and mActivateSubObjectiveTimer > 0 then
                    if mActivateSubObjectiveTimer - deltaTime <= 0 then
                        mActivateSubObjectiveTimer = 0
                        ActivateRandomSubObjective()
                    else
                        mActivateSubObjectiveTimer = mActivateSubObjectiveTimer - deltaTime
                    end
                end
            end
        elseif mSubObjectiveState == STARTED then
            if not IsNull(mActiveSubObjectiveHint) then
                local encState = mActiveSubObjectiveHint:GetEncounterDynamicState()
                if encState == COMPLETE then --Confirm COMPLETE is the same across all subobjectives
                    IncrementSubObjCount()
                    local subObjCompletedCount = gGameRules:GetNetPersistentVar(NV_NUM_OF_SUB_OBJECTIVES, 0)
                    if subObjCompletedCount >= numOfSubObjectives then
                        SetSubObjectivesState(COMPLETE)
                    else
                        ActivateRandomSubObjective()
                    end
                end
            end
        elseif mSubObjectiveState == COMPLETE then
            SetModeState(STARTED)
        end
    elseif mModeState == STARTED then
        local playersInInterior = GetTennoInInteriorShip()
        if not IsNull(playersInInterior) and #playersInInterior > 0 then
            SetModeState(ENTERED)
        end
        
        if approachPlayed == false then
            local capitalEntranceMarker = gRegion:FindFirstTagged(Symbol("CapitalShipEntranceMarker"))
            local railjackAvatar = gGameRules:GetCrewShipManager():GetPlayerShip()
            if not IsNull(railjackAvatar) then
                railjackAvatar = railjackAvatar:GetAvatarOwner()
            end
            
            if not IsNull(railjackAvatar) and not IsNull(capitalEntranceMarker) then
                local distance = railjackAvatar:DistanceToEntity(capitalEntranceMarker)
                --Broadcast("Distance: " .. distance)
                if distance < 4500 then
                    --DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("CommanderApproach01"))
                    --DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("CommanderApproach02"))
                    approachPlayed = true
                end
            end
        end
    elseif mModeState == ENTERED then
    
    elseif mModeState == BOSS_SPAWNED then
        
    
    elseif mModeState == BOSS_COMBAT then
        local powerNodeCount = gGameRules:GetNetPersistentVar(NV_GALLEON_NODE_COUNT, 0)
        
        if powerNodeCount == 1 and generatorOnePlayed == false then
            --TODO: Replace with new commander version of this transmission
            --DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("CommanderGeneratorOne"))
            generatorOnePlayed = true
        elseif powerNodeCount == 2 and generatorTwoPlayed == false then
            --TODO: Replace with new commander version of this transmission
            --DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("CommanderGeneratorTwo"))
            generatorTwoPlayed = true
        --elseif not bossHalfHealthPlayed and not IsNull(mCaptainAvatar) and mCaptainAvatar:GetHealthPercentage() <= 0.5 then
            --DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("BossHalfDead"))
            --bossHalfHealthPlayed = true
        end
        
        
        
    elseif mModeState == BOSS_KILLED then
        local playersInInterior = GetTennoInInteriorShip()
        
        if not stormWarningPlayed then
            local exitMarker = gRegion:FindFirstTagged(Symbol("ExitMarker"))
            if #playersInInterior > 0 then  
                if exitMarker:DistanceToEntity(playersInInterior[1]) <= 120 then
                    DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("StormWarning"))
                    stormWarningPlayed = true
                end
                
            end
        end

        if not IsNull(playersInInterior) and #playersInInterior == 0 then
            SetModeState(COMPLETE)
        end
    elseif mModeState == COMPLETE then
        --increment railjackmanagernetvar to move onto the next mission.
    end
end

SetModeState = function(newState)
    if mModeState ~= newState then
        mModeState = newState
        mHint:SetEncounterDynamicState(newState)
        gGameRules:SetNetPersistentVar(NV_KILL_CAPITAL_CAPTAIN_STATE, newState)
        OnModeStateChanged()
    else
        print("KillCapitalShipCaptain.lua::SetModeState - trying to set mode to state we're already in")
    end
end

SetSubObjectivesState = function(newState)
    if mSubObjectiveState ~= newState then
        mSubObjectiveState = newState
        gGameRules:SetNetPersistentVar(NV_SUB_OBJECTIVE_STATE, newState)
        OnSubObjectivesStateChanged()
    else
        print("KillCapitalShipCaptain.lua::SetSubObjectivesState - trying to set mode to state we're already in")
    end
end

function StartShieldGeneratorTimer()
    
end

function CanActivateKillCaptainEncounter()
    -- check if the proc system placed the correct rooms/objects in thte node. If not return false

    return 1
end

function CaptainTargetMonitor(lookTrigger)

    while true do
        Sleep(0)
    end

end

function CaptainBossMonitor(avatar)

    local t = 0

    while true do
        if IsNull(avatar) or avatar:IsKilled() then
            return
        end
        
        local maxHealth = avatar:GetMaxHealth()
        local health = avatar:GetHealth()
        
        if health <= maxHealth / 2 then
            --PHASE 2???
        
        end
    
    
        t = t + DeltaTime()
        Sleep(0)
        
    end

end

function KillCapitalShipCaptain(hint)

    Broadcast("KillCaptailShipCaptainEncounter.lua -- Kill Capital Ship Captain Objective Started")
    Initialize(hint)

    local sleepTime = UPDATE_INTERVAL

    while not ShouldShutDown() do
        Update(sleepTime)
        Sleep(sleepTime)
    end

    ShutDownCapitalShipStateEncounter(hint)
end

function OnTouched(trigger)

    local triggerTag = trigger:GetTag()
    
    if triggerTag == Symbol("RailjackCaptainSpawnTrigger") then
        --_T.ShowImpactMessage("[PH] BOSS TAUNT -- I HAVE SPAWNED", 6, nil, nil, false)
        --DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("CommanderFightGen"))
        SetModeState(BOSS_SPAWNED)
        
        local marker = gRegion:FindNearest(assassinateMarkerType, trigger:GetPosition(), 25)
        if not IsNull(marker) then
            marker:Destroy()
        end
        
        trigger:Destroy()
    end
    
    --local message = Localize("/Lotus/Language/SolarisJobs/DynamicRecoveryHackBonusPickup", nil)
end

function GalleonDeathAnimate()
    _GalleonDeath()
end

function VoidWarningTransmission()
    local kuvaBossTrigger = gRegion:FindFirstTagged(Symbol("RailjackCaptainSpawnTrigger"))
    if not IsNull(kuvaBossTrigger) then
        DIALOG.PlayGlobalTransmission(transmissionSet, Symbol("FirstStormWarning"))
    else
        return
    end
end
