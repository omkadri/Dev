--ARGS
satelliteAgentType = Type()
satelliteAttachPivot = Type()
satelliteTowBeam = Type()
satelliteTowBeamNoChild = Type()
satelliteTowBeamRailJackAttachPosL = Vector()
satelliteTowBeamRailJackAttachPosR = Vector()
satelliteTopTowBeamAttachType = WeakResource()

satelliteTransmissionFx = Type()

defendMarkerType = Type()

fighterReinforcementsEncounter = Type()

--LIBS
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RAILOBJ = require "Lotus.Scripts.Libs.RailjackObjectiveUI"

--RESOURCES
local exampleRes = WeakResource("/Lotus/Types/Game/ExampleRes")

--LOC
local exampleLoc = "/Lotus/Language/EidolonPlains/ExampleLoc"

--SYMBOLS
local NV_NET_VAR = Symbol("NETVAR")
local NV_NET_VAR2 = Symbol("NETVAR2")
local sSymbol = Symbol("Symbol")
local TOW_INVULNERABILITY = Symbol("TOW_INVULNERABILITY")

--CACHED VARS
local mGameRules = nil
local mAiDir = nil
local mHint = nil
local mHintPos = nil
local mHintActivationRadius = 0
local mDeactivateRadius = 0
local mParentHint = nil
local mTransmissionSet = nil
local mTimerMgr = nil
local mModeMgr = nil

--STATES
local INVALID = 0
local STARTED = 1
local SATELLITE_SPAWNED = 2
local SATELLITE_TOW = 3
local SATELLITE_DEPLOYED = 4
local SATELLITE_PICKUP = 5

--SETTINGS
local GAMEPLAY_SETTING = 150

--VARS
local mPlayerShipAvatar = nil
local mDropOffMarker = nil
local mReinforcementsHint = nil
local mSatelliteAgent = nil
local mHealthTracker = nil
local mRJTeamTracker = nil
local mAwayTeamTracker = nil
local mFragmentAvatars = {}
local mCurrentFragment = 0
local mFragmentsCompleted = 0

--defense target movement
local TIME_TO_DESTINATION = 5

local mDefenseTargetMoveTimer = 0
local mDefenseTargetMoveDestination = nil
local mTargetReachedDestination = true
local mTargetStartPosition = nil

local satellitePivotAttachLocalSpace = Vector(0, 22, 105)

local function CalculateDefenseTargetPivotWorldPosition()
    return mPlayerShipAvatar:GetPosition() + (RotateVector(satellitePivotAttachLocalSpace, mPlayerShipAvatar:GetRotation()) * mPlayerShipAvatar:GetMeshScale())
end

local function NewMoveDefenseTargetToDestination(position)
    if IsNull(mSatelliteAgent) or IsNull(mSatelliteAgent:GetAvatar()) then
        return
    end

    local satelliteAvatar = mSatelliteAgent:GetAvatar()
    satelliteAvatar:OverrideUpdateThrottleSettings(false, false)
    satelliteAvatar:Unattach()

    mTargetReachedDestination = false
    mDefenseTargetMoveTimer = 0.0
    mDefenseTargetMoveDestination = position
    mTargetStartPosition = satelliteAvatar:GetPosition()
end

local function AttachDefenseTarget(avatar)
    local pivot = mPlayerShipAvatar:Attach(satelliteAttachPivot, EMPTY_SYMBOL, satellitePivotAttachLocalSpace, ZERO_ROTATION)
    if not IsNull(pivot) then
        pivot:AttachEntity(avatar, EMPTY_SYMBOL, Vector(), ZERO_ROTATION)
    end

    local beam2AttachEntity = avatar:GetAttachment(satelliteTopTowBeamAttachType)
    local beam = mPlayerShipAvatar:Attach(satelliteTowBeam, EMPTY_SYMBOL, satelliteTowBeamRailJackAttachPosL, ZERO_ROTATION)
    local beam2
    if not IsNull(beam) then
        --beam:SetEndPointEntity(pivot, EMPTY_SYMBOL)
        beam:SetEndPointEntity(beam2AttachEntity, EMPTY_SYMBOL)
    end
    if not IsNull(beam2AttachEntity) then
        beam2 = mPlayerShipAvatar:Attach(satelliteTowBeamNoChild, EMPTY_SYMBOL, satelliteTowBeamRailJackAttachPosR, ZERO_ROTATION)
        if not IsNull(beam2) then
            beam2:SetEndPointEntity(beam2AttachEntity, EMPTY_SYMBOL)
        end
    end
end

local function DeployDefenseTarget(targetAvatar)
    targetAvatar:Unattach()
    mDropOffMarker:Destroy()
    targetAvatar:Attach(defendMarkerType, EMPTY_SYMBOL, Vector(0,2,0), ZERO_ROTATION)

    local beam = mPlayerShipAvatar:GetAttachment(satelliteTowBeam)
    if not IsNull(beam) then
        beam:Destroy()
    end

    local beam2 = mPlayerShipAvatar:GetAttachment(satelliteTowBeamNoChild)
    if not IsNull(beam2) then
        beam2:Destroy()
    end
end

local function UpdateMoveDefenseTargetToDestination()
    if mTargetReachedDestination or IsNull(mSatelliteAgent) or IsNull(mSatelliteAgent:GetAvatar()) then
        return
    end

    local satelliteAvatar = mSatelliteAgent:GetAvatar()

    if mDefenseTargetMoveTimer <= TIME_TO_DESTINATION then
        local newPos = LerpVector(mTargetStartPosition, mDefenseTargetMoveDestination, SmoothStep(mDefenseTargetMoveTimer / TIME_TO_DESTINATION))
        satelliteAvatar:Teleport(newPos, ZERO_ROTATION)
        mDefenseTargetMoveTimer = mDefenseTargetMoveTimer + DeltaTime()
    else
        satelliteAvatar:Teleport(mDefenseTargetMoveDestination, ZERO_ROTATION)
        satelliteAvatar:OverrideUpdateThrottleSettings(false, true)
        mTargetReachedDestination = true
        mDefenseTargetMoveDestination = nil
        mTargetStartPosition = nil
    end
end

local function SpawnDefenseTarget()
    local satelliteAvatar = gRegion:FindFirstTagged(Symbol("SquadLinkDefenseTarget"))
    if IsNull(satelliteAvatar) then

        local position = mPlayerShipAvatar:GetPosition() + RotateVector(mPlayerShipAvatar:GetForwardVector(), Rotation(180,0,0)) + Vector(50,0,0)
        mSatelliteAgent = mAiDir:CreateAgentAtPosition(satelliteAgentType, position, ZERO_ROTATION)

        if IsNull(mSatelliteAgent) then
            print("Failed to create Satellite Agent; that's not good!")
            return
        end

        mHint:RegisterAgent(mSatelliteAgent)
        satelliteAvatar = mSatelliteAgent:GetAvatar()
    end
    
    AttachDefenseTarget(satelliteAvatar)
    mHealthTracker.SetTarget(satelliteAvatar)
    
    mModeMgr:SetModeState(SATELLITE_SPAWNED)
end

-- OnModeStateChanged - this is called immediately when state changes - use this function for setting up the state (UI changes, creating objects, etc)
-- This func is called after host migration, so you can recover from the state you migrated during
local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    if curState == STARTED then
        mTimerMgr:AddTimer(1, SpawnDefenseTarget)
    elseif curState == SATELLITE_SPAWNED then
        mRJTeamTracker = _T.AddHudTracker("RJTeamTracker", LOTUS_UTIL.HT_LABEL)
        mHealthTracker.SetOffset(25, -5, true)
        
    elseif curState == SATELLITE_TOW then
        if not IsNull(_T.ScenarioSetLocalSquadMissionStatus) then
            _T.ScenarioSetLocalSquadMissionStatus("PreparingRelay")
        end
        
        RAILOBJ.SetExternalTrackerLabel(mRJTeamTracker, true, "[HC] TOW SQUAD LINK RELAY SATTELITE", nil, RAILOBJ.GENERIC_ICON)
        if mFragmentsCompleted < 3 then
            mCurrentFragment = mCurrentFragment + 1
        else
            local index = mCurrentFragment
            while index == mCurrentFragment do
                index = RandomInt(1, #mFragmentAvatars)
            end
            mCurrentFragment = index
        end
        mDropOffMarker = _T.StartFragmentObjective[mFragmentAvatars[mCurrentFragment]:GetFullName()]()
    
    elseif curState == SATELLITE_DEPLOYED then
        if not _T.FragmentBeaconsPlaced() and not IsNull(_T.ScenarioSetLocalSquadMissionStatus) then
            _T.ScenarioSetLocalSquadMissionStatus("BoardingFragment")
        end
        
        RAILOBJ.SetExternalTrackerLabel(mRJTeamTracker, true, "[HC] RAILJACK: DEFEND SQUAD LINK RELAY", nil, RAILOBJ.DEFEND_ICON)
        RAILOBJ.SetExternalTrackerLabel(mAwayTeamTracker, true, "[HC] AWAY TEAM: ENTER FRAGMENT", nil, RAILOBJ.GENERIC_ICON)
        mReinforcementsHint = mAiDir:ActivateSpecificEncounterAtPos(mHintPos, fighterReinforcementsEncounter, mHint)
    end
end

-- Initialize - first thing that runs when a mission encounter starts - do your initial setup here. This is called again on migration.
-- Because gPromotedToHost is unreliable here, you will need to search for mission entities first, and create if not found (see mMissionObject)
local function Initialize(hint)
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    mGameRules = gGameRules
    mHint = hint
    mParentHint = hint:GetRootParentEncounterHint()
    mHintPos = hint:GetPosition()
    mHintActivationRadius = hint:GetActivationRadius()
    mDeactivateRadius = hint:GetDeactivationRadius()
    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()
    gRegion:AddPlayersChangedBasicCallback("OnPlayersChanged")
    --mPlayers = gRegion:GetHumanPlayers()
    
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {NV_NET_VAR, NV_NET_VAR2})
    mTimerMgr = TIMER.CreateTimerMgr()
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    local playerShip = crewShipMgr:GetShips(true)[1]
    mPlayerShipAvatar = playerShip:GetAvatarOwner()
    
    mHealthTracker = _T.AddHudTracker("SatelliteHealth", LOTUS_UTIL.HT_HEALTH_TRACKER, nil, 6)
    mAwayTeamTracker = _T.AddHudTracker("AwayTeamTracker", LOTUS_UTIL.HT_LABEL, nil, 10)
    
    --Finished initializing, setting up mode state and encounter status
    local netState = mHint:GetEncounterDynamicState()
    if netState == 0 then
    
    else
        local agents = mHint:GetRegisteredAgents()
        for i, agent in ipairs(agents) do
            if agent:IsA(satelliteAgentType) then
                mSatelliteAgent = agent
            end
        end
    end
    
    local warpInSpot = gRegion:FindFirstTagged(Symbol("WarpInSpot"))
    
    mFragmentAvatars = gRegion:FindTagged(Symbol("SentientFragment"))
    table.sort(
        mFragmentAvatars,
        function(a, b)
            return warpInSpot:Distance2DToEntity(a) < warpInSpot:Distance2DToEntity(b)
        end
    )
    
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))

    if hint:GetEncounterStatus() == Npc.ES_SETUP then
        hint:SetEncounterStatus(Npc.ES_ACTIVE)
    end
end

--Main function - Contains main update loop, monitor mode state here
function Start(hint)
    Initialize(hint)
    
    local delta = 0
    local curState = INVALID

    while hint:GetEncounterStatus() < Npc.ES_SUCCEEDED do
        delta = DeltaTime()
        curState = mModeMgr:GetModeState()
        
        if curState == STARTED then
        
        elseif curState == SATELLITE_SPAWNED then
            mModeMgr:SetModeState(SATELLITE_TOW)
            
        elseif curState == SATELLITE_TOW then
            local avatar = mSatelliteAgent:GetAvatar()
            if not avatar:DamageControl():HasDamageModifier(TOW_INVULNERABILITY) then
                avatar:DamageControl():AddDamageModifier(TOW_INVULNERABILITY, Engine.DT_ANY, Engine.ANY_PART, 0.0)
                avatar:SetForceNotTargetable(true)
            end
            if mPlayerShipAvatar:Distance2DToEntity(mDropOffMarker) < 50 then
                avatar:DamageControl():RemoveDamageModifier(TOW_INVULNERABILITY)
                avatar:SetForceNotTargetable(false)

                DeployDefenseTarget(avatar)
                
                local avPos = avatar:GetPosition()
                local dropOffPoint = gRegion:FindNearestTagged(Symbol("SatelliteDropOffPoint"), avPos)
                NewMoveDefenseTargetToDestination(dropOffPoint:GetPosition())

                mModeMgr:SetModeState(SATELLITE_DEPLOYED)
            end
            
        elseif curState == SATELLITE_DEPLOYED then
            local avatar = mSatelliteAgent:GetAvatar()
            if mTargetReachedDestination then
                if not IsNull(satelliteTransmissionFx) then
                    local transmissionFx = avatar:GetAttachment(satelliteTransmissionFx)
                    if IsNull(transmissionFx) then
                        avatar:Attach(satelliteTransmissionFx, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION)
                    end
                end
            end
            if _T.IsFragmentObjectiveComplete() then
                if IsNull(mDefenseTargetMoveDestination) then
                    mFragmentsCompleted = mFragmentsCompleted + 1
                    if not IsNull(satelliteTransmissionFx) then
                        local transmissionFx = avatar:GetAttachment(satelliteTransmissionFx)
                        if not IsNull(transmissionFx) then
                            transmissionFx:Destroy()
                        end
                    end
                    NewMoveDefenseTargetToDestination(CalculateDefenseTargetPivotWorldPosition())
                    mModeMgr:SetModeState(SATELLITE_PICKUP)
                end
            end
        elseif curState == SATELLITE_PICKUP then
            if not mTargetReachedDestination then
                mDefenseTargetMoveDestination = CalculateDefenseTargetPivotWorldPosition()
            else
                AttachDefenseTarget(mSatelliteAgent:GetAvatar())
                mModeMgr:SetModeState(SATELLITE_TOW)
            end
        end

        -- handle satellite movement logic
        UpdateMoveDefenseTargetToDestination()

        mTimerMgr:Update(delta)
        
        --Optional, abandon radius logic
        if hint:ShouldShutDown() then
            LANDSCAPE.PlayersAbandonedObjective()
            hint:SetEncounterStatus(Npc.ES_FAILED)
        end
        
        Sleep(0)
    end
    
    mModeMgr:ShutDown()
end

--CALLBACKS
function OnPlayersChanged()
    --mPlayers = gRegion:GetHumanPlayers()
end
