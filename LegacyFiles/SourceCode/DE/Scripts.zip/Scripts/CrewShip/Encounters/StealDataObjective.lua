capitalShipAiSpec = Resource()
interiorShipRegionIndex = 1

transmissionSet = Resource()
enemyFaction = Symbol("Grineer")

numOfTerminalsToStealMin = 2
numOfTerminalsToStealMax = 4

terminalPickUp = WeakResource()

consoleAvatarSpawnControl = Instance()
consoleVisualsActive = Instance()
consoleVisualsDone = Instance()

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local PANIC = require "Lotus.Scripts.Libs.PanicLib"

local NV_RJ_DATA_THEFT_STATE = Symbol("RJ_DATA_THEFT_STATE")
local NV_RJ_NUM_DATA_STOLEN = Symbol("RJ_NUM_DATA_STOLEN")
local NV_RJ_NUM_DATA_TO_STEAL = Symbol("RJ_NUM_DATA_TO_STEAL")

local NOT_STARTED = 1
local WAITING_TO_START = 2
local STARTED = 3
local THEFT_IN_PROGRESS = 4
local THEFT_COMPLETE = 5
local COMPLETE = 6
local mModeState = INVALID
local SetModeState

local UPDATE_INTERVAL = 0.1 -- How frequently we will tick 

local mHint = nil
local mAiSpec = nil
local mAiDir = nil

local mPotentialObjectiveMarkers = nil
local mActiveObjectiveMarker = nil
local mTemplate = nil
local mTransmissionSet = nil
local mNumOfTerminalsToSteal = nil
local mNumOfTerminalsStolen = 0

local consoleObjectiveMarkerTag = Symbol("RJConsoleObjectiveMarker")
local stealDataMarkerType = Type("/Lotus/Types/Enemies/CaptureTargets/CaptureTargetObjectiveMarker")

function NPCAlertStart(npc)
    PANIC.SetPanicLevel(PANIC.ALERT)
end

function NPCAlertEnd(npc)
    PANIC.SetPanicLevel(PANIC.UNALERT) 
end

function OnDamaged(deco)
    --Detected()
end

function OnDestroyed(deco)

end

function OnKilled(avatar)
    
    -- if IsNull(avatar) then
    --     return
    -- end
    
    -- if mCaptainBossAgent:GetAvatar() == avatar or avatar:GetTag() == sGalleonCommanderAvatar then
    --     gGameRules:SetNetPersistentVar(NV_KILL_CAPITAL_CAPTAIN_STATE, BOSS_KILLED)
    -- end
    
end

function OnDeath(dd)

    -- local victim = dd:GetVictim()
    -- if IsNull(victim) then
    --     return
    -- end
    
    -- local faction = victim:GetOriginalFaction()

end

function OnPickedUp(item)

end

function OnCellDropped(item, createdEntity)

end

function OnActivated()
    if not IsNull(consoleVisualsActive) and not IsNull(consoleVisualsDone) and not IsNull(consoleAvatarSpawnControl) then

    end

    local modeState = gGameRules:GetNetPersistentVar(NV_RJ_DATA_THEFT_STATE, NOT_STARTED)

    if modeState == STARTED then
        gGameRules:SetNetPersistentVar(NV_RJ_DATA_THEFT_STATE, THEFT_IN_PROGRESS)        
    end
end

local function ShouldShutDown()
    if mModeState == COMPLETE then
        return true
    end

    -- local crewShipMgr = gGameRules:GetCrewShipManager()
    -- if not IsNull(crewShipMgr) then
    --     local ship = crewShipMgr:GetPlayerShip()
    --     local shipAvatar = ship:GetAvatarOwner()
    --     local hyperDriveState = shipAvatar:GetHyperDriveState()

    --     if hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_BOARDING or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP then
    --         return true
    --     end
    -- end

    return false
end

local function GetTennoInInteriorShip()
    local avatars = gRegion:GetHumanPlayerAvatars()
    local playersInInterior = { }

    for i=1,#avatars do
        local avatar = avatars[i]

        if not IsNull(avatar) then
            local avatarZone = avatar:GetZone()
        
            if not IsNull(avatarZone) then
                local avatarRegionIndex = avatarZone:GetRegionIndex()

                if avatarRegionIndex == interiorShipRegionIndex then
                    table.insert(playersInInterior, avatar)
                end
            end
        end
    end

    return playersInInterior
end

local function ActivateTerminalToSteal()
    local newTerminalToSteal = nil

    while newTerminalToSteal == nil and #mPotentialObjectiveMarkers > 0 do
        local randIndex = RandomInt(1, #mPotentialObjectiveMarkers)
        local potentialObjectiveMarker = mPotentialObjectiveMarkers[randIndex]
        if not IsNull(potentialObjectiveMarker) and not potentialObjectiveMarker:IsEnabled() then
            newTerminalToSteal = potentialObjectiveMarker
            table.remove(mPotentialObjectiveMarkers, randIndex)
            break
        elseif not IsNull(potentialObjectiveMarker) and potentialObjectiveMarker:IsEnabled() then
            table.remove(mPotentialObjectiveMarkers, randIndex)
        end 
    end

    if not IsNull(newTerminalToSteal) then
        mActiveObjectiveMarker = newTerminalToSteal
        mActiveObjectiveMarker:Enable()

        local children = mActiveObjectiveMarker:GetAttachedChildren()
        local hitSwitch = children[1]
        ObjectPortHandler(hitSwitch, "OnActivated")
        --ObjectPortHandler(startingConsole, "OnFinished")
        return true
    else
        Broadcast("StealDataObjective.lua -- Couldn't find new terminal to set as mActiveObjectiveMarker")
        return false
    end
end

local function ShutDownStealDataObjectiveEncounter(hint)
    --Destroy crewships
    --set net variables back to 0.
    mAiDir:SetEnableAutoSpawns(false)
    gGameRules:SetNetPersistentVar(NV_RJ_DATA_THEFT_STATE, 1)
end

function ConsoleUsed()
    if not IsNull(consoleVisualsActive) and not IsNull(consoleVisualsDone) and not IsNull(consoleAvatarSpawnControl) then

    end

    local modeState = gGameRules:GetNetPersistentVar(NV_RJ_DATA_THEFT_STATE, NOT_STARTED)

    if modeState == STARTED then
        gGameRules:SetNetPersistentVar(NV_RJ_DATA_THEFT_STATE, THEFT_IN_PROGRESS)        
    end
end

function ConsoleLocated()
    --gGameRules:GiveTransmissionAsyncToAllPlayers(crewShipIntroTransmission)
end

local function PlayStealDataIntro()
    --gGameRules:GiveTransmissionAsyncToAllPlayers(crewShipIntroTransmission)
end

local function PlayNewDataTerminalTransmission()

end

local function OnModeStateChanged()
    if mModeState == WAITING_TO_START then

    elseif mModeState == STARTED then

        if mNumOfTerminalsStolen == 0 then
            ActivateTerminalToSteal()

            PlayStealDataIntro() --Patrol ship transmissions
            OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/FindDataTerminal", 1)
            -- mAiDir:SetNpcHardCap(60) -- TC hack to get enemies to spawn inside the destroyers and cap ship while keeping fighters alive in space.
            mAiDir:SetAllowTeleportOldAgentsForNewSpawns(false)
        else
            PlayNewDataTerminalTransmission()
        end
        
    elseif mModeState == THEFT_IN_PROGRESS then
        SetModeState(THEFT_COMPLETE)
    elseif mModeState == THEFT_COMPLETE then
        mNumOfTerminalsStolen = mNumOfTerminalsStolen + 1
        gGameRules:SetNetPersistentVar(NV_RJ_NUM_DATA_STOLEN, mNumOfTerminalsStolen)
        mActiveObjectiveMarker:Disable() -- disable actions and etc if needed.


        if mNumOfTerminalsStolen >= mNumOfTerminalsToSteal then
            SetModeState(COMPLETE)
        else
            if ActivateTerminalToSteal() == true then
                SetModeState(STARTED)
            end
        end

    elseif mModeState == COMPLETE then
        _T.ObjectiveComplete()
    end
end

local function Initialize(hint)
    mHint = hint
    mTemplate = mHint:GetCurrentEncounterTemplate()
    mTransmissionSet = mTemplate:GetTransmissionSet()
    mPotentialObjectiveMarkers = gRegion:FindTagged(consoleObjectiveMarkerTag)
    mNumOfTerminalsToSteal = gGameRules:GetNetPersistentVar(NV_RJ_NUM_DATA_TO_STEAL, 0)
    mNumOfTerminalsStolen = gGameRules:GetNetPersistentVar(NV_RJ_NUM_DATA_STOLEN, 0)

    if mNumOfTerminalsToSteal == 0 then
        mNumOfTerminalsToSteal = RandomInt(numOfTerminalsToStealMin, numOfTerminalsToStealMax)
        gGameRules:SetNetPersistentVar(NV_RJ_NUM_DATA_TO_STEAL, mNumOfTerminalsToSteal)
    end
    
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    if not IsNull(gGameRules) then
        --mAiSpec = capitalShipAiSpec
        local mission = gGameRules:GetMission()
        mAiSpec = mission.enemySpec
        if IsNull(mAiSpec) then
            mAiSpec = capitalShipAiSpec
            mission.enemySpec = capitalShipAiSpec
            gGameRules:SetMission(mission)
            mAiDir:AssignMissionAISpec(mAiSpec)
        end
    end

    local levelInfo = gRegion:GetLevelInfo()
    ObjectPortHandler(levelInfo, "NPCAlertStart")
    ObjectPortHandler(levelInfo, "NPCAlertEnd")
    --ObjectPortHandler(panelForwarder, "OnActivated")

    SetModeState(gGameRules:GetNetPersistentVar(NV_RJ_DATA_THEFT_STATE, NOT_STARTED))

    if mModeState == NOT_STARTED then
        SetModeState(WAITING_TO_START)
    elseif mModeState == WAITING_TO_START then

    elseif mModeState >= STARTED then
        
        --there must be an objective that's been activated, find that one.
        for i=1,#mPotentialObjectiveMarkers do
            local objectiveMarker = mPotentialObjectiveMarkers[i]

            if not IsNull(objectiveMarker) and objectiveMarker:IsEnabled() then
                mActiveObjectiveMarker = objectiveMarker
            end
        end
        
    end
end

local function Update(deltaTime)
    local modeState = gGameRules:GetNetPersistentVar(NV_RJ_DATA_THEFT_STATE, NOT_STARTED)
    if modeState ~= mModeState then
        mModeState = modeState
        OnModeStateChanged(modeState)
    end

    if mModeState == WAITING_TO_START then
        if _T.IsCurrentObjective(mHint) then
            SetModeState(STARTED)
        end
    elseif mModeState == STARTED then

    elseif mModeState == THEFT_IN_PROGRESS then

    elseif mModeState == THEFT_COMPLETE then
        
    elseif mModeState == COMPLETE then
        --increment railjackmanagernetvar to move onto the next mission.
    end
end

SetModeState = function(newState)
    if mModeState ~= newState then
        mModeState = newState
        gGameRules:SetNetPersistentVar(NV_RJ_DATA_THEFT_STATE, newState)
        OnModeStateChanged()
    else
        print("StealDataObjective.lua::SetModeState - trying to set mode to state we're already in")
    end
end

function CanActivateStealDataObjectiveEncounter()
    -- check if the proc system placed the correct rooms/objects in thte node. If not return false

    local objectiveConsoles = gRegion:FindTagged(consoleObjectiveMarkerTag)

    if not IsNull(objectiveConsoles) and #objectiveConsoles >= numOfTerminalsToStealMin then
        return 1
    elseif not IsNull(objectiveConsoles) and #objectiveConsoles < numOfTerminalsToStealMin then
        print("StealDataObjective.lua::CanActivate - not enough terminals to setup mission")
        return 0
    end
    
    print("StealDataObjective.lua::CanActivate - couldn't find any terminals in the level")
    return 0
end

function StealDataObjective(hint)

    Broadcast("StealDataObjective.lua -- Rescue Capital Ship Captive Objective Started")
    Initialize(hint)

    local sleepTime = UPDATE_INTERVAL

    while not ShouldShutDown() do
        Update(sleepTime)
        Sleep(sleepTime)
    end

    ShutDownStealDataObjectiveEncounter(hint)
end