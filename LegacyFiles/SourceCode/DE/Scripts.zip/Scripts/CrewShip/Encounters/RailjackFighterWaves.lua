--ARGS
maxDefenseTimer = 300 -- in seconds
timerThresholds = { 0.3, 0.5, 0.7 } --Ratio of defense timer to know when to ramp up difficulty
maxSimFighterCount = { 2, 3, 4, 6 } -- Increment with timerThresholds
reinforceFighterThresholds = { 0, 2, 4, 5 } -- reinforce fighter count when active count falls below this value, incremented with timerThresholds
enemyFighterTier = 95
minSpawnDistanceFromPlayers = 500
fighterSpawnFxType = Type()
spawnPointTag = Symbol("FighterSpawner")
reinforcePointTag = Symbol("FighterReinforceSpawner")
stormTargetTag = Symbol()
enemyFaction = Symbol("Grineer")


--LIBS
local GAMEMODE = require "Lotus.Scripts.Libs.CommonGamemodeFunctions"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
--local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local UTIL = require "EE.Interface.Utilities"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"


--STATES
local INVALID = 0
local STARTED = 1
local SPAWNED = 2
local COMBAT = 3
local RAMP_DOWN = 4
local COMPLETE = 5

--NET VARS
local NV_DEFENSE_ROUNDS_COMPLETED = Symbol("DefenseRoundsCompleted")


--VARS
local mHint = nil
local mAiDir = nil
local mHintPos = nil
local mHintRadius = nil
local mTransmissionSet = nil
local mHintSpawnRadius = nil
local mSquadSize = nil
local mReinforceThreshold = 0
local mModeMgr = nil
local mLeaderAgent = nil
local mInitialSpawnPoints = {}
local mReinforcePoints = {}
local mActiveCount = 0
local mForceShutdown = false
local mTarget = nil
local mDefenseRoundsCompleted = 0
local mMinLevel = 35

local STORM_TARGET_RADIUS = 50
local enemyScalingBaseLevel = 1
local enemyScalingMult = 1.5

local function AttachSpawnFx(agent)
    local avatar = agent:GetAvatar()
    if not IsNull(avatar) then
        avatar:Attach(fighterSpawnFxType,  EMPTY_SYMBOL)
    end
end

local function SpawnFighter(mAiDir, tier, faction, spawnPoints, team)
    local spawnIndex = RandomInt(1, #spawnPoints)
    local spawner = spawnPoints[spawnIndex]
    --local level = mAiDir:GetRandomSpaceEnemyLevel()
    local agentType = mAiDir:GetRandomEnemyAgentType(faction, _T.SpaceEnemyLevel, false, false, tier, true)
    return mAiDir:CreateAgent(agentType, spawner, team, _T.SpaceEnemyLevel)
end

local function SpawnFighterAtPos(mAiDir, tier, faction, spawnPos, spawnRot, team)
    --local level = mAiDir:GetRandomSpaceEnemyLevel()
    local agentType = mAiDir:GetRandomEnemyAgentType(faction, _T.SpaceEnemyLevel, false, false, tier, true)
    return mAiDir:CreateAgentAtPositionOffNav(agentType, spawnPos, spawnRot, team, _T.SpaceEnemyLevel)
end

local function GetEnemyLevel(defenseRatio)

    local scaledT = (mDefenseRoundsCompleted * maxDefenseTimer) + (maxDefenseTimer * defenseRatio)    
    local scale = (scaledT / maxDefenseTimer) * 0.2
    local enemyLevel = math.floor((enemyScalingBaseLevel * (enemyScalingMult ^ scale)) + (mMinLevel - enemyScalingBaseLevel))
    enemyLevel = math.floor( math.min(enemyLevel, 9999) )

    return enemyLevel
end

local function SpawnSquad(firstSquad, spawnCount, spawnPoints)

    local hintInstances
    if firstSquad then
        -- check for existing agents. Update mSquadSize. Assign one as the leader
        local registeredAgents = mHint:GetRegisteredAgents()        
        spawnCount = spawnCount - #registeredAgents
        
        if spawnCount == 0 and IsNull(mLeaderAgent) and #registeredAgents > 0 and not IsNull(registeredAgents[1]) then
            mLeaderAgent = registeredAgents[1]
        end
        
        hintInstances = mHint:GetInstanceReferences()
        for i = 1, #hintInstances do
            if hintInstances[i]:IsA(gNpcSpawnPointType) then
                table.insert(spawnPoints, hintInstances[i])
            end
        end
    end
    
    local squadPositions = {}
    local leaderRot = Rotation()
    
    if spawnCount > 0 and #spawnPoints > 0 then
        local squadTeam = Symbol("RandomTeam")-- .. RandomInt(1, 10000))
        local buddyGroupId = -1
        
        -- Spawn leader
        local leaderAgent = SpawnFighter(mAiDir, enemyFighterTier, enemyFaction, spawnPoints, squadTeam)
        Sleep(0)
        if not IsNull(leaderAgent) and firstSquad then
        leaderAgent:SetAlert()
            if not IsNull(mTarget) then
                leaderAgent:StormTarget(mTarget, STORM_TARGET_RADIUS)
            end
            DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("FightersSpawned"))
        end

        if firstSquad and IsNull(mLeaderAgent) then
            mLeaderAgent = leaderAgent
        end

        if not IsNull(leaderAgent) then
            AttachSpawnFx(leaderAgent)
            leaderAgent:SetAlert()
            local leaderPos = leaderAgent:GetAvatar():GetPosition()
            leaderRot = leaderAgent:GetAvatar():GetSimRotation()
            local squadSpread = Vector(0, 0, -30)

            for i = 2, spawnCount do
                squadPositions[i] = leaderPos + RotateVector(squadSpread * (i - 1), leaderRot)
            end

            mHint:RegisterAgent(leaderAgent)
            buddyGroupId = leaderAgent:CreateScriptedBuddyGroup(Npc.GT_PATROL, 6) -- default patrol formation slot size is 6 in behaviors. for bigger squad, these numbers have to be increased, too. ex>FlyInFormationTactic.mMaxFormationSlots
        end

        Sleep(0.1)

        if not IsNull(leaderAgent) and not mForceShutdown then
            -- Spawn followers
            for i = 2, spawnCount do
                Sleep(0)
                
                local agent = SpawnFighterAtPos(mAiDir, enemyFighterTier, enemyFaction, squadPositions[i], leaderRot, squadTeam)

                if not IsNull(agent) then
                    agent:SetAlert()
                    if IsNull(mLeaderAgent) then --assign this agent as the leader (this will happen if crewship patrol wasn't allowed to create a new crewship
                        mLeaderAgent = agent
                    end
                    
                    if not IsNull(mTarget) then
                        agent:StormTarget(mTarget, STORM_TARGET_RADIUS)
                    end
                    
                    AttachSpawnFx(agent)
                    mHint:RegisterAgent(agent)
                    if buddyGroupId ~= -1 then
                        agent:JoinScriptedBuddyGroup(buddyGroupId)
                    end
                end
            end
            if firstSquad then
                Broadcast("Patrol spawned @" .. mHint:GetName())
            else
                Broadcast("Patrol reinforced @" .. mHint:GetName())
            end
        end
    end
end

local function UpdateSpawnParamaters(defenseRatio)
    local newWave = false
    local int = 1
    for i = 1, #timerThresholds do
        if defenseRatio <= timerThresholds[i] then
            int = i
            break
        end
    end
    local oldSquadSize = mSquadSize
    mSquadSize = maxSimFighterCount[int]
    mReinforceThreshold = reinforceFighterThresholds[int]
    if oldSquadSize ~= mSquadSize then
        newWave = true
    end
    
    return newWave
end



-- OnModeStateChanged - this is called immediately when state changes - use this function for setting up the state (UI changes, creating objects, etc)
-- This func is called after host migration, so you can recover from the state you migrated during
local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    
    if curState == STARTED then
        SpawnSquad(true, mSquadSize, mInitialSpawnPoints)
    elseif curState == SPAWNED then
    
    elseif curState == COMBAT then
        mReinforcePoints = mAiDir:FindSpaceSpawns(mHintPos, mHintRadius, minSpawnDistanceFromPlayers, reinforcePointTag)
    elseif curState == RAMP_DOWN then
        
    elseif curState == COMPLETE then
        mAiDir:SetGlobalAlertLevel(0)
        Broadcast("Patrol Completed @" .. mHint:GetName())
        mHint:SetEncounterStatus(Npc.ES_SUCCEEDED)
    end
end

local function Initialize(hint)
    mHint = hint
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    
    mAiDir:SetGlobalAlertLevel(1)
    
    mHintPos = hint:GetPosition()
    mHintRadius = hint:GetActivationRadius()
    mHintSpawnRadius = hint:GetSpawnRadius()
    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()
    mTarget = gRegion:FindNearestTagged(stormTargetTag, mHint:GetPosition())

    mSquadSize = maxSimFighterCount[1]
    mReinforceThreshold = reinforceFighterThresholds[1]
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})

    mDefenseRoundsCompleted = gGameRules:GetNetPersistentVar(NV_DEFENSE_ROUNDS_COMPLETED, 0)
    mMinLevel = mAiDir:GetSpaceMinEnemyLevel()
    
    if IsNull(_T.SpaceEnemyLevel) then
        _T.SpaceEnemyLevel = mMinLevel
    end
    
    mSquadSize = math.min(mAiDir:GetRoomTillHardCap(), mSquadSize)
    mInitialSpawnPoints = mAiDir:FindSpaceSpawns(mHintPos, mHintSpawnRadius, minSpawnDistanceFromPlayers, spawnPointTag)
    local try = 1
    while IsNull(mInitialSpawnPoints) do
        mInitialSpawnPoints = mAiDir:FindSpaceSpawns(mHintPos, mHintRadius * try, minSpawnDistanceFromPlayers, spawnPointTag)
        try = try + 1
        Sleep(0)
    end
    
    local netState = mHint:GetEncounterDynamicState()
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))
    hint:SetEncounterStatus(Npc.ES_ACTIVE)
    
end

function EnemyPatrol(hint)
    
    if IsNull(hint) then
        return
    end
    
    Initialize(hint)
    
    local delta = 0
    local curState = INVALID
    local spawnCount = 0
    local defenseTimer = 0
    local defenseRatio = 0
    local newWave = false

    while true do
        if IsNull(hint) or gGameRules:MissionCompleted() or gGameRules:MissionFailed() or hint:GetEncounterStatus() >= Npc.ES_SUCCEEDED then
            break
        end
        
        delta = DeltaTime()
        curState = mModeMgr:GetModeState()
        mActiveCount = hint:GetNumRegisteredAgents()
        defenseTimer = math.min(defenseTimer + delta, maxDefenseTimer)
        defenseRatio = defenseTimer / maxDefenseTimer
        newWave = UpdateSpawnParamaters(defenseRatio)
        
        if curState >= STARTED and not mForceShutdown then
            if IsNull(mTarget) or mTarget:GetHealth() <= 0 then
                mForceShutdown = true
            end
        end
        
        if curState == STARTED then
            if mActiveCount == mSquadSize or mForceShutdown then
                print("starting agents spawned")
                mModeMgr:SetModeState(SPAWNED)
            end
            if mActiveCount < mSquadSize then
                spawnCount = math.min(mAiDir:GetRoomTillHardCap(), mSquadSize - mActiveCount)
                SpawnSquad(true, spawnCount, mInitialSpawnPoints)
            end
        elseif curState == SPAWNED then
            if mActiveCount < mSquadSize or IsNull(mLeaderAgent) or mLeaderAgent:IsCombatAwareness() or mForceShutdown then
                mModeMgr:SetModeState(COMBAT)
            end
        elseif curState == COMBAT then
            if IsNull(mTarget) or mTarget:GetHealth() <= 0 or mForceShutdown then --stop combat and don't spawn more fighters if we're finished with defense
                mModeMgr:SetModeState(RAMP_DOWN)
            else
                if mActiveCount <= mReinforceThreshold or newWave then
                    spawnCount = math.min(mAiDir:GetRoomTillHardCap(), mSquadSize - mActiveCount)
                    local t = 1
                    while IsNull(mReinforcePoints) do
                        mReinforcePoints = mAiDir:FindSpaceSpawns(mHintPos, ( mHintRadius * (1 + t/10) ), minSpawnDistanceFromPlayers, reinforcePointTag)
                        t = t + 1
                        Sleep(0)
                    end
                    _T.SpaceEnemyLevel = GetEnemyLevel(defenseRatio)
                    SpawnSquad(false, spawnCount, mReinforcePoints)
                end
            end
        elseif curState == RAMP_DOWN then
            if mActiveCount <=0 then
                mHint:SetEncounterStatus(Npc.ES_COMPLETE)
                mModeMgr:SetModeState(COMPLETE)
            end
        end
        
        Sleep(0)
    end
    
    mModeMgr:ShutDown()
    
end