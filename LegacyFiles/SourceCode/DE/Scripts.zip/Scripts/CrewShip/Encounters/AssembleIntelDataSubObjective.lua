capitalShipAiSpec = Resource()
enemyTargetTier = 90

transmissionSet = Resource()

rjObjectiveConsoleWRes = WeakResource()
enterShipMarkerWRes = WeakResource()
crewshipObjectiveMarkerWRes = WeakResource()

enemyFaction = Symbol("Grineer")
enemyTeam = Symbol("RandomTeam")
RJConsoleDecoTag = Symbol("RJConsoleDeco")

numOfIntelPiecesToAcquire = 3

local HUD_INFO_NAME = "DynamicExcavationInfo"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local UTIL = require "EE.Interface.Utilities"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local SQUAD = require "Lotus.Scripts.Libs.SquadLib"
local timerType = Type("/Lotus/Types/Game/LotusExcavationState")

local NV_RJ_NUM_DATA_ACQUIRED = Symbol("RJ_NUM_DATA_ACQUIRED")
local NV_RJ_ASSEMBLE_INTEL_STATE = Symbol("RJ_ASSEMBLE_INTEL_STATE")
local NV_RJ_CONSOLE_ACTIVATED = Symbol("RJ_CONSOLE_ACTIVATED")

local NOT_STARTED = 1
local STARTED = 2
local COMPLETE = 99
local mModeState = INVALID
local DEFENSE_TIME = 125
local TIME_DRAIN_RATE = 1
local SetModeState

local UPDATE_INTERVAL = 0.1 -- How frequently we will tick 

local mShipOptions = 2
local mHint = nil
local mAiSpec = nil
local mAiDir = nil
local mUsedShip = nil
local mUsedCrewShips = {}
local usedConsoles = {}

local mTemplate = nil
local mTransmissionSet = nil
local mDataAcquiredTracker = nil
local mInstanceNumber = 0
local mDefenseTimeTracker = {}
local LABEL_INDEX = 2

local mTimers = { }
local mActiveConsoles = { }
local timerReset = false

local dataPiecesLoc = "[HC] Intel Data Pieces Acquired: "
local defenseTimerLoc = "[HC] Defend Console for: "

local function ShouldShutDown()
    if mModeState == COMPLETE then
        return true
    end

    return false
end

local function ShutDownAssembleIntelDataObjective(hint)
    --Destroy crewships
    --set net variables back to 0.
    mAiDir:SetEnableAutoSpawns(false)
    gGameRules:SetNetPersistentVar(NV_RJ_ASSEMBLE_INTEL_STATE, 1)
    gGameRules:SetNetPersistentVar(NV_RJ_NUM_DATA_ACQUIRED, 0)
    gGameRules:SetNetPersistentVar(NV_RJ_CONSOLE_ACTIVATED, 0)
end

local function UpdateUI()
    local collectedPieces =  gGameRules:GetNetPersistentVar(NV_RJ_NUM_DATA_ACQUIRED, 0)
    mDataAcquiredTracker.SetLabel(mDataAcquiredTracker.Localize(dataPiecesLoc) .. collectedPieces .. "/" .. numOfIntelPiecesToAcquire)
    
end

local function UpdateTimer(timer)
    local timeRemaining = timer:GetTimer()
    local index = timer:GetInstanceNumber()
    local trackerName = HUD_INFO_NAME .. index
    local hudTracker = nil
            
    if IsNull(_T.DynamicExcavationHudInfo[index]) then
        hudTracker = {}
        hudTracker[LABEL_INDEX] = _T.AddHudTracker(trackerName .. "Defend Data", LOTUS_UTIL.HT_LABEL, 0.15, 10, true)
            
        _T.DynamicExcavationHudInfo[index] = hudTracker
    else
        hudTracker = _T.DynamicExcavationHudInfo[index]
    end
    
    if not IsNull(hudTracker) then
        local finalTime = UTIL.FormatNumber(timeRemaining - TIME_DRAIN_RATE, 1)
        timer:SetTimer(finalTime)
        
        hudTracker[LABEL_INDEX].SetLabel(hudTracker[LABEL_INDEX].Localize(defenseTimerLoc) .. finalTime)
    end

end

local function AttemptConsoleDeactivation()
    
    if #mActiveConsoles > 0 then
        for i, target in ipairs(mActiveConsoles) do
            local consoleAction = target:GetAttachment(gContextActionType)
            local consoleMarker = target:GetAttachment(gBaseMarkerInfoType)
            local strayAgents = mAiDir:FindAgentsInRange(target, 50, true, false)
                        
            for j, agent in ipairs(strayAgents) do
                if not IsNull(agent) then
                    local avatar = agent:GetAvatar()
                    local consoleDistance = avatar:DistanceToEntity(target)
                
                    --agent:SetExitOnAlertAwareness(false)
                    --agent:SetExitOnCombatAwareness(true)
                    --agent:SetExitOnDamage(true)
                    --agent:SetExitOnEnemySeen(true, 50)
                    --agent:SetAlert()
    
                    agent:StormTarget(target, 0.5)
                
                    if #mTimers == 0 then
                        agent:ReturnToAiControl()
                    end
                
                    if #mTimers > 0 and consoleDistance <= 1 and not avatar:GetFaction() ~= Symbol("TENNO") then
                        if not IsNull(consoleAction) then
                            consoleAction:Enable()
                        end
                        
                        agent:UseContextAction(consoleAction, true)
                    
                        local index = mTimers[i]:GetInstanceNumber()
                    
                        _T.RemoveHudTracker(_T.DynamicExcavationHudInfo[index][LABEL_INDEX])
                    
                        table.remove(mTimers, i)
                        table.remove(mActiveConsoles, i)
                        
                        if not IsNull(consoleMarker) then
                            consoleMarker:Enable()
                        end
                    
                        --if they get to the context action, move on to the hacking loop and reset timer
                        if avatar:IsPlayingAction(Symbol("HitSwitch")) then
                            Broadcast("AssembleIntelDataSubObjective.lua -- TIMER HAS BEEN RESET BY GRINEER!")
                        end
                    
                        --[[if not IsNull(agent) and not avatar:IsKilled() and not avatar:IsPlayingAction(Symbol("HitSwitch")) then
                            agent:ReturnToAiControl()
                            agent:StormTarget(target, 0.5)
                        end]]--
                    end

            
                end
    
            end
    
        end
    end


end

function OnActivated(trigger)
    local hasTriggered = gGameRules:GetNetPersistentVar(NV_RJ_CONSOLE_ACTIVATED, 0)
    
    local user = trigger:GetInstigator()
    
    if not IsNull(user) and user:IsA(gTennoAvatarType) then
    if hasTriggered == 0 then
        local missionState = gGameRules:GetNetPersistentVar(NV_RJ_ASSEMBLE_INTEL_STATE, NOT_STARTED)
        local numOfDataPieces = gGameRules:GetNetPersistentVar(NV_RJ_NUM_DATA_ACQUIRED, 0)
        if missionState == STARTED then
            if numOfDataPieces >= numOfIntelPiecesToAcquire then
                gGameRules:SetNetPersistentVar(NV_RJ_ASSEMBLE_INTEL_STATE, COMPLETE)
            end
        
            if not IsNull(trigger) then
                local consoleDeco = trigger:GetAttachParent()
                local consoleMarker = consoleDeco:GetAttachment(gBaseMarkerInfoType)
                local consoleAction = consoleDeco:GetAttachment(gContextActionType)
                local consolePos = consoleDeco:GetPosition()

                if not IsNull(consoleMarker) then
                   consoleMarker:Disable()
                end
                
                if not IsNull(consoleAction) then
                   consoleAction:Disable()
                end
                
                local timer = gRegion:CreateEntity(timerType, consolePos, ZERO_ROTATION, consoleDeco, consoleDeco)
                timer:SetTimer(DEFENSE_TIME)
                timer:Enable(true)
                
                mInstanceNumber = mInstanceNumber + 1
                timer:SetInstanceNumber(mInstanceNumber)
                
                table.insert(mTimers, timer)
                table.insert(mActiveConsoles, consoleDeco)
                
                --mAiDir:OrderNpcsStormTarget(consoleDeco, 20)
                
            end
            gGameRules:SetNetPersistentVar(NV_RJ_CONSOLE_ACTIVATED, 1)
            
            return 1
        end
    end
    gGameRules:SetNetPersistentVar(NV_RJ_CONSOLE_ACTIVATED, 0)
    end
end

local function ActivateConsoles()
    local crewshipMgr = gGameRules:GetCrewShipManager()
    local ships = crewshipMgr:GetShips(false)
    
    while #ships < mShipOptions do
        ships = crewshipMgr:GetShips(false)
        Sleep(0)
    end
    
    local randomIndex = RandomInt(1, #ships)
    local ship = ships[randomIndex]
            
    mUsedShip = ships[randomIndex]
            
    local consoleDeco = RJ_UTIL.FindTaggedOnShip(RJConsoleDecoTag, ship)
    
    while #consoleDeco < numOfIntelPiecesToAcquire do
        randomIndex = RandomInt(1, #ships)
        ship = ships[randomIndex]
        
        mUsedShip = ships[randomIndex]
        
        consoleDeco = RJ_UTIL.FindTaggedOnShip(RJConsoleDecoTag, ship)
    
    end
    
    for i = 1, numOfIntelPiecesToAcquire do
        if #consoleDeco > 0 then
            local randConsoleIndex = RandomInt(1, #consoleDeco)
            local randConsole = consoleDeco[randConsoleIndex]
            
            table.remove(consoleDeco, randConsoleIndex)
            
            local consoleMarker = randConsole:GetAttachment(gBaseMarkerInfoType)
            local consoleAction = randConsole:GetAttachment(gContextActionType)

            randConsole:SetVisibility(true, true)

            if not IsNull(consoleMarker) then
                consoleMarker:Enable()
            end

            if not IsNull(consoleAction) then
                ObjectPortHandler(consoleAction, "OnActivated")
                consoleAction:Enable()
                table.insert(usedConsoles, randConsole)
            end
        end
    end
end

local function OnModeStateChanged()
    if mModeState == STARTED then
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/AssembleIntelData", 1)
        ActivateConsoles()
        RJ_UTIL.SetCrewShipEnterMarker(true, mUsedShip)
    elseif mModeState == COMPLETE then
        RJ_UTIL.SetCrewShipEnterMarker(false, mUsedShip)
        RJ_UTIL.SetCrewShipExitMarker(true, mUsedShip)
        
        _T.RemoveHudTracker(mDataAcquiredTracker)
        _T.DynamicExcavationHudInfo = nil
        
        mHint:SetEncounterStatus(Npc.ES_SUCCEEDED)
        
    end
end

local function Update(deltaTime)
    local modeState = gGameRules:GetNetPersistentVar(NV_RJ_ASSEMBLE_INTEL_STATE, NOT_STARTED)
    if modeState ~= mModeState then
        mModeState = modeState
        mHint:SetEncounterDynamicState(modeState)
        OnModeStateChanged(modeState)
    end

    if mModeState == STARTED then
        local numOfDataPieces = gGameRules:GetNetPersistentVar(NV_RJ_NUM_DATA_ACQUIRED, 0)
        
        for i, time in ipairs(mTimers) do
            local timeRemaining = time:GetTimer()
            local index = time:GetInstanceNumber()
            
            if timeRemaining == 0 then
                numOfDataPieces = numOfDataPieces + 1
                gGameRules:SetNetPersistentVar(NV_RJ_NUM_DATA_ACQUIRED, numOfDataPieces)
                
                _T.RemoveHudTracker(_T.DynamicExcavationHudInfo[index][LABEL_INDEX])
                
                UpdateUI()
                
                table.remove(mTimers, i)
                table.remove(mActiveConsoles, i)
            else
                UpdateTimer(time)
                AttemptConsoleDeactivation()
            end
            
        end
        
        
        if numOfDataPieces >= numOfIntelPiecesToAcquire then
            SetModeState(COMPLETE)
        end
    elseif mModeState == COMPLETE then
    
    end
end

function CanActivateAssembleIntelDataEncounter()
    -- check if the proc system placed the correct rooms/objects in thte node. If not return false

    local playerAvatars = gRegion:GetHumanPlayerAvatars()
    local crewshipMgr = gGameRules:GetCrewShipManager()
    local ships = crewshipMgr:GetShips(false)

    local numOfAvailShips = 0

    for i=1, #ships do
        local ship = ships[i]

        local playerFound = false
        if not IsNull(ship) then
            for i=1, #playerAvatars do
                local playerAvatar = playerAvatars[i]

                if not IsNull(playerAvatar) and ship:IsEntityOnBoardShip(playerAvatar) then
                    playerFound = true
                    break
                end
            end

            if not playerFound then
                local consoleDeco = RJ_UTIL.FindFirstTaggedOnShip(RJConsoleDecoTag, ship)

                if not IsNull(consoleDeco) then
                    numOfAvailShips = numOfAvailShips + 1

                    if numOfAvailShips >= numOfIntelPiecesToAcquire then
                        break
                    end
                end
            end
        end
    end

    if numOfAvailShips >= numOfIntelPiecesToAcquire then
        return 1
    end

    return 0
end

local function Initialize(hint)
    mHint = hint
    mTemplate = mHint:GetCurrentEncounterTemplate()
    mTransmissionSet = mTemplate:GetTransmissionSet()

    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    if not IsNull(gGameRules) then
        --mAiSpec = capitalShipAiSpec
        local mission = gGameRules:GetMission()
        mAiSpec = mission.enemySpec
        if IsNull(mAiSpec) then
            mAiSpec = capitalShipAiSpec
            mission.enemySpec = capitalShipAiSpec
            gGameRules:SetMission(mission)
            mAiDir:AssignMissionAISpec(mAiSpec)
        end
    end

    local levelInfo = gRegion:GetLevelInfo()
    
    if IsNull(_T.DynamicExcavationHudInfo) then
        _T.DynamicExcavationHudInfo = {}
    end
    
    mDataAcquiredTracker = _T.AddHudTracker("Data Acquired", LOTUS_UTIL.HT_LABEL)
    UpdateUI()
    
    SetModeState(gGameRules:GetNetPersistentVar(NV_RJ_ASSEMBLE_INTEL_STATE, NOT_STARTED))

    if mModeState == NOT_STARTED then
        SetModeState(STARTED)
    elseif mModeState >= STARTED then
    
    end
end

function AssembleIntelData(hint)

    Broadcast("AssembleIntelDataSubObjective.lua -- Assemble Intel Data SubObjective Started")
    Initialize(hint)

    local sleepTime = UPDATE_INTERVAL

    while not ShouldShutDown() do
        Update(sleepTime)
        Sleep(sleepTime)
    end

    ShutDownAssembleIntelDataObjective(hint)
end

SetModeState = function(newState)
    if mModeState ~= newState then
        mModeState = newState
        mHint:SetEncounterDynamicState(newState)
        gGameRules:SetNetPersistentVar(NV_RJ_ASSEMBLE_INTEL_STATE, newState)
        OnModeStateChanged()
    else
        print("AssembleIntelDataSubObjective.lua::SetModeState - trying to set mode to state we're already in")
    end
end