reactorDestroyedDroptable = Resource()
cinematic = Instance()
pilotAction = Instance()
lootCrateType = Type()
lootCrateChance = 0.7
maxLootCrates = 5
preDeathRepairDelay = 30
preDeathRepairPortion = 0.5
preDeathRepairTime = 10
executeAction = Instance()
emptyVersion = false

--local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local TABLE = require "Lotus.Scripts.Libs.TableLib"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"

local sCrewSpawnPoint = Symbol("CrewSpawnPoint")
local sCaptainSpawnPoint = Symbol("CaptainSpawnPoint")
local sBridgeDV = Symbol("BridgeDefenseVolume")
local sBridgeSpawnPoint = Symbol("BridgeCrewSpawnPoint")
local sCameraTilt = Symbol("CameraTilt")
local sReactor = Symbol("EngineReactor")
local sReactorConsole = Symbol("ReactorConsole")
local sDamageForwarder = Symbol("ShipDamageForwarder")
local sReactorDamageTrigger = Symbol("ReactorDamageTrigger")
local sBoardingAction = Symbol("BoardingHatch")
local sGrineer = Symbol("Grineer")
local sTenno = Symbol("TENNO")

local SYM_ENGINE_MAIN = Symbol("MainEngine")
local SYM_ENGINE_MANEUVERLEFT = Symbol("LeftManeuverThruster")
local SYM_ENGINE_MANEUVERRIGHT = Symbol("RightManeuverThruster")

local meltdownTimerLoc = "/Lotus/Language/Railjack/CrewshipReactorMeltdown"

local mHint = nil
local mAiDir = nil
local mTransmissionSet = nil
local mModeMgr = nil
local mTimerMgr = nil
local mCrewShip = nil
local mAvatar = nil
local mAgent = nil
local mAgentLevelRange = nil
local mCaptainSpawn = nil
local mBridgeDefenseVolume = nil
local mBridgeCrewSpawns = nil
local mEmplacementData = {}
local mMeltdownTimerTracker = nil
local mMeltdownObjectiveTracker = nil
local mCameraTiltTrigger = nil
local mReactor = nil
local mReactorConsole = nil
local mDamageForwarders = nil
local mReactorMeltdownTriggers = nil
local mDamageIntervals = {90, 80, 70, 60, 50, 40, 30, 20, 10}
local mCaptainAgent = nil
local mCrewSpec = nil
local mBoardingActions = {}
local mAgentTeam = EMPTY_SYMBOL
local mPostFadeTrigger = nil
local mSuicideAvatars = {}
local mAvatarName = ""

local mNumEngines = 0
local mNumToSpawn = 0
local mSpawns = {}
local mEnginesDisabled = 0
local mSpeedInterval = 0
local mAlerted = false
local mManeuverEnginesDisabled = 0
local mManeuverInterval = 0
local mNumManeuverEngines = 0
local mEngineRepairQueue = {}
local SetEngineEnabled = nil

local INVALID = -1
local SPAWNED = 0
local BOARDED = 1
local SPAWN_EMPLACEMENT_USERS = 2
local SPAWN_CREW = 3
local SPAWN_BRIDGE_CREW = 4
local MANAGE_CREWSHIP = 5
local REACTOR_DESTROYED = 6
local INSTANT_DESTROY = 7

local NUM_CREW = Range(10, 15)
local BRIDGE_CREW_COUNT = 2
local MAX_HANDS = 4
local MELTDOWN_TIME_LIMIT = 25
local ENGINE_REPAIR_NPC_TIME = 30
local ENGINE_DAMAGE_PCT = 0.2
local REACTOR_LOCKOUT_LVL = 26
local REACTOR_INVULN = false

local ENGINE_PARTS = { Engine.LEG_LEFT, Engine.LEG_RIGHT, Engine.HEAD, Engine.ARM_LEFT, Engine.ARM_RIGHT }
local DISABLE_ENGINE_DAMAGE = false

local SYM_SELF = Symbol("GrineerCrewShipEncounter.lua")

local SYM_ENGINE_MAIN = Symbol("MainEngine")
local SYM_ENGINE_MANEUVERLEFT = Symbol("LeftManeuverThruster")
local SYM_ENGINE_MANEUVERRIGHT = Symbol("RightManeuverThruster")

reactorShieldDeco = Type("/Lotus/Fx/Enemies/Grineer/SpaceCrewShip/GrnCrewShipEngineShieldDeco")

meltdownSpawner = Resource("/Lotus/Fx/Enemies/Grineer/SpaceCrewShip/GrnCrewShipExtMeltdown")
meltdownSpawnerquick = Resource("/Lotus/Fx/Enemies/Grineer/SpaceCrewShip/GrnCrewShipExtMeltdownQuick")
meltdownFinalExplosion = Resource("/Lotus/Fx/Enemies/Grineer/SpaceCrewShip/GrnCrewShipExplosionEnd")

sidearmProjector = Resource("/Lotus/Fx/Enemies/Grineer/SpaceCrewShip/GrnCrewShipExtMeltdownSidearms")
sidearmProjectorQuick = Resource("/Lotus/Fx/Enemies/Grineer/SpaceCrewShip/GrnCrewShipExtMeltdownSidearms")
sidearmTypeR = Type("/Lotus/Objects/Grineer/Ships/GrnDropship/GrnCrewShipREngineDeco")
sidearmTypeL = Type("/Lotus/Objects/Grineer/Ships/GrnDropship/GrnCrewShipLEngineDeco")


local function AttachProjectorsToChildren(entity, doQuick)
    local rightArm = entity:GetAttachment(sidearmTypeR)
    local leftArm = entity:GetAttachment(sidearmTypeL)
    local sidearmAttachment = sidearmProjector
    if doQuick then
        sidearmAttachment = sidearmProjectorQuick
    end
    if not IsNull(rightArm) then
        rightArm:Attach(sidearmAttachment, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION)
    end
    if not IsNull(leftArm) then
        leftArm:Attach(sidearmAttachment, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION)
    end
end

local function DismountAllEmplacements()
    for i, data in ipairs(mEmplacementData) do
        local user = data.user
        if not IsNull(user) and i > 1 then
            data.emplacement:FirePort("ForceUserToDismount")
            local agent = user:GetAgent()
            if not IsNull(agent) then
                agent:ReturnToAiControl()
            end
        end
    end
end

-- TC Hack to hide LotusDynamicProjectors on engines upon loading ("Active" toggle does nothing")
function InitSetVisibiltyOff(entity)
    if not IsNull(entity) then
        entity:SetVisibility(false, false)
    end
end

function ReactorDestroyedFx(deco)
    local unlitAtten = 1.5 --TODO: deco:GetMaterialParam(Lotus_Game.UNLIT_ATTEN, 1)
    local atten = unlitAtten
    local t = 0
    local duration = 3
    while t < duration do
        Sleep(0)
        t = t + DeltaTime()
        atten = Lerp(0.05, unlitAtten, 1 - (t / duration))
        deco:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, atten)
    end
end

local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    if curState == SPAWNED then
        
    elseif curState == BOARDED then
        mNumToSpawn = mAiDir:ScaleNpcCountForPlayers(NUM_CREW.minValue, NUM_CREW.maxValue)
        TABLE.InPlaceShuffle(mSpawns)
        local shipEncounterHint = mAgent:GetOwningEncounter()
        if not IsNull(shipEncounterHint) then
            shipEncounterHint:DeregisterAgent(mAgent)
            local childHints = shipEncounterHint:GetChildEncounters()
            if not IsNull(childHints) then
                for i = 1, #childHints do
                    childHints[i]:DeregisterAgent(mAgent)
                end
            end
        end
    elseif curState == SPAWN_BRIDGE_CREW then
        local agentType = mAiDir:GetRandomEnemyAgentTypeFromAISpec(mCrewSpec, Symbol("Grineer"), mAgentLevelRange.maxValue, true, false, 80, true)
        local agent = mAiDir:CreateAgent(agentType, mCaptainSpawn, mAgentTeam, mAgentLevelRange.maxValue)
        if not IsNull(agent) then
            local avatar = agent:GetAvatar()
            agent:SetDefenseVolume(mBridgeDefenseVolume, true)
            ObjectPortHandler(avatar, "OnKilled")
            mCaptainAgent = agent
            mHint:RegisterAgent(agent)
        else
            print("failed to spawn captain")
        end
        
        mNumToSpawn = BRIDGE_CREW_COUNT
    elseif curState == REACTOR_DESTROYED then
        for i, action in ipairs(mBoardingActions) do
            if not IsNull(action) then
                action:Disable()
            end
        end
        
        mAvatar:DamageControl():SetPreDeathEnabled(false)
    
        --mAvatar:SetHealth(5)

        if not IsNull(reactorDestroyedDroptable) then
            mAvatar:SetDropTable(reactorDestroyedDroptable)
        end
        
        DismountAllEmplacements()
        _T.RemoveHudTracker(mMeltdownObjectiveTracker)
        TABLE.InPlaceShuffle(mReactorMeltdownTriggers)
        for i = 1, #mReactorMeltdownTriggers do --/ 2 do
            mReactorMeltdownTriggers[i]:Enable()
        end
        mMeltdownTimerTracker = _T.AddHudTracker("MeltdownTracker", LOTUS_UTIL.HT_TIMER)
        mMeltdownTimerTracker.SetVisible(false, true)
        mMeltdownTimerTracker.SetLabel(meltdownTimerLoc)
        mMeltdownTimerTracker.StartTimer(MELTDOWN_TIME_LIMIT, false)
        mMeltdownTimerTracker.SetLocation(mCrewShip:GetInteriorLayer() + 1)
        mCameraTiltTrigger:FirePort("Execute")
        mTimerMgr:AddTimer(8, function() mCameraTiltTrigger:FirePort("Execute") end)
        mTimerMgr:AddTimer(16, function() mCameraTiltTrigger:FirePort("Execute") end)
        mTimerMgr:AddTimer(MELTDOWN_TIME_LIMIT - 1, function() mPostFadeTrigger:FirePort("Execute") end)
        
        local DestroyEngine = function()
            local dmgCtrl = mAvatar:DamageControl()
            local numGroups = dmgCtrl:GetNumArmourGroups()
            for i = 0, numGroups -1 do
                local group = dmgCtrl:GetArmourGroupAtIndex(i)
                local tag = group:GetTag()
                if (tag == SYM_ENGINE_MAIN or tag == SYM_ENGINE_MANEUVERLEFT or tag == SYM_ENGINE_MANEUVERRIGHT) and not group:IsDestroyed() then
                    group:SetDestroyed()
                    Broadcast("Destroying group " .. tag:c_str())
                    return
                end
            end
        end
        
        mTimerMgr:AddTimer(1, DestroyEngine)
        mTimerMgr:AddTimer(1.5, DestroyEngine)
        mTimerMgr:AddTimer(2.25, DestroyEngine)
        
        mReactor:ScriptRunChildScript(Symbol("ReactorDestroyedFx"), false)
        if not IsNull(meltdownSpawner) then
            mAvatar:Attach(meltdownSpawner, EMPTY_SYMBOL)
            AttachProjectorsToChildren(mAvatar, false)
        end
        mBridgeDefenseVolume:Disable()
        local agents = mHint:GetRegisteredAgents()
        for i, agent in ipairs(agents) do
            agent:StormTarget(mReactor, 10)
        end

        local showDestructionElsewhere = RAIL.FindTaggedOnShip(Symbol("ReactorDown"), mCrewShip)
        for i, entity in ipairs(showDestructionElsewhere) do
            entity:FirePort("TriggerPort")
        end
            
        local tagged = RAIL.FindTaggedOnShip(Symbol("ReactorFuelPipe"), mCrewShip)
        for i, entity in ipairs(tagged) do
            entity:Destroy()
        end
        print(mAvatar:GetFullName() .. " melting down!")
    elseif curState == INSTANT_DESTROY then
        for i, action in ipairs(mBoardingActions) do
            action:Disable()
        end
        mAvatar:DamageControl():SetPreDeathEnabled(false)
        --mAvatar:SetHealth(5)
        mCrewShip:InhibitReactor(100)
        mTimerMgr:AddTimer(5, 
            function() 
                mHint:SetEncounterStatus(Npc.ES_COMPLETE) 
                gRegion:CreateEntity(meltdownFinalExplosion, mAvatar:GetPosition(), mAvatar:GetRotation())
            end)
        if not IsNull(meltdownSpawnerquick) then
            mAvatar:Attach(meltdownSpawnerquick, EMPTY_SYMBOL)
            --AttachProjectorsToChildren(mAvatar, true)
        end
        print(mAvatar:GetFullName() .. " instantly destroyed!")
    end
end

function OnDisable(action)
    if action == mReactorConsole and not IsNull(mReactor) and REACTOR_INVULN then
        local shieldDeco = mReactor:GetAttachment(reactorShieldDeco)
        if not IsNull(shieldDeco) then
            shieldDeco:PlayTriggeredFade()
        end
        
        mReactor:MakeVulnerable()
        REACTOR_INVULN = false
    end
end

function OnFinished(action)
    if action ~= mReactorConsole then
        if mModeMgr:GetModeState() == SPAWNED then
            mModeMgr:SetModeState(BOARDED)
        end
    end
end

function OnDestroyed(entity)
    local state = mModeMgr:GetModeState()
    if state ~= REACTOR_DESTROYED and state ~= INSTANT_DESTROY then
        local instigator = entity:GetDamageInstigator() 
        if instigator ~= entity then
            --reactor destroyed from the inside
            mModeMgr:SetModeState(REACTOR_DESTROYED)
        elseif mAvatar:DamageControl():IsPreDeath() then
            --received too much damage externally
            mModeMgr:SetModeState(INSTANT_DESTROY)
        else
            --railjack laser
            mModeMgr:SetModeState(INSTANT_DESTROY)
        end
    end
end

function OnKilled(avatar)
    if avatar:GetAgent() == mCaptainAgent then
        DismountAllEmplacements()
        
        local avatars = RAIL.GetPlayerAvatarsOnShip(mCrewShip)
        local agents = mHint:GetRegisteredAgents()
        
        for i, agent in ipairs(agents) do
            local target = avatars[RandomInt(1, #avatars)]
            agent:StormTarget(target, 10)
        end
        
        mBridgeDefenseVolume:Disable()
    end
end

local function RepairEngine(group)
    group:SetDestroyed(false)
    group:SetCurrentHealth(group:GetMaxHealth())
end

local function RepairEngineNpc(group)
    if not group:IsDestroyed() then
        return
    end
    local curState = mModeMgr:GetModeState()
    if 
        curState < BOARDED or
        curState > BOARDED and 
        curState < REACTOR_DESTROYED and
        mHint:GetNumRegisteredAgents() > 0 
    then
        local nextRepair = mEngineRepairQueue[1]
        table.remove(mEngineRepairQueue, 1)
        RepairEngine(group)
    end
end

local function BeginPredeathRepairs(avatar)
    local maxHealth = avatar:GetMaxHealth()
    avatar:DamageControl():SetPreDeathHealthThreshold(maxHealth * preDeathRepairPortion)
    avatar:InventoryControl():AddUpgrade(Game.AVATAR_HEAL_PERCENT_MAX_HEALTH, Game.SET, 1 / (preDeathRepairTime * preDeathRepairPortion))
end

local function IsManeuverThruster(part)
    return (part == Engine.ARM_LEFT or part == Engine.ARM_RIGHT)
end

--no tag == affect all engines
SetEngineEnabled = function(engineTag, part, enable, dd)
    
    --Apply upgrades
    if enable then
        if not IsNull(engineTag) then
            if IsManeuverThruster(part) then
                local multiplier = (1 - (mManeuverInterval * mManeuverEnginesDisabled))
                print("Removing " .. multiplier .. "X multiplier to AVATAR_ACROBATIC_SPEED")
                mAvatar:InventoryControl():RemoveUpgrade(Game.AVATAR_ACROBATIC_SPEED, Game.MULTIPLY, multiplier)
                mManeuverEnginesDisabled = UTIL.Ternary(IsNull(engineTag), mNumManeuverEngines, mManeuverEnginesDisabled - 1)
                if mManeuverEnginesDisabled > 0 then
                    multiplier = (1 - (mManeuverInterval * mManeuverEnginesDisabled))
                    print("Adding " .. multiplier .. "X multiplier to AVATAR_ACROBATIC_SPEED")
                    mAvatar:InventoryControl():AddUpgrade(Game.AVATAR_ACROBATIC_SPEED, Game.MULTIPLY, multiplier)
                end
            end
            
            local multiplier = (1 - (mSpeedInterval * mEnginesDisabled))
            mAvatar:InventoryControl():RemoveUpgrade(Game.AVATAR_MOVEMENT_SPEED, Game.MULTIPLY, multiplier)
            mEnginesDisabled = mEnginesDisabled - 1
            print("Removing " .. multiplier .. "X multiplier to movement speed")

            if mEnginesDisabled > 0 then
                multiplier = (1 - (mSpeedInterval * mEnginesDisabled))
                mAvatar:InventoryControl():AddUpgrade(Game.AVATAR_MOVEMENT_SPEED, Game.MULTIPLY, multiplier)
                print("Adding " .. multiplier .. "X multiplier to movement speed")
            end
        end
    else
        if DISABLE_ENGINE_DAMAGE then
            return
        end
        
        local disableEngines = true
        
        local curState = mModeMgr:GetModeState()
        if curState >= BOARDED and curState < REACTOR_DESTROYED then
            local pilot = mEmplacementData[1].user
            if IsNull(pilot) then
                disableEngines = false
            elseif not pilot:IsA(gLotusNpcAvatarType) then
                disableEngines = false
            end
        end
        
        -- Only break engines if the Pilot is still alive
        if disableEngines then
            local dmgCtrl = mAvatar:DamageControl()
            local group = nil
            
            if curState < REACTOR_DESTROYED then
                for i = 0, dmgCtrl:GetNumArmourGroups() - 1 do
                    group = dmgCtrl:GetArmourGroupAtIndex(i)
                    if group:GetPart() == part then
                        mTimerMgr:AddTimer(ENGINE_REPAIR_NPC_TIME, RepairEngineNpc, false, group)
                        break
                    end
                end
            end

            if engineTag then
                if IsManeuverThruster(part) then
                    mAvatar:InventoryControl():RemoveUpgrade(Game.AVATAR_ACROBATIC_SPEED, Game.MULTIPLY, (1 - (mManeuverInterval * mManeuverEnginesDisabled)))
                    print("Removing " .. (1 - (mManeuverInterval * mManeuverEnginesDisabled)) .. "X multiplier to AVATAR_ACROBATIC_SPEED")

                    mManeuverEnginesDisabled = UTIL.Ternary(IsNull(engineTag), mNumManeuverEngines, mManeuverEnginesDisabled + 1)
                    
                    mAvatar:InventoryControl():AddUpgrade(Game.AVATAR_ACROBATIC_SPEED, Game.MULTIPLY, (1 - (mManeuverInterval * mManeuverEnginesDisabled)))
                    print("Adding " .. (1 - (mManeuverInterval * mManeuverEnginesDisabled)) .. "X multiplier to AVATAR_ACROBATIC_SPEED")   
                end
                
                --slow them down
                mAvatar:InventoryControl():RemoveUpgrade(Game.AVATAR_MOVEMENT_SPEED, Game.MULTIPLY, (1 - (mSpeedInterval * mEnginesDisabled)))
                print("Removing " .. (1 - (mSpeedInterval * mEnginesDisabled)) .. "X multiplier to movement speed")
                
                mEnginesDisabled = UTIL.Ternary(IsNull(engineTag), mNumEngines, mEnginesDisabled + 1)
                
                mAvatar:InventoryControl():AddUpgrade(Game.AVATAR_MOVEMENT_SPEED, Game.MULTIPLY, (1 - (mSpeedInterval * mEnginesDisabled)))
                print("Adding " .. (1 - (mSpeedInterval * mEnginesDisabled)) .. "X multiplier to movement speed")

                local damageData = Engine.DamageData()
                damageData.baseAmount = mAvatar:GetMaxHealth() * ENGINE_DAMAGE_PCT
                damageData:SetDamagePct(Engine.DT_HEALTH_DRAIN, 1.0)
                damageData:SetHitPart(Engine.TORSO)

                if not IsNull(dd) then
                    damageData:SetSource(dd:GetSource())
                    damageData:SetSourceObject(dd:GetSourceObject())
                end
                
                mAvatar:DamageDD(damageData)
                
                table.insert(mEngineRepairQueue, group)
            end
        end
    end
end

function OnDismount(action)
    for i, data in ipairs(mEmplacementData) do
        if data.emplacement == action then
            if not IsNull(data.user) and not IsNull(data.user:GetPlayer()) then
                data.user:InventoryControl():ToggleTrackDamageDealt(false, 0, false)
            end
            
            data.user = nil
        end
    end
end

function OnPreDeath(avatar)
    local agent = avatar:GetAgent()
    if not IsNull(agent) then
        agent:SetPaused(true, SYM_SELF)
        avatar:InventoryControl():RemoveUpgrade(Game.AVATAR_HEAL_PERCENT_MAX_HEALTH, Game.SET, 1 / (preDeathRepairTime * preDeathRepairPortion))
        
        if avatar:GetFaction() == sTenno then
            if not IsNull(mReactor) then
                mModeMgr:SetModeState(REACTOR_DESTROYED)
            end
        else
            mTimerMgr:AddTimer(preDeathRepairDelay, BeginPredeathRepairs, false, avatar)
        end
    end
    --if avatar == mAvatar then
    --    for i, action in ipairs(mBoardingActions) do
    --        action:Enable()
    --    end
    --    local attachments = mAvatar:GetAllAttachments(gDecorationType)
    --    for i, attachment in ipairs(attachments) do
    --        if attachment:HasTag(sBoardingAction) then
    --            attachment:Destroy()
    --        end
    --    end
    --    
    --    if mModeMgr:GetModeState() <= MANAGE_CREWSHIP then
    --        mReactor:Destroy()
    --        mModeMgr:SetModeState(REACTOR_DESTROYED)
    --    end
    --end
end

local function Initialize(hint)
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()
    mHint = hint
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, nil)
    mTimerMgr = TIMER.CreateTimerMgr()
    
    local crewShipMgr
    while IsNull(mCrewShip) do
        if IsNull(mHint) then
            return
        end
        if IsNull(crewShipMgr) and not IsNull(gGameRules) then
            crewShipMgr = gGameRules:GetCrewShipManager()
        end
        if not IsNull(crewShipMgr) then
            mCrewShip = crewShipMgr:GetShipForZone(mHint:GetZone())
        end
        if IsNull(mCrewShip) then
            Sleep(0.1)
        end
    end

    mCrewSpec = mCrewShip:GetCrewSpec()
    mAvatar = mCrewShip:GetAvatarOwner()
    mAgent = mAvatar:GetAgent()
    
    if emptyVersion then
        mAvatar:PushFactionOverride(Symbol("EmptyDestroyer"), Symbol("TENNO"))
    end
    
    mSpawns = RAIL.FindTaggedOnShip(sCrewSpawnPoint, mCrewShip)
    mCaptainSpawn = RAIL.FindFirstTaggedOnShip(sCaptainSpawnPoint, mCrewShip)
    mBridgeDefenseVolume = RAIL.FindFirstTaggedOnShip(sBridgeDV, mCrewShip)
    mBridgeCrewSpawns = gRegion:FindTaggedInRadius(sBridgeSpawnPoint, mCaptainSpawn:GetPosition(), 0, 20)
    mCameraTiltTrigger = RAIL.FindFirstTaggedOnShip(sCameraTilt, mCrewShip)
    
    local level = mAvatar:GetCurrentLevel()
    
    mReactor = RAIL.FindFirstTaggedOnShip(sReactor, mCrewShip)
    if not IsNull(mReactor) then
        local defaultHealth = mReactor:GetDefaultHealth()
        local health = mReactor:GetHealth()
        
        local newHealth = defaultHealth + (defaultHealth * (level / 100))
        mReactor:SetDefaultHealth(newHealth)
        if health >= defaultHealth then
            mReactor:SetHealth(newHealth)            
            if level >= REACTOR_LOCKOUT_LVL then
                mReactor:Attach(reactorShieldDeco, EMPTY_SYMBOL)
                mReactor:MakeInvulnerable()
                REACTOR_INVULN = true
            end
        end
        
        ObjectPortHandler(mReactor, "OnDestroyed")
    end
    
    mReactorConsole = RAIL.FindFirstTaggedOnShip(sReactorConsole, mCrewShip)
    if level >= REACTOR_LOCKOUT_LVL then
        ObjectPortHandler(mReactorConsole, "OnDisable")
    else
        mReactorConsole:FirePort("Disable")
    end

    mAgentLevelRange = Range(mAiDir:GetMinEnemyLevel(), mAiDir:GetMaxEnemyLevel())
    if mAgentLevelRange.minValue == 1 and mAgentLevelRange.maxValue == 1 then
        --this is a test level, override
        mAgentLevelRange.minValue = 20
        mAgentLevelRange.maxValue = 25
    end
    
    mDamageForwarders = RAIL.FindTaggedOnShip(sDamageForwarder, mCrewShip)
    mReactorMeltdownTriggers = RAIL.FindTaggedOnShip(sReactorDamageTrigger, mCrewShip)
    
    --TODO: Use a c++ callback instead?

    local avatarFullName = mAvatar:GetFullName()
    
    mAvatar:RegisterOnPredeathCallback("OnPreDeath")
    mAgentTeam = Symbol(avatarFullName)
    mAvatarName = mAvatar:GetFullName()
    
    local damageControl = mAvatar:DamageControl()
    damageControl:RegisterArmourDestroyedChangedCallback("OnArmourGroupDestroyedChanged")
    
    mBoardingActions = mAvatar:GetAllAttachments(gContextActionType)
    for i, action in ipairs(mBoardingActions) do
        ObjectPortHandler(action, "OnFinished")
    end
    
    mPostFadeTrigger = RAIL.FindFirstTaggedOnShip(Symbol("ReactorDestroyedFadeScript"), mCrewShip)
    
    local index = 0
    local emp = mCrewShip:GetShipEmplacement(index)
    while not IsNull(emp) do
        ObjectPortHandler(emp, "OnActivated")
        ObjectPortHandler(emp, "OnDismount")
        local data = 
        {
            user = emp:GetCurrUser(),
            emplacement = emp
        }
        
        mEmplacementData[index + 1] = data
        index = index + 1
        emp = mCrewShip:GetShipEmplacement(index)
    end

    local groupCount = damageControl:GetNumArmourGroups()
    -- Armour Group Index starts at 0, for reasons
    for i=0, groupCount - 1 do
        local ag = damageControl:GetArmourGroupAtIndex(i)
        if not IsNull(ag) then
            local tag = ag:GetTag()
            if tag == SYM_ENGINE_MANEUVERLEFT or tag == SYM_ENGINE_MANEUVERRIGHT then
                mNumManeuverEngines = mNumManeuverEngines + 1
                mNumEngines = mNumEngines + 1
            elseif tag == SYM_ENGINE_MAIN then
                mNumEngines = mNumEngines + 1
            end
        end
    end
    
    mSpeedInterval = 1 / mNumEngines
    mManeuverInterval = 1 / mNumManeuverEngines
    
    local dmgCtrl = mAvatar:DamageControl()
    for i = 0, dmgCtrl:GetNumArmourGroups() - 1 do
        local group = dmgCtrl:GetArmourGroupAtIndex(i)
        if group:IsDestroyed() then
            --staggering the repairs after host migration
            mTimerMgr:AddTimer(ENGINE_REPAIR_NPC_TIME - i*2, RepairEngineNpc, false, group)
        end
    end
    
    local netState = mHint:GetEncounterDynamicState()
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, SPAWNED, netState))
    
    if hint:GetEncounterStatus() == Npc.ES_SETUP then
        local lootPoints = RAIL.FindTaggedOnShip(Symbol("LootCrate"), mCrewShip)
        for i = 1, maxLootCrates do
            if math.random() <= lootCrateChance then
                if #lootPoints == 0 then
                    break
                end
        
                local pointIndex = RandomInt(1, #lootPoints)
                local point = lootPoints[pointIndex]
                table.remove(lootPoints, pointIndex)
                gRegion:CreateEntity(lootCrateType, point:GetPosition(), point:GetRotation())
            end
        end

        hint:SetEncounterStatus(Npc.ES_ACTIVE)
    end
end

local function UpdateDamageState()
    if #mDamageForwarders > 0 and #mDamageIntervals > 0 and mAvatar:GetHealthPercentage() * 100 < mDamageIntervals[1] then
        local index = RandomInt(1, #mDamageForwarders)
        mDamageForwarders[index]:FirePort("TriggerPort")
        table.remove(mDamageForwarders, index)
        table.remove(mDamageIntervals, 1)
    end
end

local function SpawnAgent(potentialSpawns, tier, dv)
    local agentType = mAiDir:GetRandomEnemyAgentTypeFromAISpec(mCrewSpec, Symbol("Grineer"), mAgentLevelRange.maxValue, true, false, tier, true)
    if IsNull(agentType) then
        print("failed to find agent type at tier " .. tier)
        return
    end
    
    local agent = mAiDir:CreateAgent(agentType, potentialSpawns[mNumToSpawn], mAgentTeam, mAgentLevelRange:Rand())
    if not IsNull(agent) then
        mHint:RegisterAgent(agent)
        
        if mAlerted then
            agent:SetAlert()
        end
        
        if not IsNull(dv) then
            agent:SetDefenseVolume(dv, true)
        end
    else
        if not IsNull(potentialSpawns[mNumToSpawn]) then
            print("Failed to spawn agent of type " .. agentType:GetName() .. " at " .. potentialSpawns[mNumToSpawn]:GetFullName())
        else
            print("Failed to spawn agent of type " .. agentType:GetName() .. " at a NULL spawn point!")
            print("mNumToSpawn " .. mNumToSpawn .. " #potentialSpawns " .. #potentialSpawns)
        end
    end
end

--Main function - Contains main update loop, monitor mode state here
function Start(hint)
    if IsNull(hint) or IsNull(hint:GetCurrentEncounterTemplate()) then
        return
    end

    Initialize(hint)
    
    local curState = INVALID
    local nextEmplacement = 0
    local INVALID_HEALTH  = 99999999999
    local initialPreDeathHealth = INVALID_HEALTH
    
    --[[
    if gFlashMgr:GetConfigBool("LotusGameRules.MissionDebug") then
        mTimerMgr:AddTimer(10, function() mModeMgr:SetModeState(REACTOR_DESTROYED) end)
    end
    ]]
    
    while true do
        if gGameRules:MissionCompleted() or gGameRules:MissionFailed() or IsNull(hint) or hint:GetEncounterStatus() >= Npc.ES_COMPLETE or IsNull(mCrewShip) then
            break
        end
        curState = mModeMgr:GetModeState()

        if initialPreDeathHealth == INVALID_HEALTH and not IsNull(mAvatar) and not IsNull(mAvatar:DamageControl()) then
            initialPreDeathHealth = mAvatar:DamageControl():PreDeathHealthThreshold()
        end
        
        if not IsNull(mAvatar) then
            local preDeathHealth = mAvatar:DamageControl():PreDeathHealthThreshold()
            if preDeathHealth > initialPreDeathHealth and not mAvatar:IsPreDeath() or curState == REACTOR_DESTROYED or curState == INSTANT_DESTROY then
                mAvatar:InventoryControl():RemoveUpgrade(Game.AVATAR_HEAL_PERCENT_MAX_HEALTH, Game.SET, 1 / (preDeathRepairTime * preDeathRepairPortion))
                mAvatar:GetAgent():SetPaused(false, SYM_SELF)
                mAvatar:DamageControl():SetPreDeathHealthThreshold(initialPreDeathHealth)
            end
        end
        
        if curState == SPAWNED then
            local onShip = RAIL.GetPlayerAvatarsOnShip(mCrewShip)   --not great because its gets an array and counts it..
            if #onShip > 0 then
                mModeMgr:SetModeState(BOARDED)
            end
            
        elseif curState == BOARDED then
            if emptyVersion then
                local crewShipAgent = mAvatar:GetAgent()
                crewShipAgent:SetPaused(true, Symbol("NoPilot"))
                mModeMgr:SetModeState(MANAGE_CREWSHIP)
            else
                mModeMgr:SetModeState(SPAWN_EMPLACEMENT_USERS)
            end
            
        elseif curState == SPAWN_EMPLACEMENT_USERS then
            if nextEmplacement == MAX_HANDS then
                nextEmplacement = 0
                mModeMgr:SetModeState(SPAWN_CREW)
            else
                --Don't check mNumToSpawn - we want a user on every emplacement
                local emplacementAction = mCrewShip:GetShipEmplacement(nextEmplacement)
                if not IsNull(emplacementAction) then
                    local agentType = nil
                    local tier = 81                 --pilot tier by default
                    if nextEmplacement > 0 then
                        tier = 82
                    end
                    
                    agentType = mAiDir:GetRandomEnemyAgentTypeFromAISpec(mCrewSpec, Symbol("Grineer"), mAgentLevelRange.maxValue, true, false, tier, true)
                    if not IsNull(agentType) then
                        local agent = mAiDir:CreateAgentAtPositionOffNav(agentType, emplacementAction:GetPosition(), emplacementAction:GetRotation(), mAgentTeam, mAgentLevelRange:Rand())
                        if not IsNull(agent) then
                            mHint:RegisterAgent(agent)
                            mNumToSpawn = mNumToSpawn - 1 --Decrement the count still to maintain quota
                            agent:UseContextAction(emplacementAction, false)
                        else
                            print("Failed to spawn emplacement agent of type " .. agentType:GetName() .. " at emplacement " .. emplacementAction:GetFullName())
                        end
                    else
                        if IsNull(agentType) then
                            print("failed to find agent type at tier " .. tier)
                        end
                    end
                end
                nextEmplacement = nextEmplacement + 1
            end
        elseif curState == SPAWN_CREW then
            --spawn crew
            if mNumToSpawn > 0 then
                SpawnAgent(mSpawns, 50)
                mNumToSpawn = mNumToSpawn - 1
            else
                mModeMgr:SetModeState(SPAWN_BRIDGE_CREW)
            end
        elseif curState == SPAWN_BRIDGE_CREW then
            if mNumToSpawn > 0 then
                SpawnAgent(mBridgeCrewSpawns, 50, mBridgeDefenseVolume)
                mNumToSpawn = mNumToSpawn - 1
            else
                mModeMgr:SetModeState(MANAGE_CREWSHIP)
            end
        elseif curState == MANAGE_CREWSHIP then
--~             for i, data in ipairs(mEmplacementData) do
--~                 if not IsNull(data.user) then
--~                     if not IsNull(data.user:GetPlayer()) then
--~                         local lastHitAvatar = data.user:InventoryControl():GetLastHitAvatar()
--~                         if not IsNull(lastHitAvatar) and lastHitAvatar:GetOriginalFaction() == sGrineer then
--~                             data.user:InventoryControl():ToggleTrackDamageDealt(false, 0, false)
--~                             mAvatar:SetFaction(sTenno)
--~                         end
--~                     elseif i > 1 then
--~                         local dd = data.user:DamageControl():GetLastDamageTaken()
--~                         if not IsNull(dd) then
--~                             if dd.baseAmount > 0 then
--~                                 local user = data.user
--~                                 data.emplacement:FirePort("ForceUserToDismount")
--~                                 user:GetAgent():ReturnToAiControl()
--~                             end
--~                         end
--~                     end
--~                 end
--~             end

        elseif curState == REACTOR_DESTROYED then
            if mMeltdownTimerTracker.Data.Time <= 0 then
                mTimerMgr:ClearTimers()
                _T.RemoveHudTracker(mMeltdownTimerTracker)
                hint:SetEncounterStatus(Npc.ES_COMPLETE)
            end
        end
        
        if not IsNull(mAvatar) and not mAvatar:IsKilled() then
            local agent = mAvatar:GetAgent()
            mAlerted = (not IsNull(agent) and agent:IsAlerted())
            UpdateDamageState()
            mTimerMgr:Update(DeltaTime())
        end
        
        Sleep(0)
    end
    
    if mModeMgr:GetModeState() > MANAGE_CREWSHIP and not IsNull(mAvatar) then   --only do this stuff when the destroyer is being destroyed
        gRegion:CreateEntity(meltdownFinalExplosion, mAvatar:GetPosition(), mAvatar:GetRotation())
        mAvatar:SetVisibility(false, true)
        
        local agents = mHint:GetRegisteredAgents()
        for i, agent in ipairs(agents) do
            local avatar = agent:GetAvatar()
            avatar:Destroy()
        end
        
        Sleep(5)

        mSuicideAvatars = RAIL.GetPlayerAvatarsOnShip(mCrewShip)
        while #mSuicideAvatars > 0 do
            local playersOnBoard = #mSuicideAvatars > 0
            for i, avatar in ipairs(mSuicideAvatars) do
                if not IsNull(avatar) then
                    local action = avatar:GameActionControl():GetCurrentGameAction()
                    if not IsNull(action) and action:IsA(gEmplacementType) then
                        action:Disable()
                    end
                    avatar:Teleport(mAvatar:GetPosition(), ZERO_ROTATION)
                    avatar:SetArchwingSkyMode(true)
                    print("GrineerCrewShipEncounter.lua - Teleporting" .. avatar:GetFullName() .. " to space")
                end
            end
            mSuicideAvatars = RAIL.GetPlayerAvatarsOnShip(mCrewShip)
            if #mSuicideAvatars == 0 then
                break
            end

            Sleep(0)
        end

        if not IsNull(mCrewShip) then
            mAvatar:InventoryControl():RemoveUpgrade(Game.AVATAR_HEAL_PERCENT_MAX_HEALTH, Game.SET, 1 / (preDeathRepairTime * preDeathRepairPortion))
            mAvatar:GetAgent():SetPaused(false, SYM_SELF)
            mAvatar:DamageControl():SetPreDeathHealthThreshold(initialPreDeathHealth)
            mCrewShip:DestroyShip()
        end
        print("GrineerCrewShipEncounter.lua - " .. mAvatarName .. " destroyed")
    end
end

function ScaleHitProxyHealth(proxy)
    local avatar = proxy:GetAttachParent()
    
    local proxyHealth = avatar:GetMaxHealth() * 0.1
    proxy:SetHealth(proxyHealth, true)
end

-- Gets called if destroyed or repaired
function OnArmourGroupDestroyedChanged(group, destroyed)
    -- maybe this could be moved to the script hanging off the avatar
    -- adding upgrades and enabling the boarding hatch: should these be handled here or in the avatar script?
    local avatar = group:GetAvatar()
    local dd
    if not IsNull(avatar) then
        dd = avatar:DamageControl():GetLastDamageTaken()
    end    
    
    local tag = group:GetTag()
    if not (tag == sBoardingAction) then
        SetEngineEnabled(tag, group:GetPart(), not destroyed, dd)
    end
end

function OnStateChanged(deco, initial)
    if not initial and deco:GetHealth() <= 0 then
        deco:SetMaterialParam(Lotus_Game.EMISSIVE_MAP_ATTEN, 0)
    end
end

function ExecutePilot(action, instigator)
    local pilot = pilotAction:GetCurrUser()

    if IsNull(pilot) or not IsNull(pilot:GetPlayer()) then   
        action:Disable()
        return
    end
    instigator:SetAnimName(Symbol("Tenno"))
    pilot:SetAnimName(Symbol("GrineerPilot"))
    
    if instigator:ReplicaLocallyControlled() then
        local inv = instigator:InventoryControl()
        inv:Unequip(Engine.MAIN_HAND, Engine.InventoryControllerBase_ES_INSTANT_EQUIP)
    end
    
    if gRegion:IsMaster() then
        cinematic:SetInstigatorAvatar(instigator)
        pilotAction:FirePort("ForceUserToDismount")
        cinematic:FirePort("StartPlaying")
    else
        while not cinematic:IsPlaying() do
            Sleep(0)
        end
    end
    
    while cinematic:IsPlaying() do
        Sleep(0)
    end
    
    if gRegion:IsMaster() and not IsNull(pilot) then
        pilot:Suicide()
    end
    
    local EMPLACEMENT_SKIP_ANIMATION = 1
    _T.RailjackHudAdditionalFadeDelay = 0.75
    instigator:GameActionControl():ExecuteAction(pilotAction, EMPLACEMENT_SKIP_ANIMATION)
    --use the cinematic, skip the mount anim
end

function OnPilotEmplacementUsed(action)
    local user = action:GetCurrUser()
    if IsNull(user) or not IsNull(user:GetPlayer()) then
        executeAction:Disable()
    else
        executeAction:Enable()
    end
end