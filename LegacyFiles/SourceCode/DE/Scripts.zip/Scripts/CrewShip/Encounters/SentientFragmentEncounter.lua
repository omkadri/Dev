--ARGS
crewShipType = Type()
attackMarkerType = Type()
attackAreaMarkerType = Type()
defaultObjectiveEncounter = Type() -- used when there is no objective encounter defined

--LIBS
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local MODE = require "Lotus.Scripts.Libs.CommonGamemodeFunctions"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local RAILOBJ = require "Lotus.Scripts.Libs.RailjackObjectiveUI"

--RESOURCES
local replicatedHitSwitchRes = WeakResource("/EE/Types/Actions/ReplicatedHitSwitch")
local pointOfInterestAgentType = WeakResource("/Lotus/Types/Game/CrewShip/PointOfInterestAgent")
local completionReward = Resource("/Lotus/Types/Items/MiscItems/SentientFragmentLootItem")

--LOC
local objectiveLoc = "/Lotus/Language/Railjack/KillSentients"

--SYMBOLS
local NV_POI_KILL_GOAL = Symbol("NVPoiKillGoal")
local NV_KILL_COUNT = Symbol("NVSentientFragmentKillCount")
local sHide = Symbol("Hide")
local sMissileCoreTag = Symbol("RJMissilePlatformCore")

--CACHED VARS
local mGameRules = nil
local mAiDir = nil
local mHint = nil
local mHintPos = nil
local mHintActivationRadius = 0
local mDeactivateRadius = 0
local mParentHint = nil
local mTransmissionSet = nil
local mTimerMgr = nil
local mSpawnMgr = nil
local mPlayers = nil

--STATES
local STATE = {INVALID = 0, STARTED = 1, APPROACHED = 2, BOARDED = 3, COMPLETED = 4, DISABLED = 5} -- Main mission stages

--SETTINGS 
local fadeTime = 0.5

--VARS
local mCrewShip = nil
local mAvatar = nil
local mEnterAction = nil
local mDisableMarker = nil
local mDisableAction = nil
local mKillCount = 0 -- To Do: Host migration
local mKillGoal = 20 -- To Do: Scaling for after preview
local mPathingMarker = nil
local mAreaMarker = nil
local mMissionHint = nil

local function OnMissionStatusChanged(hint)
    if mHint == mMissionHint and mMissionHint:GetEncounterStatus() == Npc.ES_SUCCEEDED then
        RAIL.SetCrewShipEnterMarker(false, mCrewShip)
        RAIL.SetCrewShipExitMarker(true, mCrewShip)
        mHint:SetEncounterStatus(Npc.ES_COMPLETE)
    end
end

local function CrewShipInitialize()
    local setupScript = gRegion:FindNearestTagged(Symbol("PoiSetupScript"), mHintPos)
    if not IsNull(setupScript) then
        setupScript:FirePort("Execute")
    else
        print("POI - Could not find setup script")
    end
    
    mAvatar = mCrewShip:GetAvatarOwner()
    
    local levelExit = RAIL.GetCrewShipExitAction(mCrewShip)
    mAiDir:SetObjective(levelExit)
    
    mEnterAction = gRegion:FindNearestTagged(Symbol("EnterPoiAction"), mHintPos)
    mDisableMarker = RAIL.FindFirstTaggedOnShip(Symbol("HangarDisableObjective"), mCrewShip)
    mDisableAction = RAIL.FindFirstTaggedOnShip(Symbol("HangarDisableAction"), mCrewShip)

    ---This is for hacker agent only
    local hackerPoiTags = gRegion:FindTagged(Symbol("SentientHackerStation"))
    if not IsNull(hackerPoiTags) then
        for i = 1, #hackerPoiTags do
            local hackerPoiTag = hackerPoiTags[i]
            if not IsNull(hackerPoiTag) and not hackerPoiTag:IsEnabled()  then
                hackerPoiTag:Disable()
                hackerPoiTag:RunArriveScript(nil)
                hackerPoiTag:RunLeaveScript(nil,true)
            end
        end
    end
    
    local levelStartScript = RAIL.FindFirstTaggedOnShip(Symbol("SentientRJLevelStartScript"), mCrewShip)
    levelStartScript:FirePort("Execute")
    
    mAvatar:SetPosition(mHintPos) 

    mEnterAction:Enable()
    RAIL.SetCrewShipEnterMarker(true, mCrewShip)
    RAIL.SetCrewShipExitMarker(false, mCrewShip)
    
    --run a random mission for this POI
    mMissionHint = mAiDir:ActivateRandomEncounterAtPos(mHintPos, {Symbol("PoiMission"), Symbol("SentientFragment")}, Npc.ET_STRONG_POINT, Npc.ET_STRONG_POINT, mHint)
    if IsNull(mMissionHint) then
        mAiDir:AddEncounter(defaultObjectiveEncounter)
        mMissionHint = mAiDir:ActivateRandomEncounterAtPos(mHintPos, {Symbol("PoiMission"), Symbol("SentientFragment")}, Npc.ET_STRONG_POINT, Npc.ET_STRONG_POINT, mHint)
    end
    
    if not IsNull(mMissionHint) then
        mMissionHint:RegisterStatusChangedCallback(OnMissionStatusChanged, Symbol("SentientFragmentObjectiveCB"))
    end
end

function ShipReady(ship)
    mCrewShip = ship
    mAvatar = mCrewShip:GetAvatarOwner()
    mHint:RegisterAgent(mAvatar:GetAgent())
    mHint:SetEncounterDynamicState(1)
    print("Spawned Sentient Fragment")
end

-- Initialize - first thing that runs when a mission encounter starts - do your initial setup here. This is called again on migration.
-- Because gPromotedToHost is unreliable here, you will need to search for mission entities first, and create if not found (see mMissionObject)
local function Initialize(hint)
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    mGameRules = gGameRules
    mHint = hint
    mParentHint = hint:GetRootParentEncounterHint()
    mHintPos = hint:GetPosition()
    
    mTimerMgr = TIMER.CreateTimerMgr()
    
    local instanceRefs = mHint:GetInstanceReferences()
    for i, instance in ipairs(instanceRefs) do
        if instance:GetTag() == sHide then
            instance:SetVisibility(false, true)
        end
    end
        
    if mHint:GetEncounterDynamicState() == 1 then
        --recover crewship/avatar after migration
        while IsNull(mCrewShip) do
            local registeredAgents = mHint:GetRegisteredAgents()
            for i, agent in ipairs(registeredAgents) do
                if agent:IsA(pointOfInterestAgentType) then
                    mAvatar = agent:GetAvatar()
                    mCrewShip = mAvatar:InventoryControl():GetActivePowerSuit()
                    break
                end
            end
            if IsNull(mCrewShip) then
                Sleep(0)
            end
        end
    else
        local crewShipMgr = gGameRules:GetCrewShipManager()
        crewShipMgr:CreateCrewShipFromType(crewShipType, nil, false, true, "ShipReady")
    end
    
    while IsNull(mCrewShip) do
        Sleep(0)
    end
    
    CrewShipInitialize()
    
    hint:SetEncounterStatus(Npc.ES_ACTIVE)
end

--Main function - Contains main update loop, monitor mode state here
function Start(hint)
    Initialize(hint)
    
    local delta = 0
    while true do
        if gGameRules:MissionCompleted() or gGameRules:MissionFailed() or hint:GetEncounterStatus() >= Npc.ES_SUCCEEDED then
            break
        end
        
        delta = DeltaTime()

        mTimerMgr:Update(delta)
        
        Sleep(0)
    end
end

--CALLBACKS
function OnPlayersChanged()
    mPlayers = gRegion:GetHumanPlayers()
end
