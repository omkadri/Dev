capitalShipAiSpec = Resource()
capitalShipAgent = Type()
enemyFaction = Symbol("Corpus")
capitalShipTierMax = 0 

local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local PANIC = require "Lotus.Scripts.Libs.PanicLib"

local NV_CAPITAL_SHIP_STATE = Symbol("CAPITAL_SHIP_STATE")
local NOT_STARTED = 1
local WAITING_TO_START = 2
local STARTED = 3
local COMPLETE = 4
local mModeState = INVALID
local SetModeState

local UPDATE_INTERVAL = 0.1 -- How frequently we will tick 

local mHint = nil
local mAiSpec = nil
local mAiDir = nil
local mCapitalShipAgent = nil

function NPCAlertStart(npc)
    PANIC.SetPanicLevel(PANIC.ALERT)
end

function NPCAlertEnd(npc)
    PANIC.SetPanicLevel(PANIC.UNALERT) 
end

function OnDamaged(deco)
    --Detected()
end

function OnDestroyed(deco)

end

local function ShouldShutDown()
    if mModeState == COMPLETE then
        return true
    end

    -- local crewShipMgr = gGameRules:GetCrewShipManager()
    -- if not IsNull(crewShipMgr) then
    --     local ship = crewShipMgr:GetPlayerShip()
    --     local shipAvatar = ship:GetAvatarOwner()
    --     local hyperDriveState = shipAvatar:GetHyperDriveState()

    --     if hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_BOARDING or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP then
    --         return true
    --     end
    -- end

    return false
end

local function ShutDownCapitalShipStateEncounter(hint)
    --Destroy crewships
    --set net variables back to 0.
    gGameRules:SetNetPersistentVar(NV_CAPITAL_SHIP_STATE, 1)
end

local function OnModeStateChanged()
    if mModeState == WAITING_TO_START then

    elseif mModeState == STARTED then
        --do lotus vo
        Sleep(0.2)

        --find first player on board capital ship and use them for the source region for the auto-spawns
        local avatarOnCapitalShip = nil
        local avatars = gRegion:GetHumanPlayerAvatars()
        for i=1,#avatars do
            local avatar = avatars[i]
            if not IsNull(avatar) and RJ_UTIL.IsInCapitalShip(avatar) then
                avatarOnCapitalShip = avatar
                break
            end
        end
        mAiDir:SetEnableAutoSpawns(true, avatarOnCapitalShip) --only turn on spawns for the away team
        mAiDir:SetCurrentTier(capitalShipTierMax, false)
        mAiDir:Enable(true)
        mAiDir:SetNpcHardCap(60) -- TC hack to get enemies to spawn inside the cap ship while keeping fighters alive in space.
        mAiDir:SetLevelAlert(true)        
    elseif mModeState == COMPLETE then
        
    end

end

local function UpdateCapitalShip(deltaTime)

end

local function Initialize(hint)
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    if not IsNull(gGameRules) then
        --mAiSpec = capitalShipAiSpec
        local mission = gGameRules:GetMission()
        mAiSpec = mission.enemySpec
        if IsNull(mAiSpec) then
            mAiSpec = capitalShipAiSpec
            mission.enemySpec = capitalShipAiSpec
            gGameRules:SetMission(mission)
            mAiDir:AssignMissionAISpec(mAiSpec)
        end
    end

    local levelInfo = gRegion:GetLevelInfo()
    ObjectPortHandler(levelInfo, "NPCAlertStart")
    ObjectPortHandler(levelInfo, "NPCAlertEnd")

    if gRegion:IsMaster() then
    end

    SetModeState(gGameRules:GetNetPersistentVar(NV_CAPITAL_SHIP_STATE, NOT_STARTED))
    
    if mModeState == NOT_STARTED then
        
        local capAvatar = gRegion:FindFirstTagged(Symbol("CorpusCapitalShipAvatar"))

        if IsNull(capAvatar) then
            mCapitalShipAgent = mAiDir:CreateAgentAtPosition(capitalShipAgent, hint:GetPosition(), ZERO_ROTATION, enemyFaction)
        end

        while not IsNull(mCapitalShipAgent) and IsNull(mCapitalShipAgent:GetAvatar()) do
            Sleep(0.1)
        end

    SetModeState(WAITING_TO_START)
    elseif mModeState == STARTED then
        --find all existing pilot actions
        --outputhandler them all
        --check if anyone is flying and check/reset blackboard values
    end


end

local function Update(deltaTime)
    local modeState = gGameRules:GetNetPersistentVar(NV_CAPITAL_SHIP_STATE, NOT_STARTED)
    if modeState ~= mModeState then
        mModeState = modeState
        OnModeStateChanged(modeState)
    end

    UpdateCapitalShip(deltaTime)

    if mModeState == WAITING_TO_START then
        local numOfTennoOnCapitalShip = RJ_UTIL.NumOfTennoOnCapitalShip()
        if numOfTennoOnCapitalShip >= 1 then
            SetModeState(STARTED)
        end
        -- if _T.IsCurrentObjective(mHint) then
        --     SetModeState(STARTED)
        -- end
    elseif mModeState == STARTED then
        -- if #mHijackedCrewShips > 0 and #mEnemyCrewShips == 0 then
        --     SetModeState(COMPLETE)
        -- end  
    elseif mModeState == COMPLETE then
        --increment railjackmanagernetvar to move onto the next mission.
    end
end

SetModeState = function(newState)
    if mModeState ~= newState then
        mModeState = newState
        gGameRules:SetNetPersistentVar(NV_CAPITAL_SHIP_STATE, newState)
        OnModeStateChanged()
    else
        print("CapitalShipStateEncounter.lua::SetModeState - trying to set mode to state we're already in")
    end
end

function CapitalShipState(hint)
    mHint = hint

    Broadcast("Capital Ship State Started")
    Initialize(hint)

    local sleepTime = UPDATE_INTERVAL

    while not ShouldShutDown() do
        Update(sleepTime)
        Sleep(sleepTime)
    end

    ShutDownCapitalShipStateEncounter(hint)
end