--ARGS
InitialFighterCount = { 2, 2, 3, 3 } --  Increment with GAL
maxSimFighterCount = { 5, 6, 7, 8 } -- Increment with GAL
stopSpawningAtSpawnCount = { 4, 5, 5, 6 } -- Increment with GAL
spaceLevelThresholds = { 15, 30, 45, 60, 100 }
activeCountLevelMultipliers = { 1, 1.5, 2, 2.5, 2.5 } --enemy level multipler for initial and maxSim agent counts 
killThresholdLevelMultipliers = { 1, 1.5, 2.5, 3, 3.5 }
enemyFighterTier = 95
minSpawnDistanceFromPlayers = 500
initialRampUpDelay = 5
maxAllowedCrewships = 3
crewShipPatrol = false -- will be a FIGHTER patrol if false
crewShipTypes = {Type()}
shipTag = Symbol("GrineerDestroyer")
fighterSpawnFxType = Type()
spawnPointTag = Symbol("FighterSpawner")
reinforcePointTag = Symbol("FighterReinforceSpawner")
patrolTag = Symbol("Patrol")
stormTargetTag = Symbol()
enemyFaction = Symbol("Grineer")

--RESOURCES
local crewShipAvatarType = WeakResource("/Lotus/Types/Game/CrewShip/GrineerDestroyer/GrineerDestroyerAvatar") --search for these types when pulling in adds
local crewShipAgentType = WeakResource("/Lotus/Types/Game/CrewShip/GrineerDestroyer/GrineerDestroyerAgent")
local patrolRouteType = WeakResource("/EE/Types/Npc/PatrolRoute")
local fighterExterminateEncounter = WeakResource("/Lotus/Types/Gameplay/CrewShip/Encounters/KillFightersExterminateSubObjective")
local crewshipExterminateEncounter = WeakResource("/Lotus/Types/Gameplay/CrewShip/Encounters/KillCrewShipsExterminateSubObjective")

--LIBS
local GAMEMODE = require "Lotus.Scripts.Libs.CommonGamemodeFunctions"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local LANDSCAPE = require "Lotus.Scripts.Libs.LandscapeLib"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"
local UTIL = require "EE.Interface.Utilities"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"

--SYMBOLS
local crewShipSpawnTag = Symbol("EnemyCrewShipSpawnPoint")


--STATES
local INVALID = 0
local STARTED = 1
local SPAWNED = 2
local COMBAT = 3
local RAMP_DOWN = 4
local COMPLETE = 5

--NET VARS
local NV_MAJOR_KILL_COUNT = Symbol("NVMajorKillCount")


--VARS
local mEnemyCrewShips = { }
local mHint = nil
local mAiDir = nil
local mHintPos = nil
local mHintRadius = nil
local mTransmissionSet = nil
local mHintSpawnRadius = nil
local mGlobalAlertLevel = nil
local mSquadSize = nil
local mKillCount = 0
local mTotalSpawnCount = 0
local mSpawnCountThreshold = nil
local mMaxSimCount = 0
local mModeMgr = nil
local mTimerMgr = nil
local mLeaderAgent = nil
local mPatrolRoute = nil
local mInitialSpawnPoints = {}
local mReinforcePoints = {}
local mCombatStarted = false
local mActiveCount = 0
local mFighterSubObj = nil
local mCrewShipSubObj = nil
local mCrewShipMgr = nil
local mMaxCrewshipCount = 0
local mForceShutdown = false
local mCrewshipKillsRemaining = 0

local STORM_TARGET_RADIUS = 50

local function GetSubObjectiveEncounter(encounterType)
    local hints = gRegion:FindAll(gEncounterHintType)
    for i, hint in ipairs(hints) do
        local activeEncounter = hint:GetCurrentEncounterTemplate()
        if activeEncounter == encounterType then
            return hint
        end
    end
    print("Could not find any " .. encounterType:GetFullName())
    return nil
end

local function OnDeath(dd)
    local victim = dd:GetVictim()
    if IsNull(victim) then
        return
    end
    
    if not victim:IsFactionOriginalFriendly(Symbol("TENNO")) then
        if victim:IsA(gSpaceFighterBaseAvatarType) or victim:IsA(crewShipAvatarType) then
            local agent = victim:GetAgent()
            if not IsNull(agent) then
                local encHint = agent:GetOwningEncounter()
                if not IsNull(encHint) and encHint == mHint then
                    mKillCount = mKillCount + 1
                end
            end
        end
    end
end

local function AttachSpawnFx(agent)
    local avatar = agent:GetAvatar()
    if not IsNull(avatar) then
        avatar:Attach(fighterSpawnFxType,  EMPTY_SYMBOL)
    end
end

local function SpawnCrewShip(mAiDir, mHintPos, mHintRadius, team, firstSquad)
    
    local spawners = {}
    if firstSquad then
        --try find a valid spawn location first
        local crewShipPatrolSpawners = {}
        local instances = mHint:GetInstanceReferences()
        for i, instance in ipairs(instances) do
            if instance:GetTag() == crewShipSpawnTag then
                table.insert(crewShipPatrolSpawners, instance)
            end
        end
    
        if #crewShipPatrolSpawners == 0 then
            crewShipPatrolSpawners = mInitialSpawnPoints --mAiDir:FindSpaceSpawns(mHintPos, mHintRadius, minSpawnDistanceFromPlayers, crewShipSpawnTag)
            if #crewShipPatrolSpawners == 0 then
                crewShipPatrolSpawners = mAiDir:FindSpaceSpawns(mHintPos, minSpawnDistanceFromPlayers * 2, minSpawnDistanceFromPlayers, crewShipSpawnTag)
            end
        end
        
        spawners = crewShipPatrolSpawners
    else
        spawners = mReinforcePoints
    end
    
    if #spawners == 0 then
        return nil
    end

    local prevCrewShipsSize = #mEnemyCrewShips    
    local enemyShip = nil
    mCrewShipMgr:CreateCrewShipFromType(crewShipTypes[SRandomInt(1, #crewShipTypes)], nil, false, false, "EnemyShipReady")
    while #mEnemyCrewShips == prevCrewShipsSize do
        Sleep(0)
    end

    enemyShip = mEnemyCrewShips[#mEnemyCrewShips]
    
    if IsNull(enemyShip) then
        return nil -- don't worry about spawning a crewship, but continue spawning the other fighters
    else
        local enemyCrewAvatar = enemyShip:GetAvatarOwner()

        while enemyCrewAvatar:GetAgent() == nil do
            Sleep(0)
        end

        local agent = enemyCrewAvatar:GetAgent()
        agent:SetTeam(team)

        local spawner = spawners[RandomInt(1, #spawners)]

        if not IsNull(spawner) then
            enemyCrewAvatar:Teleport(spawner:GetPosition(), ZERO_ROTATION)
        else
            enemyCrewAvatar:Teleport(mHintPos, Rotation()) -- gotta spawn somewhere
        end

        return agent
    end
end

local function SpawnFighter(mAiDir, tier, faction, spawnPoints, team)
    local spawnIndex = RandomInt(1, #spawnPoints)
    local spawner = spawnPoints[spawnIndex]
    local level = mAiDir:GetRandomSpaceEnemyLevel()
    
    if not IsNull(_T.SpaceEnemyLevel) then
        level = _T.SpaceEnemyLevel
    end
    
    local agentType = mAiDir:GetRandomEnemyAgentType(faction, level, false, false, tier, true)
    return mAiDir:CreateAgent(agentType, spawner, team, level)
end

local function SpawnFighterAtPos(mAiDir, tier, faction, spawnPos, spawnRot, team)
    local level = mAiDir:GetRandomSpaceEnemyLevel()
    
    if not IsNull(_T.SpaceEnemyLevel) then
        level = _T.SpaceEnemyLevel
    end
    
    local agentType = mAiDir:GetRandomEnemyAgentType(faction, level, false, false, tier, true)
    return mAiDir:CreateAgentAtPositionOffNav(agentType, spawnPos, spawnRot, team, level)
end

local function SpawnSquad(firstSquad, spawnCount, spawnPoints)
    
    local hintInstances
    if firstSquad then
        -- check for existing agents. Update mSquadSize. Assign one as the leader
        local registeredAgents = mHint:GetRegisteredAgents()
        for i, agent in ipairs(registeredAgents) do
            if agent:IsA(crewShipAgentType) then
                mLeaderAgent = agent
            end
        end
        
        spawnCount = spawnCount - #registeredAgents
        
        if spawnCount == 0 and IsNull(mLeaderAgent) and #registeredAgents > 0 and not IsNull(registeredAgents[1]) then
            mLeaderAgent = registeredAgents[1]
        end
        
        hintInstances = mHint:GetInstanceReferences()
        for i = 1, #hintInstances do
            if hintInstances[i]:IsA(gNpcSpawnPointType) then
                table.insert(spawnPoints, hintInstances[i])
            elseif hintInstances[i]:IsA(patrolRouteType) then
                mPatrolRoute = hintInstances[i]
            end
        end
        
        if IsNull(mPatrolRoute) then
            mPatrolRoute = gRegion:FindNearestTagged(patrolTag, mHintPos)
        end
    end
    
    local squadPositions = {}
    local leaderRot = Rotation()
    local fighterObjComplete = false
    
    if not IsNull(mFighterSubObj) and
        mFighterSubObj:GetEncounterDynamicState() == RAIL.SUB_OBJECTIVE_COMPLETE
    then
        fighterObjComplete = true
    end

    if spawnCount > 0 and #spawnPoints > 0 then
        local target = nil
        if stormTargetTag:IsValid() then
            target = gRegion:FindNearestTagged(stormTargetTag, mHint:GetPosition())
        end
    
        local squadTeam = Symbol("RandomTeam")-- .. RandomInt(1, 10000))
        local buddyGroupId = -1
        -- Spawn leader
        local leaderAgent
        
        -- find crewships, but only those not hijacked by players
        local activeCrewShips = gRegion:FindTagged(shipTag)
        local numPlayerShips = 0
        for i = #activeCrewShips, 1, -1 do
            if activeCrewShips[i]:GetFaction() == Symbol("TENNO") then
                table.remove(activeCrewShips, i)
                numPlayerShips = numPlayerShips + 1
            end
        end
        
        if crewShipPatrol and firstSquad and #activeCrewShips < mMaxCrewshipCount and not mForceShutdown and numPlayerShips < mCrewshipKillsRemaining then --spawn crew ship
            leaderAgent = SpawnCrewShip(mAiDir, mHintPos, mHintRadius, squadTeam, firstSquad)
            Sleep(0)
            if not IsNull(leaderAgent) then
                DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("CrewshipSpawned"))
            end
        elseif not fighterObjComplete then
            leaderAgent = SpawnFighter(mAiDir, enemyFighterTier, enemyFaction, spawnPoints, squadTeam)
            Sleep(0)
            if not IsNull(leaderAgent) and firstSquad then
                if not IsNull(target) then
                    leaderAgent:SetAlert()
                    leaderAgent:StormTarget(target, STORM_TARGET_RADIUS)
                end
                DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("FightersSpawned"))
            end
        else
            mForceShutdown = true
        end
        
        if firstSquad and IsNull(mLeaderAgent) then
            mLeaderAgent = leaderAgent
        end

        if not IsNull(leaderAgent) then
            AttachSpawnFx(leaderAgent)
            local leaderPos = leaderAgent:GetAvatar():GetPosition()
            leaderRot = leaderAgent:GetAvatar():GetSimRotation()
            local squadSpread = Vector(0, 0, -30)
            if crewShipPatrol then
                leaderPos = leaderPos + RotateVector(Vector(0, 0, -70), leaderRot)
            end
            for i = 2, spawnCount do
                squadPositions[i] = leaderPos + RotateVector(squadSpread * (i - 1), leaderRot)
            end

            mHint:RegisterAgent(leaderAgent)
            mTotalSpawnCount = mTotalSpawnCount + 1
            
            if not firstSquad then
                leaderAgent:SetAlert()
            end

            buddyGroupId = leaderAgent:CreateScriptedBuddyGroup(Npc.GT_PATROL, 6) -- default patrol formation slot size is 6 in behaviors. for bigger squad, these numbers have to be increased, too. ex>FlyInFormationTactic.mMaxFormationSlots
            if not IsNull(mPatrolRoute) and IsNull(target) then
                leaderAgent:SetPatrolRoute(mPatrolRoute)
            end
        end

        Sleep(0.1)

        if not IsNull(leaderAgent) and not fighterObjComplete and not mForceShutdown then
            -- Spawn followers
            for i = 2, spawnCount do
                Sleep(0)
                
                local agent = SpawnFighterAtPos(mAiDir, enemyFighterTier, enemyFaction, squadPositions[i], leaderRot, squadTeam)

                if not IsNull(agent) then
                    if IsNull(mLeaderAgent) then --assign this agent as the leader (this will happen if crewship patrol wasn't allowed to create a new crewship
                        mLeaderAgent = agent
                    end
                    
                    if not IsNull(target) then
                        leaderAgent:SetAlert()
                        leaderAgent:StormTarget(target, STORM_TARGET_RADIUS)
                    end
                    
                    AttachSpawnFx(agent)
                    mHint:RegisterAgent(agent)
                    mTotalSpawnCount = mTotalSpawnCount + 1
                    
                    if not firstSquad then
                        agent:SetAlert()
                    end

                    local patrol = agent:GetPatrolRoute()
                    if not IsNull(patrol) then
                        agent:SetPatrolRoute(nil)
                    end
                    if buddyGroupId ~= -1 then
                        agent:JoinScriptedBuddyGroup(buddyGroupId)
                    end
                end
            end
            if firstSquad then
                Broadcast("Patrol spawned @" .. mHint:GetName())
            else
                Broadcast("Patrol reinforced @" .. mHint:GetName())
            end
        end
    end
end

local function CombatDelay(state)
    mCombatStarted = true
end

local function DeregisterCapturedLeader()
    if not IsNull(mLeaderAgent) and mLeaderAgent:IsA(crewShipAgentType) then
        local avatar = mLeaderAgent:GetAvatar()
        if not IsNull(avatar) then
            if avatar:GetFaction() == Symbol("TENNO") then
                mHint:DeregisterAgent(mLeaderAgent)
            end
        end
    end
end

-- OnModeStateChanged - this is called immediately when state changes - use this function for setting up the state (UI changes, creating objects, etc)
-- This func is called after host migration, so you can recover from the state you migrated during
local function OnModeStateChanged()
    local curState = mModeMgr:GetModeState()
    
    if curState == STARTED then
        SpawnSquad(true, mSquadSize, mInitialSpawnPoints)
    elseif curState == SPAWNED then
    
    elseif curState == COMBAT then
        mReinforcePoints = mAiDir:FindSpaceSpawns(mHintPos, mHintRadius, minSpawnDistanceFromPlayers, reinforcePointTag)
        mTimerMgr:AddTimer(initialRampUpDelay, CombatDelay, curState)
    elseif curState == RAMP_DOWN then
        
    elseif curState == COMPLETE then
        gGameRules:RemoveOnDeathCallback(OnDeath)
        Broadcast("Patrol Completed @" .. mHint:GetName())
        
        mHint:SetEncounterStatus(Npc.ES_SUCCEEDED)
    end
end

local function Initialize(hint)
    mHint = hint
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    mHintPos = hint:GetPosition()
    mHintRadius = hint:GetActivationRadius()
    mHintSpawnRadius = hint:GetSpawnRadius()
    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()
    mGlobalAlertLevel = mAiDir:GetGlobalAlertLevel()
    mSquadSize = InitialFighterCount[math.min(#InitialFighterCount, mGlobalAlertLevel + 1)] --increment because value returned starts at 0, but lua arrays start at 1
    mSpawnCountThreshold = stopSpawningAtSpawnCount[math.min(#stopSpawningAtSpawnCount, mGlobalAlertLevel + 1)]
    mMaxSimCount = maxSimFighterCount[math.min(#maxSimFighterCount, mGlobalAlertLevel + 1)]
    mModeMgr = LANDSCAPE.CreateModeMgr(OnModeStateChanged, mHint, {})
    mTimerMgr = TIMER.CreateTimerMgr()
    mCrewShipMgr = gGameRules:GetCrewShipManager()

    --Temp hacky way to make more fighters in higher difficulty levels
    local maxAILevel = mAiDir:GetSpaceMaxEnemyLevel()
    for i, int in ipairs(spaceLevelThresholds) do
        if maxAILevel <= int then
            mSquadSize = math.floor(mSquadSize * activeCountLevelMultipliers[math.min(i, #activeCountLevelMultipliers)])
            mSpawnCountThreshold = math.floor(mSpawnCountThreshold * killThresholdLevelMultipliers[math.min(i, #killThresholdLevelMultipliers)])
            mMaxSimCount = math.floor(mMaxSimCount * activeCountLevelMultipliers[math.min(i, #activeCountLevelMultipliers)])
            break
        end
    end
    
    -- allow to spawn more crewships, up to maxAllowed, if we're still a few from the objective total
    if crewShipPatrol then
        if IsNull(_T.majorKillGoal) then
            mCrewshipKillsRemaining = 0
        else
            mCrewshipKillsRemaining = _T.majorKillGoal - gGameRules:GetNetPersistentVar(NV_MAJOR_KILL_COUNT, 0)
        end

        mMaxCrewshipCount = math.max(mCrewshipKillsRemaining, 1)
        mMaxCrewshipCount = math.min(mCrewshipKillsRemaining, maxAllowedCrewships)
    end
    
    gGameRules:RemoveOnDeathCallback(OnDeath)
    gGameRules:AddOnDeathCallback(OnDeath)
    
    mSquadSize = math.min(mAiDir:GetRoomTillHardCap(), mSquadSize)
    mInitialSpawnPoints = mAiDir:FindSpaceSpawns(mHintPos, mHintSpawnRadius, minSpawnDistanceFromPlayers, spawnPointTag)
    local try = 1
    while IsNull(mInitialSpawnPoints) do
        mInitialSpawnPoints = mAiDir:FindSpaceSpawns(mHintPos, mHintRadius * try, minSpawnDistanceFromPlayers, spawnPointTag)
        try = try + 1
        Sleep(0)
    end
    mFighterSubObj = GetSubObjectiveEncounter(fighterExterminateEncounter)
    mCrewShipSubObj = GetSubObjectiveEncounter(crewshipExterminateEncounter)
    
    local netState = mHint:GetEncounterDynamicState()
    
    mModeMgr:SetModeState(UTIL.Ternary(netState == 0, STARTED, netState))
    hint:SetEncounterStatus(Npc.ES_ACTIVE)
    
end

function EnemyPatrol(hint)
    
    if IsNull(hint) then
        return
    end
    
    Initialize(hint)
    
    local delta = 0
    local curState = INVALID
    local spawnCount = 0
    local subObj
    local subObjCount = 0
    
    if crewShipPatrol then
        subObj = mCrewShipSubObj
        if not IsNull(_T.majorKillGoal) then
            subObjCount = _T.majorKillGoal
        end
    else
        subObj = mFighterSubObj
        if not IsNull(_T.minorKillGoal) then
            subObjCount = _T.minorKillGoal
        end
    end
    
    while true do
        if IsNull(hint) or gGameRules:MissionCompleted() or gGameRules:MissionFailed() or hint:GetEncounterStatus() >= Npc.ES_SUCCEEDED then
            break
        end
        
        delta = DeltaTime()
        curState = mModeMgr:GetModeState()
        mActiveCount = hint:GetNumRegisteredAgents()
        
        if curState >= STARTED and not mForceShutdown then
            if not IsNull(subObj) then
                if subObj:GetEncounterDynamicState() == RAIL.SUB_OBJECTIVE_COMPLETE then
                    mForceShutdown = true
                end
            elseif IsNull(subObj) and subObjCount > 0 then
                mForceShutdown = true
            end
        end

        DeregisterCapturedLeader() 
        
        if curState == STARTED then
            if mActiveCount == mSquadSize or mForceShutdown then
                print("starting agents spawned")
                mModeMgr:SetModeState(SPAWNED)
            end
            if mActiveCount < mSquadSize then
                spawnCount = math.min(mAiDir:GetRoomTillHardCap(), mMaxSimCount - mActiveCount)
                SpawnSquad(true, spawnCount, mInitialSpawnPoints)
            end
        elseif curState == SPAWNED then
            if mActiveCount < mSquadSize or IsNull(mLeaderAgent) or mLeaderAgent:IsCombatAwareness() or mForceShutdown then
                mModeMgr:SetModeState(COMBAT)
            end
        elseif curState == COMBAT then
            --if mKillThreshold == 1 or mKillCount >= mKillThreshold then --must have already killed something
            if mTotalSpawnCount >= mSpawnCountThreshold or mForceShutdown then
                mModeMgr:SetModeState(RAMP_DOWN)
            elseif mCombatStarted then
                if mActiveCount < mMaxSimCount then
                    spawnCount = math.min(mAiDir:GetRoomTillHardCap(), math.min(mSpawnCountThreshold - mTotalSpawnCount, mMaxSimCount - mActiveCount))
                    local t = 1
                    while IsNull(mReinforcePoints) do
                        mReinforcePoints = mAiDir:FindSpaceSpawns(mHintPos, ( mHintRadius * (1 + t/10) ), minSpawnDistanceFromPlayers, reinforcePointTag)
                        t = t + 1
                        Sleep(0)
                    end
                    SpawnSquad(false, spawnCount, mReinforcePoints)
                end
            end
        elseif curState == RAMP_DOWN then
            if mActiveCount <=0 then
                mHint:SetEncounterStatus(Npc.ES_COMPLETE)
                mModeMgr:SetModeState(COMPLETE)
            end
        end
        
        mTimerMgr:Update(delta)
        
        Sleep(0)
    end
    mModeMgr:ShutDown()
    
end

function EnemyShipReady(enemyShip)
    if not IsNull(enemyShip) then
        table.insert(mEnemyCrewShips, enemyShip)
    end
end

function ExterminateEvaluate(hint)
    if hint:IsEnabled() then
        return 1
    else
        return 0
    end
end