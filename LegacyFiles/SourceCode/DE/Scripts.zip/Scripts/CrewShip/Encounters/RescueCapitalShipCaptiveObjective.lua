capitalShipAiSpec = Resource()
interiorShipRegionIndex = 1

transmissionSet = Resource()
enemyFaction = Symbol("Grineer")

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local PANIC = require "Lotus.Scripts.Libs.PanicLib"

local NV_RESCUE_CAPITAL_CAPTIVE_STATE = Symbol("RESCUE_CAPITAL_CAPTIVE_STATE")

local NOT_STARTED = 1
local WAITING_TO_START = 2
local STARTED = 3
local ENTERED = 4
local CAPTIVE_FREE_ONBOARD = 5
local CAPTIVE_ESCAPING = 6
local COMPLETE = 7
local mModeState = INVALID
local SetModeState

local UPDATE_INTERVAL = 0.1 -- How frequently we will tick 

local mHint = nil
local mAiSpec = nil
local mAiDir = nil

local mTemplate = nil
local mTransmissionSet = nil

local rescueMarkerType = Type("/Lotus/Types/Enemies/CaptureTargets/CaptureTargetObjectiveMarker")

local shieldStartingMessage = "/Lotus/Language/Railjack/ShieldStarting"
local airlockPanelInnerType = WeakResource("/Lotus/Types/Actions/CaptureEscapeButton") --/Lotus/Types/Actions/CaptureEscapeButton
local airlockPanelOuterType = WeakResource("/Lotus/Types/Actions/CaptureEscapeButtonOuter") --/Lotus/Types/Actions/CaptureEscapeButtonOuter

function NPCAlertStart(npc)
    PANIC.SetPanicLevel(PANIC.ALERT)
end

function NPCAlertEnd(npc)
    PANIC.SetPanicLevel(PANIC.UNALERT) 
end

function OnDamaged(deco)
    --Detected()
end

function OnDestroyed(deco)

end

function OnKilled(avatar)
    
    -- if IsNull(avatar) then
    --     return
    -- end
    
    -- if mCaptainBossAgent:GetAvatar() == avatar or avatar:GetTag() == sGalleonCommanderAvatar then
    --     gGameRules:SetNetPersistentVar(NV_KILL_CAPITAL_CAPTAIN_STATE, BOSS_KILLED)
    -- end
    
end

function OnDeath(dd)

    -- local victim = dd:GetVictim()
    -- if IsNull(victim) then
    --     return
    -- end
    
    -- local faction = victim:GetOriginalFaction()

end

local function Closest(objects,pos,minRange)
    local closestDist = FLT_MAX
    local furthestDist = 0
    local closest
    local furthest
    for i = 1, #objects do
        local dist = objects[i]:DistanceToPoint(pos)
        if dist < closestDist and dist > minRange then
            closest = objects[i]
            closestDist = dist
        end
        if dist > furthestDist then
            furthest = objects[i]
            furthestDist = dist
        end
    end
    
    local result = closest
    if IsNull(result) then
        result = furthest   
    end
    return result
end

local function DisablePanicButtons()
    local panicButtons = gRegion:FindTagged(Symbol("PanicButton"))
    for i = 1, #panicButtons do
        if not IsNull(panicButtons[i]) then
            panicButtons[i]:Disable()
        end
    end
end


local function ShouldShutDown()
    if mModeState == COMPLETE then
        return true
    end

    -- local crewShipMgr = gGameRules:GetCrewShipManager()
    -- if not IsNull(crewShipMgr) then
    --     local ship = crewShipMgr:GetPlayerShip()
    --     local shipAvatar = ship:GetAvatarOwner()
    --     local hyperDriveState = shipAvatar:GetHyperDriveState()

    --     if hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_BOARDING or hyperDriveState == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP then
    --         return true
    --     end
    -- end

    return false
end

local function GetTennoInInteriorShip()
    local avatars = gRegion:GetHumanPlayerAvatars()
    local playersInInterior = { }

    for i=1,#avatars do
        local avatar = avatars[i]

        if not IsNull(avatar) then
            local avatarZone = avatar:GetZone()
        
            if not IsNull(avatarZone) then
                local avatarRegionIndex = avatarZone:GetRegionIndex()

                if avatarRegionIndex == interiorShipRegionIndex then
                    table.insert(playersInInterior, avatar)
                end
            end
        end
    end

    return playersInInterior
end

local function ShutDownCapitalShipCaptiveStateEncounter(hint)
    --Destroy crewships
    --set net variables back to 0.
    mAiDir:SetEnableAutoSpawns(false)
    gGameRules:SetNetPersistentVar(NV_RESCUE_CAPITAL_CAPTIVE_STATE, 1)
end

local function PlayRescueIntro()
    --gGameRules:GiveTransmissionAsyncToAllPlayers(crewShipIntroTransmission)
end

local function OnModeStateChanged()
    if mModeState == WAITING_TO_START then

    elseif mModeState == STARTED then

        PlayRescueIntro() --Patrol ship transmissions
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/InfiltrateTheCapitalShip", 1)

        local capitalEntranceMarker = gRegion:FindFirstTagged(Symbol("CapitalShipEntranceMarker"))
        if not IsNull(capitalEntranceMarker) then
            capitalEntranceMarker:Enable()
        end
        mAiDir:SetNpcHardCap(60) -- TC hack to get enemies to spawn inside the destroyers and cap ship while keeping fighters alive in space.
        mAiDir:SetAllowTeleportOldAgentsForNewSpawns(false)
        
    elseif mModeState == ENTERED then 
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/FreeTheCaptiveAgent", 2) 
        
        DisablePanicButtons()
        
        -- mBossSpawnTrigger = gRegion:FindFirstTagged(Symbol("RailjackCaptainSpawnTrigger"))
        -- ObjectPortHandler(mBossSpawnTrigger, "OnTouched")
        local captiveDoor = gRegion:FindFirstTagged(Symbol("ObjectiveRoom"))
        local rescueMarker = gRegion:CreateEntity(rescueMarkerType, captiveDoor:GetPosition(), ZERO_ROTATION)
        --local assassinateMarker = bossSpawnTrigger:Attach(assassinateMarkerType, EMPTY_SYMBOL)
        rescueMarker:SetDisplayRange(Range(0,1000))
        mAiDir:SetObjective(rescueMarker)
        mAiDir:SetEnableAutoSpawns(true)
        --assassinateMarker:AttachTo(bossSpawnTrigger, EMPTY_SYMBOL)
        --assassinateMarker:SetDisplayRestriction(Lotus_Game.BaseMarkerInfo_DR_NONE)
    elseif mModeState == CAPTIVE_FREE_ONBOARD then
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/GetToTheEscapePods", 2) 

        --spawn boss
        mAiDir:SetEnableAutoSpawns(false)
        
        --SetModeState(BOSS_COMBAT)
        --DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("CommanderSpawned"))
    elseif mModeState == CAPTIVE_ESCAPING then
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/ProtectTheEscapePod", 2) 
    
    elseif mModeState == COMPLETE then
        _T.ObjectiveComplete()
    end
end

local function Initialize(hint)
    mHint = hint
    mTemplate = mHint:GetCurrentEncounterTemplate()
    mTransmissionSet = mTemplate:GetTransmissionSet()
    
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end

    if not IsNull(gGameRules) then
        --mAiSpec = capitalShipAiSpec
        local mission = gGameRules:GetMission()
        mAiSpec = mission.enemySpec
        if IsNull(mAiSpec) then
            mAiSpec = capitalShipAiSpec
            mission.enemySpec = capitalShipAiSpec
            gGameRules:SetMission(mission)
            mAiDir:AssignMissionAISpec(mAiSpec)
        end
    end

    local levelInfo = gRegion:GetLevelInfo()
    ObjectPortHandler(levelInfo, "NPCAlertStart")
    ObjectPortHandler(levelInfo, "NPCAlertEnd")
    

    SetModeState(gGameRules:GetNetPersistentVar(NV_RESCUE_CAPITAL_CAPTIVE_STATE, NOT_STARTED))

    if mModeState == NOT_STARTED then
        -- local capAvatar = gRegion:FindFirstTagged(Symbol("CorpusCapitalShipAvatar"))
        -- if IsNull(capAvatar) then
        --     mCapitalShipAgent = mAiDir:CreateAgentAtPosition(capitalShipAgent, hint:GetPosition(), ZERO_ROTATION, enemyFaction)
        -- end

        -- while not IsNull(mCapitalShipAgent) and IsNull(mCapitalShipAgent:GetAvatar()) do
        --     Sleep(0.1)
        -- end

        SetModeState(WAITING_TO_START)
    elseif mModeState == WAITING_TO_START then

    elseif mModeState == STARTED then
        --find all existing pilot actions
        --outputhandler them all
        --check if anyone is flying and check/reset blackboard values
    elseif mModeState == ENTERED then
    
    elseif mModeState == CAPTIVE_FREE_ONBOARD then
    
    elseif mModeState == CAPTIVE_ESCAPING then

    elseif mModeState == COMPLETE then

    end
end

local function Update(deltaTime)
    local modeState = gGameRules:GetNetPersistentVar(NV_RESCUE_CAPITAL_CAPTIVE_STATE, NOT_STARTED)
    if modeState ~= mModeState then
        mModeState = modeState
        OnModeStateChanged(modeState)
    end

    if mModeState == WAITING_TO_START then
        if _T.IsCurrentObjective(mHint) then
            SetModeState(STARTED)
        end
    elseif mModeState == STARTED then
        local playersInInterior = GetTennoInInteriorShip()
        if not IsNull(playersInInterior) and #playersInInterior > 0 then
            SetModeState(ENTERED)
        end
    elseif mModeState == ENTERED then
    
    elseif mModeState == CAPTIVE_FREE_ONBOARD then
        
    elseif mModeState == CAPTIVE_ESCAPING then

    elseif mModeState == COMPLETE then
        --increment railjackmanagernetvar to move onto the next mission.
    end
end

SetModeState = function(newState)
    if mModeState ~= newState then
        mModeState = newState
        gGameRules:SetNetPersistentVar(NV_RESCUE_CAPITAL_CAPTIVE_STATE, newState)
        OnModeStateChanged()
    else
        print("RescueCapitalShipCaptive.lua::SetModeState - trying to set mode to state we're already in")
    end
end

function CanActivateRescueCaptiveEncounter()
    -- check if the proc system placed the correct rooms/objects in thte node. If not return false

    return 1
end

function RescueCapitalShipCaptive(hint)

    Broadcast("RescueCapitalShipCaptive.lua -- Rescue Capital Ship Captive Objective Started")
    Initialize(hint)

    local sleepTime = UPDATE_INTERVAL

    while not ShouldShutDown() do
        Update(sleepTime)
        Sleep(sleepTime)
    end

    ShutDownCapitalShipCaptiveStateEncounter(hint)
end