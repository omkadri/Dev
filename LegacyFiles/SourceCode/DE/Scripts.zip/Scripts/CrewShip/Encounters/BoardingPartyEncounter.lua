faction = Symbol()
aiSpec = Resource()
agentTier = 90
numBoardersToSpawn = 7
timeUntilBomb = 180 --Change to 180 after testing
bombFuse = 60
bombMarkerType = Type()
detonationFX = Type()
boomSound = Resource()
hackerAgentType = Type()

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local TIMER = require "Lotus.Interface.Libs.TimerMgr"

local sPodSpawn = Symbol("PodSpawnPoint")
local sBombAction = Symbol("BoardingPartyBombAction")
local sBombPlantedSymbol = Symbol("BombPlantedBySelf")

local sTennoFaction = Symbol("TENNO")
--local sReactor = Symbol("ReactorDefenseTarget")
--local sReactorDV = Symbol("ReactorDefenseVolume")

local NV_RJ_NUM_HACKERS = Symbol("RJ_NUM_HACKERS")

local mAiDir = nil
local mTransmissionSet = nil
local mAgentLevelRange = nil

local STARTED = 0
local ATTACKING = 1
local BOMB_PLANTED = 2
local BOMB_ENDED = 3
local TERMINATE = 4

local mTimerMgr = nil
local mBombTimer = nil
local mMarker = nil

local function Initialize(hint)
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    while not mAiDir:HasEncounterMgrCompletedMigration() do
        Sleep(0)
    end
    mTransmissionSet = hint:GetCurrentEncounterTemplate():GetTransmissionSet()
    mAgentLevelRange = Range(mAiDir:GetMinEnemyLevel(), mAiDir:GetMaxEnemyLevel())
    if mAgentLevelRange.minValue == 1 and mAgentLevelRange.maxValue == 1 then
        --this is a test level, override
        mAgentLevelRange.minValue = 20
        mAgentLevelRange.maxValue = 25
    end
    
    if faction == Symbol("Sentient") then
        --If we've host migrated, we need to check what state the Sentient Hacker is in
        if hint:GetEncounterDynamicState() > 0 then
            local hackers = gRegion:FindTagged(Symbol("SentientHacker"))
        
            for i, avatar in ipairs(hackers) do
                if avatar:IsKilled() then
                    gGameRules:SetNetPersistentVar(NV_RJ_NUM_HACKERS, 0)
                else
                    gGameRules:SetNetPersistentVar(NV_RJ_NUM_HACKERS, 1)
                    
                    ObjectPortHandler(avatar, "OnKilled")
                
                    break
                end
            end
        end
    end
    
end

local function PlayOnboardCyTransmission(tag, delay)
    local playerAvatars = gRegion:GetHumanPlayerAvatars()    
    for i, avatar in ipairs(playerAvatars) do    
        -- We might actually want to play this for everyone, consider using play Global Transmission instead?
        local ship = gGameRules:GetCrewShipManager():GetPlayerShip()
        if avatar:InventoryControl():IsOnBoardShip(ship) then -- Commenting out to test in sandbox
            DIALOG.PlayLocalTransmission(mTransmissionSet, tag, delay, avatar)
        end
    end
end

local function SetAttachmentVisibility(action, visible)
    local attachments = action:GetAttachedChildren()
    
    for i=1, #attachments do
        attachments[i]:SetVisibility(visible)
        Sleep(0)
    end
    action:SetVisibility(visible)
end

local function BombDetonated(action)    
    local ship = gGameRules:GetCrewShipManager():GetPlayerShip()
    local shipAv = ship:GetAvatarOwner()
    
    if not IsNull(ship) and not IsNull(shipAv) and not shipAv:IsPreDeath() and not gGameRules:GodModeEnabled() then
        -- Put the ship into predeath
        _T.PreDeathBombPosition = action:GetPosition()
        shipAv:SetHealth(10)
    end
    
    --TODO: Have sound & FX take a look at this
    gRegion:CreateEntity(detonationFX, action:GetPosition() + Vector(0, 1, 0), ZERO_ROTATION)
    gRegion:PlaySound(boomSound, action:GetPosition() + Vector(0, 1, 0) , false)
    
    --Clean up
    mTimerMgr:RemoveTimer(mBombTimer)
    if not IsNull(mMarker) then
        mMarker:Destroy()
    end
    SetAttachmentVisibility(action, false)
    action:Disable()
end

local function BombPlanted(action)
    mMarker = gRegion:CreateEntity(bombMarkerType, action:GetPosition(), ZERO_ROTATION)
    mMarker:Enable()
    
    --hack
    local deco = action:GetAttachment(gDecorationType)
    if not IsNull(deco) then
        local offset = Vector(0, 1.65, 0)
        deco:AttachEntity(mMarker, EMPTY_SYMBOL, offset, action:GetRotation())
    end
    
    
    --action:Enable()
    
    mTimerMgr = TIMER.CreateTimerMgr()
    
    mBombTimer = mTimerMgr:AddTimer(bombFuse, function() BombDetonated(action) end)
    
    PlayOnboardCyTransmission(Symbol("IntruderPlantExplosives"), 1)
    SetAttachmentVisibility(action, true)
end

function OnKilled()
    --wait before continuing to spawn another Sentient Hacker
    Sleep(10)
    
    gGameRules:SetNetPersistentVar(NV_RJ_NUM_HACKERS, 0)
end

--Main function - Contains main update loop, monitor mode state here
function Start(hint)
    Initialize(hint)
    
    local ship = gGameRules:GetCrewShipManager():GetPlayerShip()
    local cameraTiltTrigger = RAIL.FindFirstTaggedOnShip(Symbol("CameraTilt"), ship)
    
    if not IsNull(cameraTiltTrigger) then
        if not cameraTiltTrigger:IsRunning() then
            cameraTiltTrigger:FirePort("Execute")
        end
    end
    
    if hint:GetEncounterDynamicState() == STARTED then
        
        local numExisting = hint:GetNumRegisteredAgents()
        local spawns = gRegion:FindTaggedInRadius(sPodSpawn, hint:GetPosition(), 0, 10)       
        
        for i, spawn in ipairs(spawns) do
            if i > numExisting and i <= numBoardersToSpawn then    --spawn only missing agents, its very unlikely, but possible to migrate during agent spawning phase
                local agentType
                
                if not IsNull(aiSpec) then
                    agentType = mAiDir:GetRandomEnemyAgentTypeFromAISpec(aiSpec, faction, mAgentLevelRange:Rand(), true, false, agentTier, true)
                else
                    agentType = mAiDir:GetRandomEnemyAgentType(faction, mAgentLevelRange:Rand(), true, false, agentTier, true)
                end
                
                local agent = mAiDir:CreateAgent(agentType, spawn, EMPTY_SYMBOL)
                if not IsNull(agent) then
                    agent:SetAlert()
                    hint:RegisterAgent(agent)
                end
                Sleep(0)
            end
        end
        
        if mAiDir:GetNumberOfActiveEncountersOfType(hint:GetCurrentEncounterTemplate()) == 1 then
            local shipAvatar = ship:GetAvatarOwner()
            local transTag = Symbol("RailjackBoarded")
            if not IsNull(shipAvatar) and shipAvatar:GetHealthPercentage() <= 0.6 then
                transTag = Symbol("RailjackBoardedHighRisk")
            end
            
            PlayOnboardCyTransmission(transTag, 1)

            gChallengeMgr:BroadcastNotifyTag(Symbol("BOARDING_PARTY_START"))
        end
        hint:SetEncounterDynamicState(ATTACKING)
    end
    
    --TODO: Add other boarding party objectives
    --[[if hint:GetEncounterDynamicState() == ATTACK_REACTOR then
        local target = gRegion:FindFirstTagged(sReactor)
        local dv = gRegion:FindFirstTagged(sReactorDV)
        
        local agents = hint:GetRegisteredAgents()
        for i, agent in ipairs(agents) do
            agent:StormTarget(dv, 10)
            agent:SetDefenseVolume(dv, true)
        end
    end]]--
    
    local numAgents = hint:GetNumRegisteredAgents()
    
    if faction == Symbol("Grineer") then
        local n = 0
        local bombAgent = nil
        local target = nil
        local warningsGiven = 0
    
        while not IsNull(hint) and hint:GetEncounterDynamicState() ~= TERMINATE and (numAgents > 0 or hint:GetEncounterDynamicState() == BOMB_PLANTED) do    
            Sleep(0)
            numAgents = hint:GetNumRegisteredAgents()
            local delta = DeltaTime()
        
            if n <= timeUntilBomb + 1 then
                n = n + delta
            end
        
            if n > timeUntilBomb and numAgents > 0 and hint:GetEncounterDynamicState() == ATTACKING then        
                -- There is a lot of room for improvement selection wise but this will do for first draft
          
                if IsNull(bombAgent) then
                    --Pick an agent (maybe we want demo agent in particular?)                
                    local agents = hint:GetRegisteredAgents()
                    bombAgent = agents[RandomInt(1, numAgents)] -- Choose agent better            

                    if IsNull(target) and not IsNull(bombAgent) then
                        --Pick closest hull breach point to that agent
                        --TODO put these in instanceres for perf?
                        local targets = gRegion:FindTaggedInRadius(sBombAction, bombAgent:GetAvatar():GetPosition(), 0, 500) --Make sure it's not active. This needs to pick a bomb point better. 
                        local numTargets = #targets
                        local validTargets = {}
                        for i=1,numTargets do
                            -- Only pick ones not already active
                            if targets[i]:IsRestricted() then
                                table.insert(validTargets, targets[i])
                            end
                        end
                        if #validTargets < numTargets then
                            -- We already have one on the go, don't start another. Just skip
                            hint:SetEncounterDynamicState(BOMB_ENDED)
                        else
                            target = validTargets[RandomInt(1, #validTargets)]
                        end
                    end
                
                    if not IsNull(bombAgent) and not IsNull(target) then
                        --Go set up the bomb
                        bombAgent:UseContextAction(target, false)
                    end
                end
            end
        
            --We've just placed the bomb, advance to the next phase
            if not IsNull(target) and not target:IsRestricted() and hint:GetEncounterDynamicState() == ATTACKING then
                -- Return our guy to normal behaviour whether we were the ones that planted or not.
                if not IsNull(bombAgent) then
                    bombAgent:ReturnToAiControl()
                end
            
                if not IsNull(bombAgent) and bombAgent:GetAgentBlackboardValue(sBombPlantedSymbol) == 1 then
                    BombPlanted(target)
                    PlayOnboardCyTransmission(Symbol("IntruderPlantExplosives"), 0)
                    hint:SetEncounterDynamicState(BOMB_PLANTED)
                else
                    --Somebody else planted this bomb, not our guy. Move on.
                    target = nil
                    bombAgent = nil
                    hint:SetEncounterDynamicState(BOMB_ENDED)
                end
            end
        
            -- Bomb has been placed - give warnings, and see if we defuse or disarm it
            if hint:GetEncounterDynamicState() == BOMB_PLANTED and not IsNull(target) then
                if not target:IsEnabled() then
                    -- We've defused it
                    PlayOnboardCyTransmission(Symbol("ExplosiveDefused"), 1)
                    SetAttachmentVisibility(target, false)
                    if not IsNull(mMarker) then
                        mMarker:Destroy()
                    end
                    hint:SetEncounterDynamicState(BOMB_ENDED)
                    mTimerMgr:RemoveTimer(mBombTimer)
                    SetAttachmentVisibility(target, false)
                    target:Enable()
                    target:SetRestricted(true)
                else            
                    -- Still ticking...
                    mTimerMgr:Update(delta)
                
                    local timeLeft = mTimerMgr:GetTimeLeft(mBombTimer)
                    if (timeLeft == nil or timeLeft <= 0) and warningsGiven < 3 then
                        --We're too late!
                        if not IsNull(cameraTiltTrigger) then
                            if not cameraTiltTrigger:IsRunning() then
                                cameraTiltTrigger:FirePort("Execute")
                            end
                        end
                        hint:SetEncounterDynamicState(BOMB_ENDED)
                        warningsGiven = 3 -- Just to be safe, the callback will do the actual detonation
                    elseif timeLeft <= (bombFuse * 0.25) and warningsGiven < 2 then
                        --Second Warning
                        PlayOnboardCyTransmission(Symbol("ExplosiveTimerAlmostOver"), 0)
                        warningsGiven = warningsGiven + 1
                    elseif timeLeft <= (bombFuse * 0.5) and warningsGiven < 1 then
                        -- First Warning
                        PlayOnboardCyTransmission(Symbol("ExplosiveTimerHalf"), 0)
                        warningsGiven = warningsGiven + 1
                    end
                end
            end
        end
        
        --Restore bomb back to defaults so we don't run out of bombs
        if not IsNull(target) then
            target:Enable()
            target:SetRestricted(true)
            if not IsNull(mMarker) then
                mMarker:Destroy()
            end
            if not IsNull(mTimerMgr) then
                mTimerMgr:RemoveTimer(mBombTimer)
            end
            SetAttachmentVisibility(target, false)
        end
        
    elseif faction == Symbol("Corpus") then
        while not IsNull(hint) and hint:GetEncounterDynamicState() ~= TERMINATE and numAgents > 0 do    
            Sleep(0)
            numAgents = hint:GetNumRegisteredAgents()
        
            --Corpus Boarding specific actions will go here
        
        end
    
    elseif faction == Symbol("Sentient") then
        local sentientSpawn = gRegion:FindFirstTaggedInRadius(sPodSpawn, hint:GetPosition(), 0, 10)
        
        while not IsNull(hint) and hint:GetEncounterDynamicState() ~= TERMINATE and numAgents > 0 do    
            Sleep(0)
            numAgents = hint:GetNumRegisteredAgents()
            local activeHacker = false
            local numHackers = 0
            
            if not IsNull(hackerAgentType) then
                --Are there any SentientHackers already spawned?
                numHackers = gGameRules:GetNetPersistentVar(NV_RJ_NUM_HACKERS)
                
                if numHackers > 0 then
                    activeHacker = true
                end
                
                --If not, we need to make one
                if not activeHacker and numHackers == 0 then
                    local agent = mAiDir:CreateAgent(hackerAgentType, sentientSpawn, EMPTY_SYMBOL)
                    local avatar = agent:GetAvatar()
                    
                    gGameRules:SetNetPersistentVar(NV_RJ_NUM_HACKERS, 1)
                    
                    ObjectPortHandler(avatar, "OnKilled")
                    
                    if not IsNull(agent) then
                        agent:SetAlert()
                        hint:RegisterAgent(agent)
                    end
                end
            end
        
        end
    end
    
    --If the Boarding Party was Sentient, deactivate the Sled Energy FX when the party is defeated
    if faction == Symbol("Sentient") then
        local podFX = Symbol("HideSentientPod")
        local sentientRamSledFx = gRegion:FindFirstTaggedInRadius(podFX, hint:GetPosition(), 0, 10)
            
        if not IsNull(sentientRamSledFx) then
            sentientRamSledFx:FirePort("TriggerPort")
        end
    end
    
    if hint:GetEncounterDynamicState() ~= TERMINATE then
        local numActive = mAiDir:GetNumberOfActiveEncountersOfType(hint:GetCurrentEncounterTemplate())
        local shipAv = ship:GetAvatarOwner()
        if ((hint:IsActive() and numActive <= 1) or (not hint:IsActive() and numActive == 0)) and not IsNull(shipAv) and not shipAv:IsPreDeath()  then        
            PlayOnboardCyTransmission(Symbol("BoardingPartyDefeated"), 0)
            gChallengeMgr:BroadcastNotifyTag(Symbol("BOARDING_PARTY_DEFEATED"))
        end
    end
    -- Even if boarding party is defeated, monitor the bomb
    --[[while hint:GetEncounterDynamicState() == BOMB_PLANTED do
        mTimerMgr:Update(DeltaTime())
        
        if not target:IsEnabled() then
            -- We've defused it
            PlayOnboardCyTransmission(Symbol("ExplosiveDefused"), 1)
            SetAttachmentVisibility(target, false)
            if not IsNull(mMarker) then
                mMarker:Destroy()
            end
            hint:SetEncounterDynamicState(BOMB_ENDED)
        el
    end]]--
    
    -- Clean up agents
    if not IsNull(hint) then
        local agentsToKill = hint:GetRegisteredAgents()
        for i=1, #agentsToKill do
            if not IsNull(agentsToKill[i]) then
                local av  = agentsToKill[i]:GetAvatar()
                if not IsNull(av) and av:GetOriginalFaction() ~= sTennoFaction then
                    av:Destroy()
                end
            end
        end
    end
end

function CipherResult(avatar, result, instigator)
    -- instigator is bombaction
    -- avatar is hacker
    -- result 1 is success
    
    if IsNull(avatar) then
        return
    end
    
    if not IsNull(avatar:GetAgent()) then
        result = 1
    end
    
    if result == nil then
        result = 1
    end
    
    if result == 1 then
        if avatar:GetOriginalFaction() ~= sTennoFaction and avatar:GetFaction() ~= sTennoFaction then
            if not IsNull(avatar:GetAgent()) and instigator:IsRestricted() then
                avatar:GetAgent():SetAgentBlackboardValue(sBombPlantedSymbol, 1)
            end
            instigator:SetRestricted(false)
        end
    end    
end
