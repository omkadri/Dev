playerFaction = Symbol("TENNO")

local function _GunnerAction(action, isMounting)
    if IsNull(action) then
        print("Tried to use a null action")
        return
    end

    local crewShipMgr = gGameRules:GetCrewShipManager()
    local ship = crewShipMgr:GetShipForZone(action:GetZone())
    
    if IsNull(ship) then
        print("Couldn't set up ship emplacement action" .. action:GetName() .. " because it is not in a crew ship zone")
        return
    end

    local crewShipAvatar = ship:GetAvatarOwner()
    local crewShipAgent = crewShipAvatar:GetAgent()

    if IsNull(crewShipAgent) then
        return
    end

    local enableShooting = false

    
    local gunnerAvatar = action:GetCurrUser()
    if IsNull(gunnerAvatar) then
        Sleep(0)
        gunnerAvatar = action:GetCurrUser()
    end
    
    if not IsNull(gunnerAvatar) then
        if isMounting and not gunnerAvatar:IsKilled() and (gunnerAvatar:GetFaction() ~= playerFaction) then
            enableShooting = true
        end
    end
    
    local hand = action:GetEmplacementHand()
    crewShipAgent:ControlActiveWeapon(enableShooting, hand)
    print("Set weapon " .. tostring(hand) .. " controlled: " .. tostring(enableShooting))
end

function Dismount(action)
    print("Dismount " .. action:GetName())
    _GunnerAction(action, false)
end

function Mount(action)
    print("Mount " .. action:GetName())
    _GunnerAction(action, true)
end
