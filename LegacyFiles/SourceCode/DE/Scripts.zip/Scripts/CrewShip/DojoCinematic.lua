cin = { Instance() }

Delay = 0
isShowVisibility = true
hideChildren = true
tag = Symbol()

local GondolaTubeDeco = Resource("/Lotus/Fx/Gameplay/RailJack/RailjackCannonTubeDeco")

function PlayCinematics()
    if gRegion:IsMaster() then
        for i, c in ipairs(cin) do
            c:FirePort("StartPlaying")
        end
    end
end

function InitDocking(cin, railjackAvatar)
    railjackAvatar:SetAnimAction(Symbol("Dock"))
end

function hideGondolaTube(cin, railjackAvatar)
    local tube = nil
    if not IsNull(railjackAvatar) then 
        tube = railjackAvatar:GetAttachment(GondolaTubeDeco)
        if not IsNull(tube) then
            tube:PlayTriggeredFade()
            Sleep(1)
            if not IsNull(tube) then
                tube:SetVisibility(false, false)
            end
        end
    end
end

function showGondolaTube(cin, railjackAvatar)
    local tube = nil
    if not IsNull(railjackAvatar) then
        tube = railjackAvatar:GetAttachment(GondolaTubeDeco)
        if not IsNull(tube) then
            tube:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, 0)
            tube:SetVisibility(true, false)
            local v,t,timelength = 0,0,3
            while t<timelength and not IsNull(tube) do
                v = Lerp(0,1,t/timelength)
                tube:SetMaterialParam(Lotus_Game.UNLIT_ATTEN, v)
                t = t + DeltaTime()
                Sleep(0)
            end
        end
    end
end

function HideShowTargetsWithTag()
    Sleep(Delay)
    local tagged = gRegion:FindTagged(tag)
    if not IsNull(tagged) then
        for j=1, #tagged do
            if not IsNull(tagged[j]) then
                tagged[j]:SetVisibility(isShowVisibility, hideChildren)
            end
        end
    end
end

function StopTunnelMusic()
	local seqMusic = gRegion:FindFirstTagged(Symbol("VoidTravelMusic"))
    local seqSounds = gRegion:FindFirstTagged(Symbol("VoidTravelSounds"))
    if not IsNull(seqMusic) then
        seqMusic:Disable()
    end

    if not IsNull(seqSounds) then
        seqSounds:Disable()
    end
end
