reactorAgentType = Type()
crewShipEncounterType = WeakResource()
scriptCallback = Symbol()

local sOnCrewShipSpawned = Symbol("OnCrewShipSpawnedScript")
local sReactorSpawnTag = Symbol("RailjackReactorSpawn")
local sCrewShipHint = Symbol("CrewShipHint")

function CrewShip(crewShip)
    local npcManager = gRegion:GetNpcMgr()
    --wait for nav & tac to be ready before we start
    while not npcManager:CanFind() do
        Sleep(0.1)
    end
    
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    local scriptTriggers = gRegion:FindTagged(sOnCrewShipSpawned)
    local zone = nil
    
    -- Find any tagged script triggers in the same region index, and execute them
    for i, trigger in ipairs(scriptTriggers) do
        zone = trigger:GetZone()
        if not IsNull(zone) then
            if zone:GetRegionIndex() == crewShip:GetInteriorLayer() + 1 then
                trigger:FirePort("Execute")
            end
        end
    end
    
    local pilotAction = crewShip:GetShipEmplacement(0)  --0 is pilot atm
    aiDir:SetObjective(pilotAction)
    
    --find the related hint and start the supplied encounter
    if not IsNull(crewShipEncounterType) and aiDir:EncountersEnabled() then
        local hints = gRegion:FindTagged(sCrewShipHint)
        for i, hint in ipairs(hints) do
            --make sure hint is valid and not already running an encounter after a host migration
            if crewShip:IsEntityOnBoardShip(hint) and not hint:IsActive() then
                aiDir:AddEncounterHint(hint)
                aiDir:ActivateSpecificEncounterAtSpecificHint(hint, crewShipEncounterType)
            end
        end        
    end

    if scriptCallback:IsValid() and _T[scriptCallback:c_str()] then
        _T[scriptCallback:c_str()](crewShip)
    end
end

function SpawnReactorDefenseTarget()
    local reactorSpawn = gRegion:FindFirstTagged(sReactorSpawnTag)
    while IsNull(reactorSpawn) do
        Sleep(0)
    end
    
    local level = 20 --what determines the level?
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    local agent = aiDir:CreateAgent(reactorAgentType, reactorSpawn, EMPTY_SYMBOL, level)
end