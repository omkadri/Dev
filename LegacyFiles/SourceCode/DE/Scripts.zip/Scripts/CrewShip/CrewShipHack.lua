local prevInstigator

function CheckForInstigator(hackAction)

    local crewShipAv = hackAction:GetAttachParent()

    if hackAction:IsA(gCipherActionType) then
        while true do
            local instigator = hackAction:GetCurrUser()
            
            -- remove instigator
            if (IsNull(instigator) or instigator:IsKilled()) and not IsNull(prevInstigator) then
                prevInstigator:InventoryControl():SetItemVisibility(Engine.MAIN_HAND, Engine.GRAB)
                prevInstigator = nil
            end
            
            -- Add instigator
            if (not IsNull(instigator) and not instigator:IsKilled()) and prevInstigator ~= instigator then
                local parent = hackAction:GetAttachParent()
                instigator:Teleport(hackAction:GetActivationPosition(instigator))
                instigator:InventoryControl():SetItemVisibility(Engine.MAIN_HAND, Engine.HOLSTER)
                prevInstigator = instigator
            end
            
            -- Update instigator
            if not IsNull(instigator) and not instigator:IsKilled()  then
                local motionCon = instigator:MotionControl()
                if not IsNull(motionCon) and motionCon:IsA(gLotusSpaceFlightMotionControllerType) then
                    motionCon:ForceSetView(hackAction:GetRotation())
                    instigator:SetCameraView(hackAction:GetRotation())
                end
            end
            Sleep(0)
        end        
    end
end

local prevHealth = 100
function OnEnterDoorKill(doorArmour)
    if doorArmour:GetCurrentHealth() <= 0 and prevHealth > 0 then
        local crewShipAv = doorArmour:GetAvatar()
        if not IsNull(crewShipAv) then
            local crewship = crewShipAv:InventoryControl():GetActivePowerSuit()
            if not IsNull(crewship) then
                local hitProxy = doorArmour:GetProxyId()
                local position = crewShipAv:DamageControl():GetHitProxyPosition(hitProxy)
                crewship:EnableClosestEnterAction(position, true, true)
            end
        end
    end
    prevHealth = doorArmour:GetCurrentHealth()
end

