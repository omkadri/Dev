drainPerSecond = 5
totalDrain = 50

local PLAYER_FACTION = Symbol("TENNO") 
local SOURCE_SYM = Symbol("EnergyDrainField")

function DrainShipEnergy(shipAvatar, trigger)
    
    if shipAvatar:GetFaction() ~= PLAYER_FACTION then
        return
    end
    
    local maxStacks = math.ceil(totalDrain / drainPerSecond)
    local ship = shipAvatar:InventoryControl():GetActivePowerSuit()
    local numStacksApplied = 0
    while not IsNull(shipAvatar) and numStacksApplied < maxStacks and trigger:IsTouching(shipAvatar) do
        ship:InhibitReactor(drainPerSecond, SOURCE_SYM, maxStacks) -- will be permanent
        numStacksApplied = numStacksApplied + 1
        Sleep(1)
    end

end

function ShipLeft(trigger, shipAvatar)

    if shipAvatar:GetFaction() ~= PLAYER_FACTION then
        return
    end

    local ship = shipAvatar:InventoryControl():GetActivePowerSuit()
    if not IsNull(ship) then
        ship:SetReactorDamageDuration(SOURCE_SYM, 1) -- set damage stacks to start decaying each second
    end
    
end