--Tornado Hazard
tornado = Instance()
local duration = 5
local maxIdleTime = 5
local maxAttackTime = 5
local minAttackRange = 400
local maxAttackRange = 400
local idleStepRange = 100
areaTrigger = Instance()
--LightningHazard
lightningFX = Instance()
lightningFXWaypoint = Instance()

--Camera Shake
local shakeRadius = 30
shakeMultiplier = 15
local shakeTime = 0.5
local shakeTimeMod = 2

local function StartCameraShake(pos)
    local t = 0
    local levelInfo = gRegion:GetLevelInfo()
    local player = gRegion:GetLocalPlayerAvatar()
    
    if IsNull(player) then
        return
    end
    
    if Length(player:GetSimPosition()-pos) > shakeRadius then
        return
    end

    while t < shakeTime  do
        levelInfo.postProcess.viewShake.mShakeAmbient = Abs(Sin(t*shakeTimeMod)) * shakeMultiplier
        t = t + DeltaTime()
        Sleep(0)
    end
    
    levelInfo.postProcess.viewShake.mShakeAmbient = 0
end

local function SpawnTornado()
end

local function MoveTornadoToPosition(targetPos)
    local tornadoPos = tornado:GetPosition() 
    local t = 0
    while t < duration do
        local newPos = LerpVector(tornadoPos, targetPos, t / duration)
        tornado:SetPosition(newPos)
        Sleep(0)
        t = t + DeltaTime()
    end
end

local function TornadoStickingToArea(triggerAtt, targetAtt)
    local triggerDimensions = triggerAtt:GetDimensions()
    local maxRange = triggerDimensions["x"]
    local rangeFromHome = triggerAtt:Distance2DToEntity(targetAtt)
    if rangeFromHome <= maxRange then
        return true
    else
        return false
    end
end

local function TornadoStickingToPos(pos)
    local triggerDimensions = areaTrigger:GetDimensions()
    local maxRange = triggerDimensions["x"]
    local rangeFromHome = areaTrigger:Distance2DToPoint(pos)
    if rangeFromHome <= maxRange then
        return true
    else
        return false
    end
end

local function PickRandomPositionXZ()
    local position
    local negativeRange = -1*idleStepRange
    local randomX = math.random(negativeRange, idleStepRange)
    local randomZ = math.random(negativeRange, idleStepRange)
    local randomNewPos = Vector()
    if not IsNull(tornado) then 
        position = tornado:GetPosition()
    end
    randomNewPos.x = position["x"] + randomX
    randomNewPos.y = position["y"]
    randomNewPos.z = position["z"] + randomZ
    if TornadoStickingToPos(randomNewPos) then
        return randomNewPos
    else
        PickRandomPositionXZ(position)
    end
end

local function MakePositionXZ(position)
    local newPos = Vector()
    newPos.x = position["x"]
    newPos.y = tornado:GetPosition()["y"]
    newPos.z = position["z"]
    
    return newPos
end



function StartTornado()

    --SpawnTornado()
    Broadcast("SPAWN")

    local tornadoState = Symbol("IDLE") -- IDLE / CHASE / ATTACK
    Broadcast("Idle")
    print("Tornado script has been executed")
    local inStateTime = 0
    local target = nil
    local trigger = areaTrigger
    
    while true do
        if trigger:IsEnabled() then
            if tornadoState == Symbol("IDLE") then
                --if inStateTime >= maxIdleTime then
                    if trigger:IsFull() and trigger:HasAvatarTouching() then
                        target = trigger:GetEntitiesTouching()[1] -- To be expanded to pick randomly between avatars
                        local range = tornado:Distance2DToEntity(target)
                        if range <= minAttackRange then
                            tornadoState = Symbol("CHASE")
                            Broadcast("Chasing you")
                            inStateTime = 0
                        end
                    else
                        local newPos = PickRandomPositionXZ()
                        MoveTornadoToPosition(newPos)
                        Broadcast("Tornado picked a new random spot to go")
                    end
                --end
            elseif tornadoState == Symbol("CHASE") then
                local range = tornado:Distance2DToEntity(target)
                if range <= maxAttackRange and TornadoStickingToArea(trigger, target) then
                    local newPos = MakePositionXZ(target:GetPosition())
                    MoveTornadoToPosition(newPos)
                else
                    tornadoState = Symbol("IDLE")
                    Broadcast("Back to idle")
                    inStateTime = 0
                end
            elseif tornadoState == Symbol("ATTACK") then
                if inStateTime <= maxAttackTime then
                    Sleep(1)
                else
                    tornadoState = Symbol("IDLE")   
                    inStateTime = 0
                    Broadcast("Back to idle")
                end
            else
            end
        else
            --return
        end
        Sleep(0)
    end
end

local function SpawnLightning(posStart)
    if not IsNull(lightningFX) and not IsNull(lightningFXWaypoint) then
        lightningFX:Enable()
        lightningFX:SetPosition(posStart)
        local posEnd = lightningFXWaypoint:GetPosition()
        posEnd.x = posStart.x
        posEnd.z = posStart.z
        lightningFX:SetEndPoint(posEnd)
    end
end

local function DespawnLightning()
    if not IsNull(lightningFX) then
        lightningFX:Disable()
    end
end

function StartLightning()
    while true do
    local randomPos = PickRandomPositionXZ()
    SpawnLightning(randomPos)
    Sleep(1)
    DespawnLightning()
    Sleep(2)
    end
end