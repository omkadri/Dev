
function CameraTilt(trigger)
    local INITIAL_DELAY = 0
    local TILT_ATTACK = 2
    local TILT_RELEASE = 1.5
    local TILT_HOLD = 0.0
    
    local MAX_TILT = 16

    local tiltRot = Rotation()

    Sleep(INITIAL_DELAY)
    
    local playerAv = gRegion:GetLocalPlayerAvatar()
    while IsNull(playerAv) do
        Sleep(0)
        playerAv = gRegion:GetLocalPlayerAvatar()
    end

    local post = gRegion:GetLevelInfo().postProcess
    post.viewShake.mShakeSpeed = 0.8
    post.viewShake.mShakeStrength = 0.5
    post.viewShake.mShakeFactorRot = Rotation(0.5, 0.5, 1)
    post.viewShake.mShakeFactorPos = 0.2


    local t = 0
    while t < 1 do
        Sleep(0)
        t = t + DeltaTime() / TILT_ATTACK

        local a = Clamp(SmoothStep(1 - math.pow(1 - t, 8)), 0, 1)

        local playerView = playerAv:GetCameraView()
        tiltRot.bank = Lerp(0, MAX_TILT, (a + Noise(t)) * math.cos(math.rad(playerView.heading)))
        playerAv:SetCameraView(CombineRotations(playerView, tiltRot))
        --playerAv:CameraControl():ShakeView(playerAv:GetPosition(), 10, 3 * Lerp(1, 0.3, a), 2)
        local shake = Noise(gGameRules:GetCurrentGameTime())
        post.viewShake.mShakeSpeed = Lerp(2, 1, a)
        post.viewShake.mShakeStrength = Lerp(shake * 7, 4, a)
    end

    t = 0
    while t < 1 do
        Sleep(0)
        t = t + DeltaTime() / TILT_HOLD

        local playerView = playerAv:GetCameraView()
        tiltRot.bank = MAX_TILT * math.cos(math.rad(playerView.heading)) 
        playerAv:SetCameraView(CombineRotations(playerView, tiltRot))
    end

    t = 0
    while t < 1 do
        Sleep(0)
        t = t + DeltaTime() / TILT_RELEASE
        local a = SmoothStep(Clamp(t + Noise(t), 0, 1))

        --playerAv:CameraControl():ShakeView(playerAv:GetPosition(), 10, 3 * Lerp(0.3, 0.1, t), 1)
        post.viewShake.mShakeSpeed = Lerp(1, 0.8, a)
        post.viewShake.mShakeStrength = Lerp(4, 0.5, a)

        local playerView = playerAv:GetCameraView()
        tiltRot.bank = Lerp(MAX_TILT, 0, a) * math.cos(math.rad(playerView.heading))
        playerAv:SetCameraView(CombineRotations(playerView, tiltRot))
    end
    
    --[[post.viewShake.mShakeSpeed = 0.8
    post.viewShake.mShakeStrength = 0.5
    while trigger:IsEnabled() do
        Sleep(0)
    end]]
    post.viewShake.mShakeSpeed = 0.0
    post.viewShake.mShakeStrength = 0
    post.viewShake.mShakeFactorRot = Rotation(1, 0.5, 0.5)
    post.viewShake.mShakeFactorPos = 0.0
end