railjackTransmissionSet = Resource()
multiToolAmmoType = Type()
local breachAmmoCost = 50

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"

-- Pre death breach setup
local StartHullBreachForwarderTag = Symbol("OnHullBreachStarted")
local StopHullBreachForwarderTag = Symbol("OnHullBreachStopped")

local mBreachLimit = 1
local mTimeToRepairBreaches = 60
local mRepairHealthBoost = 0
local mFullRepairInvulnerabilityDurationMin = 5
local mFullRepairInvulnerabilityDurationMax = 15
local mRailjackAvatar = nil
local mRailjackDamageControl = nil
local mMegaBreachSpawner = nil
local mRailjackPreDeathInvulnerability = Symbol('RailjackPreDeathInvulnerability')

local sTennoFaction = Symbol("TENNO")

local function GiveShipTemporaryInvulnerability(timeLeftOnTimer)
    if not IsNull(mRailjackAvatar) then
        local railjackDC = mRailjackAvatar:DamageControl()
        local invulnerabilityDuration = Lerp(mFullRepairInvulnerabilityDurationMin, mFullRepairInvulnerabilityDurationMax, (timeLeftOnTimer/ mTimeToRepairBreaches))
        if not IsNull(_T.TimedInvulnerabilityOnBreachRepairMultiplier) then
            invulnerabilityDuration = invulnerabilityDuration *_T.TimedInvulnerabilityOnBreachRepairMultiplier
        end
        
        if not IsNull(railjackDC) then
            railjackDC:GiveTemporaryImmunity(invulnerabilityDuration, invulnerabilityDuration)     
        end
    end
end

local function StopHullBreach()
    if not IsNull(mRailjackDamageControl) then
        mRailjackDamageControl:ClearPreDeathBreach()
    else
        print("ERROR RailjackPreDeath: Failed to clear predeath breach")
    end
    
    if not IsNull(mRailjackAvatar) then
        local preDeathHealthThreshold = 123
        if not IsNull(mRailjackDamageControl) then
            preDeathHealthThreshold = mRailjackDamageControl:PreDeathHealthThreshold()
            preDeathHealthThreshold = math.abs(preDeathHealthThreshold - mRailjackAvatar:GetHealth())
        end
        local portionHealthRestore = 0.3
        mRepairHealthBoost = math.max(mRailjackAvatar:GetMaxHealth() * portionHealthRestore, preDeathHealthThreshold)
        mRailjackAvatar:SetHealth(mRailjackAvatar:GetHealth() + mRepairHealthBoost)
    end
    
    if not IsNull(mMegaBreachSpawner) and mMegaBreachSpawner:GetMalfunctionCount() > 0 then
        mMegaBreachSpawner:FirePort("RepairAll")
    end
    
    local breachStoppedForwarder = gRegion:FindTagged(StopHullBreachForwarderTag)
    if not IsNull(breachStoppedForwarder) then
        breachStoppedForwarder[1]:FirePort("TriggerPort")
    end    

    OBJTXT.RemoveObjTimer()
    _T.RailjackPreDeath = nil
end
_T.RailjackStopHullBreach = StopHullBreach

function ReturnToDojo()
    if gRegion:IsMaster() then
        StopHullBreach()
    end
    print("RAILJACKPREDEATH: Return to Dojo'")
    local destinationLevel = "CrewBattleNodeDojo"
    _T.RailJackNextMissionNode = Symbol(destinationLevel)
    _T.SeamlessRailJackTransition = gGameRules:IsA(gLotusAttractModeGameRulesType)
        
    local sectorInfo = { name = destinationLevel, difficulty = 0 }
    local sectorJSON = cjson.encode(sectorInfo)
    gMatchingService:SendSquadMission(sectorJSON)

    local starChart = LOTUS_UTIL.GetStarChart()
    local travelSector = starChart:GetNodeForMission(Symbol("CrewShipGenericTunnel"))
    local shipManager = gGameRules:GetCrewShipManager()
    shipManager:SetNextMission(travelSector.mission)

    if not IsNull(_T.ClearRailjackMissionState) then
        _T.ClearRailjackMissionState()
    end
end

local function BreachFailed()
    StopHullBreach()

    gGameRules:SetReturnToLobbyCallback("ReturnToDojo")
    gGameRules:EndGame(Engine.GameRules_GS_FAILURE, 0)
    RAIL.TeleportPlayersOutOfEnemyShips()
end

local function UpdateRepairs()
    if not IsNull(_T.RailjackPreDeath) and _T.RailjackPreDeath.NewRepair then
        _T.RailjackPreDeath.NewRepair = false
        
        if mMegaBreachSpawner:GetMalfunctionCount() <= 0 then
            local timeLeftOnTimer = OBJTXT.GetObjTime()
            StopHullBreach()
            GiveShipTemporaryInvulnerability(timeLeftOnTimer)
        else
            DIALOG.PlayLocalTransmission(railjackTransmissionSet, Symbol("BreachSealed"), 0, gRegion:GetLocalPlayerAvatar())
        end
    end
end

local function PauseBreachCountDown(time)
    if not IsNull(_T.RailjackPreDeath) and OBJTXT.GetObjTime()  > 0 then
        OBJTXT.PauseObjTimer(true)
        Sleep(time)
        OBJTXT.PauseObjTimer(false)
    end
end

local function SpawnBreach()
    local breachPorts = gRegion:FindTagged(Symbol("ShowHullBreach"))
    local possibleBreachPoints = {}
    for i, portForwarder in ipairs(breachPorts) do
        local ramsledBreach = gRegion:FindNearestTagged(Symbol("RamsledBreach"), portForwarder:GetPosition())
        local hullBreach = gRegion:FindNearestTagged(Symbol("HullBreach"), portForwarder:GetPosition())
        local alreadyBreachedByBoardingParty = not IsNull(ramsledBreach) and ramsledBreach:IsVisible()
        local alreadyRuptured = not IsNull(hullBreach) and hullBreach:IsVisible()
        if alreadyRuptured then
            possibleBreachPoints = {portForwarder}
            break
        end
        if not alreadyBreachedByBoardingParty then
            table.insert(possibleBreachPoints, portForwarder)
        end
    end

    local showHullBreachForwarder = nil
    if #possibleBreachPoints == 0 then
        print("ERROR: RailJackPreDeath: No breach points available. Going to smash into preexisting breach!")
        showHullBreachForwarder = breachPorts[math.random(#breachPorts)]
    else
        showHullBreachForwarder = possibleBreachPoints[math.random(#possibleBreachPoints)]
        if not IsNull(_T.PreDeathBombPosition) then   --Create a breach as close to the bomb's explosion location as possible
            local bombExplosionPosition = _T.PreDeathBombPosition
            local closestDist = FLT_MAX
            for i=1, #possibleBreachPoints do
                local dist = Distance(bombExplosionPosition, possibleBreachPoints[i]:GetPosition())
                if dist < closestDist then
                    closestDist = dist
                    showHullBreachForwarder = possibleBreachPoints[i]
                end
            end
            _T.PreDeathBombPosition = nil
        end
    end
        
    showHullBreachForwarder:FirePort("TriggerPort")
    _T.RailjackPreDeath.OnRepairedHidePort = gRegion:FindNearestTagged(Symbol("HideHullBreach"), showHullBreachForwarder:GetPosition())  

    local malfunction = mMegaBreachSpawner:Spawn(showHullBreachForwarder:GetPosition(), showHullBreachForwarder:GetRotation())
    if IsNull(malfunction) then
        print("ERROR RailjackPreDeath: Failed to create a rupture")
    end
end

local function StartHullBreach(entity)
    print("StartHullBreach()")
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    mRailjackAvatar = crewShipMgr:GetPlayerShip():GetAvatarOwner()  
    
    if not IsNull(mRailjackAvatar) then
        mRailjackDamageControl = mRailjackAvatar:DamageControl()
    end
    
    local breachStartedForwarder = gRegion:FindTagged(StartHullBreachForwarderTag)
    if not IsNull(breachStartedForwarder) then
        breachStartedForwarder[1]:FirePort("TriggerPort")
    end

    mMegaBreachSpawner = gRegion:FindFirstTagged(Symbol("MegaBreachSpawner"))
    if not IsNull(mMegaBreachSpawner) then
        mMegaBreachSpawner:SetLimit(mBreachLimit)
    end

    local countUp = false
    local removeOnComplete = false
    local endMissionAfterTimer = false
    OBJTXT.SetObjTimer(mTimeToRepairBreaches, countUp, removeOnComplete, endMissionAfterTimer, OBJTXT.TIMELEFT_STRING, "/Lotus/Language/Game/RaidReactorExplosionTimer", 3.0, "/Lotus/Language/Game/RaidReactorExplosionTimer")

    _T.RailjackPreDeath = {}
    _T.RailjackPreDeath.NewRepair = false
    _T.RailjackPreDeath.OnRepairedHidePort = nil
    
    local numBreachesToSpawn = 1
    for i=1, numBreachesToSpawn do
        SpawnBreach()
    end

    local delayTimer = 0
    local promptTimer = 15
    while mRailjackAvatar:IsPreDeath() do            
        promptTimer = promptTimer - DeltaTime()
        if OBJTXT.GetObjTime() <= 0 then
            BreachFailed()
            break
        elseif promptTimer <= 0 then
            DIALOG.PlayLocalTransmission(railjackTransmissionSet, Symbol("BreachEventOngoing"))
            promptTimer = 15
        end

        if not IsNull(_T.MegaBreachDelayAbilityTime) then
            delayTimer = delayTimer + _T.MegaBreachDelayAbilityTime
            _T.MegaBreachDelayAbilityTime = nil
            if delayTimer > 0 then
                OBJTXT.PauseObjTimer(true)
            end
        end

        if delayTimer > 0 then
            delayTimer = delayTimer - DeltaTime()
            if delayTimer <= 0 then
                OBJTXT.PauseObjTimer(false)
            end
        end

        UpdateRepairs()
        
        Sleep(0)
    end
    print("Hull breach done")
end

function ReturnedToDojo()
    if gRegion:IsMaster() then

        local crewShipMgr = gGameRules:GetCrewShipManager()
        if not IsNull(crewShipMgr) and not IsNull(crewShipMgr:GetPlayerShip()) then
            local mRailjackAvatar = crewShipMgr:GetPlayerShip():GetAvatarOwner()
            if not IsNull(mRailjackAvatar) then
                mRailjackAvatar:SetHealth(mRailjackAvatar:GetMaxHealth())
            end
        end
    end
end

function OnRepairedScriptCallback(spawner, repairedMalfunction)
    if not IsNull(_T.RailjackPreDeath) then
        _T.RailjackPreDeath.NewRepair = true
        
        if not IsNull(_T.RailjackPreDeath.OnRepairedHidePort) then
            _T.RailjackPreDeath.OnRepairedHidePort:FirePort("TriggerPort")
            _T.RailjackPreDeath.OnRepairedHidePort = nil
        end        
    end
end

function RailjackPredeath()
    if gRegion:IsMaster() and IsNull(_T.RailjackPreDeath) then
        local crewShipMgr = gGameRules:GetCrewShipManager()
        local playerShip = crewShipMgr:GetPlayerShip()
        while IsNull(playerShip) do --Wait for ship after migration
            Sleep(0)
            playerShip = crewShipMgr:GetPlayerShip()
        end
        
        StartHullBreach()
    end
end

function ForcePredeath()
    if gRegion:IsMaster() and gFlashMgr:GetConfigBool("Engine.DeveloperMode") then        
        local crewShipMgr = gGameRules:GetCrewShipManager()
        mRailjackAvatar = crewShipMgr:GetPlayerShip():GetAvatarOwner()
        mRailjackAvatar:SetHealth(10)
    end
end

function ForceFail()
    if gRegion:IsMaster() and gFlashMgr:GetConfigBool("Engine.DeveloperMode") then
        BreachFailed()
    end
end

function StartBreachEffects()
    DIALOG.PlayLocalTransmission(railjackTransmissionSet, Symbol("BreachEventCleared"), 0, gRegion:GetLocalPlayerAvatar())
end

function StopBreachEffects()
    DIALOG.PlayLocalTransmission(railjackTransmissionSet, Symbol("BreachEventCleared"), 0, gRegion:GetLocalPlayerAvatar())
end