crewMemberGenerationInfo = Resource()
perItemExpiry = false

local movieType = Resource("/Lotus/Interface/GenericMenu.swf")
local crewMemberCount = 10

local OPTION_HIRE           = 2
local OPTION_ASSIGN         = 3
local OPTION_ASSIGN_ROLE    = 4

local UTIL = require "EE.Interface.Utilities"

local function GetCrewMemberString(crewMember)
    if not IsNull(crewMember) then
        local crewMemberString = 
        UTIL.Ternary(crewMember.mIsFemale, "FEMALE ", "MALE ") .. " " .. tostring(crewMember.mFaction) .. " " ..
        "PILOTING: " .. crewMember:GetSkillEfficiency(Lotus_Game.CMS_PILOTING) .. "/" .. crewMember:GetMaxSkillEfficiency(Lotus_Game.CMS_PILOTING) .. " " .. 
        "GUNNERY: " .. crewMember:GetSkillEfficiency(Lotus_Game.CMS_GUNNERY) .. "/" .. crewMember:GetMaxSkillEfficiency(Lotus_Game.CMS_GUNNERY) ..  " " ..
        "ENGINEERING: " .. crewMember:GetSkillEfficiency(Lotus_Game.CMS_ENGINEERING) .. "/" .. crewMember:GetMaxSkillEfficiency(Lotus_Game.CMS_ENGINEERING) ..  " "

        return crewMemberString
    else
        return ""
    end
end

local function OpenHireCrewMemberScreen()
    local hireCrewMemberMovie = gFlashMgr:GotoMovie(movieType)

    if not IsNull(hireCrewMemberMovie) then

        hireCrewMemberMovie:Execute("SetTitle", "Hire Crew Members")

        _T.MenuSelectionDone = function(pElements)
            if not IsNull(pElements[1]) and not IsNull(gGameData) then
                gGameData:AddCrewMember(pElements[1].mInfo, "CallbackCompleted")
            end
        end
        hireCrewMemberMovie:Execute("SetCallBack", "MenuSelectionDone")
        
        _T.GetMenuEntries =  function()
            local info = {}
            local player = gRegion:GetLocalPlayer()
            for i=1, crewMemberCount do
                if not IsNull(crewMemberGenerationInfo) then
                    local crewMember = crewMemberGenerationInfo:GenerateCrewMember(i, player)
                    local crewMemberString = GetCrewMemberString(crewMember)
                    table.insert(info, {mName = crewMember.mName .. ": " .. crewMemberString, mInfo = crewMember})
                end
            end
            return info
        end
        hireCrewMemberMovie:Execute("SetElementsFunction", "GetMenuEntries")
    end
end

local function OpenRoleSelectScreen(crewMember)
    local roleSelectMovie = gFlashMgr:GotoMovie(movieType)

    if not IsNull(roleSelectMovie) then
        roleSelectMovie:Execute("SetTitle", "Select Role")
        _T.SetRoleCrewMember = crewMember

        _T.MenuSelectionDone = function(pElements)
            if not IsNull(pElements[1]) and not IsNull(gGameData) and not IsNull(_T.SetRoleCrewMember) then
                gGameData:SetCrewMemberSlot(pElements[1].mInfo, _T.SetRoleCrewMember)
                gGameData:SaveLoadOut("CallbackCompleted")
            end
        end
        roleSelectMovie:Execute("SetCallBack", "MenuSelectionDone")

        _T.GetMenuEntries =  function()
            local info = {}
            table.insert(info, {mName = "Slot A", mInfo = Lotus_Game.CS_SLOT_A})
            table.insert(info, {mName = "Slot B", mInfo = Lotus_Game.CS_SLOT_B})
            table.insert(info, {mName = "Slot C", mInfo = Lotus_Game.CS_SLOT_C})
            return info
        end
        roleSelectMovie:Execute("SetElementsFunction", "GetMenuEntries")
    end
end

local function OpenAssignCrewMemberScreen()
    local assignCrewMemberMovie = gFlashMgr:GotoMovie(movieType)

    if not IsNull(assignCrewMemberMovie) then

        assignCrewMemberMovie:Execute("SetTitle", "Assign Roles")

        _T.MenuSelectionDone = function(pElements)
            if not IsNull(pElements[1]) then
                OpenRoleSelectScreen(pElements[1].mInfo)
            end
        end
        assignCrewMemberMovie:Execute("SetCallBack", "MenuSelectionDone")
        
        _T.GetMenuEntries =  function()
            local info = {}
            local inventory = gGameData:GetInventory()
            local crewMembers = inventory:GetCrewMembers()
            for _, crewMember in pairs(crewMembers) do
                crewMember:CalculateCrewMemberData(false)
                local crewMemberString = GetCrewMemberString(crewMember)
                table.insert(info, {mName = crewMember.mName .. ": " .. crewMemberString, mInfo = crewMember})
            end
            return info
        end
        assignCrewMemberMovie:Execute("SetElementsFunction", "GetMenuEntries")
    end
end

local function OpenHireAssignMenu()
    local movieType = gFlashMgr:GotoMovie(movieType)
    
    if not IsNull(movieType) then
        movieType:Execute("SetTitle", "Hire / Assign Crew Members")

        _T.GetHireAssignMenuEntries = function()
            local options = {}
            table.insert(options, {mName = "Assign Role", mInfo = OPTION_ASSIGN})
            table.insert(options, {mName = "Hire Crew Member", mInfo = OPTION_HIRE})

            return options
        end

        movieType:Execute("SetElementsFunction", "GetHireAssignMenuEntries")

        _T.HireAssignMenuSelectionDone = function(pElement)
            if not IsNull(pElement[1]) then
                if pElement[1].mInfo == OPTION_HIRE then
                    OpenHireCrewMemberScreen()
                elseif pElement[1].mInfo == OPTION_ASSIGN then
                    OpenAssignCrewMemberScreen()
                end
            end
        end

        movieType:Execute("SetCallBack", "HireAssignMenuSelectionDone")
    end
end

local function RebuildLoadOut()
    local railjackAvatar = gRegion:FindFirstTagged(Symbol("RailJackAvatar"))
    if not IsNull(railjackAvatar) then
        local shipSuit = railjackAvatar:InventoryControl():GetActivePowerSuit()
        if not IsNull(shipSuit) then
            local loadOut = gGameData:GetLoadOut()
            shipSuit:RebuildLoadOut(loadOut.mCrewShipLoadOut)
        end
    end
end

function OpenVendorMenu()    
    OpenHireAssignMenu()

    -- callback seems to fail since we;re not in the original context anymore? adding this hack for now and can be fixed when UI is created for it, need to call this when we assign a role to a crew member
    RebuildLoadOut()
end
