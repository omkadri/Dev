dropTable = Resource()

local PANIC = require "Lotus.Scripts.Libs.PanicLib"

local ALARM_DELAY = 10

local alarmTriggeringLoc = "[HC] ALARM IMMINENT"
local alarmTriggeredLoc = "[HC] ALARM TRIGGERED"
local alarmCancelledLoc = "[HC] ALARM CANCELLED"

local mDetectionTrigger = nil
local mDetected = false     --railjack entered trigger
local mEnabled = false      --detector is enabled
local mMarker = nil
local mDetectTime = 0
local mAlarmWentOff = false

local function GetAttachment(parent, attachmentType)
    local attachment = nil
    while IsNull(attachment) do
        Sleep(0)
        attachment = parent:GetAttachment(attachmentType)
    end
    return attachment
end

local function Detected()
    if mDetected then
        return
    end
    
    mDetected = true
    local players = gRegion:GetHumanPlayers()
    for i, player in ipairs(players) do
        gGameRules:DisplayMessage(player, alarmTriggeringLoc, "", 0, 3, true)
    end
end

function RailjackSensor(decoration)
    dropTable = dropTable

    while not gRegion:IsMaster() do
        Sleep(1)
    end

    mDetectionTrigger = decoration:GetAttachment(gTriggerType)
    mMarker = GetAttachment(decoration, gBaseMarkerInfoType) 
    
    ObjectPortHandler(mDetectionTrigger, "OnTouched")
    ObjectPortHandler(decoration, "OnDestroyed")
    ObjectPortHandler(decoration, "OnDamaged")
    
    while not IsNull(decoration) do
        Sleep(0)
        
        if mDetected then
            mDetectTime = mDetectTime + DeltaTime()
            
            if mDetectTime >= ALARM_DELAY then
                mAlarmWentOff = true
                local players = gRegion:GetHumanPlayers()
                for i, player in ipairs(players) do
                    gGameRules:DisplayMessage(player, alarmTriggeredLoc, "", 0, 3, true)
                end
                break
            end
        end
    end
end

function OnTouched(trigger)
    Detected()
end

function OnDamaged(deco)
    Detected()
end

function OnDestroyed(deco)
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    dropTable:GenerateDrops(deco, aiDir:GetEnemyFaction(), aiDir:GetMinEnemyLevel())
    mMarker:FirePort("Disable")
    
    if not mAlarmWentOff and mDetected then
        local players = gRegion:GetHumanPlayers()
        for i, player in ipairs(players) do
            gGameRules:DisplayMessage(player, alarmCancelledLoc, "", 0, 3, true)
        end
    end
end
