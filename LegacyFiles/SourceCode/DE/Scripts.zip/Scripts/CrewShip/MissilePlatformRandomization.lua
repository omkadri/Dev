doors = {Instance()}
minDoors = 1
nearestDoorTag = Symbol("OppositeDoor")
maxRangeDoor = 2
local maxDoors = 2
barricadeObjects = {Instance()}
barricadeObjectsHide = {Instance()}
barricadedDoor = Instance()
barricadeDoorHint = Instance()
frameUnlockedMaterial = Resource()
frameSlot = 1
navCutters = {Instance()}

function RandmizeHubDoors() --OnLevelStarted, position battery+beam, spawn reward
    local doorCount = math.random(minDoors, maxDoors)
    local randomDoorOne = 0
    local randomDoorTwo = 0
    
    if minDoors > 2 then
        return
    end
    
    randomDoorOne = math.random(1,#doors)
    
    for i = 1, #doors do
        if i ~= randomDoorOne then
            doors[i]:FirePort("Lock")
        end
    end
     
    if minDoors > 1 then
        repeat
            randomDoorTwo = math.random(1,#doors)
        until randomDoorOne ~= randomDoorTwo
        doors[randomDoorTwo]:FirePort("Unlock")
    end

end

function LockDoorIfDeadEnd()
    local currentDoor
    local nextDoor
    local doorPosition
    
    for i = 1, #doors do
        doors[i]:FirePort("Lock")
    end
    
    for i = 1, #doors do        
        nextDoor = nil
        currentDoor = doors[i]
        doorPosition = currentDoor:GetPosition()
        nextDoor = gRegion:FindTaggedInRadius(nearestDoorTag, doorPosition, 0, maxRangeDoor)
        if not IsNull(nextDoor) then
            currentDoor:FirePort("Unlock")
        end
    end
    
end

function SpawnBlastDoors()

if #doors < 1 then
    return
end

local doorStatus

for i = 1, #doors do
    doorStatus = doors[i]:GetDoorStatus()
    if doorStatus ~= 0 then
       return 
    end
end

if not IsNull(barricadeDoorHint) and barricadeDoorHint:IsA(gNpcDoorHintType) then
    barricadeDoorHint:FirePort("Lock")
end

end

function BlastDoorStateChange(hint)

    if IsNull(hint) or not hint:IsA(gNpcDoorHintType) then
        return
    end

    local hintStatus = hint:GetDoorStatus()
    
    if not IsNull(barricadedDoor) then
        if hintStatus == Npc.NpcDoorHint_DS_LOCKED then
            barricadedDoor:SetVisibility(true)
        elseif hintStatus == Npc.NpcDoorHint_DS_OPEN or hintStatus == Npc.NpcDoorHint_DS_BLOCKED then
            barricadedDoor:SetVisibility(false)
        end
    end
    
end

function OverrideFrameEmissive(hint) -- OnLevelStarted

    if IsNull(frameUnlockedMaterial) then
        return
    end

    local frames = gRegion:FindTaggedInRadius(Symbol("DoorFrameTag"), hint:GetPosition(), 0, 3)
    if #frames > 0 then
        local frameMat = frameUnlockedMaterial
        
        for i, frame in ipairs(frames) do
            frame:SetOverrideMaterial(frameSlot, frameMat)
        end
    else
        print("OverrideMaterials::OverrideDoorMaterials - " .. hint:GetFullName() .. " has no doorframes nearby")
    end

end