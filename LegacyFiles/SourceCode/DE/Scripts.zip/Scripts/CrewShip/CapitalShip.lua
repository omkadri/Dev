fadeOutTime = 0.5
fadeInTime = 0.5
attachAnim = Resource()

enterExitWaypointTag = Symbol()
crewShipEncounterType = WeakResource()

setViewAfterExiting = false --rot plyr after exiting to match wp rot

local sBackToSpaceTag = Symbol("BackToSpaceWaypoint")
local sBoardingShipTag = Symbol("BoardingShipWaypoint")

function OnDamaged(deco)
    --Detected()
end

function OnDestroyed(deco)

end

function CapitalShip(shipDeco)
    if IsNull(shipDeco) then
        return
    end

    ObjectPortHandler(shipDeco, "OnDestroyed")
    ObjectPortHandler(shipDeco, "OnDamaged")

    local shipManager = gGameRules:GetCrewShipManager()
    while shipManager:GetMissionState() ~= Lotus_Game.CrewShipMgr_MISSION_ACTIVE do
        Sleep(0)
    end

    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    if IsNull(aiDir) then
        return
    end
    
    while not aiDir:IsEnabled() and not aiDir:HasEncounterMgrCompletedMigration() do 
        Sleep(0)
    end

    --find the related hint and start the supplied encounter
    if not IsNull(crewShipEncounterType) then
        local hint = nil
        while IsNull(hint) do
            Sleep(1)
            hint = aiDir:ActivateSpecificEncounterAtPos(shipDeco:GetPosition(), crewShipEncounterType, nil, 0)
            --make sure hint is made.
        end
    end
end

function EnterExitCapitalShip(scriptTrigger, avatar)
    local enteringAvatar = nil
    local instigator = scriptTrigger:GetInstigator()
    
    if not IsNull(avatar) then
        enteringAvatar = avatar
    elseif not IsNull(instigator) and instigator:IsA(gTennoAvatarType) then
        enteringAvatar = instigator
    else
        return
    end
    
    local inventoryController = enteringAvatar:InventoryControl()
    local enterExitWaypoint = gRegion:FindFirstTagged(enterExitWaypointTag) --inventoryController:GetOnBoardShip()
    
    if not IsNull(enterExitWaypoint) and not IsNull(enteringAvatar:CameraControl()) then
        local postProcess = enteringAvatar:CameraControl():ScriptGetCurrentPostProcessInfo()
        local t = 0
        local val
    
        while t < 1 do
            val = Lerp(0, 1, t)
            postProcess.fade = val
            t = t + DeltaTime() / fadeOutTime
            Sleep(0)
        end
        postProcess.fade = 1

        local waypointRotation = enterExitWaypoint:GetRotation()
        
        local spawnPos = enterExitWaypoint:GetPosition() -- Temp; need to transform it
        local spawnRot = CombineRotations(waypointRotation, enteringAvatar:GetSimRotation())
        local viewRot = CombineRotations(waypointRotation, enteringAvatar:GetCameraView())

        enteringAvatar:Teleport(spawnPos, spawnRot)
        if setViewAfterExiting then 
			enteringAvatar:SetView(spawnRot)
		else
			enteringAvatar:SetView(viewRot)
		end
        
        if enterExitWaypointTag == sBackToSpaceTag then
            enteringAvatar:PlayAnimation(attachAnim, false)
        elseif enterExitWaypointTag == sBoardingShipTag then
            local aiDir = gRegion:GetNpcMgr():GetAiDirector()
            if not IsNull(aiDir) and aiDir:GetObjectiveComplete() then
                local explosions = gRegion:FindFirstTagged(Symbol("CorpusShipInteriorExplosions"))
                if not IsNull(explosions) then
                    while IsNull(enteringAvatar) do
                        Sleep(0)
                    end
                    explosions:RunScriptsOnEntity(enteringAvatar)
                end
            end
        end
        
        -- local downwardVelocity = Vector(0, -10, 0)
        -- downwardVelocity = RotateVector(downwardVelocity, shipRotation)
        
        t = 0
        while t < 1 do
            --instigator:MotionControl():SetPushVelocity(downwardVelocity, true)
            val = Lerp(1, 0, t)
            postProcess.fade = val
            t = t + DeltaTime() / fadeInTime
            Sleep(0)
        end

        postProcess.fade = 0
    end
end