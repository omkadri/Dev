riseSound = Resource()
fallSound = Resource()
riseCooldown = 2.0
fallCooldown = 2.0

function Initialize(entity)
    local crewship = entity:GetAttachParent()
    if not IsNull(crewship) and crewship:IsA(gCrewShipAvatarType) then
        local accelSound = Lotus_Game.CrewShipAccelSounds()
        accelSound.mRiseSound = riseSound
        accelSound.mFallSound = fallSound
        accelSound.mRiseCooldown = riseCooldown
        accelSound.mFallCooldown = fallCooldown
        crewship:SetAccelSound(accelSound)
    end
end