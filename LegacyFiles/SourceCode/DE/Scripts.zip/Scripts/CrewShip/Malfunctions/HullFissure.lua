splineType = Type()
splineTargetPoint = Type()
splineIntermitentSparks = Type()
targetPointRepaired = Type()

local MINING = require "Lotus.Scripts.Eidolon.MiningUtil"

local mSelf = nil
local mSpawner = nil
local mSpawnerInstance = 0
local mHealthForFullRepair = 0
local mFullyRepaired = false

local mDebugDrawSpline = false
local mDebugDrawProjectionPosition = false
local mDrawTime = 4
local mSeed = UnsignedToRandSeed(0)
local mNumTargetSamples = 100
local repairPercentage = 0.9    --Between [0 - 1]

function OnDestroyed(entity)
    if not IsNull(_T.Malfunctions) and not IsNull(_T.Malfunctions.Fissures) then
        _T.Malfunctions.Fissures[mSelf:GetInstance()] = nil
    end
    
    if gRegion:IsMaster() and not IsNull(gGameRules:GetCrewShipManager()) then
        local crewShip = gGameRules:GetCrewShipManager():GetShipForZone(entity:GetZone())
        if not IsNull(crewShip) then
            crewShip:GetAvatarOwner():InventoryControl():RemoveUpgrade(Game.AVATAR_STAMINA_RECHARGE_RATE, Game.ADD, -1.5, nil, nil, Engine.DT_ANY, Symbol("LIFE_SUPPORT"))
        end
    end
end

local function GetProjectionPositionAndRotation(fissure)
    local raycastStartPosition = fissure:GetPosition()
    local raycastEndPosition = raycastStartPosition + RotateVector(Vector(0, 0, 100), mSpawner:GetRotation())

    local hitEntity
    local hitPoint = Vector()
    local hitAngle = Rotation()
    local hit = gRegion:RaycastWithHitAngle(raycastStartPosition, raycastEndPosition, nil, nil, hitEntity, hitPoint, hitAngle, true)

    if mDebugDrawProjectionPosition then
        gRegion:VisAddArrow(raycastStartPosition, raycastEndPosition, Color(200,100,0), mDrawTime)
    end

    if not hit then
        print("Hull fissure: failed to find suitable surface for fissure. " .. fissure:GetFullName())
        return
    end

    local surfaceNormal = AngleToDirection(hitAngle)
    local projectorPosition = hitPoint + surfaceNormal
    
    if mDebugDrawProjectionPosition then
        gRegion:VisAddSphere(hitPoint, 0.1, Color(200,0,0), mDrawTime) 
        gRegion:VisAddSphere(projectorPosition, 0.2, Color(0,0, 100, 1), mDrawTime)
    end
    
    local projectorRotation = hitAngle
    projectorRotation.pitch = -projectorRotation.pitch
    projectorRotation.heading = projectorRotation.heading + 180
    
    if mDebugDrawProjectionPosition then
        gRegion:VisAddArrow(projectorPosition, projectorPosition + RotateVector(Vector(0,0,1), hitAngle), Color(100,0,0), mDrawTime)
    end
    
    return projectorPosition, projectorRotation
end

local function FullyRepaired(fissure)
    fissure:Destroy()    
end

local function UpdateRepairProgress()
    --Check health every so often (perhaps increase time depending on distance?)
    --Remove the first x% of target points from the fissure depending on health
end

local function InitFissure()
    local splinePos, splineRot = GetProjectionPositionAndRotation(mSelf)
    if IsNull(splinePos) then
        print("Hull fissure: failed to find a position for projector. Likely too far from a surface. " .. mSelf:GetFullName())
        return false
    end
    
    local splineFacing = AngleToDirection(splineRot)
    local splineEntity = gRegion:CreateEntity(splineType, splinePos, splineRot, mSelf, mSelf)
    
    local failureProjectedPts = {}
    local oldSeed = GetSeed()

    mSeed = UnsignedToRandSeed(SRandom(1, 999999))
    SetSeed(mSeed)
    
    local repairSplineBounds = Vector(1, 1, 1)
    local children = mSelf:GetAutoSimChildrenArray()
    if not IsNull(children) then
        for i=1,#children do
            if children[i].mType:IsA(gDecalProjectorType) and not IsNull(children[i].mInstance) then
                local decalProjector = children[i].mInstance
                repairSplineBounds = decalProjector:GetBounds()
            end
        end
    end

    local splineBoundsMin = Vector()
    local splineBoundsMax = Vector()    
    local splineOk, numPoints = MINING.GetSplineControlPointsLine(splinePos, splineRot, repairSplineBounds, false, splineEntity, failureProjectedPts, splineBoundsMin, splineBoundsMax)
    SetSeed(oldSeed)
    if not splineOk then
        print("Hull fissure: failed to generate a repair spline for " .. mSelf:GetFullName() .. "!")
        return false
    end
    
    local pts = {}
    for i=1,#failureProjectedPts do
        table.insert(pts, failureProjectedPts[i])
    end
    table.insert(pts, failureProjectedPts[1])
    
    splineEntity:SetMaterialParam(Symbol("AlphaAtten"), 0)
    splineEntity:InitFromPoints(pts)

    local samplePoints = splineEntity:SamplePoints(math.ceil(mNumTargetSamples / numPoints))
    
    mSelf:SetHealth(#samplePoints)
    mHealthForFullRepair = math.floor(#samplePoints * (1 - repairPercentage))
    
    local sparkSpacing = math.floor(#samplePoints/4)
    for i = 1, #samplePoints do
        -- sampled points are in spline space, so need to convert to world. also project to plane of decal projector. could consider doing this with a spline whose control points haven't been cast onto the rock (would that actually be equivalent though?)
        local position = RotateVector(samplePoints[i], splineRot) + splinePos
        if mDebugDrawSpline then
            gRegion:VisAddSphere(position, 0.05, Color(255,0,0), 30)            
        end
        
        local targetPointDeco = gRegion:CreateEntity(splineTargetPoint, ZERO_VECTOR, ZERO_ROTATION, mSelf, mSelf)
        local pointOffset = RotateVector(position - mSelf:GetPosition(), InverseRotation(splineRot))
        mSelf:AttachEntity(targetPointDeco, EMPTY_SYMBOL, pointOffset, ZERO_ROTATION)
        
        if (i - 1) % sparkSpacing == 0 then
            gRegion:CreateEntity(splineIntermitentSparks, position, InverseRotation(splineRot), targetPointDeco, targetPointDeco)
        end
    end

    return true
end

function OnFissureCreated(entity)
    if gRegion:IsMaster() then
        mSelf = entity
        if not IsNull(mSelf) then
            ObjectPortHandler(mSelf, "OnDestroyed")
        end
        
        local crewShipMgr
        while IsNull(crewShipMgr) do
            if not IsNull(gGameRules) then
                crewShipMgr = gGameRules:GetCrewShipManager()
            end
            if IsNull(crewShipMgr) then
                Sleep(0)
            end
        end
        local crewShip = crewShipMgr:GetShipForZone(entity:GetZone())
        if not IsNull(crewShip) then
            crewShip:GetAvatarOwner():InventoryControl():AddUpgrade(Game.AVATAR_STAMINA_RECHARGE_RATE, Game.ADD, -1.5, nil, nil, Engine.DT_ANY, Symbol("LIFE_SUPPORT"))
        end

        mSpawner = mSelf:GetCreator()
        if not InitFissure() then
            mSelf:Destroy()
            return
        end
        
        local count = 0
        while mSelf:GetHealth() > mHealthForFullRepair do
            Sleep(0.5)
        end

        FullyRepaired(mSelf)
    end    
end
