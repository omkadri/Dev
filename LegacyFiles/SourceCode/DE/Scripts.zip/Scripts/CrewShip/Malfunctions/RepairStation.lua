itemType = Type()
recallItemType = Type()

local function HasRecallItem(inventory)
    if not IsNull(inventory) then
        for i = 1, inventory:GetConsumablesCountForPage(Lotus_Game.CP_GENERAL) do
            local item = inventory:GetConsumableItem(i-1, Lotus_Game.CP_GENERAL)
            if not IsNull(item) and item:IsA(recallItemType) and inventory:GetConsumableItemCount(i-1, Lotus_Game.CP_GENERAL) > 0 then
                return true
            end
        end            
    end    
    return false
end

function GrabItem(trigger, avatar)
    if gRegion:IsMaster() and not IsNull(avatar) then
        local inventory = avatar:InventoryControl()
        if not IsNull(inventory) then
            local weaponInHand = inventory:GetWeaponInHand(Engine.MAIN_HAND)
            if not IsNull(weaponInHand) and weaponInHand:IsA(itemType) then
                avatar:RemoveItem(itemType)
            else
                avatar:GiveItem(itemType, true)
            end

            if not HasRecallItem(inventory) then
                avatar:GiveItem(recallItemType, true)
            end
        end
    end
end

function NeedsItem(trigger, avatar)
    if not IsNull(avatar) then
        local inventory = avatar:InventoryControl()
        if not IsNull(inventory) then
            for i = 1, inventory:GetConsumablesCountForPage(Lotus_Game.CP_GENERAL) do
                local item = inventory:GetConsumableItem(i-1, Lotus_Game.CP_GENERAL)
                if not IsNull(item) and item:IsA(itemType) then
                    return false
                end
            end
            
            local weaponInHand = inventory:GetWeaponInHand(Engine.MAIN_HAND)
            
            return IsNull(weaponInHand) or (not weaponInHand:IsA(itemType))
        end
    end
    
    return false
end