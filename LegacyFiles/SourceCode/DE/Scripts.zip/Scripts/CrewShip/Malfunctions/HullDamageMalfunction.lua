local UTIL = require "EE.Interface.Utilities"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"

local mDebugDraw = false
local mDebugDrawTime = 10

local mShipAvatar = nil
local mShip = nil
local mSelf = nil
local mSpawner = nil
local mInstance = -1

function OnDestroyed(entity)   
    if gRegion:IsMaster() and not IsNull(gGameRules:GetCrewShipManager()) then
--~         local crewShip = gGameRules:GetCrewShipManager():GetShipForZone(entity:GetZone())
--~         if not IsNull(crewShip) then
--~             crewShip:GetAvatarOwner():InventoryControl():RemoveUpgrade(Game.AVATAR_STAMINA_RECHARGE_RATE, Game.ADD, -1.5, nil, nil, Engine.DT_ANY, Symbol("LIFE_SUPPORT"))
--~         end
    end
end

function OnCreated(entity)
    if gRegion:IsMaster() then
        mSelf = entity
        mSpawner = mSelf:GetCreator()
        mInstance = mSpawner:GetInstance()
        
        if not IsNull(mSelf) then
            ObjectPortHandler(mSelf, "OnDestroyed")
        end
        
--~         if not IsNull(gGameRules:GetCrewShipManager()) then
--~             Sleep(0)
--~             mShip = gGameRules:GetCrewShipManager():GetShipForZone(entity:GetZone())
--~             
--~             if not IsNull(mShip) then
--~                 mShipAvatar = mShip:GetAvatarOwner()
--~                 mShipAvatar:InventoryControl():AddUpgrade(Game.AVATAR_STAMINA_RECHARGE_RATE, Game.ADD, -1.5, nil, nil, Engine.DT_ANY, Symbol("LIFE_SUPPORT"))
--~             end
--~         end
    end
end