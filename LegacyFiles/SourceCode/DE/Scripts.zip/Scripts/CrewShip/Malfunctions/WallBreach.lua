splineType = Type()
projectorTag = Symbol()
splineBank = 0
transmissionSet = Resource()
breachReminderMinDelay = 20
breachReminderMaxDelay = 60

local MINING = require "Lotus.Scripts.Eidolon.MiningUtil"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"

local mSelf = nil
local mDebugDrawSpline = false
local mDrawTime = 4
local mSeed = UnsignedToRandSeed(0)
local mNumTargetSamples = 100
local mRuptureTypeName = "/Lotus/Types/Game/CrewShip/Malfunctions/WallBreach"
local mIsRupture = false

local mMaxHealthPercentageRemovedPerBreach = -0.3
local mHealthBoostOfMaxHealthOnRepair = 0.2

local function GetPlayersOnCrewShip()
    local playerAvatars = gRegion:GetHumanPlayerAvatars()
    local playersInShip = {}
    for _, playerAv in pairs(playerAvatars) do
        local crewShip = playerAv:InventoryControl():GetOnBoardShip() 
        if not IsNull(crewShip) and crewShip:IsPlayerShip() then
            table.insert(playersInShip, playerAv)
        end
    end

    return playersInShip
end

local function PlayTransmissionForPlayers(playerAvatars, transmissionSet, name)
    for _, playerAv in pairs(playerAvatars) do
        DIALOG.PlayLocalTransmission(transmissionSet, name, 0, playerAv)
    end
end

local function CreateNewWallBreachInfo()
    local info = {}
    info.points = {}
    info.repairedPoints = {}
    info.projector = nil
    info.boundsMin = Vector()
    info.boundsMax = Vector()
    info.emergencyFallback = false
    info.nanoDecos = {}
    
    return info
end

local function GetDecalProjector()
    local waitTimer = 0
    local waitTime = 0.05
    local maxWait = 1
    local projector = nil
    while IsNull(projector) do
        projector = mSelf:GetAttachment(gDynamicDecalProjectorType)
        if waitTimer > maxWait then
            print("ERROR: Waiting too long for wall breach projector (" .. waitTimer .."s)")
            return nil
        end
        waitTimer = waitTimer + waitTime
        Sleep(waitTime)
    end
    
    return projector
end

local function AdjustMaxHealth(removeHealth)
    if gRegion:IsMaster() then
        local crewShipManager = gGameRules:GetCrewShipManager()
        if not IsNull(crewShipManager) then
            local shipAvatar = nil
            local railjackInventoryControl = nil
            if not IsNull(crewShipManager) then
                local ship = crewShipManager:GetPlayerShip()
                if not IsNull(ship) then
                    shipAvatar = ship:GetAvatarOwner()
                    if not IsNull(shipAvatar) then
                        railjackInventoryControl = shipAvatar:InventoryControl()
                    end
                end
            end

            if not IsNull(railjackInventoryControl) then        
                if removeHealth then
                    railjackInventoryControl:AddUpgrade(Game.AVATAR_HEALTH_MAX, Game.STACKING_MULTIPLY, mMaxHealthPercentageRemovedPerBreach)
                else
                    railjackInventoryControl:RemoveUpgrade(Game.AVATAR_HEALTH_MAX, Game.STACKING_MULTIPLY, mMaxHealthPercentageRemovedPerBreach)
                    shipAvatar:SetHealth(shipAvatar:GetHealth() + (shipAvatar:GetMaxHealth() * mHealthBoostOfMaxHealthOnRepair))
                end
            end
        end
    end
end

function OnDestroyed(entity)
    if entity:GetType():GetFullName() == mRuptureTypeName then
        AdjustMaxHealth(false)

        if not IsNull(_T.Malfunctions.WallBreachCount) and not gGameRules:IsHubLevel() then
            _T.Malfunctions.WallBreachCount = _T.Malfunctions.WallBreachCount -1
            if _T.Malfunctions.WallBreachCount == 0 then
                PlayTransmissionForPlayers(GetPlayersOnCrewShip(), transmissionSet, Symbol("HullRuptureRepaired"))
            end
        end
    end
    
    if not IsNull(_T.WallBreaches) then
        for breach, info in pairs(_T.WallBreaches) do
            if IsNull(breach) or breach == entity then
                if not IsNull(info.projector) then
                     info.projector:FirePort("Hide")
                end
                for i, temp in ipairs(info.nanoDecos) do
                    if not IsNull(temp) then
                        temp:PlayTriggeredFade()
                    end
                end
                _T.WallBreaches[breach] = nil
            end
        end
    end
end

local function ExtendBounds(minBounds, maxBounds)
    -- extend spline bounding box a bit in every direction
    local splineBoundsExtension = 0.25
    minBounds.x = minBounds.x - splineBoundsExtension
    minBounds.y = minBounds.y - splineBoundsExtension
    minBounds.z = minBounds.z - splineBoundsExtension
    maxBounds.x = maxBounds.x + splineBoundsExtension
    maxBounds.y = maxBounds.y + splineBoundsExtension
    maxBounds.z = maxBounds.z + splineBoundsExtension
    
    return minBounds, maxBounds
end

local function InitWallBreach()
    if IsNull( _T.WallBreaches) then
        _T.WallBreaches = {}
    end
    
    local newBreachInfo = CreateNewWallBreachInfo()
    
    local decalProjector = GetDecalProjector()
    if mIsRupture then
        decalProjector:FirePort("Show")
    end
    
    newBreachInfo.projector = decalProjector
    
    local doFallback = IsNull(decalProjector)
    if not doFallback then
        local repairSplineBounds = decalProjector:GetBounds()
        local splinePos, splineRot = decalProjector:GetPosition(), decalProjector:GetRotation()
        splineRot.bank = splineRot.bank + splineBank
        local splineEntity = gRegion:CreateEntity(splineType, splinePos, splineRot, mSelf, mSelf)
        
        local failureProjectedPts = {}
        local oldSeed = GetSeed()

        mSeed = UnsignedToRandSeed(SRandom(1, 999999))
        SetSeed(mSeed)

        local lineConstruction =  {
            spacing = 0.2,
            horizontalDeviation = 0,
            verticalDeviation = 0,
            noise = true,
            staticOnlyRaycast = false}
            
        local splineBoundsMin = Vector()
        local splineBoundsMax = Vector()
        local splineOk, numPoints = MINING.GetSplineControlPointsLine(lineConstruction, splinePos, splineRot, repairSplineBounds, false, splineEntity, failureProjectedPts, splineBoundsMin, splineBoundsMax)
        SetSeed(oldSeed)
        if not splineOk then
            print("WARNING: WallBreach failed to generate a repair spline for " .. mSelf:GetFullName() .. " with projector " .. decalProjector:GetFullName() .. " at " .. tostring(decalProjector:GetPosition()))
            doFallback = true
        else
            splineBoundsMin, splineBoundsMax = ExtendBounds(splineBoundsMin, splineBoundsMax)
            newBreachInfo.boundsMin = splineBoundsMin
            newBreachInfo.boundsMax = splineBoundsMax
            
            local pts = {}
            for i=1,#failureProjectedPts do
                table.insert(pts, failureProjectedPts[i])
            end
            table.insert(pts, failureProjectedPts[1])
            
            splineEntity:SetMaterialParam(Symbol("AlphaAtten"), 1)
            splineEntity:InitFromPoints(pts)
            
            local samplePoints = splineEntity:SamplePoints(math.ceil(mNumTargetSamples / numPoints))
            for i = 1, #samplePoints do
                -- sampled points are in spline space, so need to convert to world. also project to plane of decal projector. could consider doing this with a spline whose control points haven't been cast onto the rock (would that actually be equivalent though?)
                local position = RotateVector(samplePoints[i], splineRot) + splinePos
                table.insert(newBreachInfo.points, position)
                if mDebugDrawSpline then
                    gRegion:VisAddSphere(position, 0.05, Color(255,0,0), mDrawTime)            
                end
            end
        end
    end
    
    if doFallback then
        print("WARNING WallBreach: Falling back to single point repair.")
        newBreachInfo.boundsMin = mSelf:GetPosition() - Vector(1, 1, 1)
        newBreachInfo.boundsMax =  mSelf:GetPosition() + Vector(1, 1, 1)
        table.insert(newBreachInfo.points, mSelf:GetPosition()) 
    end
    
    --print("AF; Inserting " .. mSelf:GetFullName() .. " into wallbreaches. #info.Points = " .. #newBreachInfo.points)
    _T.WallBreaches[mSelf] = newBreachInfo
end

function RuptureTransmissions(entity)
    if IsNull(_T.Malfunctions) then
        _T.Malfunctions = {}
        _T.Malfunctions.TransmissionTimers = {}
    end
    if IsNull(_T.Malfunctions.TransmissionTimers) then
        _T.Malfunctions.TransmissionTimers = {}
    end
    if IsNull(_T.Malfunctions.WallBreachCount) or _T.Malfunctions.WallBreachCount == 1 then
        PlayTransmissionForPlayers(GetPlayersOnCrewShip(), transmissionSet, Symbol("HullRupture"))
    end
    local reminderDelay = breachReminderMinDelay + (breachReminderMaxDelay * FRand())
    if IsNull(_T.Malfunctions.TransmissionTimers.ruptureReminderDueNext) then
        _T.Malfunctions.TransmissionTimers.ruptureReminderDueNext = Time() + reminderDelay
    end
    while not IsNull(entity) do
        Sleep(reminderDelay)

        if Time() >= _T.Malfunctions.TransmissionTimers.ruptureReminderDueNext then
            PlayTransmissionForPlayers(GetPlayersOnCrewShip(), transmissionSet, Symbol("HullRuptureReminder"))
            reminderDelay = breachReminderMinDelay + (breachReminderMaxDelay * FRand())
            _T.Malfunctions.TransmissionTimers.ruptureReminderDueNext = Time() + reminderDelay
        end
    end
end

local function PlaceBreachOnWall()
    local hitPoint = Vector()
    local pos = mSelf:GetPosition()
    local raycastIgnoreTypes = {gBaseAvatarType, gPickUpType, gRagdollType, gHitProxyType}
    local targetDir = AngleToDirection(mSelf:GetRotation())
    local startPos = mSelf:GetPosition() - (targetDir * 0.01)
    local endPos = mSelf:GetPosition() + (targetDir * 2)
	if mDebugDrawSpline then
	    gRegion:VisAddArrow(startPos, endPos, Color(0, 0, 255), 30)
	end
    local hit = gRegion:RaycastIgnoreTypes(startPos, endPos, raycastIgnoreTypes, nil, hitPoint)
    if hit then
        mSelf:SetPosition(hitPoint)
    else
        print("WARNING: WallBreach failed to place itself on wall")
    end
end

function OnCreated(entity)
    mSelf = entity
    if not IsNull(mSelf) then
        ObjectPortHandler(mSelf, "OnDestroyed")
    end

    mIsRupture = mSelf:GetType():GetFullName() == mRuptureTypeName

    if mIsRupture then
        if IsNull(_T.Malfunctions) then
            _T.Malfunctions = {}
        end

        if IsNull(_T.Malfunctions.WallBreachCount) then
            _T.Malfunctions.WallBreachCount = 0
        end

        _T.Malfunctions.WallBreachCount = _T.Malfunctions.WallBreachCount + 1
    end

    if gRegion:IsMaster() then
        PlaceBreachOnWall()
        entity:ScriptRunChildScript(Symbol("RuptureTransmissions"), false)
    end
    
    if mIsRupture then
        local spawner = mSelf:GetCreator()
        if not IsNull(spawner) then
            local limit = math.floor(math.abs(1.0 / mMaxHealthPercentageRemovedPerBreach))
            spawner:SetLimit(limit)
        end
        AdjustMaxHealth(true)
    end
    
    InitWallBreach()

    if not IsNull(_T.RandomBreachRepairSubroutine) then
        _T.RandomBreachRepairSubroutine(entity)
    end
end
