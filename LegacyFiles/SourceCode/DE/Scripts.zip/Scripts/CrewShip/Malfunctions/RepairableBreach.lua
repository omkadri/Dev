repairablePoint = Type()

local mDebugDraw = false
local mDebugDrawTime = 20

local function Update()
    local delta = DeltaTime()
end

local function FindWallPlacement(startPosition, endPosition)
    local hitEntity
    local hitPoint = Vector()
    local raycastIgnoreTypes = {repairablePoint}
    local hit = gRegion:RaycastIgnoreTypes(startPosition, endPosition, raycastIgnoreTypes, hitEntity, hitPoint)
    if mDebugDraw then
        gRegion:VisAddSphere(startPosition, 0.05, Color(255, 0, 0), mDebugDrawTime)
        gRegion:VisAddLine(startPosition, endPosition, Color(190, 0, 190), mDebugDrawTime)
        gRegion:VisAddSphere(hitPoint, 0.1, Color(0, 255, 0), mDebugDrawTime)  
    end
    return hit, hitPoint
end

local function PlaceRepairPoint(entity, start, endpos)
    local hit, hitPoint = FindWallPlacement(start, endpos)
    if hit then
        entity:Attach(repairablePoint, EMPTY_SYMBOL, hitPoint - entity:GetPosition(), entity:GetRotation(), entity)
    else
        print("RepairableBreach; Could not find a place for the breach point")
    end
end

local function PlaceRepairPoints(entity)
    local startPosition = entity:GetPosition()
    local endPosition = startPosition + (RotateVector(Vector(0, 0, 1), entity:GetRotation()))
    
    local baseDistance = 0.2
    local maxAdditionalDistance = 0.6
    local count = 4
    local delta = (math.pi * 2) / count
    local maxAngleOffset = 0.25

    for i=0, (count - 1) do
        local a = delta + ((maxAngleOffset * FRand() * 2) - maxAngleOffset)
        local c = math.cos(i * a)
        local s = math.sin(i * a)
        local offset = Vector(c, s, 0) * (baseDistance + (maxAdditionalDistance * FRand()))
        
        local rotatedOffset = RotateVector(offset, entity:GetRotation())
        PlaceRepairPoint(entity, startPosition + rotatedOffset, endPosition + rotatedOffset)
    end
end

function OnSpawned(entity)
    PlaceRepairPoints(entity)
    
    while #entity:GetAllAttachments(repairablePoint) > 0 do
        Sleep(0)
        Update()
    end

    entity:Destroy()
end