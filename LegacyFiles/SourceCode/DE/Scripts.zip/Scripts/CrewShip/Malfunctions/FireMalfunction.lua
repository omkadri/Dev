fireSegmentType = Type()
fireSegmentDamagedFX = Resource()
numOfInitialSegments = 6
maxSegments = 6
minSegmentPlacementRadius = 0.4

fireWarningTransmissionSet = Resource()
fireWarningTransmissionTag = Symbol()

local mDebugDraw = false
local mDebugDrawTime = 20

local mShipAvatar = nil
local mShip = nil
local mSelf = nil
local mCreatingInitialSegments = true
local mGrowthTimer = 0
local mTimeBeforeDamaging = 30
local mDamagePerSecond = 2.0
local mAcumulatedDamage = 0
local VECTOR_UP = Vector(0, 1, 0)
local mHealPctOnRepair = 0.15

local mTimeAlive = 0
local chanceConsumed = false

local mAiDir = nil

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"

transmissionSet = Resource()
fireReminderMinDelay = 20
fireReminderMaxDelay = 60

local function GetPlayersOnCrewShip()
    local playerAvatars = gRegion:GetHumanPlayerAvatars()
    local playersInShip = {}
    for _, playerAv in pairs(playerAvatars) do
        local crewShip = playerAv:InventoryControl():GetOnBoardShip() 
        if not IsNull(crewShip) and crewShip:IsPlayerShip() then
            table.insert(playersInShip, playerAv)
        end
    end

    return playersInShip
end

local function PlayTransmissionForPlayers(playerAvatars, transmissionSet, name)
    for _, playerAv in pairs(playerAvatars) do
        DIALOG.PlayLocalTransmission(transmissionSet, name, 0, playerAv)
    end
end

local function FindSegmentPlacement(startPosition, endPosition)
    local hitPoint = Vector()
    local raycastIgnoreTypes = {fireSegmentType}
    local hit = gRegion:RaycastIgnoreTypes(startPosition, endPosition, raycastIgnoreTypes, nil, hitPoint)
    if mDebugDraw then
        gRegion:VisAddSphere(startPosition, 0.3, Color(255, 0, 0), mDebugDrawTime)
        gRegion:VisAddLine(startPosition, endPosition, Color(0, 0, 255), mDebugDrawTime)
        gRegion:VisAddSphere(hitPoint, 0.1, Color(0, 255, 0), mDebugDrawTime)  
    end
    return hit, hitPoint
end

local function AttachSegment(endPosition)
    mSelf:Attach(fireSegmentType, EMPTY_SYMBOL, endPosition - mSelf:GetPosition(), ZERO_ROTATION, mSelf)
end

local function AttachSegments(count)
    local basePosition = mSelf:GetPosition()
    local angleOffsetPercent = 0.3
    local radiusOffsetPercent = 0.7
    local raycastExtensionLength = 1.5
    local delta = (math.pi * 2) / count  
    for i=1,count do
        local a =  (i -1) * (delta + (delta * (angleOffsetPercent * FRand())))
        if count == 1 then
            a =  delta * FRand()
        end

        local c = math.cos(a)
        local s = math.sin(a)    
        local pointOnCircle = Vector(c, 0, s) * (minSegmentPlacementRadius + (minSegmentPlacementRadius * radiusOffsetPercent * FRand()))
        local targetPosition = basePosition + pointOnCircle
        
        local startPointAboveBase = basePosition + VECTOR_UP
        local raycastDir = targetPosition - startPointAboveBase
        Normalize(raycastDir)
        targetPosition = targetPosition + (raycastDir * raycastExtensionLength)
        local found, position = FindSegmentPlacement(startPointAboveBase, targetPosition)
        if found then
            AttachSegment(position)
        end
    end
end

local function PlaceBaseSegment()
    AttachSegment(mSelf:GetPosition())
end

local function Update()
    if not IsNull(mSelf) then
        if not IsNull(mShipAvatar) and mTimeAlive > mTimeBeforeDamaging then
            mDamagePerSecond = 2.0
            local scale = 1
            if not IsNull(mAiDir) then
                
                local level = mAiDir:GetSpaceMaxEnemyLevel()
                if not IsNull(level) then
                    scale = math.max(1, level/5)
                end
            end
            mDamagePerSecond = mDamagePerSecond * scale
            mAcumulatedDamage = mAcumulatedDamage + (DeltaTime() * mDamagePerSecond)       
            if mAcumulatedDamage > mDamagePerSecond then
                local damage = math.floor(mAcumulatedDamage)
                mAcumulatedDamage = mAcumulatedDamage - damage
                mShipAvatar:Damage(damage, Engine.DT_FIRE)
            end
        end
        if not IsNull(_T.RandomFireExtiguishSubroutine) and not chanceConsumed then
            chanceConsumed = _T.RandomFireExtiguishSubroutine(mSelf, mTimeAlive, chanceConsumed)
        end
        mTimeAlive = mTimeAlive + DeltaTime()
    end
end

function FireMalfunctionTransmissions(entity)
    if IsNull(_T.Malfunctions) then
        _T.Malfunctions = {}
        _T.Malfunctions.TransmissionTimers = {}
    end
    if IsNull(_T.Malfunctions.TransmissionTimers) then
        _T.Malfunctions.TransmissionTimers = {}
    end
    if IsNull(_T.Malfunctions.FireMalfunctionCount) or _T.Malfunctions.FireMalfunctionCount == 1 then
        PlayTransmissionForPlayers(GetPlayersOnCrewShip(), transmissionSet, Symbol("FiresStarted"))
    end

    local reminderDelay = fireReminderMinDelay + (fireReminderMaxDelay * FRand())
    if IsNull(_T.Malfunctions.TransmissionTimers.fireReminderDueNext) then
        _T.Malfunctions.TransmissionTimers.fireReminderDueNext = Time() + reminderDelay
    end
    while not IsNull(entity) do
        Sleep(reminderDelay)

        if Time() >= _T.Malfunctions.TransmissionTimers.fireReminderDueNext then
            PlayTransmissionForPlayers(GetPlayersOnCrewShip(), transmissionSet, Symbol("FiresOngoing"))
            reminderDelay = fireReminderMinDelay + (fireReminderMaxDelay * FRand())
            _T.Malfunctions.TransmissionTimers.fireReminderDueNext = Time() + reminderDelay
        end
    end
end

function OnDestroyed(entity)
    if not IsNull(_T.Malfunctions.FireMalfunctionCount) and not gGameRules:IsHubLevel() then
        _T.Malfunctions.FireMalfunctionCount = _T.Malfunctions.FireMalfunctionCount - 1
        if _T.Malfunctions.FireMalfunctionCount == 0 then
            PlayTransmissionForPlayers(GetPlayersOnCrewShip(), transmissionSet, Symbol("FiresCleared"))
        end
    end

    local crewShipManager = gGameRules:GetCrewShipManager()
    local shipAvatar = nil
    if not IsNull(crewShipManager) then
        local ship = crewShipManager:GetPlayerShip()
        if not IsNull(ship) then
            shipAvatar = ship:GetAvatarOwner()
        end
    end

    if not IsNull(shipAvatar) then
        local minHealthRestore = 0.15
        local repairHealthBoost = shipAvatar:GetMaxHealth() * minHealthRestore
        shipAvatar:SetHealth(shipAvatar:GetHealth() + repairHealthBoost)
    end
end

function OnCreated(entity)
    if not gRegion:IsMaster() then
        return
    end

    while IsNull(gGameRules) do
        Sleep(0)
    end

    mSelf = entity
        
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()

    if IsNull(_T.Malfunctions) then
        _T.Malfunctions = {}
    end
        
    if IsNull(_T.Malfunctions.FireMalfunctionCount) then
        _T.Malfunctions.FireMalfunctionCount = 0
    end
    _T.Malfunctions.FireMalfunctionCount = _T.Malfunctions.FireMalfunctionCount + 1
    entity:ScriptRunChildScript(Symbol("FireMalfunctionTransmissions"), false)
        
    local crewShipManager = gGameRules:GetCrewShipManager()
    local shipAvatar = nil
    if not IsNull(crewShipManager) then
        local ship = crewShipManager:GetPlayerShip()
        if not IsNull(ship) then
            mShipAvatar = ship:GetAvatarOwner()
        end
    end
        
    PlaceBaseSegment()

    if not IsNull(mSelf) then
        ObjectPortHandler(mSelf, "OnDestroyed")
    end

    local placedSegments = 1
    while not IsNull(mSelf) do
        Sleep(0)
        Update()
            
        if placedSegments < maxSegments then
            AttachSegments(1)
            placedSegments = placedSegments + 1
        end
    end
end