function DamageEngine()
--~     if gRegion:IsMaster() and not IsNull(gGameRules:GetCrewShipManager()) then
--~         local crewShip = gGameRules:GetCrewShipManager():GetPlayerShip()
--~         if not IsNull(crewShip) then
--~             local crewShipInventoryController = crewShip:GetAvatarOwner():InventoryControl()
--~             crewShipInventoryController:AddUpgrade(Game.AVATAR_MOVEMENT_SPEED, Game.STACKING_MULTIPLY, 0, nil, nil, Engine.DT_ANY)
--~         end
--~     end    
end

function RepairEngine()
--~     if gRegion:IsMaster() and not IsNull(gGameRules:GetCrewShipManager()) then
--~         local crewShip = gGameRules:GetCrewShipManager():GetPlayerShip()
--~         if not IsNull(crewShip) then
--~             local crewShipInventoryController = crewShip:GetAvatarOwner():InventoryControl()
--~             crewShipInventoryController:RemoveUpgrade(Game.AVATAR_MOVEMENT_SPEED, Game.STACKING_MULTIPLY, 0, nil, nil, Engine.DT_ANY)
--~         end
--~     end 
end