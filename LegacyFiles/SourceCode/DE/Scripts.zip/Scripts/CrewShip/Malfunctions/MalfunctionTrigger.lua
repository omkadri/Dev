targetSpawnerTag = Symbol()
malfunctionSpawnerType = Type()
triggerableSpawners = {Instance()}
local secondsBetweenFires = Range(5, 30)
function OnStateChanged(deco, initialCreation)

    if initialCreation then
        return
    end

    if not gRegion:IsMaster() then
        return
    end

    if not _T.RJFireThrottle then
        _T.RJFireThrottle = Time() + 1
    end
    local t = Time()
    if _T.RJFireThrottle <= t then
        local targetSpawner = nil
        if targetSpawnerTag:IsValid() then
            targetSpawner = gRegion:FindNearestTagged(targetSpawnerTag, deco:GetPosition())
        elseif #triggerableSpawners <= 0 then
            local searchRadius = 15
            targetSpawner = gRegion:FindNearest(malfunctionSpawnerType, deco:GetPosition(), searchRadius)
        end
        _T.RJFireThrottle = t + secondsBetweenFires:Rand()
        if not IsNull(targetSpawner) then
            targetSpawner:SpawnNear(deco:GetPosition())
        end
            
        for i, spawner in ipairs(triggerableSpawners) do
            if not IsNull(spawner) then
                spawner:SpawnNear(deco:GetPosition())
            end
        end        
    end
end