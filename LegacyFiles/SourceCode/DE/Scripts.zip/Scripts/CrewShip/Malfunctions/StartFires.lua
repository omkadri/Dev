spawners = {Instance()}

local function GetSpawnCount()
    return (1 + RandomInt(1, 2))
end

local function GetBatchDelay()
    return (3 + (7 * FRand()))
end

function SpawnFires()
    if gRegion:IsMaster() then
        local batchDelay = GetBatchDelay()
        local index = 1
        local spawnCount = GetSpawnCount()
        
        while spawnCount > 0 and index < 20 do
            if not IsNull(spawners[index]) then
                spawners[index]:FirePort("Spawn")
                spawnCount = spawnCount - 1
                if spawnCount == 0 then
                    Sleep(batchDelay)
                    batchDelay = GetBatchDelay()
                    spawnCount = GetSpawnCount()
                end            
            end
            index = index + 1
        end
    end
end