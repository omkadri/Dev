local mSelf = nil
local mDoorHintTag = Symbol("StaticDoorHint")

function OnDestroyed(entity)
    local doorHint = gRegion:FindNearestTagged(mDoorHintTag, mSelf:GetPosition())
    if not IsNull(doorHint) then    
        doorHint:FirePort("Unlock")
    end
end

function OnCreated(entity)
    if not gRegion:IsMaster() then
        return
    end

    while IsNull(gGameRules) do
        Sleep(0)
    end

    mSelf = entity
        
    if not IsNull(mSelf) then
        ObjectPortHandler(mSelf, "OnDestroyed")
    end
        
    local doorHint = gRegion:FindNearestTagged(mDoorHintTag, mSelf:GetPosition())
    if not IsNull(doorHint) then
        doorHint:FirePort("Lock")
    end
end