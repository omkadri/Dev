local mSelf = nil

local mShieldStackingMultDebuff = -0.1

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"

transmissionSet = Resource()
electricalReminderMinDelay = 20
electricalReminderMaxDelay = 60

local function GetPlayersOnCrewShip()
    local playerAvatars = gRegion:GetHumanPlayerAvatars()
    local playersInShip = {}
    for _, playerAv in pairs(playerAvatars) do
        local crewShip = playerAv:InventoryControl():GetOnBoardShip() 
        if not IsNull(crewShip) and crewShip:IsPlayerShip() then
            table.insert(playersInShip, playerAv)
        end
    end

    return playersInShip
end

local function PlayTransmissionForPlayers(playerAvatars, transmissionSet, name)
    for _, playerAv in pairs(playerAvatars) do
        DIALOG.PlayLocalTransmission(transmissionSet, name, 0, playerAv)
    end
end

local function GetRailjackInventoryControl()
    local railjackInventoryControl = nil
    local crewShipMgr
    while IsNull(crewShipMgr) do
        if not IsNull(gGameRules) then
            crewShipMgr = gGameRules:GetCrewShipManager()
        end
        if IsNull(crewShipMgr) then
            Sleep(0.1)
        end
    end
    local ship = crewShipMgr:GetPlayerShip()
    if not IsNull(ship) then
        local shipAvatar = ship:GetAvatarOwner()
        if not IsNull(shipAvatar) then  
            return shipAvatar:InventoryControl()
        end
    end
end

function ElectricalMalfunctionTransmissions(entity)
    if IsNull(_T.Malfunctions) then
        _T.Malfunctions = {}
        _T.Malfunctions.TransmissionTimers = {}
    end
    if IsNull(_T.Malfunctions.TransmissionTimers) then
        _T.Malfunctions.TransmissionTimers = {}
    end
    if IsNull(_T.Malfunctions.ElectricalMalfunctionCount) or _T.Malfunctions.ElectricalMalfunctionCount == 1 then
        PlayTransmissionForPlayers(GetPlayersOnCrewShip(), transmissionSet, Symbol("ElectricHazard"))
    end

    local reminderDelay = electricalReminderMinDelay + (electricalReminderMaxDelay * FRand())
    if IsNull(_T.Malfunctions.TransmissionTimers.electricReminderDueNext) then
        _T.Malfunctions.TransmissionTimers.electricReminderDueNext = Time() + reminderDelay
    end
    while not IsNull(entity) do
        Sleep(reminderDelay)

        if Time() >= _T.Malfunctions.TransmissionTimers.electricReminderDueNext then
            PlayTransmissionForPlayers(GetPlayersOnCrewShip(), transmissionSet, Symbol("ElectricHazardReminder"))
            reminderDelay = electricalReminderMinDelay + (electricalReminderMaxDelay * FRand())
            _T.Malfunctions.TransmissionTimers.electricReminderDueNext = Time() + reminderDelay
        end
    end
end

function OnDestroyed(entity)
    local railjackInventoryControl = GetRailjackInventoryControl()
    if not IsNull(railjackInventoryControl) then
        railjackInventoryControl:RemoveUpgrade(Game.AVATAR_SHIELD_MAX, Game.STACKING_MULTIPLY, mShieldStackingMultDebuff)
    end
    
    if not IsNull(_T.Malfunctions.ElectricalMalfunctionCount) and not gGameRules:IsHubLevel() then
        _T.Malfunctions.ElectricalMalfunctionCount = _T.Malfunctions.ElectricalMalfunctionCount - 1
        if _T.Malfunctions.ElectricalMalfunctionCount == 0 then
            PlayTransmissionForPlayers(GetPlayersOnCrewShip(), transmissionSet, Symbol("ElectricHazardRepaired"))
        end
    end
    
    local crewShipManager = gGameRules:GetCrewShipManager()
    local shipAvatar = nil
    if not IsNull(crewShipManager) then
        local ship = crewShipManager:GetPlayerShip()
        if not IsNull(ship) then
            shipAvatar = ship:GetAvatarOwner()
        end
    end

    if not IsNull(shipAvatar) then
        local minHealthRestore = 0.15
        local repairHealthBoost = shipAvatar:GetMaxHealth() * minHealthRestore
        shipAvatar:SetHealth(shipAvatar:GetHealth() + repairHealthBoost)
    end
end

function OnCreated(entity)
    if not gRegion:IsMaster() then
        return
    end

    while IsNull(gGameRules) do
        Sleep(0)
    end

    mSelf = entity

    if IsNull(_T.Malfunctions) then
        _T.Malfunctions = {}
    end
        
    if IsNull(_T.Malfunctions.ElectricalMalfunctionCount) then
        _T.Malfunctions.ElectricalMalfunctionCount = 0
    end
    _T.Malfunctions.ElectricalMalfunctionCount = _T.Malfunctions.ElectricalMalfunctionCount + 1
    entity:ScriptRunChildScript(Symbol("ElectricalMalfunctionTransmissions"), false)
        
    local railjackInventoryControl = GetRailjackInventoryControl()
    if not IsNull(railjackInventoryControl) then
        railjackInventoryControl:AddUpgrade(Game.AVATAR_SHIELD_MAX, Game.STACKING_MULTIPLY, mShieldStackingMultDebuff)
    end
        
    if not IsNull(mSelf) then
        ObjectPortHandler(mSelf, "OnDestroyed")
    end
end