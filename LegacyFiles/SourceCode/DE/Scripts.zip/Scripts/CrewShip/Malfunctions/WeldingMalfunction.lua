weldSpotType = Type()

repairNeededTransmissionSet = Resource()
repairNeededTransmissionTag = Symbol()

maxWeldSpots = 4

local UTIL = require "EE.Interface.Utilities"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"

local mDebugDraw = false
local mDebugDrawWeldSpotPlacement = false
local mDebugDrawTime = 10

local mShipAvatar = nil
local mShip = nil
local mSelf = nil
local mTableIndex = -1
local mWeldSpotTopIndex = 1
local VECTOR_UP = Vector(0, 1, 0)

local mHitEntityPtr = MutableWeakPtr()

local function MaskVector(v, mask)
    return Vector(v.x * mask.x, v.y * mask.y, v.z * mask.z)
end
local masks = {
    Vector(),
    Vector(0,0,1),
    Vector(0,1,0),
    Vector(0,1,1),
    Vector(1,0,0),
    Vector(1,0,1),
    Vector(1,1,0),
    Vector(1,1,1)
}
local vOne = Vector(1,1,1)
local function MakeBoxPoint(v1, v2, n)
    return MaskVector(v1, masks[n]) + MaskVector(v2, (vOne - masks[n]))
end

local adj = {
    {1,2,3,5},
    {6,2,5,8},
    {4,3,2,8},
    {7,3,8,5}
}
local function ActuallyDrawAABox(min, max, color, persistence)
    local points = {}
    for i = 1, 8 do
        points[i] = MakeBoxPoint(min, max, i)
    end
    for i = 1, 4 do
        local s = adj[i][1]
        for j = 2, 4 do
            gRegion:VisAddLine(points[s], points[adj[i][j]], color, persistence)
        end
    end
end

local obstacleTypes = {
    gDecorationType,
    WeakResource("/EE/Types/Engine/Terrain"),
    WeakResource("/EE/Types/Engine/CsgZone"),
    WeakResource("/EE/Types/Effects/Landscape"),
    staticDecoType
}

local function FindWeldSpot(target)
    local boundsMin = target:GetBoundsMin()
    local boundsMax = target:GetBoundsMax()
    local boundsCenter = (boundsMin + boundsMax) / 2

    if mDebugDrawWeldSpotPlacement then
        ActuallyDrawAABox(boundsMin, boundsMax, Color(0,200,0), mDebugDrawTime)
    end
    
    -- pick a spot around the decoration
    local boundsCenter_xz = Vector(boundsCenter.x, boundsMax.y, boundsCenter.z)
    local r = Distance(boundsCenter_xz, boundsMin)
    
    local angle = RandomInt(0,359)
    if mDebugDrawWeldSpotPlacement then
        gRegion:VisAddSphere(boundsCenter_xz, 0.2, Color(0,200,0), mDebugDrawTime)
        gRegion:VisAddArrow(boundsCenter_xz, boundsCenter_xz + Vector(0,0,r), Color(100,0,0), mDebugDrawTime)
    end
    local tryPosition = boundsCenter_xz + RotateVector(Vector(0,0,r), Rotation(angle, 0, 0))
    tryPosition.x = Clamp(tryPosition.x, boundsMin.x, boundsMax.x)
    tryPosition.z = Clamp(tryPosition.z, boundsMin.z, boundsMax.z)
    if mDebugDrawWeldSpotPlacement then
        gRegion:VisAddArrow(boundsCenter_xz, tryPosition, Color(200,100,0), mDebugDrawTime)
    end
    
    -- try to find ground
    local groundEnd = Vector(tryPosition.x, tryPosition.y, tryPosition.z)
    groundEnd.y = tryPosition.y - 50
    local hit = gRegion:Raycast(tryPosition, groundEnd, nil, nil, groundEnd, true)
    if not hit then
        --print('Could not find the ground')
        return
    end
    
    -- ensure the spot is reachable. use nav for this
    if not gRegion:GetNpcMgr():FindNearestNavMeshPos(groundEnd, 2) then
        --print('not gRegion:GetNpcMgr():FindNearestNavMeshPos(groundEnd, 2)')
        return
    end
    
    local heightPos = groundEnd
    heightPos.y = heightPos.y + 0.4 + (FRand() * 1.5)
    if mDebugDrawWeldSpotPlacement then
        gRegion:VisAddArrow(tryPosition, heightPos, Color(0,200,0), mDebugDrawTime)
    end
    
    -- probe the decoration to see if there's a suitable surface on which to create the resource decal and a guide spline
    mHitEntityPtr:Set(nil)
    local hitPoint = Vector()
    local hitRotation = Rotation()
    local toBoundsCenter = boundsCenter - heightPos
    hit = gRegion:RaycastWithHitAngle(heightPos, heightPos + toBoundsCenter, nil, nil, mHitEntityPtr, hitPoint, hitRotation, true)
    if not hit then
        if mDebugDrawWeldSpotPlacement then
            gRegion:VisAddArrow(heightPos, heightPos + toBoundsCenter, Color(200,100,0), mDebugDrawTime) 
        end
        --print('Did not hit target from post ground raycast')
        return
    end
    local hitEntity = mHitEntityPtr:Get()
    if hitEntity ~= target then -- must be able to reach the surface of the rock  
        if mDebugDrawWeldSpotPlacement then
            gRegion:VisAddArrow(heightPos, hitPoint, Color(200,0,0), mDebugDrawTime) 
        end
        --print('hitEntity ~= target')
        return
    end

    if mDebugDrawWeldSpotPlacement then
        gRegion:VisAddArrow(heightPos, hitPoint, Color(0,200,0), mDebugDrawTime) 
    end
    
    --Make sure there is nothing above the point obscuring it
    local hitNormal = AngleToDirection(hitRotation)
    local roofPoint = Vector(hitPoint.x, boundsMax.y, hitPoint.z) + (hitNormal * 0.1)
    local targetPoint = Vector(hitPoint.x, hitPoint.y, hitPoint.z) + (hitNormal * 0.1)
    local obstructionAbove = gRegion:Raycast(targetPoint, roofPoint, nil, nil, roofPoint, true)
    if obstructionAbove then
        if mDebugDrawWeldSpotPlacement then
            gRegion:VisAddArrow(hitPoint, roofPoint, Color(255,0,0), mDebugDrawTime)
        end    
        --print('Obstruction above the target point')
        return
    end    

    -- prevent cases where the rock surface is actually inside another decoration (the raycasts starting inside the other decoration have just gone right through the backfaces) or if the placement is very close to the ground.
    local obstacleSearchRadiusMin = 0.4
    local maxIncreaseWhenFacingGround = 0.3
    local facingGroundFactor = math.max(Dot(hitNormal, Vector(0, -1, 0)), 0)
    if mDebugDrawWeldSpotPlacement and facingGroundFactor > 0 then
        gRegion:VisAddText(hitPoint + hitNormal, Color(200,100,0), facingGroundFactor, 1, mDebugDrawTime)
    end
    
    local obstacleSearchRadius = obstacleSearchRadiusMin + (maxIncreaseWhenFacingGround * facingGroundFactor)
    local others = gRegion:FindRadiusEntities(hitPoint, obstacleSearchRadius, obstacleTypes)
    for i = 1, #others do
        if others[i] ~= target and not others[i]:IsA(weldSpotType) then
            if mDebugDrawWeldSpotPlacement then
                gRegion:VisAddSphere(hitPoint, obstacleSearchRadius, Color(200,0,0), mDebugDrawTime)
                gRegion:VisAddArrow(hitPoint, others[i]:GetPosition(), Color(100,0,100), mDebugDrawTime)
                gRegion:VisAddText(others[i]:GetPosition(), Color(200,100,0), others[i]:GetFullName(), 1, mDebugDrawTime)
            end
            --print('There are obstacles')
            return
        end
    end
    
    if mDebugDrawWeldSpotPlacement then
        gRegion:VisAddArrow(hitPoint, hitPoint + RotateVector(Vector(0,0,1), hitRotation), Color(0,0,255), mDebugDrawTime)
    end

    return hitPoint, hitRotation
end

local function Repaired()
    local pSys = mSelf:GetAllAttachments(gParticleSysType)
    for i=1, #pSys do
        pSys[i]:Disable()
    end

    mSelf:Destroy()
end

local function PlaceWeldSpot()
    --print('AF; PlaceWeldSpot')
    if not IsNull(mSelf:GetAttachParent()) then        
        local position, rotation = FindWeldSpot(mSelf:GetAttachParent())
        local foundPlace = not IsNull(position) and not IsNull(rotation)
        if foundPlace then
            mSelf:Attach(weldSpotType, EMPTY_SYMBOL, position - mSelf:GetPosition(), rotation, mSelf)
            return true
        else
            --print("AF; Could not find place for weld spot")
            return false
        end
    end
end

local function Update()
    if not IsNull(mSelf) then        
        local weldSpots = mSelf:GetAllAttachments(weldSpotType)
        if #weldSpots <= 0 then
            Repaired()
        elseif #weldSpots < maxWeldSpots then
            PlaceWeldSpot()
        elseif #weldSpots == maxWeldSpots then
            maxWeldSpots = 0
        end
    end
end

local function PlayTransmission()
    if not IsNull(_T.Malfunctions) then
        if IsNull(_T.Malfunctions.TransmissionTimers) then
            _T.Malfunctions.TransmissionTimers = {}
        end
        
        local delayBetweenWarningTransmissions = 120
        local variance = 60
        local nextDue = _T.Malfunctions.TransmissionTimers.repairWarningNextDue
        local localAvatar = gRegion:GetLocalPlayerAvatar()
        if not IsNull(localAvatar) and (IsNull(nextDue) or Time() > nextDue) then
            DIALOG.PlayLocalTransmission(repairNeededTransmissionSet, repairNeededTransmissionTag, 0, localAvatar)
            _T.Malfunctions.TransmissionTimers.repairWarningNextDue = Time() + delayBetweenWarningTransmissions + (variance * FRand())
        end
    end
end

local function CreateTableInfo()
    _T.Malfunctions.Welding.Instances[mTableIndex] = {}
    _T.Malfunctions.Welding.Instances[mTableIndex].malfunction = mSelf
    _T.Malfunctions.Welding.Instances[mTableIndex].WeldSpotInfos = {}
end

function OnCreated(entity)
    if not gRegion:IsMaster() then
        return
    end

    while IsNull(gGameRules) do
        Sleep(0)
    end

    mSelf = entity

    PlayTransmission()
        
    while not PlaceWeldSpot() do
        Sleep(0)
    end

    while not IsNull(mSelf) do
        Sleep(0)
        Update()
    end
end