local spareParts = Type('/Lotus/Types/PickUps/CrewShipSparePart')

function OnCreated(entity)
    gRegion:CreateEntity(spareParts, entity:GetPosition(), entity:GetRotation())
end

function OnRepaired()
end