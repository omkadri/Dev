hullDamageThreshold = 0.6 --Once we're at or below this percentage of health the reactor can start taking damage
drainPerMalfunction = 15

local UTIL = require "EE.Interface.Utilities"

local SOURCE_SYM = Symbol("ReactorMalfunctionDamage")
local REACTOR_SYM = Symbol("ReactorDefenseTarget")
local REACTOR_SPAWNER_SYM = Symbol("ReactorMalfunctionSpawner")

local damageIntervals = {0.6, 0.5, 0.4, 0.3, 0.2}
local reactorStartingHealth = 10000

local function UpdateInterval(healthPercent)
    for i, interval in ipairs(damageIntervals) do
        if healthPercent > interval then
            _T.Malfunctions.ReactorDamage.intervalIndex = i
            break
        end
    end
end

local function GetLowestHealthPercentage()
    local reactor = _T.Malfunctions.ReactorDamage.reactor
    local reactorHealthPercentage = reactor:GetHealth() / reactorStartingHealth
    local crewShipMgr = gGameRules:GetCrewShipManager()
    local playerRailjackAvatar = crewShipMgr:GetPlayerShip():GetAvatarOwner()
    local hullHealthPercentage = playerRailjackAvatar:GetHealth() / playerRailjackAvatar:GetMaxHealth()
    
    return math.min(reactorHealthPercentage, hullHealthPercentage)
end

local function CreateReactorDamageTable()
    if IsNull(_T.Malfunctions) then
        _T.Malfunctions = {}
    end
    
    if IsNull(_T.Malfunctions.ReactorDamage) then
        _T.Malfunctions.ReactorDamage = {}
        
        local playerShip = gGameRules:GetCrewShipManager():GetPlayerShip()
        local spawn = playerShip:GetPlayerSpawn()
        local railjackSpawnLocation = spawn:GetPosition()
        local searchRadius = 150
        
        _T.Malfunctions.ReactorDamage.spawner = gRegion:FindFirstTaggedInRadius(REACTOR_SPAWNER_SYM, railjackSpawnLocation, 0, searchRadius)
        _T.Malfunctions.ReactorDamage.reactor = gRegion:FindFirstTaggedInRadius(REACTOR_SYM, railjackSpawnLocation, 0, searchRadius)
        _T.Malfunctions.ReactorDamage.intervalIndex = 1
    end
end

function EvaluateSpawn(spawner)
    CreateReactorDamageTable()
    
    local lowestHealthPercentage = GetLowestHealthPercentage()
    local nextInterval = damageIntervals[_T.Malfunctions.ReactorDamage.intervalIndex]
    if lowestHealthPercentage < nextInterval then
        UpdateInterval(lowestHealthPercentage)
        --return true
    end
    return false
end

function ReactorMalfunctionSpawned()
    if gRegion:IsMaster() then
        local limit = 5
        if not IsNull(_T.Malfunctions.ReactorDamage.spawner) then
            local count = _T.Malfunctions.ReactorDamage.spawner:GetMalfunctionCount()        
            limit = _T.Malfunctions.ReactorDamage.spawner:GetLimit()
            
            if count == limit then
                --TODO Either prevent malfunctions or give the reactor some invulnerability
                --respiteDuration = 60
            end
        end
        
        local crewShipMgr = gGameRules:GetCrewShipManager()
        if not IsNull(crewShipMgr) then
            local playerRailjackAvatar = crewShipMgr:GetPlayerShip():GetAvatarOwner()
            if not IsNull(playerRailjackAvatar) then
                local ship = playerRailjackAvatar:InventoryControl():GetActivePowerSuit()
                if not IsNull(ship) then
                    ship:InhibitReactor(drainPerMalfunction, SOURCE_SYM, limit)
                end
            end
        end
    end    
end

function ReactorRepaired(spawner)
    if gRegion:IsMaster() then
        local crewShipMgr = gGameRules:GetCrewShipManager()
        if not IsNull(crewShipMgr) then
            local playerRailjackAvatar = crewShipMgr:GetPlayerShip():GetAvatarOwner()
            if not IsNull(playerRailjackAvatar) then
                local maxStacks = 5
                local ship = playerRailjackAvatar:InventoryControl():GetActivePowerSuit()
                if not IsNull(ship) then
                    ship:InhibitReactor(-drainPerMalfunction, SOURCE_SYM, maxStacks)
                end
            end
        end
        
        if not IsNull(_T.Malfunctions.ReactorDamage.spawner) then
            local count = _T.Malfunctions.ReactorDamage.spawner:GetMalfunctionCount()
            local restoredHealth = reactorStartingHealth * UTIL.Ternary(count == 0, 1.0, damageIntervals[count])
            if not IsNull(_T.Malfunctions.ReactorDamage.reactor) and _T.Malfunctions.ReactorDamage.reactor:GetHealth() < restoredHealth then
                _T.Malfunctions.ReactorDamage.reactor:SetHealth(restoredHealth)
            end
        end
        
        UpdateInterval(GetLowestHealthPercentage())
    end  
end

function reactorDamaged(entity, scriptDamageData)
    if gRegion:IsMaster() then
        CreateReactorDamageTable()
        local spawner = _T.Malfunctions.ReactorDamage.spawner
        if not IsNull(spawner) then
            spawner:Spawn()
        end
    end
end