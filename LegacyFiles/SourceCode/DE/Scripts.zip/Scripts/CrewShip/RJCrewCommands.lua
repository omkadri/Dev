--give crew member secondary weapon 

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

giveSecondaryWeaponAction = WeakResource("/Lotus/Types/Friendly/Rescue/GiveWeaponAction")
local powersuitType = Type("/Lotus/Types/Game/PowerSuit")

pilotAction = Instance()

--Symbols
local IDLE_ORDER = Symbol("IdleBehavior")
-- Agent goes to the station it was assigned with

local FOLLOW_ORDER = Symbol("FollowPlayer")
-- Crew agent follows the host. Will engage in combat, but otherwise simply follows

local DEFEND_ORDER = Symbol("DefendArea")
-- Agent moves into the target area with weapon drawn and engages with any enemies en route. The agent will remain in the new area, weapon at the ready, until given new orders

local PILOT_ORDER = Symbol("PilotBehavior")  
-- Take the Helm:: crew agent will take the pilot seat (if it is empty) and fly the railjack, using the turret and battle mods in combat.

local HAZARDS_ORDER = Symbol("ClearHazardsBehavior")
-- The agent will equip their Omni tool and clear any active hazards within that area (fire, electrical, breaches). 

local USETURRET_ORDER = Symbol("UseTurretBehavior") 

local CRAFT_ORDER = Symbol("CraftBehavior") 


local function IsInDojo()
    if LOTUS_UTIL.GetUIMode() == LOTUS_UTIL.UI_MODE_IN_DOJO then
        return(true)
    end
    return(false)
end

local function ExitEmplacement(crewAgent)
    local crewAvatar = crewAgent:GetAvatar()
    --if not using emplacement, do nothing 
    if crewAvatar:HasPostureModifier(Engine.PM_EMPLACEMENT) then
        local action = crewAvatar:GameActionControl():GetCurrentGameAction()
        if not IsNull(action) and action:IsA(gEmplacementType) then
            action:FirePort("ForceUserToDismountNoAnim")
            crewAvatar:Unattach()
        end
    end
end

local function GiveIdleOrder(crewAgent, playerAvatar)
-- Upon arrival, it executes POI behavior - walking between POIs, playing anim at waypoints
-- Engages in combat when enemy appears in sight
   
    --holster weapon
    local crewInventoryCtrl = crewAgent:GetAvatar():InventoryControl()
    crewInventoryCtrl:Unequip(Engine.MAIN_HAND, Engine.HOLSTER)
    
    crewAgent:ClearAllOrders()
    crewAgent:StopMoving()
    ExitEmplacement(crewAgent)
    crewAgent:SetIdle()
    crewAgent:AddOrder(Symbol(IDLE_ORDER), playerAvatar, 1.0)    
end

local function GivePilotOrder(crewAgent, playerAvatar)
-- Agent will use context action and will play piloting animation, railjack then will be autopiloted.
-- order does not work in: Dojo(Drydoc), non-mission stationary orbit, something else?

    if IsInDojo() then -- do not need pilot in dojo
        return
    end

    local shipMgr = gGameRules:GetCrewShipManager()
    if IsNull(shipMgr) or #shipMgr:GetShips(true) == 0 then
        return
    end
    
    local crewShip = shipMgr:GetShips(true)[1]
    
    if crewShip:HasPilot() and crewShip:GetPilot():IsHumanPlayer() then --ship is currently pilotied by human player
        -- Transmit cannot execute order?
        return
        
    else
        -- if there is other crew piloting - kick them out
        local otherCrewAvatar = crewShip:GetPilot()
        if not IsNull(otherCrewAvatar) then
            local action = otherCrewAvatar:GameActionControl():GetCurrentGameAction()
            if not IsNull(action) and action:IsA(gEmplacementType) then
                action:FirePort("ForceUserToDismountNoAnim")
                otherCrewAvatar:Unattach()
                GiveIdleOrder(otherCrewAvatar:GetAgent(), playerAvatar) --giving other crew member return to their station order - needs to be improved to issue this order a better way
                Sleep(3) -- wait until other grew gets out form the pilot console
            end
        end
        -- giving order
        crewAgent:ClearAllOrders()
        crewAgent:StopMoving()
        ExitEmplacement(crewAgent)
        crewAgent:AddOrder(Symbol(PILOT_ORDER), playerAvatar, 1.0)        
    end
end
    
local function GiveFollowOrder(crewAgent, playerAvatar)
-- On arrival to player position, agent joins player and follow them, engaging in combat when needed

    if IsInDojo() then -- do not need this order in dojo
        return
    end
    
    crewAgent:ClearAllOrders()
    crewAgent:StopMoving()
    ExitEmplacement(crewAgent)
    crewAgent:AddOrder(Symbol(FOLLOW_ORDER), playerAvatar, 1.0)
end

local function GiveDefendOrder(crewAgent, playerAvatar) -- coordinates of defence cirle of def. volume?
-- Agent receives passed coordinates on the ship
-- Run to it, engaging enemies if encountered
-- On arrival - execute combat behaviors like attack from open + tacwalk
-- Active until new order is given
    
    if IsInDojo() then -- do not need this order in dojo
        return
    end
    
    crewAgent:ClearAllOrders()
    ExitEmplacement(crewAgent)
    crewAgent:AddOrder(Symbol(DEFEND_ORDER), playerAvatar, 1.0)
end

local function GiveHazardsOrder(crewAgent, playerAvatar) -- coordinates in the ship as well?
-- The agent will equip their Omni tool and clear any active hazards within that area (fire, electrical, breaches). 
-- They will roam around the area if no hazard, ready to clear anything that pops up until given new orders. Clearing hazards pulls Revolite from the Host supply
-- Should they fight first if enemies are present?
    
    if IsInDojo() then -- do not need this order in dojo
        return
    end
    
    crewAgent:ClearAllOrders()
    ExitEmplacement(crewAgent)
    crewAgent:SetIdle()
    crewAgent:AddOrder(Symbol(HAZARDS_ORDER), playerAvatar, 1.0)    
end

local function GiveUseTurretOrder(crewAgent, playerAvatar) -- turret action
-- Sub option to choose between Port or Starboard (or 2 commands?), or Forward Artillery.
-- The crew agent will move to the turret and mount it and will start attacking any targets they find. They will ignore the order (transmission reply) if the turret is in use by a player. 
-- They will kick out another Crew agent already in the turret. That agent will return to their station.  
-- Using Forward Artillery - option only available if crew agent has Gunnery 5 unlocked.

    -- check if turret is currently in use by human player
    -- check if  it's an order to use forw artilery and agent has enough of Gunnery rank to use it.
    if IsInDojo() then -- do not need this order in dojo
        return
    end
    
    crewAgent:ClearAllOrders()
    crewAgent:StopMoving()
    ExitEmplacement(crewAgent)
    crewAgent:SetIdle()
    crewAgent:AddOrder(Symbol(USETURRET_ORDER), playerAvatar, 1.0) 
end

local function GiveCraftOrder(crewAgent, playerAvatar)
-- Sub option for specific resource (Revolite, Flux Energy, Munitions, Dome Charges)
-- Crew agent moves to the Forge and crafts the desired resource
-- Crafts up to the max allowed based on cap or resource supplies
-- Crafting Revolite replenishes hosts Omni supply
-- Transmission updates on crafting, and when insufficient resources exist
-- Crew agent returns to station when crafting complete
    
    if IsInDojo() then -- are we able to craft while in dojo?
        return
    end
    
    crewAgent:ClearAllOrders()
    crewAgent:StopMoving()
    ExitEmplacement(crewAgent)
    crewAgent:SetIdle()
    crewAgent:AddOrder(Symbol(CRAFT_ORDER), playerAvatar, 1.0)
end

function GiveSecondaryWeapon(action, playerAvatar)
-- Player gives secondary weapon to the crew member, code is reused from \Lotus\Scripts\Rescue.lua + saving weapons that grew had and returning them when secondary weapon is taken back - 
-- this code should be improved to take into account powersuit, OmniTool and possibly other slot numbers.
-- While in the drydock - we do not want them to do weapon swap?
-- We have OmniTool in inventory - see how that can be handled

    if gRegion:IsMaster() then
        local crewAvatar = action:GetAttachParent()
        local crewInventoryController = crewAvatar:InventoryControl()
        local playerInventoryController = playerAvatar:InventoryControl()
        local player = playerAvatar:GetPlayer()
        local crewAgent = crewAvatar:GetAgent()

        -- Get current weapon owner
        if not _T.crewWeaponPlayers then
            _T.crewWeaponPlayers = {}
        end
        local crewInstance = crewAvatar:GetInstance()
        local weaponOwnerPlayer = _T.crewWeaponPlayers[crewInstance]
        
       -- saving weapon that crew member had initially
        local crewInitialWeapon = crewInventoryController:GetWeaponInHand(Engine.MAIN_HAND)
        if not _T.crewWeapons then
            _T.crewWeapons = { [crewInstance] = crewInitialWeapon } --saving in global table under crewinstance index so it not gets overwritten by other crewmembers
        else
            crewInitialWeapon = _T.crewWeapons
        end
        
         -- Only use if we're taking back or giving new weapon
        local hasWeaponToGive = not playerInventoryController:WeaponDisabled(Engine.SLOT_1)
        local playerWeapon = playerInventoryController:GetWeaponInSlot(Engine.SLOT_1)
        
        if (player == weaponOwnerPlayer) or (hasWeaponToGive and not IsNull(playerWeapon) and not playerWeapon:IsAbilityWeapon()) then
           
           -- Give weapon back to owning player if we have one
            if not IsNull(weaponOwnerPlayer) then
                local weaponOwnerAvatar = weaponOwnerPlayer:GetAvatar()
                if not IsNull(weaponOwnerAvatar) then
                    local weaponOwnerInventory = weaponOwnerAvatar:InventoryControl()
                    if weaponOwnerInventory:WeaponDisabled(Engine.SLOT_1) then
                        weaponOwnerInventory:SetWeaponEnabled(Engine.SLOT_1)
                    end
                end
            end
            
            -- this is needed to remove given weapon from crew member
            local item = crewInventoryController:GetWeaponInSlot(Engine.SLOT_1)
            if not IsNull(item) then
                if not item:IsA(powersuitType) then 
                    crewInventoryController:RemoveItem(Engine.SLOT_1, true)
                end
            end
            
            -- Giving back crew initial weapon
            crewAvatar:GiveItem(crewInitialWeapon[crewInstance], true)
            crewInventoryController:SetWeaponEnabled(Engine.SLOT_2)
            crewAgent:RefreshWeapon()       
            
            -- Giving player's secondary weapon
            if (IsNull(weaponOwnerPlayer) or (weaponOwnerPlayer ~= player)) and hasWeaponToGive then
                
                -- Remove existing crewmember weapon - rifle
                crewInventoryController:RemoveItem(Engine.SLOT_2,false)
                
                -- Give crew member weapon
                crewInventoryController:BuildItemInLoadOutSlot(player:GetLoadOut(), Lotus_Game.LOT_NORMAL, Lotus_Game.PISTOL_SLOT, false)
                crewInventoryController:Equip(Engine.SLOT_1, Engine.MAIN_HAND, Engine.InventoryControllerBase_ES_PLAY_EQUIP_ANIM)
                crewAgent:RefreshWeapon()
                crewAvatar:SetSpawnedByAvatar(playerAvatar) -- Set spawned by player who gave weapon so xp is shared
                
                -- Remove player weapon
                local needsWeaponSwitch = playerInventoryController:GetActualSlotForHand(Engine.MAIN_HAND) == Engine.SLOT_1
                playerInventoryController:SetWeaponDisabled(Engine.SLOT_1)
                if needsWeaponSwitch then
                    playerInventoryController:Equip(Engine.SLOT_2, Engine.MAIN_HAND, Engine.InventoryControllerBase_ES_PLAY_EQUIP_ANIM)
                end
                
                _T.crewWeaponPlayers[crewInstance] = player
            else
                _T.crewWeaponPlayers[crewInstance] = nil
                _T.crewWeapons = nil
            end
        end
    
    end
end

-- this function cycles behaviors when agent attached action is hit, for testing
function ToggleBehavior(action, playerAvatar)
    
    --enable aiDir 
    local npcManager = gRegion:GetNpcMgr() 
    local aiDir = npcManager:GetAiDirector()
    if not aiDir:IsEnabled() then
        aiDir:Enable(true)
    end

    if gRegion:IsMaster() then    
        local crewAvatar = action:GetAttachParent()
        
        if crewAvatar:IsA(gRagdollType) then
            crewAvatar = crewAvatar:GetAvatarOwner()
        end
        
        if not IsNull(crewAvatar) and crewAvatar:IsA(gAvatarType) then
            local crewAgent = crewAvatar:GetAgent()
            if not IsNull(crewAgent) then
                --local testSymbol = crewAgent:GetCurrentOrderSymbol()
                if IsNull(crewAgent:GetCurrentOrderEntity()) or crewAgent:GetCurrentOrderSymbol()==(IDLE_ORDER) then
                        GiveFollowOrder(crewAgent, playerAvatar)
                elseif crewAgent:GetCurrentOrderSymbol()==(FOLLOW_ORDER) then
                        GiveDefendOrder(crewAgent, playerAvatar)
                elseif crewAgent:GetCurrentOrderSymbol()==(DEFEND_ORDER) then
                        GivePilotOrder(crewAgent, playerAvatar)
                elseif crewAgent:GetCurrentOrderSymbol()==(PILOT_ORDER) then
                        GiveIdleOrder(crewAgent, playerAvatar)
                end
            end
        end
    end

end
