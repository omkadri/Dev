magneticSpawner = Type()
radius = 100

local sSpawner = Symbol("CloudSpawner")

function MagneticCloud(cloudGenerator)

    local spawners = gRegion:FindTaggedInRadius(sSpawner, cloudGenerator:GetPosition(), 0, radius)
    while IsNull(spawners) do
        Sleep(0)
        spawners = gRegion:FindTaggedInRadius(sSpawner, cloudGenerator:GetPosition(), 0, radius)
    end
    
    while not IsNull(cloudGenerator) do
        Sleep(0)
    end
    
    for i, spawner in ipairs(spawners) do
        spawner:FirePort("Disable")
    end
end
