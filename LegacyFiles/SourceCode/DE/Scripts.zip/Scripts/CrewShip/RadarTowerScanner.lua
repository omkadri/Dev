asteroidRadarPulseInstance = Instance()
dropShipPulseInstance = Instance()
triggerInstance = Instance()

acceptedShipsToBuff = { WeakResource() }
disallowedShips = { WeakResource() }

radarTowerBuffTag = Symbol("RADAR_TOWER_BUFF")
shipBuffEffectType = Type()
lengthOfBuff = 5
amountOfDamageReduction = 0.5 -- How much damage reduction are we applying on the enemy (0 = invuln, 1 = normal)

lengthOfPulse = 1.5
timeBetweenPulses = 12

acceptableFighters = { Type() }

local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local TABLE = require "Lotus.Scripts.Libs.TableLib"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local UTIL = require "EE.Interface.Utilities"

local mGameRules = nil
local mAiDir = nil
local mRadarTowerScriptTrigger = nil
local mAsteroidRadarPulse = nil
local mDropShipPulse = nil
local mPulseScriptTrigger = nil
local mTimeTilPulse = 0
local mParentHint = nil

--RadarTowerEncounter's disabled state
local DISABLED = 8

function RemovePulseBuff(avatar)
    avatar:DamageControl():AddShieldHealthDamageModifier(radarTowerBuffTag, Engine.DT_ANY, Engine.ANY_PART, Engine.DHT_NONE, amountOfDamageReduction)
    local buffEffect = avatar:GetAttachment(shipBuffEffectType)
    if IsNull(buffEffect) then
        buffEffect = avatar:Attach(shipBuffEffectType, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, avatar)
    else
        buffEffect:Enable()
    end

    local buffTime = lengthOfBuff
    Sleep(buffTime)

    buffEffect = avatar:GetAttachment(shipBuffEffectType)

    if not IsNull(buffEffect) then
        buffEffect:Destroy()
    end
    
    if not IsNull(avatar) then
        avatar:DamageControl():RemoveShieldHealthDamageModifier(radarTowerBuffTag)
    end
end

function PulseTriggerHit(entity, avatar)
    if not IsNull(avatar) then
        local isAcceptedShip = false

        for i=1, #disallowedShips do
            local ship = disallowedShips[i]

            if avatar:IsA(ship) then
                return
            end
        end

        for i=1,#acceptedShipsToBuff do
            local ship = acceptedShipsToBuff[i]

            if avatar:IsA(ship) then
                isAcceptedShip = true
                break
            end
        end

        if isAcceptedShip == true then
            avatar:ScriptRunChildScript(Symbol("RemovePulseBuff"), false)
        end
    end
end

local function MasterUpdate(deltaTime)

    local newTime = mTimeTilPulse - deltaTime

    if not IsNull(mPulseScriptTrigger) and mPulseScriptTrigger:IsEnabled() then
        if newTime <= (timeBetweenPulses - lengthOfPulse) then
            mPulseScriptTrigger:Disable()
        else
            mTimeTilPulse = newTime
        end
    elseif newTime <= 0 then
        --trigger pulse
        --do fx thing
        if not IsNull(mAsteroidRadarPulse) then
            mAsteroidRadarPulse:Enable()
            mAsteroidRadarPulse:FirePort("Burst")
        end

        if not IsNull(mDropShipPulse) then
            mDropShipPulse:Enable()
        end
        
        if not IsNull(mPulseScriptTrigger) then
            mPulseScriptTrigger:Enable()
        end

        mTimeTilPulse = timeBetweenPulses + lengthOfPulse
    else
        mTimeTilPulse = newTime
    end
end

local function MasterInit()
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    
    if not IsNull(asteroidRadarPulseInstance) then
        mAsteroidRadarPulse = asteroidRadarPulseInstance
        mAsteroidRadarPulse:Disable()
    end

    if not IsNull(dropShipPulseInstance) then
        mDropShipPulse = dropShipPulseInstance
        mDropShipPulse:Disable()
    end

    if not IsNull(triggerInstance) then
        mPulseScriptTrigger = triggerInstance
        mPulseScriptTrigger:Disable()
    end

    if IsNull(mPulseScriptTrigger) then
        print("Error: Unable to find pulsing script trigger")
        return
    end
    
    mTimeTilPulse = UTIL.Ternary(timeBetweenPulses ~= nil, timeBetweenPulses, 3)
end

function RadarTowerScanner(scriptTrigger)
    mRadarTowerScriptTrigger = scriptTrigger

    mParentHint = mRadarTowerScriptTrigger:GetAttachParent()

    if gRegion:IsMaster() then
        MasterInit()
    end
    
    local migrated = false
    while true do
        local curState = mParentHint:GetEncounterDynamicState()

        if curState == DISABLED then
            if not IsNull(mAsteroidRadarPulse) then
                mAsteroidRadarPulse:Disable()
            end

            if not IsNull(mDropShipPulse) then
                mDropShipPulse:Disable()
            end

            if not IsNull(mPulseScriptTrigger) then
                mPulseScriptTrigger:Disable()
            end

            return
        end

        Sleep(0)
        while IsNull(mGameRules) do
            Sleep(0)
            mGameRules = gGameRules
            if not IsNull(mGameRules) then
                migrated = true
                while not mGameRules:GameStarted() do
                    Sleep(0)
                end
            end
        end

        if gRegion:IsMaster() then
            MasterUpdate(DeltaTime())
        end
    end
end