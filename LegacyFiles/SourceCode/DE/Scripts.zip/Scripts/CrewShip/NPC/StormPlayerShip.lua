baseAttackerType = WeakResource("/Lotus/Types/Game/SpaceFighterBaseAvatar")
maxRange = 500

local symbolStormTarget = Symbol("StormTarget")

function StormPlayerShip()
    local crewShipMgr = gGameRules:GetCrewShipManager()
    if IsNull(crewShipMgr) then
        return
    end
    
    local crewShipSuit
    repeat
        Sleep(0)
        crewShipSuit = crewShipMgr:GetPlayerShip()
    until not IsNull(crewShipSuit)

    local crewShipAvatar
    repeat
        Sleep(0)
        crewShipAvatar = crewShipSuit:GetOwner()
    until not IsNull(crewShipAvatar)

    local fighters = gRegion:FindAll(baseAttackerType)
    for i,v in ipairs(fighters) do
        local agent = v:GetAgent()
        agent:AddOrder(symbolStormTarget, crewShipAvatar, maxRange)
    end
end