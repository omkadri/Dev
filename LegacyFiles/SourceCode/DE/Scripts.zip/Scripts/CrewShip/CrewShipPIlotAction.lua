friendlyFaction = Symbol("TENNO")
friendlyShipMarkerType = Type()

local hijackedSymbol = Symbol("CrewShipHijacked")
local SYM_SELF = Symbol("CrewShipPilotAction.lua")

local ENGINE_ARMOR_GROUPS = { {part = Engine.HEAD, tag = Symbol("MainEngineInvulnerable")}, {part = Engine.ARM_LEFT, tag = Symbol("LeftManeuverThrusterInvulnerable")}, {part = Engine.ARM_RIGHT, tag = Symbol("RightManeuverThrusterInvulnerable")} }

local function SetEnginesInvulnerable(avatar, invulnerable)
    for i,v in ipairs(ENGINE_ARMOR_GROUPS) do
        if not invulnerable then
            avatar:DamageControl():RemoveDamageModifier(v.tag)
        else
            avatar:DamageControl():AddDamageModifier(v.tag, Engine.DT_ANY, v.part, 0)
        end
    end
end

local function _PilotAction(action, isMounting)
    if IsNull(action) then
        return
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    local ship = crewShipMgr:GetShipForZone(action:GetZone())
    
    if IsNull(ship) then
        return
    end

    local crewShipAvatar = ship:GetAvatarOwner()
    local crewShipAgent = crewShipAvatar:GetAgent()

    if IsNull(crewShipAgent) then
        return
    end

    local pilotAvatar = action:GetCurrUser()
    if not isMounting or IsNull(pilotAvatar) then
        ship:SetIsPlayerShip(true)
        crewShipAgent:SetLocomotionEnabled(false)
        if not IsNull(pilotAvatar) then
            local pilotAgent = pilotAvatar:GetAgent()
            if not IsNull(pilotAgent) then
                pilotAgent:StopScriptedMode()
            end
        end
    else
        local isPlayerShip = false
        local hijacked = 0

        if (pilotAvatar:GetFaction() == friendlyFaction) then
            if hijacked <= 0 then
                -- Pull health and armour values from Railjack
                local railjack = crewShipMgr:GetPlayerShip()
                local railjackAvatar = railjack:GetAvatarOwner()
                local railjackDmgCtrl = railjackAvatar:DamageControl()
                
                local hullClass = railjackDmgCtrl:GetHullClass()
                local armour = railjackDmgCtrl:GetArmourRating(true)
                local health = railjackAvatar:GetMaxHealth(true)
                
                if not IsNull(crewShipAvatar) then
                    local crewshipDmgCtrl = crewShipAvatar:DamageControl()
                    crewshipDmgCtrl:SetHullClass(hullClass)
                    crewshipDmgCtrl:SetArmourRating(armour)
                    crewShipAvatar:SetMaxHealth(health)
                    crewShipAvatar:SetHealth(health)
                end
            end
            isPlayerShip = true
            hijacked = 1
            local pilotPlayer = pilotAvatar:GetPlayer()
            if not IsNull(pilotPlayer) then
                gChallengeMgr:NotifyTag(pilotPlayer, Symbol("PILOTING_HIJACKED_CREWSHIP"))
            end
        end

        crewShipAvatar:PopFactionOverride(SYM_SELF)
        crewShipAvatar:PushFactionOverride(SYM_SELF, pilotAvatar:GetFaction())

        ship:SetIsPlayerShip(isPlayerShip)
        crewShipAgent:SetLocomotionEnabled(not isPlayerShip)
        SetEnginesInvulnerable(crewShipAvatar, isPlayerShip)
        crewShipAgent:SetAgentBlackboardValue(hijackedSymbol, hijacked)

        if isPlayerShip then
            if not _T.TennoconHijackLinePlayed then -- Tennocon
                gGameRules:GiveTransmissionAsyncToAllPlayers(WeakResource("/Lotus/Sounds/Dialog/RailJack/CephalonCy/DOrgoCaptureShip0770RJCephalon"))
                _T.TennoconHijackLinePlayed = true
            end

            if _T.FriendlyCrewShipMarkers and not crewShipAvatar:HasAttachment(friendlyShipMarkerType) then
                table.insert(_T.FriendlyCrewShipMarkers, crewShipAvatar:Attach(friendlyShipMarkerType, EMPTY_SYMBOL))
            end
        end
    end
        
end

function PilotActionEnded(action)
    _PilotAction(action, false)
end

function OnActivated(action)
    _PilotAction(action, true)
end

function PilotAction(action)
    ObjectPortHandler(action, "OnActivated")
end