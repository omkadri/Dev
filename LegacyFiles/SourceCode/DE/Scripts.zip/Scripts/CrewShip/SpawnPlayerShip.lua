scriptEvents = {Symbol()}
zoneAttribs = Instance()
portForwarder = Instance()
sleepTime = 0
levelInfoLayer = 0

local PLAYER_RJ_INTERIOR_LAYER = 260

local function TeleportToShip(ship, avatar)
    if IsNull(avatar) then
        return
    end
    
    local spawnPoint = ship:GetPlayerSpawn()
        
    if IsNull(spawnPoint) then
        -- TODO: a backup plan? find a zoneattribs in that regionindex?
        return
    end
    
    avatar:Teleport(spawnPoint:GetPosition(), spawnPoint:GetRotation())
    avatar:InventoryControl():SetOnBoardShip(ship)
end

local mShip = nil
function ShipReady(ship)

    if not IsNull(ship) then
        print("ShipReady - success")
        mShip = ship
    else
        mShip = false
    end
end

local function _triggerScriptEvents(ship, events)
    for i,v in ipairs(events) do
        ship:ExecuteScriptedEvent(v)
    end
end

local function _spawnPlayerShip(crewShipMgr, crewShipLoadOut)
    local highPriority = true
    local shipType = nil

    mShip = nil
    
    local useLoadOut = false
    
    local shipTypeOverride = WeakResource(gFlashMgr:GetConfigString("CrewShip.DefaultShipOverride"))
    if not IsNull(shipTypeOverride) then
        shipType = shipTypeOverride
    elseif crewShipLoadOut.mShip.mItemId.mId ~= Lotus_Game.InvalidItemID then
        shipType = crewShipLoadOut.mShip.mItemType
        useLoadOut = true
    elseif gFlashMgr:GetConfigBool("Engine.DeveloperMode") then
        shipType = WeakResource("/Lotus/Types/Game/CrewShip/Ships/RailJack")
    end
    
    if IsNull(shipType) then
        -- This action should never have been enabled!
        return
    end
    
    -- Async load
    local shipLoader = UISys.ScriptResLoader_Create({ shipType:GetFullName() })
    
    while not shipLoader:IsDone() do
        Sleep(0)
    end
    
    shipType = Type(shipType)
    
    if useLoadOut then
        crewShipMgr:CreateCrewShipFromLoadout(crewShipLoadOut, true, highPriority, "ShipReady", PLAYER_RJ_INTERIOR_LAYER)
    elseif not IsNull(shipType) then
        crewShipMgr:CreateCrewShipFromType(shipType, nil, true, highPriority, "ShipReady", PLAYER_RJ_INTERIOR_LAYER)
    end
    
    -- Wait for the ship to finish
    while mShip == nil do
        Sleep(0)
    end
end

function SpawnPlayerShip(action, avatar)
    if not gRegion:IsMaster() then
        return
    end

    local player = gRegion:GetLocalPlayer()
    while IsNull(player) do
        player = gRegion:GetLocalPlayer()
        Sleep(0)
    end
    
    while IsNull(gGameRules) do
        Sleep(1.0)
    end

    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0.1)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local existingShip = crewShipMgr:GetPlayerShip()
    if not IsNull(existingShip) or crewShipMgr:IsLoadingShip(true) then
        return -- we only need one player ship
    end
    
    local loadOut = player:GetLoadOut()
    local crewShipLoadOut = loadOut.mCrewShipLoadOut

    _spawnPlayerShip(crewShipMgr, crewShipLoadOut)
    
    if mShip ~= false then
        while mShip:GetCrewShipState() ~= Lotus_Game.CrewShip_CSS_READY do
            Sleep(0)
        end

       
        -- Do any other sort of setup
        mShip:GetAvatarOwner():SetHyperDriveState(Lotus_Game.CrewShipAvatar_HDS_ACTIVE)
        _triggerScriptEvents(mShip, scriptEvents)
    
        local playerAvatars = gRegion:GetHumanPlayerAvatars()
        
        for i,av in ipairs(playerAvatars) do
            if av:InventoryControl():GetOnBoardShip() ~= mShip then
                TeleportToShip(mShip, av)
            end
        end
    end
    
    Sleep(sleepTime)
    
    if not IsNull(portForwarder) then
        portForwarder:FirePort("TriggerPort")
    end
end

function SetupParallaxCenter(instigator)
    while IsNull(gGameRules) do
        Sleep(1.0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0.1)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetShipForZone(instigator:GetZone())
    while IsNull(ship) do
        Sleep(0.1)
        ship = crewShipMgr:GetShipForZone(instigator:GetZone())
    end
    
    while ship:GetCrewShipState() ~= Lotus_Game.CrewShip_CSS_READY do
        Sleep(0.1)
    end
    
    local playerSpawn = ship:GetBoardShipPosition(instigator:GetPosition())
    
    instigator:SetParallaxCenter(playerSpawn)
end

function SpawnShipLiset(action, instigator)
    while IsNull(gGameRules) do
        Sleep(1.0)
    end
    
    if not gGameRules:IsBootLevel() then
        return -- only meant for use in Liset!
    end
    
    if IsNull(instigator) then
        instigator = gRegion:GetLocalPlayerAvatar()
    end
    
    if instigator:ReplicaLocallyControlled() then
        _T.BackgroundMovie:Execute("ShowBlockingMessage", "1")
    end

    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0.1)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    if gRegion:IsMaster() then
        -- Host spawns the host's ship as necessary
        local existingShip = crewShipMgr:GetPlayerShip()
        if not IsNull(existingShip) then
            mShip = existingShip
        else
            local loadOut = gGameData:GetLoadOut()
            local crewShipLoadOut = loadOut.mCrewShipLoadOut
            
            _spawnPlayerShip(crewShipMgr, crewShipLoadOut)
        end
    else
        -- Client simply waits for the host to do the work
        local existingShip = crewShipMgr:GetPlayerShip()
        while IsNull(existingShip) do
            Sleep(0.1)
            existingShip = crewShipMgr:GetPlayerShip()
        end
        
        mShip = existingShip
    end
    
    if mShip ~= false then
        while mShip:GetCrewShipState() ~= Lotus_Game.CrewShip_CSS_READY do
            Sleep(0)
        end

        if gRegion:IsMaster() then
            mShip:GetAvatarOwner():SetHyperDriveState(Lotus_Game.CrewShipAvatar_HDS_READY) -- The ship starts off ready for us
        end
        
        if instigator:ReplicaLocallyControlled() then
            -- Fade to black
            local postProcess = instigator:CameraControl():ScriptGetCurrentPostProcessInfo()
            local initialVal = postProcess.fade
            local endVal = 1.0
            
            local t = 0
            local duration = 0.5

            
            while t < 1 do
                t = math.min(1.0, t + DeltaTime() / duration)
                local val = Lerp(initialVal, endVal, t)
                postProcess.fade = val
                Sleep(0)
            end
            
            -- setup the greenroom nicely
            local greenRoomAttribs = mShip:GetGreenRoom()
            local greenRoomZone = greenRoomAttribs:GetZone()
            
            local backdropZone = greenRoomZone:GetBackdrop()
            backdropZone:GetZoneAttribs():SetParallaxCenter(greenRoomAttribs)
        
            _T.BackgroundMovie:Execute("ShowBlockingMessage", "0")
            local playerAvatars = gRegion:GetHumanPlayerAvatars()
        
            for i,av in ipairs(playerAvatars) do
                if av:InventoryControl():GetOnBoardShip() ~= mShip then
                    TeleportToShip(mShip, av)
                end
            end

            -- Fade from black
            t = 0
            while t < 1 do
                t = math.min(1.0, t + DeltaTime() / duration)
                local val = Lerp(endVal, 0.0, t)
                postProcess.fade = val
                Sleep(0)
            end
        end
    end
end

function PrepareBackdrop()   
    while IsNull(gGameRules) do
        Sleep(1.0)
    end

    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0.1)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetPlayerShip()
    while IsNull(ship) do
        Sleep(0)
        ship = crewShipMgr:GetPlayerShip()
    end
    
    if not IsNull(zoneAttribs) then
        local greenRoom = ship:GetGreenRoom()
        
        if not IsNull(greenRoom) then
            greenRoom:SetBackDropId(zoneAttribs:GetBackDropId())
            greenRoom:GetZone():SetBackdrop(zoneAttribs:GetZone())
            
            zoneAttribs:GetZone():SetActualScale(1.001)
            zoneAttribs:SetParallaxCenter(greenRoom)
            
            ship:RefreshBackdrops()
        end
    end
    
    local allLevelInfos = gRegion:FindAllObjects(gLevelInfoType)
    local targetScope = nil
    if levelInfoLayer == 0 then
        targetScope = Symbol("/")
    else
        targetScope = Symbol("/Layer" .. levelInfoLayer .. "/")
    end

    print("CREWSHIP: Level info scope: "..tostring(targetScope))
    
    for i,v in ipairs(allLevelInfos) do
        local scope = v:GetScope()
        if scope == targetScope then
            gRegion:SetLevelInfo(v)
            break
        end
    end
end

function TriggerScriptEvents()
    local player = gRegion:GetLocalPlayer()
    while IsNull(player) do
        player = gRegion:GetLocalPlayer()
        Sleep(0)
    end
    
    while IsNull(gGameRules) do
        Sleep(0.1)
    end

    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0.1)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local playerShip = crewShipMgr:GetPlayerShip()
    while IsNull(playerShip) do
        Sleep(0.1)
        playerShip = crewShipMgr:GetPlayerShip()
    end
    
    _triggerScriptEvents(playerShip, scriptEvents)

    Sleep(sleepTime)
end