beamType = Type()
excludedAvatarTypes = {WeakResource()}
beamAttachBone = Symbol("GAME_L1_ARM1")
beamAttachOffset = Vector()
randomRotationLow= Vector()
randomRotationHigh = Vector()

local symTENNO = Symbol("TENNO")
local symGrineer = Symbol("Grineer")

function DamageLoop(entity)
    local victim = entity:GetInstigator()
    local parent = entity:GetAttachParent()
    
    if IsNull(victim) then
        return
    end
        
    if IsNull(parent) then
        parent = entity
    end
    
    local pos = entity:GetPosition()
    local dir = RotateVector(Vector(0,1,0), parent:GetRotation())
    pos = pos + dir * 0.2
    
    
    local torsoOffset = Vector(math.random(), math.random(), math.random()) * 0.5
    torsoOffset = torsoOffset - Vector(1,1,1) * 0.25
    
    local bone = victim:DamageControl():GetProxyBoneForPart(Engine.TORSO)    
    local beam = parent:Attach(beamType, beamAttachBone, beamAttachOffset)


    local dmgPerSec = 10
    local dmgPulseRate = 5
    -- scale up damage based on difficulty
    if _T.difficulty then
        dmgPerSec = dmgPerSec * (1 + (_T.difficulty/5))
    end
    
    local dd = Engine.DamageData()
    local accum = dmgPulseRate
    local damageTime = 0
    while not IsNull(entity) and not IsNull(victim) and not IsNull(parent) and not parent:DamageControl():IsPreDeath() do
    
        local d = victim:DistanceToEntity(entity)
        
        if d > 12.0 then
            break
        end
        
        if not victim:IsInRift() then
            damageTime = damageTime + DeltaTime()
        end
        
        if victim:GetHealth() <= 0 then
            break
        end
        
        -- scale up damage based on range to trap
        local rangeDamageAtten = 1.0 - Clamp(d / 10.0, 0.0, 1.0)
        local distanceDmgMult = Lerp(1, 5.0, rangeDamageAtten)
        
        local beamPos = victim:DamageControl():GetPartPosition(Engine.TORSO) + torsoOffset
        local rc = entity
        if not victim:IsInRift() then
            rc = gRegion:RaycastEntity(pos, beamPos, parent) 
        end
        
        if IsNull(rc) or rc == victim then
            accum = accum + DeltaTime() * dmgPerSec * distanceDmgMult
            if accum >= dmgPulseRate and gRegion:IsMaster() then
                dd.baseAmount = math.floor(accum)
                accum = accum - dd.baseAmount
                dd:SetDamagePct(Engine.DT_ELECTRICITY, 1.0)
                --dd:SetProc(Game.PT_ELECTROCUTION, true)
                dd:SetSource(entity)
                victim:DamageDD(dd)
                local vicpos = victim:GetSimPosition()
                gRegion:GetNpcMgr():SendPerception(Npc.ITB_SOUND, Npc.IST_COMBAT_SOUND, vicpos, victim, 25 , 30)
                gRegion:GetNpcMgr():SendPerception(Npc.ITB_VISUAL, Npc.IST_UNKNOWN, vicpos, victim, 25 ,30 )
            end
            
            if IsNull(beam) then
                beam = parent:Attach(beamType, beamAttachBone, beamAttachOffset)
                if not IsNull(beam) and not IsNull(pos) then
                    beam:SetEndPoint(pos)
                end
            end
            
            if not IsNull(beam) then
                beam:SetEndPoint(beamPos)
            end
        else
            if not IsNull(beam) then
                beam:Destroy()
            end
        end
        Sleep(0)
    end
    
    if not IsNull(beam) then
        beam:Destroy()
    end
end

function SparkTrap(entity)

    local victim = entity:GetInstigator()
    if IsNull(victim) then
        return
    end
    local faction = victim:GetFaction()
    
    local parent = entity:GetAttachParent()
    if IsNull(parent) or parent:DamageControl():IsPreDeath() or parent:GetHealth() <= 0 then
        entity:Destroy()
        return
    end

    local gameRules = gGameRules
    local mission = gameRules:GetMission()
    local missionInfo = mission
    
    if (IsNull(missionInfo.invasionId) or missionInfo.invasionId == "") and not missionInfo.forceAllyFaction then
        -- Regular mission; zap only Tenno
        if faction ~= symTENNO then
            return -- only zap tenno
        end
    elseif missionInfo.invasionAllyFaction == Lotus_Game.FC_GRINEER then
        -- On grineer home-turf; zap only the opposing faction
        if faction ~= missionInfo:GetFactionTag() then
            return
        end
    else -- ie: missionInfo.faction == Lotus_Game.FC_GRINEER
        -- Invading Grineer; zap all except grineer
        if faction == missionInfo:GetFactionTag() then
            return
        end
    end

    -- print("Zapping " .. faction:c_str())
    if victim:IsA(gLotusSentinelAvatarType) then
        return -- don't kill pets, they have no avoidance behaviors and just stand and die
    end
    
    for i, excludedAvatarType in ipairs(excludedAvatarTypes) do
        if victim:IsA(excludedAvatarType) then
            return
        end
    end

    entity:ScriptRunChildScript(Symbol("DamageLoop"), false)
end

function RandomZap(entity)
    local parent = entity:GetAttachParent()
    local zapDelayMin = 0.5
    local zapDelayMax = 2
    local zapDelay = Random(zapDelayMin, zapDelayMax)
    
    local t = 0
    
    while not IsNull(parent) and not parent:DamageControl():IsPreDeath() and parent:GetHealth() > 0 do
    
        if t >= zapDelay then
            local beam = parent:Attach(beamType, beamAttachBone, beamAttachOffset)
            if not IsNull(beam) then
                local beamPos = beam:GetPosition()
                local rot = Rotation(math.random(randomRotationLow.y,randomRotationHigh.y),math.random(randomRotationLow.x,randomRotationHigh.x),math.random(randomRotationLow.z,randomRotationHigh.z))
                local endPoint = beamPos + AngleToDirection(rot) * 1000
                
                local hitPoint = Vector()
                gRegion:Raycast(beamPos, endPoint, nil, nil, hitPoint)
                beam:SetEndPoint(hitPoint)
            end
            
            Sleep(0.5)
            
            if not IsNull(beam) then
                beam:Destroy()
            end
            
            t = 0
            zapDelay = Random(zapDelayMin, zapDelayMax)
        end
        t = t + DeltaTime()
        Sleep(0)
    end
    

end
