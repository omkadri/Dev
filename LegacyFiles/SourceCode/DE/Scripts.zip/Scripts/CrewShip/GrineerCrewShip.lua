warpFxType = Type()
weakPointDecoType = Type()
shieldFxType = Type()
retreatTimer = 10 --dissolve and remove after retreating for this long

local TIMER = require "Lotus.Interface.Libs.TimerMgr"

local engineDecoType = WeakResource("/Lotus/Fx/Enemies/Grineer/SpaceCrewShip/GrnCrewShipV2ThrusterCapDeco")
local engineOverrideParam = Symbol("EmissiveTintColorZZZ")
local engineOnColor = Color(200,255,0,255)
local engineOffColor = Color(0,0,0,255)
local disabledFxTag = Symbol("disabledFx")
local engineExplosionFxTag = Symbol("engineExplosionFx")
local sInvulnSymbol = Symbol("CrewShipBlockingInvuln")
local sEnterShipAction = Symbol("EnterShipAction")

local mAvatar
local mTimerMgr
local mNeedsTimerUpdate = 0

local mEnterShipAction
local mEnginesPowered = true
local mDamagedEngines = {}
local mWeakpoints = {}
local mShieldFx

local damageMultipliers = { MainEngine = {type=Engine.DT_ANY, part=Engine.HEAD, factor=5}, LeftManeuverThruster = {type=Engine.DT_ANY, part=Engine.ARM_LEFT, factor=5}, RightManeuverThruster = {type=Engine.DT_ANY, part=Engine.ARM_RIGHT, factor=5}}

local weakPointList = {{ bone = Symbol("GAME_C1_ROOT"), offset = Vector(1.5, 4, 3.5), rotation = Rotation(100, -35, 90)},
                              { bone = Symbol("GAME_C1_ROOT"), offset = Vector(-1.5, 4, 3.5), rotation = Rotation(-100, -35, 90)},
                              { bone = Symbol("GAME_C1_ROOT"), offset = Vector(0, -4.6, 3.5), rotation = Rotation(0, 90, 0)}}     
                              
local function UpdateEngineFx(specificTag, isDamage)

    local engineDecos = mAvatar:GetAllAttachments(engineDecoType)
    for i = 1, #engineDecos do
        local deco = engineDecos[i]
        local decoTag = deco:GetTag()
        
        if not specificTag or decoTag == specificTag then
        
            local destroyed = mDamagedEngines[decoTag:c_str()]
            
            local engineOn = mEnginesPowered and not destroyed
            local engineFx = deco:GetAttachedChildren()
            for _, fx in pairs(engineFx) do
                if fx:HasTag(disabledFxTag) then
                    if isDamage then
                        if destroyed then
                            fx:Enable()
                            fx:SetVisibility(true, false)
                        else
                            fx:Disable()
                            fx:SetVisibility(false, false)
                        end
                    end
                elseif fx:HasTag(engineExplosionFxTag) and not engineOn and isDamage then
                    fx:FirePort("Burst")
                else
                    fx:SetVisibility(engineOn, true)
                end
            end

--~             if engineOn then
--~                 mTimerMgr:AddTimer(
--~                     0.2, 
--~                     function(decoration) 
--~                         decoration:SetMaterialParam(engineOverrideParam, engineOnColor.red/255, engineOnColor.green/255, engineOnColor.blue/255, 1, false) 
--~                         
--~                         mNeedsTimerUpdate = mNeedsTimerUpdate - 1
--~                     end,
--~                     false,
--~                     deco
--~                 )
--~             else
--~                 mTimerMgr:AddTimer(
--~                     0.2, 
--~                     function(decoration) 
--~                         decoration:SetMaterialParam(engineOverrideParam, engineOffColor.red/255, engineOffColor.green/255, engineOffColor.blue/255, 1, false) 
--~                         
--~                         mNeedsTimerUpdate = mNeedsTimerUpdate - 1
--~                     end,
--~                     false,
--~                     deco
--~                 )
--~             end
            
            mNeedsTimerUpdate = mNeedsTimerUpdate + 1
            
            if specificTag then
                break
            end
        end
    end

end

local function UnboardNonRailjackBoardedPlayers()
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local ship = crewShipMgr:GetPlayerShip()
    
    if IsNull(ship) then
        return
    end
    
    local players = gRegion:GetHumanPlayers()
    local playerData= {}
    for _,player in ipairs(players) do
        local playerAvatar = player:GetAvatar()
        if not IsNull(playerAvatar) then
            local onBoardShip = playerAvatar:InventoryControl():GetOnBoardShip()
            if not IsNull(onBoardShip) and onBoardShip ~= ship then
                local onBoardShipAvatar = onBoardShip:GetAvatarOwner()
                if not IsNull(onBoardShipAvatar) then
                         local action = playerAvatar:GameActionControl():GetCurrentGameAction()
                         if not IsNull(action) and action:IsA(gEmplacementType) then
                            action:Disable()
                        end
                        table.insert(playerData, {playerAvatar,onBoardShipAvatar})
                end
            end
        end
    end
    
    Sleep(0.1)
    
    for i=1, #playerData do
            playerData[i][1]:Teleport(playerData[i][2]:GetPosition(), playerData[i][2]:GetRotation())
    end
end

function GrineerCrewShip(avatar)
    mTimerMgr = TIMER.CreateTimerMgr()
    
    local ship = avatar:InventoryControl():GetActivePowerSuit()
    while IsNull(ship) do
        Sleep(0)
        ship = avatar:InventoryControl():GetActivePowerSuit()
    end
    
    mAvatar = avatar
    
    avatar:RegisterOnPredeathCallback("OnPreDeath")
    avatar:DamageControl():RegisterArmourDestroyedChangedCallback("OnArmourGroupDestroyedChanged")

    for i,v in pairs(damageMultipliers) do
        local tag = Symbol(i)
        avatar:DamageControl():RemoveDamageModifier(tag)
        avatar:DamageControl():AddDamageModifier(tag, v.type, v.part, v.factor)
    end

    ship:RegisterEnginesPoweredCallback("OnEnginesPowerChanged")
  
    while true do
        Sleep(0)
        
        if mNeedsTimerUpdate > 0 then
            mTimerMgr:Update(DeltaTime())
        end
    end
end

function GrineerCrewShipShield(avatar)
    mTimerMgr = TIMER.CreateTimerMgr()
    
    local ship = avatar:InventoryControl():GetActivePowerSuit()
    while IsNull(ship) do
        Sleep(0)
        ship = avatar:InventoryControl():GetActivePowerSuit()
    end
    
    mAvatar = avatar
    local attachments = avatar:GetAttachedChildren()
    for i=1, #attachments do
        if attachments[i]:GetTag() == sEnterShipAction then
            mEnterShipAction = attachments[i]
        end
    end
    
    if gRegion:IsMaster() then
        -- Set up weakpoints    
        for i = 1, #weakPointList do
            if not IsNull(weakPointList[i]) then
                local weakPoint = avatar:Attach(weakPointDecoType, weakPointList[i].bone, weakPointList[i].offset, weakPointList[i].rotation)
                if not IsNull(weakPoint) then
                    table.insert(mWeakpoints, weakPoint)
                end
            end
        end

        if not IsNull(mWeakpoints) and #mWeakpoints > 0 then
            if not avatar:HasAttachment(shieldFxType) then
                mShieldFx = avatar:Attach(shieldFxType, EMPTY_SYMBOL)
            end
            avatar:DamageControl():AddDamageModifier(sInvulnSymbol, Engine.DT_ANY, Engine.ANY_PART, 0)
            local weakpointHealth = avatar:GetMaxHealth() / #mWeakpoints
            for i = 1, #mWeakpoints do
                mWeakpoints[i]:SetHealth(weakpointHealth, true)
            end
            
            if not IsNull(mEnterShipAction) then
                mEnterShipAction:Disable()
            end
        end
    end
    
    avatar:RegisterOnPredeathCallback("OnPreDeath")
    avatar:DamageControl():RegisterArmourDestroyedChangedCallback("OnArmourGroupDestroyedChanged")

    for i,v in pairs(damageMultipliers) do
        local tag = Symbol(i)
        avatar:DamageControl():RemoveDamageModifier(tag)
        avatar:DamageControl():AddDamageModifier(tag, v.type, v.part, v.factor)
    end

    ship:RegisterEnginesPoweredCallback("OnEnginesPowerChanged")
  
    while true do
        Sleep(0)
        
        if gRegion:IsMaster() then
            if not IsNull(mWeakpoints) and #mWeakpoints > 0 then
                local decoCount = #mWeakpoints
                for i=#mWeakpoints, 1, -1 do
                    if IsNull(mWeakpoints[i]) or mWeakpoints[i]:GetHealth() <= 0 then
                        table.remove(mWeakpoints, i)
                        decoCount = decoCount - 1 
                    end
                end
                    
                if decoCount <= 0 and avatar:DamageControl():HasDamageModifier(sInvulnSymbol) then
                    if not IsNull(mShieldFx) then
                        mShieldFx:PlayTriggeredFade()
                    end
                    avatar:DamageControl():RemoveDamageModifier(sInvulnSymbol)
                    if not IsNull(mEnterShipAction) then
                        mEnterShipAction:Enable()
                    end
                elseif not avatar:DamageControl():HasDamageModifier(sInvulnSymbol) then
                    mShieldFx = avatar:Attach(shieldFxType, EMPTY_SYMBOL)
                    avatar:DamageControl():AddDamageModifier(sInvulnSymbol, Engine.DT_ANY, Engine.ANY_PART, 0)
                end
            end
        end
        
        if mNeedsTimerUpdate > 0 then
            mTimerMgr:Update(DeltaTime())
        end
    end
end

function OnArmourGroupDestroyedChanged(group, destroyed)
    local tag = group:GetTag()
    mDamagedEngines[tag:c_str()] = destroyed
    mAvatar:DamageControl():RemoveDamageModifier(tag)
    if not destroyed then
        local props = damageMultipliers[tag:c_str()]
        mAvatar:DamageControl():AddDamageModifier(tag, props.type, props.part, props.factor)
    end
    UpdateEngineFx(tag, true)
end

function OnEnginesPowerChanged(avatar, powered)
    mEnginesPowered = powered
    UpdateEngineFx(nil, false)
end

function OnPreDeath()
    UpdateEngineFx(nil, true)
end

function RemoveOnRetreat(agent)
    local t = 0
    while t <= retreatTimer and not IsNull(agent) do
        t = t + DeltaTime()
        Sleep(0)
    end
    
    if IsNull(agent) then
        return
    end
    local avatar = agent:GetAvatar()
    if not IsNull(avatar) then
        local warpFxAttached = false
        local dissolve = 0
        while dissolve <= 1 and not IsNull(avatar) do
            avatar:SetMaterialParam(Lotus_Game.CLOAK, dissolve)
            avatar:SetDissolve(dissolve)
            dissolve = dissolve + DeltaTime() + 0.1
            if dissolve >= 0.5 and not warpFxAttached then
                avatar:Attach(warpFxType,  EMPTY_SYMBOL)
                warpFxAttached = true
            end
            Sleep(0)
        end
        
        if not IsNull(avatar) then
            if  gRegion:IsMaster() then
                UnboardNonRailjackBoardedPlayers()
            end
            Sleep(0.1)
            avatar:Destroy()
        end
    end
    
end
