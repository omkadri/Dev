interactSound = Resource()
hackFx = Resource()
secondHackFx = Resource()
hackSound = Resource()
fxAttachOffset = Vector()
secondFxAttachOffset = Vector()
turretAvatarType = Resource()
hackTime = 1.5
hackLoc = String()
local UTIL = require "EE.Interface.Utilities"

local function Update(avatar, fx, secondFx, markerInfo)
    while not IsNull(avatar) and not avatar:IsKilled() do
        Sleep(0.1)
    end
    
    if not IsNull(fx) then
        fx:Destroy()
    end
    
    if not IsNull(secondFx) then
        secondFx:Destroy()
    end
    
    if not IsNull(markerInfo) then
        markerInfo:Destroy()
    end
end

local function ClientStart(instigator, avatar, markerInfo)
    -- Execute for everyone
    markerInfo:SetContextColor(Color(_G.UIColor_Green))
    if not IsNull(hackSound) then
        avatar:PlaySound(hackSound, false, 0, false)
    end
    local hackFxInst = nil
    local secondHackFxInst = nil
    if not IsNull(hackFx) then
        hackFxInst = avatar:Attach(hackFx, EMPTY_SYMBOL, fxAttachOffset)
    end
    if not IsNull(secondHackFx) then
        secondHackFxInst = avatar:Attach(secondHackFx, EMPTY_SYMBOL, secondFxAttachOffset)
    end
    
    if not IsNull(_T.CommanderMap) and not IsNull(_T.ActiveTacticalMarker) then
        -- Execute on the player operating the command console
        Sleep(0.15)
        local miniMapClipName = _T.ActiveTacticalMarker:GetClipName()
        if _T.TacticalMapInterpolate then
            _T.TacticalMapInterpolate(miniMapClipName .. ".Progress", {"_alpha", "_xscale", "_yscale"}, {0, 10, 10}, 0.5, 0.4)
            _T.TacticalMapInterpolate(miniMapClipName .. ".TacticalText", {"_alpha"}, {0}, 0.5, 0.4)
        end
    end
    
    _T.ActiveTacticalMarker = nil
    
    if not IsNull(hackFxInst) or not IsNull(secondHackFxInst) then
        Update(avatar, hackFxInst, secondHackFxInst, markerInfo)
    end
end

local function _Start(instigator, avatar, markerInfo, skip)
    if skip then
        return
    end
    if gRegion:IsMaster() then
        if not IsNull(avatar) and avatar:IsA(gBaseAvatarType) then
            avatar:PushFactionOverride(Symbol("HACK"), Symbol("TENNO"))
            avatar:SetThreatModifier(5)
            if avatar:IsA(turretAvatarType) then
                avatar:IncrementActivationRequests()
            end
        else
            print("HackAllegiance: parent is null or not an avatar")
        end
        if not IsNull(markerInfo) then
            markerInfo:SetInteractable(false)
        end
    end
    
    ClientStart(instigator, avatar, markerInfo)
end

function Start(instigator, avatar, markerInfo)
    _Start(instigator, avatar, markerInfo)
end

function PreStart(instigator, entity, markerInfo)
    _T.DisableMarkerRollOutColor = true
    if not IsNull(interactSound) then
        UTIL.PlaySound(interactSound)
    end
    
    local miniMapMarker = _T.ActiveTacticalMarker
    local miniMapClipName = miniMapMarker:GetClipName()
    if not IsNull(_T.CommanderMap) then
        _T.InitTacticalMapMaterial(miniMapClipName)
        _T.CommanderMap:SetVariableEx(miniMapClipName, "Progress", "_xscale", 10)
        _T.CommanderMap:SetVariableEx(miniMapClipName, "Progress", "_yscale", 10)
        _T.CommanderMap:SetVariableEx(miniMapClipName, "Progress", "_color", _G.UIColor_Yellow)
        _T.CommanderMap:SetVariableEx(miniMapClipName, "TacticalText", "text", _T.CommanderMap:GetLocalized(hackLoc, true))
        _T.CommanderMap:SetVariableEx(miniMapClipName, "TacticalText", "_x", -7)
        _T.TacticalMapInterpolate(miniMapClipName .. ".Progress", {"_alpha", "_xscale", "_yscale"}, {100, 100, 100}, 0.15)
    end
    
    local fillClipName = miniMapClipName .. ".Progress.Fill"
    local time = 0
    while time < hackTime do
        time = time + RealDeltaTime()
        if not IsNull(_T.CommanderMap) then
            _T.CommanderMap:SetShaderVariable(fillClipName, "AlphaTestThreshold", time / hackTime, 0, 0, 0)
        end
        Sleep(0)
    end
    
    if not IsNull(_T.CommanderMap) then
        _T.CommanderMap:SetShaderVariable(fillClipName, "AlphaTestThreshold", 1, 0, 0, 0)
        _T.CommanderMap:SetVariableEx(miniMapClipName, "Progress", "_color", _G.UIColor_Green)
        _T.TacticalMapInterpolate(miniMapClipName .. ".TacticalText", {"_alpha"}, {100}, 0.1)
    end
    
    _Start(nil, nil, nil, true) -- Expose all script variables to editor
    
    return true
end

function ShutDown(avatar, markerInfo)
    if not IsNull(_T.ActiveTacticalMarker) and not IsNull(_T.CommanderMap) then
        local miniMapClipName = _T.ActiveTacticalMarker:GetClipName()
        _T.CommanderMap:SetVariableEx(miniMapClipName, "Progress", "_alpha", 0)
        _T.CommanderMap:SetVariableEx(miniMapClipName, "TacticalText", "_alpha", 0)
    end
    _T.ActiveTacticalMarker = nil
end