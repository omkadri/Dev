interactSound = Resource()
entityOverride = Instance()
barrierPanels = { Instance() } -- Decos to hide
barrierVolumes = { Instance() } -- Decos to disable
hackSound = Resource()
hackedIcon = Resource()
hackTime = 1.5
hackLoc = String()
local UTIL = require "EE.Interface.Utilities"

local function ClientStart(instigator, entity, markerInfo)
    -- Execute for everyone
    if not IsNull(hackSound) then
        markerInfo:PlaySound(hackSound, false, 0, false)
    end
    for i = 1, #barrierVolumes do
        barrierVolumes[i]:FirePort("Disable")
    end
    for i = 1, #barrierPanels do
        barrierPanels[i]:FirePort("Hide")
    end
    
    if not IsNull(hackedIcon) then
        markerInfo:SetIcon(hackedIcon)
    end
    markerInfo:SetContextColor(Color(_G.UIColor_Green))
    
    if not IsNull(_T.CommanderMap) and not IsNull(_T.ActiveTacticalMarker) then
        -- Execute on the player operating the command console
        Sleep(0.15)
        local miniMapClipName = _T.ActiveTacticalMarker:GetClipName()
        if _T.TacticalMapInterpolate then
            _T.TacticalMapInterpolate(miniMapClipName .. ".Progress", {"_alpha", "_xscale", "_yscale"}, {0, 10, 10}, 0.5, 0.4)
            _T.TacticalMapInterpolate(miniMapClipName .. ".TacticalText", {"_alpha"}, {0}, 0.5, 0.4)
        end
        _T.ActiveTacticalMarker = nil
    end
end

local function _Start(instigator, entity, markerInfo, skip)
    if skip then
        return
    end
    if not IsNull(entityOverride) then
        entity = entityOverride
    end
    if gRegion:IsMaster() then
        if not IsNull(markerInfo) then
            markerInfo:SetInteractable(false)
        end
    end
    
    ClientStart(instigator, entity, markerInfo)
end

function Start(instigator, entity, markerInfo)
    _Start(instigator, entity, markerInfo)
end

function PreStart(instigator, entity, markerInfo)
    if not IsNull(entityOverride) then
        entity = entityOverride
    end
    _T.DisableMarkerRollOutColor = true
    if not IsNull(interactSound) then
        UTIL.PlaySound(interactSound)
    end
    
    local miniMapMarker = _T.ActiveTacticalMarker
    local miniMapClipName = miniMapMarker:GetClipName()
    if not IsNull(_T.CommanderMap) then
        _T.InitTacticalMapMaterial(miniMapClipName)
        _T.CommanderMap:SetVariableEx(miniMapClipName, "Progress", "_xscale", 10)
        _T.CommanderMap:SetVariableEx(miniMapClipName, "Progress", "_yscale", 10)
        _T.CommanderMap:SetVariableEx(miniMapClipName, "Progress", "_color", _G.UIColor_Yellow)
        _T.CommanderMap:SetVariableEx(miniMapClipName, "TacticalText", "text", _T.CommanderMap:GetLocalized(hackLoc, true))
        _T.CommanderMap:SetVariableEx(miniMapClipName, "TacticalText", "_x", -7)
        _T.TacticalMapInterpolate(miniMapClipName .. ".Progress", {"_alpha", "_xscale", "_yscale"}, {100, 100, 100}, 0.15)
    end
    
    local fillClipName = miniMapClipName .. ".Progress.Fill"
    local time = 0
    while time < hackTime do
        time = time + RealDeltaTime()
        if not IsNull(_T.CommanderMap) then
            _T.CommanderMap:SetShaderVariable(fillClipName, "AlphaTestThreshold", time / hackTime, 0, 0, 0)
        end
        Sleep(0)
    end
    
    if not IsNull(_T.CommanderMap) then
        _T.CommanderMap:SetShaderVariable(fillClipName, "AlphaTestThreshold", 1, 0, 0, 0)
        _T.CommanderMap:SetVariableEx(miniMapClipName, "Progress", "_color", _G.UIColor_Green)
        _T.TacticalMapInterpolate(miniMapClipName .. ".TacticalText", {"_alpha"}, {100}, 0.1)
    end
    
    _Start(nil, nil, nil, true) -- Expose all script variables to editor
    
    return true
end