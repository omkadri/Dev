interactSound = Resource()
repairedSound = Resource()
droneType = Type()
repairTime = 1

local UTIL = require "EE.Interface.Utilities"

local ammoType = WeakResource("/Lotus/Weapons/CrewShip/MultitoolAmmo")

local function GetCostAndRewardTable()
    -- Copied from RailjackMultiTool.lua, change both or consolidate them
    return {
        ["/Lotus/Types/Game/CrewShip/Malfunctions/Fire"] = {cost=10, reward=600},
        ["/Lotus/Types/Game/CrewShip/Malfunctions/ElectricityMalfunction"] = {cost=10, reward=600},   
        ["/Lotus/Types/Game/CrewShip/Malfunctions/IceMalfunction"] = {cost=10, reward=600},
        ["/Lotus/Types/Game/CrewShip/Malfunctions/WallBreach"] = {cost=10, reward=300},
        ["/Lotus/Types/Game/CrewShip/Malfunctions/MegaBreach"] = {cost=30, reward=900}
    }
end

local function GetCostAndRewardForType(malfunctionType)
    local costAndReward = GetCostAndRewardTable()[malfunctionType]
    return costAndReward or {cost=0, reward=0}
end

local function GetRailjackInventory()
    local crewShipManager = gGameRules:GetCrewShipManager()
    local shipAvatar = nil
    if not IsNull(crewShipManager) then
        local ship = crewShipManager:GetPlayerShip()
        if not IsNull(ship) then
            shipAvatar = ship:GetAvatarOwner()
            return shipAvatar:InventoryControl()
        end
    end
    return nil
end

local function _Start(instigator, entity, markerInfo, skip)
    if skip then
        return
    end
    
    if not IsNull(markerInfo) then
        markerInfo:SetInteractable(false)
    end
    
    if not IsNull(repairedSound) then
        markerInfo:PlaySound(repairedSound, false, 0, false)
    end
    
    if instigator:ReplicaLocallyAuthoritative() then
        local spawner = entity:GetCreator()
        if not IsNull(spawner) then
            spawner:SendRepairRMI(entity, instigator)
        end
    end
end

function Start(instigator, entity, markerInfo)
    _Start(instigator, entity, markerInfo)
end

function PreStart(instigator, entity, markerInfo)
    local PLAYER_SKILL_LIB = require "Lotus.Scripts.Libs.PlayerSkillsLib"
    local playerAvatar = gRegion:GetLocalPlayerAvatar()
    local canRepair = playerAvatar:IsIntrinsicSkillAbilityAdded(PLAYER_SKILL_LIB.sSkillBCUberFix)
    
    if canRepair then
        local materialCount = 0
        local railjackInventory = GetRailjackInventory()
        if not IsNull(railjackInventory) then
            materialCount = railjackInventory:GetAmmoExCount(ammoType)
        end
        
        local cost = GetCostAndRewardForType(entity:GetType():GetFullName()).cost
        if not IsNull(_T.multiToolAmmoReduction) then
            cost = cost * _T.multiToolAmmoReduction
        end
        canRepair = (materialCount >= cost)
        
        if not canRepair and not IsNull(_T.TacticalMapError) then
            _T.TacticalMapError("/Lotus/Language/Railjack/NeedMultitoolAmmo", 3, {VAL = cost})
        end
    end
    
    if not canRepair then
        _T.ActiveTacticalMarker = nil
        return
    end

    _T.DisableMarkerRollOutColor = true
    if not IsNull(interactSound) then
        UTIL.PlaySound(interactSound)
    end
    
    local miniMapMarker = _T.ActiveTacticalMarker
    local miniMapClipName = miniMapMarker:GetClipName()
    if not IsNull(_T.CommanderMap) then
        _T.InitTacticalMapMaterial(miniMapClipName)
        _T.CommanderMap:SetVariableEx(miniMapClipName, "Progress", "_xscale", 10)
        _T.CommanderMap:SetVariableEx(miniMapClipName, "Progress", "_yscale", 10)
        _T.CommanderMap:SetVariableEx(miniMapClipName, "Progress", "_color", _G.UIColor_Yellow)
        _T.TacticalMapInterpolate(miniMapClipName .. ".Progress", {"_alpha", "_xscale", "_yscale"}, {100, 100, 100}, 0.15)
    end
    
    local pos = entity:GetPosition()
    local rot = entity:GetRotation()
    local numDrones = RandomInt(2, 3)
    
    for i = 1, numDrones do
        local offset = Vector(0, 0, Random(1, 1.5))
        offset = RotateVector(offset, rot)
        offset = RotateVector(offset, Rotation(Random(0, 360), Random(-20, 20), 0))
        
        local spawnPos = pos + offset
        gRegion:Raycast(pos, spawnPos, entity, nil, spawnPos, true)
        
        local endPos = pos + Vector(Random(-0.25, 0.25), Random(-0.25, 0.25), Random(-0.25, 0.25))
        local drone = gRegion:CreateEntity(droneType, spawnPos, LookTo(spawnPos + Vector(0, 0.25, 0), endPos), markerInfo)
        
        if not IsNull(drone) then
            local beam = drone:GetAttachment(gBeamType)
            if not IsNull(beam) then
                beam:SetEndPoint(endPos)
            end
            
            local seq = drone:GetAttachment(gSequencerType)
            if not IsNull(seq) then
                seq:Enable()
            end
        end
    end
    
    local fillClipName = miniMapClipName .. ".Progress.Fill"
    local time = 0
    while time < repairTime do
        time = time + DeltaTime()
        if not IsNull(_T.CommanderMap) then
            _T.CommanderMap:SetShaderVariable(fillClipName, "AlphaTestThreshold", time / repairTime, 0, 0, 0)
        end
        Sleep(0)
    end
    
    if not IsNull(_T.CommanderMap) then
        _T.CommanderMap:SetShaderVariable(fillClipName, "AlphaTestThreshold", 1, 0, 0, 0)
        _T.CommanderMap:SetVariableEx(miniMapClipName, "Progress", "_color", _G.UIColor_Green)
    end
    _Start(nil, nil, nil, true) -- Expose all script variables to editor
    
    Sleep(0.15)
    
    if _T.TacticalMapInterpolate then
        _T.TacticalMapInterpolate(miniMapClipName .. ".Progress", {"_alpha", "_xscale", "_yscale"}, {0, 10, 10}, 0.5, 0.4)
    end
    _T.ActiveTacticalMarker = nil
    
    return true
end

function ShutDown(entity, markerInfo)
    local drones = gRegion:FindAllObjects(droneType)
    
    for i, drone in ipairs(drones) do
        if not IsNull(drone) and drone:GetCreator() == markerInfo then
            local beam = drone:GetAttachment(gBeamType)
            if not IsNull(beam) then
                beam:Disable()
            end
            
            local seq = drone:GetAttachment(gSequencerType)
            if not IsNull(seq) then
                seq:Disable()
            end
            
            drone:PlayTriggeredFade()
        end
    end
    
    if _T.ActiveTacticalMarker then
        local miniMapMarker = _T.ActiveTacticalMarker
        local miniMapClipName = miniMapMarker:GetClipName()
        
        if not IsNull(_T.CommanderMap) then
            _T.CommanderMap:SetShaderVariable(miniMapClipName .. ".Progress.Fill", "AlphaTestThreshold", 1, 0, 0, 0)
            _T.CommanderMap:SetVariableEx(miniMapClipName, "Progress", "_color", _G.UIColor_Green)
        end
        
        if _T.TacticalMapInterpolate then
            _T.TacticalMapInterpolate(miniMapClipName .. ".Progress", {"_alpha", "_xscale", "_yscale"}, {0, 10, 10}, 0.5, 0.4)
        end
        
        _T.ActiveTacticalMarker = nil
    end
end