startSound = Resource()
local teleportTime = .5

local UTIL = require "EE.Interface.Utilities"

local function ClientStart(instigator, attachParent, markerInfo)
    -- Execute for everyone
    
    if not IsNull(_T.CommanderMap) and not IsNull(_T.ActiveTacticalMarker) then
        -- Execute on the player operating the command console
        _T.CommanderMap:Execute("Close", "")
    end
    
    _T.ActiveTacticalMarker = nil
    
    if not IsNull(instigator) and instigator:IsLocallyAuthoritative() then
        local attachParent = instigator:GetAttachParent()
        if not IsNull(attachParent) and attachParent:IsA(gEmplacementType) then
            attachParent:FirePort("ForceUserToDismountNoAnim")
        end
        local motionControl = instigator:MotionControl()
        instigator:Teleport(markerInfo:GetSimPosition(), markerInfo:GetSimRotation())
        instigator:ResetVerticalVelocity()
    end
end

local function _Start(instigator, deco, markerInfo, skip)
    if skip then
        return
    end
    
    ClientStart(instigator, deco, markerInfo)
end

function Start(instigator, deco, markerInfo)
    _Start(instigator, deco, markerInfo)
end

function PreStart(instigator, entity, markerInfo)
    if not IsNull(instigator) then
        instigator:PlaySound(startSound, false, 0, false)
    end
    
    local postProcess = gRegion:GetLevelInfo().postProcess
    local cameraControl = instigator:CameraControl()
    
    local time = teleportTime
    while time > 0 do
        time = time - RealDeltaTime()
        
        if time <= 1 then
            local t = (1 - time) *1.5
            if not IsNull(cameraControl) then
                cameraControl:AttenuateFOV(1.0 + (t * t))
                cameraControl:ShakeView(instigator:EyePosition(), -1, 2 * t, 0)
                
                if postProcess then
                    postProcess.bloomBoost = 5 + t * 10
                end
            end
            
            if time <= .25 then
                if not IsNull(_T.CommanderMap) then
                    _T.CommanderMap:Close()
                end
                
                if postProcess then
                    postProcess.fade = 0 + t
                end
            end
        end
        
        Sleep(0)
    end
    
    if not IsNull(cameraControl) then
        cameraControl:AttenuateFOV(1.0)
        if postProcess then
            postProcess.bloomBoost = 0
            postProcess.fade = 0
        end
    end
    
    if not IsNull(_T.CommanderMap) then
        _T.CommanderMap:Close()
    end
    
    _Start(nil, nil, nil, true) -- Expose all script variables to editor
    
    return true
end

function ShutDown(avatar, markerInfo)
    _T.ActiveTacticalMarker = nil
end