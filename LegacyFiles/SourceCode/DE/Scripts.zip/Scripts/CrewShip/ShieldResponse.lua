shieldDepletedFx = Type()
ShieldRestoredFx = Type()


function ShieldDamaged(shieldDeco)
    if not IsNull(shieldDeco) then
        shieldDeco:PlayTriggeredFade()
    end
end

function ShieldDepleted(shieldDeco)
--~     Broadcast("Shield depleted!")
    if not IsNull(shieldDepletedFx) then
        shieldDeco:Attach(shieldDepletedFx, EMPTY_SYMBOL)
    end
    if not IsNull(shieldDeco) then
        shieldDeco:SetVisibility(false)
    end
end

function ShieldRestored(shieldDeco)
--~     Broadcast("Shield restored!")
    if not IsNull(shieldDeco) then
        shieldDeco:SetVisibility(true)
    end
    if not IsNull(ShieldRestoredFx) then
        shieldDeco:Attach(ShieldRestoredFx, EMPTY_SYMBOL)
    end
end