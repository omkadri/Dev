enteringStormAttachEffect = Type("/Lotus/Fx/Gameplay/RailJack/VoidStormLevelAttach")
enteringStormAttachBone = Symbol("GAME_C1_ROOT")
playerFaction = Symbol("TENNO")

shakeCameraScriptTriggerTag = Symbol("VoidStormCameraShake")
pinEnemyMinTimer = 4
pinEnemyMaxTimer = 6
pinMinNumberOfEnemies = 1
pinMaxNumberOfEnemies = 5
pinRagdollEffect = Type()
ragdollAttachEffect = Type("/Lotus/Fx/Gameplay/RailJack/VoidStormEnemyRagdollSpawner")
pinRagdollEndEffect = Type()
--pinProjectileType = Type("/Lotus/Types/Weapons/JavelinProjectile")
--pinDamage = 10000

bossCommanderWRes = WeakResource("/Lotus/Types/Enemies/Grineer/RailJack/Avatars/GrnGalleonCommanderAvatar")

DEBUG_MODE = false

local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"

local mGameRules = nil
local mAiDir = nil
local mPlayer = nil     --local player
local mScriptTrigger = nil
local mShakeCameraScriptTrigger = nil
local mPinEnemyTimer = 5
local mBossAvatar = nil

function EnemyBurst(effect)
    local avatar = effect:GetCreator()
    if IsNull(avatar) then
        return
    end
    
    local anim = avatar:PlayAbilityReactionAnim(Symbol("EXCALIBUR_BLIND"), false, Engine.ATMM_ANIMATION_HORIZ_PHYSICS_VERT, Engine.PRT_NONE, true, RandomInt(0, 2))
    
    if not IsNull(anim) then
        Sleep(anim:GetAnimationLength() * 0.5)
    end
    
    if gRegion:IsMaster() and not avatar:IsKilled() then
        local dd = Engine.DamageData()
        dd.instantKill = true
        dd:SetProc(Game.PT_RAGDOLL, true)
        avatar:DamageDD(dd)
    end
    
    local ragdoll = nil
    while not IsNull(avatar) do
        ragdoll = avatar:GetRagdoll()
        if not IsNull(ragdoll) then
            break
        end
        
        Sleep(0)
    end
    
    if IsNull(ragdoll) then
       return
    end

    ragdoll:Attach(ragdollAttachEffect, EMPTY_SYMBOL)
    
    local t = 0
    local weightFactor = 1
    avatar = ragdoll:GetAvatarOwner()
    local force = Vector()
    local pos = ragdoll:GetCenter()
    local rot = Rotation(Random(-180, 180), 0, 0)
    pos.y = pos.y + 2

    local currentPos = Vector()
    while t < 1 and not IsNull(ragdoll) do
        ragdoll:SetDissolve(t * t)
        
        currentPos = ragdoll:GetCenter()
        force.x = 1 + Noise(Time() * 0.2) * 2 * weightFactor
        force.y = ((pos.y - currentPos.y) * 1 + AbsNoise((Time() + 2) * 0.2)) * weightFactor
        force.z = Noise((Time() + 7)  * 0.2) * 2 * weightFactor
        
        pos.y = pos.y + DeltaTime() * 3
        ragdoll:ApplyGlobalForce(RotateVector(force, rot), 1)
        t = t + DeltaTime() * 0.7
        Sleep(0)
    end
    
    if not IsNull(ragdoll) then
        gRegion:CreateEntity(pinRagdollEndEffect, ragdoll:GetCenter(), ZERO_ROTATION, avatar)
    end
end

local function PinEnemy(playerAvatar)
    mShakeCameraScriptTrigger:Enable()
    mShakeCameraScriptTrigger:RunScripts()
    mShakeCameraScriptTrigger:Disable()

    Sleep(2.0)

    local reactionAnim = Symbol("EXCALIBUR_BLIND")
    local enemiesNear = gRegion:GetPossibleTargetAgentsInRange(playerFaction, playerAvatar:GetPosition(), 40)
    local enemiesSeen = {}
    for i = 1, #enemiesNear do
        if
            not IsNull(enemiesNear[i]) and
            playerAvatar:CanSeeEntityNoRaycast(enemiesNear[i]) > 0.0 and
            not enemiesNear[i]:IsA(bossCommanderWRes) and
            not enemiesNear[i]:IsPlayingAbilityReactionAnim(reactionAnim)
        then
            table.insert(enemiesSeen, enemiesNear[i])
        end
    end

    if enemiesSeen == 0 then
        enemiesSeen = enemiesNear
    end

    if #enemiesSeen > 0 then
        local numOfEnemiesToThrow = RandomInt(pinMinNumberOfEnemies, math.min(pinMaxNumberOfEnemies, #enemiesSeen))
        
        for j = 1, numOfEnemiesToThrow do
            local index = RandomInt(1, #enemiesSeen)
            local enemyAvatarToThrow = enemiesSeen[index]
            table.remove(enemiesSeen, index)
            
            enemyAvatarToThrow:Attach(pinRagdollEffect, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, enemyAvatarToThrow)
            Sleep(math.random(0.05, 0.1))
        end
    end 
end

local function LeavingVoidStorm(playerAvatar)
    local children = playerAvatar:GetAttachment(enteringStormAttachEffect)
    if not IsNull(children) then
        children:Destroy()
    end
end

local function EnteringVoidStorm(playerAvatar)
    if not playerAvatar:HasAttachment(enteringStormAttachEffect) then
        playerAvatar:Attach(enteringStormAttachEffect, enteringStormAttachBone)
    end
end

--Setup the mode for HOST here - this is also called on migration
local function MasterInit()
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    mShakeCameraScriptTrigger = gRegion:FindFirstTagged(shakeCameraScriptTriggerTag)
    mPinEnemyTimer = RandomInt(pinEnemyMinTimer, pinEnemyMaxTimer)
    mBossAvatar = gRegion:FindFirstTagged(Symbol("GalleonCommanderAvatar"))
end

--Setup the mode for HOST and CLIENT here - this is also called on migration, but only for new HOST
local function ReplicaInit()
    mGameRules = gGameRules
    mPlayer = gRegion:GetLocalPlayer()
    local playerAvatar = mPlayer:GetAvatar()

    if not IsNull(playerAvatar) then
        if RJ_UTIL.IsInCapitalShip(playerAvatar) == false then
            LeavingVoidStorm(playerAvatar)
            return
        else
            EnteringVoidStorm(playerAvatar)
        end
    end 
end

--Called on the HOST every frame
local function MasterUpdate(delta)
    if IsNull(mGameRules) or IsNull(mPlayer) then
        return
    end
    
    if mPinEnemyTimer - delta <= 0 then
        local random = Random(0.0, 1.0)
        local pinProbability = 0.5

        if not IsNull(mBossAvatar) then
            mBossAvatar = gRegion:FindFirstTagged(Symbol("GalleonCommanderAvatar"))
            local curHealth = mBossAvatar:GetHealth() / mBossAvatar:GetMaxHealth()
            if curHealth >= 0.75 then
                pinProbability = 0.5
            elseif curHealth < 0.75 and curHealth >= 0.5 then
                pinProbability = 0.65
            elseif curHealth < 0.49 and curHealth >= 0.25 then
                pinProbability = 0.8
            else
                pinProbability = 0.9
            end
        else
            pinProbability = 0.5
        end

        if random > 1 - pinProbability and not IsNull(mPlayer:GetAvatar()) then
            local playerAvatar = mPlayer:GetAvatar()
            PinEnemy(playerAvatar)
        end
        
        mPinEnemyTimer = RandomInt(pinEnemyMinTimer, pinEnemyMaxTimer)
    else
        mPinEnemyTimer = mPinEnemyTimer - delta
    end    
end

--Called on the HOST and CLIENT every frame
local function ReplicaUpdate(delta)
    if IsNull(mGameRules) or IsNull(mPlayer) then
        return
    end

    local playerAvatar = mPlayer:GetAvatar()
    if not IsNull(playerAvatar) then
        if not DEBUG_MODE and RJ_UTIL.IsInCapitalShip(playerAvatar) == false then
            LeavingVoidStorm(playerAvatar)
            return
        end
    end
end

-- The main loop - shouldn't have to add anything here
function VoidEffects(instigator, trigger)  --Run on BOTH

    mScriptTrigger = trigger
    
    if gRegion:IsMaster() then
        MasterInit()
    end
    ReplicaInit()

    local playerAvatar = mPlayer:GetAvatar()
    if not DEBUG_MODE and RJ_UTIL.IsInCapitalShip(playerAvatar) == false then
        return
    end
    
    local migrated = false
    while true do
        Sleep(0)
        while IsNull(mGameRules) do
            Sleep(0)
            mGameRules = gGameRules
            if not IsNull(mGameRules) then
                migrated = true
                while not mGameRules:GameStarted() do
                    Sleep(0)
                end
            end
        end
        
        if migrated then
            if gPromotedToHost then
                MasterInit()
                ReplicaInit()
            end
            migrated = false
        end    
        
        if gRegion:IsMaster() then
            MasterUpdate(DeltaTime())
        end
        ReplicaUpdate(DeltaTime())
    end
end
