encountersToAutoActivate = { WeakResource() }

local CREW_STARTED = 1

function ActivateAllCrewShips()
    local npcMgr = gRegion:GetNpcMgr()
    local aiDir = npcMgr:GetAiDirector()

    while not aiDir:IsEnabled() or not aiDir:HasEncounterMgrCompletedMigration() do 
        Sleep(0)
    end

    local encounters = gRegion:FindAll(gEncounterHintType)

    local encToActivate = { }
    local encsWaitForCrew = { }
    for i=1,#encounters do
        local encounter = encounters[i]

        if not IsNull(encounter) then
            for j = 1, #encountersToAutoActivate do
                if not IsNull(encountersToAutoActivate[j]) and encounter:IsA(encountersToAutoActivate[j]) and encounter:IsActive() == false then
                    table.insert(encToActivate, encounter)
                end
            end
        end
    end

    while #encToActivate > 0 do
        if not aiDir:IsEnabled() or not aiDir:HasEncounterMgrCompletedMigration() then
            print("Host Migration at odd time!")
            break
        end
        for i = #encToActivate, 1, -1 do
            local encHint = encToActivate[i]
            if not IsNull(encHint) then
                local enc = aiDir:ActivateRandomEncounterAtSpecificHint(encHint, 0, 0)

                if not IsNull(enc) then
                    table.insert(encsWaitForCrew, encHint)
                end
            end
            table.remove(encToActivate, i)
            Sleep(0)
        end

        Sleep(0)
    end

    while #encsWaitForCrew > 0 do
        if not aiDir:IsEnabled() or not aiDir:HasEncounterMgrCompletedMigration() then
            print("Host Migration at odd time!")
            break
        end
        for i = #encsWaitForCrew, 1, -1 do
            local encHint = encsWaitForCrew[i]
            
            if IsNull(encHint) then
                table.remove(encsWaitForCrew, i)
            else
                local encState = encHint:GetEncounterStatus()

                if encState >= Npc.ES_ACTIVE then
                    table.remove(encsWaitForCrew, i)
                end
            end
        end
        Sleep(0)
    end
end