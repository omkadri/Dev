crewshipEndObjectiveHintWRes = WeakResource("/Lotus/Types/Gameplay/Crewship/CrewShipEndObjectiveEncounterHint")
overrideMissionEncounters = { WeakResource() }
missionObjectiveTagList = {Symbol("MissionObjective")}

crewShipExtractionDialogTriggerTag = Symbol("CrewShipExtractionDialogTrigger")

aiSpec = Resource()
endOfMatchMovie = Resource("/Lotus/Interface/RailjackMissionComplete.swf")

local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local TABLE = require "Lotus.Scripts.Libs.TableLib"
local RAILOBJ = require "Lotus.Scripts.Libs.RailjackObjectiveUI"

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local mGameRules = nil
local mAiDir = nil
local mRailjackMarker = nil
local mMissionManagerScriptTrigger = nil
local mHasEndOfMissionPlayed = false
local mIntroDialogDone = false

local mActivatedEncounterHint = nil
local mEndObjectiveEncounterHints = { }

local NV_MODE_STATE = Symbol("RJMODE_STATE")
local NV_NUM_PLAYERS = Symbol("NVNumPlayers")

--States 
local INVALID = 0
local ENTERED_RAILJACK_SPACE = 1
local BEGAN_MISSION = 2
local COMPLETED_MISSION = 3
local NO_OBJECTIVES = 4
local LEFT_RAILJACK_SPACE = 5
local mModeState = INVALID
local SetModeState
local sortFunc = function(a, b)     
    if not IsNull(mMissionManagerScriptTrigger) then
        local aDist = mMissionManagerScriptTrigger:DistanceToEntity(a)
        local bDist = mMissionManagerScriptTrigger:DistanceToEntity(b)
        if aDist > bDist then
            return 1
        elseif aDist < bDist then
            return -1
        else
            return 0 
        end
    else
        return 0
    end
end

local function ClearObjectiveUI()
    OBJTXT.ClearTitleObjText()
    OBJTXT.ClearPrimaryObjText()
    OBJTXT.ClearSecondaryObjText()
    RAILOBJ.RemoveReturnUI()
end

local function _ClearRailjackMissionState()
    ClearObjectiveUI()
    SetModeState(ENTERED_RAILJACK_SPACE)
    if gGameRules:IsA(gLotusGameRulesType) then
        gGameRules:SetObjectiveComplete(false)
    end
end

_T.ClearRailjackMissionState = function()
    _ClearRailjackMissionState()
end

function EndObjHintStatusChanged(hint)
    if hint:GetEncounterStatus() == Npc.ES_SUCCEEDED then
        SetModeState(COMPLETED_MISSION)
    end
end

local function ShouldCompleteMission()
    local timeLeft = RAILOBJ.GetReturnTimeLeft()
    if not IsNull(timeLeft) and timeLeft <= 0 then
        return true
    else
        local numOfTennoOnShip = RJ_UTIL.NumOfTennoOnRailjackShip()
        local playerCount = gRegion:GetHumanPlayerAvatarCount()
        if numOfTennoOnShip == playerCount then
            return true
        end
    end
end

local function StartEomMovie() 
    if gRegion:IsMaster() then
        -- commit checkpoint & allow players to free-roam until they choose next mission (this RMI's to clients as well)
        local enemyLevel = gGameRules:GetMission().minEnemyLevel
        gGameRules:CommitInventoryCheckpointToDB(Lotus_Game.LotusGameRules_ICT_RAILJACK, enemyLevel)
    end
    
    _T.RailjackEOMPending = true
end

local function OnModeStateChanged()
    if mModeState == COMPLETED_MISSION then        
        local numOfTennoOnShip = RJ_UTIL.NumOfTennoOnRailjackShip()
        local playerCount = gRegion:GetHumanPlayerAvatarCount()
        if numOfTennoOnShip ~= playerCount and mAiDir:GetObjectiveComplete() == false then
            RAILOBJ.SetReturnUI()
            
            if not IsNull(mRailjackMarker) and not mRailjackMarker:IsEnabled() then
                mRailjackMarker:Enable()
            end
        end
        
        if not IsNull(_T.RailjackStopHullBreach) then
            _T.RailjackStopHullBreach()
        end
        OBJTXT.ClearSecondaryObjText()
        RAILOBJ.RemoveAllCachedTrackers()

        gRegion:GetNpcMgr():GetAiDirector():SetEnableAutoSpawns(false)
    end
end

SetModeState = function(newState)
    if not gRegion:IsMaster() then
        return
    end

    if IsNull(mGameRules) then
        mGameRules = gGameRules
    end

    if mModeState ~= newState then
        mModeState = newState
        mGameRules:SetNetPersistentVar(NV_MODE_STATE, newState)
        OnModeStateChanged()
    else
        print("RailJackMission.lua::SetModeState - trying to set mode to state we're already in")
    end
end

local function ReplicaUpdate()
    if IsNull(mGameRules) then -- or IsNull(mHudMovie) or IsNull(mPlayer) then
        return
    end

    local modeState = mGameRules:GetNetPersistentVar(NV_MODE_STATE, INVALID)
    if modeState >= ENTERED_RAILJACK_SPACE and modeState < LEFT_RAILJACK_SPACE and not mIntroDialogDone then
        if not IsNull(gGameData) then
            if gGameData:HasCompletedNodeIntro(Symbol("RailjackMultiToolIntro")) then
                mIntroDialogDone = true
            else
                local playerAv = gRegion:GetLocalPlayerAvatar()
                if not IsNull(playerAv) then 
                    local omniToolTransmission = WeakResource("/Lotus/Sounds/Dialog/RailJack/CephalonCy/DTutToolAdd2620RJCephalon")
                    playerAv:GiveTransmissionAsync(omniToolTransmission)
                    gGameData:SetNodeIntroCompleted(Symbol("RailjackMultiToolIntro"))
                    mIntroDialogDone = true
                end
            end
        end
    end
    
    if modeState == COMPLETED_MISSION and mHasEndOfMissionPlayed == false then
        if ShouldCompleteMission() then
            StartEomMovie()
            mHasEndOfMissionPlayed = true
        end
    end
end

local function IsInStarChartMission()
    local mission = gGameRules:GetMission()
    return mission.name ~= EMPTY_SYMBOL and not IsNull(gGameRules:GetMission().levelOverride)
end

local function ArePlayersGoingToHyperSpace()
    local crewShipMgr = gGameRules:GetCrewShipManager()
    if IsNull(crewShipMgr) then
        return false
    end
    local ship = crewShipMgr:GetPlayerShip()
    if IsNull(ship) then
        return false
    end
    local crewShipAvatar = ship:GetAvatarOwner()
    if IsNull(crewShipAvatar) then
        return false
    end
    return(crewShipAvatar:GetHyperDriveState() == Lotus_Game.CrewShipAvatar_HDS_POWERING_UP)
end

local function MasterUpdate()

    local modeState = mGameRules:GetNetPersistentVar(NV_MODE_STATE, INVALID)
    if mModeState ~= modeState then
        mModeState = modeState
        OnModeStateChanged()
    end

    if mModeState < BEGAN_MISSION and mAiDir:GetObjectiveComplete() == false then
        local aiDir = gRegion:GetNpcMgr():GetAiDirector()
        if IsNull(aiDir) then
            return
        end

        while not aiDir:HasEncounterMgrCompletedMigration() do
            Sleep(0)
        end
        
        --init the NV_NUM_PLAYERS NetVar for other mission scripts
        local numPlayers = math.min(gRegion:GetHumanPlayerAvatarCount() + gFlashMgr:GetConfigInt("Server.NumVirtualTestClients"), 4) --gRegion:GetNumHumanPlayers()
        gGameRules:SetNetPersistentVar(NV_NUM_PLAYERS, numPlayers)

        if #overrideMissionEncounters > 0 then
            --first check if any of these MissionEncounter types are already active after host migration
            for i=1,#overrideMissionEncounters do
                mActivatedEncounterHint = aiDir:FindFirstActiveEncounterOfType(overrideMissionEncounters[i])
                if not IsNull(mActivatedEncounterHint) then
                    break
                end
            end
            
            -- if nothing is active, then pick one at random and activate it
            if IsNull(mActivatedEncounterHint) then
                local randIndex = RandomInt(1, #overrideMissionEncounters)
                local encounterType = overrideMissionEncounters[1]
                mActivatedEncounterHint = aiDir:ActivateSpecificEncounterAtPos(ZERO_VECTOR, encounterType, nil, 0)
            end
        elseif #mEndObjectiveEncounterHints > 0 then
            --check if any placed MissionObjective EncounterHints are active after host migration
            for i=1,#mEndObjectiveEncounterHints do 
                if mEndObjectiveEncounterHints[i]:IsActive() then
                    mActivatedEncounterHint = mEndObjectiveEncounterHints[i]
                    break
                end
            end
            
            -- if nothing is active, then pick one at random and activate it
            if IsNull(mActivatedEncounterHint) then
                local randIndex = RandomInt(1, #mEndObjectiveEncounterHints)
                local encounterHint = mEndObjectiveEncounterHints[randIndex]
                mActivatedEncounterHint = aiDir:ActivateRandomEncounterAtSpecificHint(encounterHint, 0, 0)
            end
        else 
            -- no hard-coded mission objective encounters found in the level
            -- first try find if a "MissionObjective" tagged encounter is already active after host migration 
            -- if not, try to activate one that has been included with the AI spec for this node
            mActivatedEncounterHint = aiDir:FindFirstActiveEncounterWithTags(missionObjectiveTagList)
            if IsNull(mActivatedEncounterHint) then
                mActivatedEncounterHint = mAiDir:ActivateRandomEncounterAtPos(ZERO_VECTOR, missionObjectiveTagList, Npc.ET_NONE, Npc.ET_NONE)
            end
        end

        if not IsNull(mActivatedEncounterHint) then
            mActivatedEncounterHint:RegisterStatusChangedCallback("EndObjHintStatusChanged", Symbol("RailjackEndObjCallback"))
            SetModeState(BEGAN_MISSION)
        else 
            print("RailJackMission.lua::Update - no active objective")
            local isStarChartMission = IsInStarChartMission()
            if isStarChartMission then
                _T.RailjackEOMPending = true
            end
            mHasEndOfMissionPlayed = true
            mAiDir:SetObjectiveComplete(isStarChartMission) -- test levels won't have objective hints, so let's not send all the NPCs away
            SetModeState(NO_OBJECTIVES)--COMPLETED_MISSION)
        end
    elseif mModeState >= ENTERED_RAILJACK_SPACE and mModeState < LEFT_RAILJACK_SPACE then
        if ArePlayersGoingToHyperSpace() then
            _ClearRailjackMissionState()
             SetModeState(LEFT_RAILJACK_SPACE)
             mAiDir:EnableEncounters(false) --don't allow any more encounters to activate while we prepare to warp away
        elseif mModeState == COMPLETED_MISSION then
            if ShouldCompleteMission() and mAiDir:GetObjectiveComplete() == false then
                gGameRules:SetObjectiveComplete(true)
                mAiDir:SetObjectiveComplete(true)
                ClearObjectiveUI()
            end
        end
    end
end

local function ReplicaInit()
    if IsNull(mAiDir) then
        mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    end
end

local function MasterInit(migrated)
    mAiDir = gRegion:GetNpcMgr():GetAiDirector()
    if IsNull(mGameRules) then
        mGameRules = gGameRules
    end
    local modeState = mGameRules:GetNetPersistentVar(NV_MODE_STATE, INVALID)
    if migrated and modeState == COMPLETED_MISSION then
        print("Migration After Mission Complete")
        mModeState = modeState
        mHasEndOfMissionPlayed = true
        OnModeStateChanged()
    else
        _ClearRailjackMissionState()
    end
    
    --Setup agetns if no AiSpec is loaded from mission; i.e. loading a test level
    if not IsNull(aiSpec) and IsNull(gGameRules:GetMission().enemySpec) and not IsInStarChartMission() then
        local missionAI = aiSpec:GetEnemies()
        for i=1,#missionAI do
            local mai = missionAI[i]
            local prob = mai.probability
            local agent = mai.agent
            local maxSim = mai.maxSimultaneous
            local tier = mai.tier
            local agentType = Type(agent)
            local mergeSymbol = mai.mergeSymbol
            if not IsNull(agentType) then
                mAiDir:AddMissionAIType(agentType, prob, maxSim, tier, mergeSymbol)
            else
                print("NULL agent type!")
            end
        end

        local npcEncounters = aiSpec:GetNpcEncounters()
        for i=1, #npcEncounters do
            mAiDir:AddEncounter(Type(npcEncounters[i]))
        end
    end

    mEndObjectiveEncounterHints = gRegion:FindAll(crewshipEndObjectiveHintWRes)
    TABLE.QuickSort(mEndObjectiveEncounterHints, sortFunc)

    if mModeState == BEGAN_MISSION and mAiDir:GetObjectiveComplete() == false then
        if #overrideMissionEncounters > 0 then
            local dynamicHints = gRegion:FindAll(crewshipEndObjectiveHintWRes)
            
            for i=1,#dynamicHints do
                local hint = dynamicHints[i]

                --find 
            end
        else
            for i=1,#mEndObjectiveEncounterHints do
                local encounterHint = mEndObjectiveEncounterHints[i]

                if not IsNull(encounterHint) and encounterHint:IsActive() then
                    mActivatedEncounterHint = encounterHint
                end
            end            
        end

        if not IsNull(mActivatedEncounterHint) then
            mActivatedEncounterHint:RegisterStatusChangedCallback("EndObjHintStatusChanged", Symbol("RailjackEndObjCallback"))
        end
    elseif mModeState == NO_OBJECTIVES then
        mHasEndOfMissionPlayed = true
        mAiDir:SetObjectiveComplete(false) -- test levels won't have objective hints, so let's not send all the NPCs away
    elseif mModeState == COMPLETED_MISSION then
        if ShouldCompleteMission() and mAiDir:GetObjectiveComplete() == false then
            gGameRules:SetObjectiveComplete(true)
            mAiDir:SetObjectiveComplete(true)
            ClearObjectiveUI()
        end
    end
end

local function MigrationInit()

    -- Before migration this code runs from the StreamMission.lua, but only for the host

    local mainLayer = 0
    local portForwarders = gRegion:FindTagged(Symbol("OnLevelStreamed"))
    
    for i,portForwarder in ipairs(portForwarders) do
        if not IsNull(portForwarder) then
            local regionIndex = Engine.Zone_GetRegionInstance(portForwarder:GetFullName())
            if regionIndex == mainLayer then
                portForwarder:FirePort("TriggerPort")
            end
        end
    end
end

function RailjackMission(scriptTrigger)
    mMissionManagerScriptTrigger = scriptTrigger
    mModeState = gGameRules:GetNetPersistentVar(NV_MODE_STATE, INVALID)

    local crewShipMgr = gGameRules:GetCrewShipManager()
    -- Wait for the ship to finish
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    while not IsNull(crewShipMgr) and (crewShipMgr:IsLoadingShip(true) or IsNull(crewShipMgr:GetPlayerShip())) do
        Sleep(0)
    end

    if gRegion:IsMaster() then
        MasterInit(false)
    end
    ReplicaInit()
    
    local shipAvatar = crewShipMgr:GetPlayerShip():GetAvatarOwner()
    local railjackTracker = nil

    if not IsNull(_T.AddHudTracker) and not IsNull(shipAvatar) then
        railjackTracker = _T.AddHudTracker("RailjackHealthTracker", LOTUS_UTIL.HT_HEALTH_TRACKER, 0.25, 1, false)
        railjackTracker.SetTarget(shipAvatar)
        local ugcRestricted = true
        local profile = gPlayerProfileMgr:GetPlayerProfile(0)
        if not IsNull(profile) and profile:IsUGCAllowed() then
            ugcRestricted = false
        end
        local name = nil
        if not ugcRestricted then
            local inventoryController = shipAvatar:InventoryControl()
            if not IsNull(inventoryController) then
                local shipSuit = inventoryController:GetActivePowerSuit()
                if not IsNull(shipSuit) then
                    name = tostring(shipSuit:GetLocalizeTag())
                end
            end
        end

        if name == nil or name == "" then
            railjackTracker.SetNameOverride("/Lotus/Language/Railjack/Railjack")
        else
            railjackTracker.SetNameOverride(name)
        end
        
        railjackTracker.SetIgnorePredeath(true)
    end
    
    if not IsNull(_T.ShowAbilityPanel) then
        _T.ShowAbilityPanel()
    end

    -- while not mAiDir:HasEncounterMgrCompletedMigration() do
    --     Sleep(0)
    -- end
    
    local migrated = false
    while not gGameRules:IsEnding() do
        Sleep(0)
        while IsNull(mGameRules) do
            Sleep(0)
            mGameRules = gGameRules
            if not IsNull(mGameRules) then
                migrated = true
                print("RailjackMission migrating!")
                while not mGameRules:GameStarted() do
                    Sleep(0)
                end
            end
        end
        
        if migrated then
            if gPromotedToHost then
                print("RailjackMission after migration PromotedToHost!")
                MasterInit(true)
                ReplicaInit()
                MigrationInit()
            end
            
            local shipAvatar = crewShipMgr:GetPlayerShip():GetAvatarOwner()
            if not IsNull(_T.AddHudTracker) and not IsNull(shipAvatar) then
                railjackTracker = _T.AddHudTracker("RailjackHealthTracker", LOTUS_UTIL.HT_HEALTH_TRACKER, 0.25, 1, false)
                railjackTracker.SetTarget(shipAvatar)
                local ugcRestricted = true
                local profile = gPlayerProfileMgr:GetPlayerProfile(0)
                if not IsNull(profile) and profile:IsUGCAllowed() then
                    ugcRestricted = false
                end
                local name = nil
                if not ugcRestricted then
                    local inventoryController = shipAvatar:InventoryControl()
                    if not IsNull(inventoryController) then
                        local shipSuit = inventoryController:GetActivePowerSuit()
                        if not IsNull(shipSuit) then
                            name = tostring(shipSuit:GetLocalizeTag())
                        end
                    end
                end

                if name == nil or name == "" then
                    railjackTracker.SetNameOverride("/Lotus/Language/Railjack/Railjack")
                else
                    railjackTracker.SetNameOverride(name)
                end
                railjackTracker.SetIgnorePredeath(true)
            end
            
            migrated = false
        end    
        
        mModeState = mGameRules:GetNetPersistentVar(NV_MODE_STATE, INVALID)
        if gRegion:IsMaster() then
            MasterUpdate(DeltaTime())
        end
        ReplicaUpdate(DeltaTime())
    end
    
    if not IsNull(mActivatedEncounterHint) then
        mActivatedEncounterHint:SetEncounterStatus(Npc.ES_SHUTDOWN)
    end
    
    if not IsNull(_T.RemoveHudTracker) and not IsNull(railjackTracker) then
        _T.RemoveHudTracker(railjackTracker)
    end
end

local function FindStealthAvatars(crewShipMgr)
    local avatars = gRegion:GetLocalPlayerAvatars()
    local crewships = crewShipMgr:GetShips(true)

    for i,ship in ipairs(crewships) do
        local shipAvatar = ship:GetAvatarOwner()
        if not IsNull(shipAvatar) then
            table.insert(avatars, shipAvatar)
        end
    end
    return avatars
end

local SYM_RJ_STEALTH = Symbol("RailjackProximityStealth")

function StealthUpdateLoop()
    local DEFAULT_STEALTH_RADIUS = 50 -- For testing, until all the avatars we want to apply stealth to have the correct upgrades
    local DRAW_TIME = 0.14
    local MIN_STEALTH_BOUNDS = 50
    local LARGE_STEALTH_BOUNDS = 20

    local crewShipMgr
    while(IsNull(crewShipMgr)) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end
    
    local wasStealthEnabled = gFlashMgr:GetConfigBool("Lotus.Railjack.ProximityStealth");

    while true do
        while not gFlashMgr:GetConfigBool("Lotus.Railjack.ProximityStealth") do
            if wasStealthEnabled then
                local avatars = FindStealthAvatars(crewShipMgr)
                for i,avatar in ipairs(avatars) do
                    local found, prevUpgrade = avatar:GetBlackboardFloat(SYM_RJ_STEALTH)
                    if (found) then
                        avatar:InventoryControl():RemoveUpgrade(Game.AVATAR_NPC_VIS_RANGE, Game.MULTIPLY, prevUpgrade)
                    end
                end
                wasStealthEnabled = false
            end
            Sleep(0.5)
        end

        wasStealthEnabled = true

        -- One overlap test per frame?
        local DEBUG_DRAW = gFlashMgr:GetConfigBool("Debug.Draw.AI.Perception.StealthLevel")

        -- Find players & crew ships
        local avatars = FindStealthAvatars(crewShipMgr)
        
        for i,avatar in ipairs(avatars) do
            -- Get the next registered avatar
            if not IsNull(avatar) then
                if IsNull(crewShipMgr:GetShipForZone(avatar:GetZone())) then
                
                    -- Calculate center
                    local boundsMin = avatar:GetBoundsMin()
                    local boundsMax = avatar:GetBoundsMax()
                    local boundsCenter = (boundsMin + boundsMax) / 2
                    local boundsSize = Distance(boundsMin, boundsMax)
                
                    -- Calculate test radius
                    local radius = avatar:InventoryControl():GetUpgradeModifiedValue(0.0, Game.AVATAR_STEALTH_MIN_OCCLUSION_RADIUS)
                    if radius > 0.0 then
                        local innerRadius = avatar:InventoryControl():GetUpgradeModifiedValue(0.0, Game.AVATAR_STEALTH_FULL_OCCLUSION_RADIUS)
                        if innerRadius >= radius then
                            innerRadius = math.max(radius - 0.001, 0.0)
                        end

                        local stealthMax = 1.0 --Placeholder, can add upgrade types for this
                        local stealthMin = 0.2 --Placeholder, can add upgrade types for this

                        local stealthRange = Range(innerRadius, radius)
                        local multRange = Range(stealthMin, stealthMax)
                        
                        -- Run overlap test
                        -- Will need to rewrite this in c++ soon, since filtering options from script aren't good enough
                        local ignoreTypes = { gAvatarType, gScriptTriggerType }
                        local allOverlappers = gRegion:FindRadiusEntities(avatar:GetPosition(), radius, nil, ignoreTypes)

                        -- Calculate coverage
                        local closest = FLT_MAX

                        for i,v in ipairs(allOverlappers) do
                            if not IsNull(v) then
                                local root = v:GetAttachRoot()
                                if not root:IsA(gAvatarType) then 
                                    local eBoundsMax = root:GetBoundsMax()
                                    local eBoundsMin = root:GetBoundsMin()
                                    local eBoundsCenter = (eBoundsMin + eBoundsMax) / 2
                                    local eBoundsSize = Distance(eBoundsMin, eBoundsMax)
                                    
                                    local boxColor = Color(255, 255, 255)
                                    
                                    if eBoundsSize >= boundsSize then
                                        boxColor = Color(100, 100, 255)
                                        
                                        -- Only use entities that are larger than us for proximity
                                        local targets =
                                        {
                                            eBoundsCenter,
                                            eBoundsMin,
                                            Vector(eBoundsMax.x, eBoundsMin.y, eBoundsMin.z),
                                            Vector(eBoundsMin.x, eBoundsMin.y, eBoundsMax.z),
                                            Vector(eBoundsMax.x, eBoundsMin.y, eBoundsMax.z),
                                            Vector(eBoundsMin.x, eBoundsMax.y, eBoundsMin.z),
                                            Vector(eBoundsMax.x, eBoundsMax.y, eBoundsMin.z),
                                            Vector(eBoundsMin.x, eBoundsMax.y, eBoundsMax.z),
                                            eBoundsMax
                                        }

                                        for i,target in ipairs(targets) do
                                            local hitEntity
                                            local hitPoint = Vector()
                                            hitEntity = gRegion:RaycastIgnoreTypes(boundsCenter, target, ignoreTypes, hitEntity, hitPoint)

                                            if not IsNull(hitEntity) and hitEntity:GetAttachRoot() == root then
                                                local distance = Distance(boundsCenter, hitPoint)
                                                
                                                if distance < closest then
                                                    closest = distance
                                                end

                                                if DEBUG_DRAW then
                                                    local ratio = stealthRange:MapFromRange(stealthRange:Clamp(distance))
                                                    gRegion:VisAddLine(boundsCenter, hitPoint, Color(255 * ratio, 255 - (255 * ratio), 0), DRAW_TIME)
                                                    gRegion:VisAddLine(hitPoint, target, Color(100, 100, 100), DRAW_TIME)
                                                end
                                            elseif DEBUG_DRAW then
                                                gRegion:VisAddLine(boundsCenter, target, Color(155, 0, 0), DRAW_TIME)
                                            end
                                        end
                                    end
                                    
                                    --local eBoundsCenter = (eBoundsMin + eBoundsMax) / 2
                                    if DEBUG_DRAW then
                                        gRegion:VisAddBounds(root, boxColor, DRAW_TIME)
                                    end
                                    Sleep(0)
                                end
                            end
                        end
                        
                        local found, prevUpgrade = avatar:GetBlackboardFloat(SYM_RJ_STEALTH)
                        if (found) then
                            avatar:InventoryControl():RemoveUpgrade(Game.AVATAR_NPC_VIS_RANGE, Game.MULTIPLY, prevUpgrade)
                        end

                        local VISIBLE_COLOR = Color(255, 0, 0)
                        local HIDDEN_COLOR = Color(0, 255, 0)
                        
                        if closest < FLT_MAX then
                            local ratio = stealthRange:MapFromRange(stealthRange:Clamp(closest))
                            local stealthVal = multRange:MapToRange(ratio)
                            
                            avatar:InventoryControl():AddUpgrade(Game.AVATAR_NPC_VIS_RANGE, Game.MULTIPLY, stealthVal)
                            avatar:SetBlackboardFloat(SYM_RJ_STEALTH, stealthVal)
                        else
                            avatar:ClearBlackboardValue(SYM_RJ_STEALTH)
                        end

                        if DEBUG_DRAW then
                            gRegion:VisAddWireCapsule(boundsCenter, boundsCenter, radius, VISIBLE_COLOR, DRAW_TIME)
                            gRegion:VisAddWireCapsule(boundsCenter, boundsCenter, innerRadius, HIDDEN_COLOR, DRAW_TIME)
                        end
                    end
                end
            end
            Sleep(0)
        end
    end
end

local function ForceCompleteSkirmish()
    -- debug cheat only
    if not gFlashMgr:GetConfigBool("Engine.DeveloperMode") then
        return
    end
    SetModeState(COMPLETED_MISSION)
end
_T.CompleteSkirmish = ForceCompleteSkirmish

local function ForceFailSkirmish()
    -- debug cheat only
    if not gFlashMgr:GetConfigBool("Engine.DeveloperMode") then
        return
    end
    
    gGameRules:SetReturnToLobbyCallback(
        function()
            local destinationLevel = "CrewBattleNodeDojo"
            _T.RailJackNextMissionNode = Symbol(destinationLevel)
            _T.SeamlessRailJackTransition = gGameRules:IsA(gLotusAttractModeGameRulesType)
                
            local sectorInfo = { name = destinationLevel, difficulty = 0 }
            local sectorJSON = cjson.encode(sectorInfo)
            gMatchingService:SendSquadMission(sectorJSON)

            local travelSector = LOTUS_UTIL.GetStarChart():GetNodeForMission(Symbol("CrewShipGenericTunnel"))
            gGameRules:GetCrewShipManager():SetNextMission(travelSector.mission)

            if not IsNull(_T.ClearRailjackMissionState) then
                _T.ClearRailjackMissionState()
            end
        end
    )

    gGameRules:EndGame(Engine.GameRules_GS_FAILURE, 0)
end
_T.FailSkirmish = ForceFailSkirmish
