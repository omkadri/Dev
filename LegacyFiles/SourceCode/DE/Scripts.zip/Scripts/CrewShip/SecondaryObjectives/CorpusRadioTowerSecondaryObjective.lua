
updateDeltaTime = 1
radioTowerTag = Symbol("RadioTowerSecObj")

local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"

local NV_SECONDARY_OBJECTIVE_STATE = Symbol("RJSECONDARY_OBJ_STATE")
local SECONDARY_OBJ_STARTED = 1
local SECONDARY_OBJ_COMPLETED = 2

local mRadioTowerDeco = nil
local mSecObjectiveMarker = nil
local mSecObjectiveScriptTrigger = nil

local function Update(deltaTime)

end

local function Initialize()
    mSecObjectiveMarker = mRadioTowerDeco:GetAttachment(gBaseMarkerInfoType)

    if not IsNull(mSecObjectiveMarker) and mSecObjectiveMarker:IsEnabled()  == false then
        mSecObjectiveMarker:Enable()
    end

    OBJTXT.SetSecondaryObjText("/Lotus/Language/Railjack/DestroyRadioTower", 2)
end

function OnDestroyed(deco)
    --if radiotower is destroyed, then flag script trigger for regionmanager to see secondary is complete.
    local secondaryObjectiveState = gGameRules:GetNetPersistentVar(NV_SECONDARY_OBJECTIVE_STATE, SECONDARY_OBJ_STARTED)
    if secondaryObjectiveState == SECONDARY_OBJ_STARTED then
        gGameRules:SetNetPersistentVar(NV_SECONDARY_OBJECTIVE_STATE, SECONDARY_OBJ_COMPLETED)
    end

    OBJTXT.ClearSecondaryObjText() 
end

function CorpusRadioTowerObjective(scriptTrigger)
    mSecObjectiveScriptTrigger = scriptTrigger
    local radioTowerDecoration = gRegion:FindFirstTagged(radioTowerTag)

    if not IsNull(radioTowerDecoration) then
        mRadioTowerDeco = radioTowerDecoration
        ObjectPortHandler(mRadioTowerDeco, "OnDestroyed")
        mRadioTowerDeco:MakeVulnerable()

        while (gClient:IsLoadingScreenOpen() or not IsNull(gRegion:GetPlayingCinematic())) do
            Sleep(0)
        end
        
        Initialize()

        while true do
            Update(updateDeltaTime)
            Sleep(updateDeltaTime)
        end
    end
end
