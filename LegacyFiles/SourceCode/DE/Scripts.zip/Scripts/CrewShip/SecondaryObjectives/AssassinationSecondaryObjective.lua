
updateDeltaTime = 1

assassinationTargetAgentType = Type()
enemyTeam = Symbol()

local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"

local NV_SECONDARY_OBJECTIVE_STATE = Symbol("RJSECONDARY_OBJ_STATE")
local SECONDARY_OBJ_STARTED = 1
local SECONDARY_OBJ_COMPLETED = 2

local mAssassinationAgent = nil
local mSecObjectiveMarker = nil
local mSecObjectiveScriptTrigger = nil

local function Update(deltaTime)

end

local function Initialize()
    if not IsNull(assassinationTargetAgentType) then
        local aiDir = gRegion:GetNpcMgr():GetAiDirector()
        local spawnPosition = aiDir:GetClosestWorldPointOnNavMeshScript(mSecObjectiveScriptTrigger:GetPosition())
        local spawnRot = Rotation()
        mAssassinationAgent = aiDir:CreateAgentAtPosition(assassinationTargetAgentType, spawnPosition, spawnRot, enemyTeam, aiDir:GetMaxEnemyLevel(), nil)

        while IsNull(mAssassinationAgent:GetAvatar()) do
            Sleep(0.1)
        end

        mAssassinationAgent:SetIsIgnoredByAiDirector(true)
        ObjectPortHandler(mAssassinationAgent:GetAvatar(), "OnKilled")
    end

    mSecObjectiveMarker = mAssassinationAgent:GetAvatar():GetAttachment(gBaseMarkerInfoType)

    if not IsNull(mSecObjectiveMarker) and mSecObjectiveMarker:IsEnabled() == false then
        mSecObjectiveMarker:Enable()
    end

    OBJTXT.SetSecondaryObjText("/Lotus/Language/Railjack/AssassinateTheCaptain", 2)
end 

function OnKilled(avatar)
    local secondaryObjectiveState = gGameRules:GetNetPersistentVar(NV_SECONDARY_OBJECTIVE_STATE, SECONDARY_OBJ_STARTED)
    if secondaryObjectiveState == SECONDARY_OBJ_STARTED then
        gGameRules:SetNetPersistentVar(NV_SECONDARY_OBJECTIVE_STATE, SECONDARY_OBJ_COMPLETED)
    end

    OBJTXT.ClearSecondaryObjText() 
end

function AssassinationSecondaryObjective(scriptTrigger)
    mSecObjectiveScriptTrigger = scriptTrigger

    Initialize()

    while not IsNull(mAssassinationAgent) do
        Update(updateDeltaTime)
        Sleep(updateDeltaTime)
    end
end
