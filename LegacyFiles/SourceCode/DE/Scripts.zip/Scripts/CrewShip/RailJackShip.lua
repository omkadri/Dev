screenType = Type()
HBColorCorrection = Resource()
wait = true
shakeSound = Resource()
shakeScript = Instance()
avatarType = Type()
evilTwinType = Type()
keyChainWRes = WeakResource()

enterBreachSound = Resource()
leaveBreachSound = Resource()

firePortTag = Symbol()
firePortName = Symbol()

transmissionTag = Symbol()
railjackTransmissionSet = Resource()
mixerArray = {Resource()}
occlusionFilter = Resource()
tagsToDisable = { Symbol() }
tagsToEnable = { Symbol() }
instancesToDisable = { Instance() }

-- Generic hack panel
buttonScreen = Instance()
buttonPortForwarder = Instance()
buttonLight = Instance()
buttonScreenOff = Resource()
failedPortFowarder = Instance()
disableOnUse = true

-- Generic hack panel multiple decos
decorationsToMaterialSwap = {Instance()}
materialsToSwap = {Resource()}
materialSlots = { 0 }

successForwarder = Instance()

--maxCut = -60.0
fadeOutTime = 3.0
fadeInTime = 1.0
--waitTime = 0.0
filterAmount = 1.0

-- New
alarmBank = Resource()
onMaterialsCorpus = {Resource()}
alertMaterialsCorpus = {Resource()}
offMaterialsCorpus = {Resource()}
onMaterialsGrineer = {Resource()}
alertMaterialsGrineer = {Resource()}
offMaterialsGrineer = {Resource()}
---

-- Breakable glass
glassPanes = {Instance()}
--crackedMaterials = {Resource()}
materialSlot = 0
--health = 100

local crackedChance = 0.25
local crackedChanceFire = 0.35
local crackedChanceIce = 0.35
local crackedChanceInfested = 0.4

local PANIC = require "Lotus.Scripts.Libs.PanicLib"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local GAMEMODE = require "Lotus.Scripts.Libs.CommonGamemodeFunctions"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"
local OPERATOR = require "Lotus.Powersuits.Operator.OperatorLib"
local STORY = require "Lotus.Scripts.Libs.StoryLib"
-- Gamemodes

PurgeTint = Color(140,140,140,140)
PurgeFlashTint = Color(255, 0, 0, 255)

local mEmissiveTintColor = Symbol("EmissiveTintColor")
local mEmissiveTintColorHi = Symbol("EmissiveTintColorHi")
local mEmissiveTintColorLo = Symbol("EmissiveTintColorLo")

--[[
local function avatarStumbler(entity,Avatars)
    if not IsNull(Avatars) then
        for x =1, #Avatars do
            local temp = Avatars[x]
            local impulseDir = entity:GetPosition() - temp:GetPosition()
            Normalize(impulseDir)
            
            local dd = Engine.DamageData()
            dd.baseAmount = 1
            dd:SetProc(Game.PT_STAGGERED, true)
            dd:SetSource(entity)
            dd:SetSourceObject(entity)
            dd:SetHitPart(Engine.TORSO)
            dd:SetImpulse(impulseDir * 500)
            
            temp:DamageDD(dd)
        end
    end
end
]]--

function ShutterShake()
    local playerAvatars = gRegion:GetHumanPlayerAvatars()
    if IsNull(playerAvatars) then
        return
    end
    local player = playerAvatars[1]
    local postProcess = gRegion:GetLevelInfo().postProcess
    local soundInst

    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()

    while aiDir:GetHullBreach() == true do
        local pos = player:GetPosition()
        soundInst = gRegion:PlaySound(shakeSound,pos,false)
        while not IsNull(soundInst) and aiDir:GetHullBreach() == true do
            local amp = soundInst:GetCurAmplitude()
            postProcess.viewShake.mShakeAmbient = amp  * 10
            Sleep(0) 
        end
        Sleep(0)
    end
    Sleep(4)
    postProcess.viewShake.mShakeAmbient = 0
    if not IsNull(soundInst) then
        soundInst:Stop(false)
    end
end

function CinShutterShake()
    local playerAvatars = gRegion:GetHumanPlayerAvatars()
    if IsNull(playerAvatars) then
        return
    end
    local player = playerAvatars[1]
    local postProcess = gRegion:GetLevelInfo().postProcess
    local soundInst
    local pos = player:GetPosition()
    soundInst = gRegion:PlaySound(shakeSound,pos,false)
    while not IsNull(soundInst) do
        local amp = soundInst:GetCurAmplitude()
        postProcess.viewShake.mShakeAmbient = amp  * 10
        Sleep(0) 
    end
end

function RandomizeGlass()
    if gPromotedToHost then
        return
    end
        
    local chance = crackedChance
    if _T.FxLayer == Symbol("Ice") then
        chance = crackedChanceIce
    elseif _T.FxLayer == Symbol("Fire") then
        chance = crackedChanceFire
    elseif _T.FxLayer == Symbol("Infested") then
        chance = crackedChanceInfested
    end

    if _T.faction == Symbol("RedVeil") then -- Harrow Quest
        chance = 0
    end

    for i = 1, #glassPanes do
        local zoneTag = glassPanes[i]:GetZone():GetTag()
        local r = Random(0,1)
        if r <= chance and zoneTag ~= Symbol("Spawn") then
            --local m = RandomInt(1,#crackedMaterials)
            --glassPanes[i]:SetOverrideMaterial(materialSlot, crackedMaterials[m])
            glassPanes[i]:FirePort("MaterialSwitch")
        else
            glassPanes[i]:FirePort("Make invulnerable")
        end
    end
end

function RaiseLevelAlertState()
    -- To Do: Remove scripttriggers
end

function PanicButton(avatar, result, action)
    if not gRegion:IsMaster() then
        return
    end
    if not IsNull(avatar:GetAgent()) or result == nil or result == 1 then
        PANIC.PanicButtonActivated(avatar, action, alarmBank) -- Replaces PanicMaster script
    end
end


function OnAvatarEnterBreach(avatar)
    local cameracontrol = avatar:CameraControl()

    if not IsNull(cameracontrol) then
        cameracontrol:PushColorCorrection(HBColorCorrection,3,-1,0)
    end
    
    if avatar:ReplicaLocallyControlled() then
        if IsNull(occlusionFilter) or IsNull(mixerArray) then
            return
        end

        if fadeInTime > 0.0 then
            local t = 1.0 
            while t > 0.0 do
                local amount = Lerp(filterAmount, 0.0, t) 
                for i = 1, #mixerArray do
                    mixerArray[i]:UpdateDynamicFilter(occlusionFilter, amount)
                end
                t = t - RealDeltaTime() / fadeInTime
                Sleep(0)
            end
        else           
            for i = 1, #mixerArray do
                mixerArray[i]:UpdateDynamicFilter(occlusionFilter, filterAmount)
            end
        end
        
        for i = 1, #mixerArray do
            mixerArray[i]:UpdateDynamicFilter(occlusionFilter, filterAmount)
        end
    end
end

function OnAvatarLeaveBreach(avatar)

    local cameracontrol = avatar:CameraControl()
    if not IsNull(cameracontrol) then
        cameracontrol:RemoveColorCorrection(HBColorCorrection)
    end

    if avatar:ReplicaLocallyControlled() then
        if IsNull(mixerArray) then
            return
        end

        if not IsNull(occlusionFilter) and fadeOutTime > 0.0 then
            local t = 1.0 
                while t > 0.0 do
                local amount = Lerp(0.0, filterAmount, t) 
                for i = 1, #mixerArray do
                    mixerArray[i]:UpdateDynamicFilter(occlusionFilter, amount)
                end
                t = t - RealDeltaTime() / fadeOutTime
                Sleep(0)
            end
        end

        for i = 1, #mixerArray do
            mixerArray[i]:ClearSoundFilter()
        end
    end
end

function GenericHackPanel(avatar, result, instigator)
    if IsNull(avatar) then
        return
    end
    
    if not IsNull(avatar:GetAgent()) then
        result = 1
    end
    
    if result == nil then
        result = 1
    end

    if result == 1 then
        if not IsNull(buttonPortForwarder) then
            buttonPortForwarder:FirePort("TriggerPort")
        end
        if disableOnUse then
            if not IsNull(buttonLight) then
                buttonLight:TurnOff()
            end
            if not IsNull(buttonScreen) then
                buttonScreen:SetOverrideMaterial(materialSlot, buttonScreenOff)
            end
            instigator:FirePort("Disable")
        end
    elseif not IsNull(failedPortFowarder) then
        -- don't trigger alarms in sortie missions -- players get damaged instead
        local missionInfo = gGameRules:GetMission()
        if missionInfo.sortieId == "" then
            failedPortFowarder:FirePort("TriggerPort")
        end
    end
end

function GenericHackPanelMultiDecos(avatar, result, instigator)
    if IsNull(avatar) then
        return
    end
    
    if not IsNull(avatar:GetAgent()) then
        result = 1
    end
    
    if result == nil then
        result = 1
    end

    if result == 1 then
        if not IsNull(buttonPortForwarder) then
            buttonPortForwarder:FirePort("TriggerPort")
        end
        if disableOnUse then
            if not IsNull(buttonLight) then
                buttonLight:TurnOff()
            end
            for x = 1, #decorationsToMaterialSwap do
                decorationsToMaterialSwap[x]:SetOverrideMaterial(materialSlots[x], materialsToSwap[x])
            end
            instigator:FirePort("Disable")
        end
    elseif not IsNull(failedPortFowarder) then
        -- don't trigger alarms in sortie missions -- players get damaged instead
        local missionInfo = gGameRules:GetMission()
        if missionInfo.sortieId == "" then
            failedPortFowarder:FirePort("TriggerPort")
        end
    end
end


function DoorControl(avatar, result, instigator)
    if IsNull(avatar) then
        return
    end
    
    if not IsNull(avatar:GetAgent()) then
        result = 1
    end
    
    if result == nil then
        result = 1
    end
    local screen = instigator:GetAttachment(screenType)
    
    if result == 1 then
        screen:SetOverrideMaterial(materialSlot, buttonScreenOff)
        instigator:FirePort("Disable")
    end

    if result == 1 and not IsNull(successForwarder) then
        successForwarder:FirePort("TriggerPort")
    end
end


function CinHullBreach(entity)
    Sleep(25)
    print("HullBreach()")
    _T.canClearHullBreach = false
    local pos = entity:GetPosition()
    local avatars = gRegion:FindAll(avatarType, pos, 0, 100)
    local localAvatar = nil
    local locallyAffected = false
    if not IsNull(avatars) then
        for x = 1, #avatars do
            locallyAffected = avatars[x]:ReplicaLocallyControlled()
            
            if locallyAffected then
                localAvatar = avatars[x]
                break
            end
        end
    end
    
    if locallyAffected then
        if not IsNull(shakeScript) then
            shakeScript:FirePort("Execute")
        end
        
        if not IsNull(localAvatar) then
            localAvatar:PlaySound(enterBreachSound, false, 0, false)
        end
    end
    localAvatar:SetInBreachZone(true)
    print("Hull breach done")
end


function Purge()

    GAMEMODE.TaggedFirePorts(firePortTag, tostring(firePortName))
    
    --Change all liset decorations
    local allDecos = gRegion:FindAll(gLisetDecorationType)
    for i, temp in ipairs(allDecos) do
        temp:SetNoiseParams(2, 0, 5) --rate, base, atten
        temp:SetMaterialParam(mEmissiveTintColor, PurgeFlashTint.red / 255, PurgeFlashTint.green / 255, PurgeFlashTint.blue / 255, 1)
        temp:SetMaterialParam(mEmissiveTintColorHi, PurgeFlashTint.red / 255, PurgeFlashTint.green / 255, PurgeFlashTint.blue / 255, 1)
        temp:SetMaterialParam(mEmissiveTintColorLo, PurgeFlashTint.red / 255, PurgeFlashTint.green / 255, PurgeFlashTint.blue / 255, 1)
    end
    
    local postProcess = gRegion:GetLevelInfo().postProcess
    postProcess.lightMapTint = PurgeTint
    local boost = 1
    while true do
        while boost <= 8 do
            boost = boost + .1
            postProcess.lightMapBoost = boost
            Sleep(.01)
        end
        while boost >= .1 do
            boost = boost - .1
            postProcess.lightMapBoost = boost
            Sleep(.01)
        end
        Sleep(0)
    end
end

function GetPanicButtonActionText(pInstigator, pAvatar)
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()
    if aiDir:GetLockDown() then
        return "/Lotus/Language/Actions/HackSystem"
    else
        return "/Lotus/Language/Actions/HackAlarms"
    end
end

function PanicButtonMasterScript()
    local levelPanicButtons = gRegion:FindTagged(Symbol("PanicButton"))
    
    if not IsNull(levelPanicButtons) and #levelPanicButtons > 0 then        
        local corpusMaterialSet = {tag = Symbol("CorpusPanicDeco"), lockdownMats = onMaterialsCorpus, alertMats = alertMaterialsCorpus, offMats = offMaterialsCorpus}
        local grineerMaterialSet = {tag = Symbol("GrineerPanicDeco"), lockdownMats = onMaterialsGrineer, alertMats = alertMaterialsGrineer, offMats = offMaterialsGrineer}   
        local materialSets = {corpusMaterialSet, grineerMaterialSet}     
        
        local panicStatus = PANIC.GetCurrentPanicStatus()
        
        for pbIt, panicButton in ipairs(levelPanicButtons) do
            local deco = panicButton:GetAttachment(gDecorationType)
            if not IsNull(deco) then
                local materialSet
                for i, set in ipairs(materialSets) do
                    if deco:GetTag() == set.tag then
                        materialSet = set
                        break
                    end
                end
            
                if not IsNull(materialSet) then
                    local materials = materialSet.offMats
                    if panicStatus == PANIC.LOCKDOWN then
                        materials = materialSet.lockdownMats
                    elseif panicStatus == PANIC.ALERT then
                        materials = materialSet.alertMats
                    end
                    for i = 1, #materials do
                        if not IsNull(materials[i]) then
                            deco:SetOverrideMaterial(i-1, materials[i])
                        end
                    end
                end
            end
        end
    end
    
end

local function KeyInstalled()
    if gGameData:HasShipFeature(LOTUS_UTIL.SF_RAILJACK_KEY) then
        return true
    end
    
    return false
end

local function PlayHostBoardingTransmission(avatar)
    if not gGameData:HasCompletedNodeIntro(Symbol("EnterRailjackOnceOnly")) then
        DIALOG.PlayLocalTransmission(railjackTransmissionSet, Symbol("EnterRailjackOnceOnly"), 0, avatar)
        gGameData:SetNodeIntroCompleted(Symbol("EnterRailjackOnceOnly"))
        DIALOG.WaitForTransmissionsToComplete()
        DIALOG.PlayLocalTransmission(railjackTransmissionSet, Symbol("EnterRailjackNeedKey"), 0, avatar)
    elseif gGameRules:IsA(gLotusHubGameRulesType) and 
        not KeyInstalled() and 
        not gGameData:CanUnlockShipFeature(LOTUS_UTIL.SF_RAILJACK_KEY) 
    then
        DIALOG.PlayLocalTransmission(railjackTransmissionSet, Symbol("EnterRailjackNeedKey"), 0, avatar)
    elseif gGameRules:IsA(gLotusHubGameRulesType) and
        not KeyInstalled() and 
        gGameData:CanUnlockShipFeature(LOTUS_UTIL.SF_RAILJACK_KEY) 
    then
        DIALOG.PlayLocalTransmission(railjackTransmissionSet, Symbol("EnterRailjackInstallKey"), 0, avatar)
    else
        DIALOG.PlayLocalTransmission(railjackTransmissionSet, Symbol("EnterRailjackAlways"), 0, avatar)
    end
end

function PlayBoardingTransmission(entity)
    local avatarsOnBoard = RAIL.GetTennoOnRailjack()
    local squad = {}
    local playedBoardingTrans = {}
    local avatarPlayed = false
    local avatar
    local squadAvatar

    if IsNull(gGameRules) then
        return
    end
    local lastNumAvatarsOnBoard = 0
    while gGameRules:IsA(gLotusHubGameRulesType) or gGameRules:IsA(gLotusAttractModeGameRulesType) do
        avatarsOnBoard = RAIL.GetTennoOnRailjack() --refresh incase others joined
        local numAvatarsOnBoard = #avatarsOnBoard
        if lastNumAvatarsOnBoard ~= numAvatarsOnBoard then
            lastNumAvatarsOnBoard = numAvatarsOnBoard
            squad = gMatchingService:GetSquadMembers()
            avatarPlayed = false
            for i = 1, numAvatarsOnBoard do
                avatar = avatarsOnBoard[i]
                for j = 1, #playedBoardingTrans do
                    if avatar == playedBoardingTrans[j] then
                        avatarPlayed = true
                        break
                    end
                end
            
                if not avatarPlayed then
                    if gGameRules:IsA(gLotusAttractModeGameRulesType) then --we're in front end, can't check squad
                        PlayHostBoardingTransmission(avatar)
                    else
                        for k = 1, #squad do
                            squadAvatar = gGameRules:GetAvatarByAccount(squad[k].onlineId)
                            if avatar == squadAvatar then
                                if squad[k].isHost then
                                    PlayHostBoardingTransmission(avatar)
                                else
                                    DIALOG.PlayLocalTransmission(railjackTransmissionSet, Symbol("EnterRailjackAlways"), 0, avatar)
                                end
                            end
                        end
                    end
                    table.insert(playedBoardingTrans, avatar)
                end
            end
        end
        Sleep(1)
    end
end

local function ToggleEntityState(tags, instances, entityIndex, enable)

    local entities = {}
    local toggledEntity = nil
    local taggedLayerIndex
    local tag
    
    for i = 1, #instances do
        toggledEntity = instances[i]
        if not IsNull(toggledEntity) then
            if enable then
                if toggledEntity:IsA(gLightType) then
                    Sleep(0.3)
                    toggledEntity:FirePort("TurnOn")
                else
                    toggledEntity:Enable()
                end
            else
                if toggledEntity:IsA(gLightType) then
                    toggledEntity:FirePort("TurnOff")
                else
                    toggledEntity:Disable()
                end
            end
        end
    end
    
    for i = 1, #tags do
        tag = tags[i]
        entities = gRegion:FindTagged(tag)
        for j = 1, #entities do
            if not IsNull(entities[j]) then
                toggledEntity = entities[j]
                if not IsNull(toggledEntity) then
                    local zone = toggledEntity:GetZone()
                    if not IsNull(zone) then
                        taggedLayerIndex = zone:GetLayerIndex()
                    end
                end
                
                --only toggle actions on the Railjack. Not in Dojo
                if entityIndex == taggedLayerIndex then
                    if enable then
                        if toggledEntity:IsA(gLightType) then
                            Sleep(0.3)
                            toggledEntity:FirePort("TurnOn")
                        else
                            toggledEntity:Enable()
                        end
                    else
                        if toggledEntity:IsA(gLightType) then
                            toggledEntity:FirePort("TurnOff")
                        else
                            toggledEntity:Disable()
                        end
                    end
                end
            end
        end
    end
end



local function IsHost()
    if gGameRules:IsA(gLotusHubGameRulesType) then
        return gMatchingService:IsSquadHost()
    else
        return false --can only check this when in dojo or a relay. 
    end
end



function CheckShipStatus()
    if IsHost() and KeyInstalled() then
        gMatchingService:SendSquadJsonMessage(cjson.encode({shipActivated = true}))
    elseif IsHost() and not KeyInstalled() then
        gMatchingService:SendSquadJsonMessage(cjson.encode({shipNotActivated = true}))
    end
end

function StartTheShip(entity)
    local zone = entity:GetZone()
    if IsNull(zone) then
        return
    end
    local entityLayerIndex = zone:GetLayerIndex()
    local keyMissionConsole = gRegion:FindFirstTagged(Symbol("KeyMissionAction"))
    local reliquaryConsole = gRegion:FindFirstTagged(Symbol("ReliquaryConsole"))
    local marker = gRegion:FindFirstTagged(Symbol("ReliquaryMarker"))
    local isHost = IsHost()

    -- if not host, set the lights to whatever state the hosts ship should be in
    if ( isHost and KeyInstalled() ) or ( not isHost and _T.shipActivated ) then --or devMode then
        ToggleEntityState(tagsToDisable, instancesToDisable, entityLayerIndex, true)
        ToggleEntityState(tagsToEnable, nil, entityLayerIndex, false)
        
        if not IsNull(reliquaryConsole) then    
            reliquaryConsole:SetActionText("/Lotus/Language/Railjack/SarcophagusWithKey")
        end
        
        if not IsNull(marker) then
            marker:Disable()
        end
        
        local veil = gRegion:FindFirstTagged(Symbol("ReliquaryVeil"))
        if not IsNull(veil) then
            veil:SetMaterialParam(Symbol("UnlitAtten"), 0.40)
        end
        local roots = gRegion:FindFirstTagged(Symbol("Roots"))
        if not IsNull(roots) then
            roots:SetVisibility(true, false)
        end
    elseif isHost and gGameData:CanUnlockShipFeature(LOTUS_UTIL.SF_RAILJACK_KEY) then
        if not IsNull(marker) then
            marker:Enable()
        end
        
        ToggleEntityState(tagsToDisable, instancesToDisable, entityLayerIndex, false)
        ToggleEntityState(tagsToEnable, nil, entityLayerIndex, true)
        
    else
    
        ToggleEntityState(tagsToDisable, instancesToDisable, entityLayerIndex, false)
        ToggleEntityState(tagsToEnable, nil, entityLayerIndex, true)
        
        --enable the action to start the RJ Key hunt mission if the player does not have the key and has not installed the key
        --Otherwise, do nothing. Reliquary interaction should be the default.
        if isHost and
            not gGameData:CanUnlockShipFeature(LOTUS_UTIL.SF_RAILJACK_KEY) and
            gGameData:HasShipFeature(LOTUS_UTIL.SF_RAILJACK_CEPHALON)
        then 
            if not IsNull(keyMissionConsole) then
                keyMissionConsole:Enable()
            end
            if not IsNull(marker) then
                marker:Enable()
            end
            
            if not IsNull(reliquaryConsole) then
                reliquaryConsole:Disable()
            end
        end
    end
end

local function ActivateTransmissionAtConsole(entity, avatar)
    entity:Disable()
    DIALOG.PlayLocalTransmission(railjackTransmissionSet, transmissionTag, 0, avatar)
    DIALOG.WaitForTransmissionsToComplete()
    entity:Enable()
end

local function SquadJsonCallback(json)
    print("CREWSHIP: Squad JSON received: "..tostring(json))
    
    local shipPowerTrig = gRegion:FindFirstTagged(Symbol("PowerTheShip"))

    if string.find(json, "shipActivated") then
        print("Host Railjack is active, powering it up for client")
        _T.shipActivated = true
        if not IsNull(shipPowerTrig) then
            shipPowerTrig:FirePort("Execute")
        end
    elseif string.find(json, "shipNotActivated") then
        print("Host Railjack is not active, turning power off for client")
        _T.shipActivated = false
        if not IsNull(shipPowerTrig) then
            shipPowerTrig:FirePort("Execute")
        end
    elseif string.find(json, "checkShipStatus") then
        print("Client joined the squad. Check the state of Host Railjack")
        local shipStatusTrig = gRegion:FindFirstTagged(Symbol("CheckShipStatus"))
        if not IsNull(shipStatusTrig) then
            shipStatusTrig:FirePort("Execute")
        end
    end
end

function ExecuteSelf(self)
    Sleep(1) --Allows the assets to load in before starting
    
    --_T.CrewShip is only set when the crewship is initilized in the Dojo, but not when boarding RJ straight from Liset
    --When loading from Liset, loop later when looking for the Reliquary console so we can change the action text
    while IsNull(_T.CrewShip) and not gGameRules:IsA(gLotusAttractModeGameRulesType) do
        Sleep(0)
    end
    
    --don't run this in missions
    if not gGameRules:IsA(gLotusHubGameRulesType) and not gGameRules:IsA(gLotusAttractModeGameRulesType) then
        return
    end
    
    gMatchingService:SetSquadJsonMessageCallback(SquadJsonCallback)
    
    if IsHost() then
        self:FirePort("Execute")
    elseif gGameRules:IsA(gLotusAttractModeGameRulesType) then
        local reliquaryConsole = gRegion:FindFirstTagged(Symbol("ReliquaryConsole"))
        local consoleWait = 0
        while IsNull(reliquaryConsole) do
            reliquaryConsole = gRegion:FindFirstTagged(Symbol("ReliquaryConsole"))
            consoleWait = consoleWait + 1
            if consoleWait > 100 then
                print("Could not find the RJ Reliquary when boarding RJ straight from Liset.")
                break
            end
            Sleep(0)
        end
        if not IsNull(reliquaryConsole) then    
            reliquaryConsole:SetActionText("/Lotus/Language/Railjack/SarcophagusWithKey")
        end
    else
        gMatchingService:SendSquadJsonMessage(cjson.encode({checkShipStatus = true}))
    end
    
    if IsHost() then
        local squad
        local squadCount = 0
        local oldSquadCount = 0
        while gGameRules:IsA(gLotusHubGameRulesType) or gGameRules:IsA(gLotusAttractModeGameRulesType) do
            squadCount = gMatchingService:NumSquadMembers()
            if squadCount > oldSquadCount and squadCount > 1 then
                gMatchingService:SendSquadJsonMessage(cjson.encode({checkShipStatus = true}))
                oldSquadCount = squadCount
            elseif #squad < oldSquadCount then
                oldSquadCount = squadCount
            end
            Sleep(1)
        end
    end
end

function OnRailjackUnlocked(success, body)

end

local function SetupEvilTwin(entity)

    local warWithinComplete = STORY.CheckQuestCompletion(keyChainWRes)
    if not warWithinComplete then
        print("Player did not complete War Within yet, so not creating the twin")
        return
    end
    
    -- set up evil twin
    local twinSpawn = gRegion:FindFirstTagged(Symbol("EvilTwinSpawn"))
    if IsNull(twinSpawn) then
        twinSpawn = entity
    end
    
    local voidOperatorPos = twinSpawn:GetPosition()
    local evilTwin = gRegion:CreateEntity(evilTwinType, voidOperatorPos, ZERO_ROTATION)
    local count = 0
    while IsNull(evilTwin) and count < 10 do
        count = count + 1
        Sleep(0.1)
    end
    
    if IsNull(evilTwin) then
        print("couldn't create the evil twin")
        return
    end
    
    OPERATOR.ApplyOperatorCustomization(evilTwin)
    Sleep(0)
    OPERATOR.RemoveOperatorHood(evilTwin)
    Sleep(0)

    local twinAttachDecos = evilTwin:GetAttachedChildren()
    while #twinAttachDecos < 2 do
        Sleep(0.1)
        twinAttachDecos = evilTwin:GetAttachedChildren()
    end
    
    for _,deco in ipairs(twinAttachDecos) do
        if not IsNull(deco) and deco:IsA(gDecorationType) then
            local mesh = deco:GetMesh()
            local str = mesh:GetFullName() or ""
            if not IsNull(mesh) and ((string.find(str, "[Hh]ood") ~= nil) or (string.find(str, "[Mm]ask") ~= nil)) then -- :(
                gRegion:DestroyObject(deco)
            end
        end
    end
    
    evilTwin:SetAnimName(Symbol("VoidKid"))
    --evilTwin:SetTag(Symbol("EvilTwin"))
    
    return evilTwin
    
end

local function PlayCinematic(entity)
    local evilTwin = SetupEvilTwin(entity)
    
    if IsNull(evilTwin) then
        --return
    end
    
    local cinematic = gRegion:FindFirstTagged(Symbol("RailjackFirstStartCin"))
    if not IsNull(cinematic) then
        cinematic:FirePort("StartPlaying")

        while not cinematic:IsPlaying() do
            Sleep(0)
        end
        
        while cinematic:IsPlaying() do
            Sleep(0)
        end
    end
    
    if not IsNull(evilTwin) then
        evilTwin:Destroy()
    end
end

function ReliquaryInteract(entity, avatar)
    
    if 
        IsHost() and 
        not gGameData:HasShipFeature(LOTUS_UTIL.SF_RAILJACK_KEY) and
        gGameData:CanUnlockShipFeature(LOTUS_UTIL.SF_RAILJACK_KEY)
    then
        entity:Disable()
        local marker = gRegion:FindFirstTagged(Symbol("ReliquaryMarker"))
        if not IsNull(marker) then
            marker:Disable()
        end
        
        PlayCinematic(entity)
        
        gGameData:UnlockShipFeature(LOTUS_UTIL.SF_RAILJACK_KEY, WeakResource(""), 0, "OnRailjackUnlocked")
        
        while not gGameData:HasShipFeature(LOTUS_UTIL.SF_RAILJACK_KEY) do
            Broadcast("No ship feature yet!!")
            Sleep(0)
        end
        
        DIALOG.PlayLocalTransmission(railjackTransmissionSet, Symbol("PostActivateCinematic"), 0, avatar)
        DIALOG.WaitForTransmissionsToComplete()
        
        gMatchingService:SendSquadJsonMessage(cjson.encode({shipActivated = true}))
        
        local shipPowerTrig = gRegion:FindFirstTagged(Symbol("PowerTheShip"))
        if not IsNull(shipPowerTrig) then
            shipPowerTrig:FirePort("Execute")
        end
        Sleep(2)
        DIALOG.PlayLocalTransmission(railjackTransmissionSet, Symbol("PostActivateCinematicTwo"), 0, avatar)
        DIALOG.WaitForTransmissionsToComplete()
        
        entity:Enable()
        
    else
        ActivateTransmissionAtConsole(entity, avatar)
    end
end

--enable script trigger in railjack interior for testing
function PlayReliquaryActivateCinematic(entity)
    PlayCinematic(entity)
end

function NavigationDisabled(entity, avatar)
    ActivateTransmissionAtConsole(entity, avatar)
end

function InitTubeDecoEffect(deco)
    while IsNull(gGameRules) do
        Sleep(0)
    end
    if gGameRules:IsA(gLotusHubGameRulesType) then
        deco:PlayTriggeredFade()
    end
end