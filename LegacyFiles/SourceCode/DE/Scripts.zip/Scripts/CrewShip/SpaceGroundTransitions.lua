fadeOutTime = 0.5
fadeInTime = 0.5
--groundToSpaceTransition = true -- if false, will be a space to ground transition
enterExitWaypointTag = Symbol()
cinematicTag = Symbol()
animName = Symbol()
fadeDelay = 0
fadeStartValue = 0
fadeEndValue = 1
enterAnim = Resource()
exitPointType = WeakResource() --second part of exit anim that plays post fade
--landingAnim = Resource()
poiTag = Symbol()

parallaxScale = 1.0
spaceTransformEntity = Instance()
orokinZoneAttribsWRes = WeakResource()
manageZoneAttribsOnGround = true
isArchwing = false

local sArchwingName = Symbol("Archwing")

local DerelictEnterSeq = Symbol("DerelictEnterSeq")
local DerelictExitSeq = Symbol("DerelictExitSeq")

local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"

local mCrewShip = nil

local function CreateArchwingEntity(avatar, cin)
    if IsNull(avatar) or IsNull(cin) then
        return
    end

    local flightSuit = avatar:InventoryControl():GetAlternatePowerSuit()
    local playerArchwing = nil
    if not IsNull(flightSuit) then
        local archwingType = flightSuit:GetSpaceJetpackAttachmentType()
        if not IsNull(archwingType) then
            --archwing entity should not be replicated and should be owned by the cinematic so that they are destroyed when it completes
            local repMode = Script.ObjectType_RM_SERVER_ONLY
            if not gRegion:IsMaster() then
                repMode = Script.ObjectType_RM_CLIENT_ONLY
            end
            playerArchwing = gRegion:CreateEntity(archwingType, Vector(100, 100, 100), ZERO_ROTATION, nil, nil, repMode)
        end  
    end

    if not IsNull(playerArchwing) then
        cin:AddExlipicitEntity(playerArchwing, sArchwingName)
        local customization = flightSuit:GetCustomization()
        customization:ApplyCustomization(playerArchwing)
        playerArchwing:SetAnimName(sArchwingName)
    end
    
    Sleep(0) --needed to get clients to see AW
    
    return playerArchwing
end

local function _DoFade(delay, startVal, endVal, fadeTime, avatar)
    Sleep(delay)
    local postProcess = nil
    if not IsNull(avatar) and not IsNull(avatar:GetPlayer()) and avatar:GetPlayer():IsLocal() then
        local postProcess = avatar:CameraControl():ScriptGetCurrentPostProcessInfo()
        local t = 0
        local val

        while t < 1 and not IsNull(postProcess) do
            val = Lerp(startVal, endVal, t)
            postProcess.fade = val
            t = t + DeltaTime() / fadeTime
            Sleep(0)
        end
        if not IsNull(avatar) then
            postProcess.fade = endVal
        else
            avatar = gRegion:GetLocalPlayerAvatar()
            postProcess = avatar:CameraControl():ScriptGetCurrentPostProcessInfo()    
            postProcess.fade = endVal
        end
    end
end

local function GetInstigator(entity, avatar)
    local enteringAvatar = nil
    local instigator = entity:GetInstigator()
    
    if not IsNull(avatar) then
        enteringAvatar = avatar
    elseif not IsNull(instigator) and instigator:IsA(gTennoAvatarType) then
        enteringAvatar = instigator
    end
    
    return enteringAvatar
end

local function GetInstigatorCinematic(instigator, cinematicTag)
    local players = gRegion:GetHumanPlayers()
    local playerAvatars = gRegion:GetHumanPlayerAvatars()
    
    local avatars = {}
    for i = 1, #playerAvatars do
        local player = players[i]
        table.insert(avatars, { id=player:GetPlayerID(), avatar=playerAvatars[i] })
    end 

    table.sort(avatars, function(a,b) return a.id < b.id end) -- Sort clients by player ID
    local playerIndex = nil
    for i = 1, #playerAvatars do
        if avatars[i].avatar == instigator then
            playerIndex = i
            break
        end
    end    
    
    local allCins
    if IsNull(mCrewShip) then
        allCins = gRegion:FindTagged(cinematicTag)
    else
        allCins = RJ_UTIL.FindTaggedOnShip(cinematicTag, mCrewShip)
    end
    
    if #allCins < playerIndex then
        print("PlayerIndex is greater than number of cinematics ")
        return nil
    end

    table.sort(allCins, function(a,b) return a:GetInstance() < b:GetInstance() end)

    return(allCins[playerIndex])
end

local function PlayCinematic(instigator, cinematic)
    if not IsNull(cinematic) then
    
        instigator:SetView(cinematic:GetRotation())
        instigator:PlayAnimation(nil, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_ONCE, false, 1.0)
        instigator:SetAnimName(animName)

        if gRegion:IsMaster() then
            cinematic:SetInstigatorAvatar(instigator)
            cinematic:FirePort("StartPlaying")
        end

        local t = 0
        while not IsNull(cinematic) and not cinematic:IsPlaying() and t < 5 do -- client timeout (waiting for host to start cin)
            Sleep(0)
            t = t + DeltaTime()
        end

        while not IsNull(cinematic) and cinematic:IsPlaying() do
            Sleep(0)
        end
    
        instigator:PlayAnimation(nil, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_ONCE, false, 1.0)
    end
end

function ExitSequence(instigator)
    if instigator:IsA(gLotusOperatorAvatarType) then
        local instigatorPlayer = instigator:GetAuthoritativePlayer()
        instigator:ForceOperatorTransference()
        while instigator:IsA(gLotusOperatorAvatarType) do
            Sleep(0)
            instigator = instigatorPlayer:GetAvatar()
        end
    end

    if RJ_UTIL.IsRailjackSeqPlaying(instigator, DerelictExitSeq) then
        return
    end
    RJ_UTIL.SetRailjackSeqPlaying(instigator, DerelictExitSeq)
    
    local inventoryController = instigator:InventoryControl()
    local boardedShip = inventoryController:GetOnBoardShip()
    
    local shipAvatar = nil
    if not IsNull(boardedShip) then
        shipAvatar = boardedShip:GetAvatarOwner()
    end

    local cin = GetInstigatorCinematic(instigator, cinematicTag)
    local playerArchwing = CreateArchwingEntity(instigator, cin)
    
    PlayCinematic(instigator, cin)
    
    if not IsNull(playerArchwing) then
        playerArchwing:Destroy()
    end
    
    if instigator:ReplicaLocallyControlled() or instigator:IsMaster() then
        local exitWaypoint = nil
        if not IsNull(exitPointType) and not IsNull(shipAvatar) then
            exitWaypoint = shipAvatar:GetAttachment(exitPointType)
            if IsNull(exitWaypoint) then
                exitWaypoint = gRegion:FindNearestTagged(enterExitWaypointTag, shipAvatar:GetPosition())
            end
        end
        
        if IsNull(exitWaypoint) then
            exitWaypoint = gRegion:FindFirstTagged(enterExitWaypointTag)
        end

        if not IsNull(exitWaypoint) then
            local spawnPos = exitWaypoint:GetPosition()
            local viewRot = exitWaypoint:GetRotation()

            instigator:DamageControl():GiveTemporaryImmunity(3.0, 0.0)
            instigator:Teleport(spawnPos, viewRot)
            instigator:SetView(viewRot)
        else
            print("WAYPOINT not found!")
            if not IsNull(cin) then
                instigator:DamageControl():GiveTemporaryImmunity(3.0, 0.0)
                instigator:Teleport(cin:GetPosition(), cin:GetRotation())
            end
        end
    end

    _DoFade(fadeDelay, 1, 0, fadeInTime, instigator)

    RJ_UTIL.ResetRailjackSeqPlaying(instigator, DerelictExitSeq)
end


function ExitDerelict(entity, avatar)
   
    local enteringAvatar = GetInstigator(entity, avatar)

    if IsNull(enteringAvatar) then
        return
    end    
    enteringAvatar:ScriptRunChildScript(Symbol("ExitSequence"), false)
    
end

local function ManageZoneAttribs(instigator, cinematic)
    if instigator == gRegion:GetLocalPlayerAvatar() then
        if not IsNull(spaceTransformEntity) then
            local spaceZoneAttribs = spaceTransformEntity:GetZone():GetZoneAttribs()

            if not IsNull(spaceZoneAttribs) then

                spaceZoneAttribs:SetParallaxCenter(cinematic)
                spaceZoneAttribs:GetZone():SetActualScale(parallaxScale)
                spaceZoneAttribs:GetZone():SetTransformEntity(spaceTransformEntity)

                local orokinZoneAttribs = gRegion:FindAll(orokinZoneAttribsWRes)
                for i,v in ipairs(orokinZoneAttribs) do
                    local vZone = v:GetZone()
                    if not IsNull(vZone) then
                        v:SetBackDropId(spaceZoneAttribs:GetZoneId())
                        vZone:SetBackdrop(spaceZoneAttribs:GetZone())
                    end
                end
            end
        end
    end
end

function EnterSequence(instigator)
    if RJ_UTIL.IsRailjackSeqPlaying(instigator, DerelictEnterSeq) then
        return
    end
    RJ_UTIL.SetRailjackSeqPlaying(instigator, DerelictEnterSeq)
    
    local refPoint = gRegion:FindFirstTagged(Symbol("RotationRef"))
    if not IsNull(refPoint) then
        instigator:MotionControl():SetTorsoFromView(refPoint:GetRotation())
    end
    
    local enterWaypoint = nil
    
    if not (poiTag == EMPTY_SYMBOL) then
        local poiAvatar = gRegion:FindNearestTagged(poiTag, instigator:GetPosition())
        mCrewShip = poiAvatar:InventoryControl():GetActivePowerSuit()
        enterWaypoint = RJ_UTIL.FindFirstTaggedOnShip(Symbol("BoardShipPosition"), mCrewShip)
        --enterWaypoint is only used as a condition for boarding, but never actually used - can probably remove in favour of finding boarding cinematic
    elseif not IsNull(enterExitWaypointTag) then
        enterWaypoint = gRegion:FindFirstTagged(enterExitWaypointTag)
    end
    
    if not IsNull(enterWaypoint) and not IsNull(instigator:CameraControl()) then
        instigator:PlayAnimation(enterAnim, false)
        _DoFade(fadeDelay, fadeStartValue, fadeEndValue, fadeOutTime, instigator)
    end
    
    local cinematic = GetInstigatorCinematic(instigator, cinematicTag)
    
	if manageZoneAttribsOnGround == true then
		ManageZoneAttribs(instigator, cinematic)
	end
    
    local playerArchwing = nil
    if isArchwing then
        playerArchwing = CreateArchwingEntity(instigator, cinematic)
    end
    
    PlayCinematic(instigator, cinematic)
    RJ_UTIL.ResetRailjackSeqPlaying(instigator, DerelictEnterSeq)
    
    if not IsNull(playerArchwing) then
        playerArchwing:Destroy()
    end
end

function EnterDerelict(entity, avatar)
    local enteringAvatar = GetInstigator(entity, avatar)

    if IsNull(enteringAvatar) then
        return
    end
    
    enteringAvatar:ScriptRunChildScript(Symbol("EnterSequence"), false)

end

function DynamicHide(entity)
    while not IsNull(entity) do
        local player = gRegion:GetLocalPlayerAvatar()
        if not IsNull(player) then
            local playerZone = player:GetZone()
            if not IsNull(playerZone) then
                local regionIndex = playerZone:GetRegionIndex()
                
                local visibility = entity:IsVisible()
                local newVisibility = regionIndex ~= 1
                if visibility ~= newVisibility then
                    entity:SetVisibility(newVisibility)
                    -- TODO: DISABLE ANY ATTACHED EFFECTS THAT MIGHT NOT USE PARENT VISIBILITY?
                end
            end
        end
        Sleep(0.1)
    end
end

function DoFade(cin)
    local avatar = cin:GetInstigatorAvatar()
    if not IsNull(avatar) then
        _DoFade(fadeDelay, fadeStartValue, fadeEndValue, fadeOutTime, avatar)
    end
end