local nodeMax = 2

local NV_GALLEON_NODE_COUNT = Symbol("GALLEON_NODE_COUNT")
local NV_KILL_CAPITAL_CAPTAIN_STATE = Symbol("KILL_CAPITAL_CAPTAIN_STATE")

local NOT_STARTED = 1
local BOSS_COMBAT = 6
local BOSS_KILLED = 7

local mTransmissionSet = Resource("/Lotus/Sounds/Dialog/RailJack/CommanderEhraRok/CommanderEhraRokTransmissions")
local sShieldNode = Symbol("GalleonCommanderShieldNode")
local sCommanderInvincible = Symbol("GalleonCommanderInvincibility")

local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"
local RJ_UTIL = require "Lotus.Scripts.Libs.RailjackUtilities"

immunityAttachment = WeakResource()
immunityBeam = Type()
nemesisMovieType = Resource()
finalPose = Resource()
attachedFx = WeakResource()
nodeMarkerType = WeakResource()

bossIntroMovie = Resource()
bossIntroMovieDelay = 0

local function IncrementNetVar(s)
    local val = gGameRules:GetNetPersistentVar(s, 0)
    val = val + 1
    gGameRules:SetNetPersistentVar(s, val)
end

local function DestroyBeam(avatar)
    local immunityAttach = avatar:GetAttachment(immunityAttachment)
    local beams = {}
    if not IsNull(immunityAttach) then
        beams = immunityAttach:GetAllAttachments(immunityBeam)
    end
    
    if not IsNull(beams[1]) then
        beams[1]:Destroy()
    end

end

local function GeneratorsDestroyed(beamNodes, avatar)

    local generatorCount = 0
    if not IsNull(gGameRules) then
        generatorCount = gGameRules:GetNetPersistentVar(NV_GALLEON_NODE_COUNT, 0)
    end

    if generatorCount >= nodeMax then
        if not IsNull(beamNodes) then
            for i = #beamNodes, 1, -1 do
                if not IsNull(beamNodes[i]) then    
                    beamNodes[i]:Destroy()
                    table.remove(beamNodes, i)
                end
            end
            DestroyBeam(avatar)
        end
        
        return true
    elseif generatorCount == 1 then
        if #beamNodes > 1 then
            if not IsNull(beamNodes[1]) then
                beamNodes[1]:Destroy()
                table.remove(beamNodes, 1)
            end
            DestroyBeam(avatar)
        end
        
    end

    return false
end

function CommanderBossMonitor(avatar)

    local t = 0
    local phaseTwoSet = false
    local shieldDestroyed = false
    
    local prevHealth = -1
    local interiorBeamNodes = gRegion:FindTagged(Symbol("GalleonCommanderShieldNode"))
    
    while true do
        if IsNull(avatar) or avatar:IsKilled() then
            return
        end
        
        local maxHealth = avatar:GetMaxHealth()
        local health = avatar:GetHealth()
        
        if (health <= maxHealth / 2) and (prevHealth > maxHealth / 2) and phaseTwoSet == false then
            OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/DestroyTheShieldNodes", 2) 

            local shieldNodes = gRegion:FindTagged(Symbol("GalleonPowerNode"))
            for i = 1, #shieldNodes do
                shieldNodes[i]:MakeVulnerable()
                local marker = shieldNodes[i]:GetAttachment(nodeMarkerType)
                if not IsNull(marker) then
                    marker:Enable()
                end
            end

            avatar:DamageControl():AddDamageModifier(sCommanderInvincible, Engine.DT_ANY, Engine.ANY_PART, 0)
            avatar:DamageControl():AddShieldDamageModifier(sCommanderInvincible, Engine.DT_ANY, Engine.ANY_PART, 0)

            local capitalEntranceMarker = gRegion:FindFirstTagged(Symbol("CapitalShipEntranceMarker"))
            if not IsNull(capitalEntranceMarker) then
                capitalEntranceMarker:Disable()
            end

            local assassinationObjMarker = gRegion:FindFirstTagged(Symbol("CrewShipAssassinateObjectiveMarker"))
            if not IsNull(assassinationObjMarker) then
                assassinationObjMarker:Disable()
            end
        
            local backToSpaceMarkers = gRegion:FindTagged(Symbol("BackToSpaceMarker"))
            for i=1, #backToSpaceMarkers do
                backToSpaceMarkers[i]:Enable()
            end

            phaseTwoSet = true
        end
        
        --for testing only!!! comment this out
--~         local nodesDestroyed = 0
--~         if t >= 1 and nodesDestroyed == 0 then
--~             gGameRules:SetNetPersistentVar(NV_GALLEON_NODE_COUNT, 1)
--~             nodesDestroyed = 1
--~             --Broadcast("SIMULATING SHIELD NODES DESTROYED")
--~         end
--~         
--~         if t >= 2 and nodesDestroyed == 1 then
--~             nodesDestroyed = 2
--~             gGameRules:SetNetPersistentVar(NV_GALLEON_NODE_COUNT, 2)
--~             --Broadcast("SIMULATING SHIELD NODES DESTROYED")
--~         end

        if GeneratorsDestroyed(interiorBeamNodes, avatar) and shieldDestroyed == false then
            --_T.ShowImpactMessage("[PH] BOSS TAUNT -- GALLEON SHIELDS DESTROYED!", 6, nil, nil, false)

            OBJTXT.SetPrimaryObjText("/Lotus/Language/Railjack/KillTheCaptain", 2) 

            local capitalEntranceMarker = gRegion:FindFirstTagged(Symbol("CapitalShipEntranceMarker"))
            if not IsNull(capitalEntranceMarker) then
                capitalEntranceMarker:Enable()
            end

            local assassinationObjMarker = gRegion:FindFirstTagged(Symbol("CrewShipAssassinateObjectiveMarker"))
            if not IsNull(assassinationObjMarker) then
                assassinationObjMarker:Enable()
            end

            local backToSpaceMarkers = gRegion:FindTagged(Symbol("BackToSpaceMarker"))
            for i=1, #backToSpaceMarkers do
                backToSpaceMarkers[i]:Disable()
            end

            local immunityAttach = avatar:GetAttachment(immunityAttachment)
            if not IsNull(immunityAttach) then
                immunityAttach:Destroy()
            end
            local damageControl = avatar:DamageControl()
            damageControl:RemoveDamageModifier(sCommanderInvincible)
            damageControl:RemoveShieldDamageModifier(sCommanderInvincible)
            damageControl:SetMaxShield(0)
            damageControl:SetShield(0, false)
            shieldDestroyed = true
            break
        end
    
    
        t = t + DeltaTime()
        Sleep(0)
        
        prevHealth = health
        
    end
    
    --gGameRules:ClearNetPersistentVar(NV_NODE_COUNT)
    Broadcast("GrineerCommander.lua -- Boss Monitor Complete!")

end

function CommanderShieldNode(deco)

    local node = deco
    
    while true do
    
        if IsNull(deco) then
            return
        end
    
        local health = deco:GetHealth()
        
        if health <= 0 then
            break
        end
    
        Sleep(0)
    end

end

function FinisherCompleteScript(trigger, avatar)
    
    local parent = trigger:GetAttachParent()
    trigger:Disable()
    
    --cull the lightning fx on his shoulder so they don't interfer in the cinematic finisher
    local fx = parent:GetAttachment(attachedFx)
    local allAttached = parent:GetAllAttachments(attachedFx)
    if not IsNull(fx) then
        fx:Destroy()
    end

    avatar:InventoryControl():SetItemVisibility(Engine.MAIN_HAND, Engine.HIDE)
    
    parent:SetMeshScale(1, true)
    local hackDevice = gRegion:FindFirstTagged(Symbol("TennoHackDevice"))
    if not IsNull(hackDevice) then
        hackDevice:SetVisibility(true)
    end
    
    --kill off other enemies so they don't crowd around the finisher
    local grineerAvatars = gRegion:FindAll(gLotusNpcAvatarType, avatar:GetPosition(), 0, 500)
    for i = #grineerAvatars, 1, -1 do
        local faction = grineerAvatars[i]:GetFaction()
        if grineerAvatars[i] ~= parent and faction == Symbol("Grineer") then
            grineerAvatars[i]:Destroy()
        end
    end
    
    local cin = gRegion:FindFirstTagged(Symbol("CommanderCinematic"))
    if not IsNull(cin) then
        avatar:SetAnimName(Symbol("Tenno"))
        parent:DamageControl():AddProcImmunity(Engine.DT_ANY, Symbol())
        parent:DamageControl():RemoveAllProcs()
        if gRegion:IsMaster() then
            cin:SetInstigatorAvatar(avatar)
            cin:FirePort("StartPlaying")
        end

        Sleep(0)

        local timeout = 0
        while not cin:IsPlaying() and timeout < 5 do --timeout for clients
            timeout = timeout + DeltaTime()
            Sleep(0)        
        end
    
        while cin:IsPlaying() do
            Sleep(0)
        end
    end
    
--~     if not IsNull(weapon) then
--~         weapon:Destroy()
--~     end

    avatar:InventoryControl():SetItemVisibility(Engine.MAIN_HAND, Engine.EQUIP)
    
    if gGameRules:GetNetPersistentVar(NV_KILL_CAPITAL_CAPTAIN_STATE, NOT_STARTED) == BOSS_COMBAT then
        gGameRules:SetNetPersistentVar(NV_KILL_CAPITAL_CAPTAIN_STATE, BOSS_KILLED)
    end
end

function OnActivated(action)
    Broadcast("GrineerCommander.lua -- Finisher Activated")
end

function FinisherActionCreated(action)
    DIALOG.PlayGlobalTransmission(mTransmissionSet, Symbol("CommanderPreDeath"))
    ObjectPortHandler(action, "OnActivated")
end

function ShowNemesisScreen()
    if IsNull(nemesisMovieType) then
        return
    end

    gFlashMgr:GotoMovie(nemesisMovieType)
end

function SetDeathPose()
    local avatar = gRegion:FindFirstTagged(Symbol("GalleonCommanderAvatar"))
    if not IsNull(avatar) then
        avatar:PlayAnimation(finalPose, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_LOOP)
    end
end

function ShieldBeams(spawner)
    local avatar = spawner:GetAttachParent()
    if IsNull(avatar) then
        return
    end

    local shieldPoints = gRegion:FindTagged(Symbol("GalleonCommanderShieldNode"))
    for i=1, #shieldPoints do
        local beam = spawner:Attach(immunityBeam, EMPTY_SYMBOL, Vector(0, 1, 0), Rotation(0, -90, 0))
        if not IsNull(beam) then
            beam:SetEndPoint(shieldPoints[i]:GetPosition())
        end
    end
end

function TestIntroCinematic()
    local spawner = gRegion:FindFirstTagged(Symbol("CommanderTestSpawn"))
    if not IsNull(spawner) then
        spawner:FirePort("Start")
    end
    
    local avatar = gRegion:FindFirstTagged(Symbol("GalleonCommanderAvatar"))
    local oldScale = 1  
    if not IsNull(avatar) then
        oldScale = avatar:GetMeshScale()
        avatar:SetMeshScale(1, true)
        _T["vipAvatar"] = avatar
        Sleep(0)
        avatar:InventoryControl():SetItemVisibility(Engine.MAIN_HAND, Engine.HIDE)
    end
    
    local cin = gRegion:FindFirstTagged(Symbol("CommanderIntroCin"))
    
    if not IsNull(cin) then
        cin:FirePort("StartPlaying")
        if not IsNull(bossIntroMovie) then
            Sleep(bossIntroMovieDelay)
            local movie = gFlashMgr:PushMovie(bossIntroMovie)
            movie:Execute("BossIntro", "")
        end
        
        while cin:IsPlaying() do
            Sleep(0)
        end
        avatar:InventoryControl():SetItemVisibility(Engine.MAIN_HAND, Engine.EQUIP)
        avatar:SetMeshScale(oldScale, true)
    end
end

