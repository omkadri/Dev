fadeFrom = true
decorations = {Instance()}
paramName = Symbol()
inputValues = {0.0, 0.0, 0.0, 0.0}
duration = 2.0
flareMultiplier = 2.0
flareDuration = 0.5

local function _fadeMaterialParam(fadingFrom, decos, parameter, input, decorationValues, time)
    if time > 0 then
        local t = 0
        while t < time do
            Sleep(0)
            t = t + DeltaTime()
            
            local lerpAlpha = math.min(1.0, t / time)
            
            for i,v in ipairs(decos) do
                local values = decorationValues[i]
                if fadingFrom then
                    v:SetMaterialParam(paramName, Lerp(input[1], values[1], lerpAlpha), Lerp(input[2], values[2], lerpAlpha), Lerp(input[3], values[3], lerpAlpha), Lerp(input[4], values[4], lerpAlpha))
                else
                    v:SetMaterialParam(paramName, Lerp(values[1], input[1], lerpAlpha), Lerp(values[2], input[2], lerpAlpha), Lerp(values[3], input[3], lerpAlpha), Lerp(values[4], input[4], lerpAlpha))
                end
            end
        end
    else
            
        for i,v in ipairs(decos) do
            local values = decorationValues[i]
            if fadingFrom then
                v:SetMaterialParam(paramName, values[1], values[2], values[3], values[4])
            else
                v:SetMaterialParam(paramName, input[1], input[2], input[3], input[4])
            end
        end
    end
end

function FadeMaterialParam()
    local decorationValues = {}
    for i,v in ipairs(decorations) do
        local values = {v:GetMaterialParam(paramName, 1), v:GetMaterialParam(paramName, 2), v:GetMaterialParam(paramName, 3), v:GetMaterialParam(paramName, 4)}
        decorationValues[#decorationValues + 1] = values
    end
    
    _fadeMaterialParam(fadeFrom, decorations, paramName, inputValues, decorationValues, duration)
end

function FlareMaterialParam()
    local decorationValues = {}
    for i,v in ipairs(decorations) do
        local values = {v:GetMaterialParam(paramName, 1), v:GetMaterialParam(paramName, 2), v:GetMaterialParam(paramName, 3), v:GetMaterialParam(paramName, 4)}
        decorationValues[#decorationValues + 1] = values
    end
    
    local flareValues = {}
    for i,v in ipairs(inputValues) do
        flareValues[i] = v * flareMultiplier
    end
    _fadeMaterialParam(false, decorations, paramName, flareValues, decorationValues, flareDuration)
    
    decorationValues = {}
    for i,v in ipairs(decorations) do
        local values = {v:GetMaterialParam(paramName, 1), v:GetMaterialParam(paramName, 2), v:GetMaterialParam(paramName, 3), v:GetMaterialParam(paramName, 4)}
        decorationValues[#decorationValues + 1] = values
    end
    
    _fadeMaterialParam(false, decorations, paramName, inputValues, decorationValues, duration)
end