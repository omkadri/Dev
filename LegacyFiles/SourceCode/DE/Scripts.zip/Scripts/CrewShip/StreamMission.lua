local LOTUS_NET = require "Lotus.Interface.LotusNetworkUtilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local UTIL = require "EE.Interface.Utilities"
local WORLD_STATE_UTIL = require "Lotus.Interface.WorldStateUtilities"

starchartRes = Resource()
missionNode = Symbol()
railjackGameRules = WeakResource("/Lotus/Types/GameRules/LotusGameRules")
railjackTennoAvatarType = WeakResource("/Lotus/Types/Player/TennoAvatar")
dojoGameRules = Resource("/Lotus/Types/GameRules/LotusDojoGameRules")
dojoAvatarType = WeakResource("/Lotus/Types/Player/TennoAvatar")
dojoKey = WeakResource("/Lotus/Types/Keys/DojoKey")

local mLevelCreated = nil
local mLevelDestroyed = nil
local mStreamingLayer = 0
local mTunnelStreamingLayer = 366

local CREWSHIP_STREAM_SEQ = Symbol("CrewshipStream")
local CREWSHIP_STREAM_SEQ_DOJO = Symbol("CrewshipStreamDojo")
local CREWSHIP_STREAM_SEQ_MISSION = Symbol("CrewshipStreamMission")
local DESTROY_TUNNEL_SEQ = Symbol("DestroyTunnel")
local REGION_CREATED_FENCE = Symbol("CREWSHIP_REGION_CREATED")
local WARP_COUNTER_TAG = Symbol("WarpInCounter")

local UI_UTIL = require "Lotus.Interface.UIUtilities"

local mPeerAvatarType = Resource("/Lotus/Types/Player/TennoAvatarHubPeer")

local mEndOfMatchMovie = WeakResource("/Lotus/Interface/EndOfMatch.swf")

local mSentientExterminateKeys = {
    { level = WeakResource("/Lotus/Levels/Railjack/Proc/RailJackDeepSpace01ExterminateCombinedNoPoiProc"), key = WeakResource("/Lotus/Types/Keys/TestKeyRailjackSentientExterminate") },
    { level = WeakResource("/Lotus/Levels/Railjack/Proc/RailJackDeepSpace01ExterminateCombined1Poi1OroProc"), key = WeakResource("/Lotus/Types/Keys/TestKeyRailjackSentientExterminatePoi1Oro") },
    { level = WeakResource("/Lotus/Levels/Railjack/Proc/RailJackDeepSpace01ExterminateCombined1Poi1RadarProc"), key = WeakResource("/Lotus/Types/Keys/TestKeyRailjackSentientExterminatePoi1Radar") },
    { level = WeakResource("/Lotus/Levels/Railjack/Proc/RailJackDeepSpace01ExterminateCombined1Poi1SuperWeaponProc"), key = WeakResource("/Lotus/Types/Keys/TestKeyRailjackSentientExterminatePoi1SuperWep") },
    { level = WeakResource("/Lotus/Levels/Railjack/Proc/RailJackDeepSpace01ExterminateCombined1Poi1HangarProc"), key = WeakResource("/Lotus/Types/Keys/TestKeyRailjackSentientExterminatePoi1Hangar") },
    { level = WeakResource("/Lotus/Levels/Railjack/Proc/RailJackDeepSpace01ExterminateCombined1Poi1MissilePlatProc"), key = WeakResource("/Lotus/Types/Keys/TestKeyRailjackSentientExterminatePoi1Missile") },
    { level = WeakResource("/Lotus/Levels/Railjack/Proc/RailJackDeepSpace02ExterminateCombined2PoiProc"), key = WeakResource("/Lotus/Types/Keys/TestKeyRailjackSentientExterminateDevourerSegment2PoiProc") },
    { level = WeakResource("/Lotus/Levels/Railjack/Proc/RailJackDeepSpace02ExterminateCombined1Poi1GalleonProc"), key = WeakResource("/Lotus/Types/Keys/TestKeyRailjackSentientExterminatePoi1GalleonProc") }
}

-- Dojo 
local DOJO_DATA_FAILED = 0
local DOJO_DATA_SUCCESS = 1
local DOJO_DATA_PENDING = 2

function OnLevelDestroyed(levelType, levelLayer)

    print("CREWSHIP: OnLevelDestroyed")

    if IsNull(levelType) then
        mLevelDestroyed = false
    else
        mLevelDestroyed = true
    end
end

function OnLevelCreated(levelType, levelLayer)

    if IsNull(levelType) then
        mLevelCreated = false
    else
        print("CREWSHIP: OnLevelCreated, layer: "..tostring(levelLayer))
        mLevelCreated = true
    end
end

function OnHubSessionReady()
end

local function _DismountAllEmplacements(sleepTime)
    -- Dismount (guns etc)
    local emplacements = gRegion:FindTagged(Symbol("ShipEmplacement"))
    for i = 1, #emplacements do
        local usr = emplacements[i]:GetCurrUser()
        if not IsNull(usr) and usr:ReplicaLocallyControlled() then
            emplacements[i]:FirePort("ForceUserToDismount")
        end
    end
    if sleepTime then
        Sleep(sleepTime)
    end
end

local function SessionUnlocked()
end

local function _UnlockGameSession(session)

    if IsNull(session) then
        return
    end

    local settings = session:GetSettings()
    if _T.gActiveMatchMakingMode == _T.MATCHMAKING_QUICKMATCH_GAMEMODE then
        local playerProfile = gPlayerProfileMgr:GetPlayerProfile(0)
        local profileSettings = playerProfile:Settings()
        local hostSettings = profileSettings:GetHostSettingsCopy()

        settings.regionId = hostSettings.regionId
    else
        settings.regionId = (_T.gActiveMatchMakingMode == _T.MATCHMAKING_INVITE_ONLY_GAMEMODE and Engine.INVITE_ONLY or Engine.PRIVATE)
    end

    gMatchingService:UpdateSessionSettings(settings, SessionUnlocked)
end

local function _SetHubSession(session)
    if not IsNull(session) then
        local settings = session:GetSettings()
        settings.gameModeId = LOTUS_UTIL.BuildGameModeIdForClanDojo()

        -- In case we locked the session after completing bounty stage -- unlock again
        if _T.gActiveMatchMakingMode == _T.MATCHMAKING_QUICKMATCH_GAMEMODE then
            local playerProfile = gPlayerProfileMgr:GetPlayerProfile(0)
            local profileSettings = playerProfile:Settings()
            local hostSettings = profileSettings:GetHostSettingsCopy()

            settings.regionId = hostSettings.regionId
        else
            settings.regionId = (_T.gActiveMatchMakingMode == _T.MATCHMAKING_INVITE_ONLY_GAMEMODE and Engine.INVITE_ONLY or Engine.PRIVATE)
        end
        settings.originalSessionId = "reset"
        -- TODO: settings.originalSessionId = _T.gDojoData.GuildId
        settings:ScriptClearMaps()

        gMatchingService:UpdateSessionSettings(settings, "OnHubSessionReady")
    end
end

local function _getCrewShipMgr()
    local crewShipMgr = gGameRules:GetCrewShipManager()
    
    while IsNull(crewShipMgr) do
        Sleep(0)
        crewShipMgr = gGameRules:GetCrewShipManager()
    end

    return crewShipMgr
end

local function _HostHubTransition()

    print("STREAMMISSION: _HostHubTransition")

    if gRegion:IsMaster() then
        local gameRules = gRegion:CreateObject(Type(dojoGameRules))
        if not IsNull(gameRules) then
            local currentPlayer = gRegion:GetLocalPlayer()
            local currentAvatar = currentPlayer:GetAvatar()
            currentPlayer:InheritCurrentSpawnPosRot()
            gameRules:EquipWeaponOnSpawn(false)
            gameRules:SpawnPlayer(currentPlayer, Type(dojoAvatarType))

            currentAvatar = currentPlayer:GetAvatar()
            currentAvatar:InventoryControl():SetWeaponsEnabled(false)

            local crewShipMgr = _getCrewShipMgr()
            local playerShip = crewShipMgr:GetPlayerShip()
            if not IsNull(playerShip) then
                playerShip:GetAvatarOwner():InventoryControl():ClearCargoOnReturnToDojo()
            end
        end

    end

    _G.gPromotedToHost = false
    gMatchingService:UpdatePresence()
end

local function _ReturnToDojo()

    local wasClient = not gRegion:IsMaster()
    if wasClient then
        print("CREWSHIP: Migrating client")
        gClient:ForceSeamlessHostMigration(dojoGameRules)

        -- Wait until we respawn
        while not gRegion:IsMaster() do
            Sleep(0.1)
        end

        local localAvatar = gRegion:GetLocalPlayerAvatar()
        while IsNull(localAvatar) or not localAvatar:IsMaster() do
            Sleep(0)
            localAvatar = gRegion:GetLocalPlayerAvatar()
        end
        localAvatar:InventoryControl():SetWeaponsEnabled(false)

        while not gGameRules:GameStarted() do
            Sleep(0)
        end

        gRegion:VerifyObjectsNetStatus()
    end

    -- If we're host -- we have to let all the clients leave first
    while gRegion:IsMaster() and gRegion:GetNumRemotePlayers() > 0 do
        Sleep(0.1)
    end

    gMatchingService:SetSquadReturningToLobby(false)
    -- Stop accepting replication messages
    -- TODO: Do it sooner?
    gRegion:NotifySeamlessRegionStreaming()

    -- Update loadout info so squad panel shows correct level on items that got xp in plains.
    gMatchingService:UpdateLocalLoadout()

    if gRegion:IsMaster() then
        local cin = gRegion:FindFirstTagged(Symbol("SummonRailjack"))
        if not IsNull(cin) then
            cin:FirePort("StartPlaying")
        else
            print("Cinematic not found!")
            -- This means our dojo has no hanger, so we have to drop RJ as well
        end

        -- Update the session to unlock it
        local session = gMatchingService:GetSession()
        if not IsNull(session) and gMatchingService:IsSquadHost() then
            _SetHubSession(session)
        end

        -- Mostly to refresh it before _HostHubTransition (can be slow, we don't
        -- want to lump these 2 frames together)
        Sleep(0)

        -- If we were a client we've already migrated before (CREWSHIP: Migrating client) above.
        if not wasClient then
            _HostHubTransition()
        end

        if IsNull(cin) then
            local spawns = gRegion:FindAll(gPlayerSpawnType)
            if #spawns > 0 then
                local localAvatar = gRegion:GetLocalPlayerAvatar()
                localAvatar:Teleport(spawns[1]:GetPosition(), spawns[1]:GetRotation())
            else
                print("CREWSHIP: Could not find spawns!")
            end
        end

    else
        print("NOT YET IMPLEMENTED")
    end
end

function ReturnToDojo()
    _ReturnToDojo()
end

local function _DestroyHubAvatars()

    if not _T.hubAvatars then
        return
    end

    for i=1,#_T.hubAvatars do
        if not IsNull(_T.hubAvatars[i]) then
            gRegion:DestroyObject(_T.hubAvatars[i])
        end
    end

    _T.hubAvatar = nil

end

local function _clientWaitForStreaming()
    mLevelCreated = nil
    
    while mLevelCreated == nil do
        Sleep(0.1)
    end
end

local function _waitForStreaming(levelArgs)
    mLevelCreated = nil
    
    Engine.StreamRegion(levelArgs)
    
    while mLevelCreated == nil do

        if _T.hubAvatars and gRegion:GetNumRemotePlayers() > 0 then
            _DestroyHubAvatars()
        end

        Sleep(0.1)
    end
end

local function _removeStreamedRegion(streamingLayer)
    print("CREWSHIP: Destroying region: " .. tostring(streamingLayer))
    mLevelDestroyed = nil
    
    local levelArgs = Engine.OpenLevelArgs()
    levelArgs.streamingLayer = streamingLayer
    levelArgs.streamingMode = GraphicsRes.StreamRegion_InPlace
    
    levelArgs:SetStreamingCallback("OnLevelDestroyed")
    
    Engine.RemoveStreamedRegion(levelArgs)
    
    while mLevelDestroyed == nil do
        Sleep(0.1)
    end
    
    if mLevelDestroyed then
        print("CREWSHIP: Successfully destroyed region: " .. tostring(streamingLayer))
        return true
    else
        print("CREWSHIP: Region: " .. tostring(streamingLayer) .. " was already destroyed.")
        return false
    end
end

local function _AreAllPlayersConnected()
    return gRegion:GetNumHumanPlayers() >= gMatchingService:NumSquadMembers()
end

local function _BuildHubName(guildId, allianceId)
    local hubName = "DojoHUB_HUB_" .. guildId
    if allianceId ~= "" then
        hubName = hubName .. "_" .. allianceId
    end
    
    return hubName
end

local function _StreamVoidTunnelCommon(streamSequence, mainLevelInfo)

    gGameRules:SignalMultiplayerFence(Symbol("VT_ConnectionStart"), streamSequence)

    local crewShipMgr = _getCrewShipMgr()

    local levelArgs = Engine.OpenLevelArgs()
    levelArgs.streamingLayer = mTunnelStreamingLayer
    levelArgs.streamingMode = GraphicsRes.StreamRegion_InPlace
    
    levelArgs:SetStreamingCallback("OnLevelCreated")
   
    if gRegion:IsMaster() then

        local missionInfo = crewShipMgr:GetNextMission()
        
        -- For the generic tunnel, create it with an available offset (instead of at origin)
        local streamingOffset = Vector()
        _T.TunnelIndex = crewShipMgr:AcquireLevelAnchor(true, streamingOffset)
        levelArgs:SetStreamingOffset(streamingOffset, Rotation())

        local missionLevel = missionInfo.levelOverride
        levelArgs.level = missionLevel

        LOTUS_NET.AddMissionContextObjects(levelArgs, missionInfo)
        
        local isPvp = false
        local isArchwing = true
        LOTUS_NET.SetContextObjectsFromSquadLoadOuts(levelArgs, isPvp, isArchwing)

        _waitForStreaming(levelArgs)
    else
        while true do -- clients can theoretically fail due to querying too early, so keep trying
            _waitForStreaming(levelArgs)
            
            if mLevelCreated then
                break
            end
        end
    end
    
    local success = mLevelCreated
    mLevelCreated = nil
    
    if success then
        if not IsNull(mainLevelInfo) then
            print("Level info region instance: "..tostring(Engine.Zone_GetRegionInstance(mainLevelInfo:GetFullName())))
            print("Streaming layer: "..tostring(mStreamingLayer))
            if Engine.Zone_GetRegionInstance(mainLevelInfo:GetFullName()) == mStreamingLayer then
                print("CREWSHIP: Destroying mission's level info: "..tostring(mainLevelInfo:GetFullName()))
                gRegion:DestroyObject(mainLevelInfo)
            end
        end

        if gRegion:IsMaster() then
            -- TODO: Clients will need to do this too, so I guess we need to send that encoded string thing to squad members somehow
            local missionInfo = crewShipMgr:GetNextMission()
            gGameRules:SetMission(missionInfo)
        end
    else
        print("CREWSHIP: Level creation failed")
        Broadcast("LEVEL CREATION FAILED")
    end
    
    gGameRules:SignalMultiplayerFence(REGION_CREATED_FENCE, streamSequence)
    
    if gRegion:IsMaster() then
        -- Host waits until everyone has finished creating the level
        gGameRules:SuspendUntilMultiplayerFenceReached(REGION_CREATED_FENCE)

        local portForwarders = gRegion:FindTagged(Symbol("OnLevelStreamed"))
        
        for i,portForwarder in ipairs(portForwarders) do
            if not IsNull(portForwarder) then
                local regionIndex = Engine.Zone_GetRegionInstance(portForwarder:GetFullName())
                if regionIndex == mTunnelStreamingLayer then
                    portForwarder:FirePort("TriggerPort")
                end
            end
        end
    end

    gGameRules:FinishMultiplayerFenceSequence(streamSequence)
    print("CREWSHIP: StreamVoidTunnel done")
end

function StreamVoidTunnelFromDojo_P2P()
    local mainLevelInfo = gRegion:GetLevelInfo()
    _StreamVoidTunnelCommon(CREWSHIP_STREAM_SEQ_DOJO, mainLevelInfo)
end

local function MissionSessionSettingsReady()
end

function StreamVoidTunnel(scriptTrigger)
    while IsNull(gGameRules) do
        Sleep(0)
    end

    if not _T.Railjack_FromDojo then
        gGameRules:SignalMultiplayerFence(Symbol("VT_Start"), CREWSHIP_STREAM_SEQ)
    end

    if gMatchingService:IsSquadHost() then
        gGameRules:HideGameSession(false)
    end

    local crewShipMgr = _getCrewShipMgr()
    gGameRules:EquipWeaponOnSpawn(true)

    local regionDestroyed = Symbol("CREWSHIP_REGION_DESTROYED")
    local mainLevelInfo = gRegion:GetLevelInfo()

    -- Destroy the old level
    _removeStreamedRegion(mStreamingLayer)
    gRegion:GetNpcMgr():GetAiDirector():Reset()

    local squadMission = gMatchingService:GetSquadMission()
    local toDojo = false
    local goingFromLiset = _T.SeamlessRailJackTransition

    if squadMission ~= "" then
        local sm = cjson.decode(squadMission)
        if sm.name ~= nil and string.find(sm.name, "Dojo") ~= nil then
            toDojo = true
        end
    end

    _T.RailjackReturnToDojo = toDojo and not goingFromLiset

    if (_T.RailjackEOMPending or _T.RailjackReturnToDojo) and not IsNull(mEndOfMatchMovie) then
        -- show EOM while transitioning to next mission
        _T.RailjackEOMPending = false

        -- If player holding TAB when we want to open, make sure to force close it, otherwise we'll
        -- have the wrong eomScreenMode.
        gGameRules:DisableQuickProgress(true)
        if gGameRules:IsViewingQuickProgress() then
            gGameRules:CloseQuickProgress()
        end

        if IsNull(gFlashMgr:FindMovie(mEndOfMatchMovie)) then
            print("CREWSHIP: Opening EOM movie")
            gFlashMgr:PushMovie(mEndOfMatchMovie)
        else
            print("CREWSHIP: EOM movie already open")
        end

        print("CREWSHIP: Waiting for inventory upload")
         
        -- wait until inventory has been uploaded
        while(gGameRules:HasInventoryCheckpointPending() or gGameRules:HasInventoryUploadPending()) do
            Sleep(0)
        end

        print("CREWSHIP: Done waiting for inventory upload")

        -- reset our gamerules state for next mission
        _T.MissionEnded = nil
        gGameRules:ResetMissionCompleted()

        if not _T.RailjackReturnToDojo then
            gGameRules:DisableQuickProgress(false)
        end

    elseif _T.MissionEnded == true then
        _T.MissionEnded = nil
        gGameRules:ResetMissionCompleted()

    end

    _T.SeamlessRailJackTransition = nil
    if goingFromLiset then
        print("CREWSHIP: Going from Orbiter")
        -- Destroy ship PQ
        for pqLayer = UI_UTIL.PQ_FIRST_LAYER, UI_UTIL.PQ_LAST_LAYER do
            -- We can stop once we hit the first layer that was not there (PQ layers are sequential)
            if not _removeStreamedRegion(pqLayer) then
                break
            end
        end
    end

    print("CREWSHIP: StreamVoidTunnel - from dojo: "..tostring(_T.Railjack_FromDojo)..", from orbiter: "..tostring(goingFromLiset))

    if not _T.Railjack_FromDojo then
        gGameRules:SignalMultiplayerFence(regionDestroyed, CREWSHIP_STREAM_SEQ)
    end

    if gRegion:IsMaster() then
        -- Host waits until everyone has finished destroying the level

        if not _T.Railjack_FromDojo then
            gGameRules:SuspendUntilMultiplayerFenceReached(regionDestroyed)
        end

        -- If going from Dojo, we can now advertise our session (mission)
        if _T.Railjack_FromDojo and gMatchingService:IsSquadHost() and _T.RailJackNextMissionNode then
            local enable = true
            local pvp = false
            LOTUS_NET.Host_AdvertisePublicGame(tostring(_T.RailJackNextMissionNode), enable, pvp, MissionSessionSettingsReady)
        end

        if goingFromLiset then
            if toDojo then
                local hubName = _BuildHubName(gGameData:GetGuildId(), gGameData:GetAllianceId())
                gMatchingService:SetSquadHostHubLevelName(hubName)
            end

            gMatchingService:SendHubMissionLoad()
        end
    end

    local streamSequence = CREWSHIP_STREAM_SEQ
    local fromDojo = false
    if _T.Railjack_FromDojo then
        streamSequence = CREWSHIP_STREAM_SEQ_DOJO
        fromDojo = true
        _T.RailjackReturnToDojo = false
    end
    _T.Railjack_FromDojo = nil

    if not goingFromLiset then
        if gMatchingService:IsSquadHost() or gMatchingService:NumSquadMembers() == 0 then
            -- Wait until everyone connects
            print("CREWSHIP: Waiting for players to connect")
            while not _AreAllPlayersConnected() do
                Sleep(0.1)
            end
            print("CREWSHIP: Everyone in")
        else
            if gRegion:IsMaster() then
                -- Make sure RJ avatar survives seamless migration (we destroy agents/avatars there)
                local existingShip = crewShipMgr:GetPlayerShip()
                if not IsNull(existingShip) then
                    local shipAvatar = existingShip:GetAvatarOwner()
                    if not IsNull(shipAvatar) then
                        print("CREWSHIP: Clearing agent on "..tostring(shipAvatar:GetFullName()))
                        shipAvatar:ClearAgent()
                    else
                        print("CREWSHIP: RJ has no avatar")
                    end
                else
                    print("CREWSHIP: No railjack?")
                end

                print("CREWSHIP: Squad client ready for seamless load. Host ready="..tostring(gMatchingService:IsSquadHostReady()))
                gMatchingService:SendSeamlessMissionLoad()
            end

            -- Wait until we disconnect
            while gRegion:IsMaster() do
                Sleep(0.1)
            end

            -- ...and get our local dude back
            local localAvatar = gRegion:GetLocalPlayerAvatar()
            while IsNull(localAvatar) or localAvatar:IsMaster() do
                Sleep(0)
                localAvatar = gRegion:GetLocalPlayerAvatar()
            end

            -- Can't test it reliably as we don't know if we got the RJ yet or not
            --Sleep(0)
            --gRegion:VerifyObjectsNetStatus()
        end
    end

    -- If going from dojo we have to split it into 2 triggers,
    -- so that we can start proper fence bookeeping after everyone connects.
    if fromDojo then
        if gRegion:IsMaster() then
            local part2trigger = gRegion:FindFirstTagged(Symbol("StreamVoidTunnelDojoP2P"))
            part2trigger:FirePort("Execute")
        end
    else
        _StreamVoidTunnelCommon(streamSequence, mainLevelInfo)
    end
end

function OnDojoData(success, json)

    if success then
        _T.GetDojoDataResult = DOJO_DATA_SUCCESS

        print("CREWSHIP: OnDojoData - success")

        _T.gDojoData.Result = success
        _T.gDojoData.Body = json
    else
        -- Dojo failure
        _T.GetDojoDataResult = DOJO_DATA_FAILED
    end
end

-- Clients go to host's dojo
local function _GetReturnDojoGuildId()
    if gMatchingService:IsSquadHost() then
        print("Squad host, returning local guild id ("..tostring(gGameData:GetGuildId())..")")
        return gGameData:GetGuildId(), gGameData:GetAllianceId()
    end

    local squadMembers = gMatchingService:GetSquadMembers()
    for i = 1, #squadMembers do
        if squadMembers[i].isHost then
            print("Squad client, found host, returning his guild id ("..tostring(squadMembers[i].guildId)..")")
            return squadMembers[i].guildId, ""
        end
    end

    print("Could not find host to retrieve a guild id")
    return "", ""
end

local function _RequestDojoData()
    -- Special case -- go back to dojo
    _T.Railjack_ToDojo = true
    _T.GetDojoDataResult = DOJO_DATA_PENDING
    
    -- Overlap GetDojoData webget with some of the tunnel streaming
    local credentials = gPlayerProfileMgr:GetPlayerProfile(0):GetCredentials()
    local guildId, allianceId = _GetReturnDojoGuildId()
    if guildId == "" then
        print("Could not find guild id!")
        _T.GetDojoDataResult = DOJO_DATA_FAILED
    else
        _T.gDojoData = { GuildId = guildId, AllianceId =  allianceId }
        Engine.WebGet(gGameConfig:GetWebServer() .. "getGuildDojo.php?" .. credentials .. "&guildId=" .. guildId, "OnDojoData")
    end
end

local function AbortMissionOnDojoFailure()
    if gRegion:IsMaster() then
        gGameRules:EndGame(Engine.GameRules_GS_INTERRUPTED, 0.0)    -- EndGame will take care of DB commit for host, for clients we need to explicitly do the commit
    else
        local force = true
        Engine.Disconnect(force)
    end
end

function StreamNextMissionVoidTunnel(scriptTrigger)

    gGameRules:SignalMultiplayerFence(Symbol("NextMission_Start"), CREWSHIP_STREAM_SEQ_MISSION)

    -- We only load the next mission; we don't destroy previous or trigger ports
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = _getCrewShipMgr()
    
    local returnToDojo = _T.Railjack_ToDojo
    _T.Railjack_ToDojo = false
    _T.Railjack_StreamingNextMission = true

    local levelArgs = Engine.OpenLevelArgs()

    -- Client + dojo (we do not hit SelectNextMission)
    if not gRegion:IsMaster() and _T.GetDojoDataResult == nil and string.find(gMatchingService:GetSquadMission(), "Dojo") then
        _RequestDojoData()
        -- Have to clear it here so it doesn't stay for another run (_T survives seamless migration)
        _T.Railjack_ToDojo = false
        returnToDojo = true
    end

    if returnToDojo then
        _DismountAllEmplacements()
        gFlashMgr:CloseAllMovies()

        if not IsNull(gRegion) then
            local avatar = gRegion:GetLocalPlayerAvatar()
            if not IsNull(avatar) then
                local cameraControl = avatar:CameraControl()
                cameraControl:SetCameraSpot(nil, 0)
            end
        end
    end
    
    gGameRules:SetPauseDisabled(false)

    if returnToDojo and not IsNull(gGameData) then

        if gMatchingService:IsSquadHost() and gMatchingService:NumSquadMembers() > 1 then
            gMatchingService:SetSquadReturningToLobby(true)
        end

        while _T.GetDojoDataResult == DOJO_DATA_PENDING do
            Sleep(0.1)
        end
        
        if _T.GetDojoDataResult == DOJO_DATA_FAILED then

            print("CREWSHIP: GetDojoData FAILED")
            UTIL.ShowMessage("/Lotus/Language/Menu/Dojo_ConnectionError", AbortMissionOnDojoFailure)

            -- Clean up so that we do not hold everyone else hostage, we're not gonna make it
            if not gRegion:IsMaster() then
                gGameRules:SignalMultiplayerFence(REGION_CREATED_FENCE, CREWSHIP_STREAM_SEQ_MISSION)
            end

            return
        end

        local hubName = _BuildHubName(_T.gDojoData.GuildId, _T.gDojoData.AllianceId)
        gMatchingService:SetSquadHostHubLevelName(hubName)

        _T.GetDojoDataResult = nil
        
        local dojoKeyRes = Resource(dojoKey)
        local mission = dojoKeyRes:GetMission()
        levelArgs = LOTUS_NET.GetMissionOpenLevelArgs(Symbol("DojoHub_HUB"), mission, dojoKeyRes, false, nil, nil, false, true)

        _T.gDojoData = nil

        if not levelArgs then
            print("CREWSHIP: GetDojoData FAILED")
            UTIL.ShowMessage("/Lotus/Language/Menu/Dojo_ConnectionError", AbortMissionOnDojoFailure)

            -- Clean up so that we do not hold everyone else hostage, we're not gonna make it
            if not gRegion:IsMaster() then
                gGameRules:SignalMultiplayerFence(REGION_CREATED_FENCE, CREWSHIP_STREAM_SEQ_MISSION)
            end

            return
        end
    end

    levelArgs.streamingLayer = mStreamingLayer
    levelArgs.streamingMode = GraphicsRes.StreamRegion_InPlace
    
    levelArgs:SetStreamingCallback("OnLevelCreated")

    if gRegion:IsMaster() then
        local level = levelArgs.level
        if not returnToDojo then
            local missionInfo = crewShipMgr:GetNextMission()
            local missionLevel = missionInfo.levelOverride
            levelArgs.level = missionLevel
            LOTUS_NET.AddMissionContextObjects(levelArgs, missionInfo)
            print("Host streaming " .. gMatchingService:GetSquadMission() .. " with MissionInfo: \n" .. missionInfo:EncodeAsString())
        end

        local isPvp = false
        local isArchwing = true
        LOTUS_NET.SetContextObjectsFromSquadLoadOuts(levelArgs, isPvp, isArchwing)

        _waitForStreaming(levelArgs)
    else
        while true do -- clients can theoretically fail due to querying too early, so keep trying
            _waitForStreaming(levelArgs)
            
            if mLevelCreated then
                break
            end
        end
    end
    
    local success = mLevelCreated
    mLevelCreated = nil
    
    if success then
        if gRegion:IsMaster() then
            -- TODO: Clients will need to do this too, so I guess we need to send that encoded string thing to squad members somehow
            local missionInfo = crewShipMgr:GetNextMission()
            gGameRules:SetMission(missionInfo)
        end
    end
    
    gGameRules:SignalMultiplayerFence(REGION_CREATED_FENCE, CREWSHIP_STREAM_SEQ_MISSION)
    if gRegion:IsMaster() then

        _DestroyHubAvatars()

        -- Host waits until everyone has finished creating the level
        gGameRules:SuspendUntilMultiplayerFenceReached(REGION_CREATED_FENCE)
        
        local portForwarders = gRegion:FindTagged(Symbol("OnLevelStreamed"))
        
        for i,portForwarder in ipairs(portForwarders) do
            if not IsNull(portForwarder) then
                local regionIndex = Engine.Zone_GetRegionInstance(portForwarder:GetFullName())
                if regionIndex == mStreamingLayer then
                    portForwarder:FirePort("TriggerPort")
                end
            end
        end

        if not returnToDojo then
            _UnlockGameSession(gMatchingService:GetSession())
        end

        gMatchingService:SetSquadMissionReady(false)
    end

    gGameRules:FinishMultiplayerFenceSequence(CREWSHIP_STREAM_SEQ_MISSION)
    print("CREWSHIP: StreamNextMissionVoidTunnel done")
end

function DestroyTunnelLevel(scriptTrigger)

    gGameRules:SignalMultiplayerFence(Symbol("DT_Start"), DESTROY_TUNNEL_SEQ)

    while IsNull(gGameRules) do
        Sleep(0)
    end

    local crewShipMgr = _getCrewShipMgr()
    gGameRules:EquipWeaponOnSpawn(true)
    
    local regionDestroyed = Symbol("CREWSHIP_REGION_DESTROYED")
    
    _removeStreamedRegion(mTunnelStreamingLayer)
    
    if _T.TunnelIndex ~= nil then
        crewShipMgr:FreeLevelAnchor(true, _T.TunnelIndex)
        _T.TunnelIndex = nil
    end

    gGameRules:SignalMultiplayerFence(regionDestroyed, DESTROY_TUNNEL_SEQ)
    
    if gRegion:IsMaster() then
        -- Host waits until everyone has finished destroying the level
        gGameRules:SuspendUntilMultiplayerFenceReached(regionDestroyed)
    end
    
    local levelInfo = gRegion:GetLevelInfo()
    if Engine.Zone_GetRegionInstance(levelInfo:GetFullName()) == mTunnelStreamingLayer then
        print("CREWSHIP: Destroying tunnel level info")
        gRegion:DestroyObject(levelInfo)
    end
    
    if gRegion:IsMaster() then
        local portCounter = gRegion:FindFirstTagged(WARP_COUNTER_TAG)
        while IsNull(portCounter) do
            Sleep(0)
            portCounter = gRegion:FindFirstTagged(WARP_COUNTER_TAG)
        end

        portCounter:FirePort("Increment")
    end
            
    gGameRules:FinishMultiplayerFenceSequence(DESTROY_TUNNEL_SEQ)
    print("CREWSHIP: DestroyTunnelLevel done")
end

function SelectNextMission()
    if IsNull(starchartRes) then
        return
    end
    
    while IsNull(gGameRules) do
        Sleep(0)
    end
    
    local crewShipMgr = _getCrewShipMgr()
    
    local missionNodeName = _T.RailJackNextMissionNode
    if missionNodeName == nil then
        local squadMission = gMatchingService:GetSquadMission()
        
        if squadMission ~= "" then
            missionNodeName = Symbol(cjson.decode(squadMission).name)
        end

        if missionNodeName == nil then
            missionNodeName = missionNode
        end
    end

    if string.find(tostring(missionNodeName), "Dojo") then
        _RequestDojoData()
    else
        local radialSector = nil
        local mission = nil
        local baseNodeName = tostring(missionNodeName)
        local alertTagIdx = string.find(baseNodeName, LOTUS_UTIL.ALERT_TAG)
        local scenarioTagIdx = string.find(baseNodeName, LOTUS_UTIL.SCENARIO_BEACON_TAG)

        if alertTagIdx then
            baseNodeName = string.sub(baseNodeName, 1, alertTagIdx - 1)
            
            if _T.CachedAlerts and _T.CachedAlerts[baseNodeName] ~= nil then
                mission = _T.CachedAlerts[baseNodeName].mAlertInfo.mMissionInfo
                mission.alertId = _T.CachedAlerts[baseNodeName].mAlertInfo.mId.mId
            end
        else
            local keyTagIdx = string.find(baseNodeName, LOTUS_UTIL.KEY_TAG)
            if keyTagIdx then
                baseNodeName = string.sub(baseNodeName, 1, keyTagIdx - 1)
                local keyRes = Resource(baseNodeName)
                if not IsNull(keyRes) then
                    mission = keyRes:GetMission()
                end
            end
        end
       
        if not mission then
            radialSector = starchartRes:GetNodeForMission(Symbol(baseNodeName))
            mission = radialSector.mission
        end

        if scenarioTagIdx and _G.Scenario and _G.Scenario.Id then
            mission.scenarioId = _G.Scenario.Id
        end
        
        -- load sentient proclevel variant during window of fragment availability (if squad is qualified)
        if WORLD_STATE_UTIL.CheckSentientFragmentAvailable(radialSector) then
            for k,v in pairs(mSentientExterminateKeys) do
                if v.level == mission.levelOverride then
                    local keyRes = Resource(v.key)
                    if not IsNull(keyRes) then
                        local keyMission = keyRes:GetMission()
                        if IsNull(keyMission.questReq) or LOTUS_UTIL.HasCompletedQuest(keyMission.questReq) or gFlashMgr:GetConfigBool("Multiplayer.UnlockAllMissions") then
                            mission = keyMission:Copy()
                            mission.minEnemyLevel = radialSector.mission.minEnemyLevel
                            mission.maxEnemyLevel = radialSector.mission.maxEnemyLevel
                            mission.minSpaceEnemyLevel = radialSector.mission.minSpaceEnemyLevel
                            mission.maxSpaceEnemyLevel = radialSector.mission.maxSpaceEnemyLevel
                            mission.location = radialSector.mission.location
                            if IsNull(mission.enemyCacheOverride) then
                                mission.enemyCacheOverride = radialSector.mission.enemyCacheOverride
                            end
                        end
                    end
                    break
                end
            end
        end

        crewShipMgr:SetNextMission(mission)
    end

    _T.RailJackNextMissionNode = nil
end

function SetupRailjackGameRules()
    while IsNull(gGameRules) do
        Sleep(0)
    end

    -- Needed so that DojoMgr reinitializes properly after coming back from the mission.
    _T.DojoMgr = nil

    if gGameRules:IsA(railjackGameRules) or not gRegion:IsMaster() or not gMatchingService:IsSquadHost() then
        return
    end

    local crewShipMgr = _getCrewShipMgr()
    local missionInfo = crewShipMgr:GetNextMission()

    local gameRulesType = railjackGameRules
    if missionInfo.gameRules then
        gameRulesType = missionInfo.gameRules
    end

    if gGameRules:IsA(gLotusHubGameRulesType) then
        -- Destroy everyone not in our squad (and disable future hub communication, that part is not super
        -- important since we destroy the game rules soon anyway)
        gGameRules:PauseHubUpdates(true)

        -- Save hub avatars
        _T.hubAvatars = gRegion:FindAll(mPeerAvatarType)
        if _T.hubAvatars then
            print("CREWSHIP: Has "..tostring(#_T.hubAvatars).." hub avatar(s)")
        end
    end

    _T.SeamlessRailJackTransition = gGameRules:IsA(gLotusAttractModeGameRulesType)

    local gameRules = gRegion:CreateObject(Type(gameRulesType))
    if not IsNull(gameRules) then
        gameRules:SetMission(missionInfo)

        -- Have to make sure it makes it to the client, before he gets the 'destroy old game rules' message
        gRegion:ForceOpenObject(gameRules)
 
        -- NOTE: order of calls important, need to call InheritCurrentSpawnPosRot first
        -- so that we know it's a 'seamless' connection
        local currentPlayer = gRegion:GetLocalPlayer()
        currentPlayer:InheritCurrentSpawnPosRot()
        gameRules:TrySendLocalPlayerLoadOut()
--        gameRules:EquipWeaponOnSpawn(false)
        gameRules:SpawnPlayer(currentPlayer, Type(railjackTennoAvatarType))
            
        local avatar = currentPlayer:GetAvatar()
        if not IsNull(avatar) then
            avatar:NotifyReadyToSpawn(true)
        end

        -- Respawn all the other dudes
        local playerList = gRegion:GetHumanPlayers()
        for i = 1, #playerList do
            local player = playerList[i]
            if not player:IsLocal() then
                gameRules:ReconnectPlayer(player)
            end
        end
    else
        print("NULL game rules!")
    end
end

local function ResetMalfunctionSpawners()
    local spawners = gRegion:FindAll(gMalfunctionSpawnerType)
    for i = #spawners, 1, -1 do
        local spawner = spawners[i]
        if not IsNull(spawner) then
            spawner:FirePort("RepairAll")
        end
    end
end

function EnterDojoHangar()
    local crewShipMgr = _getCrewShipMgr()
    local ship = crewShipMgr:GetPlayerShip()
    
    if IsNull(ship) then
        return
    end
    
    local crewShipAvatar = ship:GetAvatarOwner()

    ResetMalfunctionSpawners()
    crewShipAvatar:SetHyperDriveState(Lotus_Game.CrewShipAvatar_HDS_POWERING_DOWN)
    
    ship:RefreshBackdrops()
    ship:ExecuteScriptedEvent(Symbol("WarpOff"))
    ship:ExecuteScriptedEvent(Symbol("FlameOff"))
end

function ReadyHyperDrive()
    local crewShipMgr = _getCrewShipMgr()
    local ship = crewShipMgr:GetPlayerShip()
    
    if IsNull(ship) then
        return
    end
    
    local crewShipAvatar = ship:GetAvatarOwner()

    crewShipAvatar:SetHyperDriveState(Lotus_Game.CrewShipAvatar_HDS_READY)
end

