--The order of the arrays matters!
-- 1 = Hull, 2 = Hood Tube, 3 = L Nacelle, 4 = R Nacelle,  5 = Tail, 6 = Hood
consoleActionText = Symbol()
keyChainWRes = WeakResource("/Lotus/Types/Keys/RailJackBuildQuest/RailjackBuildQuestKeyChain")
buildFxType = WeakResource()
inRepairFxType = WeakResource()
transmissionTag = Symbol()
refreshCrewShipTag = Symbol()
blockUntilSuccess = true --for advancing quest stage
contributeMovie = Resource() --Resource("/Lotus/Interface/Dojo/ResearchContribution.swf") --Resource()
inputFilter = Resource() --Resource("/Lotus/Types/Game/InputFilters/LotusCinematicInputFilter")
installPartsSound = Resource()
contributionSuccessSound = Resource()
contributionCompletedSound = Resource()
openContributeScreenSound = Resource()
railjackPartBlueprintItems =
{
    WeakResource("/Lotus/Types/Items/ShipFeatureItems/Railjack/RailjackHullFeatureItemBlueprint"),
    WeakResource("/Lotus/Types/Items/ShipFeatureItems/Railjack/RailjackHoodBraceFeatureItemBlueprint"),
    WeakResource("/Lotus/Types/Items/ShipFeatureItems/Railjack/RailjackNacelleLeftFeatureItemBlueprint"),
    WeakResource("/Lotus/Types/Items/ShipFeatureItems/Railjack/RailjackNacelleRightFeatureItemBlueprint"),
    WeakResource("/Lotus/Types/Items/ShipFeatureItems/Railjack/RailjackTailFeatureItemBlueprint"),
    WeakResource("/Lotus/Types/Items/ShipFeatureItems/Railjack/RailjackHoodFeatureItemBlueprint")
}

-- Tied to the different blueprint items, in each pair, 1 is the step for installing the part, 2 is repairing
-- 1-based
local questStepsForParts =
{
    { 3, 4 },
    { 6, 7 },
    { 9, 10 },
    { 12, 13 },
    { 15, 16 },
    { 18, 19 }
}

local questMissionStages = {2,5,8,11,14,17}

local partTags = 
{
    Symbol("PartHull"),
    Symbol("PartHoodTube"),
    Symbol("PartLeftNacelle"),
    Symbol("PartRightNacelle"),
    Symbol("PartTail"),
    Symbol("PartHood")
}

local partPortTags = 
{
    Symbol("PartHullPort"),
    Symbol("PartHoodTubePort"),
    Symbol("PartLeftNacellePort"),
    Symbol("PartRightNacellePort"),
    Symbol("PartTailPort"),
    Symbol("PartHoodPort")
}

local revealTags = 
{
    Symbol("ShipConstructionHull"),
    Symbol("ShipConstructionHoodTube"),
    Symbol("ShipConstructionLeftNacelle"),
    Symbol("ShipConstructionRightNacelle"),
    Symbol("ShipConstructionTail"),
    Symbol("ShipConstructionHood")
}

local hullAddOns = {
    WeakResource("/Lotus/Objects/Tenno/Ships/RailJack/Caps/RailJackHullTopTechCapDeco"),
    WeakResource("/Lotus/Objects/Tenno/Ships/RailJack/Caps/RailJackHullLeftTechCapDeco"),
    WeakResource("/Lotus/Objects/Tenno/Ships/RailJack/Caps/RailJackHullRightTechCapDeco")
}
    

local transmissionSet = Resource("/Lotus/Sounds/Dialog/RailJack/CephalonCy/CephalonCyRailjackQuestTransmissions")
local cameraSpotTime = 15 --leave as 0 to force wait until transmissions are finished, otherwise wait this long on the camera spot
local sAuxBlend = Symbol("AuxBlendingConstant_AuxBlendingBase")
local dirtyBlendBase = 1.25
local cleanBlendBase = -1
local mGotCallback = false
local mCallbackSuccess = false
local dockedCinematicStage = 20
local integrateCyStage = 21
local endOfQuestMovieType = WeakResource("/Lotus/Interface/EndOfQuest.swf")

local POST = require "Lotus.Scripts.Libs.PostProcessLib"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"

local function ClearObjectives()
    local marker = gRegion:FindFirstTagged(Symbol("InstallCyMarker"))
    if not IsNull(marker) then
        marker:Disable()
    end
    OBJTXT.ClearPrimaryObjText()
    OBJTXT.ClearSecondaryObjText()
end

local function MarkExit(console)
    ClearObjectives()
    Sleep(1)
    OBJTXT.SetPrimaryObjText("/Lotus/Language/Menu/RetunToShipUpperCase", OBJTXT.EXTRACT_ICON)
    local exitMarker = gRegion:FindFirstTagged(Symbol("LeaveDojoMarker"))
    if not IsNull(exitMarker) then
        exitMarker:Enable()
    end
    if not IsNull(console) then
        console:Disable()
    end
end

local function GetPersonalTechProject(pRecipe)
    local techProjects = gGameData:GetPersonalTechProjects()
    local techProject = nil
    for i = 1, #techProjects do
        if techProjects[i].mItemType:GetFullName() == pRecipe:GetFullName() then
            techProject = techProjects[i]

            break
        end
    end

    return techProject
end

local function OpenContributeMovie(pTechProject)
    if IsNull(contributeMovie) or IsNull(_T.BackgroundMovie) then
        return
    end

	UTIL.PlaySound(openContributeScreenSound)

    _T.OnContributionMade =
        function(pSuccess)
            _T.OnContributionMade = nil
            local avatar = gRegion:GetLocalPlayerAvatar()
            if pSuccess then
                -- Made a contribution, maybe do something here, transmission, check if it's fully
                -- contributed and show timer or message?
                local updatedTechProject = GetPersonalTechProject(pTechProject.mItemType)
                if updatedTechProject ~= nil and updatedTechProject.mState == 1 then
                    -- Fully contributed
                    local timeLeft = Engine.GetRelativeSeconds(updatedTechProject.mCompletionDate:Copy())
                    local timeLeftText = Localize("/Lotus/Language/Railjack/RailjackQuestRepairProgressAlt", { TIME = LOTUS_UTIL.GetTwitterStyleTime(timeLeft, false, true) })
                    UTIL.ShowMessage(timeLeftText)
                    if not IsNull(avatar) then
                        DIALOG.PlayLocalTransmission(transmissionSet, Symbol("AllResourcesDone"), 0, avatar)
                    end
					UTIL.PlaySound(contributionCompletedSound)
                    ClearObjectives()
                else
                    if not IsNull(avatar) then
                        DIALOG.PlayLocalTransmission(transmissionSet, Symbol("PartialResourcesDone"), 0, avatar)
                    end
                    UTIL.ShowMessage("/Lotus/Language/Menu/ContributionSucessful")
					UTIL.PlaySound(contributionSuccessSound)
                end
            end
        end
    _T.mSelectedElementForContribution = { Recipe = pTechProject.mItemType, mTechItem = pTechProject, mCallback = "OnContributionMade", mSkipContributeSuccessMsg = true }
    _T.DojoResearchContribution = true
    local contribMovie = gFlashMgr:PushMovie(contributeMovie)
end

local function AdvanceToNextStage(gameData)
    local activeQuest, missionIndex, difficulty = LOTUS_UTIL.GetActiveQuest(gameData) -- MissionIndex returns stage from 1
    if not IsNull(activeQuest) and not IsNull(missionIndex) then
        local completeIndex = missionIndex - 1
        
        mCallbackSuccess = false
        mGotCallback = false
        gameData:CompleteQuestStage(completeIndex, "QuestCompleteCallback") -- CompleteQuestStage requires stage starting from 0

        local retryTime = 3
        local t = -1
        local blockingMsgTimer = 0
        local blockingMsgShown = false
        if not blockUntilSuccess then
            blockingMsgTimer = -1
        end
        
        while not mCallbackSuccess do
            local dt = RealDeltaTime()
            
            if blockingMsgTimer >= 0 then
                blockingMsgTimer = blockingMsgTimer + dt
            end
            if blockingMsgTimer > 2 then
                _T.BackgroundMovie:Execute("ShowBlockingMessage", "1")
                blockingMsgShown = true
                blockingMsgTimer = -1
            end
            
            if mGotCallback then
                t = 0
            end
            
            if t >= 0 then
                t = t + dt
            end
            if t > retryTime then
                t = -1
                retryTime = math.min(retryTime * 2, 60)
                mGotCallback = false
                gameData:CompleteQuestStage(completeIndex, "QuestCompleteCallback")
            end
            Sleep(0)
        end
        
        if blockingMsgShown then
            _T.BackgroundMovie:Execute("ShowBlockingMessage", "0")
        end

        LOTUS_UTIL.UpdateQuests()
    end
end

local function ToggleVisHangarEntities(visible)
    local entities = gRegion:FindTagged(Symbol("HangarHide"))
    for i = 1, #entities do
        entities[i]:SetVisibility(visible, true)
    end
end

--hide host RJ if it exists, and show all parts that were hidden due to host ship
local function ToggleExistingShip(shipAvatar, partIndex, visible)
    if not IsNull(shipAvatar) then
        shipAvatar:SetVisibility(visible, true)
        local int = math.max(1, partIndex - 1)
        for i = 1, int do
            local builtPart = gRegion:FindFirstTagged(partTags[i])
            if not IsNull(builtPart) then
                builtPart:SetVisibility(not visible, true)
            end
        end
    end
end
 
local function SetCameraSpotAndReveal(cameraSpot, avatar, partIndex, revealPiece)
    POST.Fade(1, 0.1)
    
    local shipAvatar = gRegion:FindFirstTagged(Symbol("RailJackAvatar"))
    
    if revealPiece then
        ToggleVisHangarEntities(false)
        ToggleExistingShip(shipAvatar, partIndex, false)
        
        local partInstance = gRegion:FindFirstTagged(partTags[partIndex])
    
        if not IsNull(partInstance) then
            partInstance:SetVisibility(true, true)
            partInstance:SetMaterialParam(sAuxBlend, 0.7, dirtyBlendBase, 0, 0) --(symbol, value for constant, value for base, ...)
            UTIL.PlaySound(installPartsSound)            
			local buildFx = partInstance:GetAttachment(buildFxType)
            if not IsNull(buildFx) then
                buildFx:Enable()
            end
            local repairFx = partInstance:GetAttachment(inRepairFxType)
            if not IsNull(repairFx) then
                repairFx:Enable()
            end
        end
        local partPortInstance = gRegion:FindFirstTagged(partPortTags[partIndex])
    
        if not IsNull(partPortInstance) then
            partPortInstance:FirePort("TriggerPort")
        end
    else
        ToggleVisHangarEntities(true)
        ToggleExistingShip(shipAvatar, partIndex, true)
    end
    
    avatar:CameraControl():SetCameraSpot(cameraSpot, 0.1)
    Sleep(0.2)
    POST.Fade(0, 0.6)
    
end

local function TriggerReveal(partIndex)
    local cameraSpot = gRegion:FindFirstTagged(revealTags[partIndex])
    local avatar = gRegion:GetLocalPlayerAvatar()
    
    avatar:SetHudHidden(true)
    if not IsNull(inputFilter) then
        avatar:PushInputFilter(inputFilter)
    end
    
    SetCameraSpotAndReveal(cameraSpot, avatar, partIndex, true)
    
    local foundTrans = DIALOG.PlayLocalTransmission(transmissionSet, revealTags[partIndex], 0, avatar)
    --[[if IsNull(cameraSpot) or not foundTrans then
        return
    end]]
    if IsNull(cameraSpot) or not foundTrans then
        Sleep(2)
    else
        local t = 5
        while IsNull(_T.curTransmission) and t > 0 do --wait for transmission to start
            t = t - DeltaTime()
            Sleep(0)
        end
        
        if cameraSpotTime == 0 then
            DIALOG.WaitForTransmissionsToComplete()
        else
            local cameraWait = 0
            while cameraWait < cameraSpotTime and not IsNull(_T.curTransmission) do
                cameraWait = cameraWait + DeltaTime()
                Sleep(0)
            end
        end
    end
    
    SetCameraSpotAndReveal(nil, avatar, partIndex, false)
    
    avatar:SetHudHidden(false)
    if not IsNull(inputFilter) then
        avatar:PopInputFilter(inputFilter)
    end
    
    local activeQuest = gGameData:GetInventory():GetActiveQuest()
    if activeQuest == keyChainWRes then
        _T.BackgroundMovie:Execute("ShowBlockingMessage", "2")
        AdvanceToNextStage(gGameData)

        -- Want to go right into ResearchContribution from here, so ping PersonalTechProjects every .5s for
        -- 5s. If it gets created in that time, open ResearchContribution, otherwise oh well.
        local spinTime = 5
        local repairRecipe = railjackPartBlueprintItems[_T.RailjackConstruction_PartBlueprintIndex]
        if not IsNull(repairRecipe) then
            while spinTime > 0 do
                Sleep(0.5)
                spinTime = spinTime - 0.5

                local techProject = GetPersonalTechProject(repairRecipe)
                if not IsNull(techProject) then
                    OpenContributeMovie(techProject)

                    break
                end
            end
        end

        _T.RailjackConstruction_PartBlueprintIndex = nil
        _T.BackgroundMovie:Execute("ShowBlockingMessage", "0")
        
        return true
    end
    
    return false
end

local function ToggleRailjackAnimNames(setAnimName)
    local part = nil
    local animName = Symbol("")
    if setAnimName then
        animName = Symbol("RailJack")
    end
    
    for i = 1, #partTags do
        part = gRegion:FindFirstTagged(partTags[i])
        if not IsNull(part) then
            part:SetAnimName(animName)
        end
    end
end

function QuestCompleteCallback(result, body)
    mCallbackSuccess = result
    mGotCallback = true
end
 
function OnCephalonUnlocked(success, body)
    _T.BackgroundMovie:Execute("ShowBlockingMessage", "0")

    if success then
        -- Will play transmission and give inbox message.
    else
        UTIL.ShowErrorMessage("/Lotus/Language/Railjack/RailjackQuestErrorCephalonInstall")
    end
end

function OnRepairRecipeStarted(success, body)
    if not success then
        UTIL.ShowErrorMessage("/Lotus/Language/Railjack/RailjackQuestErrorStartTechProject")

        return
    end

    -- Do camera spot, transmission stuff for showing part go into Railjack?
    local partRecipe = railjackPartBlueprintItems[_T.RailjackConstruction_PartBlueprintIndex]
    if IsNull(partRecipe) then
        return
    end
    
    local techProject = GetPersonalTechProject(partRecipe)
    OpenContributeMovie(techProject)

    _T.RailjackConstruction_PartBlueprintIndex = nil
end

function OnInboxSync(result, post)
    if result and gGameData:HasUnreadMailboxMessages() then
        _T.gQueueMailbox = true
    end
end

function OnInventorySynced(result, post)
    _T.BackgroundMovie:Execute("ShowBlockingMessage", "0")
    if result then
        gGameData:SyncInbox("OnInboxSync")
    end
end

function OnConfirmIntegrateCy(result)
    local advanceStage = false
    local transTag = Symbol("IntegrateCyNo")
    if tonumber(result) == Engine.CI_SELECT then
        advanceStage = true
        transTag = Symbol("IntegrateCyYes")
    end

    _T.RailjackQuest_IntegrateCyChoice = advanceStage
    DIALOG.PlayLocalTransmission(transmissionSet, transTag, 0, _T.RailjackQuest_Avatar)
    _T.RailjackQuest_Avatar = nil
end

function RailjackConstruction(entity, avatar)
    if IsNull(gGameData) or IsNull(gGameRules) or IsNull(_T.BackgroundMovie) then
        return
    end

    local activeQuest, missionIndex, difficulty, canProgress = LOTUS_UTIL.GetActiveQuest(gGameData)
    if IsNull(activeQuest) or activeQuest ~= keyChainWRes then
        -- Console should be disabled if our activeQuest isn't the RailjackBuild
        return
    elseif missionIndex == dockedCinematicStage then
        ClearObjectives()

        local finaleCinematic = gRegion:FindFirstTagged(Symbol("RepairedRailjack"))
        if not IsNull(finaleCinematic) then
            ToggleRailjackAnimNames(true)
            finaleCinematic:FirePort("StartPlaying")
            ToggleVisHangarEntities(false)
            
            while finaleCinematic:IsPlaying() do
                Sleep(0)
            end
            
            ToggleVisHangarEntities(true)
            ToggleRailjackAnimNames(false)

        end
        Sleep(1)
        AdvanceToNextStage(gGameData)
        return
    elseif missionIndex == integrateCyStage then
        _T.RailjackQuest_Avatar = avatar
        UTIL.ShowYesOrNoMessage("/Lotus/Language/Railjack/RailjackQuestIntegrateCyConfirm", "OnConfirmIntegrateCy")

        while _T.RailjackQuest_IntegrateCyChoice == nil do
            Sleep(0.1)
        end

        if _T.RailjackQuest_IntegrateCyChoice then
            ClearObjectives()
            entity:Disable()
            Sleep(1)
            DIALOG.WaitForTransmissionsToComplete()
            Sleep(1)
            
            AdvanceToNextStage(gGameData)

            -- Wait for EoQ to appear before refreshing hangar.
            local endOfQuestMovie = nil
            while IsNull(endOfQuestMovie) do
                Sleep(0.1)
                
                endOfQuestMovie = gFlashMgr:FindMovie(endOfQuestMovieType)
            end

            local refreshHangarTrigger = gRegion:FindFirstTagged(refreshCrewShipTag)
            if not IsNull(refreshHangarTrigger) then
                _T.RailjackQuest_UseProfileLoadout = true
                refreshHangarTrigger:FirePort("Execute")

                while _T.CrewShip == nil do
                    Sleep(0.1)
                end

                for i = 1, #partTags do
                    local partInstance = gRegion:FindFirstTagged(partTags[i])
                    if not IsNull(partInstance) then
                        partInstance:SetVisibility(false, true)
                    end
                end
            end
        end
        _T.RailjackQuest_IntegrateCyChoice = nil

        return
    end

    local installCinPlayed
    if gGameData:HasShipFeature(LOTUS_UTIL.SF_RAILJACK_CEPHALON) then
        local foundPart = false
        for i = 1, #questStepsForParts do
            local installIndex = questStepsForParts[i][1]
            local repairingIndex = questStepsForParts[i][2]
            if missionIndex == installIndex or missionIndex == repairingIndex then
                foundPart = true

                if missionIndex == installIndex then
                    -- Have broken part, install step
                    _T.RailjackConstruction_PartBlueprintIndex = i
                    ClearObjectives()
                    installCinPlayed = TriggerReveal(_T.RailjackConstruction_PartBlueprintIndex) -- do transmission, cameraspot, show piece here
                end                
                
                if missionIndex == repairingIndex or installCinPlayed then
                    -- Part installed, repairing it.
                    local partRecipe = railjackPartBlueprintItems[i]
                    local techProject = GetPersonalTechProject(partRecipe)

                    if techProject ~= nil then
                        if techProject.mState == 1 then
                            -- Fully contributed
                            ClearObjectives()
                            -- To Do: Add UI timer? -- no the final timer will be several hours. the 2m timer is temp only
                            local timeLeft = Engine.GetRelativeSeconds(techProject.mCompletionDate:Copy())
                            if timeLeft > 0 then
                                local timeLeftText = Localize("/Lotus/Language/Railjack/RailjackQuestRepairProgress", { TIME = LOTUS_UTIL.GetTwitterStyleTime(timeLeft, false, true) })
                                UTIL.ShowMessage(timeLeftText)
                                
                                if not IsNull(avatar) then
                                    DIALOG.PlayLocalTransmission(transmissionSet, Symbol("AllResourcesDoneReminder"), 0, avatar)
                                end
                            else
                                -- Fully contributed and past completion date, CheckPersonalTechProjectAdvance should advance quest,
                                -- Show message just in case?
                                UTIL.ShowMessage("/Lotus/Language/Railjack/RailjackQuestRepairComplete")
                            end
                        else
                            if not installCinPlayed then
                                OpenContributeMovie(techProject)
                            end
                        end
                    end
                end

                break
            end
        end

        if not foundPart then
            -- In a find the part quest step
            UTIL.ShowMessage("/Lotus/Language/Railjack/RailjackQuestFindPart")
            MarkExit(entity)
        end
    elseif gGameData:CanUnlockShipFeature(LOTUS_UTIL.SF_RAILJACK_CEPHALON) then
        _T.BackgroundMovie:Execute("ShowBlockingMessage", "2")
        gGameData:UnlockShipFeature(LOTUS_UTIL.SF_RAILJACK_CEPHALON, WeakResource(""), 0, "OnCephalonUnlocked")
    else
        UTIL.ShowMessage("/Lotus/Language/Railjack/RailjackQuestBuildCephCy")
    end
end



--on entity slot of the parts console
function ToggleConsole(entity)
    while IsNull(gGameRules) or not gGameRules:IsA(gLotusHubGameRulesType) do
        Sleep(0)
    end
    
    if IsNull(gGameData) then
        return
    end
    
    local activeQuest = gGameData:GetInventory():GetActiveQuest()
    if not IsNull(entity) then
        if activeQuest ~= keyChainWRes or gGameData:GetGuildId() ~= gGameRules:GetGuildId() then
            entity:Disable()
            return
        elseif not IsNull(activeQuest) and activeQuest == keyChainWRes then
            local quest, missionIndex, difficulty = LOTUS_UTIL.GetActiveQuest(gGameData)
            while IsNull(missionIndex) do
                Sleep(1)
                quest, missionIndex, difficulty = LOTUS_UTIL.GetActiveQuest(gGameData)
            end
            for i, q in ipairs(questMissionStages) do
                if missionIndex == q then
                    entity:Disable()
                    return
                end
            end
        end
    end
end

function SetupPartsOnLevelLoad(entity)
    if LOTUS_UTIL.HasCompletedQuest(keyChainWRes) then
        return
    end
    local allPartsRepaired = false
    --disable the build fx if all repairs are complete
    local activeQuest, missionIndex, difficulty = LOTUS_UTIL.GetActiveQuest(gGameData) -- MissionIndex returns stage from 1

    if activeQuest == keyChainWRes and missionIndex >= activeQuest:GetNumChainStages() - 1 then
        allPartsRepaired = true
    end

    for i = 1, #railjackPartBlueprintItems do
        local partRecipe = railjackPartBlueprintItems[i]
        local techProject = GetPersonalTechProject(partRecipe)
        local partInstance = gRegion:FindFirstTagged(partTags[i])
        local hullPart = gRegion:FindFirstTagged(partTags[1])
        
        if not IsNull(techProject) and not IsNull(partInstance) then  
            partInstance:SetVisibility(true, true)

            --remove the extra bits that are stuck on the hull during construction
            --to prevent some minor zfighting
            local addOnWRes
            if i == 2 then
                addOnWRes = hullAddOns[1]
            elseif i == 3 then
                addOnWRes = hullAddOns[2]
            elseif i == 4 then
                addOnWRes = hullAddOns[3]
            end
            
            local addOn = hullPart:GetAttachment(addOnWRes)
            if not IsNull(addOn) then
                addOn:Destroy()
            end
            
            local repairing = true
            if techProject.mState == 1 then
                local timeLeft = Engine.GetRelativeSeconds(techProject.mCompletionDate:Copy())
                if timeLeft <= 0 then
                    repairing = false
                end
            end

            if repairing then
                partInstance:SetMaterialParam(sAuxBlend, 0.7, dirtyBlendBase, 0, 0) --(symbol, value for constant, value for base, ...)
                local repairFx = partInstance:GetAttachment(inRepairFxType)
                if not IsNull(repairFx) then
                    repairFx:Enable()
                end
            end
            
            if not allPartsRepaired then
                local buildFx = partInstance:GetAttachment(buildFxType)
                if not IsNull(buildFx) then
                    buildFx:Enable()
                end
            end
        end
    end
end

function SetPartRepaired(entity)

    local allPartsRepaired = false
    --disable the build fx if all repairs are complete
    local activeQuest, missionIndex, difficulty = LOTUS_UTIL.GetActiveQuest(gGameData) -- MissionIndex returns stage from 1
    if activeQuest == keyChainWRes and missionIndex >= activeQuest:GetNumChainStages() - 1 then
        allPartsRepaired = true
    end

    for i = 1, #railjackPartBlueprintItems do
        local partRecipe = railjackPartBlueprintItems[i]
        local techProject = GetPersonalTechProject(partRecipe)
        local partInstance
        
        if IsNull(techProject) then -- the previous entry was the last completed project
            partInstance = gRegion:FindFirstTagged(partTags[math.max(1 , i - 1)])
        elseif i == #railjackPartBlueprintItems then -- we're on the last part
            partInstance = gRegion:FindFirstTagged(partTags[i])
        end
        
        if not IsNull(partInstance) then  
            local t = 0
            local currentBlendBase
            while t < 1 do
                currentBlendBase = Lerp(dirtyBlendBase, cleanBlendBase, t)
                partInstance:SetMaterialParam(sAuxBlend, 0.7, currentBlendBase, 0, 0) --(symbol, value for constant, value for base, ...)
                t = t + DeltaTime()
                Sleep(0)
            end
            partInstance:SetMaterialParam(sAuxBlend, 0.7, cleanBlendBase, 0, 0) --(symbol, value for constant, value for base, ...)
            local repairFx = partInstance:GetAttachment(inRepairFxType)
            if not IsNull(repairFx) then
                repairFx:Disable()
            end
            if allPartsRepaired then
                local buildFx = partInstance:GetAttachment(buildFxType)
                if not IsNull(buildFx) then
                    buildFx:Disable()
                end
            end
            break
        end
    end
end

function DojoHubStageSetup()    
    local console = gRegion:FindFirstTagged(Symbol("RailjackRepairConsole"))
    if not IsNull(console) then
        local activeQuest, missionIndex, difficulty, canProgress = LOTUS_UTIL.GetActiveQuest(gGameData)
        local locTag = tostring(activeQuest:GetLocalizeTagForChainStage(missionIndex-1))
        OBJTXT.SetPrimaryObjText(locTag)
        console:SetActionText(tostring(consoleActionText))
        local marker = gRegion:FindFirstTagged(Symbol("InstallCyMarker"))
        if not IsNull(marker) then
            marker:FirePort("Enable")
        end
        
        if not console:IsEnabled() then
            console:FirePort("Enable")
        end
    end
end

function PlayTransmission()
    local avatar = gRegion:GetLocalPlayerAvatar()
    if not IsNull(avatar) then
        DIALOG.PlayLocalTransmission(transmissionSet, transmissionTag, 0, avatar)
    end
end
