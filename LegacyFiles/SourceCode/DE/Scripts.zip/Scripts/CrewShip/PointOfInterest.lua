commonLootCrateTypes = {Type()}
uncommonLootCrateTypes = {Type()}
rareLootCrateTypes = {Type()}
ultraRareLootCrateTypes = {Type()}
commonChanceOverride = 0
uncommonChanceOverride = 0
rareChanceOverride = 0
ultraRareChanceOverride = 0
maxCommon = 10
maxUncommon = 5
maxRare = 0
maxUltraRare = 0
destroyInfestedTaggedEntities = true
lockerOpenPctOverride = 0
ignoreExteriorTypes = {WeakResource()}

local RAIL = require "Lotus.Scripts.Libs.RailjackUtilities"

local lootSpawned = false
local sCommon = Symbol("LootCrate")
local sRare = Symbol("RareLootCrateWaypoint")
local sUltra = Symbol("UltraRareLootCrateWaypoint")

local mCommonPoints = nil
local mRarePoints = nil
local mUltraRarePoints = nil

local function SpawnCrates(types, count, points)
    for i = 1, count do
        local crateType = types[RandomInt(1, #types)]
        if #points == 0 then
            return
        end
        
        local pointIndex = RandomInt(1, #points)
        local point = points[pointIndex]
        table.remove(points, pointIndex)
        if not IsNull(point) then
            gRegion:CreateEntity(crateType, point:GetPosition(), point:GetRotation())
        end
    end
end

local function SpawnCratesOnPOI(numCommon, numUncommon, numRare, numUltraRare)
    lootSpawned = true
    
    print("Spawning " .. numCommon .. " " .. numUncommon .. " " .. numRare .. " " .. numUltraRare)
    
    SpawnCrates(commonLootCrateTypes, numCommon, mCommonPoints)
    SpawnCrates(uncommonLootCrateTypes, numUncommon, mCommonPoints)
    SpawnCrates(rareLootCrateTypes, numRare, mRarePoints)
    SpawnCrates(ultraRareLootCrateTypes, numUltraRare, mUltraRarePoints)
end

local function OpenLocker(locker)
    local thiefTrigger = locker:GetAttachment(WeakResource("/Lotus/Types/LevelObjects/LockerAttachments/ThiefScriptTrigger"))
    if not IsNull(thiefTrigger) then
        thiefTrigger:Destroy()
    end

    local hitSwitch = locker:GetAttachment(WeakResource("/Lotus/Types/LevelObjects/LockerAttachments/LockerReplicatedHitSwitch"))
    if not IsNull(hitSwitch) then
        hitSwitch:FirePort("Enable")
    end
    
    local eDeco = locker:GetAttachment(WeakResource("/Lotus/Types/LevelObjects/LockerAttachments/LockerOpenIconDeco"))
    if not IsNull(eDeco) then
        eDeco:FirePort("Show")
    end
    
    locker:FirePort("MaterialSwitch")
end

local function OpenLockersOnPOI(crewShip)
    local lockers = RAIL.FindTaggedOnShip(Symbol("Locker"), crewShip)
    
    if not IsNull(lockers) and #lockers > 0 then
        local minLockersToOpen = 8
        local openPct = 0.5
        if lockerOpenPctOverride > 0 then
            openPct = math.min(lockerOpenPctOverride, 1)
        end
        
        local numOpen = math.max( math.ceil(#lockers * openPct), minLockersToOpen)
        numOpen = math.min(#lockers, numOpen)
        
        for i = 1, numOpen do
            local r = RandomInt(1, #lockers)
            OpenLocker(lockers[r])
            table.remove(lockers, r)
        end
    end    
end

function OnCrewShipSpawned(crewShip)
    --TODO: condense this with CrewShipLoot.lua a bit to kill some of this duplicate script
    commonLootCrateTypes = commonLootCrateTypes
    uncommonLootCrateTypes = uncommonLootCrateTypes
    rareLootCrateTypes = rareLootCrateTypes
    ultraRareLootCrateTypes = ultraRareLootCrateTypes

    mCommonPoints = RAIL.FindTaggedOnShip(sCommon, crewShip)
    mRarePoints = RAIL.FindTaggedOnShip(sRare, crewShip)
    mUltraRarePoints = RAIL.FindTaggedOnShip(sUltra, crewShip)

    if commonChanceOverride > 0 or uncommonChanceOverride > 0 or rareChanceOverride > 0 or ultraRareChanceOverride > 0 then
        local numCommonToSpawn = 0
        for i = 1, maxCommon do
            local r = math.random()
            if r <= commonChanceOverride then
                numCommonToSpawn = numCommonToSpawn + 1
            end
        end
    
        local numUncommonToSpawn = 0
        for i = 1, maxUncommon do
            local r = math.random()
            if r <= uncommonChanceOverride then
                numUncommonToSpawn = numUncommonToSpawn + 1
            end
        end
    
        local numRareToSpawn = 0
        for i = 1, maxRare do
            local r = math.random()
            if r <= rareChanceOverride then
                numRareToSpawn = numRareToSpawn + 1
            end
        end
    
        local numUltraRareToSpawn = 0
        for i = 1, maxUltraRare do
            local r = math.random()
            if r <= ultraRareChanceOverride then
                numUltraRareToSpawn = numUltraRareToSpawn + 1
            end
        end

        SpawnCratesOnPOI(numCommonToSpawn, numUncommonToSpawn, numRareToSpawn, numUltraRareToSpawn)
    else
        if IsNull(_T.CrewShipLootSpawnFuncs) then
            _T.CrewShipLootSpawnFuncs = {}
        end
    
        table.insert(_T.CrewShipLootSpawnFuncs, SpawnCratesOnPOI)
    end

    if destroyInfestedTaggedEntities then
        local infested = RAIL.FindTaggedOnShip(Symbol("Infested"), crewShip)
        for i=1,#infested do
            local e = infested[i]
            if not IsNull(e) then
                gRegion:DestroyObject(e)
            end
        end
    end
    
    OpenLockersOnPOI(crewShip)
    
    while not lootSpawned do
        Sleep(0)
    end
end

function PointOfInterestReplicaSetup(trigger)
    local poiAvatarWRes = WeakResource("/Lotus/Types/Game/CrewShip/PointOfInterestAvatar")
    local avatar = nil
    local waitTime = 0
    while IsNull(avatar) do
        avatar = gRegion:FindNearest(poiAvatarWRes, trigger:GetPosition(), 250)    
        if IsNull(avatar) then
            Sleep(1)
            waitTime = waitTime + 1
            if waitTime >= 10 then
                return --give up
            end
        end
    end
    
    local inv = avatar:InventoryControl()
    local ship = inv:GetActivePowerSuit()

    waitTime = 0
    while IsNull(ship) do
        Sleep(0)
        ship = inv:GetActivePowerSuit()
        waitTime = waitTime + DeltaTime()
        if waitTime >= 10 then
            return --give up
        end
    end

    ship:SetExteriorScope(trigger, ignoreExteriorTypes)
end