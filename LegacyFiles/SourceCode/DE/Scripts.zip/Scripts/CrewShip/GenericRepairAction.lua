repairStartAnim = Resource()
repairAnim = Resource()
repairCompleteAnim = Resource()
duration = 3
hackDevice = Instance()
cinematicTag = Symbol()
itemType = Type()
storeItemType = Resource()
survivalRewardsMovie = Resource()

local mCancelPressed = false
local mAction = nil

function UsePressed(inputEventData)
    if inputEventData == 1 then
        mCancelPressed = true
        for i, callback in ipairs(_T.RepairActionCancelledCallbacks) do
            callback(mAction)
        end
    end
end

function Repair(action, instigator)
    mAction = action
    instigator:PlayNonReplicatedAnimation(repairStartAnim, true, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_FREEZE, true)
    instigator:PlayNonReplicatedAnimation(repairAnim, false, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_LOOP, true)
    local player = instigator:GetPlayer()
    if player:IsLocal() then
        player:PushScriptedInputHandler(Symbol("RepairAction"), gFlashMgr:GetInputCodeValue("USE"), "UsePressed")
    end
    
    while 
        not mCancelPressed and
        not instigator:IsKilled() and 
        action:IsEnabled()
    do
        Sleep(0)
    end
    if player:IsLocal() then
        player:PopScriptedInputHandler(Symbol("RepairAction"), gFlashMgr:GetInputCodeValue("USE"))
    end
    instigator:PlayNonReplicatedAnimation(repairCompleteAnim, true, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_ONCE, true)
end

function UseAction(action, instigator)
    local cinematic = gRegion:FindNearestTagged(cinematicTag, action:GetPosition()) --this will need to change if we have more than one
    instigator:SetAnimName(Symbol("Tenno"))
    if gRegion:IsMaster() then
        cinematic:SetInstigatorAvatar(instigator)
    end

    if instigator:ReplicaLocallyControlled() then
        local inv = instigator:InventoryControl()
        local mainHandWeapon = inv:GetWeaponInHand(Engine.MAIN_HAND)
            
        inv:Unequip(Engine.MAIN_HAND, Engine.InventoryControllerBase_ES_INSTANT_EQUIP)
    end
    
    if gRegion:IsMaster() then
        cinematic:FirePort("StartPlaying")
    else
        while not cinematic:IsPlaying() do
            Sleep(0)
        end
    end
    
    while cinematic:IsPlaying() do
        Sleep(0)
    end
    
    if instigator:ReplicaLocallyControlled() then
        instigator:InventoryControl():EquipBestWeapon(false, true, false)
    end
    
    if not IsNull(itemType) then
        if gRegion:IsMaster() then
            local players = gRegion:GetHumanPlayers()
            for i, player in ipairs(players) do
                player:SendGiveItem(itemType, 1)
            end
        end
    end
    
    local movie = gFlashMgr:PushMovie(survivalRewardsMovie)
    if not IsNull(movie) then
        _T.DisplayReward(storeItemType, 1)
    end

end