doorFrameType = WeakResource()
minDistance = 0
maxDistance = 1

function EnableEmissives(instigator)

    local doorframes = {}

    local position = instigator:GetPosition()
    
    doorframes = gRegion:FindAll(doorFrameType,position,minDistance,maxDistance)
    
    if IsNull(doorframes) then
        return
    end
    
    for i = 1, #doorframes do
        doorframes:SetMaterialParam(Lotus_Game.EMISSIVE_MAP_ATTEN, 0)
    end

end