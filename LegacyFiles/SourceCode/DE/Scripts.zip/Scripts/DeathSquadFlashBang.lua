embedDelay = 0.2
maxRadius = 6

fadeDuration = 5
blindedDuration = 1
blindProjector = Type()
beamType = Type()
BlindedLocalSound = Resource()

local postFade = require "Lotus.Scripts.PostProcess.BasePostProcessFade"

function OnStopped(projectile)

    Sleep(embedDelay)
    local position = projectile:GetPosition()
    
    local victims = gRegion:FindAll(gBaseAvatarType, projectile:GetPosition(), 0, maxRadius)
        
    local emptySym = Symbol()
    local attachBone = Symbol("GAME_C1_HEAD1")
    local attachPos = Vector()
    local attachRot = Rotation()
    local dd = nil

    for i=1, #victims do
        if not victims[i]:IsA(gLotusNpcAvatarType) and not victims[i]:IsA(gLotusSentinelAvatarType) and not victims[i]:IsDeadType() then
            local beam = victims[i]:Attach(beamType, attachBone, attachPos, attachRot)

            if not IsNull(beam) then
                beam:SetEndPoint(position)
            end

            victims[i]:Attach(blindProjector, emptySym, attachPos, attachRot)

            if victims[i]:ReplicaLocallyControlled() then
                victims[i]:PlaySound(BlindedLocalSound, false, 0, false)
            end

            local impulse = 20
            local impulseDir = victims[i]:GetSimPosition() - position

            if dd == nil then
                dd = Engine.DamageData()
                dd:SetProc(Game.PT_STUNNED, true)
                dd:SetSource(projectile)
            end

            dd:SetSourceObject(projectile)
            dd:SetImpulse(impulseDir * impulse)

            victims[i]:DamageDD(dd)
        end
    end
end

function FadePost(entity)
    Sleep(0.6)
    local avatar = entity:GetAttachParent()    
    postFade.AvatarFade(avatar, -1, 0, fadeDuration, blindedDuration)
end