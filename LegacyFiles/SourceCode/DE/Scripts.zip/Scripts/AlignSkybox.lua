zoneId = Symbol("BackDropSpaceAlt")
skyboxTag = Symbol("Backdrop")
alignZoneAttribs = Instance()

function AlignSkyboxToZoneAttribs(instigator)
    if instigator:ReplicaLocallyControlled() then
        local backdrops = gRegion:FindTagged(skyboxTag)
        for i = 1, #backdrops do
            local backdrop = backdrops[i]
            if backdrop:IsA(gZoneAttribsType) and backdrop:GetZoneId() == zoneId then
                local rot = alignZoneAttribs:GetRotation()
                rot.heading = -rot.heading

                -- Clear out pitch/bank
                rot.pitch = 0
                rot.bank = 0
                backdrop:SetRotation(rot)
                break
            end
        end
    end
end

function SetParallaxCenterToThis(trigger, avatar)
    if IsNull(trigger) then
        return
    end
    local backdrops = gRegion:FindTagged(skyboxTag)
    for i = 1, #backdrops do
        local backdrop = backdrops[i]
        if backdrop:IsA(gZoneAttribsType) and backdrop:IsBackDrop() then
            backdrop:SetParallaxCenter(trigger)
        end
    end
end