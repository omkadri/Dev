animBecomeAlert = Resource()
attackedViewDist = 120
attackedFovHoriz = 170
attackedFovVert = 90

function OnDamage(avatar, scriptDamageData)
    if gRegion:IsMaster() and not IsNull(avatar) and avatar:GetForceNotTargetable() and not avatar:IsKilled() and scriptDamageData:GetAmount() > 0 then
        local damageSource = scriptDamageData:GetSource()
        if not IsNull(damageSource) and damageSource:IsA(gBaseAvatarType) and damageSource:IsHumanPlayer() then
            avatar:SetForceNotTargetable(false)
            if not IsNull(avatar:GetAgent()) then
                avatar:GetAgent():SetViewPerception(attackedViewDist, attackedViewDist, attackedFovHoriz, attackedFovVert)
                avatar:GetAgent():SetCombatAwareness()
            end
            if not IsNull(animBecomeAlert) then
                avatar:PlayAnimation(animBecomeAlert, true, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_ONCE, true)
            end
        end
    end
end

function WorkerInitialize(avatar)
    Sleep(0)
    if gRegion:IsMaster() and not IsNull(avatar:GetAgent()) then
        avatar:GetAgent():SetIdle()
        avatar:SetForceNotTargetable(true)
    end
end