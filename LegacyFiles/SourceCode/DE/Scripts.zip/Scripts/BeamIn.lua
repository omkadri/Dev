
TennoDeco = Instance()
energize = Type()
smallenergize = Type()

function BeamIn(agent)
    local avatar = agent:GetAvatar()
    
    
    local t = 1.1
    while t > 0 do
        avatar:SetMaterialParam(Lotus_Game.CLOAK, t)
        t = t - DeltaTime() * 0.3
        Sleep(0)
    end
    
    avatar:SetMaterialParam(Lotus_Game.CLOAK, 0.0)

end

function BeamInDeco()
    Sleep(0.1)
    TennoDeco:Attach(energize, EMPTY_SYMBOL)
    TennoDeco:Attach(smallenergize, EMPTY_SYMBOL)

    
    local t = 1.1
    while t > 0 do
        TennoDeco:SetMaterialParam(Lotus_Game.CLOAK, t)
        t = t - DeltaTime() * 0.34
        Sleep(0)
    end
    
    TennoDeco:SetMaterialParam(Lotus_Game.CLOAK, 0.0)
end

