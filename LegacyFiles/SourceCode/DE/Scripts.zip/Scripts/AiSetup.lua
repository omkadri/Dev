aiTypes = { Type() }
aiProbability = { 1.0 }
minLevel = 1
maxLevel = 1
enabledAutoSpawns = false
objective = Instance()
missionResourceTypes = { Type() }
missionResourceTypeFaction = Symbol("Corpus")
missionResourceTypeTag = Symbol()
enableEncounters = false
setLevelAlert = true

function SetupAi()
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()
   
    local gameRules = gRegion:GetGameRules()
    if not IsNull(gameRules) then

        if not IsNull(aiTypes) and #aiTypes > 0 then
            --print("Setting up mission AI");
            aiDir:SetMaxAI(1)
            for i=1,#aiTypes do
                local prob = aiProbability[i]
                local maxSim = 0
                local tier = 0
                local agentType = aiTypes[i]
                if not IsNull(agentType) then
                    aiDir:AddMissionAIType(agentType, prob, maxSim, tier)
                else
                    print("NULL agent type!")
                end
            end
            
            for i = 1, #missionResourceTypes do
                aiDir:AddMissionResourceType(missionResourceTypes[i], 1, missionResourceTypeFaction, missionResourceTypeTag) 
            end

            --aiDir:AddPreferredSpawnTag(Type("/Lotus/Types/Enemies/Corpus/BipedRobot/BipedRobotAgent"), Symbol("BipedSpecialSpawn"))
            aiDir:SetEnemyLevelMinMax(minLevel, maxLevel)
            aiDir:SetUseNewSpawnPacing(true)
            aiDir:SetEnableAutoSpawns(enabledAutoSpawns)
            aiDir:Enable(true)
            aiDir:SetObjective(objective)
            aiDir:SetLevelAlert(setLevelAlert)
            aiDir:SetCustomSpawnSelectionFilter(0, 1000, 0, 3, false, false, false)
            aiDir:SetUseCustomSpawnSelectionFilter(true)
            aiDir:EnableEncounters(enableEncounters)
            return true
        end
    end
end
