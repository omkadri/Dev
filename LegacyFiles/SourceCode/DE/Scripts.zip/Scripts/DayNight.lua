procLevelInfo = Resource()
forestZoneAttribsType = Type()

dayMinFogDensity = 0.3
dayMaxFogDensity = 0.4
nightMinFogDensity = 0.3
nightMaxFogDensity = 0.5

waterDayMaterial = Resource()
waterNightMaterial = Resource()

sunBounceDayColor = Color(255, 239, 197)
sunBounceDayBrightness = 0.1
sunBounceNightColor = Color(133, 150, 166)
sunBounceNightBrightness = 0.1

sunLightDayColor = Color(255, 235, 179)
sunLightDayBrightness = 2
sunLightDayGFE = 0.1 --Gameplay Fallof Exponent

sunLightNightColor = Color(133, 150, 166)
sunLightNightBrightness = 0.65
sunLightNightGFE = 0.1 --Gameplay Fallof Exponent

--Volumetric settings here as well Attenuation/MieScattering
sunVolumeDayColor = Color(255, 245, 219)
sunVolumeDayBrightness = 0.25

forceTimeOfDay = 0


nightFogVolTexture = Resource("/EE/Materials/Projection/ForestCanopyBandW.png")

local dayTag = Symbol("Day")
local nightTag = Symbol("Night")
local waterTag = Symbol("Water")
local nightSwapTag = Symbol("NightSwap")

local backDropDayTag = Symbol("BackDrop")
local backDropNightTag = Symbol("BackDropNight")

local NV_DAY_NIGHT = Symbol("DayNight")

local waterVolumeType = WeakResource("/EE/Types/Engine/WaterVolumeTrigger")

local function TriggerDayNightPortFowarder(tag)
    local forwarders = gRegion:FindTagged(tag)
    for i, forwarder in ipairs(forwarders) do
        forwarder:FirePort("TriggerPort")
    end
end

local function SetEmissiveMapAtten(entity, val)

    if IsNull(entity) then
        return
    end
    
    entity:SetMaterialParam(Lotus_Game.EMISSIVE_MAP_ATTEN, val)

    local decoChildren = entity:GetAllAttachments(gDecorationType) --returns parent too for whatever reason
    local children = entity:GetAttachedChildren()
    
    for i = 1, #children do
        if children[i]:IsA(gDecorationType) then
            if val <= 0 then
                children[i]:SetVisibility(false, false)
            elseif val > 0 then
                children[i]:SetVisibility(true, false)
            end
        end
    end
    
end

local function MaterialSwapEntities(ents)
    for i, ent in ipairs(ents) do
        if not IsNull(ent) then
            ent:SetMaterialSwap(true)
        end
    end
end

local function DisableEntities(ents)

    if IsNull(ents) then
        return
    end

    for i = 1, #ents do
    
        if not IsNull(ents[i]) then --Need to nilcheck since particle systems can be autokill, continue keyword in lua disabled
            local tmp = ents[i]
        
            if ents[i]:IsA(gParticleSysType) then
                ents[i]:Disable()
            elseif ents[i]:IsA(gDecorationType) then
                --SetEmissiveMapAtten(ents[i], 0)
                ents[i]:SetVisibility(false, true)
            elseif ents[i]:IsA(gSequencerType) then
                ents[i]:Disable()
            elseif ents[i]:IsA(gLightType) then
                ents[i]:TurnOff()
            elseif ents[i]:IsA(waterVolumeType) then
                ents[i]:Disable()
            end
            
        end
        
    end

end

local function EnableEntities(ents)
    
    if IsNull(ents) then
        return
    end

    for i = 1, #ents do

        if not IsNull(ents[i]) then --Need to nilcheck since particle systems can be autokill, continue keyword in lua disabled
        
            if ents[i]:IsA(gParticleSysType) then
                ents[i]:Enable()
            elseif ents[i]:IsA(gDecorationType) then
                --SetEmissiveMapAtten(ents[i], 1)
                ents[i]:SetVisibility(true, true)
            elseif ents[i]:IsA(gSequencerType) then
                ents[i]:Enable()
            elseif ents[i]:IsA(gLightType) then
                ents[i]:TurnOn()
            elseif ents[i]:IsA(waterVolumeType) then
                ents[i]:Enable()
            end
            
        end
        
    end

end

local function OverrideBackdrop(zone, newBackdrop)
    local attribs = zone:GetAttribs()
    if not IsNull(attribs) then
        local id = attribs:GetBackDropId()
        if id == Symbol("BackDrop") or id == Symbol("BackDropNight") then -- Don't override special custom backdrops for individual tiles
            zone:SetBackdrop(newBackdrop)
        end
    end
end

local function ApplyPostProcess(isDay)

    if _T.badlandsColorCorrectionActive then
        return
    end
    
    local overridePostProcessAndFog = false -- Override post process and fog from levelinfo
    local mission = gGameRules:GetMission()
    if not IsNull(mission.levelOverride) then
        local test = string.find(mission.levelOverride:GetFullName(), "GrineerForestExterminateHaloween")
        if not IsNull(mission.levelOverride) and string.find(mission.levelOverride:GetFullName(), "GrineerForestExterminateHaloween") ~= nil then
            overridePostProcessAndFog = true
        end
    end

    --Post process-------------------------------------------------------
    local levelInfo = gRegion:GetLevelInfo()
    if IsNull(procLevelInfo) or IsNull(levelInfo) then
        return
    end
    
    if not overridePostProcessAndFog then
        if isDay == 1 then
            levelInfo.postProcess = procLevelInfo.postProcess
        else
            levelInfo.postProcess = procLevelInfo.postProcessAlt
        end
    end

    --Skybox-------------------------------------------------------------
    local zoneAttribs = gRegion:FindAll(gZoneAttribsType)
    local skyboxZoneAttribs = {}
    local zones = {}

    local bgSym = Symbol("Backdrop")
    local flyInSym = Symbol("FlyIn")
    
    --Get Zones
    for i = 1, #zoneAttribs do
        if not IsNull(zoneAttribs[i]) then
            local tag = zoneAttribs[i]:GetTag()
            if zoneAttribs[i]:GetZoneId() == flyInSym then
                -- don't smash the FlyIn zone
            elseif zoneAttribs[i]:GetTag() ~= bgSym then
                table.insert(zones, zoneAttribs[i]:GetZone())
            else
                table.insert(skyboxZoneAttribs, zoneAttribs[i])
            end
        end
    end
    
    --Check backdrop IDs
    local backDropDayZoneAttribs
    local backDropNightZoneAttribs
    
    for i = 1, #skyboxZoneAttribs do
        local backdropID = skyboxZoneAttribs[i]:GetBackDropId()
        local zoneID = skyboxZoneAttribs[i]:GetZoneId()
        if zoneID == backDropDayTag then
            backDropDayZoneAttribs = skyboxZoneAttribs[i]
        elseif zoneID == backDropNightTag then
            backDropNightZoneAttribs = skyboxZoneAttribs[i]
        end
    end
    
    if IsNull(backDropDayZoneAttribs) or IsNull(backDropNightZoneAttribs) then --ERRORRRR!!!
        return
    end
    
    --Slam backdrops and Fog--------------------------------------------------    
    local dayFogDensity = Clamp(SRandom(dayMinFogDensity,dayMaxFogDensity) * 0.5, 0.0, 0.2)
    local nightFogDensity = Clamp(SRandom(nightMinFogDensity,nightMaxFogDensity) * 0.5, 0.0, 0.2)
    
    for i = 1, #zones do
        if not IsNull(zones[i]) then
            if not overridePostProcessAndFog then
                if isDay == 1 then
                    --zones[i]:SetBackdrop(backDropDayZoneAttribs:GetZone())
                    OverrideBackdrop(zones[i], backDropDayZoneAttribs:GetZone())
                    zones[i]:SetDistanceFogDensity(dayFogDensity)
                    zones[i]:SetFlashlight(false)
                else
                    --zones[i]:SetBackdrop(backDropNightZoneAttribs:GetZone())
                    OverrideBackdrop(zones[i], backDropNightZoneAttribs:GetZone())
                    zones[i]:SetDistanceFogDensity(nightFogDensity)
                    zones[i]:SetFlashlight(true)
                end
            else
                if isDay == 1 then
                    --zones[i]:SetBackdrop(backDropDayZoneAttribs:GetZone())
                    OverrideBackdrop(zones[i], backDropDayZoneAttribs:GetZone())
                    zones[i]:SetFlashlight(false)
                else
                    --zones[i]:SetBackdrop(backDropNightZoneAttribs:GetZone())
                    OverrideBackdrop(zones[i], backDropNightZoneAttribs:GetZone())
                    zones[i]:SetFlashlight(true)
                end
                if _T.gForceFogColor then
                    zones[i]:SetFogColor(_T.gForceFogColor)
                    zones[i]:SetOverrideLevelFog(true)
                else
                    zones[i]:SetOverrideLevelFog(false)
                end
            end
        end
    end
    
    -------Water----------------------------------------------------
    local waterDecos = gRegion:FindTagged(waterTag)
    
    for i = 1, # waterDecos do
        if not IsNull(waterDecos[i]) then
            if isDay == 1 then
                waterDecos[i]:SetOverrideMaterial(0, waterDayMaterial)
            else
                waterDecos[i]:SetOverrideMaterial(0, waterNightMaterial)
            end
        end
    end
    
end

local function ApplyPostProcessOrokinSabotage(isDay)

    --Post process-------------------------------------------------------
    local levelInfo = gRegion:GetLevelInfo()
    if IsNull(procLevelInfo) or IsNull(levelInfo) then
        return
    end
    
    -- In orokin sabotage postprocess is handled locally per zone in another script

    --Skybox-------------------------------------------------------------
    local zoneAttribs = gRegion:FindAll(forestZoneAttribsType)
    local zones = {}

    local bgSym = Symbol("Backdrop")
    local flyInSym = Symbol("FlyIn")
    
    --Get Zones
    for i = 1, #zoneAttribs do
        if not IsNull(zoneAttribs[i]) then
            local tag = zoneAttribs[i]:GetTag()
            if zoneAttribs[i]:GetZoneId() == flyInSym then
                -- don't smash the FlyIn zone
            elseif zoneAttribs[i]:GetTag() ~= bgSym then
                table.insert(zones, zoneAttribs[i]:GetZone())
            end
        end
    end
    
    --Check backdrop IDs
    local backDropDayZoneAttribs
    local backDropNightZoneAttribs
    local zoneAttribs = gRegion:FindAll(gZoneAttribsType)
    for i = 1, #zoneAttribs do
        if zoneAttribs[i]:GetBackDropId() == backDropDayTag then
            backDropDayZoneAttribs = zoneAttribs[i]
        elseif zoneAttribs[i]:GetBackDropId() == backDropNightTag then
            backDropNightZoneAttribs = zoneAttribs[i]
        end
    end
    
    if IsNull(backDropDayZoneAttribs) or IsNull(backDropNightZoneAttribs) then --ERRORRRR!!!
        return
    end
    
    --Slam backdrops and Fog--------------------------------------------------
    local dayFogDensity = Clamp(SRandom(dayMinFogDensity,dayMaxFogDensity) * 0.5, 0.0, 0.2)
    local nightFogDensity = Clamp(SRandom(nightMinFogDensity,nightMaxFogDensity) * 0.5, 0.0, 0.2)
    
    for i = 1, #zones do
        if not IsNull(zones[i]) then
            if isDay == 1 then
                --zones[i]:SetBackdrop(backDropDayZoneAttribs:GetZone())
                OverrideBackdrop(zones[i], backDropDayZoneAttribs:GetZone())
                zones[i]:SetDistanceFogDensity(dayFogDensity)
                zones[i]:SetFlashlight(false)
            else
                --zones[i]:SetBackdrop(backDropNightZoneAttribs:GetZone())
                OverrideBackdrop(zones[i], backDropNightZoneAttribs:GetZone())
                zones[i]:SetDistanceFogDensity(nightFogDensity)
                zones[i]:SetFlashlight(true)
            end
        end
    end
    
    -------Water----------------------------------------------------
    local waterDecos = gRegion:FindTagged(waterTag)
    
    for i = 1, # waterDecos do
        if not IsNull(waterDecos[i]) then
            if isDay == 1 then
                waterDecos[i]:SetOverrideMaterial(0, waterDayMaterial)
            else
                waterDecos[i]:SetOverrideMaterial(0, waterNightMaterial)
            end
        end
    end
    
end

local function CalcHour(t)

    --[[
    January 1, 1970 GMT
    Human readable time     Seconds
    1 hour  3600 seconds
    1 day   86400 seconds
    1 week  604800 seconds
    1 month (30.44 days)    2629743 seconds
    1 year (365.24 days)     31556926 seconds
    ]]
    
    local currentDay = math.floor(t / 86400) % 365
    local currentHour = math.floor(t / 3600) % 24
    local currentMinute = math.floor(t / 60) % 60
    
    local currentYear = 1970 + math.floor(t / 31556926)
    
    return currentHour
end

local function CycleTest()

    Sleep(0) --Frame hack

    local gameRules = gGameRules
    local dayEntities = gRegion:FindTagged(dayTag)
    local nightEntities = gRegion:FindTagged(nightTag)
    
    local dayCheck = true
    DisableEntities(dayEntities)
    DisableEntities(nightEntities)
    
    while true do
    
        if dayCheck then
            EnableEntities(dayEntities)
            DisableEntities(nightEntities)
            dayCheck = false
        else
            EnableEntities(nightEntities)
            DisableEntities(dayEntities)
            dayCheck = true
        end
        
        ApplyPostProcess(dayCheck)
    
        Sleep(5)
    end

end

local function SetLightProperties(lightEntities, brightness, color, gfe)

    for i = 1, #lightEntities do
        lightEntities[i]:SetBrightness(brightness)
        lightEntities[i]:SetColor(color)
        if not IsNull(gfe) then
            lightEntities[i]:SetFalloffExponent(gfe)
        end
    end

end

local function SetLightVolumeProperties(lightEntities, attenuation, mieScattering, mieWrap, scattering, extinction, texture) --, noise, noiseScale, noiseSpeed)
    -- april 2019 haxxor
    for i = 1, #lightEntities do
        local light = lightEntities[i]
        light:SetVolumetricLightAttenuation(attenuation)
        light:SetVolumetricLightMieScattering(mieScattering)
        light:SetVolumetricLightMieWrap(mieWrap)
        light:SetVolumetricLightScattering(scattering)
        light:SetVolumetricLightExtinction(extinction)
        if not IsNull(texture) then
            light:SetTexture(texture)
        end
    end
end

local function SetLightVolumeNoiseProperties()

end

local function LocalStart()

    Sleep(0) --Frame hack
    ---------------------------------------------------------------------------------------------------
    
    local gameRules = gGameRules
    
    while IsNull(gameRules) do
        gameRules = gGameRules
        Sleep(0)
    end
    
    local worldTime = gameRules:GetGlobalWorldTime()
    local dayEntities = gRegion:FindTagged(dayTag)
    local nightEntities = gRegion:FindTagged(nightTag)
    local nightSwapEntities = gRegion:FindTagged(nightSwapTag) --For more exceptions to the rule
    
    --Extra Lights--------------------------------------------------------------------
    local sunBounceEntities = gRegion:FindTagged(Symbol("SunBounce"))
    local sunLightEntities = gRegion:FindTagged(Symbol("SunLight"))
    local sunVolumeEntities = gRegion:FindTagged(Symbol("SunVolume"))
    ---------------------------------------------------------------------------------

    --Ensure that both sets of objects are hidden and disabled by default
    DisableEntities(dayEntities)
    DisableEntities(nightEntities)
    
    --Check Time of Day
    local worldHour = CalcHour(worldTime)
    local dayNight = gameRules:GetNetPersistentVar(NV_DAY_NIGHT, 9999) --Setup in ProceduralLevel.lua
    local debugString = "Day/Night: "
    
    --dayNight = 1 -- DEBUG: DAY
    --dayNight = 0 -- DEBUG: NIGHT
    
    while dayNight == 9999 do -- poll until var arrives
        Sleep(0)
        dayNight = gameRules:GetNetPersistentVar(NV_DAY_NIGHT, 9999)
    end
    
    --Day: 5am --> 7pm GMT
    if dayNight == 1 then
        sunLightDayBrightness = math.min(0.65, sunLightDayBrightness)
        EnableEntities(dayEntities)
        SetLightProperties(sunBounceEntities, sunBounceDayBrightness, sunBounceDayColor)
        SetLightProperties(sunLightEntities, sunLightDayBrightness, sunLightDayColor, sunLightDayGFE)
        SetLightProperties(sunVolumeEntities, sunVolumeDayBrightness, sunVolumeDayColor)
        SetLightVolumeProperties(sunVolumeEntities, 0.4, 0.1, 0.0, 0.15, 0.0)
        TriggerDayNightPortFowarder(Symbol("DayPortForwarder"))
        debugString = worldHour .. " DAY!"
    else
        EnableEntities(nightEntities)
        MaterialSwapEntities(nightSwapEntities)
        SetLightProperties(sunBounceEntities, sunBounceNightBrightness, sunBounceNightColor)
        SetLightProperties(sunLightEntities, sunLightNightBrightness, sunLightNightColor, sunLightNightGFE)
        SetLightProperties(sunVolumeEntities, 0.3, Color(57, 164, 242))
        SetLightVolumeProperties(sunVolumeEntities, 0.3, 0.1, 0.0, 0.3, 0.0, nightFogVolTexture)
        TriggerDayNightPortFowarder(Symbol("NightPortForwarder"))
        debugString = worldHour .. " NIGHT!"
    end
    
    print(debugString)
    --CycleTest() --DEBUG FOR SWAPPING ON THE FLY
    
    local firePostProcess = WeakResource("/Lotus/Levels/Proc/Grineer/GrineerForestLevelInfoFairyQuest")
    local postProcessInfo = gRegion:GetLevelInfo()
    if postProcessInfo == firePostProcess then
        DisableEntities(nightEntities)
        EnableEntities(dayEntities)
        TriggerDayNightPortFowarder(Symbol("DayPortForwarder"))
        return
    end
    
    ApplyPostProcess(dayNight)
    
end

function Start()
    LocalStart()
end

function ForceDay()
    Broadcast("DayNight.lua -- ForceDay")
    _T.gForceDayNight = "Day"
    LocalStart()
end

function ForceNight()
    Broadcast("DayNight.lua -- ForceNight")
    _T.gForceDayNight = "Night"
    LocalStart()
end

function OrokinSabotageDayNight()
    Sleep(0) --Frame hack
    
    local gameRules = gGameRules
    while IsNull(gameRules) do
        gameRules = gGameRules
        Sleep(0)
    end
    
    local worldTime = gameRules:GetGlobalWorldTime()
    local dayEntities = gRegion:FindTagged(dayTag)
    local nightEntities = gRegion:FindTagged(nightTag)
    
    --Ensure that both sets of objects are hidden and disabled by default
    DisableEntities(dayEntities)
    DisableEntities(nightEntities)
        
    --Check Time of Day
    local worldHour = CalcHour(worldTime)
    local dayNight = gameRules:GetNetPersistentVar(NV_DAY_NIGHT, 9999) --Setup in ProceduralLevel.lua
    local debugString = ""
    while dayNight == 9999 do -- poll until var arrives
        Sleep(0)
        dayNight = gameRules:GetNetPersistentVar(NV_DAY_NIGHT, 9999)
    end

    --Day: 5am --> 7pm GMT
    if dayNight == 1 then
        EnableEntities(dayEntities)
        debugString = worldHour .. " DAY!"
    else
        EnableEntities(nightEntities)
        debugString = worldHour .. " NIGHT!"
    end
    
    ApplyPostProcessOrokinSabotage(dayNight)
    --ApplyPostProcessOrokinSabotage(0)
end

function SyncSkiesWithWorldState()
    while IsNull(gGameRules) do
        Sleep(0)
    end

    local oldGameRules = nil
    while _T.isStreamingLevel do
        oldGameRules = gGameRules
        Sleep(0)
    end

    while oldGameRules == gGameRules do
        Sleep(0)
    end

    local skies
    while #skies == 0 do
        Sleep(0)
        skies = gRegion:FindAll(gDynamicSkyType)
    end

    if _T.ForceTimeOfDay ~= nil then
        return
    end

    local worldSeconds = gGameRules:GetTruncatedWorldTimeSecs()
    local forceNight = (gGameRules:GetMission().fxLayer == Symbol("PermaNight"))
    local noRain = (gGameRules:GetMission().fxLayer == Symbol("NoRain"))

    for i=1,#skies do
        local sky = skies[i]
        if not IsNull(sky) then
            local HOURS_PER_SECOND = sky:GetTimeOfDayRate()
            local SECONDS_PER_DAY = (24.0 / HOURS_PER_SECOND)

            local daySeconds = math.fmod(worldSeconds, SECONDS_PER_DAY)
            local hourOfDay = 24.0 * (daySeconds / SECONDS_PER_DAY)

            if forceNight then
                sky:SetTimeOfDay(0)
                sky:SetTimeOfDayRate(0)
            else
                sky:SetTimeOfDay(hourOfDay)
            end

            if noRain then
                sky:SetWeatherOverride(0)
            end

            local dayNum = math.floor(worldSeconds / SECONDS_PER_DAY)
            sky:InitWeatherCycle(dayNum, -0.1125, 0.075)
        end
    end
end

function SetSkiesTime()
    _T.ForceTimeOfDay = forceTimeOfDay
    local skies = gRegion:FindAll(gDynamicSkyType)
    for i=1,#skies do
        skies[i]:SetTimeOfDay(math.mod(forceTimeOfDay, 24))
        skies[i]:SetTimeOfDayRate(0)
    end
end
