tag = Symbol()


function AddDisallowedSpawnTag()
    local npcMgr = gRegion:GetNpcMgr()
    while IsNull(npcMgr) do
        npcMgr = gRegion:GetNpcMgr()
        Sleep(0)
    end
    local aiDir = npcMgr:GetAiDirector()
    while IsNull(aiDir) do
        aiDir = npcMgr:GetAiDirector()
        Sleep(0)
    end
    
    aiDir:AddDisallowedTag(tag)
end