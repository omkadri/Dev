doorInstance = Instance()
doorInstances = {Instance()}
openAnim = Resource()
closeAnim = Resource()
openAnimRateOverride = 1
closeAnimRateOverride = 1
delayClose = 0.0
delayOpen = 0.0
openMaterial = Resource()
lockedMaterial = Resource()
materialSlot = 0

function AnimateDoor(doorHint, oldStatus)

    local doorStatus = doorHint:GetDoorStatus()
    --print("Door status: "..tostring(doorStatus))
    
    -- Swap materials
    if not IsNull(doorInstance) and not IsNull(lockedMaterial) and not IsNull(openMaterial) then
        local currentMaterial = openMaterial
        if doorStatus == Npc.NpcDoorHint_DS_LOCKED then
            currentMaterial = lockedMaterial
        else
            currentMaterial = openMaterial
        end
        doorInstance:SetOverrideMaterial(materialSlot, currentMaterial)
    end
    
    -- Animate door    
    if doorStatus == Npc.NpcDoorHint_DS_OPEN and oldStatus ~= Npc.NpcDoorHint_DS_BLOCKED then
        if delayOpen > 0.01 then
            Sleep(delayOpen)
        end
        doorInstance:FirePort("OpenOccluder")
        doorInstance:PlayAnimation(openAnim, true, false, 0, Symbol(), openAnimRateOverride)
    elseif doorStatus == Npc.NpcDoorHint_DS_CLOSED then
        if delayClose > 0.01 then
            Sleep(delayClose)
        end
        doorInstance:PlayAnimation(closeAnim, true, false, 0, Symbol(), closeAnimRateOverride)
        doorInstance:FirePort("CloseOccluder")
    end
end

function AnimateDoors(doorHint, oldStatus)
    local doorStatus = doorHint:GetDoorStatus()
    
    if doorStatus ~= oldStatus then
        if doorStatus == Npc.NpcDoorHint_DS_OPEN and oldStatus ~= Npc.NpcDoorHint_DS_BLOCKED then
            if delayOpen > 0.01 then
                Sleep(delayOpen)
            end
        
            for i, door in ipairs (doorInstances) do
                door:FirePort("OpenOccluder")
                local wait = false
                if i == #doorInstances then
                    wait = true
                end
                door:PlayAnimation(openAnim, wait, false, 0, EMPTY_SYMBOL, openAnimRateOverride)
            end
        
        elseif doorStatus == Npc.NpcDoorHint_DS_CLOSED then
            if delayClose > 0.01 then
                Sleep(delayClose)
            end

            for i, door in ipairs (doorInstances) do
                local wait = false
                if i == #doorInstances then
                    wait = true
                end
                door:PlayAnimation(closeAnim, wait, false, 0, EMPTY_SYMBOL, closeAnimRateOverride)
            end
            for i, door in ipairs (doorInstances) do
                --door:FirePort("CloseOccluder")
            end
        end
    end
end
