effectsToRemove = {WeakResource()}
fxToAttach = Type()
decoEffect = Type()
weightModifier = 1.0
speed = 0.3
cloakColorMult = 5

ApplyEnergyColor = true

excludedAvatarTypes = { WeakResource() }

local CLOAKHDR = Symbol("CloakHDR")
local CLOAKVECTOR = Symbol("CloakVector")

local COLOR_UTIL = require "Lotus.Scripts.Effects.EffectsColorUtilities"

local function GetChildren(entity)
    local children = {}
    local decoChildren = entity:GetAllAttachments(gDecorationType)
    local clothChildren = entity:GetAllAttachments(gSkeletalClothExType)
    for i=1, #decoChildren do
        if not IsNull(decoChildren[i]) then
            table.insert(children, decoChildren[i])
        end
    end
    for i=1, #clothChildren do
        if not IsNull(clothChildren[i]) then
            table.insert(children, clothChildren[i])
        end
    end
    return children
end

local function SetupMatParams(entity, energyColor, vec, children)
    local atten = cloakColorMult / 255
    entity:SetMaterialParam(CLOAKVECTOR, vec.x, vec.y, vec.z, 1)
    entity:SetMaterialParam(CLOAKHDR, energyColor.red * atten, energyColor.green * atten, energyColor.blue * atten, 1)
    for i=1,#children do
        if not IsNull(children[i]) then
            children[i]:SetMaterialParam(CLOAKHDR, energyColor.red * atten, energyColor.green * atten, energyColor.blue * atten, 1)
            children[i]:SetMaterialParam(CLOAKVECTOR, vec.x, vec.y, vec.z, 1)
        end
    end
end

local function SetDissolve(entity, t, children)
    entity:SetDissolve(t)
end

local function EffectsLoop(parent, ragdoll, energyColor, t, vec, weightFactor)
    t = SmoothStep(t)--math.pow(t, 1.5)
    if not IsNull(ragdoll) then
        ragdoll:SetDissolve(t)

        local dx = Noise(Time() * 0.2) * 2 * weightFactor
        local dy = (3 + AbsNoise((Time() + 3) * 0.2)) * weightFactor
        local dz = Noise((Time() + 7)  * 0.2) * 2 * weightFactor
        
        ragdoll:ApplyGlobalForce(Vector(dx,dy,dz), 1)
    else
        parent:SetDissolve(t)
    end
    if IsNull(ragdoll) and not IsNull(parent:GetRagdoll()) then
        ragdoll = parent:GetRagdoll()
    end
end

local function DissolvePosLoop(boneName, parent, children) --Update material with bone's local position
    local vec = parent:GetBonePosition(boneName)
    parent:SetMaterialParam(CLOAKVECTOR, vec.x, vec.y, vec.z, 2.5)
    for i=1,#children do
        if not IsNull(children[i]) then
            children[i]:SetMaterialParam(CLOAKVECTOR, vec.x, vec.y, vec.z, 2.5)
        end
    end
end

function Dissolve(victimAvatar)
    local avatar = _T.DissolveInstigator

    local energyColor = Color()
    energyColor.red = 47
    energyColor.green = 175
    energyColor.blue = 209

    if not IsNull(avatar) and avatar:IsA(gTennoAvatarType) then
        local weapon = avatar:InventoryControl():GetWeaponInHand(Engine.MAIN_HAND)
        if not IsNull(weapon) then
            local playerCustomization = weapon:GetCustomization()
            local colors = playerCustomization:GetColors(Lotus_Game.PrimaryColors)
            if colors:Initialized(Lotus_Game.EnergyColor) then
                energyColor = Color(colors.mEnergyColor)
            end
        end
    end

    local ragdoll
    local t = 0
    local parent = victimAvatar
    local weights = {}
    
    if not IsNull(parent) then
        parent:AddDeltaAttenuation(Symbol("ChannelingKill"), 0.5)
        
        local numRagdolls = parent:GetNumRagdolls()
        if numRagdolls > 0 then
            for i = 0, numRagdolls - 1 do
                ragdoll = parent:GetRagdollByIndex(i)
                local particleSys = ragdoll:Attach(fxToAttach, EMPTY_SYMBOL)
                if not IsNull(particleSys) and ApplyEnergyColor then
                    particleSys:SetColorMinMax(energyColor, energyColor)
                    COLOR_UTIL.ApplyHighLow(particleSys, energyColor)
                end
            end
        else
            local particleSys = parent:Attach(fxToAttach, EMPTY_SYMBOL)
            if not IsNull(particleSys) and ApplyEnergyColor then
                particleSys:SetColorMinMax(energyColor, energyColor)
                COLOR_UTIL.ApplyHighLow(particleSys, energyColor)
            end
        end
        
        local vec = parent:GetCenter()
        local hitProxies = parent:DamageControl():GetHitProxies()
        local boneName = nil
        if not IsNull(hitProxies) then --Pick a random bone to dissolve out of.  Can we feed the hit proxy that took the killing blow into this?
            local randomHitProxy = hitProxies[math.random(1,#hitProxies)] 
            boneName = randomHitProxy.mBoneName
            local deco = gRegion:CreateEntity(decoEffect, parent:GetBonePosition(boneName), ZERO_ROTATION)
            if ApplyEnergyColor then 
                deco:SetMaterialParam(Lotus_Game.TINT_COLOR, energyColor.red/255, energyColor.green/255, energyColor.blue/255, 1)
                COLOR_UTIL.ApplyHighLow(deco, energyColor)
            end
        end
        if IsNull(boneName) then
            boneName = Symbol("GAME_C1_HIP1")
        end
        
        local children = GetChildren(parent)
        
        SetupMatParams(parent, energyColor, vec, children)

        local setupRagdoll = false
        local endEffects = {false, false, false}
        while t < 1 and not IsNull(parent) do
            local numRagdolls = parent:GetNumRagdolls()
            if numRagdolls > 0 then
                local ragdollSetUpCheck = false --Hold this until the end, so multiple ragdolls get set up
                for i = 0, numRagdolls - 1 do
                    ragdoll = parent:GetRagdollByIndex(i)
                    if not setupRagdoll and not IsNull(ragdoll) then
                        children = GetChildren(ragdoll)
                        SetupMatParams(ragdoll, energyColor, vec, children)
                        weights[i] = Clamp(ragdoll:GetTotalWeight(), 80, 400) / 174 --Fx were balanced for boxman
                        if (i == (numRagdolls -1)) then
                            ragdollSetUpCheck = true
                        end
                        for j=1, #effectsToRemove do
                            local fx = ragdoll:GetAttachment(effectsToRemove[j])
                            if not IsNull(fx) then
                                fx:Destroy()
                            end
                        end
                    else
                        weights[i] = 1
                    end
                    EffectsLoop(ragdoll, ragdoll, energyColor, t, vec, weights[i] * weightModifier)
                    if not IsNull(boneName) then
                        DissolvePosLoop(boneName, ragdoll, children)
                    end
                    if t > 0.7 and not endEffects[i] then
                        Effects.DisableChildParticleSystems(ragdoll, gParticleSysType)
                        endEffects[i] = true
                    end
                end
                if ragdollSetUpCheck then
                    setupRagdoll = true
                end
            else
                EffectsLoop(parent, nil, energyColor, t, vec, 0)
                if not IsNull(boneName) then
                    DissolvePosLoop(boneName, parent, children)
                end
            end
            Sleep(0.0)
            t = t + DeltaTime() * speed
        end
        
        local numRagdolls = parent:GetNumRagdolls()
        if numRagdolls > 0 then
            for i = 0, numRagdolls - 1 do
                local ragdoll = parent:GetRagdollByIndex(i)
                ragdoll:Destroy()
            end
        end
        
        --Need this check in PvP to ensure that we don't destroy player avatars (is this necessary in PvE anyways?)
        if gGameRules:IsPvpEnabled() then
            local npcAgent = parent:GetAgent()
            local player = parent:GetPlayer()
            if IsNull(npcAgent) then
                return
            end
                
            if not IsNull(player) then
                return
            end
        end
            
        if parent:IsA(gTennoAvatarType) then
            return
        end
            
        if not IsNull(parent) then
            parent:Destroy()
        end
    end
end

function NotifyChannelingKill(weapon, victim)
    if IsNull(victim) then
        return
    end
    for i=1, #excludedAvatarTypes do
        if victim:IsVIP() or victim:IsA(excludedAvatarTypes[i]) then
            return
        end
    end
    _T.DissolveInstigator = weapon:GetAvatarOwner()
    victim:ScriptRunChildScript(Symbol("Dissolve"), false)
end

function NotifyOnDamageDone(weapon, dd, victim)
    Sleep(0.0) -- Sleep one frame, this could be the lethal damage but it hasn't been processed yet.
    if not IsNull(victim) and victim:IsKilled() then
        for i=1, #excludedAvatarTypes do
            if victim:IsVIP() or victim:IsA(excludedAvatarTypes[i]) then
                return
            end
        end
        _T.DissolveInstigator = weapon:GetAvatarOwner()
        victim:ScriptRunChildScript(Symbol("Dissolve"), false)
    end
end

function TestMyDissolve(deco)
    Sleep(1)
    local t = 0
    local val = 1
    local vec = Vector(.2, 1.2, 0.15)
    deco:SetMaterialParam(Symbol("CloakVector"), vec.x, vec.y, vec.z, val)
    while true do
        deco:SetDissolve(t)
        Sleep(0)
        t = t + DeltaTime() / 2
        if t > 1 then
            t = 0
            local energyColor = Color(math.random(0,255), math.random(0,255), math.random(0,255), 255)
            deco:SetMaterialParam(CLOAKHDR, energyColor.red / 25, energyColor.green / 25, energyColor.blue / 25, 1)
            vec = Vector((math.random() - 0.5) * 0.5, math.random() * 2.0, (math.random() - 0.5) * 0.5)
            deco:SetMaterialParam(Symbol("CloakVector"), vec.x, vec.y, vec.z, val)
        end
    end
end

function InfestedRagdollDissolve(ragdoll)
    Sleep(3)
    local t = 0
    if ragdoll:GetDissolve() > 0.01 then
        return --Something else is dissolving this ragdoll, don't compete
    end
    while t < 1 and not IsNull(ragdoll) do
        ragdoll:SetDissolve(t)
        t = t + DeltaTime()
        Sleep(0)
    end
end