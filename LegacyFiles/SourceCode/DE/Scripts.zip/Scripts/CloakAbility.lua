cloakMaterial = Resource()
activateSound = Resource()
activateLocalSound = Resource()
errorSound = Resource()
deactivateSound = Resource()
loopingEffectSound = Resource()
cloakFX = Type()
cloakColorCorrection = Resource()

local UTIL = require "EE.Interface.Utilities"

local printPrefix = "CloakAbility: "


function Activate(ability, avatar, boost)
    print(printPrefix .. "Activated cloak ability");
    
    avatar:SetPostureModifier(Engine.PM_CLOAK, true)
    gRegion:AllNpcsForget(avatar)
    
    ability:SetOverrideMaterialForEntity(avatar, cloakMaterial)

    avatar:Attach(cloakFX, EMPTY_SYMBOL)
    
    if avatar:IsLocallyAuthoritative() then
        avatar:PlaySound(activateLocalSound, false, false)
    end
    avatar:PlaySound(activateSound, false, false)
    
    _T["cloakSoundLoop"] = avatar:PlaySound(loopingEffectSound, false)
    avatar:CameraControl():PushColorCorrection(cloakColorCorrection, 1.0, -1.0, 1.0)    
end

function Deactivate(ability, avatar)
    print(printPrefix .. "Deactivating cloak ability");
    
    avatar:SetPostureModifier(Engine.PM_CLOAK, false)
    
    ability:RestoreEntityMaterials()

    local effects = avatar:GetAttachment(cloakFX)
    if not IsNull(effects) then
        effects:Destroy()
    end
            
    if not IsNull(_T["cloakSoundLoop"]) then
        _T["cloakSoundLoop"]:Stop(true)
        _T["cloakSoundLoop"] = nil
    end

    avatar:PlaySound(deactivateSound, false, false)
    avatar:CameraControl():RemoveColorCorrection(cloakColorCorrection)
end
