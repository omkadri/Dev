bipedSpawnPod = Instance()
bipedPodPreSpawnAnim = Resource()
bipedPodPostSpawnAnim = Resource()
bipedDoorScript = Instance()
bipedAttachBone = Symbol()
bipedAttachOffset = Vector()
bipedAttachRotation = Rotation()
bipedFriendlyEffect = Type()
portTimer = Instance()
bipedSpawnPoint = Instance()
bipedCooldownTime = 8.0
bipedAgentType = Type()
hackActionType = Type()
chance = 0.25

spawnerDeco = Instance()
spawnerAttachBone = Symbol()
spawnerOpenAnim = Resource()
spawnerCloseAnim = Resource()
avatarAttachOffest = Vector()
avatarAttachRotation = Rotation()


--function InfestedSpawner
spawnControl = Instance()
deadBiped = Instance()
deadBipedAnim = Resource()
chanceToSpawn = 0.25
chanceToShowDeadBiped = 0.5

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local function IsEventMission()
    -- NOTE: would normally call gGameRules:GetMission(), but this script runs before the mission has been cached off on the host...
    local squadMission = gMatchingService:GetSquadMission()
    if squadMission and squadMission ~= "" then
        local squadMissionDecoded = cjson.decode(squadMission)
        if squadMissionDecoded.name ~= nil then
            return(string.find(squadMissionDecoded.name, LOTUS_UTIL.EVENT_TAG))
        else
            return(false)
        end
    end
    return(false)
end

function bipedSpawnerDoors()
    -- Make sure we still animate the spawner even if it is off-screen
    if not IsNull(bipedSpawnPod) then
        bipedSpawnPod:SetAnimateMaster(true)
        bipedSpawnPod:PlayAnimation(bipedPodPreSpawnAnim, true, false, 0)
        Sleep(2)
        bipedSpawnPod:PlayAnimation(bipedPodPostSpawnAnim, true, false, 0)
        bipedSpawnPod:SetAnimateMaster(false)
    end
end

function onBipedSpawned(agent)
    if not IsNull(agent) then
        if not IsNull(bipedSpawnPoint) and not IsNull(portTimer) then
            bipedSpawnPoint:FirePort("Disable")

            portTimer:SetRemainingTime(bipedCooldownTime)
            portTimer:FirePort("Start")
        end

        agent:SetAllExits(false)
        
        local avatar = agent:GetAvatar()
        avatar:AttachTo(bipedSpawnPod, bipedAttachBone)
        --avatar:SetAttachLocalSpace(ZERO_VECTOR, ZERO_ROTATION)
        avatar:SetAttachLocalSpace(bipedAttachOffset, bipedAttachRotation)

        bipedDoorScript:FirePort("Execute")
        Sleep(1.5)
        avatar:Unattach()

        agent:SetAlert()
        agent:ReturnToAiControl()
    end
end

function SpawnForPlayer(instigator, selection, this)

    if IsEventMission() then
        return
    end

    if selection ~= 1 then
        return
    end

    local npcMgr = gRegion:GetNpcMgr()
    local aiDir = npcMgr:GetAiDirector()
    local spawnPoint = gRegion:FindNearest(gNpcSpawnPointType, this:GetPosition(), 1)
    
    local agent = aiDir:CreateAgent(bipedAgentType, spawnPoint, instigator:GetFaction())
    
    _T.idleTimoutReset = true

    if IsNull(agent) then
        print("BipedSpawner.lua::SpawnForPlayer - Failed to create agent")
        return
    end
    
    local avatar = agent:GetAvatar()
    avatar:SetSpawnedByAvatar(instigator)
    avatar:Attach(bipedFriendlyEffect, EMPTY_SYMBOL)
    agent:AddOrder(Symbol("StormTarget"), instigator) -- Follow player
    
    -- Pseudo-disable with empty restricted faction list so this can't run again
    this:SetRestricted(true)
end

function RandomChanceToEnable(this)
    if IsEventMission() then
        return
    end

    local action = nil
    if gRegion:IsMaster() then
        local randNum = Random(0,1)
        if randNum <= chance then
            local rot = this:GetRotation()
            rot.heading = rot.heading + 180
            action = this:Attach(hackActionType, EMPTY_SYMBOL, Vector(0,0,2.1), Rotation(180,0,0))
        end
    else
        local attempts = 5
        while IsNull(action) and attempts > 0 do
            action = this:GetAttachment(hackActionType)
            Sleep(1)
            attempts = attempts - 1
        end
    end
    
    if not IsNull(action) then
        local t = 1
        local sign = 1
        while not IsNull(action) and action:IsEnabled() do
            this:SetMaterialParam(Lotus_Game.EMISSIVE_MAP_ATTEN, Lerp(0,1,t))
            t = t + sign * DeltaTime()
            if t > 1 then
                t = 1
                sign = sign * -1
            elseif t < 0 then
                t = 0
                sign = sign * -1
            end
            Sleep(0)
        end
        this:SetMaterialParam(Lotus_Game.EMISSIVE_MAP_ATTEN, 1)
    end
end

--Randomly spawns an infested moa or a dead moa
function InfestedSpawner()
    if IsEventMission() then
        return
    end

    local randNum = Random(0,1)
    if randNum <= chanceToSpawn then
        spawnControl:FirePort("Start")
    elseif randNum <= chanceToShowDeadBiped + chanceToSpawn then
        deadBiped:AttachTo(bipedSpawnPod, bipedAttachBone)
        deadBiped:SetAttachLocalSpace(bipedAttachOffset, bipedAttachRotation)
        bipedSpawnPod:PlayAnimation(bipedPodPreSpawnAnim, false, false, 0)
        Sleep(0.5)
        deadBiped:PlayAnimation(deadBipedAnim, true, false, 0)
        deadBiped:Unattach()
        bipedSpawnPod:PlayAnimation(bipedPodPostSpawnAnim, true, false, 0)
    end
end

function VenusRobotSpawnerAnims(agent)
    if not IsNull(agent) then
        local avatar = agent:GetAvatar()
        if not IsNull(avatar) then
            agent:SetAllExits(false)
            avatar:AttachTo(spawnerDeco, spawnerAttachBone)
            avatar:SetAttachLocalSpace(avatarAttachOffest, avatarAttachRotation)
            spawnerDeco:SetAnimateMaster(true)
            spawnerDeco:PlayAnimation(spawnerOpenAnim, true, false, 0)
            avatar:Unattach()
            agent:ReturnToAiControl()
            spawnerDeco:PlayAnimation(spawnerCloseAnim, true, false, 0)
            spawnerDeco:SetAnimateMaster(false)
        end
    end
end