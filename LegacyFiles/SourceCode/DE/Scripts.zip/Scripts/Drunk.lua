local shakeLib = require "Lotus.Scripts.Libs.ShakeLib"

colorCorrection = Resource()
postMaterial = Resource()
mixerArray = {Resource()}
paralyzeSound = Resource()
inaccruacyMultiplier = 10.0

local paralyzeSoundInst = nil

local DISTORT_WEIGHT_DISTORT_SCALE = Symbol("DistortWeight_DistortScale")

local function HandleDrunkness(avatar)
    local cameraControl = avatar:CameraControl()

    local postProcess = gRegion:GetLevelInfo():GetPostProcessInfo(avatar:GetSplitScreenID())    
    local wt = -0.045
    local scale = 0.6
    local lastSpeed = postProcess.viewShake.mShakeSpeed

    local inAndOut = 1.0

    gRegion:AddPostFXMaterial(avatar:GetSplitScreenID(), postMaterial)
    cameraControl:PushColorCorrection(colorCorrection, 0.0, -1.0, 0.0)

    local shakeID = shakeLib:RequestIndex()

    local lastWeapon = nil
    while avatar:IsDrunk() do
        local t = avatar:GetDrunknessLevel()

        local tt = Time() * 0.01
        local tt = math.fmod(tt, 1.0)
        t = t * (math.abs(math.sin(tt * math.pi * 2) * 0.5) + 0.5)

        local weapon = avatar:InventoryControl():GetWeaponInHand(Engine.MAIN_HAND)
        if not IsNull(lastWeapon) and lastWeapon ~= weapon then
            lastWeapon:GetActiveFireBehavior():ClearAttenuation()
        end

        if not IsNull(weapon) then
            local effect = 1 + t * inaccruacyMultiplier
            weapon:GetActiveFireBehavior():SetAttenuation(effect, effect)
        end

        postMaterial:SetParam(DISTORT_WEIGHT_DISTORT_SCALE, wt * t, scale * t)
        if IsNull(cameraControl) then
            print("CameraController null for: " .. avatar:GetName())
        end

        cameraControl:SetColorCorrectionOpacity(colorCorrection, t)
        for i = 1, #mixerArray do
            mixerArray[i]: SetOcclusionBias(t)
        end

        shakeLib:ApplyShake(shakeID, t * 2.0, t)

        if IsNull(paralyzeSoundInst) then
            paralyzeSoundInst = avatar:PlaySound(paralyzeSound, false)
        else
            paralyzeSoundInst:SetGain(-40 * (1.0 - t))
        end

        lastWeapon = weapon
        Sleep(0)
    end

    if not IsNull(lastWeapon) then
        lastWeapon:GetActiveFireBehavior():ClearAttenuation()
    end

    shakeLib:ClearIndex(shakeID)

    if not IsNull(paralyzeSoundInst) then
        paralyzeSoundInst:Stop(false)
    end

    postMaterial:SetParam(DISTORT_WEIGHT_DISTORT_SCALE, 0.0, 0.7)
    cameraControl:RemoveColorCorrection(colorCorrection)
    gRegion:RemovePostFXMaterial(avatar:GetSplitScreenID(), postMaterial)
    for i = 1, #mixerArray do
        mixerArray[i]: SetOcclusionBias(0)
    end

    postProcess.viewShake.mShakeSpeed = lastSpeed
end

function DrunkEffect(context, avatar)
    if IsNull(avatar) or IsNull(avatar:GetPlayer()) then
        return -- no post for NPC
    end

    avatar:SetPostureModifier(Engine.PM_DRUNK, true)
    HandleDrunkness(avatar)
    avatar:SetPostureModifier(Engine.PM_DRUNK, false)
end
