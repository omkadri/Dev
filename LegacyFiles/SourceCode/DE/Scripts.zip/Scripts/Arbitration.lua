playerRespawnPickupType = Type()
numPickupPerDeath = 1
pointCarryFx = Type()
carryBuffType = WeakResource("/Lotus/Types/Gameplay/Arbitration/ResurrectHudBuff")
reviveSound = Resource("/Lotus/Sounds/Gameplay/Arbitration/ArbitrationPlayerRevive")
pointsRequiredForResurrect = 10
debugMode = false
canDepositLessThanRevivePoints = true
reviveFxType = Type("/Lotus/Fx/PowersuitAbilities/ReviveBlast")
respawnAnim = Resource("/Lotus/Animations/Tenno/Contextual/RevivePowerBoost_anim.fbx")
waitTimeBeforeDestroyingPickups = 15
timeToLiveWithoutSeen = 60 -- max time for drones to live without having seen any players
maxLastSeenTime = 20 -- time in seconds in which the drones must have seen the player to stay alive

local pointCarryFxWeak = WeakResource("/Lotus/Fx/Gameplay/EliteReviveOrbDeco")
local playerRespawnPickupTypeWeak = WeakResource("/Lotus/Types/Gameplay/Arbitration/PlayerResurrectPickup")
local mMaxPointCarryBuffs = 25
local mPointCarryBuffs = 
{
    { upgradeType = Game.WEAPON_DAMAGE_AMOUNT, op = Game.MULTIPLY, getVal = function(level) return (1 + 1.5 * (1 - math.floor(100 * math.pow(1.2, -level)) / 100)) end, applyToNonHuman = true},
    { upgradeType = Game.AVATAR_HEALTH_MAX, op = Game.MULTIPLY, getVal = function(level) return (math.ceil(100 * math.pow(1.21, -level)) / 100) end },
    { upgradeType = Game.AVATAR_SHIELD_MAX, op = Game.MULTIPLY, getVal = function(level) return (math.ceil(100 * math.pow(1.21, -level)) / 100) end },
    { upgradeType = Game.AVATAR_POWER_RATE, op = Game.ADD, getVal = function(level) return (-1 * math.max(0, level-2)) end }
}
local mObjectTiveSet = false
local REVIVE_STATION_TAG = Symbol("ReviveStation")
local REVIVE_STATE_TAG = Symbol("PlayerReviveStationState")
local mEliteAlertReviveStation = WeakResource("/Lotus/Types/Gameplay/Arbitration/ReviveStationTrigger")
local mEliteAlertReviveStationState = WeakResource("/Lotus/Types/Gameplay/Arbitration/PlayerReviveStationState")
local uiPriority = 10
local reviveLabel = "/Lotus/Language/Game/ResurrectHudLabel"
local reviveObjPrimary = "/Lotus/Language/Game/ResurrectHudPrimary"
local mTimeAlive = 0
local mNeedsToClearPickups = false

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"

local function GetId(avatar)
    if IsNull(avatar) then
        return EMPTY_SYMBOL
    end
    local avatarName = avatar:GetUIName()
    return Symbol("RESURRECTION_SCORE_" .. avatarName)
end

local function GetDeadPlayers()
    local dead = {}
    local players = gRegion:GetHumanPlayers()
    for i, player in ipairs(players) do
        local playerAv = player:GetAvatar()
        if not IsNull(playerAv) and playerAv:IsKilled() then
            table.insert( dead, playerAv )
        end
    end
    return dead
end

local function IsAnyPlayerDead()
    local dead = GetDeadPlayers()
    return #dead > 0
end

local function UpdateHud()
    if IsNull(_T.ArbitrationHudTracker) then
        return
    end

    local isAnyPlayerDead = IsAnyPlayerDead()
    if not mObjectTiveSet and isAnyPlayerDead then
        mObjectTiveSet = true
        _T.ArbitrationHudTracker[0] = _T.AddHudTracker("ArbitrationPrimaryLabel", LOTUS_UTIL.HT_LABEL, 0.15, uiPriority, true)
        _T.ArbitrationHudTracker[0].SetLabel(_T.ArbitrationHudTracker[0].Localize(reviveObjPrimary))
    elseif mObjectTiveSet and not isAnyPlayerDead then
        mObjectTiveSet = false
        _T.RemoveHudTracker(_T.ArbitrationHudTracker[0])
    end
    local reviveState = gRegion:FindTagged(REVIVE_STATE_TAG)
    for i, state in ipairs(reviveState) do
        if not IsNull(state) then 
            local hudID = state:GetInstanceNumber() + 1 -- 0 is taken by primary
            local tracker = _T.ArbitrationHudTracker[hudID]
            if IsNull(tracker) then
                local playerAv = state:GetAvatar()
                if not IsNull(playerAv) then
                    local id = GetId(playerAv)
                    _T.ArbitrationHudTracker[hudID] =  _T.AddHudTracker(id:c_str() .. "Label", LOTUS_UTIL.HT_LABEL, 0.15, uiPriority + 10, true)
                    _T.ArbitrationHudTracker[hudID].SetOffset(10, -15)
                    _T.ArbitrationHudTracker[hudID].SetLabel(_T.ArbitrationHudTracker[hudID].Localize(reviveLabel, { PLAYER = tostring( playerAv:GetUIName())}))
                end
            end
        end
    end
end

local function CreatePlayerRespawnPickup(victim, count)
    if IsNull(playerRespawnPickupType) then
        return
    end
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    
    -- find valid center position (victim may be off nav)
    local centerPos = victim:GetPosition()

    -- calc desired drop positions
    local dropPositions = {}
    local angle = 360 / count
    for i = 1, count do
        local radius = 1 + math.random() * 2
        local offset = Vector(0,0.5, radius)
        local rot = Rotation(angle * i + math.random() * 25,0,0)
        offset = RotateVector(offset, rot)
        local pos = centerPos + offset
        -- adjust locations to ensure they're on nav. TODO: avoid overlap?
        local adjustedPos = aiDir:GetClosestWorldPointOnNavMeshScript(pos)
        dropPositions[i] = adjustedPos
    end
        
    -- spawn pickups
    local airtime = 1
    local grav = gRegion:GetGravity().y
    for i = 1, count do
        local dropPos = dropPositions[i]
        local toDropPoint = dropPos - centerPos
        airtime = 0.5 + math.random()
        local vx = toDropPoint.x / airtime
        local vz = toDropPoint.z / airtime
        local vy = -(0.5 * grav * airtime - toDropPoint.y / airtime)
        local drop = gRegion:CreateEntity(playerRespawnPickupType, centerPos, ZERO_ROTATION)
        local velocity = Vector(vx,vy,vz)
        drop:ApplyForce(velocity, Engine.FT_VELOCITY_CHANGE)
    end
end

local function PointsGathered(pointsAdded, newTotalPoints, avatar)
    -- add something to communicate how many points the avatar is carrying
    if not IsNull(pointCarryFx) then
        local fx = avatar:GetAllAttachments(pointCarryFxWeak)
        local fxToAdd = newTotalPoints - #fx
        if fxToAdd > 0 then
            for i=1, fxToAdd do
                local randRot = Rotation(math.random(-180,180), 0, 0)
                avatar:Attach(pointCarryFx, EMPTY_SYMBOL, Vector(0, 0.7, 0), randRot)
            end
        end
    end

    local prevPoints = newTotalPoints - pointsAdded
    local newBuffLevel = math.min(mMaxPointCarryBuffs, newTotalPoints)
    local oldBuffLevel = math.min(mMaxPointCarryBuffs, prevPoints)
    if newBuffLevel > oldBuffLevel then
        local invCont = avatar:InventoryControl()
        if not IsNull(invCont) then
            for i = 1, #mPointCarryBuffs do
                local buff = mPointCarryBuffs[i]
                invCont:RemoveUpgrade(buff.upgradeType, buff.op, buff.getVal(oldBuffLevel))
                invCont:AddUpgrade(buff.upgradeType, buff.op, buff.getVal(newBuffLevel))
            end
        end
        
        local statusStruct = Lotus_Game.BuffNotification()
        statusStruct.instigator = avatar
        statusStruct.affected = { avatar }
        statusStruct.buffType = Lotus_Game.BT_AMOUNT
        statusStruct.abilityType = carryBuffType
        statusStruct.buffData = newBuffLevel
        statusStruct.isDebuff = true
        statusStruct.forceSquadPanel = true
        avatar:ProcessBuffNotification(statusStruct, true, true)    
    end
end

local function RemovePointDebuffs(avatar, pointsToRemove, totalPoints, removeNotification)  
    
    if IsNull(removeNotification) then
        removeNotification = true
    end  

    local invCont = avatar:InventoryControl()
    
    local newPoints = totalPoints - pointsToRemove
    if not IsNull(invCont) then
        for i = 1, #mPointCarryBuffs do
            local buff = mPointCarryBuffs[i]
            invCont:RemoveUpgrade(buff.upgradeType, buff.op, buff.getVal(totalPoints))
            invCont:AddUpgrade(buff.upgradeType, buff.op, buff.getVal(newPoints))
        end
    end
    
    if removeNotification then
        local addBuff = newPoints > 0
        local statusStruct = Lotus_Game.BuffNotification()
        statusStruct.instigator = avatar
        statusStruct.affected = { avatar }
        statusStruct.buffType = Lotus_Game.BT_AMOUNT
        statusStruct.abilityType = carryBuffType
        statusStruct.buffData = newPoints
        statusStruct.isDebuff = true
        statusStruct.forceSquadPanel = true
        avatar:ProcessBuffNotification(statusStruct, addBuff, true)
    end
end

local function RemovePointFx(avatar, points)
    local fx = avatar:GetAllAttachments(pointCarryFxWeak)
    if not IsNull(fx) then
        local fxToRemove = math.min(points, #fx)
        for i = 1, fxToRemove do
            if not IsNull(fx[i]) or not fx[i]:IsGarbage() then
                fx[i]:Unattach() -- there can be multiple RemovePointFx calls in 1 frame, so Unattach so we dont destroy the same fx more than once
                fx[i]:Destroy()
            end
        end
    end
end

local function GetPoints(avatar)
    return gGameRules:GetNetPersistentVar(GetId(avatar), 0)
end

local function AddpointsToAvatar(avatar, points)
    local ressurectionId = GetId(avatar)
    local currentPoints = gGameRules:GetNetPersistentVar(ressurectionId, 0)
    currentPoints = Clamp(currentPoints + points, 0, mMaxPointCarryBuffs)
    gGameRules:SetNetPersistentVar(ressurectionId, currentPoints) 
    return currentPoints
end

local function RemovePointEffects(avatar, points, removeNotification)
    local totalPoints = GetPoints(avatar)
    RemovePointDebuffs(avatar, points, totalPoints, removeNotification)
    RemovePointFx(avatar, points)
    
    local otherAvatar
    local player = avatar:GetPlayer()
    if avatar:IsA(gLotusOperatorAvatarType) then
        otherAvatar = player:GetOwnedPowerSuitAvatar()
    else
        otherAvatar = player:GetOperatorAvatar()
    end
    
    if not IsNull(otherAvatar) then
        RemovePointDebuffs(otherAvatar, points, totalPoints, removeNotification)
        RemovePointFx(otherAvatar, points)
    end
end

local function RemovePoints(avatar, points)
    if IsNull(points) or points <= 0 then
        return
    end

    RemovePointEffects(avatar, points, true)
    AddpointsToAvatar(avatar, -points)
end

local function RemoveAllPoints(avatar)
    local points = GetPoints(avatar)
    if points > 0 then
        RemovePoints(avatar, points)
    end
    
    local fx = avatar:GetAllAttachments(pointCarryFxWeak)
    for i=1, #fx do
        if not IsNull(fx[i]) or not fx[i]:IsGarbage() then
            fx[i]:Destroy()
        end
    end
end

local function EnsurePointEffects(playerAv)
    local points = GetPoints(playerAv)
    if points > 0 then
        local fx = playerAv:GetAllAttachments(pointCarryFxWeak)
        if #fx ~= points then
            RemovePointEffects(playerAv, points, false)
            PointsGathered(points, points, playerAv)
        end
    end
end


local function SanitizePlayerPoints(playerToSkip)
    --if no more dead players, remove points from live players 
    if not IsAnyPlayerDead() then
        local pickups = gRegion:FindAll(playerRespawnPickupTypeWeak)
        for i, pickup in ipairs(pickups) do
            pickup:Destroy()
        end
        
        local playerAvatars = gRegion:GetHumanPlayerAvatars()
        for _, playerAv in ipairs(playerAvatars) do
            RemoveAllPoints(playerAv)
        end
    else
        local playerAvatars = gRegion:GetHumanPlayerAvatars()
        for _, playerAv in ipairs(playerAvatars) do
            if playerAv ~= playerToSkip then
                EnsurePointEffects(playerAv)
            end
        end
    end
end

local function DestroyReviveBeacon(trigger, reviveState)
    if not IsNull(reviveState) then
        local hudID = reviveState:GetInstanceNumber() + 1
        reviveState:Destroy()
        local tracker = _T.ArbitrationHudTracker[hudID]
        if not IsNull(tracker) then
            _T.RemoveHudTracker(_T.ArbitrationHudTracker[hudID])
            _T.ArbitrationHudTracker[hudID] = nil
        end
    end

    if not IsNull(trigger) then
        trigger:Destroy()
    end
end

local function Revive(trigger, reviveState)
    -- resurrect dead player
    local playerAvatar = nil
    local reviveCandidateAv = reviveState:GetAvatar()
    if not IsNull(reviveCandidateAv) then
        local reviveCandidatePlayer = reviveCandidateAv:GetPlayer()
        if not IsNull(reviveCandidatePlayer) then
            gGameRules:RespawnPlayer(reviveCandidatePlayer, false)
            reviveCandidatePlayer:SetCanRespawn(true)
            playerAvatar = reviveCandidatePlayer:GetAvatar()
            if not IsNull(playerAvatar) then
                playerAvatar:Attach(reviveFxType, EMPTY_SYMBOL)
                playerAvatar:PlayAnimation(respawnAnim, false)
                playerAvatar:PlaySound(reviveSound,false)
            end
        end
    end
    
    DestroyReviveBeacon(trigger, reviveState)
    SanitizePlayerPoints(playerAvatar)
end

function OnDroneDeath(avatar)
    if IsAnyPlayerDead() and gRegion:IsMaster() then
        CreatePlayerRespawnPickup(avatar, numPickupPerDeath)
    end
end

function SetupReviveTower(tower)
    -- check if we are the first tower (only dead player not from host migration), if so reset everyone's points
    local towers = gRegion:FindTagged(REVIVE_STATION_TAG)    
    if #towers == 1 then
        local players = gRegion:GetHumanPlayers()
        for i, player in ipairs(players) do
            local playerAv = player:GetAvatar()
            if not IsNull(playerAv) then
                if not _T.ArbitrationDeadPlayerSpawned then
                    RemoveAllPoints(playerAv)
                else
                    EnsurePointEffects(playerAv)
                end
            end
        end
        _T.ArbitrationDeadPlayerSpawned = false
    else
        for i, other in ipairs(towers) do
            local towerState = gRegion:FindNearestTagged(REVIVE_STATE_TAG, tower:GetPosition())
            local otherState = gRegion:FindNearestTagged(REVIVE_STATE_TAG, other:GetPosition())
            if otherState ~= towerState and not IsNull(otherState) and not IsNull(towerState) and otherState:GetAvatar() == towerState:GetAvatar() then -- duplicate
                --DestroyReviveBeacon(other, otherState)
            end
        end
    end

    local creator = tower:GetCreator()
    if not IsNull(creator) and creator:IsLocallyAuthoritative() then
        local player = creator:GetPlayer()
        if not IsNull(player) then
            while true do
                player:NotifyActivity() -- stop dead players from being marked AFK
                Sleep(1)
            end
        end
    end
end

function PickupEvaluate(parentPickUp, avatar)
    if IsNull(avatar) or avatar:IsHumanPlayer() then
        return true
    end
    return false
end

function GetRespawnPoint(avatar, item, trigger)
    if IsNull(avatar) or avatar:IsKilled() then
        return
    end

    if not IsAnyPlayerDead() then
        RemoveAllPoints(avatar)
        return
    end
    
    local amount = 1 -- todo: items with different amounts
    local points = AddpointsToAvatar(avatar, amount)
    
    PointsGathered(amount, points, avatar)
    
    local drop = trigger:GetAttachParent()
    drop:Destroy()
end

function OnReviveStationExit(trigger, avatar)
    if avatar:IsLocallyAuthoritative() then
        _T.HideImpactMessage()
    end
end

function OnReviveStationActivated(trigger, avatar)
    if IsNull(avatar) or avatar:IsKilled() then
        return
    end
    
    local isMaster = gRegion:IsMaster()

    local reviveState = gRegion:FindNearestTagged(REVIVE_STATE_TAG, trigger:GetPosition())
    if not IsNull(reviveState) and not IsNull(reviveState:GetAvatar()) then
        local currentPoints = reviveState:GetPower()
        
        local incomingPoints = GetPoints(avatar)
        local canRevive = false
        if canDepositLessThanRevivePoints and isMaster then
            local pointsAccepted = math.min(pointsRequiredForResurrect - currentPoints, incomingPoints)
            
            if pointsAccepted > 0 then
                RemovePoints(avatar, pointsAccepted)
                
                currentPoints = currentPoints + pointsAccepted
                if currentPoints >= pointsRequiredForResurrect then
                    canRevive = true
                else
                    -- deposit point
                    reviveState:SetPower(currentPoints)
                    if debugMode and gFlashMgr:GetConfigBool("Engine.DeveloperMode") then
                        local drawTime = 5
                        local size = 3
                        gRegion:VisAddText(trigger:GetPosition() + Vector(0,2,0), Color(200,100,0), (pointsRequiredForResurrect - currentPoints) .. " needed", size, drawTime)
                    end
                end
            end
        else
            canRevive = incomingPoints >= pointsRequiredForResurrect
            if not canRevive then
                --check if there are any other players in radius and count their points too
                local playerAvatars = gRegion:GetHumanPlayerAvatars()
                local playersChecked = {}
                table.insert(playersChecked, avatar)
                for _, playerAv in pairs(playerAvatars) do
                    if playerAv ~= avatar and not IsNull(playerAv) and not playerAv:IsKilled() and trigger:IsAvatarTouching(playerAv) then
                        local playerPoints = GetPoints(playerAv)
                        incomingPoints = incomingPoints + playerPoints
                        table.insert(playersChecked, playerAv)
                        
                        if isMaster and incomingPoints >= pointsRequiredForResurrect then
                            canRevive = true
                            local pointsLeftToConsume = pointsRequiredForResurrect
                            for i, p in pairs(playersChecked) do
                                local points = math.min(GetPoints(p), pointsLeftToConsume)
                                RemovePoints(p, points)
                                pointsLeftToConsume = pointsLeftToConsume - points
                                if pointsLeftToConsume <= 0 then
                                    break
                                end
                            end
                            break
                        end 
                    end
                end
                local localAvatar = gRegion:GetLocalPlayerAvatar()
                if not IsNull(localAvatar) and trigger:IsAvatarTouching(localAvatar) then
                    _T.ShowImpactMessage("<ARBITRATION_DRONE> " .. incomingPoints .. "/" .. pointsRequiredForResurrect, -1)
                end
            elseif isMaster then
                RemovePoints(avatar, pointsRequiredForResurrect)
            end
        end

        if isMaster and canRevive then
            Revive(trigger, reviveState)
        end

        if avatar:IsLocallyAuthoritative() then
            while not IsNull(trigger) and trigger:IsAvatarTouching(avatar) do
                -- Update impact message count, hide message for the exiting player
                local points = 0
                local playerAvatars = gRegion:GetHumanPlayerAvatars()
                for _, playerAv in pairs(playerAvatars) do
                    if not IsNull(playerAv) and not playerAv:IsKilled() and trigger:IsAvatarTouching(playerAv) then
                        local playerPoints = GetPoints(playerAv)
                        points = points + playerPoints
                    end
                end
                
                _T.ShowImpactMessage("<ARBITRATION_DRONE> " .. points .. "/" .. pointsRequiredForResurrect, -1)
                Sleep(0.5)
            end
        end
    end
end

local function SpawnReviveTower(playerAv)
    local revivePos = gRegion:GetNpcMgr():GetAiDirector():GetClosestWorldPointOnNavMeshScript(playerAv:GetPosition())
    revivePos.y = revivePos.y + 1

    local reviveStation = gRegion:CreateEntity(Type(mEliteAlertReviveStation), revivePos, ZERO_ROTATION, playerAv, nil)    
    local reviveStationState = gRegion:CreateEntity(Type(mEliteAlertReviveStationState), revivePos, ZERO_ROTATION, playerAv, nil)

    reviveStationState:SetPower(0)
    reviveStationState:SetAvatar(playerAv)

    local otherStates = gRegion:FindTagged(REVIVE_STATE_TAG)
    local max = 0
    for i = 1, #otherStates do
        if otherStates[i] ~= reviveStationState then
            max = math.max(max, otherStates[i]:GetInstanceNumber())
        end
    end
    reviveStationState:SetInstanceNumber(max + 1)
end

local function HandlePlayerSpawned(player)
    local playerAv = player:GetAvatar()
    if not IsNull(playerAv) then
        if playerAv:IsKilled() then
            _T.ArbitrationDeadPlayerSpawned = true
            SpawnReviveTower(playerAv)
        else
            local points = GetPoints(playerAv)
            if points > 0 and not playerAv:IsKilled() and IsAnyPlayerDead() then
                RemovePointEffects(playerAv, points, false)
                PointsGathered(points, points, playerAv)
            end
        end
    end
end

local function HandlePlayerDisconnected(player)
    SanitizePlayerPoints()
end

local function HandlePlayerAvatarChanged(player)
    if IsNull(player) then
        return
    end
    
    -- Operator vs. the Arena mechanics: All points carry over to the controlling player
    local avatar = player:GetAvatar()
    if IsNull(avatar) or not avatar:IsHumanPlayer() then
        return
    end
    
    local oldAvatar
    if avatar:IsA(gLotusOperatorAvatarType) then
        oldAvatar = player:GetOwnedPowerSuitAvatar()
    else
        oldAvatar = player:GetOperatorAvatar()
    end
    
    if IsNull(oldAvatar) then
        return
    end
    
    -- handle deco effects
    local pointEffects = oldAvatar:GetAllAttachments(pointCarryFxWeak)
    for i = 1, #pointEffects do
        pointEffects[i]:Unattach()
        pointEffects[i]:AttachTo(avatar, Symbol())
    end
    
    --handle financial stress debuff

    local id = GetId(avatar)
    local buffLevel = math.min(mMaxPointCarryBuffs, GetPoints(avatar))
    local invCont = avatar:InventoryControl()
    local oldInvCont = oldAvatar:InventoryControl()
    if not IsNull(invCont) and not IsNull(oldInvCont) then
        for i = 1, #mPointCarryBuffs do
            local buff = mPointCarryBuffs[i]
            oldInvCont:RemoveUpgrade(buff.upgradeType, buff.op, buff.getVal(buffLevel))
            invCont:AddUpgrade(buff.upgradeType, buff.op, buff.getVal(buffLevel))
        end
    end
    
    if buffLevel > 0 then
        local statusStruct = Lotus_Game.BuffNotification()
        statusStruct.instigator = avatar
        statusStruct.affected = { avatar }
        statusStruct.buffType = Lotus_Game.BT_AMOUNT
        statusStruct.abilityType = carryBuffType
        statusStruct.buffData = buffLevel
        statusStruct.isDebuff = true
        statusStruct.forceSquadPanel = true
        avatar:ProcessBuffNotification(statusStruct, true, true)
    end
end

local function DoesAvatarHaveReviveTower(avatar)
    local reviveStations = gRegion:FindTagged(REVIVE_STATION_TAG)
    for _, reviveStation in ipairs(reviveStations) do
        local state = gRegion:FindNearestTagged(REVIVE_STATE_TAG, reviveStation:GetPosition())
        if not IsNull(state) then
            local reviveAv = state:GetAvatar()

            if not IsNull(reviveAv) and reviveAv == avatar then
                return true
            end
        end    
    end
    return false
end

function Arbitration()

    while gClient:IsHostMigrationInProgress() or IsNull(gRegion:GetLocalPlayerAvatar()) do
        Sleep(0)
    end

    if IsNull(_T.ArbitrationHudTracker) then
        _T.ArbitrationHudTracker = {}
    end
    
    mTimeAlive = 0
    mNeedsToClearPickups = gPromotedToHost
    while true do
        if mNeedsToClearPickups then
            mTimeAlive = mTimeAlive + DeltaTime()
            if mTimeAlive > waitTimeBeforeDestroyingPickups then
                if not IsAnyPlayerDead() then
                    local pickups = gRegion:FindAll(playerRespawnPickupTypeWeak)
                    for i, pickup in ipairs(pickups) do
                        pickup:Destroy()
                    end
                end
                mNeedsToClearPickups = false
            end
        end

        if not IsNull(_T.EliteAlertPlayerAvatarChanged) then
            local player = _T.EliteAlertPlayerAvatarChanged
            _T.EliteAlertPlayerAvatarChanged = nil
            HandlePlayerAvatarChanged(player)
        end
        
        if not IsNull(_T.EliteAlertPlayerDisconnected ) then
            local player = _T.EliteAlertPlayerDisconnected 
            _T.EliteAlertPlayerDisconnected  = nil
            HandlePlayerDisconnected(player)
        end

        if not IsNull(_T.EliteAlertPlayerSpawned) then
            for i, player in pairs(_T.EliteAlertPlayerSpawned) do
                table.remove( _T.EliteAlertPlayerSpawned, i)
                if not IsNull(player) then
                    HandlePlayerSpawned(player)
                end
            end
        end

        UpdateHud()
        local players = gRegion:GetHumanPlayers()

        if not IsNull(_T.EliteAlertDroneList) then
            for i = #_T.EliteAlertDroneList, 1, -1 do
                local droneData = _T.EliteAlertDroneList[i]
                if not IsNull(droneData.droneAgent) and not IsNull(droneData.droneAgent:GetAvatar()) and not droneData.droneAgent:GetAvatar():IsKilled() then
                    local timeSinceCreation = Time() - droneData.creationTime
                    if timeSinceCreation > timeToLiveWithoutSeen then
                        local shouldDestroyDrone = true
                        for i, player in ipairs(players) do
                            local avatar = player:GetAvatar()
                            if not IsNull(avatar) and droneData.droneAgent:HasSeenRecently(avatar, maxLastSeenTime) then
                                shouldDestroyDrone = false
                                break
                            end
                        end

                        if shouldDestroyDrone then
                            print("Destroying " .. droneData.droneAgent:GetAvatar():GetName() .. " for not seeing a player for " .. tostring(maxLastSeenTime) .. "sec, " .. tostring(timeSinceCreation) .. "sec after creation")
                            droneData.droneAgent:GetAvatar():Destroy()
                            _T.EliteDroneForceSpawn = true
                        end
                    end
                else
                    table.remove( _T.EliteAlertDroneList, i)
                end

            end
        end

        -- remove the revive station if players disconnected
        local reviveStations = gRegion:FindTagged(REVIVE_STATION_TAG)
        local deadPlayers = GetDeadPlayers()
        if #deadPlayers ~= #reviveStations then
            for i, dead in ipairs(deadPlayers) do
                if not IsNull(dead) and not DoesAvatarHaveReviveTower(dead) then
                    SpawnReviveTower(dead)
                    RemoveAllPoints(dead)
                end
            end
        end
        for _, reviveStation in ipairs(reviveStations) do
            -- get revive state
            local reviveState = gRegion:FindNearestTagged(REVIVE_STATE_TAG, reviveStation:GetPosition())
            local avatar = reviveState:GetAvatar()
            local foundPlayer = false

            if not IsNull(avatar) then
                for i, player in ipairs(players) do
                    local av = player:GetAvatar()
                    foundPlayer = IsNull(av) or ((av == avatar) and av:IsKilled())
                    if foundPlayer then
                        local player = av:GetPlayer()
                        if not IsNull(player) then
                            player:NotifyActivity() -- stop dead players from being marked AFK
                        end
                        break
                    end
                end
                if not foundPlayer then
                    DestroyReviveBeacon(reviveStation, reviveState)
                    SanitizePlayerPoints()
                    break 
                end
            else
                local found = false
                for i, player in ipairs(players) do
                    local av = player:GetAvatar()
                    if not IsNull(av) and av:IsKilled() and not DoesAvatarHaveReviveTower(av) then
                        reviveState:SetAvatar(av)
                        found = true
                        break
                    end
                end
                if not found then
                    DestroyReviveBeacon(reviveStation, reviveState)
                end
            end
        end

        Sleep(0)
    end
end