attachType = Type()
radialCaster = Instance()
radialType = Type()
radialPostTexture = Resource()
radLight = Type()
morphName = Symbol("Morphs.Rage")

beamLife = 0.75
setBeamEndPointOnCreate = false
sleepTime = 0

introPostTexture = Resource()
introSound = Resource()
slomoTool = Resource()
saturation = 1.0

inWorldTransmission = Resource()
cinematicTag = Symbol()

preCinematicSound = Resource()
preCinematicDelay = 0.2

boneName = Symbol()
rotation = Rotation()

newPostFxMaterial = Resource()
postProcessVolume = Instance()

fadeTime = 0

textMovie = Resource("/Lotus/Interface/IntroTextB.swf")
textOverlayTag = String("/Lotus/Language/NewWarIntro/NewWarIntroText")

-- Morphs.Alert Morphs.Dead Morphs.Fear Morphs.Pain Morphs.Rage Morphs.Smug

local UTIL = require "EE.Interface.Utilities"

function RandomHeading(entity)
    entity:SetRotation(Rotation(math.random() * 360.0, 0, 0))
end

function SetMorph(entity)
    Sleep(0.0)
    local deco = entity:GetAttachment(attachType)
    if not IsNull(deco) then
        deco:SetMorphValue(morphName, 1.0)
    end
end

function SelfSetMorph(entity)
    Sleep(0.0)
    
    if not IsNull(entity) then
        entity:SetMorphValue(morphName, 1.0)
    end
end

function SelfSetMorphHack(entity)
    while not IsNull(entity) do
        entity:SetMorphValue(morphName, 1.0)
        Sleep(0.0)
    end
end

function RadialPost(cinematic)
    -- don't have avatar at this point, use player instead
    local player = gRegion:GetLocalPlayers()[1]
    local cameraControl = player:CameraControl()
    cameraControl:PushColorCorrection(radialPostTexture, 0.0, -1.0, 0.0)
    cameraControl:SetColorCorrectionOpacity(radialPostTexture, 0.0)
    local postProcess = gRegion:GetLevelInfo().postProcess
    local cinematic = gRegion:GetPlayingCinematic()
    _T.radialLight = radialCaster:GetAttachment(radLight)
    _T.radialLight:FirePort("TurnOn")
    
    Sleep(0.5)
    
    local t = 0.0
    while t < 1.0 do
    
        postProcess.motionBlurStrength = Lerp(4.0, 2.0, t)
    
        t = t + DeltaTime() * 0.25
        if _T.blowup == nil then
            cameraControl:SetColorCorrectionOpacity(radialPostTexture, t)
        end
        if not IsNull(cinematic) then
            local st = (t * t)
            cinematic:SetShakeParams(st * 0.5, 0.0, 0.3, 1.5)
        end
        Sleep(0)
    end

end

function RadialBlast(cinematic)

    Sleep(0.15)
    local PausedFx = gRegion:FindTagged(Symbol("SleepingFx"))
    local player = gRegion:GetLocalPlayers()[1]
    local cameraControl = player:CameraControl()
    local pos = radialCaster:GetBonePosition(Symbol("GAME_R1_ARM1"))
    local radialEntity = gRegion:CreateEntity(radialType, pos, ZERO_ROTATION)
    local cinematic = gRegion:GetPlayingCinematic()

    local postProcess = gRegion:GetLevelInfo().postProcess
    
    local startScale = 0.1
    local scale = startScale
    _T.blowup = true
    _T.radialLight:FirePort("TurnOff")
    
    if #PausedFx > 0 then
        for i = 1, #PausedFx do
            PausedFx[i]:RemoveDeltaAttenuation(Symbol("Cinematic"))
            local attachments = PausedFx[i]:GetAllAttachments(gEntityType)
            if #attachments > 0 then
                for x = 1, #attachments do
                    attachments[x]:RemoveDeltaAttenuation(Symbol("Cinematic"))
                end
            end
        end
    end
    
    cameraControl:RemoveColorCorrection(radialPostTexture)
    postProcess.fade = -1
    
    
    cinematic:SetShakeParams(1.0, 0.0, 0.3, 1.5)
    
    
    while true do
        postProcess.fade = math.min(0, postProcess.fade + DeltaTime() * 4.0)
        radialEntity:SetMeshScale(scale)
        scale = scale + DeltaTime()  * (5.0 + scale)
        Sleep(0)
    end
    
end

function ParticleSleeper(entity)
    Sleep(sleepTime * 0.3)
    entity:AddDeltaAttenuation(Symbol("Cinematic"), 0.0)
    
    local attachments = entity:GetAllAttachments(gEntityType)
    if #attachments > 0 then
        for x = 1, #attachments do
            attachments[x]:AddDeltaAttenuation(Symbol("Cinematic"), 0.0)
        end
    end
    Sleep(0)
    

    
end


function BeamTest(effect)

    while true do
        
        
        local av = gRegion:GetPlayerAvatar()
        if not IsNull(av) then
            local pos = av:EyePosition()
            effect:SetEndPoint(pos)
        end
        
        Sleep(0)
    end

end

function BeamControl(effect)
    if setBeamEndPointOnCreate and not gRegion:IsMaster() then
        if not IsNull(effect:GetCreator()) then
            effect:SetEndPoint(effect:GetCreator():GetPosition())
        end
    end

    Sleep(beamLife)
    if not IsNull(effect) then
        effect:Destroy()
    end
end

function IntroFXOne(cinematic)
    local soundInst = cinematic:PlaySound(introSound, false, 0, false)
    
    local player = gRegion:GetLocalPlayers()[1]
    local cameraControl = player:CameraControl()
    cameraControl:PushColorCorrection(introPostTexture, 0.0, -1.0, 0.0)
    cameraControl:SetColorCorrectionOpacity(introPostTexture, 1.0)
    
    
    gFlashMgr:SetConfigFloat("Delta.SlomoSpeedMultiplier", 0.05)
    gFlashMgr:ExecuteToolMenuCommand(slomoTool)
end

function IntroFXTwo(cinematic)
    gFlashMgr:ExecuteToolMenuCommand(slomoTool)
end

function IntroFXThree(cinematic)
    local postProcess = gRegion:GetLevelInfo():GetPostProcessBias()
    
    local t = 0.0
    while t <= 1.0 do
        t = t + RealDeltaTime() * 0.35
        postProcess.motionBlurStrength = 3--Lerp(4.0, 2.0, t)
        if not IsNull(cinematic) then
            local st = (t * t)
            cinematic:SetShakeParams(st * 5, 0.1, 0.3, 30.5)
        end
        
        cinematic:SetFOVAtten(1 + (t * t) * 0.8)
        
        postProcess.fade = -math.pow(t, 3.0)
        postProcess.bloom = t
        Sleep(0)
    end
end

function IntroFX(cinematic)
    
    
end


function ColorCorrect(cinematic)
    local postProcess = gRegion:GetLevelInfo().postProcess
    postProcess:SetColorCorrection(introPostTexture)
    postProcess.saturation = saturation
end

function PlayInWorldTransmissionThenCinematic()
    if not _T.InWorldTransmissionQueue then
        _T.InWorldTransmissionQueue = {}
    end

    local transToPlay = nil
    local curNode = tostring(gGameRules:GetMission().location)

    transToPlay = inWorldTransmission

    table.insert(_T.InWorldTransmissionQueue, transToPlay)

    while #_T.InWorldTransmissionQueue > 0 or _T.InWorldTransmissionPlaying do
        Sleep(0)
    end

    if not IsNull(preCinematicSound) then
        UTIL.PlaySound(preCinematicSound)
    end

    Sleep(preCinematicDelay)

    -- Fade out
    local levelInfo = gRegion:GetLevelInfo()
    local t = 0.0
    while t <= 1.0 do
        t = t + RealDeltaTime()
        
        levelInfo.postProcess.fade = math.pow(t, 3.0)
        Sleep(0)
    end

    local cinematic = gRegion:FindFirstTagged(cinematicTag)
    if not IsNull(cinematic) then
        cinematic:FirePort("StartPlaying")
    end

    while not IsNull(cinematic) and not cinematic:IsPlaying() do
        Sleep(0)
    end
    -- Fade in
    t = 0.0
    while t <= 1.0 do
        t = t + RealDeltaTime() * 2.0
        levelInfo.postProcess.fade = 1.0 - math.pow(t, 3.0)
        Sleep(0)
    end    
    
    while not IsNull(cinematic) and cinematic:IsPlaying() do
        Sleep(0)
    end
    
    levelInfo.postProcess.fade = -1.0
    Sleep(3)

    Engine.Disconnect(false)
end

function OnQuestStartCinematicFinished()
    _T.QuestStartCinPlaying = false
end

function SetBoneDirector(deco)
    while true do
        Sleep(0)
        deco:SetBoneDirector(boneName, rotation)
    end
end

function FromBlack(cinematic)
    local levelInfo = cinematic:GetRegionMgr():GetLevelInfo()
    local t = 1.0
    levelInfo.postProcess.fade = t
    while t > 0.0 do
        t = t - DeltaTime() * 0.5
        levelInfo.postProcess.fade = t
        Sleep(0)
    end
    levelInfo.postProcess.fade = 0
end

function ToBlack(cinematic)
    local levelInfo = cinematic:GetRegionMgr():GetLevelInfo()
    
    if not IsNull(postProcessVolume) then
        postProcessVolume:FirePort("Disable")
    end
    Sleep(0)
    if fadeTime == 0 then
        levelInfo.postProcess.fade = 1
        return
    end
    
    local t = 0
    while t < fadeTime do
        Sleep(0)
        t = t + DeltaTime()
        levelInfo.postProcess.fade = Lerp(0, 1, t / fadeTime)
    end
end

function FromWhite(cinematic)
    local levelInfo = cinematic:GetRegionMgr():GetLevelInfo()
    local t = 1.0
    levelInfo.postProcess.fade = t
    while t > 0.0 do
        t = t - DeltaTime() * 0.5
        levelInfo.postProcess.fade = -t
        Sleep(0)
    end
    levelInfo.postProcess.fade = 0
end

function ToWhite(cinematic)
    local levelInfo = cinematic:GetRegionMgr():GetLevelInfo()
    local t = 0
    --levelInfo.postProcess.fade = t
    while t < 1 do
        t = t + DeltaTime() * 2.5
        levelInfo.postProcess.fade = (0 - t)
        Sleep(0)
    end
    levelInfo.postProcess.fade = -1
end

function SwapPostFxMaterial(cinematic)
    local postProcess = cinematic:GetRegionMgr():GetLevelInfo().postProcess
    postProcess:SetPostFxMaterial(newPostFxMaterial)
end

function HunhowTalkingSword(entity)
    local region = entity:GetRegionMgr()
    local hunhowTag = Symbol("Hunhow")
    local sUnlitAtten = Symbol("UnlitAtten")
    local deco = entity:Attach(attachType, EMPTY_SYMBOL)
    local decoSize = 1
    if not IsNull(deco) then
        decoSize = deco:GetMeshScale()
    end
    while true do
        local cinematic = region:GetPlayingCinematic()
        while not IsNull(cinematic) and not IsNull(entity) do 
            local soundInstance = cinematic:GetSoundInstanceByTag(hunhowTag)
            if not IsNull(soundInstance) then
                local amp = soundInstance:GetCurAmplitude()
                entity:SetSize(2.0 + 3.0 * amp)
                if not IsNull(deco) then
                    deco:SetMaterialParam(sUnlitAtten, 0.4 + 3.0 * amp)
                    deco:SetMeshScale(Lerp(decoSize * 0.65, decoSize, amp))
                end
            end
            Sleep(0)
        end
        Sleep(0)
    end
end

function OperatorCrawl(cinematic)
    
    if IsNull(cinematic) then
        return
    end
    
    local heartTag = Symbol("Heartbeat")
    local region = cinematic:GetRegionMgr()
    local postProcess = region:GetLevelInfo():GetPostProcessBias()
    local initialHit = 1
    local spinWait = true
    
    --postProcess.radialBlurStrength = 1
    local soundInstance = nil
    
    while spinWait or not IsNull(soundInstance) do 
    
        local amp = 0
        soundInstance = cinematic:GetSoundInstanceByTag(heartTag)
        if not IsNull(soundInstance) then
            amp = soundInstance:GetCurAmplitude()
            spinWait = false
        end

        amp = math.pow(amp, 5.0)
    
        postProcess.blur = Clamp(amp * 100, 0, 1)
        postProcess.bloom = initialHit + Clamp(amp * 100, 0, 2)
        postProcess.radialBlurStrength = Clamp(0.5 + amp * 100, 0, 1)
        postProcess.fade = -initialHit
        postProcess.saturation =  -initialHit
        initialHit = Clamp(initialHit - DeltaTime(), 0, 1)
        
        Sleep(0)
    end
    
    local t = -1.0
    while t < 1.0 do
        t = Clamp(t + DeltaTime() * 0.1, 0, 1)
        postProcess.blur = Lerp(postProcess.blur, 0, t)
        postProcess.bloom = Lerp(postProcess.bloom, 0, t)
        postProcess.fade = Lerp(postProcess.fade, 0, t)
        postProcess.radialBlurStrength = Lerp(postProcess.radialBlurStrength, 0, t)
        postProcess.saturation = Lerp(postProcess.saturation, 0, t)
        Sleep(0)
    end
    
end

function DipToBlack(cinematic)
    local region = cinematic:GetRegionMgr()
    local postProcess = region:GetLevelInfo():GetPostProcessBias()

    local t = 0.0
    while t < 1.0 do
        t = Clamp(t + DeltaTime() * 0.25, 0, 1)
        local tm = math.abs(1 - math.abs(t * 2 - 1))
        postProcess.fade = math.pow(tm, 4.0)
        --print("Dip to black: " .. tm)
        Sleep(0)
    end 
end

function DipToHeldBlack(cinematic)
    local region = cinematic:GetRegionMgr()
    local postProcess = region:GetLevelInfo():GetPostProcessBias()

    local t = 0.0
    while t < 1.0 do
        t = Clamp(t + DeltaTime() * 0.5, 0, 1)
        postProcess.fade = (t * t)
        Sleep(0)
    end
    
    postProcess.fade = 1
    Sleep(1)
    
    t = 0.0
    while t < 1.0 do
        t = Clamp(t + DeltaTime() * 0.5, 0, 1)
        postProcess.fade = math.pow(1.0 - t, 2.0)
        Sleep(0)
    end 
    postProcess.fade = 0
    
end

function RadialBoff(cinematic)
    local region = cinematic:GetRegionMgr()
    local postProcess = region:GetLevelInfo():GetPostProcessBias()

    postProcess:SetRadialBlurScale(1,1)
    postProcess.radialBlurStrength = 1.0
    Sleep(4)
    
    local t = 0.0
    while t < 1.0 do
        t = Clamp(t + DeltaTime() * 0.25, 0, 1)
        postProcess.radialBlurStrength = 1.0 - t
        Sleep(0)
    end
end

function CreateSplash(spawner)
    local triggerType = Type("/EE/Types/Engine/WaterSimTrigger")
    local pos = spawner:GetSimPosition()
    local trigger = gRegion:FindNearest(triggerType, pos, 50)
    for i=1, 6 do
        if not IsNull(trigger) then
            trigger:InsertSplashPoint(pos + Vector(Random(-0.15, 0.15), 0, Random(-0.15, 0.15)))
        end
        Sleep(0)
    end
end

function JunctionLights(cinematic)
    local lights = gRegion:FindTagged(Symbol("SunLight"))
    for i=1,#lights do
       local light = lights[i]
       light:SetBrightness(4.0)
       light:SetColor(Color(128,196,255)) 
    end

    local postProcessBias = gRegion:GetLevelInfo():GetPostProcessBias()
    postProcessBias.bloom = 4.0
    postProcessBias.blur = 1.0
    postProcessBias.radialBlurStrength = 1.0
    postProcessBias:SetColorCorrection(introPostTexture)
end

function OperatorMemoryStart(cinematic)
    local postProcessBias = gRegion:GetLevelInfo():GetPostProcessBias()
    local t = 0
    while t < 1.0 do
        t = math.min(1.0, t + DeltaTime())
        postProcessBias.bloom = t * 4.0
        postProcessBias.blur = t
        postProcessBias.radialBlurStrength = t * 0.5
        Sleep(0)
    end
    --postProcessBias:SetColorCorrection(introPostTexture)
end

function OperatorMemoryEnd(cinematic)
    local postProcessBias = gRegion:GetLevelInfo():GetPostProcessBias()
    local t = 0
    while t < 1.0 do
        t = math.min(1.0, t + DeltaTime())
        postProcessBias.bloom = (1-t) * 4.0
        postProcessBias.blur = 1.0 -t
        postProcessBias.radialBlurStrength = (1.0 - t) * 0.5
        Sleep(0)
    end
end

function ShowMemoryDecos(cinematic)
    local entity = gRegion:FindFirstTagged(cinematicTag)
    if not IsNull(entity) then
        entity:SetVisibility(true, true)
        
        local a = entity:GetAttachedChildren()
        
        local t = 0
        while t < 1 do
            t = math.min(1, t + DeltaTime())
            entity:SetDissolve(1.0 - t)
            
            for i=1,#a do
                a[i]:SetDissolve(1.0 - t)
                a[i]:Enable()
            end
            
            Sleep(0)
        end
        
    end
end

function HideMemoryDecos(cinematic)
    local sUnlitAtten = Symbol("UnlitAtten")
    local entity = gRegion:FindFirstTagged(cinematicTag)
    if not IsNull(entity) then
        local t = 1
        
        local a = entity:GetAttachedChildren()
        
        while t > 0 do
            t = math.max(0, t - DeltaTime())
            entity:SetDissolve(1.0 - t)
            
            for i=1,#a do
                a[i]:SetMaterialParam(sUnlitAtten, t)
            end
            
            Sleep(0)
        end
        entity:SetVisibility(false, true)
    end
end

-- need this in order for Transmission system to shutdown while a cinematic loop is playing...
function NeewaImages(cinematic)
    local minTime = 17.0
    local startTime = Time()
    Sleep(2.0)
    while not IsNull(cinematic) and not IsNull(_T.TransmissionSoundInstance) do
        Sleep(0)
    end
    local curTime = Time()
    Sleep(math.max(0, minTime - (curTime - startTime)))
    Sleep(2.0)
    cinematic:Stop()
end

function EidolonEmerge(cinematic)
    local region = cinematic:GetRegionMgr()
    local postProcess = region:GetLevelInfo():GetPostProcessBias()
    local mainPostProcess = region:GetLevelInfo().postProcess

    mainPostProcess:SetRadialBlurScale(0.5,0.5)
    postProcess.radialBlurStrength = 1.0
    
    local t = 0.0
    while t < 1.0 do
        t = Clamp(t + DeltaTime() * 0.25, 0, 1)
        local v = math.abs(t * 2 - 1)
        postProcess.radialBlurStrength = 1.0 - v
        Sleep(0)
    end
end

function EidolonStep(cinematic)
    local region = cinematic:GetRegionMgr()
    local postProcess = region:GetLevelInfo():GetPostProcessBias()

    postProcess:SetRadialBlurScale(0.15,0.15)
    postProcess.radialBlurStrength = 1.0
    
    local t = 0.0
    while t < 1.0 do
        t = Clamp(t + DeltaTime() * 0.5, 0, 1)
        postProcess.radialBlurStrength = 1.0 - t
        Sleep(0)
    end
end

function VocalEmissiveAtten(cinematic)
    Sleep(0)
    
    local sNpcCinematicDecoNoSing = Symbol("NpcCinematicDecoNoSing")
    local skelMeshType = WeakResource("/EE/Types/GraphicsRes/SkeletalMesh")
    local allDecos = gRegion:FindAll(gDecorationType)
    local greenRoomEntities = {}
    for i=1,#allDecos do
        local mesh = allDecos[i]:GetMesh()
        if not IsNull(mesh) and mesh:IsA(skelMeshType) and not allDecos[i]:HasTag(sNpcCinematicDecoNoSing) then
            greenRoomEntities[#greenRoomEntities + 1] = allDecos[i]
        end
    end

    local emissiveMapAtten = Symbol("EmissiveMapAtten")
    --greenRoomEntities = cinematic:GetGreenRoomEntities()
    local vocalSoundInstance = cinematic:GetSoundInstanceByTag(Symbol("Vocals"))
    while not IsNull(cinematic) and not IsNull(vocalSoundInstance) do
       local amp = vocalSoundInstance:GetCurAmplitude()
       amp = amp * amp
       local t = Lerp(0.0, 10, amp)
       for i=1,#greenRoomEntities do
            local entity = greenRoomEntities[i]
            if not IsNull(entity) then
                entity:SetMaterialParam(emissiveMapAtten, t, 0, 0, 0)
            end
       end
       Sleep(0)
    end

    for i=1,#greenRoomEntities do
        local entity = greenRoomEntities[i]
        if not IsNull(entity) then
            entity:SetMaterialParam(emissiveMapAtten, 1.0)
        end
    end
end

function TextOverlay()
    local movie = gFlashMgr:PushMovie(textMovie)
    if not IsNull(movie) then
        movie:Execute("NewWarIntro", textOverlayTag)
    end
end
