triggerType = Type()
hitProxyType = Type()
swellTime = 2
maxSize = .25
attachOffset = Vector()
droneFaction = Symbol()

function OnCreate(projectile)
    Sleep(0)    -- Unfortunately we need to sleep for a frame because the instigator isn't set yet :(

    projectile:AttachTo(projectile:GetInstigator(), Symbol("GAME_C1_TAIL5"))

    local hitProxy = projectile:Attach(hitProxyType, EMPTY_SYMBOL)

    local startSize = projectile:GetMeshScale()

    projectile:SetAttachLocalSpace(attachOffset + attachOffset * startSize, Rotation())

    local t = 0
    while t < swellTime and not IsNull(projectile) do
        local parent = projectile:GetAttachParent()

        if IsNull(parent) then
            -- Parent died, stop growin', start fallin'. Set DamageMultiplier of projectile based on how big it got
            projectile:SetDamageMultiplier(t / swellTime)
            break
        end

        local newSize = Lerp(startSize, maxSize, t / swellTime)

        projectile:SetMeshScale(newSize)
        projectile:SetAttachLocalSpace(attachOffset + attachOffset * newSize, Rotation())       -- Could potentially do some cool rotation thing here

        Sleep(0)
        t = t + DeltaTime()
    end

    if not IsNull(projectile) then
        if t >= swellTime then
            projectile:SetMeshScale(maxSize)
        end

        --Unattach and set kinematic velocity so the projectile will fall
        projectile:SetInitialIgnoreAvatar(projectile:GetInstigator())
        projectile:Unattach()
        projectile:SetKinematicVelocity(Vector(0, -.2, 0))
    end
end

function OnEmbed(projectile)
    if gRegion:IsMaster() then
        local attachParent = projectile:GetAttachParent()
        local instigatorFaction = projectile:GetInstigatorFaction()
        if not IsNull(attachParent) and attachParent:IsA(gAvatarType) and not attachParent:IsFactionFriendly(instigatorFaction) then
            --Embeded on an enemy, don't need to make trigger, just explode now!
            projectile:Destroy()
        else
            local trigger = projectile:Attach(triggerType, EMPTY_SYMBOL)

            ObjectPortHandler(trigger, "OnTouched")
        end
    end
end

function OnTouched(trigger)
    if not IsNull(trigger) and not IsNull(trigger:GetAttachParent()) then
        local proj = trigger:GetAttachParent()
        local touching = trigger:GetEntitiesTouching()
        local instigatorFaction = droneFaction
        if not IsNull(proj) then
            instigatorFaction = proj:GetInstigatorFaction()
        end
        for i = 1, #touching do
            if not IsNull(touching[i]) and (touching[i]:IsA(gAvatarType)) and not touching[i]:IsFactionFriendly(instigatorFaction) then
                trigger:GetAttachParent():Destroy() -- Destroy the parent projectile
                break
            end
        end
    end
end