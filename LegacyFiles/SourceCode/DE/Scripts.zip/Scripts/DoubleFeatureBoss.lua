VIPs = {Type()}
DropTables = {Resource()}
hyenaMarker = Type()
transDelay = 5
giveObjTransmission = Type()
deathTransmission = Type()
SpawnRange = 30
giveDeathMark = true
backupDelay = 10
bossMarkerType = Type()
bossMarkerOffset = Vector(0,0.5,0)
attachBossMarker = false

meleeAvatar = WeakResource()
sniperAvatar = WeakResource()
meleeSpawnAnim = Resource()
sniperSpawnAnim = Resource()
spawnInEffectMelee = Type()
spawnInEffectSniper = Type()

local NV_INDEX_SPAWNED_MULTIBOSS    = Symbol("SpawnedMultiBoss")
local NV_INDEX_NUM_BOSSES_ALIVE     = Symbol("MBossesAlive")

local function GiveTransmission(trans)
    if IsNull(trans) then
        return
    end
    local players = gRegion:GetHumanPlayers()
    if not IsNull(players) then
        for x = 1, #players do
            local avatar = players[x]:GetAvatar()
            if not IsNull(avatar) then
                avatar:GiveItem(trans, true)
            end
        end
    end
end

local function SetupBossAgents(aiDir, agent, it)
    local av = agent:GetAvatar()
    _T["MultiBossAvatars"][it] = av
    av:OverrideDisarmAction(Lotus_Game.LotusNpcAvatar_DA_DAMAGE_ONLY)
    av:SetIsVIP()
    if giveDeathMark then
        av:SetDeathMarkChance(1) -- default Vor has chance 0 so we don't hurt new players
    end

    if it <= #DropTables then
        av:SetDropTable(DropTables[it])
    end
    
    if attachBossMarker then
        av:Attach(bossMarkerType, Symbol("GAME_C1_SPINE1"), bossMarkerOffset)
    end
    
    return av
end

function SpawnBosses(avatar)
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()

    if IsNull(avatar) or IsNull(aiDir) then
        return
    end
    
    avatar:AddInvisibilityRequest()
    
    local markers = avatar:GetAllAttachments(bossMarkerType) -- Remove marker from invisible avatar
    for i, att in ipairs(markers) do
        att:Destroy()
    end
    
    local liveAvatars = {}
    _T["MultiBossAvatars"] = {}
    local validFallbackAvatar = nil
    
    if gGameRules:GetNetPersistentVar(NV_INDEX_SPAWNED_MULTIBOSS) == 0 then
        local spawnPoints = gRegion:FindAll(gNpcSpawnPointType, avatar:GetPosition(), 0, SpawnRange)
        local invalidTag = Symbol("DoNotUse")
        local x = 1
        while x <= #spawnPoints do
            if IsNull(spawnPoints[x]) or spawnPoints[x]:GetTag() == invalidTag then
                table.remove(spawnPoints, x)
            else
                x = x + 1
            end
        end
    
        if #spawnPoints == 0 then
            avatar:SetHealth(0)
        else
            local numAgents = 0
            for i = 1, #VIPs do
                local sp = spawnPoints[RandomInt(1, #spawnPoints)]
                local agent = aiDir:CreateAgent(VIPs[i], sp)
            
                if not IsNull(agent) and not IsNull(agent:GetAvatar()) then
                    validFallbackAvatar = agent:GetAvatar()
                    numAgents  = numAgents + 1
                    liveAvatars[numAgents] = SetupBossAgents(aiDir, agent, i)
                end
            end
        end
        
        --Fallback; if not all bosses spawned, something's probably up with the spawnpoints
        --First, check if we have no bosses at all (a HUGE problem) and spawn it around the player as last resort
        if validFallbackAvatar == nil then
            local localPlayers = gRegion:GetHumanPlayers()
            if #localPlayers > 0 then
                local player = localPlayers[RandomInt(1, #localPlayers)]
                
                if player ~= nil then
                    local playerav = player:GetAvatar()
                    local agent = aiDir:CreateAgentNearEntity(VIPs[1], playerav, 10, Symbol(), aiDir:GetMaxEnemyLevel())
                    if not IsNull(agent) and not IsNull(agent:GetAvatar()) then
                        validFallbackAvatar = agent:GetAvatar()
                        liveAvatars[1] = SetupBossAgents(aiDir, agent, 1)
                    end
                end
            end
        end
        
        --If we have 'a' boss then try to spawn all the missing bosses around it
        if validFallbackAvatar ~= nil then
            local numAgents = 0
            for i = 1, #VIPs do
                if _T["MultiBossAvatars"][i] == nil then
                    local agent = aiDir:CreateAgentNearEntity(VIPs[i], validFallbackAvatar, 10, validFallbackAvatar:GetFaction(), aiDir:GetMaxEnemyLevel())
                    if not IsNull(agent) and not IsNull(agent:GetAvatar()) then
                        validFallbackAvatar = agent:GetAvatar()
                        numAgents  = numAgents + 1
                        liveAvatars[numAgents] = SetupBossAgents(aiDir, agent, i)
                    end
                else
                    numAgents  = numAgents + 1
                end
            end
        end
        
        gGameRules:SetNetPersistentVar(NV_INDEX_SPAWNED_MULTIBOSS, 1)
    end
    
    while not IsNull(avatar) and not avatar:IsKilled() do
        local numLiveAgents = 0
        for i = 1, #liveAvatars do
            if not IsNull(liveAvatars[i]) and not liveAvatars[i]:IsKilled() then -- liveAvatars[i]:GetHealth() > 0 then
                numLiveAgents = numLiveAgents + 1
            end
        end
        if numLiveAgents == 0 then
            print("         multibosses killed, killing proxy avatar")
            --we've killed all VIPs
            avatar:DamageEx(avatar:GetMaxHealth() + 1, Engine.DT_SUICIDE, Engine.TORSO, 0, avatar, avatar)
        end
        Sleep(0)
    end
    
    _T["MultiBossAvatars"] = nil
    print("done")
end


local function SetupJetpackBossAgents(aiDir, agent, it)
        agent:SetAlert()
        local av = agent:GetAvatar()
        av:SetVisibility(false)
        _T["MultiBossAvatars"][it] = av
        av:OverrideDisarmAction(Lotus_Game.LotusNpcAvatar_DA_DAMAGE_ONLY)
        av:SetIsVIP()

        if av:IsA(meleeAvatar) then
            if not IsNull(meleeSpawnAnim) then
                av:PlayNonReplicatedAnimation(meleeSpawnAnim, false, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_ONCE, true)
                av:Attach(spawnInEffectMelee, EMPTY_SYMBOL)
                Sleep(0.3)
                av:SetVisibility(true)
            end
        elseif av:IsA(sniperAvatar) then
            if not IsNull(sniperSpawnAnim) then
                av:PlayNonReplicatedAnimation(sniperSpawnAnim, false, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_ONCE, true)
                av:Attach(spawnInEffectSniper, EMPTY_SYMBOL)
                Sleep(0.3)
                av:SetVisibility(true)
            end
        end
        if giveDeathMark then
            av:SetDeathMarkChance(1) -- default Vor has chance 0 so we don't hurt new players
        end
    
        if  it <= #DropTables then
            av:SetDropTable(DropTables[it])
        end
        
        return av
end

function SpawnJetpackBosses(avatar)
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()

    if IsNull(avatar) or IsNull(aiDir) then
        return
    end
    
    avatar:AddInvisibilityRequest()
    
    local liveAvatars = {}
    _T["MultiBossAvatars"] = {}
    local validFallbackAvatar = nil
    
    if gGameRules:GetNetPersistentVar(NV_INDEX_SPAWNED_MULTIBOSS) == 0 then
        local spawnPoints = gRegion:FindAll(gNpcSpawnPointType, avatar:GetPosition(), 0, SpawnRange)
        local invalidTag = Symbol("DoNotUse")
        local x = 1
        while x <= #spawnPoints do
            if IsNull(spawnPoints[x]) or spawnPoints[x]:GetTag() == invalidTag then
                table.remove(spawnPoints, x)
            else
                x = x + 1
            end
        end
        
        if #spawnPoints == 0 then
            avatar:SetHealth(0)
        else
            local numAgents = 0
            for i = 1, #VIPs do
                local sp = spawnPoints[RandomInt(1, #spawnPoints)]
                local prevSp
                
                if #spawnPoints > 1 then
                    while sp == prevSp do
                        sp = spawnPoints[RandomInt(1, #spawnPoints)]
                    end
                else
                    Sleep(1) --Reuse spawn point for now. Don't know if we'll ever get here, but check anyway
                end
                
                local agent = aiDir:CreateAgent(VIPs[i], sp)
            
                if not IsNull(agent) and not IsNull(agent:GetAvatar()) then
                    validFallbackAvatar = agent:GetAvatar()
                    numAgents  = numAgents + 1
                    liveAvatars[numAgents] = SetupJetpackBossAgents(aiDir, agent, i)
                end
                prevSp = sp
            end
        end

        Sleep(1)
        
        --Fallback; if not all bosses spawned, something's probably up with the spawnpoints
        --First, check if we have no bosses at all (a HUGE problem) and spawn it around the player as last resort
        if validFallbackAvatar == nil then
            local localPlayers = gRegion:GetHumanPlayers()
            if #localPlayers > 0 then
                local player = localPlayers[RandomInt(1, #localPlayers)]
                
                if player ~= nil then
                    local playerav = player:GetAvatar()
                    local agent = aiDir:CreateAgentNearEntity(VIPs[1], playerav, 10, Symbol(), aiDir:GetMaxEnemyLevel())
                    if not IsNull(agent) and not IsNull(agent:GetAvatar()) then
                        validFallbackAvatar = agent:GetAvatar()
                        liveAvatars[1] = SetupJetpackBossAgents(aiDir, agent, 1)
                    end
                end
            end
        end
        
        --If we have 'a' boss then try to spawn all the missing bosses around it
        if validFallbackAvatar ~= nil then
            local numAgents = 0
            for i = 1, #VIPs do
                if _T["MultiBossAvatars"][i] == nil then
                    local agent = aiDir:CreateAgentNearEntity(VIPs[i], validFallbackAvatar, 10, validFallbackAvatar:GetFaction(), aiDir:GetMaxEnemyLevel())
                    if not IsNull(agent) and not IsNull(agent:GetAvatar()) then
                        validFallbackAvatar = agent:GetAvatar()
                        numAgents  = numAgents + 1
                        liveAvatars[numAgents] = SetupJetpackBossAgents(aiDir, agent, i)
                    end
                else
                    numAgents  = numAgents + 1
                end
            end
        end
        
        gGameRules:SetNetPersistentVar(NV_INDEX_SPAWNED_MULTIBOSS, 1)
    end
    
    while not IsNull(avatar) and not avatar:IsKilled() do
        local numLiveAgents = 0
        for i = 1, #liveAvatars do
            if not IsNull(liveAvatars[i]) and not liveAvatars[i]:IsKilled() then -- liveAvatars[i]:GetHealth() > 0 then
                numLiveAgents = numLiveAgents + 1
            end
        end
        if numLiveAgents == 0 then
            print("         multibosses killed, killing proxy avatar")
            --we've killed all VIPs
            avatar:DamageEx(avatar:GetMaxHealth() + 1, Engine.DT_SUICIDE, Engine.TORSO, 0, avatar, avatar)
        end
        Sleep(0)
    end
    
    _T["MultiBossAvatars"] = nil
    print("done")
end

local function _DisableMarkers(objectiveMarkInst)
    local markersToReEnable = {}
    for i=1, #objectiveMarkInst do 
        if objectiveMarkInst[i]:IsA(gBaseMarkerInfoType) and objectiveMarkInst[i]:IsEnabled() then
            table.insert(markersToReEnable, objectiveMarkInst[i])
            objectiveMarkInst[i]:Disable()
        end
    end

    return markersToReEnable
end

function SpawnHyenaBosses(avatar)
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()
    local humanPlayers = gRegion:GetHumanPlayers()
    local hyenas = {}
    local potHyenas = VIPs
    local num = 0

    local sDoNotUse = Symbol("DoNotUse")
    
    if #humanPlayers == 1 then
        for i = 1, 2 do
            num = math.random(1,#potHyenas)
            table.insert(hyenas, potHyenas[num])
            table.remove(potHyenas, num)
        end
    else
        for i = 1, #humanPlayers do
            num = math.random(1,#potHyenas)
            table.insert(hyenas, potHyenas[num])
            table.remove(potHyenas, num)
        end
    end

    if IsNull(avatar) or IsNull(aiDir) then
        return
    end
    
    avatar:AddInvisibilityRequest()
    
    local liveAvatars = {}
    _T["MultiBossAvatars"] = {}
    local spawnerNum = 0
    
    
    local setupAlreadyDone = gGameRules:GetNetPersistentVar(NV_INDEX_SPAWNED_MULTIBOSS) ~= 0
    if not setupAlreadyDone then
        local spawnPoints = gRegion:FindAllExcludingTagged(gNpcSpawnPointType, avatar:GetPosition(), 0, SpawnRange, sDoNotUse)
        
        if #spawnPoints == 0 then
            avatar:SetHealth(0)
        else
            local numAgents = 0
            for i = 1, #hyenas do
                
                spawnerNum = math.random(1, #spawnPoints)
                local sp = spawnPoints[spawnerNum]
                table.remove(spawnPoints, spawnerNum)
                local agent = aiDir:CreateAgent(hyenas[i], sp)
            
                if not IsNull(agent) and not IsNull(agent:GetAvatar()) then
                    numAgents  = numAgents + 1
                    local av = agent:GetAvatar()
                    liveAvatars[numAgents] = av
                    _T["MultiBossAvatars"][i] = av
                    av:OverrideDisarmAction(Lotus_Game.LotusNpcAvatar_DA_DAMAGE_ONLY)
                    av:SetIsVIP()
                    av:Attach(hyenaMarker, Symbol("GAME_C1_SPINE2"), Vector(0, 0.5, 0))

                end
            end
            gGameRules:SetNetPersistentVar(NV_INDEX_NUM_BOSSES_ALIVE, numAgents)            
        end
        
        gGameRules:SetNetPersistentVar(NV_INDEX_SPAWNED_MULTIBOSS, 1)
    else
        local numLiveBosses = gGameRules:GetNetPersistentVar(NV_INDEX_NUM_BOSSES_ALIVE)

        if numLiveBosses > 0 then

            -- Need to find spawned bosses, scan all spawnpoints in vicinity.
            local spawnPoints = gRegion:FindAllExcludingTagged(gNpcSpawnPointType, avatar:GetPosition(), 0, SpawnRange, sDoNotUse)
            local numSpawned = 0;

            print("Waiting for "..tostring(numLiveBosses).." to spawn")
            print("Types: "..tostring(#VIPs))

            while (numSpawned < numLiveBosses) do
                numSpawned = 0
                for x = 1, #spawnPoints do
                    if not IsNull(spawnPoints[x]) and not IsNull(spawnPoints[x]:GetActiveAvatar()) then

                        if spawnPoints[x]:GetActiveAvatar() ~= avatar then
                            numSpawned = numSpawned + 1
                        end
                    end
                end

                Sleep(0.1)
            end

            print("Done, bosses spawned")

            numSpawned = 1 -- Lua indexing
            for x = 1, #spawnPoints do
                if not IsNull(spawnPoints[x]) and not IsNull(spawnPoints[x]:GetActiveAvatar()) then
                    local av = spawnPoints[x]:GetActiveAvatar()

                    if av ~= avatar then
                        liveAvatars[numSpawned] = av
                        _T["MultiBossAvatars"][numSpawned] = av

                        av:OverrideDisarmAction(Lotus_Game.LotusNpcAvatar_DA_DAMAGE_ONLY)
                        av:Attach(hyenaMarker, Symbol("GAME_C1_SPINE2"), Vector(0, 0.5, 0))
                        av:SetIsVIP()

                        numSpawned = numSpawned + 1
                        print("Adding live avatar")
                    end
                end
            end

        end

    end
    
    local agentsTracked = 0

    local objectiveMarkInst = gRegion:FindTagged(Symbol("ObjectiveMarker"))    
    local markersToReEnable = _DisableMarkers(objectiveMarkInst)
    -- After migration, this script runs before enabling objective markers, so we have to keep trying to 
    -- disable them if we have any bosses around
    local retryToDisableMarkers = setupAlreadyDone and #markersToReEnable == 0 and #liveAvatars > 0

    if not setupAlreadyDone then
        Sleep(transDelay)
        GiveTransmission(giveObjTransmission)
    end
    
    while not IsNull(avatar) and not avatar:IsKilled() do

        if retryToDisableMarkers then
            markersToReEnable = _DisableMarkers(objectiveMarkInst)

            if #markersToReEnable > 0 then
                retryToDisableMarkers = false
            end
        end

        local numLiveAgents = 0
        for i = 1, #liveAvatars do
            if not IsNull(liveAvatars[i]) and not liveAvatars[i]:IsKilled() then -- liveAvatars[i]:GetHealth() > 0 then
                numLiveAgents = numLiveAgents + 1
            end
        end
        gGameRules:SetNetPersistentVar(NV_INDEX_NUM_BOSSES_ALIVE, numLiveAgents)

        if numLiveAgents < agentsTracked and numLiveAgents > 0 then
            GiveTransmission(deathTransmission)
        end

        agentsTracked = numLiveAgents

        if numLiveAgents == 0 then
            print("VIPs killed")

            --we've killed all VIPs
            avatar:DamageEx(avatar:GetMaxHealth() + 1, Engine.DT_SUICIDE, Engine.TORSO, 0, avatar, avatar)
            for i=1, #markersToReEnable do 
                if not IsNull(markersToReEnable[i]) then
                    markersToReEnable[i]:Enable()
                end
            end

        end
        Sleep(0)
    end
    
    _T["MultiBossAvatars"] = nil
    print("done")
end

function SpawnHekDroneSquad(avatar)
    local npcManager = gRegion:GetNpcMgr()
    local aiDir = npcManager:GetAiDirector()

    local sDoNotUse = Symbol("DoNotUse")
    
    if IsNull(avatar) or IsNull(aiDir) then
        return
    end
    
    avatar:AddInvisibilityRequest()
    
    local liveAvatars = {}
    _T["MultiBossAvatars"] = {}
    local spawnerNum = 0
    
    
    local setupAlreadyDone = gGameRules:GetNetPersistentVar(NV_INDEX_SPAWNED_MULTIBOSS) ~= 0
    if not setupAlreadyDone then
        local spawnPoints = gRegion:FindAllExcludingTagged(gNpcSpawnPointType, avatar:GetPosition(), 0, SpawnRange, sDoNotUse)
        
        if #spawnPoints == 0 then
            avatar:SetHealth(0)
        else
            local numAgents = 0
            for i = 1, #VIPs do
                if i == 2 then
                    Sleep(backupDelay)
                end
                
                spawnerNum = math.random(1, #spawnPoints)
                local sp = spawnPoints[spawnerNum]
                table.remove(spawnPoints, spawnerNum)
                local agent = aiDir:CreateAgent(VIPs[i], sp)
            
                if not IsNull(agent) and not IsNull(agent:GetAvatar()) then
                    numAgents  = numAgents + 1
                    local av = agent:GetAvatar()
                    liveAvatars[numAgents] = av
                    _T["MultiBossAvatars"][i] = av
                    av:OverrideDisarmAction(Lotus_Game.LotusNpcAvatar_DA_DAMAGE_ONLY)
                    av:SetIsVIP()
                    --av:Attach(hyenaMarker, Symbol("GAME_C1_SPINE2"), Vector(0, 0.5, 0))
                    
                    if av:IsA(meleeAvatar) then
                        if not IsNull(meleeSpawnAnim) then
                            av:PlayNonReplicatedAnimation(meleeSpawnAnim, false, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_ONCE, true)
                            av:Attach(spawnInEffectMelee, EMPTY_SYMBOL)
                            Sleep(0.3)
                            av:SetVisibility(true)
                        end
                    elseif av:IsA(sniperAvatar) then
                        if not IsNull(sniperSpawnAnim) then
                            av:PlayNonReplicatedAnimation(sniperSpawnAnim, false, Engine.ATMM_ANIMATION_DRIVEN, Engine.PRT_ONCE, true)
                            av:Attach(spawnInEffectSniper, EMPTY_SYMBOL)
                            Sleep(0.3)
                            av:SetVisibility(true)
                        end
                    end
                    
                    if giveDeathMark then
                        av:SetDeathMarkChance(1) -- default Vor has chance 0 so we don't hurt new players
                    end
                end
            end
            gGameRules:SetNetPersistentVar(NV_INDEX_NUM_BOSSES_ALIVE, numAgents)            
        end
        
        gGameRules:SetNetPersistentVar(NV_INDEX_SPAWNED_MULTIBOSS, 1)
    else
        local numLiveBosses = gGameRules:GetNetPersistentVar(NV_INDEX_NUM_BOSSES_ALIVE)

        if numLiveBosses > 0 then

            -- Need to find spawned bosses, scan all spawnpoints in vicinity.
            local spawnPoints = gRegion:FindAllExcludingTagged(gNpcSpawnPointType, avatar:GetPosition(), 0, SpawnRange, sDoNotUse)
            local numSpawned = 0;

            print("Waiting for "..tostring(numLiveBosses).." to spawn")
            print("Types: "..tostring(#VIPs))

            while (numSpawned < numLiveBosses) do
                numSpawned = 0
                for x = 1, #spawnPoints do
                    if not IsNull(spawnPoints[x]) and not IsNull(spawnPoints[x]:GetActiveAvatar()) then

                        if spawnPoints[x]:GetActiveAvatar() ~= avatar then
                            numSpawned = numSpawned + 1
                        end
                    end
                end

                Sleep(0.1)
            end

            print("Done, bosses spawned")

            numSpawned = 1 -- Lua indexing
            for x = 1, #spawnPoints do
                if not IsNull(spawnPoints[x]) and not IsNull(spawnPoints[x]:GetActiveAvatar()) then
                    local av = spawnPoints[x]:GetActiveAvatar()

                    if av ~= avatar then
                        liveAvatars[numSpawned] = av
                        _T["MultiBossAvatars"][numSpawned] = av

                        av:OverrideDisarmAction(Lotus_Game.LotusNpcAvatar_DA_DAMAGE_ONLY)
                        --av:Attach(hyenaMarker, Symbol("GAME_C1_SPINE2"), Vector(0, 0.5, 0))
                        av:SetIsVIP()

                        numSpawned = numSpawned + 1
                        print("Adding live avatar")
                    end
                end
            end

        end

    end
    
    local agentsTracked = 0


    if not setupAlreadyDone then
        Sleep(transDelay)
        GiveTransmission(giveObjTransmission)
    end
    
    while not IsNull(avatar) and not avatar:IsKilled() do

        local numLiveAgents = 0
        for i = 1, #liveAvatars do
            if not IsNull(liveAvatars[i]) and not liveAvatars[i]:IsKilled() then -- liveAvatars[i]:GetHealth() > 0 then
                numLiveAgents = numLiveAgents + 1
            end
        end
        gGameRules:SetNetPersistentVar(NV_INDEX_NUM_BOSSES_ALIVE, numLiveAgents)

        agentsTracked = numLiveAgents

        if numLiveAgents == 0 then
            print("VIPs killed")

            --we've killed all VIPs
            avatar:DamageEx(avatar:GetMaxHealth() + 1, Engine.DT_SUICIDE, Engine.TORSO, 0, avatar, avatar)

        end
        Sleep(0)
    end
    
    _T["MultiBossAvatars"] = nil
    print("done")
end
