local UTIL = require "EE.Interface.Utilities"


-- Copy-pasted from UICommonResources.lua
-- TODO: Eliminate duplication
local function InitColors(tableName)
    -- #### COLOR ####
    tableName.UIColor_LightBlue = 0xC2D8D9
    tableName.UIColor_MediumBlue = 0x7B98A6
    tableName.UIColor_DarkBlue = 0x45606D
    tableName.UIColor_MediumGrey = 0x808080
    tableName.UIColor_DarkGrey = 0x242424
    tableName.UIColor_Yellow = 0xE8D55D
    tableName.UIColor_Orange = 0xCD7C01
    tableName.UIColor_Gold = 0xFFCC00
    tableName.UIColor_Health = 0xcc2929
    tableName.UIColor_Shield = 0x00d5ff
    tableName.UIColor_Overshield = 0xb300ff
    tableName.UIColor_Stamina = 0x44b357
    tableName.UIColor_Armor = 0xDEA635
    tableName.UIColor_Red = 0xc80406
    tableName.UIColor_Green = 0x8de426
    tableName.UIColor_LightGreen = 0xB8E880
    tableName.UIColor_White = 0xEFEFEF
    tableName.UIColor_Black = 0x000000
    tableName.UIColor_PositiveReputation = 0x4cc3ff
    tableName.UIColor_NegativeReputation = 0xff4c4c
    tableName.UIColor_OpposedReputation = 0xeec400
    tableName.UIColor_PvpTeamOne = 0xe58f39
    tableName.UIColor_PvpTeamTwo = 0x2dc8e0
    tableName.UIColor_PvpKill = 0xf34e14
    tableName.UIColor_Hyperlink = 0x33CCFF
    tableName.UIColorObject_White = UTIL.ConvertColorNumberToProceduralRGB(tableName.UIColor_White)
    tableName.UIColorObject_Black = UTIL.ConvertColorNumberToProceduralRGB(tableName.UIColor_Black)
    tableName.UIColorObject_Yellow = UTIL.ConvertColorNumberToProceduralRGB(tableName.UIColor_Yellow)
    tableName.UIColorObject_DarkBlue = UTIL.ConvertColorNumberToProceduralRGB(tableName.UIColor_DarkBlue)
end
 
-- Stubs for HUD functions (dedicated server == no HUD)
function DedicatedServerInit()
    _T.InitializeTerritoryHUDElements = function(...) end
    _T.UpdateTerritoryProgress = function(...) end
    _T.UpdateTerritoryScores = function(...)  end
    _T.HideTerritoryHUDElements = function(...)  end
    
    _T.InitializePvpHUDElements = function(...) end
    _T.UpdatePvpXP = function(...)  end
    
    _T.ShowWeaponPanel = function(...) end
    _T.HideWeaponPanel = function(...) end
    _T.ShowAbilityPanel = function(...) end
    _T.HideAbilityPanel = function(...) end
    
    _T.SetAbilityTimer = function(...) end
    _T.AddAbilityTimer = function(...) end
    _T.SetFocusTimer = function(...) end

    _T.AddLogMessage = function(...) end
    _T.AddPvpKillMessage = function(...) end

    _T.ShowImpactMessage = function(...) end
    _T.HideImpactMessage = function(...) end

    InitColors(_T)
    InitColors(_G)
end
