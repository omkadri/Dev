flashMovie = Resource()
entityToAttachTo = Instance()
offset = Vector()
offsetRotation = Rotation()
scale = Vector(1,1,1)

function AttachMovie(entity)
    if IsNull(entityToAttachTo) then
        entityToAttachTo = entity
    end

    if IsNull(flashMovie) or IsNull(entityToAttachTo) then
        return
    end
    
    local movie = gFlashMgr:PushMovie(flashMovie)
    if not IsNull(movie) then
        movie:AttachToEntity(entityToAttachTo, offset, offsetRotation, scale)
        movie:SetInstigator(entityToAttachTo)
    end
end
