pickupEffects = {Type()}

local UTIL = require "EE.Interface.Utilities"
local COLOR_UTIL = require "Lotus.Scripts.Effects.EffectsColorUtilities"
local fxOffset = Vector(0, 0.3, 0)

function InitDrop(drop)
    local research = drop:GetSourcePlayer():GetActiveDojoColorResearch()    
    if not IsNull(research) and #(research:GetDropAvatars()) > 0 then
        drop:SetDropAvatarTypes(research:GetDropAvatars())
        drop:SetDropChance(research:GetDropChance())
    end
end

function MissionCheck(drop)
    return not IsNull(drop:GetSourcePlayer():GetActiveDojoColorResearch())
end

function ShouldDropForPlayer(drop, player)
    local sourcePlayer = drop:GetSourcePlayer()
    if (player == sourcePlayer) then
        return true
    else
        local research = player:GetActiveDojoColorResearch()
        return (not IsNull(research) and research == sourcePlayer:GetActiveDojoColorResearch())
    end
end

function CustomizePickUpAppearance(pickup)
    local player = nil
    
    if IsNull(pickup:GetCreator()) then
        local avatar = gRegion:GetLocalPlayerAvatar()
        if not IsNull(avatar) then
            player = avatar:GetPlayer()
        end
    else
        player = pickup:GetCreator()
    end
    
    if not IsNull(player) then
        local research = player:GetActiveDojoColorResearch()
        if not IsNull(research) then
            local numToGive = research:GetDropBundleSize()

            -- Resource boosters normally apply when the player picks them up, but since
            -- pigment drops aren't autonomous, we need to apply them to the contained amount.
            local validType = WeakResource("/Lotus/Types/Items/MiscItems/ResourceItem")
            numToGive = player:GetAvatar():InventoryControl():GetUpgradeModifiedValue(numToGive, Game.GAMEPLAY_PICKUP_AMOUNT, validType, nil)
            -- Also, since pigments are set up to be 100% drops from some targets, to make drop
            -- chance boosters effective we just apply them to the amounts.
            numToGive = player:GetAvatar():InventoryControl():GetUpgradeModifiedValue(numToGive, Game.GAMEPLAY_PICKUP_RATE, validType, nil)
            numToGive = UTIL.Round(numToGive)

            pickup:SetNumToGive(numToGive)
        
            local color = research:GetColor()
            pickup:SetMaterialParam(Lotus_Game.EMISSIVE_TINT_COLOR, COLOR_UTIL.SRGBToLinear(color.red), COLOR_UTIL.SRGBToLinear(color.green), COLOR_UTIL.SRGBToLinear(color.blue), 1)
            color.alpha = 255 -- Just in case
            for i=1, #pickupEffects do
                local temp = pickup:Attach(pickupEffects[i], EMPTY_SYMBOL, fxOffset)
                if not IsNull(temp) then
                    if temp:IsA(gLensFlareType) then
                        temp:SetTint(color)
                    elseif temp:IsA(gParticleSysType) then
                        temp:SetColorMinMax(color, color)
                        COLOR_UTIL.ApplyHighLow(temp, color)
                    end
                end
            end
        end
    end
end

function PickedUpEffects(player, item, position)
    if IsNull(player) then
        return
    end
    local research = player:GetActiveDojoColorResearch()
    if not IsNull(research) then
        local color = research:GetColor()
        color.alpha = 255 -- Just in case
        local avatar = player:GetAvatar()
        local pos = position
        if IsNull(pos) then
            pos = avatar:GetCenter()
        end
        for i=1, #pickupEffects do
            local temp = gRegion:CreateEntity(pickupEffects[i], pos, ZERO_ROTATION)
            if not IsNull(temp) then
                if temp:IsA(gLensFlareType) then
                    temp:SetTint(color)
                elseif temp:IsA(gParticleSysType) then
                    temp:SetColorMinMax(color, color)
                    COLOR_UTIL.ApplyHighLow(temp, color)
                end
            end
        end
    end
end
