transmissionHoldPosition = Type()
timeToHoldPosition = 30
transmissionCompleted = Type()

--Timer stuff below

timerMessage = Symbol()
expiryPortTrigger = Instance()
expiryPortCommand = Symbol()
expiryEndMission = false

local function GiveObjectivePrivate1() --Transmission to play when defend stage begins
    
    Sleep(1)
    
    local players = gRegion:GetHumanPlayers()
    
    if not IsNull(players) then
        for x = 1, #players do
            local avatar = players[x]:GetAvatar()
            avatar:GiveItem(transmissionHoldPosition, true)
        end
    end
end

local function GiveObjectivePrivate2() -- Transmission to play when defend stage is complete

    Sleep(1)
  
    local players = gRegion:GetHumanPlayers()
    
    if not IsNull(players) then
        for x = 1, #players do
            local avatar = players[x]:GetAvatar()
            avatar:GiveItem(transmissionCompleted, true)
        end
    end
end

local function GiveObjective1()
    GiveObjectivePrivate1()
end

local function GiveObjective2()
    GiveObjectivePrivate2()
end

function raiseBlastDoor()

GiveObjectivePrivate1() --Begin defend stage

Sleep(timeToHoldPosition) --Total time required to defend

GiveObjectivePrivate2() --Defend completed


    local DoorTags = gRegion:FindTagged(Symbol("Door")) --Open doors and switch to unlocked material version
        if not IsNull(DoorTags) then
        for x=1,#DoorTags do
            DoorTags[x]:FirePort("Open")
            DoorTags[x]:FirePort("MaterialSwitch")
        end
    end
    
    local DoorTriggerTags = gRegion:FindTagged(Symbol("DoorTrigger")) --Enable door triggers
        if not IsNull(DoorTriggerTags) then
        for x=1,#DoorTriggerTags do
            DoorTriggerTags[x]:FirePort("Enable")
        end
    end
    
    local DoorHintTags = gRegion:FindTagged(Symbol("DoorHint")) --Enable door hints
        if not IsNull(DoorHintTags) then
        for x=1,#DoorHintTags do
            DoorHintTags[x]:FirePort("OnUnlocked")
        end
    end
    
    local DoorFrameTags = gRegion:FindTagged(Symbol("DoorFrameTag")) --Switch material on doorframes to unlocked version
        if not IsNull(DoorFrameTags) then
        for x=1,#DoorFrameTags do
            DoorFrameTags[x]:FirePort("MaterialSwitch")
        end
    end
end

