function DisplayMessage(gameRules, msg, genericMsg, delay, duration, positive, argName, arg, sound)
    if IsNull(_T.ShowImpactMessage) then
        return      --we aren't ready to show messages yet
    end

    Sleep(delay)

    local argsTable = {}
    if argName ~= String() then
        local argNameList = StringSplit(",", argName)
        local argValueList = StringSplit(",", arg)
        for i = 1, #argNameList do
            argsTable[argNameList[i]] = argValueList[i]
        end    
    end

    if msg ~= "" then
        if not IsNull(sound) then
            sound = Resource(sound)
        end

        _T.ShowImpactMessage(Localize(msg, argsTable), duration, positive, sound, false)
    else
        _T.HideImpactMessage()
    end

    local playerAvatar = gRegion:GetLocalPlayerAvatar()
    while IsNull(playerAvatar) or IsNull(playerAvatar:GetPlayer()) do
        Sleep(0)
        playerAvatar = gRegion:GetLocalPlayerAvatar()
    end
    
    local player = playerAvatar:GetPlayer()
    local hudStatus = player:GetHudStatus()
    
    if IsNull(hudStatus) then
        return
    end
    
    if genericMsg ~= "" then
        hudStatus:SetGenericMessage(Localize(genericMsg, argsTable))
        Sleep(duration)
    end
    hudStatus:SetGenericMessage("")
end