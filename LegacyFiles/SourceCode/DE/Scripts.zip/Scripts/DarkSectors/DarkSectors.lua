portalEffect = Type()
initialPortalEffect = Type()
portalTriggerType = Type()
initialPortalTriggerType = Type()
avatarGlowProjector = Type("/Lotus/Fx/Gameplay/DarkSectorRifts/DarkSectorRiftPlayerGlowSpawner")
transmissionSet = Resource()

local transferDecoEffect = Type("/Lotus/Fx/Gameplay/DarkSectorRifts/DarkSectorTransferDeco")
local enemySpawnInEffect = Type("/Lotus/Fx/Gameplay/DarkSectorRifts/DarkSectorEnemySpawnIn")
local portalEnterSound = Resource("/Lotus/Sounds/Gameplay/DarkSector/DarkSectorPortalEnter")
local mixer = Resource("/EE/Sounds/Mixer/Master")
local timePickupType = Type("/Lotus/Types/Game/DarkSectors/DarkSectorTimePickup")
local teleportInputFilter = Resource("/Lotus/Types/Input/OnslaughtPortalFilter")
local rewardsMovie = Resource("/Lotus/Interface/SurvivalReward.swf")
local waveSummaryMovie = Resource("/Lotus/Interface/OnslaughtWaveSummary.swf")
local transitionPostFxMat = Resource("/Lotus/Materials/OnslaughtPost")
local defaultPostFxMat = Resource("/Lotus/Materials/LotusPost")
local endOfMatchMovie = WeakResource("/Lotus/Interface/EndOfMatch.swf")
local progressMovie = WeakResource("/Lotus/Interface/Progress.swf")

local portalOpenTransmission = Resource("/Lotus/Sounds/Dialog/SanctuaryOnslaught/DOnslaughtConduitSpawnSmrs")
local portalWarningTransmission = Resource("/Lotus/Sounds/Dialog/SanctuaryOnslaught/DOnslaughtConduitCloseSmrs")
local stabilityWarningTransmission = Resource("/Lotus/Sounds/Dialog/SanctuaryOnslaught/DOnslaughtEffTooLowSmrs")

local gearDisabledTransmission = Resource("/Lotus/Sounds/Dialog/SanctuaryOnslaught/DOnslaughtGearDisabledSmrs")
local gearDisabledSound = Resource("/Lotus/Sounds/Gameplay/DarkSector/DarkSectorGearWheelDisabled")

local UTIL = require "EE.Interface.Utilities"
local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
-- local GAMEMODE = require "Lotus.Scripts.Libs.CommonGamemodeFunctions"
local DIALOG = require "Lotus.Scripts.Libs.TransmissionSet"
local OBJTXT = require "Lotus.Scripts.Libs.ObjectiveText"

local NV_WAVE_NUMBER = Symbol("Wave")
local NV_AVERAGE_WAVE_RANK = Symbol("AvgWaveRank")
local NV_MISSION_TIMER = Symbol("MissionTimer")
local NV_NEXT_PORTAL_TIMER = Symbol("NextPortalTimer")
local NV_MISSION_SCORE = Symbol("Score")
local NV_MISSION_KILLS = Symbol("Kills")
local NV_MISSION_VIP_KILLS = Symbol("VIPKills")
local NV_LAST_WAVE_CLEARED_TIME = Symbol("LastWaveTime")
local NV_LAST_WAVE_KILLS = Symbol("LastWaveKills")
local NV_LAST_WAVE_VIP_KILLS = Symbol("LastWaveVIPKills")
local NV_LAST_WAVE_TOTAL_SCORE = Symbol("LastWaveScore")
local NV_REWARDS_GIVEN = Symbol("RewardsGiven")
local NV_WAVE_CLEAR_SCORE = Symbol("WaveClearScore")

local PLAYER_FACTION_TAG = Symbol("TENNO")

local NORMAL = 1
local HARD = 2

local DEATH_ROOM_ACTIVATION_DELAY = 3
local PORTAL_FADE_IN_DURATION = 1
local PORTAL_DURATION = 30
local PORTAL_WARNING_TIME = PORTAL_DURATION / 2
local PORTAL_AUTO_DISSOLVE_TIME = PORTAL_WARNING_TIME + (PORTAL_WARNING_TIME / 2)

local WAVE_DURATION = 2.5 * 60

local TIMER_START = WAVE_DURATION
local MAX_MISSION_TIMER = 5 * 60

local PLAYER_RANDOM_SPAWN_NEAR_WAYPOINT_DISTANCE = 5
local MAX_PORTAL_PROTECTOR_SPAWNS = 8
local PORTAL_PROTECTOR_SPAWN_RANGE = 75

local VIP_SPAWN_COOLDOWN = { 6, 20 } -- number of regular enemies to spawn in between Eximus (min, max)

local KILL_TIME_BONUS = 1
local KILL_VIP_TIME_BONUS = 5

local TIME_PICKUP_BONUS_TIME = 30
local TIME_PICKUP_SPREAD_DISTANCE = 20

local CLOCK_RATE_MULTIPLIER = {  -- clock ticks faster at higher waves
    [NORMAL] = {
        [0] = 1,
        [2] = 1.5,
        [5] = 1.75,
        [10] = 2.25,
        [13] = 3,
        [16] = 5
    },

    [HARD] = {
        [0] = 1,
        [2] = 2,
        [5] = 2.5,
        [7] = 3,
        [10] = 4,
        [15] = 6
    }
}

local NUM_TIME_PICKUPS_PER_WAVE = {
    [NORMAL] = {
        [0] = 4,
        [2] = 3,
        [5] = 2,
        [10] = 1,
        [15] = 0
    },

    [HARD] = {
        [0] = 2,
        [2] = 2,
        [5] = 2,
        [10] = 1,
        [15] = 0
    }
}

local FOCUS_BOOSTS_PER_WAVE = {
    [NORMAL] = {
        [0] = { 45, 8 }, -- duration, multiplier
        [2] = { 45, 12 },
        [5] = { 45, 14 },
        [7] = { 45, 16 }
    },

    [HARD] = {
        [0] = { 45, 10 }, -- duration, multiplier
        [2] = { 45, 15 },
        [5] = { 45, 17},
        [7] = { 45,  19},
        [12] = { 45, 25 }
    }
}

local ENEMY_LEVELS_PER_WAVE = {
    [NORMAL] = {
        [0] = { 20, 30 }, -- min, max
        [2] = { 30, 40 },
        [5] = { 50, 60 },
        [10] = { 60, 80 },
        [15] = { 80, 100 },
        [20] = { 110, 130 },
        [25] = { 130, 150 }
    },

    [HARD] = {
        [0] = { 60, 70 }, -- min, max
        [2] = { 65, 75 },
        [5] = { 75, 85 },
        [10] = { 80, 90 },
        [12] = { 120, 130 },
        [15] = { 150, 180 },
        [20] = { 200, 220 },
        [25] = { 250, 280 }
    }
}

local MAX_SIMULTANEOUS_ENEMIES_PER_WAVE = {
    [NORMAL] = {
        [0] =  { 15, 20, 20, 20 }, -- values for 1 player, 2 players, 3 players, 4 players
        [2] = { 20, 22, 22, 22 },
        [5] = { 25, 25, 25, 25 },
        [7] = { 35, 35, 35, 35 },
    },

    [HARD] = {
        [0] =  { 40, 40, 40, 40 } -- values for 1 player, 2 players, 3 players, 4 players
    }
}

local ENEMY_DAMAGE_MULT_PER_WAVE = {
    [NORMAL] = {
        [0] = 1.0,
        [2] = 1.0,
        [5] = 1.0,
        [10] = 1.0
    },

    [HARD] = {
        [0] = 1.0,
        [2] = 1.0,
        [5] = 1.0,
        [10] = 1.0
    }
}

local WAVE_START_TRANSMISSIONS = {
    Resource("/Lotus/Sounds/Dialog/SanctuaryOnslaught/DOnslaughtProg2WavesSmrs"),
    Resource("/Lotus/Sounds/Dialog/SanctuaryOnslaught/DOnslaughtProg4WavesSmrs"),
    Resource("/Lotus/Sounds/Dialog/SanctuaryOnslaught/DOnslaughtProg8WavesSmrs")
}

local PORTAL_ATTENUATION = Symbol("PortalAtten")
local PIXELATE_ATTEN = Symbol("PixelateAtten")
local DOOR_HINT_TAG = Symbol("DoorHint")
local DISABLED_SPAWN_TAGS = { Symbol("DoNotUse"), Symbol("DroneSpawn"), Symbol("BipedSpecialSpawn"), Symbol("GroupSpawn"), Symbol("TurretSpawn"), Symbol("CameraSpawn"), Symbol("FixedCameraSpawn"), Symbol("dSpawn"), Symbol("hSpawn"), Symbol("DefenseAgentSpawn") }
local ENEMY_TEAM_TAG = Symbol("Enemy")

local SCORE_WAVE_CLEAR = 10000
local SCORE_ENEMY_KILL = 10
local SCORE_VIP_KILL = 1000

local SCORING_RANK_NAMES = { 
    "/Lotus/Language/Onslaught/RankS", 
    "/Lotus/Language/Onslaught/RankAP", "/Lotus/Language/Onslaught/RankA", "/Lotus/Language/Onslaught/RankAM", 
    "/Lotus/Language/Onslaught/RankBP", "/Lotus/Language/Onslaught/RankB", "/Lotus/Language/Onslaught/RankBM", 
    "/Lotus/Language/Onslaught/RankCP", "/Lotus/Language/Onslaught/RankC", "/Lotus/Language/Onslaught/RankCM" 
}
local SCORING_RANK_PCT_THRESHOLDS = { 
    1.0, 
    0.90, 0.85, 0.80, 
    0.70, 0.60, 0.50, 
    0.40, 0.30, 0.20 
} -- percentage of "S Rank Score" to qualify for individual ranks

local STARTING_WAVE_NUM = 0

local ABILITY_THROTTLES = { -- { NUM_CASTS, CAST_PERIOD, COOLDOWN }
    { 6, 2, 8 },
    { 4, 6, 8 },
    { 4, 10, 10 },
    { 2, 10, 15 }
}

local mWorldStateChallengesAdded = false


local function GetWaveClearValue(waveNum)
    return SCORE_WAVE_CLEAR * waveNum
end

local function GetWaveRank(waveNum, waveScore)
    local PER_MINUTE_MULT = (WAVE_DURATION / 60)
    local S_RANK_SCORE = GetWaveClearValue(waveNum) + (50 * PER_MINUTE_MULT * SCORE_ENEMY_KILL) + (10 * PER_MINUTE_MULT * SCORE_VIP_KILL)

    local rankIdx = #SCORING_RANK_PCT_THRESHOLDS
    for i = 1, #SCORING_RANK_PCT_THRESHOLDS do
        if waveScore >= (SCORING_RANK_PCT_THRESHOLDS[i] * S_RANK_SCORE) then
            rankIdx = i
            break
        end
    end
    
    return rankIdx
end

local function GenerateRandomStreamWaveSeed(streamName)
    local curWave = gGameRules:GetNetPersistentVar(NV_WAVE_NUMBER, STARTING_WAVE_NUM)
    local seedStr = streamName .. "_" .. SeedToString(gGameRules:GetMission().seed) .. "_" .. tostring(curWave)
    return HashCrc32(seedStr)
end

local function IsDeterministicMode()
    if _T.IsDeterministicMode == nil then
        local missionSeed = SeedToString(gGameRules:GetMission().seed)
        _T.IsDeterministicMode = (missionSeed ~= "0")
    end
    return _T.IsDeterministicMode
end

local function StreamedRandomInt(streamName, min, max)
    if not IsDeterministicMode() then
        return RandomInt(min, max)
    end

    -- deterministic streams per wave 
    local oldSeed = GetSeed()
    
    if not _T.EndlessExtermination.RandStreams then
        _T.EndlessExtermination.RandStreams = {}
    end

    if not _T.EndlessExtermination.RandStreams[streamName] then
        _T.EndlessExtermination.RandStreams[streamName] = GenerateRandomStreamWaveSeed(streamName)
    end
    
    _T.EndlessExtermination.RandStreams[streamName] = _T.EndlessExtermination.RandStreams[streamName] + 1
    
    SetSeed(UnsignedToRandSeed(_T.EndlessExtermination.RandStreams[streamName]))
    local value = SRandomInt(min, max)
    SetSeed(oldSeed)

    return value
end

local function GetPortalDuration()
    if gCmdLine:Soak() then
        return PORTAL_DURATION / 6
    elseif gFlashMgr:GetConfigBool("LotusGameRules.FastDefense") then
        return PORTAL_DURATION / 2
    else
        return PORTAL_DURATION
    end
end

local function GetWaveDuration()
    if gCmdLine:Soak() then
        return 10
    elseif gFlashMgr:GetConfigBool("LotusGameRules.FastDefense") then
        return 30
    end
    return WAVE_DURATION
end

local function DisplayMessage(message, duration, instigator, argNames, argValues)
    if not argNames then
        argNames = ""
        argValues = ""
    end

    if instigator == nil then
        local humanPlayers = gRegion:GetHumanPlayers()
        for i, player in ipairs(humanPlayers) do
            gGameRules:DisplayMessage(player, message, "", 0, duration, true, argNames, argValues)
        end
    else
        local player = instigator:GetPlayer()
        gGameRules:DisplayMessage(player, message, "", 0, duration, true, argNames, argValues)
    end
end

local function PlayTransmission(transmission, targetPlayer)
    local players = gRegion:GetHumanPlayers()
    
    if not IsNull(players) then
        for i = 1, #players do
            if not targetPlayer or players[i] == targetPlayer then
                local avatar = players[i]:GetAvatar()
                if not IsNull(avatar) then
                    avatar:GiveTransmissionAsync(transmission)
                end
            end
        end
    end
end

local function UpdateScoreTracker()
    if IsNull(_T.EndlessExtermination.ScoreHudTracker) then
        local uiPriority = OBJTXT.GetPriorityOffset() + 6
        _T.EndlessExtermination.ScoreHudTracker = _T.AddHudTracker("DSScore", LOTUS_UTIL.HT_LABEL, 0.15, uiPriority, true)        
    end
    -- _T.EndlessExtermination.ScoreHudTracker.SetLabel(Localize("/Lotus/Language/Onslaught/Score", { VALUE = UTIL.FormatNumber(gGameRules:GetNetPersistentVar(NV_MISSION_SCORE, 0)) }))]]    
    local localizedText = _T.EndlessExtermination.ScoreHudTracker.Localize("/Lotus/Language/Onslaught/Score", nil, true)
    local score = UTIL.FormatNumber(gGameRules:GetNetPersistentVar(NV_MISSION_SCORE, 0))
    local text = "<p><font face=\"Noto Sans\" color=\"#FFFFFF\"><b>" .. localizedText .. " " .. score .. "</b></font></p>"
    _T.EndlessExtermination.ScoreHudTracker.SetLabel(text)
end

local function RefreshHudTrackers()
    if not _T.EndlessExtermination or not _T.AddHudTracker then
        return
    end

    if gRegion:IsMaster() then
        --[[if IsNull(_T.EndlessExtermination.FloorNumHudTracker) then
            _T.EndlessExtermination.FloorNumHudTracker = _T.AddHudTracker("DSFloorNum", LOTUS_UTIL.HT_LABEL, 0.15, 0, true)
        end
        _T.EndlessExtermination.FloorNumHudTracker.SetLabel(Localize("/Lotus/Language/Onslaught/Wave", { VALUE = (gGameRules:GetNetPersistentVar(NV_WAVE_NUMBER, STARTING_WAVE_NUM) + 1) }))]]
        local waveNum = gGameRules:GetNetPersistentVar(NV_WAVE_NUMBER, STARTING_WAVE_NUM) + 1
        --OBJTXT.SetObjTitleText("/Lotus/Language/Onslaught/Wave", waveNum)
        OBJTXT.SetTitleObjText("/Lotus/Language/Onslaught/Wave", " " .. waveNum, false)
        --OBJTXT.SetPrimaryObjText("/Lotus/Language/Onslaught/Wave", OBJTXT.NO_ICON, " " .. waveNum)
        OBJTXT.SetPrimaryObjText("/Lotus/Language/Onslaught/KillAllEnemies", OBJTXT.ATTACK_ICON)
        
        --[[if IsNull(_T.EndlessExtermination.PortalTimeTracker) then
            _T.EndlessExtermination.PortalTimeTracker = _T.AddHudTracker("DSPortal", LOTUS_UTIL.HT_LABEL, 0.15, 2, true)
        end
        _T.EndlessExtermination.PortalTimeTracker.SetLabel(Localize("/Lotus/Language/Onslaught/PortalTimer", { TIME = GAMEMODE.FormatTime(gGameRules:GetNetPersistentVar(NV_NEXT_PORTAL_TIMER, GetWaveDuration()), true) }))]]
        local time = gGameRules:GetNetPersistentVar(NV_NEXT_PORTAL_TIMER, GetWaveDuration())
        OBJTXT.SetObjTimer(time, false, false, false, nil, nil, nil, "/Lotus/Language/Onslaught/PortalTimer")
            
        --[[if IsNull(_T.EndlessExtermination.TimerBarHudTracker) then
            _T.EndlessExtermination.TimerBarHudTracker = _T.AddHudTracker("DSTime", LOTUS_UTIL.HT_PROGRESS_BAR, 0.15, 3, true)
            _T.EndlessExtermination.TimerBarHudTracker.SetFlareColor(_G.UIColor_DarkBlue)
            _T.EndlessExtermination.TimerBarHudTracker.SetLabel(Localize("/Lotus/Language/Onslaught/Stability", nil), 1)
            _T.EndlessExtermination.TimerBarHudTracker.SetGoalLabel("")
        end]]
        _T.MissionTimer = gGameRules:GetNetPersistentVar(NV_MISSION_TIMER, TIMER_START)
        --local timeRemainingPct = _T.MissionTimer / MAX_MISSION_TIMER
        --_T.EndlessExtermination.TimerBarHudTracker.SetValue(timeRemainingPct)
        local pct = UTIL.Round( (_T.MissionTimer / MAX_MISSION_TIMER) * 100 )
        OBJTXT.SetObjProgressBar("/Lotus/Language/Onslaught/Stability", pct, 100, nil, true)
        
        UpdateScoreTracker()
    end
    
    _T.EndlessExtermination.NeedsHudTrackerRefresh = false
end

local function InitializeDeathRoom()
    _T.EndlessExtermination.RoomInitialized = true
    _T.EndlessExtermination.KeysAcquired = 0
    _T.EndlessExtermination.WaveEnding = false
end

local function LerpForCurrentWave(sparseArray, subArrayIdx)
    local difficulty = UTIL.Ternary(IsDeterministicMode(), HARD, NORMAL)
    local sparseValues = sparseArray[difficulty]
    local curWave = Clamp(gGameRules:GetNetPersistentVar(NV_WAVE_NUMBER, STARTING_WAVE_NUM), 0, 100)

    local startIdx = nil
    local endIdx = nil

    for waveIdx = 0, 100 do
        if sparseValues[waveIdx] then
            if startIdx == nil or (waveIdx <= curWave and waveIdx > startIdx) then
                startIdx = waveIdx
            end

            if endIdx == nil or endIdx < startIdx or (waveIdx >= curWave and endIdx < waveIdx) then
                endIdx = waveIdx
            end
        end
    end
    
    local finalValue = 1
    if startIdx ~= nil and endIdx ~= nil then
        local startVal
        local endVal
        if subArrayIdx then -- multidimensional array
            startVal = sparseValues[startIdx][subArrayIdx]
            endVal = sparseValues[endIdx][subArrayIdx]
        else
            startVal = sparseValues[startIdx]
            endVal = sparseValues[endIdx]
        end
        local pct = Clamp((curWave - startIdx) / (endIdx - startIdx), -1, 1)
        finalValue = Lerp(startVal, endVal, pct)
    end
    
    return finalValue
end

local function GetZoneIdx(entity)
    if not IsNull(entity) then
        local zone = entity:GetZone()
        if not IsNull(zone) then
            return zone:GetRegionIndex()
        end
    end
    
    return -1
end

local function SpawnTimePickups()
    local numToSpawn = math.ceil(LerpForCurrentWave(NUM_TIME_PICKUPS_PER_WAVE))
    local spawnPoint = gGameRules:GetSpawnPoint()
    local roomCenter = spawnPoint:GetPosition()
    local allSpawnPoints = gRegion:FindAll(gNpcSpawnPointType, roomCenter, 0, 500)
    local validSpawnPoints = {}

    -- grab all legit spawn points
    for _,v in pairs(allSpawnPoints) do
        local canUse = true
        for __,tag in pairs(DISABLED_SPAWN_TAGS) do
            if v:GetTag() == tag then
                canUse = false
                break
            end
        end
        if canUse and v:DistanceToPoint(roomCenter) > TIME_PICKUP_SPREAD_DISTANCE then
            table.insert(validSpawnPoints, v)
        end
    end

    local spawnZoneIdx = GetZoneIdx(spawnPoint)

    if not _T.EndlessExtermination.TimePickupsTotal then
        _T.EndlessExtermination.TimePickupsTotal = {}
        _T.EndlessExtermination.TimePickupsAcquired = {}
    end
    
    _T.EndlessExtermination.TimePickupsTotal[spawnZoneIdx] = 0
    _T.EndlessExtermination.TimePickupsAcquired[spawnZoneIdx] = 0
    
    for i = 1, numToSpawn do
        local spawnIdx = StreamedRandomInt("TimePickup", 1, #validSpawnPoints)
        local spawnPoint = validSpawnPoints[spawnIdx]
        local spawnPointPos = spawnPoint:GetPosition()
        
        -- don't reuse any nearby spawn points
        for j = #validSpawnPoints, 1, -1 do
            if validSpawnPoints[j]:DistanceToPoint(spawnPointPos) < TIME_PICKUP_SPREAD_DISTANCE and (#validSpawnPoints > numToSpawn - i) then
                table.remove(validSpawnPoints, j)
            end
        end

        local navPoint = gRegion:GetNpcMgr():GetAiDirector():GetClosestWorldPointOnNavMeshScript(spawnPointPos)
        navPoint.y = navPoint.y + 0.5
        
        gRegion:CreateEntity(timePickupType, navPoint, ZERO_ROTATION)

        _T.EndlessExtermination.TimePickupsTotal[spawnZoneIdx] = _T.EndlessExtermination.TimePickupsTotal[spawnZoneIdx] + 1
    end
end

function OnNextDeathRoomReady()
    -- note: this won't be called on host until all clients have fully streamed the next death room
    _T.EndlessExtermination.DeathRoomStreamingInProgress = false

    -- Enable the portal
    if not IsNull(_T.EndlessExtermination.PortalInstance) then
        local trigger = _T.EndlessExtermination.PortalInstance:GetAttachment(gScriptTriggerType)
        if not IsNull(trigger) then
            trigger:Enable()
        end
    end
    
    -- Initialize the kill counts
    _T.EndlessExtermination.EnemiesSpawned = 0

    local minLevel = LerpForCurrentWave(ENEMY_LEVELS_PER_WAVE, 1)
    local maxLevel = LerpForCurrentWave(ENEMY_LEVELS_PER_WAVE, 2)
    gRegion:GetNpcMgr():GetAiDirector():SetEnemyLevelMinMax(minLevel, maxLevel)

    local seed = GenerateRandomStreamWaveSeed("AIDir")
    gRegion:GetNpcMgr():GetAiDirector():SetRandSeed(UnsignedToRandSeed(seed))
       
    -- Unlock all the doors
    local DoorHintTags = gRegion:FindTagged(DOOR_HINT_TAG)
    if not IsNull(DoorHintTags) then
        for x=1,#DoorHintTags do
            DoorHintTags[x]:FirePort("Unlock")
        end
    end
    
    local npcHints = gRegion:FindAll(gNpcDoorHintType)
    for i = 1, #npcHints do
        npcHints[i]:FirePort("Unlock")
    end
    
    SpawnTimePickups()

    if gGameRules:GetNetPersistentVar(NV_WAVE_NUMBER, STARTING_WAVE_NUM) > 0 then
        PlayTransmission(portalOpenTransmission)

        gChallengeMgr:BroadcastNotifyTag(Symbol("SANCTUARY_ONSLAUGHT_WAVE_COMPLETE"))
        if IsDeterministicMode() then
            gChallengeMgr:BroadcastNotifyTag(Symbol("ELITE_SANCTUARY_ONSLAUGHT_WAVE_COMPLETE"))
        end
    end

    if gCmdLine:Soak() then    
        local playerAvatars = gRegion:GetHumanPlayerAvatars()
        for i,v in ipairs(playerAvatars) do
            v:Teleport(_T.EndlessExtermination.PortalInstance:GetPosition(), v:GetSimRotation())
        end
    end
end

local function ShowPortal(initial)
    local position = Vector()
    local portalTrigger = nil
    
    _T.EndlessExtermination.ActiveTeleports = {}

    local effectType
    if initial then
        portalTrigger = initialPortalTriggerType
        effectType = initialPortalEffect
        local initialPortalSpawn = gRegion:FindFirstTagged(Symbol("PortalSpawn"))
    
        if not IsNull(initialPortalSpawn) then
            position = initialPortalSpawn:GetPosition()
        end
    else
        portalTrigger = portalTriggerType
        effectType = portalEffect
        position = gGameRules:GetSpawnPoint():GetPosition()
    end

    position.y = position.y + 2.5

    _T.EndlessExtermination.PortalInstance = gRegion:CreateEntity(effectType, position, ZERO_ROTATION)
    _T.EndlessExtermination.PortalInstance:Attach(portalTrigger, EMPTY_SYMBOL)

    if not initial then
        DisplayMessage("/Lotus/Language/Onslaught/PortalOpening", 10, nil)

        -- enemies swarm portal
        gRegion:GetNpcMgr():GetAiDirector():OrderNpcsStormTarget(_T.EndlessExtermination.PortalInstance)
    end
    OBJTXT.SetPrimaryObjText("/Lotus/Language/Onslaught/EnterTheConduit")
end

local function PrepareNextDeathRoom()
    gGameRules:PrepareNextDeathRoom("OnNextDeathRoomReady")
    _T.EndlessExtermination.DeathRoomStreamingInProgress = true
end

local function StreamInitialLevel()
    if not gGameRules:IsA(gEndlessExterminationGameRulesType) then
        Broadcast("Wrong game rules! Try again later")
        return
    end

    _T.gDisableCamerasAndTurrets = true

    if gPromotedToHost then
        return
    end
    
    ShowPortal(true)

    PrepareNextDeathRoom()
end

local function InitAIDirector()
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    aiDir:SetLevelAlert(true)
    if gPromotedToHost then
        -- new host needs to wait until fully-finished loading before allowing enemies to start whooping up on players
        _T.EnableAIDirQueued = true
    else
        aiDir:Enable(true)
    end
    aiDir:SetEnableAutoSpawns(false)
    aiDir:SetCustomSpawnSelectionFilter(10, 150, 0, 5, false, false, false)
    aiDir:SetUseCustomSpawnSelectionFilter(true)
    aiDir:SetExhaustActiveZonesAtPeak(false) --prevents intensity peak stopping spawning
    aiDir:SetAllowTeleportOldAgentsForNewSpawns(false)

    for _,tag in pairs(DISABLED_SPAWN_TAGS) do
        aiDir:AddDisallowedTag(tag)
    end
end

local function InitializeAfterHostMigration()
    _T.InitializedAfterHostMigration = true

    local waveDuration = GetWaveDuration()
    _T.NextPortalTimer = gGameRules:GetNetPersistentVar(NV_NEXT_PORTAL_TIMER, waveDuration)
    if _T.NextPortalTimer == 0 then
        -- That won't do at all!
        _T.NextPortalTimer = waveDuration
    end
    _T.gDisableCamerasAndTurrets = true

    InitializeDeathRoom()

    gGameRules:SetupSpawnPoint()

    local enemies = gRegion:FindAll(gLotusNpcAvatarType)
    for i = 1, #enemies do
        if enemies[i]:GetOriginalFaction() ~= PLAYER_FACTION_TAG then
            ObjectPortHandler(enemies[i], "OnKilled")
        end
    end

    InitAIDirector()

    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    local minLevel = LerpForCurrentWave(ENEMY_LEVELS_PER_WAVE, 1)
    local maxLevel = LerpForCurrentWave(ENEMY_LEVELS_PER_WAVE, 2)
    aiDir:SetEnemyLevelMinMax(minLevel, maxLevel)

    _T.EndlessExtermination.TimePickupsAcquired = {}
    _T.EndlessExtermination.TimePickupsTotal = {}
    
    local existingTimePickups = gRegion:FindAll(timePickupType)
    for _,pickup in pairs(existingTimePickups) do
        local zoneIdx = GetZoneIdx(pickup)
        if _T.EndlessExtermination.TimePickupsTotal[zoneIdx] == nil then
            _T.EndlessExtermination.TimePickupsTotal[zoneIdx] = 0
            _T.EndlessExtermination.TimePickupsAcquired[zoneIdx] = 0
        end
        _T.EndlessExtermination.TimePickupsTotal[zoneIdx] = _T.EndlessExtermination.TimePickupsTotal[zoneIdx] + 1
    end

    gGameRules:SetupEnemies()
end

local function InitEndlessExtermination()
    if _T.EndlessExtermination then
        return
    end

    _T.EndlessExtermination = {Players = {}, ActiveTeleports = {}, EnemiesSpawned = 0}
    
    _T.EndlessExtermination.NeedsHudTrackerRefresh = (not gRegion:IsMaster() and gGameRules:GetNetPersistentVar(NV_WAVE_NUMBER, STARTING_WAVE_NUM) > 0) or gPromotedToHost
    
    _T.CurrentRewardCount = gGameRules:GetNetPersistentVar(NV_REWARDS_GIVEN, 0)

    DIALOG.SetupMissionTransmissionSet(transmissionSet)

    -- make sure we don't have left over post-process effects from host migration
    if gPromotedToHost then
        local postProcess = gRegion:GetLevelInfo().postProcess
        postProcess:SetPostFxMaterial(defaultPostFxMat)
        postProcess.fade = 0
    end
end

function OnLevelLoaded(arg1, arg2, arg3)
    InitEndlessExtermination()
    
    if not gPromotedToHost then
        InitAIDirector()
    end
end

function OnPlayerConnected(gameRules, player)
end

function OnPlayerDisconnected(gameRules, player)
end

function OnPlayerSpawned(gameRules, player)
    _T.EndlessExtermination.Players[player:GetPlayerName()] = {Avatar = player:GetAvatar(), Zone = "wee"}

    if not _T.EndlessExtermination.DidInitial then
        _T.EndlessExtermination.DidInitial = true
        StreamInitialLevel()
    end
end

local function KillStragglers()
    local spawnZoneIdx = gGameRules:GetSpawnZoneIndex() + 1 -- Zone:GetRegionIndex() is 1-based in EngineBinding
    
    local playersLeaving = {}
    local playersStaying = {}
    
    local humanPlayers = gRegion:GetHumanPlayers()
    for i,pl in ipairs(humanPlayers) do
        local playerName = pl:GetPlayerName()
        local av = pl:GetAvatar()
        local avZoneIdx = GetZoneIdx(av)
        
        if not IsNull(av) and _T.wispPocketEntrance ~= nil then
            -- WispPocket ability streams in a small level you can be in
            local instance = av:GetInstance()
            if _T.wispPocketEntrance[instance] ~= nil and not IsNull(_T.wispPocketEntrance[instance].exitPortal) then
                avZoneIdx = GetZoneIdx(_T.wispPocketEntrance[instance].exitPortal)
            end
        end

        if
            not IsNull(av) and
            spawnZoneIdx ~= avZoneIdx and
            (not _T.EndlessExtermination.ActiveTeleports or not _T.EndlessExtermination.ActiveTeleports[playerName]) 
        then
            playersLeaving[#playersLeaving+1] = pl
        else
            playersStaying[#playersStaying+1] = pl
        end
    end
    
    gGameRules:UpdatePlayersStaying(playersLeaving, playersStaying)
end

local function IncrementScore(amount)
    local curScore = gGameRules:GetNetPersistentVar(NV_MISSION_SCORE, 0) + amount
    gGameRules:SetNetPersistentVar(NV_MISSION_SCORE, curScore)

    --[[if not IsNull(_T.EndlessExtermination.ScoreHudTracker) then
        _T.EndlessExtermination.ScoreHudTracker.SetLabel(Localize("/Lotus/Language/Onslaught/Score", { VALUE = curScore }))
    end]]
    UpdateScoreTracker()
end

local function IncMissionTimer(amount)
    if not _T.MissionTimer or not gRegion:IsMaster() or gGameRules:MissionCompleted() then
        return
    end

    _T.MissionTimer = Clamp(_T.MissionTimer + amount, 0, MAX_MISSION_TIMER)
    gGameRules:SetNetPersistentVar(NV_MISSION_TIMER, math.ceil(_T.MissionTimer))

    --[[if _T.EndlessExtermination.TimerBarHudTracker then
        local timeRemainingPct = _T.MissionTimer / MAX_MISSION_TIMER
        _T.EndlessExtermination.TimerBarHudTracker.SetValue(timeRemainingPct)
    end]]
    local pct = UTIL.Round( (_T.MissionTimer / MAX_MISSION_TIMER) * 100 )
    OBJTXT.UpdateObjProgressBarPct(pct, 100)
    
    if _T.MissionTimer <= 0 then
        print("VoidOnslaught timer expired. Ending mission")
        gGameRules:SendEndMissionCheatRMI()
    elseif _T.MissionTimer < 50 then
        local curWave = gGameRules:GetNetPersistentVar(NV_WAVE_NUMBER, STARTING_WAVE_NUM)
        if _T.LastStabilityWarningWave ~= curWave then
            PlayTransmission(stabilityWarningTransmission)
            _T.LastStabilityWarningWave = curWave 
        end
    end
end

function OnKilled(victim)
    local victimZone = victim:GetZone()
    if not IsNull(victimZone) then
        -- figure out if this enemy is in a zone that players have left behind
        local victimZoneIdx = victimZone:GetRegionIndex()
        local playerAvatars = gRegion:GetHumanPlayerAvatars()
        
        for _,playerAv in pairs(playerAvatars) do
            local playerZone = playerAv:GetZone() 
            if not IsNull(playerZone) and victimZoneIdx < playerZone:GetRegionIndex() then
                -- don't track kills occurring in previous deathroom
                return
            end
        end
    end

    -- award points if player was resposible for kill
    local lastDmg = victim:DamageControl():GetLastDamageTaken()
    if not IsNull(lastDmg) then
        local dmgSource = lastDmg:GetSource()
        if not IsNull(dmgSource) and dmgSource:IsA(gLotusMirrorAvatarType) then
            dmgSource = dmgSource:GetMirroredAvatar() -- for mirage clone
        end
        if not IsNull(dmgSource) and dmgSource:IsA(gLotusSentinelAvatarType) then
            dmgSource = dmgSource:GetOwningPlayerAvatar() -- for pets
        end
        if not IsNull(dmgSource) and dmgSource:IsA(gLotusNpcAvatarType) then
            local spawnerAvatar = dmgSource:GetSpawnedByAvatar()
            if not IsNull(spawnerAvatar) then
                dmgSource = spawnerAvatar
            end
        end

        if not IsNull(dmgSource) and dmgSource:IsA(gTennoAvatarType) and dmgSource:GetFaction() == Symbol("TENNO") and not IsNull(dmgSource:GetAuthoritativePlayer()) then
            local timeBonus = 0
            if victim:IsVIP() then
                timeBonus = KILL_VIP_TIME_BONUS
                IncrementScore(SCORE_VIP_KILL)
                gGameRules:SetNetPersistentVar(NV_MISSION_VIP_KILLS, gGameRules:GetNetPersistentVar(NV_MISSION_VIP_KILLS, 0) + 1)
                gGameRules:SetNetPersistentVar(NV_LAST_WAVE_VIP_KILLS, gGameRules:GetNetPersistentVar(NV_LAST_WAVE_VIP_KILLS, 0) + 1)
            else
                timeBonus = KILL_TIME_BONUS
                IncrementScore(SCORE_ENEMY_KILL, NV_MISSION_KILLS)
                gGameRules:SetNetPersistentVar(NV_MISSION_KILLS, gGameRules:GetNetPersistentVar(NV_MISSION_KILLS, 0) + 1)
                gGameRules:SetNetPersistentVar(NV_LAST_WAVE_KILLS, gGameRules:GetNetPersistentVar(NV_LAST_WAVE_KILLS, 0) + 1)
            end

            IncMissionTimer(timeBonus)
        end
    end
end

local function PrepareWaveStats()
    -- cache final wave stats for display
    local curWave = gGameRules:GetNetPersistentVar(NV_WAVE_NUMBER, STARTING_WAVE_NUM) - 1
    local missionScore = gGameRules:GetNetPersistentVar(NV_MISSION_SCORE, 0)
    local finalWaveScore = missionScore - gGameRules:GetNetPersistentVar(NV_LAST_WAVE_TOTAL_SCORE, 0)
    gGameRules:SetNetPersistentVar(NV_LAST_WAVE_TOTAL_SCORE, missionScore)
    gGameRules:SetNetPersistentVar(NV_LAST_WAVE_CLEARED_TIME, gGameRules:GetGameDuration())
    
    local waveRank = GetWaveRank(curWave, finalWaveScore)
    if not _T.TotalWaveRank then
        _T.TotalWaveRank = waveRank
    else
        _T.TotalWaveRank = _T.TotalWaveRank + waveRank
    end
    gGameRules:SetNetPersistentVar(NV_AVERAGE_WAVE_RANK, math.floor(_T.TotalWaveRank / (curWave + 1)))
    _T.EndlessExtermination.LastWaveScore = finalWaveScore
end

local function ResetWaveStats()
    -- reset stats for next wave
    gGameRules:SetNetPersistentVar(NV_LAST_WAVE_KILLS, 0)
    gGameRules:SetNetPersistentVar(NV_LAST_WAVE_VIP_KILLS, 0)
end

local function GiveWaveRewards()
    if gRegion:IsMaster() then
        gGameRules:HideGameSession(true)
    end

    local curWave = gGameRules:GetNetPersistentVar(NV_WAVE_NUMBER, STARTING_WAVE_NUM)
    if curWave % 2 ~= 0 then
        return
    end

    local rewardCount = curWave / 2

    if _T.CurrentRewardCount == nil then
        _T.CurrentRewardCount = gGameRules:GetNetPersistentVar(NV_REWARDS_GIVEN, 0)
    end

    while _T.CurrentRewardCount < rewardCount do
        gGameRules:OnTieredRewardRoundOver(_T.CurrentRewardCount)

        _T.CurrentRewardCount = _T.CurrentRewardCount + 1

        local movie = gFlashMgr:PushMovie(rewardsMovie)
        if not IsNull(movie) then
            movie:Execute("ShowReward", tostring(_T.CurrentRewardCount))
        end
        
        Sleep(0)
    end
    
    if gRegion:IsMaster() then
        gGameRules:SetNetPersistentVar(NV_REWARDS_GIVEN, rewardCount)
    end
end

local function EndWave()
    ShowPortal()

    local curWave = gGameRules:GetNetPersistentVar(NV_WAVE_NUMBER, STARTING_WAVE_NUM)
--~     local totalMissionTime = gGameRules:GetGameDuration()
--~     local lastWaveClearedTime = gGameRules:GetNetPersistentVar(NV_LAST_WAVE_CLEARED_TIME, 0)
--~     local thisWaveDuration = totalMissionTime - lastWaveClearedTime
    local waveScore = GetWaveClearValue(curWave + 1)

    IncrementScore(waveScore)

    local totalWaveScore = gGameRules:GetNetPersistentVar(NV_WAVE_CLEAR_SCORE, 0) + waveScore
    gGameRules:SetNetPersistentVar(NV_WAVE_CLEAR_SCORE, totalWaveScore)

    gGameRules:SetNetPersistentVar(NV_WAVE_NUMBER, curWave + 1)
    PrepareNextDeathRoom()

    _T.EndlessExtermination.RoomInitialized = false
    _T.EndlessExtermination.WaveEnding = true
    _T.EndlessExtermination.RandStreams = nil
    _T.EndlessExtermination.vipCooldown = nil
end

local function GetMaxEnemyCount()
    local playerCount = gRegion:GetHumanPlayerAvatarCount() + gFlashMgr:GetConfigInt("Server.NumVirtualTestClients")
    local numPlayers = math.min(playerCount, 4)
    
    if numPlayers == 0 then
        return 0
    end
    
    local maxSimultaneous = math.ceil(LerpForCurrentWave(MAX_SIMULTANEOUS_ENEMIES_PER_WAVE, numPlayers))
    
    return math.min(gRegion:GetNpcMgr():GetAiDirector():GetNpcHardCap(), maxSimultaneous)
end

local function NeedSpawns()
    if not _T.EndlessExtermination.RoomInitialized or _T.EndlessExtermination.DeathRoomStreamingInProgress then
        return false
    end
    local maxSimAICount = GetMaxEnemyCount()
    return gRegion:GetNpcMgr():GetAiDirector():GetActiveAICount() < maxSimAICount and (IsNull(_T.EndlessExtermination) or IsNull(_T.EndlessExtermination.PortalInstance) or (not IsNull(gGameRules:GetSpawnPoint()) and Distance(_T.EndlessExtermination.PortalInstance:GetPosition(), gGameRules:GetSpawnPoint():GetPosition()) > 500))
end

local function SpawnEnemy(isVip, spawnPoint)
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    local playerAvatars = gRegion:GetHumanPlayerAvatars()
    local playerCount = gRegion:GetHumanPlayerAvatarCount() + gFlashMgr:GetConfigInt("Server.NumVirtualTestClients")
    local numPlayers = math.min(playerCount, 4)
    
    local targetPlayerAvatars = {}
    for _,avatar in pairs(playerAvatars) do
        if not avatar:IsKilled() and not avatar:IsPreDeath() then
            table.insert(targetPlayerAvatars, avatar)
        end
    end
    
    -- Spawn enemy
    local genusType = Engine.STANDARD
    if _T.EndlessExtermination.vipCooldown and _T.EndlessExtermination.vipCooldown <= 0 then
        genusType = Engine.EXIMUS
        _T.EndlessExtermination.vipCooldown = nil
    end
    
    local agent = aiDir:CreateRandomAgent(nil, ENEMY_TEAM_TAG, 0, nil, genusType)

    if not IsNull(agent) then
        aiDir:TrackAgent(agent)
        agent:SetAlert()
        
        local avatar = agent:GetAvatar()
        ObjectPortHandler(avatar, "OnKilled")

        local damageMult = LerpForCurrentWave(ENEMY_DAMAGE_MULT_PER_WAVE)
        if damageMult > 1.0 then
            avatar:InventoryControl():AddUpgrade(Game.WEAPON_DAMAGE_AMOUNT, Game.MULTIPLY, damageMult)
        end

        if genusType == Engine.EXIMUS then
            avatar:SetIsVIP()
            avatar:SetThreatModifier(-5)
            avatar:SetFaction(aiDir:GetFaction(0))
        end

        _T.EndlessExtermination.EnemiesSpawned = _T.EndlessExtermination.EnemiesSpawned + 1

        if _T.EndlessExtermination.vipCooldown then
            _T.EndlessExtermination.vipCooldown = _T.EndlessExtermination.vipCooldown - 1
        else
            _T.EndlessExtermination.vipCooldown = StreamedRandomInt("VIPSpawn", VIP_SPAWN_COOLDOWN[1], VIP_SPAWN_COOLDOWN[2])
        end
        
        -- spawn enemies in strategic location (one group near the portal, others surrounding each VIP)
        if not IsNull(spawnPoint) then
            local navPoint = aiDir:GetClosestWorldPointOnNavMeshScript(spawnPoint:GetPosition())
            agent:GetAvatar():Teleport(navPoint)
            gRegion:CreateEntity(enemySpawnInEffect, navPoint, ZERO_ROTATION)
        elseif _T.EndlessExtermination.EnemiesSpawned < MAX_PORTAL_PROTECTOR_SPAWNS then
            local spawnPoint = gGameRules:GetSpawnPoint()
            local roomCenter = spawnPoint:GetPosition()
            local randomPoint = aiDir:GetRandomPointInRadiusOnNav(roomCenter, PORTAL_PROTECTOR_SPAWN_RANGE, false, 1)
            agent:GetAvatar():Teleport(randomPoint)
            gRegion:CreateEntity(enemySpawnInEffect, randomPoint, ZERO_ROTATION)
            
            if Distance(randomPoint, roomCenter) < PORTAL_PROTECTOR_SPAWN_RANGE / 2 then
                local bestDist = 999999
                local targetPlayer = nil
                for i = 1, #targetPlayerAvatars do
                    local dist = targetPlayerAvatars[i]:DistanceToPoint(randomPoint)
                    if dist < bestDist then
                        bestDist = dist
                        targetPlayer = targetPlayerAvatars[i]
                    end
                end
                        
                if not IsNull(targetPlayer) then
                    agent:StormTarget(targetPlayer)
                else
                    agent:StormTarget(spawnPoint)
                end
            end
        else
            gRegion:CreateEntity(enemySpawnInEffect, agent:GetAvatar():GetPosition(), ZERO_ROTATION)
        end
    end
    
    return agent
end

local function DissolveScene(instigator, dissolvePct)
    dissolvePct = Clamp(dissolvePct, 0, 1)

    if not IsNull(instigator) then
        local camera = instigator:GetAuthoritativePlayer():GetCamera()
        local transferDeco = camera:GetAttachment(transferDecoEffect)
        if IsNull(transferDeco) then
            transferDeco = camera:Attach(transferDecoEffect, EMPTY_SYMBOL)
        end
        if not IsNull(transferDeco) then
            transferDeco:SetMeshScale(Lerp(5, 0.1, dissolvePct))
            transferDeco:SetMaterialParam(Symbol("multiplier"), Clamp(dissolvePct * 3, 0, 1))
        end
    end
    
    local postProcess = gRegion:GetLevelInfo().postProcess
    postProcess.fade = -1 * Clamp(dissolvePct * dissolvePct, 0, 1)
    
    if false then
        local allDecos = gRegion:FindAll(nil, gRegion:GetLocalPlayerAvatar():GetPosition(), 0, 500)
        for _,deco in pairs(allDecos) do
            if not deco:IsA(gLotusAvatarType) and (IsNull(deco:GetAttachRoot()) or not deco:GetAttachRoot():IsA(gLotusAvatarType)) then
                deco:SetDissolve(dissolvePct)
            end
        end
    end
end

local function MapFromRange(t, range)
    t = Clamp(t, range.min, range.max)
    local f = range.max - range.min
    return (t - range.min) / f
end

local function DeactivateAndBlockAbilities(instigator, deactivate, block)
    local avatar = instigator
    if not IsNull(avatar) and avatar:IsA(gLotusOperatorAvatarType) and not IsNull(avatar:GetAuthoritativePlayer()) then
        avatar = avatar:GetAuthoritativePlayer():GetOwnedPowerSuitAvatar()
    end

    local success = false
    if not IsNull(avatar) then
        local inv = avatar:InventoryControl()
        if not IsNull(inv) and inv:IsA(gLotusInventoryControllerType) then
            local suit = inv:GetActivePowerSuit()
            if not IsNull(suit) then
                if deactivate then
                    suit:DeactivateAbilitiesSendRMI()
                end
                suit:SetAbilityIdentifiersBlocked(block)
                success = true
            end
        end
    end
    
    if not success then
        print("failed, no avatar or powersuit")
    end
end

local function ConsumeAllEnergy(instigator)
    local avatar = instigator
    if avatar:IsA(gLotusOperatorAvatarType) and not IsNull(avatar:GetPlayer()) then
        avatar = avatar:GetPlayer():GetOwnedPowerSuitAvatar()
        if IsNull(avatar) then
            return
        end
    end
    
    -- if the guy has any powers going, turn them off
    local invControl = avatar:InventoryControl()
    if not IsNull(invControl) then
        local suit = invControl:GetActivePowerSuit()
        if not IsNull(suit) then
            suit:SetEnergy(suit:GetInitialEnergy())
        end
    end
end

local function FormatScoreValue(count, individualValue)
    return UTIL.FormatNumber(count) .. " x " .. UTIL.FormatNumber(individualValue)
end

function ShowWaveScore(gameRules, waveNum, waveKills, waveVIPKills, waveTotal)
    if gFlashMgr:HasMovie(endOfMatchMovie) then
        return
    end

    -- NOTE: not to be called directly. Gets called from gameRules RMI
    local waveRank = GetWaveRank(waveNum, waveTotal)
    local waveRankLetter = Localize(SCORING_RANK_NAMES[waveRank], nil)
    local waveRankText = Localize("/Lotus/Language/Onslaught/RankLabel", { RANK = waveRankLetter })
    
    if not gFlashMgr:HasMovie(waveSummaryMovie) then
        gFlashMgr:PushMovie(waveSummaryMovie)
    end
    
    local orangeHex = UTIL.ConvertColorNumberToHex(_G.UIColor_Orange)

    _T.OWS_SetText("Card.WaveTitle", Localize("/Lotus/Language/Onslaught/WaveSummaryHeader", { VALUE = waveNum }))
    
    _T.OWS_PopulateWaveSummaryLine(Localize("/Lotus/Language/Onslaught/EndOfMatchKills", false), FormatScoreValue(waveKills, SCORE_ENEMY_KILL), UTIL.FormatNumber(waveKills * SCORE_ENEMY_KILL), true)
    _T.OWS_PopulateWaveSummaryLine(Localize("/Lotus/Language/Onslaught/EndOfMatchVIPKills", false), FormatScoreValue(waveVIPKills, SCORE_VIP_KILL), UTIL.FormatNumber(waveVIPKills * SCORE_VIP_KILL), true)
    _T.OWS_PopulateWaveSummaryLine(Localize("/Lotus/Language/Onslaught/EndOfMatchClearBonus", false), FormatScoreValue(waveNum, SCORE_WAVE_CLEAR), UTIL.FormatNumber(waveNum * SCORE_WAVE_CLEAR), false)

    _T.OWS_SetText("Card.TotalTitle", Localize("/Lotus/Language/Onslaught/EndOfMatchTotal", false))
    _T.OWS_SetText("Card.Total", UTIL.FormatNumber(waveTotal))

    _T.OWS_SetText("Card.Rank", waveRankLetter)
end

function DoTeleportation(instigator)
    if IsNull(instigator) or not instigator:IsA(gBaseAvatarType) or IsNull(instigator:GetPlayer()) then
        print("Using portal teleport on non-player avatar!")
        return
    end

    local origInstigator = instigator
    local instigatorPlayer = instigator:GetPlayer()
    local playerName = instigatorPlayer:GetPlayerName()
    
    if not _T.EndlessExtermination then
        InitEndlessExtermination()
    end
    
    if _T.EndlessExtermination.ActiveTeleports[playerName] ~= nil then
        -- Already doing the thing
        return
    end
    
    local numTeleportingPlayers = 0
    for i,v in pairs(_T.EndlessExtermination.ActiveTeleports) do
        numTeleportingPlayers = numTeleportingPlayers + 1
    end
    
    if numTeleportingPlayers == 0 and not _T.EndlessExtermination.RoomInitialized then
        -- make sure mission timer doesn't tick down while first guy is waiting for fancy transition fx
        _T.PreparingNextWave = true
    end

    gGameRules:OnTeleport(instigator)

    _T.EndlessExtermination.ActiveTeleports[playerName] = true
    
    local warframe = instigatorPlayer:GetOwnedPowerSuitAvatar()
    local companion

    if not IsNull(warframe) then
        companion = warframe:InventoryControl():GetCompanion()
    end
    
    local isHost = gRegion:IsMaster()
    local isLocal = instigator:ReplicaLocallyControlled()
    
    if isLocal then
        gRegion:PlaySound(portalEnterSound, Vector(), false)
        
        local warframe = instigatorPlayer:GetOwnedPowerSuitAvatar()
        if not IsNull(warframe) then
            warframe:PushInputFilter(teleportInputFilter)
        end
        local operator = instigatorPlayer:GetOperatorAvatar()
        if not IsNull(operator) then
            operator:PushInputFilter(teleportInputFilter)
        end
        
        local HUDInstance = gGameRules:GetHudMovieInstance()
        if not IsNull(HUDInstance) then
            HUDInstance:Execute("OnPowerModifierHeld", "false")
        end

        if not IsNull(_T.EndlessExtermination.PortalInstance) then
            local objective = _T.EndlessExtermination.PortalInstance:GetAttachment(gBaseMarkerInfoType)
            if not IsNull(objective) then
                objective:Disable()
            end
        end

        print("onslaught disabling abilities for " .. playerName)
        DeactivateAndBlockAbilities(origInstigator, true, true)
    end
    
    if isHost then
        ConsumeAllEnergy(origInstigator)

        if not IsNull(warframe) then
            warframe:SetPostureModifier(Engine.PM_CLOAK, true)
        end
        local operator = instigatorPlayer:GetOperatorAvatar()
        if not IsNull(operator) then
            operator:SetPostureModifier(Engine.PM_CLOAK, true)
        end
        if not IsNull(companion) then
            companion:SetPostureModifier(Engine.PM_CLOAK, true)
        end
    end
    
    local fovSweep = {min =  2, max = 3}
    local timeFreeze = {min = 0, max = 0.5}
    
    local timer = 0
    local attenutationSpeedMult = 1
    
    if not IsNull(instigator) then
        local warframe = instigatorPlayer:GetOwnedPowerSuitAvatar()
        if not IsNull(warframe) then
            warframe:DamageControl():AddShieldHealthDamageModifier(PORTAL_ATTENUATION, Engine.DT_ANY, Engine.ANY_PART, Engine.DHT_NONE, 0)
            warframe:Attach(avatarGlowProjector, EMPTY_SYMBOL)
        end
        
        local operator = instigatorPlayer:GetOperatorAvatar()
        if not IsNull(operator) then
            operator:DamageControl():AddShieldHealthDamageModifier(PORTAL_ATTENUATION, Engine.DT_ANY, Engine.ANY_PART, Engine.DHT_NONE, 0)
            operator:Attach(avatarGlowProjector, EMPTY_SYMBOL)
        end
        
        attenutationSpeedMult = math.max(instigator:GetSpeed() * 0.5, 1)
    end
    if not IsNull(companion) then
        companion:SetPostureModifier(Engine.PM_CLOAK, true)
        companion:DamageControl():AddShieldHealthDamageModifier(PORTAL_ATTENUATION, Engine.DT_ANY, Engine.ANY_PART, Engine.DHT_NONE, 0)
        companion:Attach(avatarGlowProjector, EMPTY_SYMBOL)
    end
    
    if isLocal then
        local postProcess = gRegion:GetLevelInfo().postProcess
        postProcess:SetPostFxMaterial(transitionPostFxMat)
    end
    
    while timer < DEATH_ROOM_ACTIVATION_DELAY and not IsNull(instigator) do
        local timeFreezePct = MapFromRange(timer, timeFreeze)
        local fovPct = MapFromRange(timer, fovSweep)
        local dissolvePct = timer / DEATH_ROOM_ACTIVATION_DELAY
        
        if isLocal then
            mixer:SetOcclusionBias(fovPct)
            if not IsNull(instigator) and not IsNull(instigator:CameraControl()) then
                instigator:CameraControl():AttenuateFOV(1 + (fovPct * fovPct * 2))
            end
            if not _T.RoomDissolveOverride then
                _T.RoomDissolveOverride = 0
            end
            DissolveScene(instigator, math.max(dissolvePct, _T.RoomDissolveOverride))
            if not IsNull(transitionPostFxMat) then
                transitionPostFxMat:SetParam(PIXELATE_ATTEN, timer / DEATH_ROOM_ACTIVATION_DELAY)
            end
        end
        
        if isHost then
            local atten = Clamp(timeFreezePct * timeFreezePct * attenutationSpeedMult, 0, 1)
            if not IsNull(instigatorPlayer) then
                local warframe = instigatorPlayer:GetOwnedPowerSuitAvatar()
                if not IsNull(warframe) then
                    warframe:AddDeltaAttenuation(PORTAL_ATTENUATION, Lerp(1.0, 0.05, atten))
                end
                local operator = instigatorPlayer:GetOperatorAvatar()
                if not IsNull(operator) then
                    operator:AddDeltaAttenuation(PORTAL_ATTENUATION, Lerp(1.0, 0.05, atten))
                end
            end
            if not IsNull(companion) then
                companion:AddDeltaAttenuation(PORTAL_ATTENUATION, Lerp(1.0, 0.05, atten))
            end
        end

        local dt = DeltaTime()
        timer = timer + dt

        Sleep(0)
        instigator = instigatorPlayer:GetAvatar() -- avatar could have changed while sleeping (i.e. due to respawn)
    end

    if isLocal or isHost then
        _T.EndlessExtermination.NeedsHudTrackerRefresh = true
    end
    
    if isHost and not IsNull(instigator) then
        local spawnPoint = gGameRules:GetSpawnPoint()
        if not IsNull(spawnPoint) then
            local aiDir = gRegion:GetNpcMgr():GetAiDirector()
            local randomPoint = aiDir:GetRandomPointInRadiusOnNav(spawnPoint:GetPosition(), PLAYER_RANDOM_SPAWN_NEAR_WAYPOINT_DISTANCE, false, 1)
            
            instigator:Teleport(randomPoint, spawnPoint:GetRotation())
            instigator:ClearLastValidPosition()
            local warframe = instigator:GetPlayer():GetOwnedPowerSuitAvatar()
            local operator = instigator:GetPlayer():GetOperatorAvatar()
            if not IsNull(warframe) and warframe ~= instigator then
                randomPoint = aiDir:GetRandomPointInRadiusOnNav(spawnPoint:GetPosition(), PLAYER_RANDOM_SPAWN_NEAR_WAYPOINT_DISTANCE, false, 1)
                warframe:Teleport(randomPoint, spawnPoint:GetRotation())
                warframe:ClearLastValidPosition()
            elseif not IsNull(operator) and operator ~= instigator then
                randomPoint = aiDir:GetRandomPointInRadiusOnNav(spawnPoint:GetPosition(), PLAYER_RANDOM_SPAWN_NEAR_WAYPOINT_DISTANCE, false, 1)
                operator:Teleport(randomPoint, spawnPoint:GetRotation())
                operator:ClearLastValidPosition()
            end
            
            if not IsNull(companion) then
                randomPoint = aiDir:GetRandomPointInRadiusOnNav(spawnPoint:GetPosition(), PLAYER_RANDOM_SPAWN_NEAR_WAYPOINT_DISTANCE, false, 1)
                companion:Teleport(randomPoint, spawnPoint:GetRotation())
            end
            if not IsNull(warframe) and _T.khoraKavat and not IsNull(_T.khoraKavat[warframe:GetInstance()]) and not IsNull(_T.khoraKavat[warframe:GetInstance()].avatar) then
                _T.khoraKavat[warframe:GetInstance()].avatar:Teleport(randomPoint, spawnPoint:GetRotation())
            end
            
            aiDir:ClearStormTargetOrder(_T.EndlessExtermination.PortalInstance)
        end
        
        ConsumeAllEnergy(origInstigator)

        if not _T.EndlessExtermination.RoomInitialized then
            InitializeDeathRoom()
            ResetWaveStats()
        end
    end
    
    local warframe = instigatorPlayer:GetOwnedPowerSuitAvatar()
    if not IsNull(warframe) then
        local glowChildren = warframe:GetAllAttachments(avatarGlowProjector)
        for i=1, #glowChildren do
            glowChildren[i]:Destroy()
        end
    end

    local operator = instigatorPlayer:GetOperatorAvatar()
    if not IsNull(operator) then
        local glowChildren = operator:GetAllAttachments(avatarGlowProjector)
        for i=1, #glowChildren do
            glowChildren[i]:Destroy()
        end
    end

    if not IsNull(companion) then
        local glowChildren = companion:GetAllAttachments(avatarGlowProjector)
        for i=1, #glowChildren do
            glowChildren[i]:Destroy()
        end
    end
    
    if isLocal then --new level info?
        local postProcess = gRegion:GetLevelInfo().postProcess
        postProcess:SetPostFxMaterial(transitionPostFxMat)
    end
    
    timer = DEATH_ROOM_ACTIVATION_DELAY
    while timer > 0 and not IsNull(instigator) do
        local timeFreezePct = MapFromRange(timer, timeFreeze)
        local fovPct = MapFromRange(timer, fovSweep)
        local dissolvePct = timer / DEATH_ROOM_ACTIVATION_DELAY

        if isLocal then
            mixer:SetOcclusionBias(fovPct)
            if not IsNull(instigator) and not IsNull(instigator:CameraControl()) then
                instigator:CameraControl():AttenuateFOV(1 + (fovPct * fovPct * 2))
            end
            DissolveScene(instigator, dissolvePct)
            _T.RoomDissolveOverride = 0
            local postProcess = gRegion:GetLevelInfo().postProcess
            postProcess:SetPostFxMaterial(transitionPostFxMat)
            if not IsNull(transitionPostFxMat) then
                transitionPostFxMat:SetParam(PIXELATE_ATTEN, dissolvePct)
            end
        end
        
        if isHost then
            if not IsNull(instigatorPlayer) then
                local warframe = instigatorPlayer:GetOwnedPowerSuitAvatar()
                if not IsNull(warframe) then
                    warframe:AddDeltaAttenuation(PORTAL_ATTENUATION, Lerp(1.0, 0.05, timeFreezePct * timeFreezePct))
                end
                local operator = instigatorPlayer:GetOperatorAvatar()
                if not IsNull(operator) then
                    operator:AddDeltaAttenuation(PORTAL_ATTENUATION, Lerp(1.0, 0.05, timeFreezePct * timeFreezePct))
                end
            end

            if not IsNull(companion) then
                companion:AddDeltaAttenuation(PORTAL_ATTENUATION, Lerp(1.0, 0.05, timeFreezePct * timeFreezePct))
            end
        end

        local dt = DeltaTime()
        timer = timer - dt
        
        Sleep(0)
        instigator = instigatorPlayer:GetAvatar() -- avatar could have changed while sleeping (i.e. due to respawn)
    end
    
    if isLocal then
        if not IsNull(instigatorPlayer) then
            local warframe = instigatorPlayer:GetOwnedPowerSuitAvatar()
            if not IsNull(warframe) then
                warframe:PopInputFilter(teleportInputFilter)
            end
            local operator = instigatorPlayer:GetOperatorAvatar()
            if not IsNull(operator) then
                operator:PopInputFilter(teleportInputFilter)
            end
        end
        
        if not IsNull(instigator) and not IsNull(instigator:CameraControl()) then
            instigator:CameraControl():AttenuateFOV(1)
        end
        mixer:SetOcclusionBias(0)
        DissolveScene(instigator, 0)
        _T.RoomDissolveOverride = 0
        while IsNull(gGameRules:GetDynamicMusicMgr()) do
            Sleep(0)
        end
        gGameRules:GetDynamicMusicMgr():SetMusicState(Symbol("HeavyCombat"))
        local postProcess = gRegion:GetLevelInfo().postProcess
        postProcess:SetPostFxMaterial(defaultPostFxMat)
        postProcess.fade = 0
        
        print("onslaught enabling abilities for " .. playerName)
        DeactivateAndBlockAbilities(origInstigator, false, false)
    end
    
    if isHost then
        if not IsNull(instigator) then
            local warframe = instigatorPlayer:GetOwnedPowerSuitAvatar()
            if not IsNull(warframe) then
                warframe:SetPostureModifier(Engine.PM_CLOAK, false)
                warframe:RemoveDeltaAttenuation(PORTAL_ATTENUATION)
            end
            local operator = instigatorPlayer:GetOperatorAvatar()
            if not IsNull(operator) then
                operator:SetPostureModifier(Engine.PM_CLOAK, false)
                operator:RemoveDeltaAttenuation(PORTAL_ATTENUATION)
            end
        end
        if not IsNull(companion) then
            companion:RemoveDeltaAttenuation(PORTAL_ATTENUATION)
            companion:SetPostureModifier(Engine.PM_CLOAK, false)
        end
        if gGameRules:GetNetPersistentVar(NV_WAVE_NUMBER, STARTING_WAVE_NUM) > 0 and not IsNull(instigator) then
            local instigatorInv = instigator:InventoryControl()
            if instigatorInv:HasFocusLensEquipped() and not instigatorInv:HasReachedDailyFocusCap() then
                local duration = LerpForCurrentWave(FOCUS_BOOSTS_PER_WAVE, 1)
                local multiplier = LerpForCurrentWave(FOCUS_BOOSTS_PER_WAVE, 2)
                instigatorInv:OnFocusBoostEvent(true, duration, multiplier)
            end
        end
    end

    if _T.PreparingNextWave then
        _T.NextPortalTimer = GetWaveDuration()
        gGameRules:SetNetPersistentVar(NV_NEXT_PORTAL_TIMER, _T.NextPortalTimer)
    end
    
    if isLocal then
        _T.EndlessExtermination.NeedsHudTrackerRefresh = true
    end

    Sleep(2)

    if _T.PreparingNextWave then
        _T.PreparingNextWave = false
    end

    local warframe = instigatorPlayer:GetOwnedPowerSuitAvatar()
    if not IsNull(warframe) then
        warframe:DamageControl():RemoveShieldHealthDamageModifier(PORTAL_ATTENUATION)
    end
    local operator = instigatorPlayer:GetOperatorAvatar()
    if not IsNull(operator) then
        operator:DamageControl():RemoveShieldHealthDamageModifier(PORTAL_ATTENUATION)
    end
    if not IsNull(companion) then
        companion:DamageControl():RemoveShieldHealthDamageModifier(PORTAL_ATTENUATION)
    end

    if isLocal and not isHost then
        _T.EndlessExtermination.ActiveTeleports = {}
    else
        _T.EndlessExtermination.ActiveTeleports[playerName] = nil
    end
    
    local curWave = gGameRules:GetNetPersistentVar(NV_WAVE_NUMBER, STARTING_WAVE_NUM)
    local missionTimer = gGameRules:GetNetPersistentVar(NV_MISSION_TIMER, TIMER_START)
    if
        (curWave > 0) and
        ((curWave % 2) == 0) and
        ((curWave / 2) <= #WAVE_START_TRANSMISSIONS) and
        (missionTimer > 75)
    then
        local playChance = math.random(1,100)
        if playChance <= 40 then
            PlayTransmission(WAVE_START_TRANSMISSIONS[curWave / 2], instigatorPlayer)
        end
    end
end

local function IsPlayerInActiveZone(player)
    if not IsNull(player) then
        local avatar = player:GetAvatar()
        if not IsNull(avatar) then
            local avZone = GetZoneIdx(avatar)
            local spawnZone = GetZoneIdx(gGameRules:GetSpawnPoint())
            return(avZone == spawnZone)
        end
    end

    return false
end

-- The initial portal does not do a count down until somebody uses it
function InitialPortalTriggerUpdate(trigger)
    while not trigger:IsEnabled() do
        Sleep(0)
    end
    
    local portalTimer = 0
    
    while portalTimer < PORTAL_FADE_IN_DURATION do
        local dt = DeltaTime()
        portalTimer = portalTimer + dt
        
        local pct = Clamp(portalTimer / PORTAL_FADE_IN_DURATION, 0, 1)
        
        Sleep(0)
    end
    
    -- enable portal spawner
    local parent = trigger:GetAttachParent()

    if not IsNull(parent) then
        parent:Enable()
    end
    
    while true do
        if _T.EndlessExtermination ~= nil then
            local hasValues = false
            for i,v in pairs(_T.EndlessExtermination.ActiveTeleports) do
                hasValues = true
                break
            end
            
            if hasValues then
                break
            end
        end
        Sleep(0)
    end
    
    local player = gRegion:GetLocalPlayer()
    local playerName = player:GetPlayerName()
    local playerTeleported = false
    local prevTimer = 0
    local warningPlayed = false
    local numPlayers = gRegion:GetNumHumanPlayers()
    portalTimer = 0

    while portalTimer < GetPortalDuration() do
        local dt = DeltaTime()
        prevTimer = portalTimer
        portalTimer = portalTimer + dt
        
        local val = GetPortalDuration() - portalTimer
        local pct = Clamp(val / PORTAL_FADE_IN_DURATION, 0, 1)
        
        if not playerTeleported and (IsNull(player) or _T.EndlessExtermination.ActiveTeleports[playerName] == nil) then
            if math.floor(prevTimer) < math.floor(portalTimer) and portalTimer < GetPortalDuration() then
                _T.ShowImpactMessage(Localize("/Lotus/Language/Onslaught/PortalClosing", { TIME = math.ceil(GetPortalDuration() - portalTimer) }), 1, true, nil, false)
            end
            if portalTimer > PORTAL_WARNING_TIME then
                if not warningPlayed then
                    warningPlayed = true
                    PlayTransmission(portalWarningTransmission, player)
                end
            end
            if IsPlayerInActiveZone(player) then
                playerTeleported = true
                DissolveScene(gRegion:GetLocalPlayerAvatar(), 0)
            elseif portalTimer > PORTAL_AUTO_DISSOLVE_TIME then
                local pct = (portalTimer - PORTAL_AUTO_DISSOLVE_TIME) / (GetPortalDuration() - PORTAL_AUTO_DISSOLVE_TIME)
                _T.RoomDissolveOverride = pct * pct * pct
                DissolveScene(gRegion:GetLocalPlayerAvatar(), _T.RoomDissolveOverride)
            end
        else
            playerTeleported = true
        end
    
        Sleep(0)
    end
    
    local objective = trigger:GetAttachParent():GetAttachment(gBaseMarkerInfoType)
    if not IsNull(objective) then
        objective:Disable()
    end
    
    if not playerTeleported then
        _T.ShowImpactMessage(Localize("/Lotus/Language/Onslaught/PortalClosed", nil), 4, true, nil, false)
    end

    if gRegion:IsMaster() then
        KillStragglers()

        trigger:Disable()
        Sleep(4) -- Give some time for scripts to finish
        
        if not IsNull(_T.EndlessExtermination.PortalInstance) then
            _T.EndlessExtermination.PortalInstance:Destroy()
        end
        _T.EndlessExtermination.PortalInstance = nil
    end
end

-- Regular portals do a count down as soon as they are enabled
function PortalTriggerUpdate(trigger)
    while not trigger:IsEnabled() do
        Sleep(0)
    end
    
    local parent = trigger:GetAttachParent()

    if not IsNull(parent) then
        parent:Enable()
    end
    
    if not _T.EndlessExtermination then
        InitEndlessExtermination()
    end

    -- give rewards now that the portal has appeared
    local waveNum = gGameRules:GetNetPersistentVar(NV_WAVE_NUMBER, STARTING_WAVE_NUM)
    if waveNum > 0 and (_T.EndlessExtermination.LastShownWave == nil or _T.EndlessExtermination.LastShownWave < waveNum) then
        -- first guy through triggers wave score for all
        _T.EndlessExtermination.LastShownWave = waveNum
        if gRegion:IsMaster() then
            PrepareWaveStats()
            
            local waveNum = gGameRules:GetNetPersistentVar(NV_WAVE_NUMBER, STARTING_WAVE_NUM)
            local waveKills = gGameRules:GetNetPersistentVar(NV_LAST_WAVE_KILLS, 0)
            local waveVIPKills = gGameRules:GetNetPersistentVar(NV_LAST_WAVE_VIP_KILLS, 0)
            local waveTotal = _T.EndlessExtermination.LastWaveScore
            gGameRules:BroadcastWaveScore(waveNum, waveKills, waveVIPKills, waveTotal)
        end

        GiveWaveRewards()
    end
    
    local player = gRegion:GetLocalPlayer()
    local playerName = player:GetPlayerName()
    local playerTeleported = false
    local portalTimer = 0
    local prevTimer = 0
    local warningPlayed = false

    _T.ShowImpactMessage(Localize("/Lotus/Language/Onslaught/PortalClosing", { TIME = GetPortalDuration() }), 1, true, nil, false)
    
    while portalTimer < GetPortalDuration() do
        local dt = DeltaTime()
        prevTimer = portalTimer
        portalTimer = portalTimer + dt
        
        if portalTimer <= PORTAL_FADE_IN_DURATION then
            local val = portalTimer
            local pct = Clamp(val / PORTAL_FADE_IN_DURATION, 0, 1)
        else
            local val = GetPortalDuration() - portalTimer
            local pct = Clamp(val / PORTAL_FADE_IN_DURATION, 0, 1)
        end
        
        if not playerTeleported and (IsNull(player) or _T.EndlessExtermination.ActiveTeleports[playerName] == nil) then
            if math.floor(prevTimer) < math.floor(portalTimer) and portalTimer < GetPortalDuration() then
                _T.ShowImpactMessage(Localize("/Lotus/Language/Onslaught/PortalClosing", { TIME = math.ceil(GetPortalDuration() - portalTimer) }), 1, true, nil, false)
            end
            if portalTimer > PORTAL_WARNING_TIME then
                if not warningPlayed then
                    warningPlayed = true
                    PlayTransmission(portalWarningTransmission, player)
                end
            end

            if IsPlayerInActiveZone(player) then
                playerTeleported = true
                DissolveScene(gRegion:GetLocalPlayerAvatar(), 0)
            elseif portalTimer > PORTAL_AUTO_DISSOLVE_TIME then
                local pct = (portalTimer - PORTAL_AUTO_DISSOLVE_TIME) / (GetPortalDuration() - PORTAL_AUTO_DISSOLVE_TIME)
                _T.RoomDissolveOverride = pct * pct * pct
                DissolveScene(gRegion:GetLocalPlayerAvatar(), _T.RoomDissolveOverride)
            end
        else
            playerTeleported = true
        end
        
        Sleep(0)
    end

    if not IsNull(_T.EndlessExtermination.PortalInstance) then
        local objective = _T.EndlessExtermination.PortalInstance:GetAttachment(gBaseMarkerInfoType)
        if not IsNull(objective) then
            objective:Disable()
        end
    end
    
    if not playerTeleported then
        _T.ShowImpactMessage(Localize("/Lotus/Language/Onslaught/PortalClosed", nil), 4, true, nil, false)
    end

    if gRegion:IsMaster() then
        KillStragglers()

        trigger:Disable()
        Sleep(4) -- Give some time for scripts to finish
        
        gGameRules:DestroyPrevDeathRoom()
        
        if not IsNull(_T.EndlessExtermination.PortalInstance) then
            _T.EndlessExtermination.PortalInstance:Destroy()
        end
        _T.EndlessExtermination.PortalInstance = nil
        
    else
        _T.EndlessExtermination.ActiveTeleports = {}
    end
end

function OnTouchPortal(instigator)
    instigator:ScriptRunChildScript(Symbol("DoTeleportation"), false)
end

local function GetWaveClockRateMultiplier()
    local curWave = Clamp(gGameRules:GetNetPersistentVar(NV_WAVE_NUMBER, STARTING_WAVE_NUM), 0, 100)
    if _T.CachedClockRateMultiplier and _T.CachedWaveNum and _T.CachedWaveNum == curWave then
        return _T.CachedClockRateMultiplier
    end
    
    _T.CachedClockRateMultiplier = LerpForCurrentWave(CLOCK_RATE_MULTIPLIER)
    _T.CachedWaveNum = curWave

    return _T.CachedClockRateMultiplier
end

local function OnTimePickup(instigator)
    IncMissionTimer(TIME_PICKUP_BONUS_TIME)

    if _T.EndlessExtermination.TimePickupsAcquired == nil then
        _T.EndlessExtermination.TimePickupsAcquired = {}
        _T.EndlessExtermination.TimePickupsTotal = {}
    end
    
    local zoneIdx = GetZoneIdx(instigator)
    if not _T.EndlessExtermination.TimePickupsAcquired[zoneIdx] then
        _T.EndlessExtermination.TimePickupsAcquired[zoneIdx] = 0
    end
    if not _T.EndlessExtermination.TimePickupsTotal[zoneIdx] then
        _T.EndlessExtermination.TimePickupsTotal[zoneIdx] = 1
    end
    
    _T.EndlessExtermination.TimePickupsAcquired[zoneIdx] = _T.EndlessExtermination.TimePickupsAcquired[zoneIdx] + 1

    DisplayMessage("/Lotus/Language/Onslaught/TimeBonus", 3, nil, "COUNT,TOTAL", tostring(_T.EndlessExtermination.TimePickupsAcquired[zoneIdx]) .. "," .. tostring(_T.EndlessExtermination.TimePickupsTotal[zoneIdx]))
end
_T.OnTimePickup = OnTimePickup

function OnLocalAvatarCreated(gameRules, avatar)
    InitEndlessExtermination()

    if gPromotedToHost and not _T.InitializedAfterHostMigration then
        InitializeAfterHostMigration()
    end
end

local function UpdateAbilityThrottling(delta)
    -- only applies to weekly challenge mode
    if not IsDeterministicMode() then
        return
    end

    if not _T.EndlessExtermination.AbilityCastInfo then
        _T.EndlessExtermination.AbilityCastInfo = {}
    end
    
    if IsNull(_T.EndlessExtermination.AbilityCastInfo.Avatar) then
        local avatar = gRegion:GetLocalPlayerAvatar()
        if not IsNull(avatar) and not avatar:IsA(gLotusOperatorAvatarType) then
            _T.EndlessExtermination.AbilityCastInfo = {Avatar = avatar, CastCounts = {}, CastTimes = {}}
        else
            return
        end
    end
    
    local avatar = _T.EndlessExtermination.AbilityCastInfo.Avatar
    if IsNull(avatar) then
        return
    end
    
    local suit = avatar:InventoryControl():GetActivePowerSuit()
    if IsNull(suit) then
        return
    end
    
    local ability = nil
    local activationCount = 0
    local castCounts = _T.EndlessExtermination.AbilityCastInfo.CastCounts
    local castTimes = _T.EndlessExtermination.AbilityCastInfo.CastTimes
    for i = 1, 4 do
        for j = #castTimes[i], 1, -1 do
            castTimes[i][j] = castTimes[i][j] - delta
            if castTimes[i][j] <= 0 then
                table.remove(castTimes[i], j)
            end
        end
        
        ability = suit:GetAbilityByIndex(i - 1)
        activationCount = ability:GetActivationCount()
        
        if castCounts[i] == nil then
            castCounts[i] = activationCount
        elseif castCounts[i] ~= activationCount then
            castCounts[i] = activationCount
            
            if castTimes[i] == nil then
                castTimes[i] = {}
            end
            table.insert(castTimes[i], ABILITY_THROTTLES[i][2])
            
            if #castTimes[i] >= ABILITY_THROTTLES[i][1] then
                ability:SetCooldownTime(ABILITY_THROTTLES[i][3])
                castTimes[i] = nil
                
                DIALOG.PlayLocalTransmission(_T.MissionTransmissionSet, Symbol("AbilityThrottled"), 0, avatar)
            end
        end
    end
end

function OnUpdate(gameRules, delta)
    delta = RealDeltaTime()

    if not mWorldStateChallengesAdded and gGameRules:GameStarted() then
        gChallengeMgr:AddWorldStateChallenges()
        mWorldStateChallengesAdded = true
    end

    if not _T.EndlessExtermination then
        return
    end
    
    UpdateAbilityThrottling(delta)
    
    if not gRegion:IsMaster() or gGameRules:Paused() then
        return
    end
    
    if _T.EnableAIDirQueued and not gFlashMgr:HasMovie(progressMovie) then
        _T.EnableAIDirQueued = false
        gRegion:GetNpcMgr():GetAiDirector():Enable(true)
    end
    
    if _T.EndlessExtermination.NeedsHudTrackerRefresh then
        RefreshHudTrackers()
    end

    if _T.NextPortalTimer and _T.NextPortalTimer > 0 then
        _T.NextPortalTimer = math.max(_T.NextPortalTimer - delta, 0)

        local portalTime = math.ceil(_T.NextPortalTimer)
        gGameRules:SetNetPersistentVar(NV_NEXT_PORTAL_TIMER, portalTime)
        OBJTXT.SetObjTimer(portalTime, false, false, false, nil, nil, nil, "/Lotus/Language/Onslaught/PortalTimer")

        if _T.NextPortalTimer <= 0 then
            EndWave()
        end
    end

    if NeedSpawns() then    
        SpawnEnemy()
    end

    if _T.MissionTimer and not _T.PreparingNextWave and not _T.EndlessExtermination.DeathRoomStreamingInProgress and (_T.EndlessExtermination.RoomInitialized or gRegion:GetNpcMgr():GetAiDirector():GetActiveAICount() > 0) then
        local timerDelta = delta * GetWaveClockRateMultiplier()

        if not gFlashMgr:GetConfigBool("LotusGameRules.FastDefense") then
            IncMissionTimer(-timerDelta)
        end
    end

    --[[if _T.EndlessExtermination.PortalTimeTracker then
        _T.EndlessExtermination.PortalTimeTracker.SetLabel(Localize("/Lotus/Language/Onslaught/PortalTimer", { TIME = GAMEMODE.FormatTime(gGameRules:GetNetPersistentVar(NV_NEXT_PORTAL_TIMER, GetWaveDuration()), true) }))
    end]]

    if _T.EndlessExtermination and _T.EndlessExtermination.ScoreHudTracker then
        --_T.EndlessExtermination.ScoreHudTracker.SetLabel(Localize("/Lotus/Language/Onslaught/Score", { VALUE = UTIL.FormatNumber(gGameRules:GetNetPersistentVar(NV_MISSION_SCORE, 0)) }))
        UpdateScoreTracker()
    end
end

function OnAttemptUseDisabledConsumable()
    PlayTransmission(gearDisabledTransmission, gRegion:GetLocalPlayer())
    UTIL.PlaySound(gearDisabledSound)
end
