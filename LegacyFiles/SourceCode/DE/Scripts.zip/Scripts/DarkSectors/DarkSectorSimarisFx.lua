startDelay = 0
transmission = Resource()

local emissiveSym = Symbol("EmissiveMapAtten")
local unlitSym = Symbol("UnlitAtten")

function GiveTransmission()
    
    Sleep(startDelay)

    local playerAv = gRegion:GetLocalPlayerAvatar()
    if not IsNull(playerAv) and not IsNull(transmission) then
        playerAv:GiveTransmissionAsync(transmission)
    end

    local decos = gRegion:FindTagged(Symbol("SimarisDeco"))
    if #decos == 0 then
        return
    end
    
    local deco = decos[1]
    if IsNull(deco) then
        return
    end
    
    while IsNull(_T.TransmissionSoundInstance) do
        Sleep(0)
    end

    local s = deco:GetMeshScale()
    local t = 0
    local sc = s

    while not IsNull(_T.TransmissionSoundInstance) and not IsNull(deco) do
       local amp = _T.TransmissionSoundInstance:GetCurAmplitude()
       t = 2 + amp * 6.0
       deco:SetMaterialParam(emissiveSym, t, 0, 0, 0, true)
       deco:SetMaterialParam(unlitSym, t * 5, 0, 0, 0, true)
       sc = Lerp(s * 0.95, s * 1.1, amp)
       deco:SetMeshScale(sc)
       Sleep(0)
    end
end
