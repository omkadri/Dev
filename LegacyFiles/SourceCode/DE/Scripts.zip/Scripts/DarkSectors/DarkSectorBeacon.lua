
function OnTimePickup(instigator)
    if not gRegion:IsMaster() or not _T.OnTimePickup then
        return
    end

    _T.OnTimePickup(instigator)
end
