dropChance = 0.0014
dropRateUpgrade = Game.GAMEPLAY_PICKUP_RATE
dropRateUpgradeValidType = WeakResource("/Lotus/Types/Items/MiscItems/MiscItemBase")
goalTag = Symbol()

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"


local function _IsSpaceMission()
    local gameRules = gGameRules
    if IsNull(gameRules) or IsNull(gameRules:GetMission()) then
        return false
    end
    
    return gameRules:GetMission().archwingRequired and not gameRules:GetMission().isSharkwingMission
end

function IsSpaceMission()
    return _IsSpaceMission()
end

function IsNotSpaceMission()
    return not _IsSpaceMission()
end

function IsArchwingMission()
    local gameRules = gGameRules
    if IsNull(gameRules) or IsNull(gameRules:GetMission()) then
        return false
    end
    
    return gameRules:GetMission().archwingRequired
end

local function CheckRegion(starChart, currentRegion, currentRegionIdx, goalInfo)
    local regionMatches = false
    local node = goalInfo.mNode
    if node ~= "" then
        local region = starChart:GetRegionByMissionName(Symbol(node))
        regionMatches = currentRegion.name == region.name
    end
    
    if not regionMatches then
        local eventRegions = goalInfo.mRegions
        for _, regionIdx in ipairs(eventRegions) do
            if regionIdx == currentRegionIdx then
                regionMatches = true
                break
            end
        end
    end
    
    return regionMatches
end

function IsRelayReconstructionRegion()
    local gameRules = gGameRules
    if IsNull(gameRules) or IsNull(gameRules:GetMission()) then
        return false
    end
    
    local profile = gPlayerProfileMgr:GetPlayerProfile(0)
    if IsNull(profile) then
        return false
    end
    
    local gameData = profile:GetGameSpecificData()
    if IsNull(gameData) then
        return false
    end

    local locationTag = gameRules:GetMissionLocation()
    if IsNull(locationTag) or not locationTag:IsValid() then
        return false
    end

    local starChart = LOTUS_UTIL.GetStarChart()
    local currentRegion = starChart:GetRegionByMissionName(locationTag)
    local currentRegionIdx = starChart:GetNodeForMission(locationTag).region

    local worldState = gameData:GetWorldState()
    for _, goalInfo in ipairs(worldState.mGoals) do
        if goalInfo.mTag == goalTag and Engine.GetRelativeSeconds(goalInfo.mActivation) < 0 and Engine.GetRelativeSeconds(goalInfo.mExpiry) > 0 then
            local regionMatches = CheckRegion(starChart, currentRegion, currentRegionIdx, goalInfo)
            if regionMatches then
                return true
            end
        end
    end
    
    return false
end

function InitEventRegionResourceDrops(drop)
    local gameRules = gGameRules
    if IsNull(gameRules) or IsNull(gameRules:GetMission()) then
        return
    end
    
    local profile = gPlayerProfileMgr:GetPlayerProfile(0)
    if IsNull(profile) then
        return
    end
    
    local gameData = profile:GetGameSpecificData()
    if IsNull(gameData) then
        return
    end

    local locationTag = gameRules:GetMissionLocation()

    if IsNull(locationTag) or not locationTag:IsValid() then
        return
    end
    
    local starChart = LOTUS_UTIL.GetStarChart()
    local currentRegion = starChart:GetRegionByMissionName(locationTag)
    local missionInfo = gGameRules:GetMission()
    local isSpaceMission = _IsSpaceMission()
    local currentRegionIdx = starChart:GetNodeForMission(locationTag).region

    local worldState = gameData:GetWorldState()
    for _,goalInfo in ipairs(worldState.mGoals) do
        if Engine.GetRelativeSeconds(goalInfo.mActivation) < 0 and Engine.GetRelativeSeconds(goalInfo.mExpiry) > 0 then
            local regionMatches = CheckRegion(starChart, currentRegion, currentRegionIdx, goalInfo)
            
            if regionMatches and not isSpaceMission then
                for _,pickupType in ipairs(goalInfo.mRegionDrops) do
                    if not IsNull(pickupType) and pickupType:IsA(gPickUpType) then
                        drop:AddPotentialDrop(Type(pickupType), dropChance, {}, dropRateUpgrade, dropRateUpgradeValidType)
                    end
                end
            end

            if #goalInfo.mArchwingDrops > 0 and isSpaceMission and missionInfo.faction == goalInfo.mFaction and missionInfo.minEnemyLevel > 10 and missionInfo.missionType ~= Lotus_Game.MT_RACE then
                for _,pickupType in ipairs(goalInfo.mArchwingDrops) do
                    if not IsNull(pickupType) and pickupType:IsA(gPickUpType) then
                        drop:AddPotentialDrop(Type(pickupType), dropChance, {}, dropRateUpgrade, dropRateUpgradeValidType)
                    end
                end
            end
        end
    end

end

function InitSortieDrops(drop)
    local gameRules = gGameRules
    if IsNull(gameRules) or IsNull(gameRules:GetMission()) then
        return
    end
    
    local profile = gPlayerProfileMgr:GetPlayerProfile(0)
    if IsNull(profile) then
        return
    end
    
    local gameData = profile:GetGameSpecificData()
    if IsNull(gameData) then
        return
    end

    -- sortie conditional drops
    local sortieId = gameRules:GetMission().sortieId
    if sortieId == "" then
        return
    end

    local separatorIndex = string.find(sortieId, "_")
    if separatorIndex ~= nil then
        local worldState = gameData:GetWorldState()
        local sortieMongoId = string.sub(sortieId, separatorIndex + 1)

        for _,sortieInfo in ipairs(worldState.mSorties) do
            if Engine.GetRelativeSeconds(sortieInfo.mExpiry) > 0 and sortieInfo.mId.mId == sortieMongoId then
                for _,pickupType in ipairs(sortieInfo.mRegionDrops) do
                    if not IsNull(pickupType) and pickupType:IsA(gPickUpType) then
                        drop:AddPotentialDrop(Type(pickupType), dropChance, {}, dropRateUpgrade, dropRateUpgradeValidType)
                    end
                end
            end
        end
    end
end
