nodeName = Symbol()
quests = {WeakResource()}

truePortEntities = {Instance()}
truePortNames = {String()}

falsePortEntities = {Instance()}
falsePortNames = {String()}

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"


local function Result(b)
    local objs, ports
    if b then
        objs, ports = truePortEntities, truePortNames
    else
        objs, ports = falsePortEntities, falsePortNames
    end
    for i=1,math.min(#objs, #ports) do
        local obj, port = objs[i], ports[i]
        if port ~= "" and not IsNull(obj) then
            obj:FirePort(port)
        end
    end

    return b
end

function CheckNodeCompletion()
    local playerProfile = gPlayerProfileMgr:GetPlayerProfile(0)
    while IsNull(playerProfile) do
        Sleep(0)
        playerProfile = gPlayerProfileMgr:GetPlayerProfile(0)
    end
    local gameData = playerProfile:GetGameSpecificData()
    while IsNull(gameData) do
        Sleep(0)
        gameData = playerProfile:GetGameSpecificData()
    end

    return Result(gameData:HasCompletedMission(nodeName))
end

function CheckQuestCompletion()
    if #quests == 0 then
        return Result(false)
    end
    for i=1,#quests do
        if not LOTUS_UTIL.HasCompletedQuest(quests[i]) then
            return Result(false)
        end
    end
    return Result(true)
end
