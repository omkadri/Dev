iconDeco = Type()
iconYOffset = 0.8
iconScale = 1

local mChildDeco = nil


function SetDialogTriggerText(deco)
    repeat
        --SetLiteMode will try to use this colour, but it will be Null at first. Also we need to wait at least one frame for the deco's ID be set
        Sleep(0)
    until not IsNull(_G.UIColor_DarkGrey)

    local decoMode = deco:GetDecoMode()

    -- Make child deco
    mChildDeco = deco:Attach(iconDeco, EMPTY_SYMBOL, Vector(0, iconYOffset, 0))

    if not IsNull(mChildDeco) then
        mChildDeco:SetMeshScale(iconScale)

        if decoMode == Lotus_Game.DojoPlaceableDecoration_DM_COLLECTING_MATERIALS then
            mChildDeco:SetOverrideMaterialForAllSections(_T.DojoMgr.mDojo:GetDecoMaterialOverride(Framework.JsonProceduralLevel_ZS_CONSTRUCTION_QUEUED))
        elseif decoMode == Lotus_Game.DojoPlaceableDecoration_DM_UNDER_CONSTRUCTION then
            mChildDeco:SetOverrideMaterialForAllSections(_T.DojoMgr.mDojo:GetDecoMaterialOverride(Framework.JsonProceduralLevel_ZS_UNDER_CONSTRUCTION))
        elseif decoMode == Lotus_Game.DojoPlaceableDecoration_DM_DONE then
            mChildDeco:SetVisibility(false, true)
        end
    end
    
    local decoID = deco:GetID()
    if decoID == "" then    -- Will be empty for one that is currently being placed
        return
    end

    local statusChangeCallback = function(deco, oldMode, newMode)
            if newMode == Lotus_Game.DojoPlaceableDecoration_DM_DONE then
                if not IsNull(mChildDeco) then
                    mChildDeco:SetVisibility(false, true)
                end
            end
        end

    local focusChangeCallback = function(focused)
            local mode = deco:GetDecoMode()
            if focused then
                if not IsNull(mChildDeco) then
                    mChildDeco:SetVisibility(true, true)
                end
            elseif mode == Lotus_Game.DojoPlaceableDecoration_DM_DONE then
                if not IsNull(mChildDeco) then
                    mChildDeco:SetVisibility(false, true)
                end
            end
        end

    local onSelectedCallback = function(focused)
            if not IsNull(mChildDeco) then
                mChildDeco:SetVisibility(focused, true)
            end
        end

    _T.DojoMgr:AddDecoStatusChangedCallback(decoID, statusChangeCallback)

    _T.DojoMgr:AddDecoFocusChangedCallback(decoID, focusChangeCallback)

    _T.DojoMgr:AddDecoSelectedCallback(decoID, onSelectedCallback)
end

function UpdateBillboarding(entity)
    if not IsNull(entity) then
        local player = gRegion:GetLocalPlayer()
        if not IsNull(player) then
            local cameraControl = player:CameraControl()
            if not IsNull(cameraControl) then
                while not IsNull(entity) and not IsNull(_T.FxNamePlateParentDeco) and not IsNull(cameraControl) do
                    local cameraPos = cameraControl:GetViewPosition()
                    local decoPos = _T.FxNamePlateParentDeco:GetSimPosition()

                    local newRot = LookTo(cameraPos, decoPos)
                    entity:Teleport(decoPos, newRot)
                    Sleep(0)
                end
            end
        end
    end
end