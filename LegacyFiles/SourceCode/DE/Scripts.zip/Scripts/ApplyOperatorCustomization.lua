local BATTLE_BEGINS = Symbol("BattleBegins")
local BATTLE_CONCLUDED = Symbol("BattleConcluded")

local LOTUS_UTIL = require "Lotus.Interface.LotusUtilities"
local TRANS_UTIL = require "Lotus.Interface.TransmissionUtilities"
local OPERATOR = require "Lotus.Powersuits.Operator.OperatorLib"

operatorTransferenceInFx = Type()
warframeToOperatorFx = Type()
setInvisibleOnSpawn = true

function DynMusicStateChanged(oldState, newState)
    --print("Dyn music state changed from "..oldState.." to "..newState)

    local lotusAvatar = gRegion:GetLocalPlayerAvatar()
    if IsNull(lotusAvatar) then
        return
    end

    local localPlayerGameData = nil
    if not IsNull(gPlayerProfileMgr:GetPlayerProfile(0)) then
        localPlayerGameData = gPlayerProfileMgr:GetPlayerProfile(0):GetGameSpecificData()
    else
        return
    end

    local wasCombat = string.find(oldState, "Combat") ~= nil and string.find(newState, "Fallback") == nil
    local isCombat  = string.find(newState, "Combat") ~= nil and string.find(newState, "Fallback") == nil
    local wasIdle = not wasCombat
    local isIdle  = not isCombat

    local response = nil

    if wasCombat and isIdle then
        print("Combat -> idle")
        response = TRANS_UTIL:GetTransmissionResponse(BATTLE_CONCLUDED, localPlayerGameData, lotusAvatar)
    elseif isCombat and wasIdle then
        print("Idle -> combat")
        response = TRANS_UTIL:GetTransmissionResponse(BATTLE_BEGINS, localPlayerGameData, lotusAvatar)
    end

    if not IsNull(response) then
        lotusAvatar:GiveTransmissionAsync(response)
    end
end

local function _ApplyOperatorCustomization(operator)
    OPERATOR.ApplyOperatorCustomization(operator)
end

function ApplyOperatorCustomization()
    OPERATOR.ApplyOperatorCustomization(nil)
end

function ApplyOperatorCustomizationAndRemoveHood()
    OPERATOR.ApplyOperatorCustomization(nil)
    OPERATOR.RemoveOperatorHood()
end

function ApplyCustomizationAndUpdate(avatar)
    if not gRegion:IsMaster() then
        if setInvisibleOnSpawn then
            avatar:SetLocalVisibility(false)
        end
        _ApplyOperatorCustomization(avatar)
        local player = avatar:GetPlayer()
        while IsNull(player) do
            player = avatar:GetPlayer()
            Sleep(0)
        end
        avatar:SetLocalVisibility(true)
        local operatorSpawnFx = gRegion:CreateEntity(operatorTransferenceInFx, avatar:GetSimPosition(), avatar:GetRotation())
        avatar:Attach(operatorSpawnFx, EMPTY_SYMBOL)
        local instigatorAvatar = player:GetOwnedPowerSuitAvatar()
        if not IsNull(instigatorAvatar) then
            local warframeFx = gRegion:CreateEntity(warframeToOperatorFx, instigatorAvatar:GetSimPosition(), instigatorAvatar:GetRotation())
            instigatorAvatar:Attach(warframeFx, EMPTY_SYMBOL)
        end
    end
    
    while not IsNull(_T.spawningOperator) do
        if avatar:ReplicaLocallyControlled() then
            _T.spawningOperator = nil
        end
        Sleep(0)
    end
    
    if gRegion:IsMaster() then
        Sleep(1)
        if LOTUS_UTIL.GetUIMode() ~= LOTUS_UTIL.UI_MODE_IN_GAME or IsNull(avatar) or not avatar:ReplicaLocallyControlled() then
            return
        end

        if not _T.MusicStateChangeRegistered then

            local gameRules = gGameRules
            local musicMgr = gameRules:GetDynamicMusicMgr()

            if not IsNull(musicMgr) then
                musicMgr:RegisterStateChangeCallback("DynMusicStateChanged")

                _T.MusicStateChangeRegistered = true
            end
        end


        while not IsNull(avatar) do
            if LOTUS_UTIL.GetUIMode() == LOTUS_UTIL.UI_MODE_IN_GAME then
                LOTUS_UTIL.UpdateHeadTracking(avatar, true) -- why
            end
            
            --avatar:SetBoneDirector(spineBone, spineRot)
            
            Sleep(0)
        end
    end
end