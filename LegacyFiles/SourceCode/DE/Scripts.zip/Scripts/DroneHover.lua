hoverSound = Resource()
pitchMin = 0.5
pitchMax = 0.8

local soundInstance = nil

function DroneHover(droneAvatar)

    soundInstance = droneAvatar:PlaySound(hoverSound, false)
    local newPitch = 1.0
    local desiredPitch = 1.0
    
    while not IsNull(soundInstance) and not IsNull(droneAvatar) do
    
        local velocity = droneAvatar:GetVelocity()
        velocity.y = math.max(velocity.y, 0)
        local velocityLen = Length(velocity)
        velocityLen = velocityLen * 2.0
        
        local t = Clamp(velocityLen, 0.0, 1.0)
        --t = (t * t)
        desiredPitch = Lerp(pitchMin, pitchMax, t)
        
        newPitch = Lerp(newPitch, desiredPitch, DeltaTime())
    
        soundInstance:SetPitch(desiredPitch)
        
        Sleep(0)
    
    end
    
    if not IsNull(soundInstance) then
        soundInstance:Stop(false)
    end

end
