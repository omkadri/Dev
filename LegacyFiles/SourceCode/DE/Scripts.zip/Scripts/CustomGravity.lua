
customGravity = -98.1

function ApplyGravity(projectile)
    if not IsNull(projectile) then
        projectile:SetDisableGravity(true)
    end

    while true do
        if not IsNull(projectile) and not projectile:IsDead() then
            projectile:ApplyForce(Vector(0.0, customGravity, 0.0))
        end

        Sleep(0)
    end
end
