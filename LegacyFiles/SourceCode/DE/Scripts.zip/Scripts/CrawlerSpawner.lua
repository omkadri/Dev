hoverSound = Resource()
pitchMin = 0.5
pitchMax = 0.8
local soundInstance = nil
crawlerAgents = {Resource()}
boneName = Symbol("GAME_C1_TAIL6")
crawlerAttachOffset = Vector(0,-0.9,-0.5)
crawlerAttachRotation = Rotation(0,45,0)
crawlerCarryTag = Symbol("CarriedCrawler") --Tag for making sure that drones do not go after the carried crawler; match this tag to other crawler pickup abilities
heldAnim = Resource()
attachFx = Type() --"/Lotus/Fx/PowersuitAbilities/Necro/CloneTheDeadTeleportIn")
inheritlevel = false
checkForActiveCount = false
maxActiveAvatars = { 2, 3, 4, 5 } --by player count
avatarWeakRes = WeakResource()
spawnedAvatarSearchRange = 100
levelRestriction = 0 --only use this ability if enemy levels are >= this. 0 == don't check level restriction

function ChooseMeshAndDoDroneHoverScript(droneAvatar)
    --DroneHover.lua code----------------------------------------
    soundInstance = droneAvatar:PlaySound(hoverSound, false)
    local newPitch = 1.0
    local desiredPitch = 1.0
    
    while not IsNull(soundInstance) and not IsNull(droneAvatar) do
    
        local velocity = droneAvatar:GetVelocity()
        velocity.y = math.max(velocity.y, 0)
        local velocityLen = Length(velocity)
        velocityLen = velocityLen * 2.0
        
        local t = Clamp(velocityLen, 0.0, 1.0)
        --t = (t * t)
        desiredPitch = Lerp(pitchMin, pitchMax, t)
        
        newPitch = Lerp(newPitch, desiredPitch, DeltaTime())
    
        soundInstance:SetPitch(desiredPitch)
        
        Sleep(0)
    
    end
    
    if not IsNull(soundInstance) then
        soundInstance:Stop(false)
    end
    --DroneHover.lua ends----------------------------------------
    
    --Below is the spawn script for determining a random crawler for the Poison Drone
    
    if levelRestriction > 0 then
        if not IsNull(droneAvatar) then
            while IsNull(droneAvatar:GetAgent()) do
                Sleep(0)
            end
            local level = droneAvatar:GetAgent():GetCurrentLevel()
            if level < levelRestriction then
                return
            end
        end
    end
    
    --don't spawn with a crawler if we're in the Emissary Derelict assassinate mission
    local boss = gRegion:FindFirstTagged(Symbol("MutalistAvatar"))
    if not IsNull(boss) or _T.NoDroneCrawlers then
        return
    end
    
    if checkForActiveCount then
        local playerCount = gRegion:GetHumanPlayerAvatarCount()
        local maxAvatars = maxActiveAvatars[math.max(1, playerCount)]
        local activeAvatars = gRegion:FindAll(avatarWeakRes, droneAvatar:GetPosition(), 0, spawnedAvatarSearchRange)
        
        if #activeAvatars >= maxAvatars then
            return
        end
    end
    
    local currentRegion = droneAvatar:GetRegionMgr()
    local luckyCrawler = RandomInt(1, #crawlerAgents)
    
    --Set level
    local aiDir = currentRegion:GetNpcMgr():GetAiDirector()
    local agentLevel = 1
    if not IsNull(aiDir) then
        agentLevel = aiDir:GetMinEnemyLevel()
    end
    
    if inheritlevel then
        local droneAgent = droneAvatar:GetAgent()
        if not IsNull(droneAgent) then
            agentLevel = droneAgent:GetCurrentLevel()
        end 
    end
        
    
    local agent = currentRegion:GetNpcMgr():CreateAgentAtPosition(crawlerAgents[luckyCrawler], droneAvatar:GetSimPosition(), crawlerAttachRotation, Symbol(), agentLevel, true)
    if not IsNull(agent) then
        local crawlerAvatar = agent:GetAvatar();
        crawlerAvatar:AttachTo(droneAvatar, boneName)
        crawlerAvatar:SetAttachLocalSpace(crawlerAttachOffset, crawlerAttachRotation)
        
        crawlerAvatar:SetPostureModifier(Engine.PM_STUN, true)
        crawlerAvatar:SetPostureModifier(Engine.PM_HELD, true)
        
        crawlerAvatar:SetTag(crawlerCarryTag)
        droneAvatar:SetTag(crawlerCarryTag)       
        crawlerAvatar:PlayNonReplicatedAnimation(heldAnim, false, Engine.ATMM_PHYSICS_DRIVEN, Engine.PRT_LOOP, true)
        
        Sleep(0)
        
        local droneAgent = droneAvatar:GetAgent()
        if droneAgent and droneAgent:GetOwningEncounter() then
            local encounter = droneAgent:GetOwningEncounter()
            if not IsNull(encounter) then
                encounter:RegisterAgent(agent)
            end
        end
        
        if not IsNull(aiDir) and not IsNull(agent) and not agent:IsIgnoredByAiDirector() then
            aiDir:IncrementMaxPopulationSpawnCount()
        else
            local spawnedBy = droneAvatar:GetSpawnedByAvatar()
            if not IsNull(_T.cloneTheDeadAbility) and not IsNull(spawnedBy) then
                local instance = spawnedBy:GetInstance()
                if not IsNull(_T.cloneTheDeadAbility[instance]) then
                    crawlerAvatar:Attach(attachFx, EMPTY_SYMBOL, ZERO_VECTOR, ZERO_ROTATION, spawnedBy)
                end
            end
        end
        
        Sleep(0.5)
        if not IsNull(crawlerAvatar) and not IsNull(droneAvatar) then
            crawlerAvatar:SetFaction(droneAvatar:GetFaction())
        end
    end
end
