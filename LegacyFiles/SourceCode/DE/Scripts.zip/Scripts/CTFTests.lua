local orbitRadius = 0.5
local orbitSpeed = 3

local function Bob(entity)
    
    local pos = entity:GetPosition()
    local y = math.sin(Time())
    pos.y = y * 0.25
    entity:SetPosition(pos)
end

local function Orbit(entity, target)
    
    local pos = entity:GetPosition()
    local targetPos = target:GetPosition()
    
    pos.x = targetPos.x + (orbitRadius * math.cos(Time() * orbitSpeed))
    pos.y = targetPos.y + 1
    pos.z = targetPos.z + (orbitRadius * math.sin(Time() * orbitSpeed))
    entity:SetPosition(pos)

end


function EntityScript(entity)

    _T.entityParent = nil
    while true do
        local parentAvatar = entity:GetAttachParent()
        local a = 0
        
        if IsNull(_T.entityParent) or _T.entityParent:IsKilled() then
            Bob(entity)
            entity:SetMaterialParam(Lotus_Game.EMISSIVE_TINT_COLOR, 0, 1, 0, 1)
        else
            Orbit(entity, _T.entityParent)
        end

        Sleep(0)
    end

end


function AttachTriggerScript(trigger, avatar)

    local parent = trigger:GetAttachParent()
    local a = avatar
    
    _T.entityParent = avatar
    
    parent:SetMaterialParam(Lotus_Game.EMISSIVE_TINT_COLOR, 1, 0, 0, 1)
    --parent:AttachTo(avatar, Symbol("GAME_R1_ARM3"))

end

function DepositScript(trigger, entity)

    local t = trigger
    local tag = entity:GetTag()
    
    if tag == Symbol("SunFlag") or tag == Symbol("MoonFlag") then
        entity:Destroy()
    end

end