acolyteAgentTypes = { WeakResource() }
acolyteTransmissionTypes = { WeakResource() }

spawnInEffect = WeakResource()

local function SpawnAcolyte(enemyType, targetPlayer, distance, spawnFx, faction)

    local targetAvatar = targetPlayer:GetAvatar()
    if IsNull(targetAvatar) then
        return
    end
    
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    local agent = aiDir:CreateAgentNearEntity(Type(enemyType), targetAvatar, distance, EMPTY_SYMBOL) -- last arg is team, which is different from faction
    
    if not IsNull(agent) then
        local avatar = agent:GetAvatar()
        if not IsNull(avatar) then
            avatar:Attach(spawnFx, EMPTY_SYMBOL)
            agent:SetLockTarget(false)   -- Allow us to change target
            agent:SetScriptedPersistentTarget(targetAvatar)    -- Change target
            agent:SetLockTarget(true)    -- Prevent future target changes
            avatar:SetExclusiveTarget(targetAvatar)
            avatar:SetFaction(faction)
        end
    end
    
end

local function DoTransmissionTaunts(players, enemyIndices)
    
    for i = 1, #players do
        local transmission = Resource(acolyteTransmissionTypes[enemyIndices[i]])
        local player = players[i]
        
        if player:IsLocal() then
            player:GetAvatar():GiveTransmissionAsync(transmission)    
        end
    end
    
end

function SpawnAcolytes()

    local players = gRegion:GetHumanPlayers()
    local numPlayers = #players

    local resourceTypes = { spawnInEffect:GetFullName() }
    
    -- randomly match each player in the mission with one of the acolyte enemies
    local enemyIndices = {}
    for i = 1, #acolyteAgentTypes do
        table.insert(enemyIndices, math.random(1, #enemyIndices+1), i)
        if (i <= numPlayers) then
            table.insert(resourceTypes, acolyteAgentTypes[i]:GetFullName())
            table.insert(resourceTypes, acolyteTransmissionTypes[i]:GetFullName())
        end
    end
    
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    
    if (gRegion:IsMaster()) then
        gGameRules:BroadcastRequestResourceBatch(resourceTypes)
        gGameRules:HideGameSession(true) -- don't let players join the mission now that we've decided what guys to spawn, otherwise the resources for their enemy won't be loaded, or no enemy will spawn at all, if they show up after all the enemies spawned
        aiDir:SetEnableAutoSpawns(false)
    end
    
    -- wait for resources to load
    Sleep(5)
    
    -- players may have changed
    players = gRegion:GetHumanPlayers()
    if #players > numPlayers then
        -- someone joined the session somehow. an enemy will spawn for them, but it'll be spot-loaded..
        print("player joined hidden session!")
    end
    
    -- send transmission taunts to players
    DoTransmissionTaunts(players, enemyIndices)
    
    if not gRegion:IsMaster() then
        return
    end
    
    Sleep(5) -- wait for transmissions to end
    
    players = gRegion:GetHumanPlayers()
    if #players > numPlayers then
        -- someone joined the session somehow. an enemy will spawn for them, but it'll be spot-loaded
        print("player joined hidden session!")
    end
    
    -- spawn guys
    local aiDir = gRegion:GetNpcMgr():GetAiDirector()
    local faction = aiDir:GetFaction(1) -- we spawn in the second half of the sabotage mission, so this should be the faction of the enemies around us
    if faction == EMPTY_SYMBOL then
        faction = Symbol("Sentient")
    end
    local spawnFx = Resource(spawnInEffect)
    for i = 1, #players do
        local player = players[i]
        local enemyIdx = enemyIndices[i]
        local enemyType = acolyteAgentTypes[enemyIdx]
        
        SpawnAcolyte(enemyType, player, 10, spawnFx, faction)
    end
   
end